"""Apply only the two reviewed object hashes, then preserve resource receipts."""
import json
import os
from pathlib import Path
import subprocess
import sys
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
out = Path(__file__).resolve().parent
def sample(group):
    return {k:(group/k).read_text() for k in ['memory.peak','memory.events','memory.swap.current',
        'memory.high','memory.max','memory.swap.max','cgroup.events']}
closed = []
for unit in ['primelora-tc-aux-d2f5068ca318458f9a2f951f8c99e941.scope',
             'primelora-tc-aux-ef4ec15e9f624cf0a7bba812aeb67c73.scope',
             'primelora-tc-aux-dd1c5c78e9f64baeb620f36157f23544.scope']:
    identity = p.scope_identity(unit)
    group = Path(identity['path'])
    assert not p.owned_pids(group) and p.scope_still_owned(identity)
    resources = sample(group)
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    closed.append(dict(identity=identity,resources=resources,after='inactive'))
with (out/'audit_resources.json').open('x') as f:
    json.dump(closed,f,indent=2)
unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])
before = sample(group)
assert before['memory.high'].strip() == str(3*1024**3)
assert before['memory.max'].strip() == str(4*1024**3)
assert before['memory.swap.max'].strip() == '0' and os.sched_getaffinity(0) == {2,3,26,27}
commands = [
    ['python3',str(out/'download_archives.py'),'apply','torchtriton','--reviewed-audit-sha256',
     '210ffa6717d5efb07a9588969c55d6fa026b7fb07ca014b00008f3141730886d'],
    ['python3',str(out/'download_archives.py'),'apply','libcublas','--attempt','2','--reviewed-audit-sha256',
     '38148ed528a7b716404203129e05cf3d1453b879ed81dd09865fa3a901cb4eaa'],
]
codes = []
try:
    with (out/'apply.log').open('x') as log:
        for command in commands:
            completed = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
            codes.append(completed.returncode)
            completed.check_returncode()
finally:
    with (out/'apply_resources.json').open('x') as f:
        json.dump(dict(identity=identity,before=before,after=sample(group),returncodes=codes),f,indent=2)
print(json.dumps(dict(returncodes=codes)))
