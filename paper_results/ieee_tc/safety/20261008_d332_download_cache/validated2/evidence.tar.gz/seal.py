"""Keep the two named download removals and their public-byte proof auditable."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
raw = Path(__file__).resolve().parent
receipt = json.loads((raw/'apply_resources.json').read_text())
assert receipt['returncodes'] == [0,0]
identity = receipt['identity']
group = Path(identity['path'])
assert not p.owned_pids(group) and p.scope_still_owned(identity)
resources = {k:(group/k).read_text() for k in ['memory.peak','memory.events','memory.swap.current','cgroup.events']}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'apply_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,after='inactive'),f,indent=2)
out = p.ROOT/'paper_results/ieee_tc/safety/20261008_d332_download_cache'
out.mkdir(exist_ok=False)
paths = sorted(x for x in raw.rglob('*') if x.is_file())
archive = out/'evidence.tar.gz'
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in paths:
    assert token and token not in path.read_bytes()
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        tar.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in paths:
        assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw))).read()).hexdigest() == p.digest(path)
completed = [json.loads((raw/name/'complete.json').read_text()) for name in ['torchtriton','libcublas_attempt2']]
with (out/'summary.json').open('x') as f:
    json.dump(dict(kind='two_verified_public_download_archives_v1',removed_files=2,
        removed_allocated_bytes=sum(r['removed_allocated_bytes'] for r in completed),
        before=json.loads((raw/'torchtriton/audit.json').read_text())['before'],after=completed[-1]['after'],
        all_model_artifacts_results_environments_compiler_caches_retained=True,
        prior_helpers=[dict(path=str(x),sha256=p.digest(x)) for x in [
            raw.parent.parent.parent/'d328_20261008/cache1/conda_archive.py',
            Path('/home/qhq/experimental_cleanup_20260916/cleanup.py'),
            Path('/home/qhq/storage_cleanup_20260916/perform_cleanup.py')]],
        archive_sha256=p.digest(archive),raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths],
        caveat='Initial libcublas audit failed on absent API SHA; independent official object stream verified SHA before deletion. Future launch must recheck current headroom.'),f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+path.name+'\n')
print(json.dumps(dict(removed_allocated_bytes=sum(r['removed_allocated_bytes'] for r in completed),archive_bytes=archive.stat().st_size,scope_inactive=True)))
