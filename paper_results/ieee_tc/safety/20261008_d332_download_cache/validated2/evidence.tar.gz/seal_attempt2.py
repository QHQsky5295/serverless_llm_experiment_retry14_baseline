"""Finish storage evidence only; prior stop/removals are NOT repeated."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
raw = Path(__file__).resolve().parent
closed = json.loads((raw/'apply_cleanup.json').read_text())
assert closed['after'] == 'inactive'
assert subprocess.check_output(['systemctl','--user','show',closed['identity']['unit'],'-p','ActiveState','--value'],text=True).strip() == 'inactive'
parent = p.ROOT/'paper_results/ieee_tc/safety/20261008_d332_download_cache'
assert (parent/'summary.json').stat().st_size == 0
out = parent/'validated2'
out.mkdir(exist_ok=False)
paths = sorted(x for x in raw.rglob('*') if x.is_file())
archive = out/'evidence.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        tar.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in paths:
        assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw))).read()).hexdigest() == p.digest(path)
completed = [json.loads((raw/name/'complete.json').read_text()) for name in ['torchtriton','libcublas_attempt2']]
helpers = [raw.parent.parent/'d328_20261008/cache1/conda_archive.py',
    Path('/home/qhq/experimental_cleanup_20260916/cleanup.py'),
    Path('/home/qhq/storage_cleanup_20260916/perform_cleanup.py')]
summary = dict(kind='two_verified_public_download_archives_v1',removed_files=2,
    removed_allocated_bytes=sum(r['removed_allocated_bytes'] for r in completed),
    before=json.loads((raw/'torchtriton/audit.json').read_text())['before'],after=completed[-1]['after'],
    all_model_artifacts_results_environments_compiler_caches_retained=True,
    prior_helpers=[dict(path=str(x),sha256=p.digest(x)) for x in helpers],
    archive_sha256=p.digest(archive),raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths],
    initial_seal_failure=dict(reason='Wrong parent depth for D328 helper, after removals/closure; no removals repeated.',
        archive_path=str(parent/'evidence.tar.gz'),archive_sha256=p.digest(parent/'evidence.tar.gz'),
        empty_summary_retained=str(parent/'summary.json')),
    caveat='Initial libcublas audit required missing API SHA; official object bytes were streamed and SHA checked before deletion. Future launch must recheck headroom.')
with (out/'summary.json').open('x') as f:
    json.dump(summary,f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+path.name+'\n')
print(json.dumps(dict(removed_allocated_bytes=summary['removed_allocated_bytes'],archive_bytes=archive.stat().st_size,scope_inactive=True)))
