"""Reuse D328 guards/apply for three explicit verified public download archives.

Installed/extracted packages and compiler caches remain untouched. No wildcard
deletion. Audit precedes a separately reviewed SHA-authorized apply.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import time
import urllib.request

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('d328',
    '/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d328_20261008/cache1/conda_archive.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
TARGETS = {
    'torchtriton': ('pytorch', 'torchtriton', '2.2.0', 'torchtriton-2.2.0-py310'),
    'libcublas': ('nvidia', 'libcublas', '12.1.0.26', 'libcublas-12.1.0.26-0'),
    'libcusparse': ('nvidia', 'libcusparse', '12.0.2.55', 'libcusparse-12.0.2.55-0'),
}

def audit(channel, package, version):
    refs = d.guard()
    stamp = d.prior.stamp(d.ARCHIVE)
    record = json.loads(d.RECORD.read_text())
    api = f'https://api.anaconda.org/release/{channel}/{package}/{version}'
    with urllib.request.urlopen(api, timeout=20) as response:
        remote = json.load(response)
    matches = [r for r in remote['distributions'] if r['basename'] == 'linux-64/'+d.ARCHIVE.name]
    assert len(matches) == 1
    public = matches[0]
    digest = d.sha(d.ARCHIVE)
    assert digest == record['sha256']
    assert stamp['size'] == public['size'] == record['size']
    url = record['url']
    assert url == f'https://conda.anaconda.org/{channel}/linux-64/'+d.ARCHIVE.name
    # Some old NVIDIA API rows omit SHA256. Require the actual official object
    # bytes in that case, not an MD5-only deletion decision or a skipped check.
    public_object = None
    if public['sha256'] == '':
        h, count = hashlib.sha256(), 0
        with urllib.request.urlopen(url,timeout=30) as response:
            assert response.status == 200
            while block := response.read(4*1024*1024):
                h.update(block)
                count += len(block)
        assert count == stamp['size'] and h.hexdigest() == digest
        public_object = dict(streamed_bytes=count,sha256=h.hexdigest(),stored_copy=False)
    else:
        assert digest == public['sha256']
    with urllib.request.urlopen(urllib.request.Request(url,method='HEAD'),timeout=20) as response:
        assert response.status == 200 and int(response.headers['Content-Length']) == stamp['size']
    assert d.prior.stamp(d.ARCHIVE) == stamp
    d.save('audit.json',dict(created=time.time(),path=str(d.ARCHIVE),stat=stamp,sha256=digest,
        api=api,public=public,public_object=public_object,url=url,public_head=True,references=refs,
        retained_record=str(d.RECORD),retained_record_sha=d.sha(d.RECORD),
        before=d.prior.usage(),action='unlink_one_verified_public_download_archive'))
    print(json.dumps(dict(target=package,audit_sha256=d.sha(d.OUT/'audit.json'),
        reclaim_bytes=stamp['blocks']*512)),flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action',choices=['audit','apply'])
    parser.add_argument('target',choices=TARGETS)
    parser.add_argument('--reviewed-audit-sha256')
    parser.add_argument('--attempt',type=int,default=1)
    args = parser.parse_args()
    channel, package, version, name = TARGETS[args.target]
    assert args.attempt >= 1
    d.OUT = OUT/(args.target if args.attempt == 1 else f'{args.target}_attempt{args.attempt}')
    d.ARCHIVE = d.ROOT/(name+'.tar.bz2')
    d.RECORD = d.ROOT/name/'info/repodata_record.json'
    if args.action == 'audit':
        d.OUT.mkdir(exist_ok=False)
        audit(channel,package,version)
    else:
        d.apply(args.reviewed_audit_sha256)
