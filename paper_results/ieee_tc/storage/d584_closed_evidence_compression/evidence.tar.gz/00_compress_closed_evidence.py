"""Reuse lossless compression for two closed development outcomes and one monitor."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
RESULTS = RAW.parent.parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW / 'storage_identity.json', identity)
group = Path(identity['path'])
assert (group / 'memory.high').read_text().strip() == str(3 * p.GIB)
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
assert (group / 'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
closed = read(RAW.parent / 'd583_20261016/cleanup_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
seal = RESULTS / 'slora_qualification/d435_20261011/protected_before.json'
assert p.verify_seal(seal)['pass']

outcomes = [
    ('d516_20261014', '04382f60609b03fb562397a8e84466ee8abb5aa9a421330f71e1520f302a151b',
     'backup_result_receipt.json', 'backup_result_closure.json'),
    ('d529_20261014', 'd61db79fa0748e72390984e5733498a7d158037ac805ac78ec0bf4d9746ea7d9',
     'publication_receipt.json', 'publication_closure.json'),
]
bindings = []
for name, sha, pubname, closename in outcomes:
    directory = RESULTS / 'p2_backend_qualification' / name
    launch = read(directory / '7b_full_w0/launch.json')
    assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
    local = read(directory / 'local_cleanup.json')
    for key in ('identity', 'service_aux', 'service_identity', 'auxiliary_identity'):
        if key in local:
            assert not Path(local[key]['path']).exists()
    publication = read(directory / pubname)
    assert publication['passed'] and publication['head'] == publication['remote']
    subprocess.run(['git', 'merge-base', '--is-ancestor', publication['head'], 'HEAD'], cwd=MAIN, check=True)
    close = read(directory / closename)
    assert close['passed'] and close['actual_recursive_procs_empty']
    assert not Path(close['identity']['path']).exists()
    source = directory / '7b_full_w0/launch.launch/physical_deployment/main_outcome.json'
    assert p.digest(source) == sha
    bindings.append(dict(source=str(source), source_sha256=sha, published_checkpoint=publication['head'],
                         launch_sha256=p.digest(directory / '7b_full_w0/launch.json')))

hydra = RESULTS / 'hydraserve_qualification/d582_20261016'
close = read(hydra / 'closure.json')
assert close['actual_recursive_empty'] and close['service_gone']
assert not Path(close['service']['path']).exists()
publication = read(hydra / 'result_publication_receipt.json')
assert publication['passed'] and publication['head'] == publication['remote']
close = read(hydra / 'result_publication_closure.json')
assert close['passed'] and close['actual_recursive_procs_empty'] and close['path_gone']
assert not Path(close['identity']['path']).exists()
stop = read(hydra / 'remote_stop.json')
assert stop['all_owned_units_inactive'] and stop['download_hashes_match_remote']
monitor = hydra / 'remote_monitor.log'
assert p.digest(monitor) == stop['hashes']['remote_monitor.log']
bindings.append(dict(source=str(monitor), source_sha256=p.digest(monitor),
                     published_checkpoint=publication['head'], remote_stop_sha256=p.digest(hydra / 'remote_stop.json')))
save(RAW / 'bindings.json', bindings)

original = MAIN / 'scripts/ieee_tc/compress_closed_main_outcomes.py'
data = original.read_bytes()
assert hashlib.sha256(data).hexdigest() == '3fbe720eaca01f6451a028ece71eba9600df420f1d233fdd669b3e2822e1f33b'
namespace = {'__name__': 'compression_recipe', '__file__': str(original)}
exec(compile(data, str(original), 'exec'), namespace)
receipt1 = MAIN / 'paper_results/ieee_tc/storage/20261016_d584_closed_development_outcomes.json'
namespace['OUT'] = receipt1
namespace['TARGETS'] = [dict(run=name + '/7b_full_w0', audit_sha=sha) for name, sha, _, _ in outcomes]
assert namespace['main']() == 0

# As in D581, read HydraServe's real canonical launch receipt, not a synthetic success record.
source = data.decode()
assert source.count("(raw / 'launch.json')") == 2
source = source.replace("(raw / 'launch.json')", "(raw.parent / 'launch_gate.json')")
namespace = {'__name__': 'hydra_monitor_recipe', '__file__': str(original)}
exec(compile(source, str(original), 'exec'), namespace)
receipt2 = MAIN / 'paper_results/ieee_tc/storage/20261016_d584_closed_hydraserve_monitor.json'
namespace['RAW_ROOT'] = hydra.parent
namespace['OUT'] = receipt2
namespace['TARGETS'] = [dict(run=hydra.name + '/launch_gate.launch', audit_sha=bindings[-1]['source_sha256'],
                             remote_monitor_log='remote_monitor.log')]
assert namespace['main']() == 0
assert p.verify_seal(seal)['pass']
entries = read(receipt1)['entries'] + read(receipt2)['entries']
assert len(entries) == 3 and all(row['audit_sha_matches'] for row in entries)
summary = dict(passed=True, files=3, reclaimed_bytes=sum(row['allocated_bytes_reclaimed'] for row in entries),
               free_bytes=read(receipt2)['after']['available_bytes'],
               receipts={str(path):p.digest(path) for path in (receipt1, receipt2)},
               protected_unchanged=True, core_recipe_sha256=p.digest(original))
save(RAW / 'storage_result.json', summary)
print(json.dumps(summary))
