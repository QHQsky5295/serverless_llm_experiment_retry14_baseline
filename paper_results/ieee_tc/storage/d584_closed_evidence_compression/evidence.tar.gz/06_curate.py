"""Reuse D539 guarded curation for D583 cache and D584 lossless evidence."""
from hashlib import sha256
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent.parent / 'serverless_qualification/d539_20261015/curate.py'
assert sha256(original.read_bytes()).hexdigest() == '5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source = original.read_text()

def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace("RAW.parent.parent/'storage_maintenance/d538_20261015'", "RAW.parent/'d583_20261016'")
replace("RAW.parent.parent/'vllm_qualification/d532_20261015'", "RAW.parent.parent/'hydraserve_qualification/d582_20261016'")
replace("((RAW,'review'),(CLEAN,'cleanup'))", "((RAW,'storage'),(CLEAN,'cleanup'))")
replace(source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')], """clean=read(CLEAN/'cleanup_receipt.json')
assert clean['passed'] and clean['returncode']==0
before=read(D532/'cache_cleanup_before.json');after=read(D532/'cache_cleanup_after.json')
assert before['current_cache_bytes_rehashed'] and before['current_original_bytes_rehashed']
assert before['payload_bytes']==12889613139 and before['files']==4970
assert after['removed'] and after['observed_reclaimed_bytes']==12908072960
assert not after['raw_results_removed'] and not after['unique_artifacts_removed']
summary=read(RAW/'storage_result.json')
assert summary['passed'] and summary['files']==3
receipts=[Path(path) for path in summary['receipts']]
bindings={r['source']:r for r in read(RAW/'bindings.json')}
for receipt in receipts:
    assert p.digest(receipt)==summary['receipts'][str(receipt)]
    compressed=read(receipt)
    assert compressed['source_archive_round_trip_verified']
    for row in compressed['entries']:
        assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']==bindings[row['source']]['source_sha256']
        assert not Path(row['source']).exists() and p.digest(Path(row['archive']))==row['archive_sha256']
""")
replace(source[source.index('specs=['):source.index('reports=[]')], """specs=[('storage/d583_targeted_cache_reclaim',
 [CLEAN/n for n in ('run_cleanup.py','reclaim_d582.py','close.py','cleanup_identity.json',
 'cleanup_receipt.json','cleanup_closure.json','retained_metadata.tar.gz')]+
 [D532/n for n in ('cache_cleanup_before.json','cache_cleanup_after.json')]+
 [CLEAN.parent/'d538_20261015/run_cleanup.py', CLEAN.parent/'d575_20261016/reclaim_d574.py',
 RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py'],
 {'cleanup_receipt.json':CLEAN/'cleanup_receipt.json','cleanup_closure.json':CLEAN/'cleanup_closure.json',
 'cache_cleanup_after.json':D532/'cache_cleanup_after.json'}),
 ('storage/d584_closed_evidence_compression',
 [RAW/n for n in ('compress_closed_evidence.py','close.py','bindings.json','storage_identity.json',
 'storage_result.json','storage_closure.json','curate.py')]+receipts+
 [ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py'],
 {'outcomes_receipt.json':receipts[0],'monitor_receipt.json':receipts[1],
 'storage_result.json':RAW/'storage_result.json','storage_closure.json':RAW/'storage_closure.json'})]
""")
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'curate.py')})
