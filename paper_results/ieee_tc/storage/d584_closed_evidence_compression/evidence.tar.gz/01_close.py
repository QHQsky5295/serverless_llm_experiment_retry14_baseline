"""Reuse exact-identity empty-resource closure for storage and preservation."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
original = RAW.parent / 'd578_20261016/close.py'
exec(compile(original.read_text(), str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'close.py')})
