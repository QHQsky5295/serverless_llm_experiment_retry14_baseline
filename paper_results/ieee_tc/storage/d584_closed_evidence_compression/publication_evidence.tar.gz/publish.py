"""Reuse exact-path checkpoint, source/archive/secrets/user-dirt guards."""
from hashlib import sha256
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent.parent / 'serverless_qualification/d539_20261015/publish.py'
assert sha256(original.read_bytes()).hexdigest() == '34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source = original.read_text()
changes = {
    '3e759d75b6e69e182d646d87aca5090f5935024f': 'a350fd0366f5e3ea9ba024ff3b70325ea02d950e',
    "('review','curation')": "('storage','curation')",
    "'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'":
        "'docs/ieee_tc/D583_D584_STORAGE_MAINTENANCE.md'",
    'tc: preserve startup queue review and safe cache reclaim (D538-D539)':
        'tc: preserve D582 cache reclaim and lossless closed evidence (D583-D584)',
    "names=['docs/ieee_tc/EXECUTION_STATUS.md'":
        "names=['paper_results/ieee_tc/storage/20261016_d584_closed_development_outcomes.json','paper_results/ieee_tc/storage/20261016_d584_closed_hydraserve_monitor.json','docs/ieee_tc/EXECUTION_STATUS.md'",
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'publish.py')})
