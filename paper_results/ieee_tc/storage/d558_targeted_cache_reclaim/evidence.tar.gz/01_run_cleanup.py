"""Reuse exact-closure/protected/source guards from bounded D538 maintenance."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d538_20261015/run_cleanup.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='6749cdfcd7d4b42fedb43781c9e6a9257f7a431764a226c2c748176790112c21'
source=data.decode()
changes={
    'vllm_qualification/d532_20261015':'vllm_qualification/d557_20261016',
    "('analysis','result','publication','review','review_backup')":"('analysis','contract','result','publication')",
    '3e759d75b6e69e182d646d87aca5090f5935024f':'1e85658f0410c38096ba94534d6af4cc7ebde14b',
    'bde215460acb9e850efa479a89bda6fc39a2bd7d':'aff60bb210c6d1fb9ce94534c5ef37521976bc0a',
    "recipe=OLD/'reclaim_objects.py'":"recipe=RAW/'reclaim_d557.py'",
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'run_cleanup.py')})
