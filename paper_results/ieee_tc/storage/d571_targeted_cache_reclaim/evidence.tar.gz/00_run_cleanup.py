"""Reuse D568/D538 guards; freshly audit the sealed D569 download copies."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d538_20261015/run_cleanup.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='6749cdfcd7d4b42fedb43781c9e6a9257f7a431764a226c2c748176790112c21'
source=data.decode()
changes={
    'vllm_qualification/d532_20261015':'loquetier_qualification/d569_20261016',
    "('analysis','result','publication','review','review_backup')":"('analysis','cross','result','result_publication')",
    '3e759d75b6e69e182d646d87aca5090f5935024f':'cc5ad04d887a4ebf99c55bb4417b80760b9f1bc0',
    'bde215460acb9e850efa479a89bda6fc39a2bd7d':'5486c4d6a8417ef67484d2b1dbb65d0cd938ff27',
    "recipe=OLD/'reclaim_objects.py'":"recipe=RAW/'reclaim_d569.py'",
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'run_cleanup.py')})
