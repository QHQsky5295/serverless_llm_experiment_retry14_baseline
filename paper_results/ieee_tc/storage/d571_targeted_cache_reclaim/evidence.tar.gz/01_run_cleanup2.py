"""Same deletion contract after transient remote-ref verification failure."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d538_20261015/run_cleanup.py'
driver=(RAW/'run_cleanup.py').read_text()
old="source=data.decode()"
assert driver.count(old)==1
driver=driver.replace(old,"source=data.decode().replace('cleanup_identity.json','cleanup2_identity.json').replace('cleanup_receipt.json','cleanup2_receipt.json').replace('cleanup.log','cleanup2.log')")
exec(compile(driver,str(RAW/'run_cleanup.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'run_cleanup2.py')})
