"""Existing full-content/reference audit, exact new target and 500 prepared IDs."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='e66e17f0a2ca0f72c0c0ae9f6bb6c6da8351b924f4d72ce4f7e93c64476892bb'
source=data.decode().replace('d532','d569').replace('d569_20261015','d569_20261016')
changes={
    '/tmp/tc-d569-7bv/':'/tmp/tc-d569-7bl/',
    'ROOT = Path(__file__).resolve().parent':"ROOT = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/loquetier_qualification/d569_20261016')",
    'main_comparison/d569_vllm_w1/':'loquetier/d569_capacity_prefix1000/',
    'f3b2344147c51db9407b9711ec6dbc59af8c6c5007dd7c9d90fdd68efcf6ddb7':'31737ac6b8e4721aa52885d6beca45a1f7c27f9fdf58435df83beacab9b88cfe',
    "audit['offered_unique_adapters'] == 132":"audit['offered_unique_adapters'] == 60 and audit['deployment_prepared_adapters'] == 500",
    "audit['verified_materialized_bytes'] == 3300789780":"audit['verified_materialized_bytes'] == 12985984450",
    "len(selected) == audit['offered_unique_adapters']":"len(selected) == audit['deployment_prepared_adapters']",
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'reclaim_d569.py')})
