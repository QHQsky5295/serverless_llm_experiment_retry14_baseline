"""Reuse fresh cache/source SHA, reference and process checks on D574 only."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='e66e17f0a2ca0f72c0c0ae9f6bb6c6da8351b924f4d72ce4f7e93c64476892bb'
source=data.decode().replace('d532','d574').replace('d574_20261015','d574_20261016')
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('ROOT = Path(__file__).resolve().parent',
        "ROOT = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d574_20261016')")
replace("TARGET = Path('/tmp/tc-d574-7bv/remote_artifacts/objects')", "TARGET = ROOT/'remote_artifacts/objects'")
replace("launch = json.loads((ROOT/'launch7b.json').read_text())\nassert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed'] and launch['service_returncode'] == 0", """launch = json.loads((ROOT/'result.json').read_text())
assert launch['passed'] and launch['gpu_released'] and launch['physical_native_contexts_qualified']
closed = json.loads((ROOT/'closure.json').read_text())
assert closed['actual_recursive_empty'] and closed['service_gone']
assert not Path(closed['service']['path']).exists()
assert json.loads((ROOT/'remote_stop.json').read_text())['all_owned_units_inactive']""")
replace('main_comparison/d574_vllm_w1/result1/audit.json',
        'hydraserve/d574_native_lifecycle_qualification_v2/affected_qualification.json')
replace('f3b2344147c51db9407b9711ec6dbc59af8c6c5007dd7c9d90fdd68efcf6ddb7',
        '2abb52ba6126629bb21aee2ef749a052fc8c5404de93b25a8566076ae10a2c5b')
replace("assert audit['workload_passed'] and audit['offered_unique_adapters'] == 132 and audit['verified_materialized_bytes'] == 3300789780", """assert audit['passed'] and audit['n_native_contract_complete']==100 and audit['remote_transfers']==29
receipts = [json.loads(p.read_text()) for p in (ROOT/'remote_artifacts/receipts').glob('*.json')]
assert len(receipts)==29 and all(r['evidence']['content_verified'] for r in receipts)
assert all(r['evidence']['remote_pack_performed'] is False for r in receipts)
audit['offered_unique_adapters']=29
audit['verified_materialized_bytes']=sum(r['evidence']['payload_bytes_verified'] for r in receipts)
assert audit['verified_materialized_bytes']==724665100""")
replace("ROOT/'remote_resolver_evidence/receipts'", "ROOT/'remote_artifacts/receipts'")
start=source.index('metadata = TARGET.parent')
end=source.index("before = shutil.disk_usage('/home/qhq').free")
replace(source[start:end], """metadata = TARGET.parent
# The HydraServe resolver stores original evidence alongside its cache, not
# in /tmp. Preserve it in place and verify the already published receipts.
import tarfile
published = json.loads((audit_path.parent/'manifest.json').read_text())
refs = {r['path']:r for r in published['archive_members'].values()}
for path in (metadata/'receipts').glob('*.json'):
    assert str(path) in refs and digest(path)==refs[str(path)]['sha256']
retained = [metadata/'run_contract.json'] + sorted((metadata/'journals').glob('*'))
assert len(retained)>1 and all(p.is_file() and not p.is_symlink() for p in retained)
archive = Path(__file__).resolve().parent/'retained_metadata.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in retained:bundle.add(path,arcname=str(path.relative_to(metadata)),recursive=False)
with tarfile.open(archive) as bundle:
    for path in retained:
        assert sha256(bundle.extractfile(str(path.relative_to(metadata))).read()).hexdigest()==digest(path)
""")
replace('metadata_copies_hash_match=True',
        "published_receipts_hash_match=True,metadata_retained_in_place=True,metadata_archive_sha256=digest(archive)")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'reclaim_d574.py'),'sha256':sha256})
