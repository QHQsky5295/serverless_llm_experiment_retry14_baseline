"""Reuse exact-identity, recursively-empty maintenance closure."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
original = RAW.parent / 'd575_20261016/close.py'
exec(compile(original.read_text(), str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'close.py')})
