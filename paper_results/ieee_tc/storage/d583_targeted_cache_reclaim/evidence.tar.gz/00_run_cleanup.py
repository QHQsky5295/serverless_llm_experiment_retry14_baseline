"""Apply the proven bounded cleanup orchestration to sealed D582 only."""
from hashlib import sha256
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent / 'd538_20261015/run_cleanup.py'
data = original.read_bytes()
assert sha256(data).hexdigest() == '6749cdfcd7d4b42fedb43781c9e6a9257f7a431764a226c2c748176790112c21'
source = data.decode()
changes = {
    'vllm_qualification/d532_20261015': 'hydraserve_qualification/d582_20261016',
    "('analysis','result','publication','review','review_backup')": "('prepare','remote_prelaunch','curation','publication','audit','output_comparison','output_comparison2','result','result_publication')",
    '3e759d75b6e69e182d646d87aca5090f5935024f': 'a350fd0366f5e3ea9ba024ff3b70325ea02d950e',
    'bde215460acb9e850efa479a89bda6fc39a2bd7d': '80e08b4c6e7c2874b1b237500a00811ec06cd8c5',
    "recipe=OLD/'reclaim_objects.py'": "recipe=RAW/'reclaim_d582.py'",
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'run_cleanup.py')})
