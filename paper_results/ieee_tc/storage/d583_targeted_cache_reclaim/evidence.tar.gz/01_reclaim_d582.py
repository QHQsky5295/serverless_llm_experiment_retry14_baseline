"""Rehash current cache and original objects; retain every raw D582 measurement."""
from pathlib import Path

RAW = Path(__file__).resolve().parent
recipe = RAW.parent / 'd575_20261016/reclaim_d574.py'
text = recipe.read_text()
prefix = text.split('exec(compile(source,', 1)[0]
assert len(prefix) < len(text)
namespace = {'__name__': 'reclaim_recipe', '__file__': str(RAW / 'reclaim_d582.py')}
exec(compile(prefix, str(recipe), 'exec'), namespace)
source = namespace['source'].replace('d574', 'd582')
changes = {
    'hydraserve/d582_native_lifecycle_qualification_v2/affected_qualification.json':
        'hydraserve/d582_lifecycle_full_w2_result/full_w2_evaluation.json',
    '2abb52ba6126629bb21aee2ef749a052fc8c5404de93b25a8566076ae10a2c5b':
        'e9518e38884310f76fddfafe182d0a3231a36c81362bb04f899e5cc05efdaef3',
    "assert audit['passed'] and audit['n_native_contract_complete']==100 and audit['remote_transfers']==29":
        "assert audit['full_audit_pass'] and audit['n_v1_contract_complete']==4000 and audit['remote_transfers']==497",
    'len(receipts)==29': 'len(receipts)==497',
    "audit['offered_unique_adapters']=29": "audit['offered_unique_adapters']=497",
    "audit['verified_materialized_bytes']==724665100":
        "audit['verified_materialized_bytes']==12889613139",
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(namespace['original']), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'reclaim_d582.py'),
      'sha256': namespace['sha256']})
