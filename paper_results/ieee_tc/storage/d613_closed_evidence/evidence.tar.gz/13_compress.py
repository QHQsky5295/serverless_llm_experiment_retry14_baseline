"""Reuse D604 verified compression on three exact, closed D607 evidence files."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d604_20261017/compress.py')
code = source.read_text()
start = code.index('targets = [')
end = code.index('\nchecks = []', start)
code = code[:start] + """targets = [
    dict(run='d607_20261017/7b_canonical_files_full_w2'),
    dict(run='d607_20261017/7b_canonical_files_full_w2', remote_monitor_log='remote_monitor.log'),
    dict(run='d607_20261017/7b_canonical_files_full_w2',
        run_result='experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d607_7b_canonical_files_full_w2.json'),
]
assert p.host_sample()['available_bytes'] >= 24*p.GIB
assert (RAW.stat().st_dev == ROOT.stat().st_dev)
import shutil
assert shutil.disk_usage(ROOT).free >= 100*p.GIB + 2*p.GIB
""" + code[end:]
exec(compile(code, str(source), 'exec'))
