"""Reuse D607 explicit-path, verified small-evidence publication procedure."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/storage/d613_closed_evidence'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,data):
    with path.open('x') as stream:json.dump(data,stream,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('branch','--show-current')=='retry14_continuous_queue_v2'
assert git('rev-parse','HEAD')=='d99efb86bbb04143ab1826bd26fd5b2d18550f05'
assert not git('diff','--cached','--name-only')
assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')
preserved={
    ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(path)==sha,path
result=read(RAW/'storage_result.json');receipt=read(RAW/'receipt.json')
assert receipt['passed'] and receipt['result_sha256']==p.digest(RAW/'storage_result.json')
closure=read(RAW/'storage_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
assert len(result['entries'])==4
assert sum(row['allocated_bytes_reclaimed'] for row in result['entries'])==1335574528
for row in result['entries']:
    assert row['audit_sha_matches'] and row['removed_uncompressed_duplicate']
    assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']
    assert not Path(row['source']).exists()
    assert p.digest(Path(row['archive']))==row['archive_sha256']
assert p.digest(ROOT/'faaslora/memory/residency_manager.py')=='fd783131934664f1dee49f78b21366c2aff7264d60a15c2a9bcb975e207bec4f'
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
gate=p.preflight([ROOT],32*1024*1024)
assert not any('host_memory_below_stop' in x or 'filesystem_below_stop' in x for x in gate['issues'])
save(RAW/'publication_resource_gate.json',gate)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
doc=ROOT/'docs/ieee_tc/D613_CLOSED_EVIDENCE_STORAGE.md'
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json')])
review=ROOT/'docs/ieee_tc/D614_RESOURCE_WORKING_POINT_AUDIT.md'
files += [doc,review,RAW.parent/'d604_20261017/compress.py',RAW.parent/'d609_20261017/compress.py',RAW.parent/'d592_20261017/close.py']
assert sum(path.stat().st_size for path in files)<32*1024*1024
OUT.mkdir(parents=True,exist_ok=False);members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as bundle:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<8*1024*1024;clean(data)
        if path.suffix=='.py':ast.parse(data)
        elif path.suffix=='.json':json.loads(data)
        name=f'{i:02d}_{path.name}';info=tarfile.TarInfo(name)
        info.size,info.mode,info.mtime=len(data),0o600,0
        bundle.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(members)
    for name,record in members.items():assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==record['sha256']
save(OUT/'summary.json',dict(passed=True,kind='d613_verified_closed_log_storage_v1',
    storage=result,receipt=receipt,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},source_commit=git('rev-parse','HEAD'),
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz'),
    production_changed=False,inference_runs_added=0,ranking_eligible=False))
with (OUT/'result.sha256').open('x') as stream:
    for name in ('summary.json','evidence.tar.gz'):stream.write(p.digest(OUT/name)+'  '+name+'\n')
names=[str(doc.relative_to(ROOT)),str(review.relative_to(ROOT)),'docs/ieee_tc/EXECUTION_STATUS.md']
names += [str((OUT/name).relative_to(ROOT)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
for name in names:
    if not name.endswith('.tar.gz'):clean((ROOT/name).read_bytes())
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: archive closed evidence and bound the next model resource working point (D613-D614)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD');remote=git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head==remote
for path,sha in preserved.items():assert p.digest(path)==sha,path
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity))
print(json.dumps(dict(passed=True,head=head,remote_equal=True,files=len(names))))


