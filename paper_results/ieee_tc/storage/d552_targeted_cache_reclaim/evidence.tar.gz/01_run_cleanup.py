"""Reuse D538 bounded closure/protection gates for the new D537 cache target."""
import json
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
latest=RAW.parent.parent/'p2_backend_qualification/d551_20261015'
for name in ('analysis','review','publication','publication2'):
    closed=json.loads((latest/(name+'_closure.json')).read_text())
    assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
    assert not Path(closed['identity']['path']).exists()
assert json.loads((latest/'remote_stop.json').read_text())['all_owned_units_inactive']
original=RAW.parent/'d538_20261015/run_cleanup.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='6749cdfcd7d4b42fedb43781c9e6a9257f7a431764a226c2c748176790112c21'
source=data.decode().replace('vllm_qualification/d532_20261015','serverless_qualification/d537_20261015')
changes={
    "('analysis','result','publication','review','review_backup')":"('analysis','result','result_publication','cross')",
    '3e759d75b6e69e182d646d87aca5090f5935024f':'723818eb9da2c73fca80ffc797be60a42cc3bf53',
    "recipe=OLD/'reclaim_objects.py'":"recipe=RAW/'reclaim_d537.py'",
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'run_cleanup.py')})
