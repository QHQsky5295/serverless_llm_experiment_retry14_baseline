"""Reuse SHA-bound D532 full-content reclamation for closed D537 only."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='e66e17f0a2ca0f72c0c0ae9f6bb6c6da8351b924f4d72ce4f7e93c64476892bb'
source=data.decode().replace('d532','d537')
changes={
    'ROOT = Path(__file__).resolve().parent':"ROOT = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/serverless_qualification/d537_20261015')",
    '/tmp/tc-d537-7bv/':'/tmp/tc-d537-7br/',
    "ROOT/'launch7b.json'":"ROOT/'launch7b_repaired.json'",
    'main_comparison/d537_vllm_w1/':'main_comparison/d537_serverlessllm_w1/',
    'f3b2344147c51db9407b9711ec6dbc59af8c6c5007dd7c9d90fdd68efcf6ddb7':'23cb0f2b3296458e375147baae125d553a7cb1d78d30d62a3d3d7ffec1c70800',
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'reclaim_d537.py')})
