"""Reuse exact-identity recursive-empty CPU maintenance closure."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d545_20261015/close.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='2c76f37723295d61319bc85191b8fe5a3858a2c6a7e2d48ed2f2c760f700efe3'
exec(compile(data,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'close.py')})
