"""Reuse D547 checked content/receipt curation for closed D537 cache."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d547_20261015/curate.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='230a33fcc473f40d3bf50c1e14fabf81e377e342bb5db4b4705d22057e3cd0cd'
source=data.decode().replace('d547','d552').replace('D547','D552').replace('d536','d537')
source=source.replace('vllm_qualification/d537_20261015','serverless_qualification/d537_20261015')
source=source.replace("OLD.parent/'d532_20261015/reclaim_objects.py'",
    "RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py'")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py')})
