"""Reuse D545 exact-path publication with the current checkpoint identity."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d545_20261015/publish.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='af14e3c0646e4c5f0102757d54ead2f2e02716a420417bf198af2c11e71fcbaf'
source=data.decode().replace('d545','d552').replace('D545','D552').replace('D544','D537')
source=source.replace('dfeacf4e6042318b4cf365a4f9620a2a2dbd305e','723818eb9da2c73fca80ffc797be60a42cc3bf53')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py')})
