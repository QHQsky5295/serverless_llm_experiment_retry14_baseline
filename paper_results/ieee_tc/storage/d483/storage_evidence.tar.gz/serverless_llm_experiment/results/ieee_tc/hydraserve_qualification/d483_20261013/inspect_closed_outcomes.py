"""Metadata-only enumeration for the existing explicitly gated archiver."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.compress_closed_main_outcomes import RAW_ROOT, require_closed_launch

rows = []
for source in RAW_ROOT.glob('*/*/launch.launch/physical_deployment/main_outcome.json'):
    raw = source.parents[2]
    stat = source.lstat()
    row = dict(run=str(raw.relative_to(RAW_ROOT)), source=str(source),
               size=stat.st_size, allocated=stat.st_blocks*512)
    try:
        launch = json.loads((raw/'launch.json').read_text())
        require_closed_launch(launch, allow_closed_failure=True)
        row.update(closed=True, launch_pass=launch['pass'],
                   launch_sha256=p.digest(raw/'launch.json'),
                   archive_exists=source.with_suffix('.json.gz').exists(),
                   receipt_exists=(raw/'compression_receipt.json').exists())
    except (OSError, ValueError, RuntimeError) as error:
        row.update(closed=False, reason=type(error).__name__+': '+str(error))
    rows.append(row)
rows.sort(key=lambda row: row['allocated'], reverse=True)
with (ROOT/'closed_outcomes_inventory.json').open('x') as out:
    json.dump(rows, out, indent=2)
print(json.dumps(dict(files=len(rows), allocated=sum(r['allocated'] for r in rows),
                     largest=rows[:30]), indent=2))
