"""Small regression before lossless compression; no inference/model action."""
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(name,data):
    with (ROOT/name).open('x') as out:json.dump(data,out,indent=2)
save('test_identity.json',p.scope_identity(p.cg_path().name))
with (ROOT/'test.log').open('x') as log:
    rc=subprocess.run([sys.executable,'-B','-m','unittest',
        'tests.test_ieee_tc_closed_outcome_archive','-v'],cwd=MAIN,stdout=log,stderr=subprocess.STDOUT,timeout=30).returncode
save('test_result.json',dict(passed=rc==0,returncode=rc,source_sha256={name:p.digest(MAIN/name) for name in
    ('scripts/ieee_tc/compress_closed_main_outcomes.py','tests/test_ieee_tc_closed_outcome_archive.py')}))
print((ROOT/'test.log').read_text())
sys.exit(rc)
