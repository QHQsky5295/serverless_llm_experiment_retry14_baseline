"""Reuse exact-owned recursive-empty scope closure with new campaign identity."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
template=ROOT.parent/'d481_20261013/close.py'
source=template.read_text().replace("'probe','probe_retry','test','curation','backup_baseline','backup_main'",
                                    "'test','storage','inventory','detail','legacy_test','legacy_storage','environment','build','curation','backup_baseline','backup_main'")
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(ROOT/'close_reused.py')})
