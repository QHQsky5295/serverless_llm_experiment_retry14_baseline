"""Reuse bounded metadata inventory for two large experiment-result subtrees."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
template=ROOT/'inventory_storage.py'
source=template.read_text()
start=source.index('roots = [')
end=source.index('\nstart = ',start)
source=source[:start]+'''roots = [
 '/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification',
 '/home/qhq/serverless_llm_baselines/results/paper_experiments/15_new_serverless_baselines_remote_v1',
]'''+source[end:]
source=source.replace('inventory_', 'detail_').replace('--max-depth=2','--max-depth=3')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(ROOT/'detail_reused.py')})
