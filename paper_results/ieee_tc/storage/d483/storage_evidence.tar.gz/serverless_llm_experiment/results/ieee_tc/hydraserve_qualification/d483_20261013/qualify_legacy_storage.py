"""Recheck all archival tests after the narrow adjacent-result extension."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
template=ROOT/'qualify_storage.py'
source=template.read_text().replace("'test_", "'legacy_test_").replace("'test.log'", "'legacy_test.log'")
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(ROOT/'legacy_test_reused.py')})
