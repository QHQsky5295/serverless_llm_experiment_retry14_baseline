"""Reuse D578 exact-path storage checkpoint; never stage unrelated work."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
recipe=RAW.parent/'d578_20261016/publish.py'
assert sha256(recipe.read_bytes()).hexdigest()=='857fb87e7dcb7b615bfeea7b35a835baffe1b533b776dcfb555871d744f26820'
source=recipe.read_text()
for old,new in (('97994d5345bd541ec649f48855a56e8e303a6974','4b5276a219a5e213d86a941dfc7837f9fedf5c09'),
 ('D577_D578','D580_D581'),('D577-D578','D580-D581'),('D576','D579'),('six lossless','two lossless'),
 ('20261016_d578_closed_remote_monitors.json','20261016_d581_closed_hydraserve_monitors.json')):
    assert old in source,old
    source=source.replace(old,new)
exec(compile(source,str(recipe),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py')})
