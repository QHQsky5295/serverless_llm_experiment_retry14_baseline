"""Reuse D578 combined storage curation for fresh D580/D581 receipts."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
recipe=RAW.parent/'d578_20261016/curate.py'
assert sha256(recipe.read_bytes()).hexdigest()=='fd711a0dd48adb81d3959e0b0889c6fe2356ef63f0102d481f23c0804d5fca3e'
prefix=recipe.read_text().split('exec(compile(source,',1)[0]
namespace={'__name__':'curation_recipe','__file__':str(RAW/'curate.py')}
exec(compile(prefix,str(recipe),'exec'),namespace)
source=namespace['source']
for old,new in (('d577','d580'),('d578','d581'),('d576','d579'),
 ('3305705472','3305709568'),("len(compressed['entries'])==6","len(compressed['entries'])==2"),
 ('20261016_d581_closed_remote_monitors.json','20261016_d581_closed_hydraserve_monitors.json')):
    assert old in source,old
    source=source.replace(old,new)
exec(compile(source,str(namespace['original']),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py')})
