"""Reuse lossless closed-log compression for explicit HydraServe W0/W1 monitors."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
HYDRA=RAW.parent.parent/'hydraserve_qualification'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as handle:json.dump(value,handle,indent=2)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'storage_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed=read(RAW.parent/'d580_20261016/cleanup_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
seal=HYDRA.parent/'slora_qualification/d435_20261011/protected_before.json'
assert p.verify_seal(seal)['pass']
campaigns=('d576_20261016','d579_20261016')
bindings=[]
for name in campaigns:
    directory=HYDRA/name
    closed=read(directory/'closure.json')
    assert closed['actual_recursive_empty'] and closed['service_gone']
    assert not Path(closed['service']['path']).exists()
    pub=read(directory/'result_publication_receipt.json')
    assert pub['passed'] and pub['head']==pub['remote']
    pc=read(directory/'result_publication_closure.json')
    assert pc['path_gone'] and pc['actual_recursive_procs_empty']
    assert not Path(pc['identity']['path']).exists()
    stop=read(directory/'remote_stop.json')
    assert stop['all_owned_units_inactive'] and stop['download_hashes_match_remote']
    path=directory/'remote_monitor.log'
    assert path.is_file() and not path.is_symlink()
    assert p.digest(path)==stop['hashes']['remote_monitor.log']
    bindings.append(dict(source=str(path),source_sha256=p.digest(path),
        launch_sha256=p.digest(directory/'launch_gate.json'),
        remote_stop_sha256=p.digest(directory/'remote_stop.json'),
        published_checkpoint=pub['head']))
save(RAW/'bindings.json',bindings)
original=MAIN/'scripts/ieee_tc/compress_closed_main_outcomes.py'
data=original.read_bytes()
assert hashlib.sha256(data).hexdigest()=='3fbe720eaca01f6451a028ece71eba9600df420f1d233fdd669b3e2822e1f33b'
source=data.decode()
# HydraServe's canonical launch receipt is campaign/launch_gate.json; use its
# actual existing standard closure fields, never synthesize a success record.
old="(raw / 'launch.json')"
assert source.count(old)==2
source=source.replace(old,"(raw.parent / 'launch_gate.json')")
namespace={'__name__':'closed_monitor_recipe','__file__':str(original)}
exec(compile(source,str(original),'exec'),namespace)
receipt=MAIN/'paper_results/ieee_tc/storage/20261016_d581_closed_hydraserve_monitors.json'
namespace['RAW_ROOT']=HYDRA
namespace['OUT']=receipt
namespace['TARGETS']=[dict(run=name+'/launch_gate.launch',audit_sha=bindings[i]['source_sha256'],
    remote_monitor_log='remote_monitor.log') for i,name in enumerate(campaigns)]
assert namespace['main']()==0
assert p.verify_seal(seal)['pass']
result=read(receipt)
assert result['source_archive_round_trip_verified'] and len(result['entries'])==2
assert all(row['audit_sha_matches'] for row in result['entries'])
summary=dict(passed=True,files=len(result['entries']),
    reclaimed_bytes=sum(row['allocated_bytes_reclaimed'] for row in result['entries']),
    free_bytes=result['after']['available_bytes'],receipt_sha256=p.digest(receipt),
    protected_unchanged=True,core_recipe_sha256=p.digest(original))
save(RAW/'storage_result.json',summary)
print(json.dumps(summary))
