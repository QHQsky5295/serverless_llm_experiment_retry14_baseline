"""Reuse the verified D604 compressor on only closed, sealed D615 evidence."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d604_20261017/compress.py')
code = source.read_text()
start = code.index('targets = [')
end = code.index('\nchecks = []', start)
code = code[:start] + """targets = [
    dict(run='d615_20261017/7b_three_replica_full_w2'),
    dict(run='d615_20261017/7b_three_replica_full_w2', remote_monitor_log='remote_monitor.log'),
    dict(run='d615_20261017/7b_three_replica_full_w2',
        run_result='experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d615_7b_three_replica_full_w2.json'),
]
assert p.host_sample()['available_bytes'] >= 24*p.GIB
assert RAW.stat().st_dev == ROOT.stat().st_dev
import shutil
assert shutil.disk_usage(ROOT).free >= 102*p.GIB
parent=c.RAW_ROOT/'d615_20261017'
audit=json.loads((parent/'actual_qualification.json').read_text())
curated=json.loads((ROOT/'paper_results/ieee_tc/p2_backend/d615_three_replica_full_w2/result1/summary.json').read_text())
assert audit['passed'] and audit==curated['audit']
refs={row['path']:row['sha256'] for row in audit['refs']}
for target in targets:
    path,_=c.evidence_paths(c.RAW_ROOT/target['run'],target.get('remote_monitor_log'),run_result=target.get('run_result'))
    assert p.digest(path)==refs[str(path)]
    assert not path.is_mount()
""" + code[end:]
exec(compile(code, str(source), 'exec'))
