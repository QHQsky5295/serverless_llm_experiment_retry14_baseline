"""Reuse D604 verified compression on four exact, closed D611/D551 evidence files."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d604_20261017/compress.py')
code = source.read_text()
start = code.index('targets = [')
end = code.index('\nchecks = []', start)
code = code[:start] + """targets = [
    dict(run='d611_20261017/7b_inventory_extent_full_w2'),
    dict(run='d611_20261017/7b_inventory_extent_full_w2', remote_monitor_log='remote_monitor.log'),
    dict(run='d611_20261017/7b_inventory_extent_full_w2',
        run_result='experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d611_7b_inventory_extent_full_w2.json'),
    dict(run='d551_20261015/7b_initial_control_full_w1',
        run_result='experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d551_7b_initial_control_full_w1.json'),
]
assert p.host_sample()['available_bytes'] >= 24*p.GIB
assert (RAW.stat().st_dev == ROOT.stat().st_dev)
import shutil
assert shutil.disk_usage(ROOT).free >= 100*p.GIB + 2*p.GIB
""" + code[end:]
exec(compile(code, str(source), 'exec'))

