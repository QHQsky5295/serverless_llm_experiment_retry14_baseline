"""Reuse D539 exact-path storage checkpoint with archive/secrets/user-dirt guards."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert sha256(original.read_bytes()).hexdigest()=='34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('3e759d75b6e69e182d646d87aca5090f5935024f','97994d5345bd541ec649f48855a56e8e303a6974')
replace("('review','curation')", "('storage','curation')")
replace("'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'",
        "'docs/ieee_tc/D577_D578_STORAGE_MAINTENANCE.md'")
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: preserve verified D576 cache reclaim and six lossless monitors (D577-D578)')
replace("names=['docs/ieee_tc/EXECUTION_STATUS.md'", """names=['paper_results/ieee_tc/storage/20261016_d578_closed_remote_monitors.json','docs/ieee_tc/EXECUTION_STATUS.md'""")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py')})
