"""Reuse D539 bounded combined curation for D577 reclamation and D578 compression."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert sha256(original.read_bytes()).hexdigest()=='5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("RAW.parent.parent/'storage_maintenance/d538_20261015'", "RAW.parent/'d577_20261016'")
replace("RAW.parent.parent/'vllm_qualification/d532_20261015'", "RAW.parent.parent/'hydraserve_qualification/d576_20261016'")
replace("((RAW,'review'),(CLEAN,'cleanup'))", "((RAW,'storage'),(CLEAN,'cleanup'))")
old=source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old,"""clean=read(CLEAN/'cleanup_receipt.json')
assert clean['passed'] and clean['returncode']==0
before=read(D532/'cache_cleanup_before.json');after=read(D532/'cache_cleanup_after.json')
assert before['current_cache_bytes_rehashed'] and before['current_original_bytes_rehashed']
assert before['payload_bytes']==3300789780 and before['files']==1320
assert after['removed'] and after['observed_reclaimed_bytes']==3305705472
assert not after['raw_results_removed'] and not after['unique_artifacts_removed']
receipt=ROOT/'paper_results/ieee_tc/storage/20261016_d578_closed_remote_monitors.json'
compressed=read(receipt);summary=read(RAW/'storage_result.json')
assert compressed['source_archive_round_trip_verified'] and summary['passed']
assert len(compressed['entries'])==6
bindings={r['source']:r for r in read(RAW/'bindings.json')}
for row in compressed['entries']:
    assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']==bindings[row['source']]['source_sha256']
    assert not Path(row['source']).exists() and p.digest(Path(row['archive']))==row['archive_sha256']
""")
old=source[source.index('specs=['):source.index('reports=[]')]
replace(old,"""specs=[('storage/d577_targeted_cache_reclaim',
 [CLEAN/n for n in ('run_cleanup.py','reclaim_d576.py','close.py','cleanup_identity.json',
 'cleanup_receipt.json','cleanup_closure.json','retained_metadata.tar.gz')]+
 [D532/n for n in ('cache_cleanup_before.json','cache_cleanup_after.json')],
 {'cleanup_receipt.json':CLEAN/'cleanup_receipt.json','cleanup_closure.json':CLEAN/'cleanup_closure.json',
 'cache_cleanup_after.json':D532/'cache_cleanup_after.json'}),
 ('storage/d578_closed_monitor_compression',
 [RAW/n for n in ('compress_closed_monitors.py','close.py','bindings.json','storage_identity.json',
 'storage_result.json','storage_closure.json','curate.py')]+
 [receipt,ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py',
 RAW.parent.parent/'hydraserve_qualification/d478_20261012/compress_closed_monitors.py'],
 {'compression_receipt.json':receipt,'storage_result.json':RAW/'storage_result.json',
 'storage_closure.json':RAW/'storage_closure.json'})]
""")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py')})
