"""Reuse the narrow lossless archiver on explicit, released historical logs."""
import json
import os
import subprocess
import sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
with (RAW/'storage_identity.json').open('x') as stream:
    json.dump(p.scope_identity(p.cg_path().name),stream,indent=2)
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
seal=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')
assert p.verify_seal(seal)['pass']
targets=[
 ('d158_20261002/7b_full_w0_full1','full1'),
 ('d131_20261001/7b_full_w0_full1','full1'),
 ('d129_20260930/7b_full_w0_full1','full1'),
 ('d110_20260928/3b_full_w0_profile4','profile4'),
 ('d125_20260930/7b_full_w0_full1','full1'),
 ('d119_20260930/7b_full_w0_full1','full1'),
 ('d145_20261001/7b_full_w0_full1','full1'),
 ('d100_20260928/3b_full_w0_attempt7','full_attempt7'),
 ('d148_20261001/7b_full_w0_full1','full1'),
 ('d137_20261001/7b_full_w0_full1','full1'),
 ('d96_20260928/3b_full_w0_attempt3','full_attempt3'),
 ('d97_20260928/3b_full_w0_attempt4','full_attempt4'),
 ('d135_20261001/7b_full_w0_full1','full1'),
 ('d101_20260928/3b_full_w0_attempt8','full_attempt8'),
 ('d112_20260928/3b_full_w0_full9','full9'),
 ('d150_20261001/7b_full_w0_full1','full1'),
]
command=[sys.executable,str(MAIN/'scripts/ieee_tc/compress_closed_main_outcomes.py')]
for run, tag in targets:
    command.extend(['--closed-run',run,'--remote-monitor-log',f'remote_monitor_{tag}_final.log'])
receipt=MAIN/'paper_results/ieee_tc/storage/20261012_d478_closed_remote_monitors.json'
command.extend(['--receipt',str(receipt)])
with (RAW/'storage.log').open('x') as stream:
    subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=True)
assert p.verify_seal(seal)['pass']
result=json.loads(receipt.read_text())
assert result['source_archive_round_trip_verified']
summary=dict(passed=True,files=len(result['entries']),reclaimed_bytes=sum(row['allocated_bytes_reclaimed'] for row in result['entries']),
             free_bytes=result['after']['available_bytes'],receipt_sha256=p.digest(receipt),protected_unchanged=True)
with (RAW/'storage_result.json').open('x') as stream:json.dump(summary,stream,indent=2)
print(json.dumps(summary),flush=True)
