"""Reuse D478 exact closed-run compression; six additional unchanged remote logs."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'hydraserve_qualification/d478_20261012/compress_closed_monitors.py'
source=original.read_text()
targets=[
 ('d512_20261014/7b_full_w0_prefix1','remote_monitor.log'),
 ('d516_20261014/7b_full_w0','remote_monitor.log'),
 ('d529_20261014/7b_full_w0','remote_monitor.log'),
 ('d533_20261015/7b_full_w1','remote_monitor.log'),
 ('d551_20261015/7b_initial_control_full_w1','remote_monitor.log'),
 ('d554_20261015/7b_initial_control_full_w2','remote_monitor.log'),
]
start=source.index('targets=[')
end=source.index('\ncommand=',start)
source=source[:start]+'targets='+repr(targets)+source[end:]
source=source.replace("f'remote_monitor_{tag}_final.log'",'tag')
source=source.replace('20261012_d478_closed_remote_monitors.json',
                      '20261016_d578_closed_remote_monitors.json')
anchor="command=[sys.executable,str(MAIN/'scripts/ieee_tc/compress_closed_main_outcomes.py')]"
assert source.count(anchor)==1
source=source.replace(anchor,"""group=p.cg_path()
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
prior=RAW.parent/'d577_20261016/cleanup_closure.json'
closed=json.loads(prior.read_text())
assert closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
bindings=[]
for run,tag in targets:
    campaign=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification')/Path(run).parent
    stop=json.loads((campaign/'remote_stop.json').read_text())
    assert stop['all_owned_units_inactive'] and stop['download_hashes_match_remote']
    path=campaign/tag
    assert path.is_file() and not path.is_symlink()
    bindings.append(dict(run=run,source=str(path),source_sha256=p.digest(path),
        remote_stop_sha256=p.digest(campaign/'remote_stop.json'),
        launch_sha256=p.digest(campaign/Path(run).name/'launch.json')))
with (RAW/'bindings.json').open('x') as handle:json.dump(bindings,handle,indent=2)
"""+anchor)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'compress_closed_monitors.py')})
