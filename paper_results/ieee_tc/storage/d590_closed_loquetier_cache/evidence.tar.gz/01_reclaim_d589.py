"""Reclaim only closed D589 downloads, reusing the existing cleanup primitives."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/loquetier_qualification/d589_20261016')
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
TARGET = Path('/tmp/tc-d589-7bl/remote_artifacts/objects')
ORIGINAL = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
sys.path.insert(0, str(MAIN/'scripts/ieee_tc'))
from cleanup_d370_aborted_cache import digest, active_reference, write_json

assert ROOT.name == 'd589_20261016'
assert not (ROOT/'cache_cleanup_before.json').exists()
assert TARGET.is_dir() and not TARGET.is_symlink() and TARGET.resolve() == TARGET
launch = json.loads((ROOT/'launch7b.json').read_text())
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed'] and launch['service_returncode'] == 0
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
audit_path = MAIN/'paper_results/ieee_tc/loquetier/d589_capacity_full_w2/result1/audit.json'
assert digest(audit_path) == '69ca2da9ba4340caa09cb79a127722b5d702cbab55fe7c8246ec061d613330db'
audit = json.loads(audit_path.read_text())
assert audit['workload_passed'] and audit['offered_unique_adapters'] == 497 and audit['deployment_prepared_adapters'] == 500 and audit['verified_materialized_bytes'] == 12985984450
index_path = MAIN/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
assert digest(index_path) == 'e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c'
index = json.loads(index_path.read_text())
expected, total = set(), 0
selected = {p.stem for p in (ROOT/'remote_resolver_evidence/receipts').glob('*.json')}
assert len(selected) == audit['deployment_prepared_adapters']
assert selected <= {r['id'] for r in index['artifacts']}
assert selected == {p.name for p in TARGET.iterdir() if p.is_dir()}
for row in index['artifacts']:
    if row['id'] not in selected:
        continue
    for item in row['files']:
        p, source = TARGET/row['id']/item['path'], ORIGINAL/row['id']/item['path']
        assert p.is_file() and not p.is_symlink() and source.is_file()
        assert p.stat().st_size == source.stat().st_size == item['size_bytes']
        assert (p.stat().st_dev,p.stat().st_ino) != (source.stat().st_dev,source.stat().st_ino)
        # Rehash both current cache and retained original; no stale hash assumption.
        assert digest(p) == digest(source) == item['sha256']
        expected.add(p)
        total += item['size_bytes']
assert total == audit['verified_materialized_bytes']
assert not any(p.is_symlink() for p in TARGET.rglob('*'))
assert {p for p in TARGET.rglob('*') if p.is_file()} == expected
for line in Path('/proc/self/mountinfo').read_text().splitlines():
    mount = line.split()[4]
    assert mount != str(TARGET) and not mount.startswith(str(TARGET)+'/')
assert not active_reference(TARGET)
private = str(TARGET.parent.parent)
assert not active_reference(TARGET.parent.parent)
unreadable, hits = [], []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    try:
        if proc.stat().st_uid != os.getuid():
            continue
        links = [proc/'cwd',proc/'root',*list((proc/'fd').iterdir())]
        for link in links:
            try:
                value = os.readlink(link)
                if value == private or value.startswith(private+'/'):
                    hits.append(dict(pid=proc.name,link=link.name))
            except (FileNotFoundError,ProcessLookupError):
                pass
    except (FileNotFoundError,ProcessLookupError):
        pass
    except PermissionError:
        unreadable.append(proc.name)
assert not hits, hits
future = []
for repo in (MAIN,BASE):
    result = subprocess.run(['git','grep','-l','-F',private,'--','configs','scripts'],cwd=repo,capture_output=True,text=True)
    assert result.returncode in (0,1), result.stderr
    future.extend(result.stdout.splitlines())
assert not future, future
metadata = TARGET.parent
saved = ROOT/'remote_resolver_evidence'
for name in ('receipts','journals'):
    originals = {p.relative_to(metadata) for p in (metadata/name).rglob('*') if p.is_file()}
    copies = {p.relative_to(saved) for p in (saved/name).rglob('*') if p.is_file()}
    assert originals == copies
    assert all(digest(metadata/p) == digest(saved/p) for p in originals)
assert digest(metadata/'run_contract.json') == digest(saved/'run_contract.json')
before = shutil.disk_usage('/home/qhq').free
record = dict(schema='ieee_tc_closed_download_cache_reclamation_v1',campaign=ROOT.name,
    target=str(TARGET),status='verified_before_removal',files=len(expected),payload_bytes=total,
    disk_before_bytes=before,audit=dict(path=str(audit_path),sha256=digest(audit_path)),
    source_index=dict(path=str(index_path),sha256=digest(index_path)),retained_original_pool=str(ORIGINAL),
    retained_evidence=str(ROOT),all_cache_bytes_previously_hashed_by_audit=True,
    current_original_bytes_rehashed=True,current_cache_bytes_rehashed=True,current_file_sizes_and_original_inodes_verified=True,
    owned_runtime_references=hits,future_config_script_references=future,cache_symlinks_or_nested_mounts=False,
    metadata_copies_hash_match=True,unreadable_same_uid_proc_entries=sorted(set(unreadable)),
    open_fd_check_scope='readable same-UID FD/cwd/root plus fuser, not claimed complete system-wide',
    raw_results_removed=False,unique_artifacts_removed=False,recipe_sha256=digest(Path(__file__)),
    recorded_unix=time.time())
write_json(ROOT/'cache_cleanup_before.json',record)
shutil.rmtree(TARGET)
assert not TARGET.exists()
after = shutil.disk_usage('/home/qhq').free
write_json(ROOT/'cache_cleanup_after.json',dict(schema=record['schema'],campaign=ROOT.name,
    target=str(TARGET),removed=True,disk_before_bytes=before,disk_after_bytes=after,
    observed_reclaimed_bytes=after-before,before_receipt_sha256=digest(ROOT/'cache_cleanup_before.json'),
    raw_results_removed=False,unique_artifacts_removed=False,recorded_unix=time.time()))
print(json.dumps(dict(removed=str(TARGET),files=len(expected),payload_bytes=total,
    observed_reclaimed_bytes=after-before,disk_after_bytes=after,unreadable_same_uid_proc_entries=sorted(set(unreadable)))))
