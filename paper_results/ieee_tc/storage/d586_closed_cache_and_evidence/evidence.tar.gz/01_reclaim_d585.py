"""Reuse the full-content audit for D585's closed, reconstructible downloads."""
from hashlib import sha256
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent / 'd571_20261016/reclaim_d569.py'
source = original.read_text()
source = source.replace('d569', 'd585')
changes = {
    'loquetier/d585_capacity_prefix1000/': 'loquetier/d585_capacity_full_w0/',
    '31737ac6b8e4721aa52885d6beca45a1f7c27f9fdf58435df83beacab9b88cfe':
        '84ffa84a02450883c4e2c74721e7b96573e8ea5e17352b23b5c8b69dcc33c955',
    "audit['offered_unique_adapters'] == 60": "audit['offered_unique_adapters'] == 132",
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'reclaim_d585.py')})
