"""Bound D585-only maintenance with existing closure and publication guards."""
from hashlib import sha256
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent / 'd538_20261015/run_cleanup.py'
data = original.read_bytes()
assert sha256(data).hexdigest() == '6749cdfcd7d4b42fedb43781c9e6a9257f7a431764a226c2c748176790112c21'
source = data.decode()
changes = {
    'vllm_qualification/d532_20261015': 'loquetier_qualification/d585_20261016',
    "('analysis','result','publication','review','review_backup')":
        "('qualification','backup','start','analysis','analysis2','cross','result','result_publication')",
    '3e759d75b6e69e182d646d87aca5090f5935024f': '545cd2a06b41bb00470c2b9e7c2cf723c3759326',
    'bde215460acb9e850efa479a89bda6fc39a2bd7d': '80e08b4c6e7c2874b1b237500a00811ec06cd8c5',
    "recipe=OLD/'reclaim_objects.py'": "recipe=RAW/'reclaim_d585.py'",
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'run_cleanup.py')})
