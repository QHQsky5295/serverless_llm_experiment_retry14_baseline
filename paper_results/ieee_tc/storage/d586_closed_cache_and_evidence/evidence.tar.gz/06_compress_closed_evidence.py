"""Bounded reuse of the existing two-roundtrip lossless compression recipe."""
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
RESULTS = RAW.parent.parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW / 'storage_identity.json', identity)
group = Path(identity['path'])
assert (group / 'memory.high').read_text().strip() == str(3 * p.GIB)
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
assert (group / 'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
closed = read(RAW / 'cleanup_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
seal = RESULTS / 'slora_qualification/d435_20261011/protected_before.json'
assert p.verify_seal(seal)['pass']

directory = RESULTS / 'p2_backend_qualification/d554_20261015'
run = directory / '7b_initial_control_full_w2'
launch = read(run / 'launch.json')
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
local = read(directory / 'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty']
for key in ('service_identity', 'auxiliary_identity'):
    assert not Path(local[key]['path']).exists()
publication = read(directory / 'publication_receipt.json')
assert publication['passed'] and publication['remote_equal']
subprocess.run(['git', 'merge-base', '--is-ancestor', publication['head'], 'HEAD'], cwd=MAIN, check=True)
close = read(directory / 'publication_closure.json')
assert close['passed'] and close['actual_recursive_procs_empty'] and close['path_gone']
assert not Path(close['identity']['path']).exists()
source = run / 'launch.launch/physical_deployment/main_outcome.json'
expected = 'a1178f573177405a514e0a03e1c063a9042e480bec7eaa0fd7aa577e4998106b'
assert p.digest(source) == expected
bindings = [dict(source=str(source), source_sha256=expected,
                 published_checkpoint=publication['head'], launch_sha256=p.digest(run / 'launch.json'))]
save(RAW / 'bindings.json', bindings)

original = MAIN / 'scripts/ieee_tc/compress_closed_main_outcomes.py'
data = original.read_bytes()
assert p.digest(original) == '3fbe720eaca01f6451a028ece71eba9600df420f1d233fdd669b3e2822e1f33b'
namespace = {'__name__': 'compression_recipe', '__file__': str(original)}
exec(compile(data, str(original), 'exec'), namespace)
receipt = MAIN / 'paper_results/ieee_tc/storage/20261016_d586_closed_d554_outcome.json'
namespace['OUT'] = receipt
namespace['TARGETS'] = [dict(run='d554_20261015/7b_initial_control_full_w2', audit_sha=expected)]
assert namespace['main']() == 0
assert p.verify_seal(seal)['pass']
entries = read(receipt)['entries']
assert len(entries) == 1 and all(row['audit_sha_matches'] for row in entries)
summary = dict(passed=True, files=1,
               reclaimed_bytes=sum(row['allocated_bytes_reclaimed'] for row in entries),
               free_bytes=read(receipt)['after']['available_bytes'],
               receipts={str(receipt): p.digest(receipt)}, protected_unchanged=True,
               core_recipe_sha256=p.digest(original))
save(RAW / 'storage_result.json', summary)
print(json.dumps(summary))
