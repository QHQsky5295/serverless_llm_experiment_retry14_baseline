"""Reuse exact-path publication; no user edits, large logs or secrets staged."""
from hashlib import sha256
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent.parent / 'serverless_qualification/d539_20261015/publish.py'
assert sha256(original.read_bytes()).hexdigest() == '34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source = original.read_text()
changes = {
    '3e759d75b6e69e182d646d87aca5090f5935024f': '545cd2a06b41bb00470c2b9e7c2cf723c3759326',
    "('review','curation')": "('cleanup','storage','curation')",
    "'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'":
        "'docs/ieee_tc/D586_STORAGE_MAINTENANCE.md','paper_results/ieee_tc/storage/20261016_d586_closed_d554_outcome.json'",
    'tc: preserve startup queue review and safe cache reclaim (D538-D539)':
        'tc: preserve closed Loquetier cache reclaim and lossless W2 evidence (D586)',
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'publish.py')})
