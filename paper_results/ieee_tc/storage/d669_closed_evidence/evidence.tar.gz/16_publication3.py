"""Resume D668's already verified checkpoint, recognizing standard CSV CRLF."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d668_3b_host_inventory_prefix1/completion'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication3_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed=read(RAW/'publication2_closure.json')
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
record=read(OUT/'publication.json');test_counts=record['test_counts']
assert record['passed'] and test_counts['distinct_final_pass']==183
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==record['parent_commit']
for path,sha in record['preserved'].items():assert p.digest(Path(path))==sha
assert p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')['pass']
for path,sha in read(OUT/'analysis_manifest.json')['source_refs'].items():assert p.digest(Path(path))==sha
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def secret_check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
source=RAW/'publication2.py';data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='2a0f7e42a639ad26b9d395b9521be3796ecdecfb4e8f89e3bd0a29dd57ab43fc'
tree=ast.parse(data);assert isinstance(tree.body[-1],ast.If)
namespace={'__file__':str(source),'__name__':'__main__'}
exec(compile(ast.Module(body=tree.body[:-1],type_ignores=[]),str(source),'exec'),namespace)
code=namespace['code'];tail=code[code.index("names=['scripts/analyze_control_path_overhead.py'"):]
published=sorted(v for v in OUT.rglob('*') if v.is_file() and v.name!='result.sha256')
old="assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()"
assert tail.count(old)==1
tail=tail.replace(old,"assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)")
# Keep blank-at-eol/EOF and indent checks; only recognize CSV's CRLF terminator.
tail=tail.replace("['git','diff'","['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff'")
tail=tail.replace("RAW/'publication2_receipt.json'","RAW/'publication3_receipt.json'")
exec(compile(tail,str(source),'exec'))
