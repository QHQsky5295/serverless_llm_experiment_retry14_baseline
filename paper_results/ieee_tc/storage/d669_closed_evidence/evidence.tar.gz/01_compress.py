"""Reuse bounded D604 maintenance for exactly two closed 3B outcome logs."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d604_20261017/compress.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='e8693b459971c1dd496537f3d0ae1d2e8f300972454678757239c02869e26d2d'
code=data.decode()
start=code.index('targets = [')
end=code.index('checks = []',start)
code=code[:start]+'''targets=[dict(run='d660_20261018/3b_full_w0'),dict(run='d665_20261018/3b_full_w0')]
import shutil
assert p.host_sample()['available_bytes']>=24*p.GIB
assert RAW.stat().st_dev==ROOT.stat().st_dev
assert shutil.disk_usage(ROOT).free>=100*p.GIB+1.5*max(c.evidence_paths(c.RAW_ROOT/t['run'])[0].stat().st_size for t in targets)
expected={
 'd660_20261018/3b_full_w0':'b3687a3afe1ef3b006a28e11cc02236e04d2ea266475116e4b8d3175343ae3cf',
 'd665_20261018/3b_full_w0':'ff5b3e489ae6a457541ed2c6cf7215077bd8723c6f2998000b1b308b02367e81',
}
''' + code[end:]
old='    sha = p.digest(source)'
assert code.count(old)==1
code=code.replace(old,"    assert not source.is_mount()\n"+old+"\n    assert sha==expected[target['run']]")
ast.parse(code)
exec(compile(code,str(source),'exec'))
