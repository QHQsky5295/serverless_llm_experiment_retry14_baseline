"""Reuse bounded D620 checked publication for two closed 3B logs."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d620_20261017/publish.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='87ec83dea05b79b0ed41ba80fae9c6dbb15a806d13ed274e32280f12b912243e'
code=data.decode()
changes={
 'd620_closed_evidence':'d669_closed_evidence',
 '87f8612647ed0c0c4a093b9dd78924c0a50b4f60':'b91906fb285db98ca97a4c05664d14d95327af4c',
 "len(result['entries'])==3":"len(result['entries'])==2",
 'fd783131934664f1dee49f78b21366c2aff7264d60a15c2a9bcb975e207bec4f':'0bfc67d521627b803acd95f876bf2387cf0033c7caee0f4684e87f23035bded9',
 'D620_CLOSED_EVIDENCE_STORAGE.md':'D669_CLOSED_EVIDENCE_STORAGE.md',
 'p2_backend_qualification/d619_20261017':'p2_backend_qualification/d668_20261018',
 "files += [doc,parent/'publication_closure.json',parent/'actual_qualification.json',RAW.parent/'d604_20261017/compress.py',RAW.parent/'d613_20261017/compress.py',RAW.parent/'d592_20261017/close.py']":
 "files += [doc,RAW/'tests.log',RAW.parent/'d604_20261017/compress.py',RAW.parent/'d592_20261017/close.py',*sorted(parent.glob('publication*.py')),*sorted(parent.glob('publication*.json')),parent/'close_publication3.py']",
 'd620_verified_closed_log_storage_v1':'d669_verified_closed_log_storage_v1',
 'tc: preserve lossless D619 evidence compression before same-source W2/W0 (D620)':
 'tc: archive closed 3B evidence losslessly before the next HOST optimization (D669)',
}
for old,new in changes.items():
    assert code.count(old)==1,old
    code=code.replace(old,new)
ast.parse(code)
exec(compile(code,str(source),'exec'))
