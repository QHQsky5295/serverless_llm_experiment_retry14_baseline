"""Reuse exact-identity closure for the resumed checkpoint."""
from pathlib import Path
import sys
source=Path(__file__).resolve().parent/'close.py'
code=source.read_text()
old="'publication','publication2')"
assert code.count(old)==1
code=code.replace(old,"'publication','publication2','publication3')")
sys.argv=[str(source),'publication3']
exec(compile(code,str(source),'exec'))
