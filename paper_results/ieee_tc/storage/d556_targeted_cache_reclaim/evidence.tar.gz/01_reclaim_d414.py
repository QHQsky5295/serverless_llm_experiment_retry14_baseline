"""Reuse full-content reclamation for one independently sealed old private cache."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='e66e17f0a2ca0f72c0c0ae9f6bb6c6da8351b924f4d72ce4f7e93c64476892bb'
source=data.decode()
changes={
    'ROOT = Path(__file__).resolve().parent':"ROOT = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/serverless_qualification/d414_20261011')",
    '/tmp/tc-d532-7bv/':'/tmp/tc-d414-7br/',
    "ROOT.name == 'd532_20261015'":"ROOT.name == 'd414_20261011'",
    "ROOT/'launch7b.json'":"ROOT/'launch7b_repaired.json'",
    'main_comparison/d532_vllm_w1/result1':'baseline_audit/d414_7b_full_w0',
    'f3b2344147c51db9407b9711ec6dbc59af8c6c5007dd7c9d90fdd68efcf6ddb7':'714a2fdb01b2d5a0e2e6f3a9b0faf7cb23b29632efbf5b343822b7dfe4b7dd74',
    "audit['offered_unique_adapters'] == 132":"audit['offered_unique_adapters'] == 132",
    "audit['verified_materialized_bytes'] == 3300789780":"audit['verified_materialized_bytes'] == 3300789780",
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
# Verify actual original service/replay resource paths are absent today, not
# merely their historical booleans. Full file/reference gates remain unchanged.
needle="assert not subprocess.check_output(['nvidia-smi'"
assert source.count(needle)==1
source=source.replace(needle, """assert not Path(launch['gate_request']['scope']['path']).exists()
assert not Path(launch['replay_process']['cgroup']).exists()
""" + needle)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'reclaim_d414.py')})
