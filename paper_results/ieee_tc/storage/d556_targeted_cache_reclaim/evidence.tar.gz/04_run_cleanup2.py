"""Bound existing closed-download reclamation; retain results and unique assets."""
import json, os, subprocess, sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OLD=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/serverless_qualification/d414_20261011')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,row):
    with path.open('x') as f:json.dump(row,f,indent=2)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'cleanup2_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
closed=read(RAW/'cleanup_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
for repo,remote,branch,expected in ((MAIN,'faaslora_origin','retry14_continuous_queue_v2','cd534fd91b8b7e5ebdff4c28cf7a5e8ca2118ae4'),(BASE,'origin','main','aff60bb210c6d1fb9ce94534c5ef37521976bc0a')):
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==expected
    assert subprocess.check_output(['git','ls-remote',remote,'refs/heads/'+branch],cwd=repo,text=True).split()[0]==expected
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
before=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert before['pass'] and before['entry_count']==147
recipes=[RAW/'reclaim_d414.py',RAW/'reclaim_d419.py']
with (RAW/'cleanup2.log').open('x') as log:
    for recipe in recipes:
        result=subprocess.run([sys.executable,str(recipe)],cwd=MAIN,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:
            break
after=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
save(RAW/'cleanup2_receipt.json',dict(passed=result.returncode==0 and after['pass'],returncode=result.returncode,identity=identity,
    recipes=[dict(path=str(recipe),sha256=p.digest(recipe)) for recipe in recipes],before_protected=before,after_protected=after,
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}))
result.check_returncode()
assert after['pass']
print(json.dumps(read(OLD/'cache_cleanup_after.json')))
