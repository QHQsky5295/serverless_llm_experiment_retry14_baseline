"""Bound D555 cache reclamation with the existing D538 protection/closure gates."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d538_20261015/run_cleanup.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='6749cdfcd7d4b42fedb43781c9e6a9257f7a431764a226c2c748176790112c21'
source=data.decode()
changes={
    'vllm_qualification/d532_20261015':'serverless_qualification/d555_20261015',
    "('analysis','result','publication','review','review_backup')":"('analysis','result','result_publication','cross')",
    '3e759d75b6e69e182d646d87aca5090f5935024f':'cd534fd91b8b7e5ebdff4c28cf7a5e8ca2118ae4',
    'bde215460acb9e850efa479a89bda6fc39a2bd7d':'aff60bb210c6d1fb9ce94534c5ef37521976bc0a',
    "recipe=OLD/'reclaim_objects.py'":"recipe=RAW/'reclaim_d555.py'",
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'run_cleanup.py')})
