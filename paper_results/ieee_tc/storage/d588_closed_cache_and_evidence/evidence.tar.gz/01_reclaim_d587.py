"""Reuse the full-content audit for D587's closed, reconstructible downloads."""
from hashlib import sha256
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent / 'd571_20261016/reclaim_d569.py'
source = original.read_text()
source = source.replace('d569', 'd587')
changes = {
    'loquetier/d587_capacity_prefix1000/': 'loquetier/d587_capacity_full_w1/',
    '31737ac6b8e4721aa52885d6beca45a1f7c27f9fdf58435df83beacab9b88cfe':
        '3645c39143339125af504da01d51be8d4adfc3e539cd7b4075c4754a1a1655b1',
    "audit['offered_unique_adapters'] == 60": "audit['offered_unique_adapters'] == 132",
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'reclaim_d587.py')})
