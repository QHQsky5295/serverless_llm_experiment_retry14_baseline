"""Reuse identity-checked, recursively empty maintenance scope closure."""
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent / 'd575_20261016/close.py'
source = original.read_text().replace("('cleanup', 'curation', 'publication')",
                                     "('cleanup', 'storage', 'curation', 'publication')")
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'close.py')})
