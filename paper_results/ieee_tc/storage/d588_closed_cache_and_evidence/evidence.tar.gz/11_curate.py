"""Reuse guarded curation for the single D588 maintenance checkpoint."""
from hashlib import sha256
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent.parent / 'serverless_qualification/d539_20261015/curate.py'
assert sha256(original.read_bytes()).hexdigest() == '5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source = original.read_text()

def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace("RAW.parent.parent/'storage_maintenance/d538_20261015'", 'RAW')
replace("RAW.parent.parent/'vllm_qualification/d532_20261015'",
        "RAW.parent.parent/'loquetier_qualification/d587_20261016'")
replace("((RAW,'review'),(CLEAN,'cleanup'))", "((RAW,'storage'),(CLEAN,'cleanup'))")
replace(source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')], """clean=read(CLEAN/'cleanup_receipt.json')
assert clean['passed'] and clean['returncode']==0
before=read(D532/'cache_cleanup_before.json');after=read(D532/'cache_cleanup_after.json')
assert before['current_cache_bytes_rehashed'] and before['current_original_bytes_rehashed']
assert before['payload_bytes']==12985984450 and before['files']==5000
assert after['removed'] and after['observed_reclaimed_bytes']==13004480512
assert not after['raw_results_removed'] and not after['unique_artifacts_removed']
summary=read(RAW/'storage_result.json')
assert summary['passed'] and summary['files']==1
receipts=[Path(path) for path in summary['receipts']]
bindings={row['source']:row for row in read(RAW/'bindings.json')}
for receipt in receipts:
    assert p.digest(receipt)==summary['receipts'][str(receipt)]
    compressed=read(receipt)
    assert compressed['source_archive_round_trip_verified']
    for row in compressed['entries']:
        assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']==bindings[row['source']]['source_sha256']
        assert not Path(row['source']).exists() and p.digest(Path(row['archive']))==row['archive_sha256']
""")
replace(source[source.index('specs=['):source.index('reports=[]')], """specs=[('storage/d588_closed_cache_and_evidence',
 [RAW/name for name in ('run_cleanup.py','reclaim_d587.py','close.py','cleanup_identity.json',
 'cleanup_receipt.json','cleanup_closure.json','compress_closed_evidence.py','bindings.json',
 'storage_identity.json','storage_result.json','storage_closure.json','curate.py')]+
 [D532/name for name in ('cache_cleanup_before.json','cache_cleanup_after.json')]+receipts+
 [RAW.parent/'d538_20261015/run_cleanup.py',RAW.parent/'d571_20261016/reclaim_d569.py',
 RAW.parent/'d575_20261016/close.py',RAW.parent.parent/'hydraserve_qualification/d570_20261016/close.py',
 RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py',
 RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py',
 RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py',
 ROOT/'scripts/ieee_tc/cleanup_d370_aborted_cache.py',
 ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py'],
 {'cleanup_receipt.json':RAW/'cleanup_receipt.json','cleanup_closure.json':RAW/'cleanup_closure.json',
 'cache_cleanup_before.json':D532/'cache_cleanup_before.json',
 'cache_cleanup_after.json':D532/'cache_cleanup_after.json',
 'compression_receipt.json':receipts[0],'storage_result.json':RAW/'storage_result.json',
 'storage_closure.json':RAW/'storage_closure.json'})]
""")
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'curate.py')})
