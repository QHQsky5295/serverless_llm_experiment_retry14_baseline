"""Reuse exact-owned recursive-empty scope closure for D604."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d592_20261017/close.py')
exec(compile(source.read_text(), str(source), 'exec'))
