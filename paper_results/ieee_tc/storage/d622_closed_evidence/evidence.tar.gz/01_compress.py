"""D622: reuse D604's bounded driver and the shared lossless compressor.

Only the explicit four closed files below are eligible. D145's historical
completion/closure schema differs; its four failed requests remain failures.
No retrospective publication closure is invented for that old run.
"""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d604_20261017/compress.py')
code = source.read_text()
start = code.index('targets = [')
end = code.index("save(RAW/'prechecks.json'", start)
code = code[:start] + '''targets = [
    dict(run='d621_20261017/7b_device_domain_full_w2'),
    dict(run='d621_20261017/7b_device_domain_full_w2', remote_monitor_log='remote_monitor.log'),
    dict(run='d621_20261017/7b_device_domain_full_w2',
         run_result='experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d621_7b_device_domain_full_w2.json'),
    dict(run='d145_20261001/7b_full_w0_full1',
         legacy_result='7b_outputs_full1/experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d145_7b_full_w0_full1.json'),
]
import shutil
assert p.host_sample()['available_bytes'] >= 24*p.GIB
assert RAW.stat().st_dev == ROOT.stat().st_dev
paths = [c.evidence_paths(c.RAW_ROOT/t['run'], t.get('remote_monitor_log'),
         t.get('legacy_result'), t.get('run_result'))[0] for t in targets]
# Maintenance below the new-experiment floor is allowed, but even a worst-case
# archive must leave the 100 GiB stop reserve intact. One target at a time.
assert shutil.disk_usage(ROOT).free >= 100*p.GIB + 1.5*max(x.stat().st_size for x in paths)
modern = c.RAW_ROOT/'d621_20261017'
audit = json.loads((modern/'actual_qualification.json').read_text())
curated = json.loads((ROOT/'paper_results/ieee_tc/p2_backend/d621_device_domain_full_w2/result1/summary.json').read_text())
assert audit['passed'] and audit == curated['audit']
refs = {row['path']:row['sha256'] for row in audit['refs']}
legacy_path = ROOT/'paper_results/ieee_tc/p2_backend/20261001_d145_7b_full_w0_full1.json'
assert p.digest(legacy_path) == '8a75bdc7f4600094f31ce92201acb6a13d9b8c3760d60665af2eb1414be7733f'
legacy = json.loads(legacy_path.read_text())
assert legacy['execution_completed'] is True and legacy['full_qualified'] is False
assert legacy['population']['success'] == 3996
assert legacy['population']['failure_observations'] == {'RuntimeError':4}
assert legacy['cleanup']['complete'] is True
oldrefs = {str(Path(row['path']).resolve()):row['sha256'] for row in legacy['source_refs']}
checks = []
for target in targets:
    run = c.RAW_ROOT/target['run']
    launch = json.loads((run/'launch.json').read_text())
    c.require_closed_launch(launch)
    assert not Path(launch['service_identity']['path']).exists()
    assert not Path(launch['auxiliary']['path']).exists()
    source, receipt = c.evidence_paths(run, target.get('remote_monitor_log'),
        target.get('legacy_result'), target.get('run_result'))
    assert source.resolve() == source.absolute() and not source.is_mount()
    assert not receipt.exists() and not source.with_suffix(source.suffix+'.gz').exists()
    c.no_active(source)
    if target.get('legacy_result'):
        assert p.digest(run/'launch.json') == oldrefs[str(run/'launch.json')]
        stop_path = run.parent/'stop_services_full1.log'
        assert p.digest(stop_path) == oldrefs[str(stop_path)]
        stop_text = stop_path.read_text()
        assert stop_text.count('MainPID=0') == 3 and stop_text.count('ActiveState=inactive') == 3
        expected = oldrefs[str(source)]
        assert expected == '86a73878f24ada577643067bd6d3e1a89b47ae9a1f8b164a10ce5c4f79f9705c'
        extra = dict(legacy_schema=True, prior_result_sha256=p.digest(legacy_path),
            historical_remote_stop_sha256=p.digest(stop_path),
            historical_publication_closure_receipt_available=False,
            present_day_no_active_source_check=True,
            original_population=legacy['population'], original_full_qualified=False)
    else:
        closed = json.loads((run.parent/'publication_closure.json').read_text())
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists()
        completion = json.loads((run.parent/'completion_receipt.json').read_text())
        stop = json.loads((run.parent/'remote_stop.json').read_text())
        assert stop['all_owned_units_inactive'] and stop['download_hashes_match_remote']
        expected = refs[str(source)]
        if target.get('run_result'):
            assert expected == completion['source_sha256']
        if target.get('remote_monitor_log'):
            assert expected == stop['hashes']['remote_monitor.log']
        extra = dict(legacy_schema=False,
            completion_sha256=p.digest(run.parent/'completion_receipt.json'),
            publication_closure_sha256=p.digest(run.parent/'publication_closure.json'))
    print('Verifying closed source: '+str(source), flush=True)
    assert p.digest(source) == expected
    target['audit_sha'] = expected
    checks.append(dict(**target, **extra, source=str(source), source_bytes=source.stat().st_size,
        launch_sha256=p.digest(run/'launch.json'),
        actual_service_and_auxiliary_paths_gone=True, no_active_source=True))
''' + code[end:]
exec(compile(code, str(source), 'exec'))
