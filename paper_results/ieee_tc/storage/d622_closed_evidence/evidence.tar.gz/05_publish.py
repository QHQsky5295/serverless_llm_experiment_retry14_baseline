"""Reuse D620's checked explicit-path publication with D622-only identities."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d620_20261017/publish.py')
code=source.read_text()
changes={
    'd620_closed_evidence':'d622_closed_evidence',
    '87f8612647ed0c0c4a093b9dd78924c0a50b4f60':'3c65d6706ce521243e1b0311e02990e09ea8c4ef',
    "len(result['entries'])==3":"len(result['entries'])==4",
    'D620_CLOSED_EVIDENCE_STORAGE.md':'D622_CLOSED_EVIDENCE_STORAGE.md',
    "p2_backend_qualification/d619_20261017":"p2_backend_qualification/d621_20261017",
    'd620_verified_closed_log_storage_v1':'d622_verified_closed_log_storage_v1',
    'tc: preserve lossless D619 evidence compression before same-source W2/W0 (D620)':
        'tc: preserve closed D621 and historical failed D145 evidence losslessly (D622)',
    "assert sum(path.stat().st_size for path in files)<32*1024*1024":
        """files += [RAW/'tests.log',
    RAW.parent/'d620_20261017/publish.py',
    ROOT/'paper_results/ieee_tc/p2_backend/20261001_d145_7b_full_w0_full1.json',
    parent.parent/'d145_20261001/7b_full_w0_full1/launch.json',
    parent.parent/'d145_20261001/stop_services_full1.log']
assert sum(path.stat().st_size for path in files)<32*1024*1024""",
}
for before,after in changes.items():
    assert code.count(before)==1, before
    code=code.replace(before,after)
exec(compile(code,str(source),'exec'))
