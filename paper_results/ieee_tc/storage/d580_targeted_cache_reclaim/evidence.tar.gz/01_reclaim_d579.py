"""Reuse D577 fresh cache/original SHA and reference validation for D579 only."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
recipe=RAW.parent/'d577_20261016/reclaim_d576.py'
prefix=recipe.read_text().split("exec(compile(source,str(namespace['original'])",1)[0]
assert len(prefix)<len(recipe.read_text())
namespace={'__name__':'reclaim_recipe','__file__':str(RAW/'reclaim_d579.py')}
exec(compile(prefix,str(recipe),'exec'),namespace)
source=namespace['source'].replace('d576','d579').replace('full_w0','full_w1')
old='cd87563103cd04b786275f8b87b888b69a9118bdb0a97b37ef9879181880680d'
assert source.count(old)==1
source=source.replace(old,'55e4669060c162b527db2c819dc1ec58d08c85d05cb60ed8420729d72edf3140')
inner=namespace['namespace']
exec(compile(source,str(inner['original']),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'reclaim_d579.py'),'sha256':inner['sha256']})
