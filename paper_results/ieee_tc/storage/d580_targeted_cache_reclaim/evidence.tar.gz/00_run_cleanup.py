"""Reuse bounded D538 orchestration for freshly sealed D579 downloads only."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d538_20261015/run_cleanup.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='6749cdfcd7d4b42fedb43781c9e6a9257f7a431764a226c2c748176790112c21'
source=data.decode()
changes={
 'vllm_qualification/d532_20261015':'hydraserve_qualification/d579_20261016',
 "('analysis','result','publication','review','review_backup')":"('prepare','remote_prelaunch','audit','output_comparison','result','result_publication')",
 '3e759d75b6e69e182d646d87aca5090f5935024f':'4b5276a219a5e213d86a941dfc7837f9fedf5c09',
 'bde215460acb9e850efa479a89bda6fc39a2bd7d':'80e08b4c6e7c2874b1b237500a00811ec06cd8c5',
 "recipe=OLD/'reclaim_objects.py'":"recipe=RAW/'reclaim_d579.py'",
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'run_cleanup.py')})
