"""Archive explicit closed legacy results using the existing tested archiver.

No JSON loading/compaction: preserve every original byte. Verify each output
directory against the actual closed launch's recorded configuration first.
"""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import yaml

ROOT=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc import compress_closed_main_outcomes as archive

def save(name,value):
    with (ROOT/name).open('x') as out:
        json.dump(value,out,indent=2)

save('legacy_storage_identity.json',p.scope_identity(p.cg_path().name))
assert os.sched_getaffinity(0)=={2,3,26,27}
assert json.loads((ROOT/'legacy_test_result.json').read_text())['passed']
assert json.loads((ROOT/'legacy_test_closure.json').read_text())['passed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
seal=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')
assert p.verify_seal(seal)['pass']
# First large-file batch, no automatic recursion or other experiment roots.
targets=['d148_20261001/7b_full_w0_full1',
         'd137_20261001/7b_full_w0_full1',
         'd135_20261001/7b_full_w0_full1']
command=[sys.executable,'-B',str(MAIN/'scripts/ieee_tc/compress_closed_main_outcomes.py')]
bindings=[]
for run in targets:
    raw=archive.RAW_ROOT/run
    launch=json.loads((raw/'launch.json').read_text())
    archive.require_closed_launch(launch)
    args=launch['command']
    config=Path(args[args.index('--config')+1])
    assert config.parent==raw.parent and config.resolve()==config
    output=Path(yaml.safe_load(config.read_text())['experiment']['output_dir'])
    assert output.parent==raw.parent and output.resolve()==output
    files=list(output.glob('experiment_results_*.json'))
    assert len(files)==1,files
    source=files[0]
    relative=str(source.relative_to(raw.parent))
    assert archive.evidence_paths(raw,legacy_result=relative)[0]==source
    assert raw.parent.name.split('_')[0]+'_' in source.name
    archive.no_active(source)
    bindings.append(dict(run=run,source=str(source),config=str(config),
        config_sha256=p.digest(config),launch_sha256=p.digest(raw/'launch.json'),
        source_stamp=archive.stamp(source)))
    command.extend(['--closed-run',run,'--legacy-result',relative])
largest=max(row['source_stamp']['size'] for row in bindings)
free=os.statvfs('/home/qhq').f_bavail*os.statvfs('/home/qhq').f_frsize
assert free>=p.disk_required(largest+16*1024**2)
save('legacy_storage_bindings.json',dict(bindings=bindings,free_before=free,
    peak_additional_upper_bytes=largest+16*1024**2,
    reason='Closed legacy outputs retained losslessly; actual recorded config binds each selected path.'))
receipt=MAIN/'paper_results/ieee_tc/storage/20261013_d483_closed_legacy_results.json'
command.extend(['--receipt',str(receipt)])
start=time.monotonic()
reason=None
with (ROOT/'legacy_storage.log').open('x') as log:
    child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        while child.poll() is None:
            mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
            available=int(mem['MemAvailable'].split()[0])*1024
            disk=os.statvfs('/home/qhq')
            if available<16*1024**3 or disk.f_bavail*disk.f_frsize<100*1024**3 or not disk.f_favail:
                reason='resource_guard'
                break
            if time.monotonic()-start>7200:
                reason='finite_maintenance_time_guard'
                break
            time.sleep(1)
    finally:
        if child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL)
                child.wait()
    rc=child.wait()
if rc or reason:
    save('legacy_storage_failure.json',dict(returncode=rc,reason=reason,
        elapsed_s=time.monotonic()-start,partial_state_must_be_inspected=True))
    raise RuntimeError('legacy archival incomplete; preserve partial state and receipts')
assert p.verify_seal(seal)['pass']
result=json.loads(receipt.read_text())
assert result['source_archive_round_trip_verified']
summary=dict(passed=True,files=len(result['entries']),
    reclaimed_bytes=sum(row['allocated_bytes_reclaimed'] for row in result['entries']),
    free_bytes=result['after']['available_bytes'],receipt_sha256=p.digest(receipt),
    protected_unchanged=True,elapsed_s=time.monotonic()-start)
save('legacy_storage_result.json',summary)
print(json.dumps(summary),flush=True)
