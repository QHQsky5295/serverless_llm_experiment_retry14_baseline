"""Reuse protected/source/secrets/smoke/explicit-stage checks for terminal backup."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
template=HERE.parent.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d483_terminal').replace('D480','D483 terminal')
source=source.replace("BASE/'paper_results/ieee_tc/hydraserve/d483_terminal/summary.json'",
                      "MAIN/'paper_results/ieee_tc/storage/d483_terminal/summary.json'")
source=source.replace("assert mode in ('baseline','main')", "assert mode == 'main'")
source=source.replace("    paths = ['docs/ieee_tc/EXECUTION_STATUS.md']", """    paths = [
        'docs/ieee_tc/EXECUTION_STATUS.md',
        'docs/ieee_tc/D483_STORAGE_MAINTENANCE.md',
        'paper_results/ieee_tc/storage/20261013_d483_closed_legacy_results.json',
        'paper_results/ieee_tc/storage/d483_terminal/summary.json',
        'paper_results/ieee_tc/storage/d483_terminal/terminal_evidence.tar.gz']""")
marker="    remote, branch = 'faaslora_origin','retry14_continuous_queue_v2'\n    smoke = []"
assert marker in source
source=source.replace(marker,marker.replace('smoke = []',
    "smoke = ['tests.test_ieee_tc_closed_outcome_archive']"))
source=source.replace('qualify HydraServe native platform injection seam on CPU',
                      'seal lossless historical-result archival and protected cleanup evidence')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(HERE/'backup_reused.py')})
