"""Record an actual historical input-to-cache dependency, without bulk hashing."""
import json
from pathlib import Path
import sys

RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

run=BASE/'results/paper_experiments/15_new_serverless_baselines_remote_v1/20260521_dlora_remote_mig3_full4000_g2u92_s4_v1_llama32_3b_llama32_3b_r4000_a500_seed42_z1p0_hot48_rot500_s8_remote_fair_real-remote_v1_dlora'
manifest=run/'MANIFEST.json'
metadata=json.loads(manifest.read_text())
subset=Path(metadata['materialized_adapter_subset_path'])
assert subset.parent==run/'shared_inputs'
inputs=json.loads(subset.read_text())
cache=Path(inputs['remote_dir'])
assert cache==run/'remote_cache/dlora' and cache.is_dir()
source=Path(inputs['source_remote_dir'])
assert source.is_dir()
helper=BASE/'scripts/materialize_remote_adapter_subset.py'
result=dict(kind='specific_cache_retention_witness',manifest=str(manifest),
    manifest_sha256=p.digest(manifest),subset=str(subset),subset_sha256=p.digest(subset),
    actual_input_root=str(cache),recorded_original_root=str(source),
    materializer=str(helper),materializer_sha256=p.digest(helper),
    decision='retain; current historical input refers directly to this cache',
    limitations='One concrete dependency, not an all-consumer audit. No full cache/source SHA comparison or reconstruction has been performed this turn; do not infer wholesale deletion eligibility.',
    mutation=False)
with (RAW/'cache_retention_witness.json').open('x') as out:
    json.dump(result,out,indent=2)
print(json.dumps(result,indent=2))
