"""Small read-only live observation; never restarts or mutates a workload."""
import json
import os
from pathlib import Path
import sys
import time

RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

identity=json.loads((RAW/'legacy_storage_identity.json').read_text())
assert p.scope_still_owned(identity)
group=Path(identity['path'])
members={str(path):path.read_text().split() for path in group.rglob('cgroup.procs')}
processes=[]
for pid in sorted({pid for rows in members.values() for pid in rows}):
    process=Path('/proc')/pid
    try:
        stat=process.joinpath('stat').read_text()
        processes.append(dict(pid=int(pid),start_ticks=int(stat.rsplit(')',1)[1].split()[19]),
            comm=process.joinpath('comm').read_text().strip(),
            read_bytes=next(line for line in process.joinpath('io').read_text().splitlines()
                            if line.startswith('read_bytes:'))))
    except FileNotFoundError:
        processes.append(dict(pid=int(pid),exited_during_observation=True))
rows=[]
for binding in json.loads((RAW/'legacy_storage_bindings.json').read_text())['bindings']:
    source=Path(binding['source'])
    archived=source.with_suffix('.json.gz')
    receipt=source.with_name(source.name+'.compression_receipt.json')
    row=dict(run=binding['run'],source_exists=source.exists(),archive_exists=archived.exists(),
             archive_size=archived.stat().st_size if archived.exists() else None)
    if receipt.exists():
        data=json.loads(receipt.read_text())
        assert data['source_sha256']==data['first_roundtrip_sha256']==data['second_roundtrip_sha256']
        assert not source.exists() and archived.stat().st_size==data['archive_bytes']
        row.update(receipt_consistent=True,receipt_sha256=p.digest(receipt),
            reclaimed_bytes=data['allocated_bytes_reclaimed'],source_sha256=data['source_sha256'])
    rows.append(row)
mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
disk=os.statvfs('/home/qhq')
report=dict(time_unix=time.time(),identity=identity,actual_members=members,processes=processes,
    resources={key:(group/key).read_text().strip() for key in
               ('memory.current','memory.peak','memory.events','memory.swap.current')},
    mem_available_bytes=int(mem['MemAvailable'].split()[0])*1024,
    disk_free_bytes=disk.f_bavail*disk.f_frsize,files=rows,
    limitation='Receipt/metadata consistency check; not a new independent full-file SHA pass.')
with (RAW/'live_storage_observations.jsonl').open('a') as out:
    out.write(json.dumps(report)+'\n')
    out.flush();os.fsync(out.fileno())
print(json.dumps(report,indent=2))
