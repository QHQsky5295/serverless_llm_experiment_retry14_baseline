"""Close the large-file maintenance evidence without changing the live snapshot."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

HERE=Path(__file__).resolve().parent
RAW=HERE.parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path,value):
    with path.open('x') as out:json.dump(value,out,indent=2)
save(HERE/'curation_identity.json',p.scope_identity(p.cg_path().name))
closed=json.loads((RAW/'legacy_storage_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_empty']
result=json.loads((RAW/'legacy_storage_result.json').read_text())
assert result['passed'] and result['files']==3 and result['protected_unchanged']
receipt=MAIN/'paper_results/ieee_tc/storage/20261013_d483_closed_legacy_results.json'
assert p.digest(receipt)==result['receipt_sha256']
aggregate=json.loads(receipt.read_text())
assert aggregate['source_archive_round_trip_verified']
bindings=json.loads((RAW/'legacy_storage_bindings.json').read_text())['bindings']
assert len(bindings)==len(aggregate['entries'])==3
receipts=[]
for binding,row in zip(bindings,aggregate['entries']):
    assert row['source']==binding['source'] and row['run']==binding['run']
    assert row['source_stamp']==binding['source_stamp']
    assert p.digest(Path(binding['config']))==binding['config_sha256']
    source=Path(row['source'])
    assert not source.exists()
    assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']
    assert p.digest(Path(row['archive']))==row['archive_sha256']
    item=source.with_name(source.name+'.compression_receipt.json')
    assert json.loads(item.read_text())['source_sha256']==row['source_sha256']
    receipts.append(item)
tests=json.loads((RAW/'legacy_test_result.json').read_text())
assert tests['passed']
for name,sha in tests['source_sha256'].items():assert p.digest(MAIN/name)==sha
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
files=receipts+[receipt]+[RAW/name for name in
    ('compress_legacy_storage.py','legacy_storage_bindings.json','legacy_storage_identity.json',
     'legacy_storage_result.json','legacy_storage_closure.json','legacy_storage.log',
     'observe_storage.py','live_storage_observations.jsonl',
     'cache_retention_witness.py','cache_retention_witness.json',
     'legacy_test_result.json','legacy_test_closure.json','legacy_test.log',
     'storage_result.json','backup_main_receipt.json','backup_main_closure.json',
     'backup_baseline_receipt.json','backup_baseline_closure.json')]
files += [HERE/name for name in ('curate.py','close.py','backup.py')]
dest=MAIN/'paper_results/ieee_tc/storage/d483_terminal'
dest.mkdir()
manifest={str(path):dict(sha256=p.digest(path),bytes=path.stat().st_size) for path in files}
archive=dest/'terminal_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as out:
    for path in files:
        assert path.stat().st_size<1024**2
        out.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle.getmembers():
        assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest()==manifest['/home/qhq/'+member.name]['sha256']
completed=json.loads((RAW/'storage_result.json').read_text())
summary=dict(checkpoint_verified=True,performance_result=False,source_manifest=manifest,
    archive_sha256=p.digest(archive),tests=tests,tests_count=12,
    legacy_storage=result,monitor_storage=completed,
    total_allocated_bytes_reclaimed=result['reclaimed_bytes']+completed['reclaimed_bytes'],
    actual_terminal_closure=closed,protected_verification=protected,
    live_work=None,cache_retention=json.loads((RAW/'cache_retention_witness.json').read_text()),
    previous_live_snapshot_sha256=p.digest(MAIN/'paper_results/ieee_tc/storage/d483/summary.json'))
save(dest/'summary.json',summary)
save(HERE/'curation_result.json',dict(passed=True,source_count=len(files),
    archive_sha256=p.digest(archive),summary_sha256=p.digest(dest/'summary.json')))
print(json.dumps(dict(passed=True,total_reclaimed_bytes=summary['total_allocated_bytes_reclaimed'],
    archive_sha256=p.digest(archive))))
