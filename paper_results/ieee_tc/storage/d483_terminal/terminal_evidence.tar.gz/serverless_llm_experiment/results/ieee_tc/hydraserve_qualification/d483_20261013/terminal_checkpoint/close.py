"""Reuse actual recursive-empty closure, retaining separate terminal receipts."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
template=HERE.parent.parent/'d481_20261013/close.py'
exec(compile(template.read_text(),str(template),'exec'),
     {'__name__':'__main__','__file__':str(HERE/'close_reused.py')})
