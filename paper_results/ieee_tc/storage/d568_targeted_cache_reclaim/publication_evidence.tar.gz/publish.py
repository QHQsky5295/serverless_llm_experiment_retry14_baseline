"""Adapt D537 exact-path publication with archive/SHA/secret/protected guards."""
import hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(x):return json.loads(x.read_text())
def save(x,v):
    with x.open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='e24b442aa6f7958f75f59371ede986f955c1de3c'
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
for name in ('cleanup','curation'):
    c=read(RAW/(name+'_closure.json'))
    assert c['passed'] and c['path_gone'] and c['actual_recursive_procs_empty']
    assert not Path(c['identity']['path']).exists()
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D568_TARGETED_CACHE_RECLAIM.md']
reports=read(RAW/'curation_receipt.json')['reports']
for item in reports:
    out=Path(item['path']);record=read(out/'manifest.json')
    assert record['passed'] and not record['new_gpu_run'] and not record['production_changed']
    for path,sha in record['preserved'].items():assert p.digest(Path(path))==sha
    for name,sha in record['outputs'].items():assert p.digest(out/name)==sha
    with tarfile.open(out/'evidence.tar.gz') as bundle:
        assert set(bundle.getnames())==set(record['archive_members'])
        for name,ref in record['archive_members'].items():
            data=bundle.extractfile(name).read();check(data)
            assert hashlib.sha256(data).hexdigest()==ref['sha256']
    subprocess.run(['sha256sum','-c','result.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
    names += [str((out/name).relative_to(ROOT)) for name in (*record['outputs'],'manifest.json','result.sha256')]
out=Path(reports[-1]['path']);archive=out/'publication_evidence.tar.gz'
members=[RAW/n for n in ('publish.py','curation_identity.json','curation_closure.json','curation_receipt.json','close.py')]
with tarfile.open(archive,'x:gz') as bundle:
    for path in members:
        data=path.read_bytes();check(data);bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
with (out/'publication.sha256').open('x') as f:f.write(p.digest(archive)+'  '+archive.name+'\n')
subprocess.run(['sha256sum','-c','publication.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
names += [str(x.relative_to(ROOT)) for x in (archive,out/'publication.sha256')]
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(names) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: preserve D567 closed-cache reclamation before Loquetier qualification (D568)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity,protected=protected))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
