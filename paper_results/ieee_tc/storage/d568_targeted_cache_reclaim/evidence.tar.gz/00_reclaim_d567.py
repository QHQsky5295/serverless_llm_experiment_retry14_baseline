"""Reuse SHA-bound D532 content/ownership audit for sealed D567 private objects."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='e66e17f0a2ca0f72c0c0ae9f6bb6c6da8351b924f4d72ce4f7e93c64476892bb'
source=data.decode().replace('d532','d567').replace('d567_20261015','d567_20261016')
changes={
    '/tmp/tc-d567-7bv/':'/tmp/tc-d567-7bl/',
    'ROOT = Path(__file__).resolve().parent':"ROOT = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/loquetier_qualification/d567_20261016')",
    'main_comparison/d567_vllm_w1/':'loquetier/d567_capacity_full500/',
    'f3b2344147c51db9407b9711ec6dbc59af8c6c5007dd7c9d90fdd68efcf6ddb7':'4a131744ab34af981ccbb636e77427bb47c2523c1eeb1e9f8e2e946142913544',
    "audit['offered_unique_adapters'] == 132":"audit['offered_unique_adapters'] == 500",
    "audit['verified_materialized_bytes'] == 3300789780":"audit['verified_materialized_bytes'] == 12985984450",
}
for old,new in changes.items():
    assert source.count(old)==1,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'reclaim_d567.py')})
