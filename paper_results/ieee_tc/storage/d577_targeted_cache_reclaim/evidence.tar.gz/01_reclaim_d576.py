"""Reuse D575 fresh-source/cache validation for sealed D576 downloads only."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
recipe=RAW.parent/'d575_20261016/reclaim_d574.py'
prefix=recipe.read_text().split('exec(compile(source,',1)[0]
namespace={'__name__':'reclaim_recipe','__file__':str(RAW/'reclaim_d576.py')}
exec(compile(prefix,str(recipe),'exec'),namespace)
source=namespace['source'].replace('d574','d576')
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('hydraserve/d576_native_lifecycle_qualification_v2/affected_qualification.json',
        'hydraserve/d576_lifecycle_full_w0_result/full_w0_evaluation.json')
replace('2abb52ba6126629bb21aee2ef749a052fc8c5404de93b25a8566076ae10a2c5b',
        'cd87563103cd04b786275f8b87b888b69a9118bdb0a97b37ef9879181880680d')
replace("assert audit['passed'] and audit['n_native_contract_complete']==100 and audit['remote_transfers']==29",
        "assert audit['full_audit_pass'] and audit['n_v1_contract_complete']==4000 and audit['remote_transfers']==132")
replace('len(receipts)==29','len(receipts)==132')
replace("audit['offered_unique_adapters']=29","audit['offered_unique_adapters']=132")
replace("audit['verified_materialized_bytes']==724665100","audit['verified_materialized_bytes']==3300789780")
exec(compile(source,str(namespace['original']),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'reclaim_d576.py'),'sha256':namespace['sha256']})
