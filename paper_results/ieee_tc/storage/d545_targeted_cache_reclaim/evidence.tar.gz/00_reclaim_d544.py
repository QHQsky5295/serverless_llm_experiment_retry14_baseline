"""Reuse D532/D538 closed-cache checks, limited to D544 duplicate downloads."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

RAW=Path(__file__).resolve().parent
OLD=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/loquetier_qualification/d544_20261015')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
TARGET=Path('/tmp/tc-d544-7bl/remote_artifacts/objects')
ORIGINAL=Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
sys.path[:0]=[str(MAIN),str(MAIN/'scripts/ieee_tc')]
from scripts import ieee_tc_preflight as p
from cleanup_d370_aborted_cache import digest, active_reference, write_json
def read(path):return json.loads(path.read_text())
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
write_json(RAW/'cleanup_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert TARGET.is_dir() and not TARGET.is_symlink() and TARGET.resolve()==TARGET
launch=read(OLD/'launch7b.json')
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert launch['pass'] is False and launch['service_returncode']==1
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for name in ('analysis','analysis2','cross','result','result_publication'):
    closed=read(OLD/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert read(OLD/'local_cleanup.json')['passed']
publication=read(OLD/'result_publication_receipt.json')
assert publication['passed'] and publication['head']==publication['remote']
assert subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=MAIN,text=True).split()[0]==publication['head']
diagnostic=read(OLD/'audit_full4000_w1.json')
assert diagnostic['measurement_complete'] and diagnostic['native_revalidated_requests']==3844
assert diagnostic['outcome_contract']=='complete_with_failures' and diagnostic['counts']['N_failed']==156
assert not diagnostic['workload_passed'] and not diagnostic['performance_ranking_eligible']
assert diagnostic['physical_gpu_seconds']>0 and diagnostic['n_correct'] is None
assert read(OLD/'evidence_copy_receipt.json')['actual_gpu_release']
index_path=MAIN/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
assert digest(index_path)=='e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c'
index=read(index_path)
selected={path.stem for path in (OLD/'remote_resolver_evidence/receipts').glob('*.json')}
assert len(selected)==500 and selected=={r['id'] for r in index['artifacts']}
assert selected=={path.name for path in TARGET.iterdir() if path.is_dir()}
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
expected=set();total=0
for row in index['artifacts']:
    for item in row['files']:
        path,source=TARGET/row['id']/item['path'],ORIGINAL/row['id']/item['path']
        assert path.is_file() and not path.is_symlink() and source.is_file()
        assert path.stat().st_size==source.stat().st_size==item['size_bytes']
        assert (path.stat().st_dev,path.stat().st_ino)!=(source.stat().st_dev,source.stat().st_ino)
        assert digest(path)==digest(source)==item['sha256']
        expected.add(path);total+=item['size_bytes']
assert total==12985984450
assert not any(path.is_symlink() for path in TARGET.rglob('*'))
assert {path for path in TARGET.rglob('*') if path.is_file()}==expected
for line in Path('/proc/self/mountinfo').read_text().splitlines():
    mount=line.split()[4]
    assert mount!=str(TARGET) and not mount.startswith(str(TARGET)+'/')
assert not active_reference(TARGET) and not active_reference(TARGET.parent.parent)
private=str(TARGET.parent.parent);hits=[];unreadable=[]
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
    try:
        if proc.stat().st_uid!=os.getuid():continue
        for link in [proc/'cwd',proc/'root',*list((proc/'fd').iterdir())]:
            try:
                value=os.readlink(link)
                if value==private or value.startswith(private+'/'):hits.append(dict(pid=proc.name,link=link.name))
            except (FileNotFoundError,ProcessLookupError):pass
    except (FileNotFoundError,ProcessLookupError):pass
    except PermissionError:unreadable.append(proc.name)
assert not hits,hits
future=[]
for repo in (MAIN,BASE):
    result=subprocess.run(['git','grep','-l','-F',private,'--','configs','scripts'],cwd=repo,capture_output=True,text=True)
    assert result.returncode in (0,1),result.stderr
    future.extend(result.stdout.splitlines())
assert not future,future
metadata=TARGET.parent;saved=OLD/'remote_resolver_evidence'
for name in ('receipts','journals'):
    originals={path.relative_to(metadata) for path in (metadata/name).rglob('*') if path.is_file()}
    copies={path.relative_to(saved) for path in (saved/name).rglob('*') if path.is_file()}
    assert originals==copies
    assert all(digest(metadata/path)==digest(saved/path) for path in originals)
assert digest(metadata/'run_contract.json')==digest(saved/'run_contract.json')
before=shutil.disk_usage('/home/qhq').free
write_json(RAW/'cleanup_before.json',dict(schema='ieee_tc_closed_download_cache_reclamation_v1',
    target=str(TARGET),files=len(expected),payload_bytes=total,disk_before_bytes=before,
    retained_original_pool=str(ORIGINAL),retained_evidence=str(OLD),
    all_current_original_and_cache_bytes_rehashed=True,metadata_copies_hash_match=True,
    protected_before=protected,owned_runtime_references=hits,future_config_script_references=future,
    unreadable_same_uid_proc_entries=sorted(set(unreadable)),
    open_fd_check_scope='readable same-UID FD/cwd/root plus fuser, not whole system',
    raw_results_removed=False,unique_artifacts_removed=False,classification_unchanged=True,
    recipe_sha256=digest(Path(__file__)),source_index_sha256=digest(index_path),
    publication_head=publication['head'],recorded_unix=time.time()))
shutil.rmtree(TARGET)
assert not TARGET.exists()
after=shutil.disk_usage('/home/qhq').free
protected_after=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected_after['pass']
write_json(RAW/'cleanup_receipt.json',dict(passed=True,identity=identity,target=str(TARGET),
    files=len(expected),payload_bytes=total,observed_reclaimed_bytes=after-before,
    disk_after_bytes=after,raw_results_removed=False,unique_artifacts_removed=False,
    protected_after=protected_after,before_receipt_sha256=digest(RAW/'cleanup_before.json'),
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,removed=str(TARGET),files=len(expected),
    payload_bytes=total,reclaimed_bytes=after-before,disk_after_bytes=after)),flush=True)
