"""Reuse D545 exact-path publication with the current checkpoint identity."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d545_20261015/publish.py').read_text()
source=source.replace('d545','d547').replace('D545','D547').replace('D544','D536')
source=source.replace('dfeacf4e6042318b4cf365a4f9620a2a2dbd305e','f52100be2b8b24890a77fdb03adbfc20fca11fe2')
exec(compile(source,str(RAW/'publish_reused.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'publish.py')})
