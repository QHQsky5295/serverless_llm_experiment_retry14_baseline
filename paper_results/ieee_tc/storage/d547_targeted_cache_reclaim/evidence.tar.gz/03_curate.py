"""Reuse D545 archive/roundtrip curation for D536's retained cleanup receipts."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d545_20261015/curate.py').read_text()
source=source.replace('d545','d547').replace('D545','D547')
source=source.replace('CLEAN=RAW',"CLEAN=RAW\nOLD=RAW.parent.parent/'vllm_qualification/d536_20261015'")
old="""clean=read(RAW/'cleanup_receipt.json');before=read(RAW/'cleanup_before.json')
assert clean['passed'] and clean['files']==5000 and clean['payload_bytes']==12985984450
assert before['all_current_original_and_cache_bytes_rehashed'] and before['metadata_copies_hash_match']
assert not clean['raw_results_removed'] and not clean['unique_artifacts_removed']
assert not Path(clean['target']).exists()"""
new="""clean=read(RAW/'cleanup_receipt.json');before=read(OLD/'cache_cleanup_before.json')
after=read(OLD/'cache_cleanup_after.json')
assert clean['passed'] and clean['returncode']==0
assert before['files']==1320 and before['payload_bytes']==3300789780
assert before['current_original_bytes_rehashed'] and before['current_cache_bytes_rehashed']
assert before['metadata_copies_hash_match'] and after['removed']
assert not after['raw_results_removed'] and not after['unique_artifacts_removed']
assert not Path(after['target']).exists()"""
assert source.count(old)==1;source=source.replace(old,new)
source=source.replace("[RAW/n for n in ('reclaim_d544.py','close.py','curate.py','cleanup_identity.json','cleanup_before.json','cleanup_receipt.json','cleanup_closure.json')]",
    "[RAW/n for n in ('reclaim_d536.py','run_cleanup.py','close.py','curate.py','cleanup_identity.json','cleanup_receipt.json','cleanup_closure.json')] + [OLD/'cache_cleanup_before.json',OLD/'cache_cleanup_after.json',RAW.parent/'d538_20261015/run_cleanup.py',RAW.parent/'d545_20261015/curate.py',RAW.parent/'d545_20261015/close.py',OLD.parent/'d532_20261015/reclaim_objects.py']")
source=source.replace("{'cleanup_before.json':RAW/'cleanup_before.json','cleanup_receipt.json':RAW/'cleanup_receipt.json','cleanup_closure.json':RAW/'cleanup_closure.json'}",
    "{'cleanup_before.json':OLD/'cache_cleanup_before.json','cleanup_after.json':OLD/'cache_cleanup_after.json','cleanup_receipt.json':RAW/'cleanup_receipt.json','cleanup_closure.json':RAW/'cleanup_closure.json'}")
exec(compile(source,str(RAW/'curate_reused.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'curate.py')})
