"""Reuse SHA-bound D532 full-content reclamation for closed D536 only."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'vllm_qualification/d532_20261015/reclaim_objects.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='e66e17f0a2ca0f72c0c0ae9f6bb6c6da8351b924f4d72ce4f7e93c64476892bb'
source=data.decode().replace('d532','d536')
source=source.replace('ROOT = Path(__file__).resolve().parent',
    "ROOT = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d536_20261015')")
source=source.replace('f3b2344147c51db9407b9711ec6dbc59af8c6c5007dd7c9d90fdd68efcf6ddb7',
    '3a7a7fba27734b2ac5bed3eeca3a29cce2a25f69984443fb56226ac90ecf63f2')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'reclaim_d536.py')})
