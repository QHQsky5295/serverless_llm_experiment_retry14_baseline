"""Reuse D538 bounded closure/protection checks for the newly selected cache."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d538_20261015/run_cleanup.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='6749cdfcd7d4b42fedb43781c9e6a9257f7a431764a226c2c748176790112c21'
source=data.decode().replace('d532','d536')
source=source.replace("('analysis','result','publication','review','review_backup')",
    "('analysis','result','publication','review')")
source=source.replace('3e759d75b6e69e182d646d87aca5090f5935024f','f52100be2b8b24890a77fdb03adbfc20fca11fe2')
source=source.replace("recipe=OLD/'reclaim_objects.py'","recipe=RAW/'reclaim_d536.py'")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'run_cleanup.py')})
