"""Reuse explicit-source/checksum/secret guards for D541 tested common repair."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=MAIN/'paper_results/ieee_tc/resource_measurement/d541_pidfd_exit'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=MAIN,text=True).strip()
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD')=='31526e77835ec8e70e0096de21dbc3b9375bfc19'
assert git('branch','--show-current')=='retry14_continuous_queue_v2' and not git('diff','--cached','--name-only')
changed=set(git('diff','--name-only','--','faaslora','tests','scripts','configs/ieee_tc').splitlines())
assert changed=={'faaslora/metrics/metrics_collector.py','tests/test_ieee_tc_gpu_lifecycle.py'}
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
before=read(RAW/'before_receipt.json');failed=read(RAW/'after_receipt.json');after=read(RAW/'after2_receipt.json')
assert before['passed'] and before['expected_old_failure'] and before['returncode']==1
assert failed['passed'] is False and failed['returncode']==1
assert after['passed'] and after['returncode']==0
assert 'Ran 53 tests' in (RAW/'after2.log').read_text() and (RAW/'after2.log').read_text().rstrip().endswith('OK')
for path,sha in after['sources'].items():assert p.digest(Path(path))==sha
cleanup=read(RAW/'cleanup_receipt.json')
assert cleanup['passed'] and not cleanup['raw_results_removed'] and not cleanup['unique_artifacts_removed']
assert not Path(cleanup['target']).exists()
for name in ('before','after','after2','cleanup'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
preserved={str(MAIN/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log')])
files += [MAIN/'faaslora/metrics/metrics_collector.py',MAIN/'tests/test_ieee_tc_gpu_lifecycle.py',
          MAIN/'docs/ieee_tc/D541_PIDFD_EXIT_MEASUREMENT_FIX.md']
OUT.mkdir(parents=True,exist_ok=False)
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<4*1024*1024;clean(data)
        if path.suffix=='.py':ast.parse(data)
        name=f'{i:02d}_{path.name}';info=tarfile.TarInfo(name)
        info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'summary.json',dict(passed=True,new_gpu_performance=False,baseline_algorithm_changed=False,
    before_reproduced=before,first_regression=failed,final_regression=after,cleanup=cleanup,
    preserved_failure_commit='31526e77835ec8e70e0096de21dbc3b9375bfc19',
    old_metric_source_sha256=before['sources'][str(MAIN/'faaslora/metrics/metrics_collector.py')],
    source_sha256={str(MAIN/path):p.digest(MAIN/path) for path in sorted(changed)},
    affected_run_requires_new_attempt=True,old_gpu_seconds_unknown=True,
    protected=protected,preserved=preserved,scope=identity,
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz')))
with (OUT/'result.sha256').open('x') as f:
    for name in ('summary.json','evidence.tar.gz'):f.write(p.digest(OUT/name)+'  '+name+'\n')
paths=[*sorted(changed),'docs/ieee_tc/D541_PIDFD_EXIT_MEASUREMENT_FIX.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(MAIN)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
for name in paths:
    data=(MAIN/name).read_bytes();assert len(data)<2*1024*1024
    if not name.endswith('.tar.gz'):clean(data)
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=MAIN,check=True)
subprocess.run(['git','add','--',*paths],cwd=MAIN,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for name in paths:assert subprocess.check_output(['git','show',':'+name],cwd=MAIN)==(MAIN/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=MAIN,check=True)
subprocess.run(['git','commit','-m','tc: observe high-numbered pidfd exits without weakening physical release (D541)'],cwd=MAIN,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=MAIN,check=True)
head=git('rev-parse','HEAD')
assert git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]==head
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote_equal=True,files=paths,identity=identity))
print(json.dumps(dict(passed=True,head=head,files=len(paths),remote_equal=True)),flush=True)
