"""Reuse bounded CPU regression receipt pattern; never start model/remote work."""
import json
import os
from pathlib import Path
import subprocess
import sys
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
phase=sys.argv[1];assert phase in ('before','after','after2')
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
with (RAW/(phase+'_identity.json')).open('x') as f:json.dump(identity,f,indent=2)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
tests=(['tests.test_ieee_tc_gpu_lifecycle.DedicatedPhysicalOwner.test_real_high_numbered_pidfd_waits_for_exit']
       if phase=='before' else ['tests.test_ieee_tc_gpu_lifecycle','tests.test_ieee_tc_cpu_frontend_integration'])
command=[sys.executable,'-B','-m','unittest',*tests,'-v']
with (RAW/(phase+'.log')).open('x') as log:
    result=subprocess.run(command,cwd=MAIN,stdout=log,stderr=subprocess.STDOUT)
contents=(RAW/(phase+'.log')).read_text()
passed=(result.returncode!=0 and 'filedescriptor out of range in select()' in contents
        if phase=='before' else result.returncode==0)
record=dict(passed=passed,phase=phase,command=command,returncode=result.returncode,
    expected_old_failure=phase=='before',identity=identity,
    sources={str(path):p.digest(path) for path in (Path(__file__),
        MAIN/'faaslora/metrics/metrics_collector.py',MAIN/'tests/test_ieee_tc_gpu_lifecycle.py',
        MAIN/'tests/test_ieee_tc_cpu_frontend_integration.py',RAW/(phase+'.log'))},
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')})
with (RAW/(phase+'_receipt.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record),flush=True)
assert passed
