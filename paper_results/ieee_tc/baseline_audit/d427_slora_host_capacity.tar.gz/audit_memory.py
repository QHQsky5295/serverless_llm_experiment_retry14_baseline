"""D427 extension of D425 source/log inventory, not a performance runner.

Reuse the frozen content index, pool and audited layout; read headers/configs
only. No tensor materialization, remote request, GPU import or asset generation.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct

BASE = Path('/home/qhq/serverless_llm_baselines')
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
POOL = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
BACKBONE = Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf/config.json')
HERE = Path(__file__).resolve().parent
INDEX = MAIN/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
INVENTORY = MAIN/'paper_results/ieee_tc/baseline_audit/d425_slora_reuse_inventory.json'
HELPER = BASE/'scripts/prepare_ieee_tc_serverless_stack.py'


def identity(path):
    blob = path.read_bytes()
    return dict(path=str(path), bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest())


spec = importlib.util.spec_from_file_location('d427_source', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
source = []
for name, expected in helper.SLORA_HOST_LAYOUT_SOURCES.items():
    item = identity(BASE/'repos/S-LoRA'/name)
    assert item['sha256'] == expected, name
    source.append(item)
assert identity(INDEX)['sha256'] == 'e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c'
index = json.loads(INDEX.read_bytes())
facts, records = [], []
for adapter in index['artifacts']:
    aid = adapter['id']
    assert Path(aid).name == aid and aid not in ('.', '..')
    files = {row['path']: row for row in adapter['files']}
    config_path = POOL/aid/'adapter_config.json'
    weight_path = POOL/aid/'adapter_model.safetensors'
    cfg_id = identity(config_path)
    assert cfg_id['sha256'] == files['adapter_config.json']['sha256']
    cfg = json.loads(config_path.read_bytes())
    assert set(cfg['target_modules']) == {'q_proj', 'k_proj', 'v_proj', 'o_proj'}
    assert not cfg.get('modules_to_save') and cfg['bias'] == 'none'
    before = weight_path.stat()
    assert before.st_size == files['adapter_model.safetensors']['size_bytes']
    with weight_path.open('rb') as handle:
        length_blob = handle.read(8)
        length = struct.unpack('<Q', length_blob)[0]
        assert 0 < length < 1024**2
        raw_header = handle.read(length)
    header = json.loads(raw_header)
    tensors = {k: v for k, v in header.items() if k != '__metadata__'}
    assert {v['dtype'] for v in tensors.values()} == {'F16'}
    end = 0
    for value in sorted(tensors.values(), key=lambda v: v['data_offsets'][0]):
        start, stop = value['data_offsets']
        assert start == end and stop-start == 2*__import__('math').prod(value['shape'])
        end = stop
    assert end + 8 + length == before.st_size
    after = weight_path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    facts.append(dict(adapter_id=aid, rank=cfg['r'], dtype='F16',
                      tensor_shapes={k: v['shape'] for k, v in tensors.items()}))
    records.append(dict(adapter_id=aid, rank=cfg['r'], config_sha256=cfg_id['sha256'],
        header_sha256=hashlib.sha256(length_blob+raw_header).hexdigest(),
        tensor_bytes=end, weight_bytes=before.st_size,
        frozen_weight_sha256=files['adapter_model.safetensors']['sha256'],
        weight_payload_rehashed_this_audit=False))
assert len(records) == len({r['adapter_id'] for r in records}) == 500
model = json.loads(BACKBONE.read_bytes())
bounds = [helper.slora_host_storage_bound(facts, model, n, 80*1024**3) for n in (1, 2, 3, 4)]
logs = []
for entry in json.loads(INVENTORY.read_bytes())['support_files']:
    path = Path(entry['path'])
    if path.suffix != '.log':
        continue
    assert identity(path)['sha256'] == entry['sha256']
    rows = []
    for number, line in enumerate(path.read_text(errors='replace').splitlines(), 1):
        if re.search(r'\bRSS\b|\bVmRSS\b|\bRssAnon\b|\bRssFile\b|memory\.current|memory\.peak|memory\.max|MemoryMax|resident.set', line, re.I):
            rows.append(dict(line_number=number, text=line[:1000]))
    logs.append(dict(path=str(path), sha256=entry['sha256'], matched_lines=rows))
result = dict(schema='ieee_tc_d427_slora_host_capacity_audit_v1',
    sources=[identity(p) for p in (INDEX, INVENTORY, BACKBONE, HELPER, Path(__file__))]+source,
    pool=str(POOL), pool_weight_payload_bytes=sum(r['tensor_bytes'] for r in records),
    pool_materialized_file_bytes=sum(f['size_bytes'] for a in index['artifacts'] for f in a['files']),
    records=records, replica_bounds=bounds, historical_logs=logs,
    decision='Native four-replica full-pool two-copy pinned tensors alone exceed common memory.max; do not launch that configuration. Smaller replicas are not yet memory-qualified. No policy/storage adaptation selected here.',
    limitations=['Header/config audit reuses earlier full content SHA evidence; no new payload hash.',
                 'Bounds exclude all other service memory and are not measured RSS.',
                 'Legacy log pattern scan is not an exhaustive claim that no other measurement exists.',
                 'No GPU run, performance comparison, runtime patch, or baseline qualification.'])
with (HERE/'audit.json').open('x') as output:
    json.dump(result, output, indent=2)
print(json.dumps(dict(output=str(HERE/'audit.json'), sha256=identity(HERE/'audit.json')['sha256'],
    adapter_count=len(records), bytes=result['pool_weight_payload_bytes'],
    bounds=[dict(replicas=r['replicas'], pinned_GiB=r['pinned_adapter_bytes_lower_bound']/1024**3,
                 exceeds_max=r['exceeds_memory_max']) for r in bounds],
    logs=len(logs), memory_pattern_lines=sum(len(r['matched_lines']) for r in logs)), indent=2))
