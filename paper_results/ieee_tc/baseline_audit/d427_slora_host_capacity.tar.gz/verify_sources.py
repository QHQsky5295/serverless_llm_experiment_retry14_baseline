"""Reuse D425 fixed-commit source comparison for the HOST-layout evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

NATIVE = Path('/home/qhq/serverless_llm_baselines/repos/S-LoRA')
COMMIT = 'c1ddf488781ea7f551cd0bb07bfd097124c93411'
rows = []
for path in ('slora/models/peft/layer_weights/lora_layer_weight.py',
             'slora/models/peft/layer_weights/hf_load_utils.py'):
    url = f'https://raw.githubusercontent.com/S-LoRA/S-LoRA/{COMMIT}/{path}'
    with urllib.request.urlopen(url, timeout=30) as response:
        remote = response.read(1024**2)
    original = subprocess.check_output(['git', 'show', COMMIT+':'+path], cwd=NATIVE)
    assert remote == original, path
    current = (NATIVE/path).read_bytes()
    rows.append(dict(path=path, url=url, commit=COMMIT, upstream_bytes=len(remote),
        upstream_sha256=hashlib.sha256(remote).hexdigest(), upstream_equals_git_head=True,
        current_sha256=hashlib.sha256(current).hexdigest(), current_equals_upstream=current == remote))
result = dict(schema='ieee_tc_d427_upstream_host_layout_v1', rows=rows,
    compatibility_note='Existing local TP/GQA compatibility changes retained. Both source versions retain separate and packed CPU tensors in the audited TP1 non-GQA branch.')
with Path(__file__).with_name('sources.json').open('x') as output:
    json.dump(result, output, indent=2)
print(json.dumps(result, indent=2))
