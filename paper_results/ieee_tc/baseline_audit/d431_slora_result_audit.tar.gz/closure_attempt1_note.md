The first auxiliary closure command called the preflight module's
`stop_own_unit` after verifying the first auxiliary scope was empty and had its
expected identity. That helper accepts only test units, so it raised
`ValueError: refusing to kill a non-test unit` before stopping anything.
Its empty stdout log is retained; stderr was displayed but was not redirected
to that log. No production guard or unit identity rule was changed.

The second command reread each exact scope identity, memory limits and all
descendant cgroup.procs, then stopped only those four empty D431 scopes using
systemctl and verified disappearance. See aux_closure2.log. This was closure
of completed CPU tests, not a failed or repeated performance experiment.
