"""D425 adaptation of the existing D420 legacy replay inventory, CPU only.

No performance ranking, inferred native timestamps, qualification promotion,
weight/trace generation, or old-result writes. Output is exclusive-create.
"""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path('/home/qhq/serverless_llm_baselines')
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
HERE = Path(__file__).resolve().parent
OUT = MAIN/'paper_results/ieee_tc/baseline_audit/d425_slora_reuse_inventory.json'


def identity(path):
    blob = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(blob).hexdigest(), bytes=len(blob))


paths = subprocess.check_output(
    ['rg', '--files', 'results', '-g', '*slora*replay.json'], cwd=BASE,
    text=True).splitlines()
paths = sorted(p for p in paths if '7b' in p)
rows, support = [], {}
patterns = {
    'first_native_token': r'first_token_(time|ts)|native_first_token|first_token_monotonic',
    'last_native_token': r'last_token_(time|ts)|native_last_token|last_token_monotonic',
    'physical_lease': r'physical_owner_id|allocation_monotonic|release_monotonic|gpu_acquired|gpu_released',
    'resource_envelope': r'MemoryHigh|MemoryMax|memory\.high|memory\.max|memory\.swap\.max',
    'replay_start_marker': r'\[4/5\] Replaying',
    'replica_startup': r'replica=\d+ startup_sec=',
    'traceback': r'Traceback \(most recent call last\)',
}
for name in paths:
    p = BASE/name
    data = json.loads(p.read_bytes())
    records = data['results']
    ids = sorted({r['adapter_id'] for r in records if r.get('adapter_id')})
    key_union = sorted({k for r in records for k in r})
    server_keys = sorted({k for r in records for k in (r.get('server_metrics') or {})})
    row = dict(**identity(p), reported_rows=len(records),
        reported_success=sum(r.get('success') is True for r in records),
        actual_logical_ids=len(ids), adapter_ids_sha256=hashlib.sha256(
            json.dumps(ids, separators=(',', ':')).encode()).hexdigest(),
        native_token_source_rows=sum(r.get('completion_token_source') == 'slora_native_sse_token_id' for r in records),
        output_contract_match_rows=sum(r.get('output_contract_match') is True for r in records),
        output_token_hash_rows=sum(bool(r.get('completion_token_ids_sha256')) for r in records),
        canonical_prompt_hash_rows=sum(bool(r.get('canonical_prompt_sha256')) for r in records),
        nonempty_server_metrics_rows=sum(bool(r.get('server_metrics')) for r in records),
        row_keys=key_union, server_metric_keys=server_keys,
        generation_contract=data.get('generation_contract'), routing_policy=data.get('routing_policy'),
        trace_source=data.get('trace_source'), max_requests=data.get('max_requests'),
        client_prewarm_sec_excluded_from_workload_clock=data.get('client_prewarm_sec_excluded_from_workload_clock'),
        replay_time_origin=data.get('replay_time_origin'), support_files=[])
    run = p.parents[2]
    stem = p.name.removesuffix('_replay.json')
    candidates = [*list((run/'raw/logs').glob(stem+'*')),
        *list((run/'raw/shared_inputs').glob(stem+'*')),
        run/'logs/40_slora.log', run/'protocol/system_resolved_config.json',
        p.with_name(stem+'_summary.json')]
    for q in sorted(set(candidates)):
        if not q.is_file():
            continue
        row['support_files'].append(str(q))
        if str(q) in support:
            continue
        item = identity(q)
        if q.suffix == '.log':
            lines = q.read_text(errors='replace').splitlines()
            item['lines'] = len(lines)
            item['pattern_counts'] = {k: sum(bool(re.search(pat, line)) for line in lines)
                                      for k, pat in patterns.items()}
            item['startup_seconds'] = [float(re.search(r'startup_sec=([0-9.]+)', line)[1])
                for line in lines if re.search(patterns['replica_startup'], line)]
        support[str(q)] = item
    row['reuse'] = 'R2_assets_and_historical_diagnostics_not_current_timing_resource_contract'
    rows.append(row)

native = BASE/'repos/S-LoRA'
diff = subprocess.check_output(['git', 'diff', '--binary'], cwd=native)
patch = BASE/'patches/S-LoRA_local_changes.patch.gz'
assert gzip.decompress(patch.read_bytes()) == diff, 'published compatibility patch differs from live source'
modified = subprocess.check_output(['git', 'diff', '--name-only'], cwd=native, text=True).splitlines()
source_paths = [native/f for f in modified]
source_paths += [native/'slora/server/api_server.py', BASE/'scripts/run_slora_fair_experiment.sh',
    BASE/'scripts/replay_openai_trace.py', BASE/'docs/UPSTREAM_REPO_STATE.md',
    BASE/'docs/EUROSYS27_V2_FORMAL_CONFIG_GATE.md', patch, Path(__file__),
    Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d420_20261011/inventory.py'),
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
    MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
    MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
result = dict(schema='ieee_tc_d425_slora_reuse_inventory_v1',
    scope='All rg-discovered results/** filenames matching *slora*replay.json and containing 7b; not an exhaustive assertion about every file on the server.',
    selector='rg --files results -g *slora*replay.json; substring 7b',
    files=len(rows), historical=rows, support_files=list(support.values()),
    log_patterns=patterns,
    pattern_caveat='No pattern matches alone do not prove no equivalent evidence exists under another name. Native source and representative complete server logs are reviewed separately.',
    upstream_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=native, text=True).strip(),
    compatibility_diff_sha256=hashlib.sha256(diff).hexdigest(), compatibility_patch_matches=True,
    source_identity=[identity(p) for p in source_paths],
    rows_with_500_actual_adapter_ids=[r['path'] for r in rows if r['actual_logical_ids'] == 500],
    decision='Retain historical observations and tested fixed-length/FIFO/assets. Do not derive native first/last or physical leases from HTTP timestamps/startup maxima. New common-contract observation path is required before current G1/G2 ranking.',
    performance_ranking_eligible=False)
OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open('x') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(json.dumps(dict(files=len(rows), support_files=len(support),
    max_actual_adapter_ids=max(r['actual_logical_ids'] for r in rows),
    full_native_length_runs=sum(r['reported_rows'] == 4000 and r['native_token_source_rows'] == 4000 and r['output_contract_match_rows'] == 4000 for r in rows),
    output=str(OUT), sha256=hashlib.sha256(OUT.read_bytes()).hexdigest())))
for r in rows:
    print(json.dumps({k:r[k] for k in ('path','reported_rows','reported_success','actual_logical_ids','native_token_source_rows','output_contract_match_rows','nonempty_server_metrics_rows')}))
