"""Seal D425's source joins and existing-test/protection receipts, no GPU."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import urllib.request

BASE = Path('/home/qhq/serverless_llm_baselines')
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(MAIN/'scripts'))
from ieee_tc_preflight import verify_seal


def ident(p):
    data = p.read_bytes()
    return dict(path=str(p), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


invpath = MAIN/'paper_results/ieee_tc/baseline_audit/d425_slora_reuse_inventory.json'
inv = json.loads(invpath.read_bytes())
allrefs = inv['historical'] + inv['support_files'] + inv['source_identity']
for r in allrefs:
    assert ident(Path(r['path'])) == {k:r[k] for k in ('path','sha256','bytes')}
native = BASE/'repos/S-LoRA'
joins = []
for r in inv['support_files']:
    if r['path'].endswith('/protocol/system_resolved_config.json'):
        config = json.loads(Path(r['path']).read_bytes())
        old = config.get('hashed_config', {}).get('systems', {}).get('S-LoRA', {}).get('upstream_worktree_identity')
        if old:
            mismatches = [f for f,v in old['dirty_tracked_files'].items()
                if ident(native/f)['sha256'] != v['content_sha256']]
            joins.append(dict(source=r['path'], commit=old['commit'],
                recorded_modified_files=len(old['dirty_tracked_files']),
                recorded_modified_file_mismatches=mismatches,
                current_only_modified_paths=sorted(set(subprocess.check_output(
                    ['git','diff','--name-only'],cwd=native,text=True).splitlines()) - set(old['dirty_tracked_files'])),
                old_full_index_diff_sha256=old['head_to_worktree_binary_diff_sha256']))

f = 'slora/server/router/model_infer/model_rpc.py'
def forward(blob):
    tree = ast.parse(blob)
    cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ModelRpcServer')
    return ast.dump(next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='forward'),include_attributes=False)
assert forward((native/f).read_bytes()) == forward(subprocess.check_output(['git','show','HEAD:'+f],cwd=native))
api = 'slora/server/api_server.py'
url = 'https://raw.githubusercontent.com/S-LoRA/S-LoRA/'+inv['upstream_commit']+'/'+api
official = urllib.request.urlopen(url, timeout=25).read()
assert official == subprocess.check_output(['git','show','HEAD:'+api],cwd=native) == (native/api).read_bytes()
protected = verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d423_20261011/protected_before.json'))
assert protected['pass'], protected
test = HERE/'fixed_length_cpu_tests.log'
assert 'Ran 9 tests' in test.read_text() and test.read_text().rstrip().endswith('OK')
result = dict(schema='ieee_tc_d425_source_reuse_evidence_v1',
    inventory=ident(invpath), verified_source_references=len(allrefs),
    historical_source_joins=joins,
    current_full_index_diff_sha256=hashlib.sha256(subprocess.check_output(
        ['git','diff','--binary','--full-index','HEAD','--'],cwd=native)).hexdigest(),
    forward_AST_equals_upstream=True, api_equals_official_and_git=True,
    official_api=dict(url=url, sha256=hashlib.sha256(official).hexdigest(),bytes=len(official)),
    source_files=[ident(HERE/'inventory.py'),ident(Path(__file__)),
        ident(BASE/'tests/test_fixed_length_generation_contract.py'),ident(test)],
    protected=protected,
    claim_scope='Deterministic byte/AST/legacy-field checks and existing CPU regressions only; not an independent semantic audit or GPU performance qualification.')
out=MAIN/'paper_results/ieee_tc/baseline_audit/d425_slora_source_evidence.json'
with out.open('x') as handle:
    json.dump(result,handle,indent=2)
    handle.write('\n')
print(json.dumps(dict(output=str(out),sha256=ident(out)['sha256'],
    verified_refs=len(allrefs),protected=protected,source_joins=joins)))
