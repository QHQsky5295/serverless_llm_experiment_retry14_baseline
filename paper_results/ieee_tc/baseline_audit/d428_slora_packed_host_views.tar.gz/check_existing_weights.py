"""D428 bounded HOST representation check, using D427's existing pool identity.

All four distinct frozen weight classes, one representative each, all layers.
No GPU, no inference, no output generation or new adapter pool. Pinning is
mocked with CPU allocation; storage equivalence is not measured pinned RSS.
"""
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

import torch
from safetensors import safe_open

HERE = Path(__file__).resolve().parent
BASE = Path('/home/qhq/serverless_llm_baselines')
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
POOL = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
INDEX = MAIN/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
MODEL = Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf/config.json')
NATIVE = BASE/'repos/S-LoRA'
VIEW = HERE/'source_view'
torch.set_num_threads(4)
assert not torch.cuda.is_initialized()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024**2), b''):
            h.update(chunk)
    return h.hexdigest()


assert digest(INDEX) == 'e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c'
manifest = json.loads((VIEW/'measurement_manifest.json').read_bytes())
assert manifest['host_layout'] == 'packed_views_v1'
for relative, expected in manifest['measured_sha256'].items():
    assert digest(VIEW/relative) == expected
assert digest(Path(manifest['helper_path'])) == manifest['helper_sha256']
sys.path.insert(0, str(VIEW))
path = 'slora/models/peft/layer_weights/lora_layer_weight.py'
original, modified = load('d428_original_layer', NATIVE/path), load('d428_modified_layer', VIEW/path)
model = json.loads(MODEL.read_bytes())
classes = {}
for row in json.loads(INDEX.read_bytes())['artifacts']:
    facts = next(f for f in row['files'] if f['path'] == 'adapter_model.safetensors')
    classes.setdefault(facts['sha256'], []).append(row)
assert len(classes) == 4
old_empty = torch.empty
allocations = []


def cpu_packed(*args, **kwargs):
    assert kwargs.pop('pin_memory') is True and kwargs['device'] == 'cpu'
    allocations.append(args[0])
    return old_empty(*args, **kwargs)


rows = []
for sha, members in sorted(classes.items()):
    item = min(members, key=lambda r: r['id'])
    aid = item['id']
    config_path, weight_path = POOL/aid/'adapter_config.json', POOL/aid/'adapter_model.safetensors'
    assert digest(weight_path) == sha
    config = json.loads(config_path.read_bytes())
    with safe_open(str(weight_path), framework='pt', device='cpu') as reader:
        weights = {k: reader.get_tensor(k) for k in reader.keys()}
    before = len(allocations)
    old_bytes = new_bytes = compared_elements = 0
    for i in range(model['num_hidden_layers']):
        old = original.LoraLayerWeight(i, 0, 1, config, model)
        new = modified.LoraLayerWeight(i, 0, 1, config, model)
        with patch.object(torch.Tensor, 'pin_memory', lambda value: value.clone()):
            old.load_hf_weights(weights, swap=True)
        with patch.object(torch, 'empty', side_effect=cpu_packed):
            new.load_hf_weights(weights, swap=True)
        assert torch.equal(old.w_combined_home, new.w_combined_home)
        assert old.w_combined_home.stride() == new.w_combined_home.stride()
        assert new.w_combined_home.is_contiguous()
        old_storage = {old.w_combined_home.untyped_storage().data_ptr(): old.w_combined_home.untyped_storage().nbytes()}
        new_storage = {new.w_combined_home.untyped_storage().data_ptr(): new.w_combined_home.untyped_storage().nbytes()}
        for side in ('A', 'B'):
            for module in ('q', 'k', 'v', 'o'):
                name = f'{module}_lora_{side}_home'
                actual, expected = getattr(new, name), getattr(old, name)
                assert actual.shape == expected.shape and torch.equal(actual, expected), (aid, i, name)
                old_storage[expected.untyped_storage().data_ptr()] = expected.untyped_storage().nbytes()
                new_storage[actual.untyped_storage().data_ptr()] = actual.untyped_storage().nbytes()
                compared_elements += actual.numel()
        assert len(old_storage) == 9 and len(new_storage) == 1
        assert sum(old_storage.values()) == 2*sum(new_storage.values())
        old_bytes += sum(old_storage.values())
        new_bytes += sum(new_storage.values())
        del old, new, actual, expected, old_storage, new_storage
    assert len(allocations)-before == model['num_hidden_layers']
    rows.append(dict(adapter_id=aid, rank=config['r'], weight_sha256=sha,
        config_sha256=digest(config_path), members_with_same_weight_sha=len(members),
        compared_layers=model['num_hidden_layers'], compared_module_elements=compared_elements,
        packed_values_and_layout_exact=True, module_values_exact=True,
        original_unique_storage_bytes=old_bytes, packed_unique_storage_bytes=new_bytes))
    del weights
    gc.collect()
assert not torch.cuda.is_initialized()
result = dict(schema='ieee_tc_d428_existing_weight_layout_equivalence_v1',
    source_index_sha256=digest(INDEX), source_view_manifest_sha256=digest(VIEW/'measurement_manifest.json'),
    recipe_sha256=digest(Path(__file__)), model_config_sha256=digest(MODEL),
    torch_version=torch.__version__, cuda_initialized=False,
    pin_memory_mocked=True, native_inference_performed=False,
    rows=rows, distinct_weight_classes_checked=len(rows), total_packed_allocations=len(allocations),
    limitations=['Not a measured pinned-memory or GPU performance experiment.',
                 'Four content representatives do not replace 500 logical-ID native execution.',
                 'BMM/TP/GQA and unqualified input modes are not supported by this representation adapter.',
                 'Actual startup/peak memory/service integration and full qualification remain open.'])
with (HERE/'existing_weights.json').open('x') as output:
    json.dump(result, output, indent=2)
print(json.dumps(result, indent=2))
