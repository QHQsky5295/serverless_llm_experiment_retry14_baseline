"""Reuse D141 qualification/evidence workflow for the opt-in stack observer."""
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal, digest

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d143_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == '30c5977836ceacf887829d0aa057a251e7c5e71d'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['systemctl','--user','show','primelora-d143-stack-verify-20261001.scope','-p','ActiveState','--value'],text=True).strip() == 'inactive'
assert 'Ran 337 tests in 78.572s\n\nOK\n' in (raw/'test.log').read_text()
assert 'Exit status: 0' in (raw/'test_time.txt').read_text()
subprocess.run(['sha256sum','-c',str(raw/'test_sources.sha256')],check=True)
cleanup = (raw/'test_cleanup.txt').read_text()
assert 'InvocationID=08c360e12fe942b38625079fdee6e295' in cleanup and 'TasksCurrent=0' in cleanup
events = {r.split()[0]:int(r.split()[1]) for r in cleanup.splitlines()
          if r.startswith(('low ', 'high ', 'max ', 'oom ', 'oom_kill ', 'oom_group_kill '))}
assert len(events) == 6 and not any(events.values())
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
files = [root/p for p in ('faaslora/__init__.py','faaslora/utils/logger.py',
    'tests/test_ieee_tc_stack_diagnostic.py','docs/ieee_tc/D143_COOPERATIVE_DIAGNOSTIC.md')]
files += [raw/name for name in ('test.log','test_time.txt','test_scope.txt','test_sources.sha256',
    'test_cleanup.txt','test_launcher.log','verify_stack_diagnostic.sh','curate_qualification.py')]
import_cleanup=(raw/'import_cleanup.txt').read_text()
assert 'InvocationID=440515eefb8641a3aa9fd62872e69261' in import_cleanup
assert 'TasksCurrent=0' in import_cleanup
import_events={r.split()[0]:int(r.split()[1]) for r in import_cleanup.splitlines()
    if r.startswith(('low ', 'high ', 'max ', 'oom ', 'oom_kill ', 'oom_group_kill '))}
assert len(import_events)==6 and not any(import_events.values())
assert subprocess.check_output(['systemctl','--user','show','primelora-d143-import-probe-20261001.scope','-p','ActiveState','--value'],text=True).strip()=='inactive'
assert [json.loads(row) for row in (raw/'import_pair.log').read_text().splitlines()]==[
    dict(flag='0',python_returncode=0),dict(flag='python_frames_v1',python_returncode=0)]
for flag in ('0','python_frames_v1'):
    log=(raw/f'import_probe_{flag}.log').read_text()
    assert 'IMPORT_COMPLETE' in log and 'Traceback' not in log and 'Exception' not in log
assert 'Exit status: 0' in (raw/'import_time.txt').read_text()
subprocess.run(['sha256sum','-c',str(raw/'import_sources.sha256')],check=True)
stack_root=raw/'import_probe_python_frames_v1/diagnostic_stacks'
meta_files=list(stack_root.glob('*.json'))
assert len(meta_files)==1
meta=json.loads(meta_files[0].read_text())
stack_file=meta_files[0].with_suffix('.stacks.jsonl')
payload=stack_file.read_bytes()
assert payload.endswith(b'\n') and len(payload)<1024**2
samples=[json.loads(row) for row in payload.splitlines()]
assert samples
previous_time=meta['capture_start_monotonic_s']
previous_cpu=0.0
previous_observer=0.0
for index,row in enumerate(samples,1):
    assert row['index']==index and row['pid']==meta['pid']
    for field in ('scheduled_monotonic_s','observed_monotonic_s','interval_seconds',
            'scheduler_delay_seconds','process_cpu_seconds','process_cpu_delta_seconds',
            'observer_cpu_seconds_before_sample','snapshot_wall_seconds'):
        assert type(row[field]) in (int,float) and math.isfinite(row[field]) and row[field]>=0,field
    assert row['observed_monotonic_s']>previous_time
    assert row['process_cpu_seconds']>=previous_cpu
    assert row['observer_cpu_seconds_before_sample']>=previous_observer
    assert row['interval_seconds']>=2.0
    identities=[t['ident'] for t in row['threads']]
    assert len(identities)==len(set(identities))
    assert meta['main_thread_ident'] in identities and row['observer_thread_ident'] in identities
    for thread in row['threads']:
        assert type(thread['truncated']) is bool and len(thread['frames'])<=100
        for filename,function,line in thread['frames']:
            assert isinstance(filename,str) and isinstance(function,str) and type(line) is int
    previous_time=row['observed_monotonic_s']
    previous_cpu=row['process_cpu_seconds']
    previous_observer=row['observer_cpu_seconds_before_sample']
import_observation=dict(native_pair_returncodes=[0,0],sample_count=len(samples),
    bytes=len(payload),complete_lines=True,
    max_interval_s=max(r['interval_seconds'] for r in samples),
    max_scheduler_delay_s=max(r['scheduler_delay_seconds'] for r in samples),
    observer_cpu_before_last_sample_s=samples[-1]['observer_cpu_seconds_before_sample'],
    observer_cpu_excludes_last_sample=True,complete_main_thread_coverage=True,
    gil_scheduling_bias=True,performance_overhead_measured=False)
files += [raw/name for name in ('import_cleanup.txt','import_launcher.log','import_pair.log',
    'import_probe_0.log','import_probe_python_frames_v1.log','import_scope.txt',
    'import_sources.sha256','import_time.txt','probe_import.py','run_import_probe.sh')]
files += meta_files+[stack_file]
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for p in files:
    assert p.stat().st_size < 2*1024**2
    data = p.read_bytes()
    assert secret not in data
    assert not any(r.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in r for r in data.splitlines())
    if p.suffix == '.py': compile(data, str(p), 'exec')
    if p.suffix == '.sh': subprocess.run(['bash','-n',str(p)],check=True)
for p in raw.glob('*.sh'): subprocess.run(['bash','-n',str(p)],check=True)
compile((raw/'verify_prefix1_prelaunch.py').read_bytes(),'verify_prefix1_prelaunch.py','exec')
result = dict(kind='d143_stack_observer_cpu_qualification_v1',
    parent_commit='30c5977836ceacf887829d0aa057a251e7c5e71d',
    decision='opt_in_diagnostic_cpu_qualified_gpu_observation_pending',
    tests=337,test_seconds=78.572,formal_performance_result=False,cuda_executed=False,
    cpu_time_profile=False,measured_observer_overhead=None,
    protected=protected,cleanup_memory_events=events,import_memory_events=import_events,
    import_observation=import_observation,
    serving_policy_change=False,source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
curated=out/'20261001_d143_stack_qualification.json'
with curated.open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
files.append(curated)
bundle=out/'20261001_d143_stack_qualification_sources.tar.gz'
with bundle.open('xb') as f:
    with tarfile.open(fileobj=f,mode='w:gz') as archive:
        for p in files: archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(files)
    for member,p in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==digest(p)
with (out/'20261001_d143_stack_qualification_sources.sha256').open('x') as f:
    f.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,tests=337)))
