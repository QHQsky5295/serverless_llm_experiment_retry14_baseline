"""Bounded 3B asset/profile audit and unchanged-case migration specification."""
import collections
import json
import os
from pathlib import Path
import subprocess
import sys
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

refs = {}
def bound(path, expected=None):
    path = Path(path)
    value = p.digest(path)
    assert expected is None or value == expected, str(path)
    refs[str(path)] = value
    return path
def read(path):
    return json.loads(bound(path).read_text())
def save(name, value):
    with (RAW/name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save('analysis_identity.json', identity)
cg = Path(identity['path'])
assert (cg/'memory.high').read_text().strip() == str(3*p.GIB)
assert (cg/'memory.max').read_text().strip() == str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
gate = p.preflight([ROOT], 64*1024*1024)
save('preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
bound('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md',
      'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83')
bound(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
      '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22')
bound(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
      '193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d')
bound(ROOT/'configs/generated/lora_manifest_1000.json',
      '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df')
index_path = bound(ROOT/'paper_results/ieee_tc/inputs/20260927_3b_remote_content_index.json',
                   'bd1826c58f00ea30dee1d3829dc11727a975127db701a1eee6c6c86b4a38f275')
index = read(index_path)
pool = Path(index['provenance']['pool_root']).resolve(strict=True)
ranks = collections.Counter()
weight_hashes = collections.Counter()
config_checks = []
assert len(index['artifacts']) == 500
for artifact in index['artifacts']:
    aid = artifact['id']
    directory = (pool/aid).resolve(strict=True)
    assert directory.parent == pool
    files = {f['path']:f for f in artifact['files']}
    config_path = bound(directory/'adapter_config.json', files['adapter_config.json']['sha256'])
    config = json.loads(config_path.read_text())
    rank = config['r']
    assert type(rank) is int and rank > 0
    ranks[rank] += 1
    weights = files['adapter_model.safetensors']
    assert (directory/'adapter_model.safetensors').stat().st_size == weights['size_bytes']
    weight_hashes[weights['sha256']] += 1
    config_checks.append(dict(adapter_id=aid, rank=rank, config_sha256=refs[str(config_path)],
        indexed_weights_sha256=weights['sha256'], indexed_weights_bytes=weights['size_bytes']))
assert dict(ranks) == {8:350, 16:150}
save('adapter_config_checks.json', config_checks)
trace = bound('/home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260509_134259_llama32_3b_main_s8/shared_artifacts/llama32_3b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json',
              '4ea5d026da3820301e753ad6b03ea776e25a5c3f01921933bd124598eb26018d')
subset = bound(Path(str(trace).replace('_trace.json', '_adapter_subset.json')))
old_summary = read(ROOT/'paper_results/ieee_tc/p2_backend/20261001_d138_3b_full_w0_full1.json')
old_cfg = yaml.safe_load(bound(RAW.parent/'d138_20261001/3b_main_config_full1.yaml').read_text())
initial = read(ROOT/'paper_results/ieee_tc/p2_backend/d89_3b_initialization/manifest.json')
for name in ('service','preparation'):
    bound(ROOT/f'paper_results/ieee_tc/p2_backend/d89_3b_initialization/{name}.json',
          initial['profiles'][name]['profile_sha256'])
spec_path = bound(ROOT/'paper_results/ieee_tc/p2_backend/20260927_d88_3b_admission_source_spec.json')
spec = read(spec_path)
assert spec['trace_sha256'] == refs[str(trace)] and len(spec['representatives']) == 24
assert spec['model_overrides']['ieee_native_host_workspace'] == old_cfg['model']['ieee_native_host_workspace']
candidate_path = bound(ROOT/'configs/ieee_tc/20261017_d641_3b_native_source.yaml')
candidate = yaml.safe_load(candidate_path.read_text())['model_profiles']['llama32_3b_main_modelscope']['model']
assert candidate['max_lora_rank'] == max(ranks)
assert all(candidate[k] == old_cfg['model'][k] for k in ('max_loras','max_num_seqs',
    'runtime_concurrency_cap','max_num_batched_tokens','gpu_memory_utilization','max_model_len'))
# Index transformation only: no new requests, adapter payload, sampling or timing.
fresh = json.loads(json.dumps(spec))
removed = {key:fresh.pop(key) for key in ('admission_initialization','full_development_contract')}
fresh['nvme_parent'] = str(RAW.parent/'d641_20261017')
fresh['purpose'] = 'Current 3B native source qualification; not Full/admission timing export'
fresh['derivation'] = 'D640: identical D88 representative requests, waves, bins and budgets; fresh current native timings. Rank16 matches the existing 500-ID pool. No stale Full/admission binding.'
assert all(fresh[k] == spec[k] for k in ('waves','bins','rounds','representatives',
    'trace_sha256','content_index','movement_concurrency','model_overrides'))
save('source_spec.json', fresh)
history = subprocess.check_output(['git','log','--format=%H %s',old_summary['execution_commit']+'..HEAD','--',
    'faaslora/experiment','faaslora/serving','faaslora/scheduling','faaslora/memory',
    'scripts/run_all_experiments.py'],cwd=ROOT,text=True)
save('implementation_history.json', dict(source_commit=old_summary['execution_commit'],
    current_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    entries=history.splitlines()))
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
summary = dict(kind='d640_3b_asset_profile_migration_audit_v1',passed=True,no_gpu_run=True,
    no_production_change=True,new_weights=0,new_full_traces=0,static_configs_verified=500,
    ranks=dict(ranks),indexed_distinct_weight_sha256=len(weight_hashes),
    weight_bytes_rehashed=False,weight_integrity_boundary='frozen content-index SHA and current sizes; native loading validation pending',
    trace=dict(path=str(trace),sha256=refs[str(trace)],subset_path=str(subset),subset_sha256=refs[str(subset)]),
    old_execution_commit=old_summary['execution_commit'],old_population=old_summary['population'],
    old_latency_ms=old_summary['conditional_success_latency_ms'],old_physical=old_summary['physical'],
    old_profile=dict(profiles=initial['profiles'],coverage={k:initial['coverage'][k] for k in
        ('static_adapter_count','exact_file_content_classes','rank_counts','class_domain_covered')},
        slot_capacity_bytes=initial['activation_geometry']['slot_capacity_bytes']),
    migration_candidate=candidate,source_spec_sha256=p.digest(RAW/'source_spec.json'),
    unchanged_case_count=sum(len(w['requests']) for w in fresh['waves']),
    unchanged_waves=len(fresh['waves']),removed_stale_bindings=removed,
    compatibility='R2 for old timings and Full results; same input/assets reusable; no inherited formal SLO or resource qualification',
    current_3b_common_warm_reference='not located in curated inventory',
    current_3b_resident_reference='not located in curated inventory',
    next='One fresh native source qualification, then derive measured admission/profile evidence, common 3B warm reference and current Full diagnostic. No 7B threshold substitution.',
    protected=protected,refs=refs,scope=identity)
save('qualification.json',summary)
print(json.dumps({k:summary[k] for k in ('passed','static_configs_verified','ranks',
    'indexed_distinct_weight_sha256','unchanged_case_count','unchanged_waves','compatibility')}))
