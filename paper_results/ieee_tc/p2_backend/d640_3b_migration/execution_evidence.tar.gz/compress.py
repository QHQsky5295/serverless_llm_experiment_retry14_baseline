"""Explicit two closed main-outcomes only, retaining successful/failed identity."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name)
with (RAW/'qualification_identity.json').open('x') as f:json.dump(identity,f,indent=2)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
audit=json.loads((RAW/'qualification.json').read_text());assert audit['passed']
closed=json.loads((RAW/'analysis_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
args=[sys.executable,str(ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py'),
    '--closed-run','d634_20261017/7b_min2_full_w0',
    '--closed-run','d636_20261017/7b_min2_full_w0','--allow-closed-failure',
    '--receipt',str(ROOT/'paper_results/ieee_tc/storage/20261017_d640_closed_outcomes.json')]
subprocess.run(args,check=True,cwd=ROOT)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
with (RAW/'storage_verification.json').open('x') as f:json.dump(dict(passed=True,protected=protected,
    compressor_sha256=p.digest(ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py')),f,indent=2)
