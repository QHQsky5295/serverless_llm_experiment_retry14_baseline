"""Exercise existing native source input resolver, without CUDA/network/model load."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name)
with (RAW/'analysis2_identity.json').open('x') as f:json.dump(identity,f,indent=2)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
audit=json.loads((RAW/'qualification.json').read_text())
for path,sha in audit['refs'].items():assert p.digest(Path(path))==sha
from faaslora.datasets.workload_generator import FrozenReplayPlan
config=ROOT/'configs/ieee_tc/20261017_d641_3b_native_source.yaml'
source=yaml.safe_load(config.read_text())['model_profiles']['llama32_3b_main_modelscope']
cfg=dict(source['model'])
cfg.update(visible_device_ids=[0],device_id=0,timing_contract='ieee_tc_native_v1',
    ieee_worker_observation=True,ieee_gpu_references=True,ieee_scheduler_observation=True,
    ieee_input_upper_bounds=[759],generation_contract='fixed_length_greedy_v1',
    canonical_prompt_renderer='role_lines_v1',max_input_len=759,max_output_tokens_cap=256,
    ieee_physical_allocation=True)
plan=FrozenReplayPlan.load(Path(audit['trace']['path']),count=1000)
spec,bins,identities,waves,index=p.source_profile_inputs(RAW/'source_spec.json',plan,cfg,
    Path(source['storage']['remote_dir']).resolve(strict=True))
assert len(identities)==24 and len(waves)==46 and sum(map(len,waves))==368
assert not ({'admission_initialization','full_development_contract'} & spec.keys())
assert cfg['max_lora_rank']==max(map(int,audit['ranks']))
shell=ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh'
subprocess.run(['bash','-n',str(shell)],check=True)
assert 'MODEL_PROFILE=llama32_3b_main_modelscope' in shell.read_text()
for name in ('analyze.py','compress.py','close.py','validate_inputs.py'):
    ast.parse((RAW/name).read_text())
with (RAW/'input_qualification.json').open('x') as f:
    json.dump(dict(passed=True,native_source_input_resolver_pass=True,model_config=cfg,
        trace_identity=plan.identity(),identity_count=len(identities),wave_count=len(waves),
        request_cases=sum(map(len,waves)),config_sha256=p.digest(config),
        source_spec_sha256=p.digest(RAW/'source_spec.json'),runner_sha256=p.digest(shell),
        no_cuda_model_load=True,no_http_request=True,scope=identity),f,indent=2)
print(json.dumps(dict(passed=True,identities=len(identities),waves=len(waves),cases=sum(map(len,waves)))))
