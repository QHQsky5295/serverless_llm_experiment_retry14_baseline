"""Reuse explicit-file backup with D640 input checks and storage receipts."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d640_3b_migration'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'",
        "=='f62db6e4ff582e203908290bf89a32d067c4c51a'")
begin=code.index('reg=read(RAW/')
end=code.index('preserved={',begin)
code=code[:begin]+'''audit=read(RAW/'qualification.json')
inputs=read(RAW/'input_qualification.json')
assert audit['passed'] and inputs['passed'] and inputs['request_cases']==368
for path,sha in audit['refs'].items():assert p.digest(Path(path))==sha
assert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==inputs['runner_sha256']
for phase in ('analysis','analysis2','qualification'):
    close=read(RAW/(phase+'_closure.json'))
    assert close['passed'] and close['actual_recursive_procs_empty'] and close['path_gone']
    assert not Path(close['identity']['path']).exists()
storage=ROOT/'paper_results/ieee_tc/storage/20261017_d640_closed_outcomes.json'
storage_data=read(storage)
assert len(storage_data['entries'])==2 and read(RAW/'storage_verification.json')['passed']
for row in storage_data['entries']:
    assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']
    assert p.digest(Path(row['archive']))==row['archive_sha256']
    assert not Path(row['source']).exists()
gate=p.preflight([ROOT],32*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
''' +code[end:]
begin=code.index('members=[RAW/name')
end=code.index('\nfor path in members:',begin)
code=code[:begin]+'''members=[RAW/name for name in ('analyze.py','validate_inputs.py','compress.py','close.py','backup.py',
    'qualification.json','input_qualification.json','adapter_config_checks.json','implementation_history.json','source_spec.json',
    'analysis_identity.json','analysis_closure.json','analysis2_identity.json','analysis2_closure.json',
    'qualification_identity.json','qualification_closure.json','storage_verification.json','preflight.json','backup_gate.json')]
members += [storage,ROOT/'docs/ieee_tc/D640_3B_MIGRATION_AND_PROFILE_AUDIT.md',
    ROOT/'configs/ieee_tc/20261017_d641_3b_native_source.yaml',ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh']
assert len({path.name for path in members})==len(members)
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
''' +code[end:]
begin=code.index('test_counts={')
end=code.index("save(OUT/'qualification.json'",begin)
code=code[:begin]+'''test_counts={'static_adapter_configs':500,'source_identities':24,'source_cases':368}
record=dict(passed=True,production_candidate=False,native_gpu_validation=False,full_performance_run=False,
    parent_commit='f62db6e4ff582e203908290bf89a32d067c4c51a',audit=audit,inputs=inputs,
    storage=storage_data,protected=protected,preserved={str(k):v for k,v in preserved.items()},
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='Current 3B source-only qualification prepared; old timings R2. No new GPU performance or complete independent audit.')
with (OUT/'source_spec.json').open('x') as f:f.write((RAW/'source_spec.json').read_text())
assert p.digest(OUT/'source_spec.json')==audit['source_spec_sha256']
''' +code[end:]
code=code.replace("('qualification.json','execution_evidence.tar.gz')",
                  "('qualification.json','execution_evidence.tar.gz','source_spec.json')")
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D640_3B_MIGRATION_AND_PROFILE_AUDIT.md',\n    'configs/ieee_tc/20261017_d641_3b_native_source.yaml','scripts/ieee_tc/run_d298_capacity_source.sh',\n    str(storage.relative_to(ROOT)),str((OUT/'source_spec.json').relative_to(ROOT))]")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: audit existing 3B assets and prepare current native source qualification (D640)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
