import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

out = Path(__file__).resolve().parent
prelaunch_scope = json.loads((out/'prelaunch1.log').read_text().splitlines()[-1])['scope']
assert p.scope_still_owned(prelaunch_scope)
group = Path(prelaunch_scope['path'])
assert not p.owned_pids(group)
scope_resources = {key: (group/key).read_text() for key in
    ['memory.high','memory.max','memory.peak','memory.events','memory.swap.current','memory.swap.max']}
subprocess.run(['systemctl','--user','stop',prelaunch_scope['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',prelaunch_scope['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (out/'prelaunch_cleanup.json').open('x') as f:
    json.dump(dict(identity=prelaunch_scope,resources=scope_resources,inactive=True),f,indent=2)
previous = json.loads((out/'prelaunch_binding.json').read_text())
smoke_root = p.ROOT/'paper_results/ieee_tc/p2_backend/d334_native_pending_validation'
smoke = json.loads((smoke_root/'smoke1/audit.json').read_text())
assert smoke['stats']['completed'] == 100
assert smoke['native_pending_turn_trigger']['combined_successful_requests'] == 45
assert not smoke['full_qualified'] and not smoke['common_slo_qualified']
prior = json.loads((out.parent/'d334_20261008/prelaunch_binding.json').read_text())
for ref in prior['source_references']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
assert subprocess.check_output(['git','-C',str(p.ROOT),'diff','--name-only',
    'e0b1060d906ee401bba5468c4330d6cb0b114c43','--','faaslora','scripts','configs/ieee_tc'],text=True).strip() == ''

for ref in previous['source_references']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
head = subprocess.check_output(['git', '-C', str(p.ROOT), 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'e0b1060d906ee401bba5468c4330d6cb0b114c43'
remote = subprocess.check_output(['git', '-C', str(p.ROOT), 'ls-remote', 'faaslora_origin', 'refs/heads/retry14_continuous_queue_v2'], text=True).split()[0]
assert remote == head
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(p.ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(p.ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
seal = p.verify_seal(p.ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count'] == 147 and seal['changed'] == [str(known)]
assert p.digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'],text=True).strip()
assert not (out/'7b_full_w0').exists()
gate = p.preflight([p.ROOT], 32*p.GIB)
assert gate['preflight_pass'], gate['issues']
receipt = dict(kind='d335_launch_gate_v1', passed=True, source_head=head, remote_head=remote,
    prelaunch_receipt_sha256=p.digest(out/'prelaunch_binding.json'),
    diagnostic_prefix_count=None, source_requests=4000, observer='none',
    preflight=gate, protection=seal)
with (out/'launch_gate1.json').open('x') as f:
    json.dump(receipt, f, indent=2, allow_nan=False)
print(json.dumps(dict(passed=True, head=head, disk=gate['filesystems'][0]['free_bytes'], memory=gate['memory']['MemAvailable'])))
