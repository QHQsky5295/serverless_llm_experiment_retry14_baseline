"""Reuse D824 explicit-path backup; no production changes in D837."""
import hashlib
from pathlib import Path

template = Path(__file__).resolve().parent.parent/'d824_20261025/backup.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == 'ee84b28423f93cea5a6764c529174b4531ad1bcf7c38ee4e1d37c95bc0b951c8'
source = template.read_text()
for old, new in (
    ('d824_current_ingress_pending', 'd837_gzip_extraction'),
    ('107185c45f49a891c0b391b1140b7d765e83daea', '99d344e4b78eb61fada70d25b2f6537abec177a1'),
    ("OUT/'final_manifest.json'", "OUT/'manifest.json'"),
    ('D824_CURRENT_INGRESS_AND_CONTROL_20261025.md', 'D837_GZIP_EXTRACTION_PROFILE_20261025.md'),
    ('len(set(paths)) == 20', 'len(set(paths)) == 6'),
    ('backup/d824-current-ingress-control-20261025', 'backup/d837-gzip-extraction-20261025'),
    ('tc: preserve current 3B ingress and actual scaling-trigger diagnosis (D824)',
     'tc: retain gzip extraction evidence and reject direct stream mode (D837)'),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'), globals())
