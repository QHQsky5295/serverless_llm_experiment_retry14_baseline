"""Bind the actual interval ledger through the retained envelope's explicit SHA."""
import ast
from pathlib import Path
source=Path(__file__).resolve().with_name('diagnose.py')
code=source.read_text()
before="    physical=read(physical_path)\n    assert closed_physical_integral(physical)==audit['stats']['physical_gpu_seconds']"
assert code.count(before)==1
code=code.replace(before,"""    envelope=read(physical_path)
    ledger=Path(envelope['summary_path'])
    assert ledger==physical_dir/'summary.json'
    assert p.digest(ledger)==envelope['summary_sha256']
    assert p.digest(terminal_path)==envelope['request_terminals_sha256']
    ref(ledger)
    physical=read(ledger)
    assert closed_physical_integral(physical)==audit['stats']['physical_gpu_seconds']""")
for name in ('identity','resource_gate','receipt'):
    old="RAW/'analysis_"+name+".json'"
    assert code.count(old)==1
    code=code.replace(old,"RAW/'analysis2_"+name+".json'")
ast.parse(code)
exec(compile(code,str(source),'exec'))
