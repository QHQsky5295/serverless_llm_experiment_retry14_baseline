"""Reuse the verified explicit-path D612 publication with D630 bindings."""
import ast
import hashlib
from pathlib import Path

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/publish.py')
assert hashlib.sha256(source.read_bytes()).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=source.read_text()
changes={
    'd612_w2_quality_resource_diagnosis':'d630_w2_gate_capacity_diagnosis',
    'f72091155cd3bb258651fc461db11b9113c72faf':'ac5ab5751de32650add8eb70e846535e3c89abf1',
    "for name in ('analysis',):":"for name in ('analysis','analysis2'):",
    "RAW/'analysis_receipt.json'":"RAW/'analysis2_receipt.json'",
    "diagnosis['runs']['D607']['all']['joint']==3762":"diagnosis['runs']['D621']['all']['joint']==3798",
    "diagnosis['runs']['D611']['all']['joint']==3819":"diagnosis['runs']['D629']['all']['joint']==3727",
    "assert not any('host_memory_below_stop' in x or 'filesystem_below_stop' in x for x in gate['issues'])":"assert gate['preflight_pass'],gate['issues']",
    'D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md':'D630_W2_GATE_CAPACITY_DIAGNOSIS.md',
    "RAW.parent/'d607_20261017/publish_result.py'":"RAW.parent/'d612_20261017/publish.py'",
    'd612_reused_parent_closed_log_diagnosis_v1':'d630_retained_w2_gate_capacity_diagnosis_v1',
    'tc: preserve post-SLO resource gap diagnosis without another replay (D612)':'tc: preserve W2 activation-capacity diagnosis and next resource hypothesis (D630)',
}
for old,new in changes.items():
    assert code.count(old)==1,old
    code=code.replace(old,new)
ast.parse(code)
exec(compile(code,str(source),'exec'))
