"""D630: bind closed W2 sources to existing D342 gate/capacity analyzers.

No serving, synthetic timeline, new estimator, threshold change, or figure.
Use bounded streaming projections, not copies of weights or full raw results.
"""
import collections
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
from statistics import fmean
import subprocess
import sys
import ijson

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import (
    summarize_dispatch_gate_intervals, summarize_dispatch_capacity_context)
from scripts.ieee_tc.check_d299_full_context import closed_physical_integral

def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def actual(path):
    if path.is_file():return path
    compressed=path.with_suffix(path.suffix+'.gz')
    assert compressed.is_file(),path
    return compressed
def opened(path):return gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')

refs=[]
def ref(path,original=None):
    row=dict(path=str(path),sha256=p.digest(path))
    if original is not None:
        digest=hashlib.sha256()
        with opened(path) as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
        assert digest.hexdigest()==original,path
        row['uncompressed_sha256']=original
    refs.append(row)

identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'analysis_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],64*1024*1024)
save(RAW/'analysis_resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
for path,sha in {
    ROOT/'scripts/analyze_control_path_overhead.py':'6ebc923d59cbc3a44e51363d8461dab70bf1a9ea2c3d994072e6397cf1018fd7',
    ROOT/'scripts/ieee_tc/check_d299_full_context.py':'b8a71f5ac405e705e003b9998cf036a8a520b87306929c3c2851e81588927992',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
}.items():assert p.digest(path)==sha;ref(path)
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
ref(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'));ref(Path(__file__))

fields=('request_id','instance_id','success','scheduled_arrival_offset_s',
    'arrival_released_offset_s','admission_start_offset_s','dispatch_window_wait_ms',
    'admitted_offset_s','runtime_slot_wait_ms','arrival_release_lateness_ms',
    'dispatch_admission_wait_ms','native_token_timing','adapter_id','canonical_prompt_sha256',
    'requested_completion_tokens','generation_contract','completion_token_source',
    'overall_ttft_ms','completion_token_ids_sha256')
runs={};contracts={};outputs={}
for name,tag,published in (
    ('D621','7b_device_domain_full_w2','d621_device_domain_full_w2'),
    ('D629','7b_private_verify_full_w2','d629_private_verify_full_w2')):
    folder=RAW.parent/(name.lower()+'_20261017');run=folder/tag
    summary_path=ROOT/'paper_results/ieee_tc/p2_backend'/published/'result1/summary.json'
    summary=read(summary_path);audit=read(folder/'actual_qualification.json')
    assert summary['passed'] and summary['audit']==audit and audit['passed']
    assert audit['fixed_workload_complete4000'] and audit['stats']['n_correct'] is None
    ref(summary_path);ref(folder/'actual_qualification.json')
    for phase in ('analysis','publication2' if name=='D629' else 'publication'):
        closed_path=folder/(phase+'_closure.json');closed=read(closed_path)
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists();ref(closed_path)
    cleanup=read(folder/'local_cleanup.json')
    assert cleanup['passed'] and not Path(cleanup['service_identity']['path']).exists()
    assert not Path(cleanup['auxiliary_identity']['path']).exists()
    assert read(folder/'remote_stop.json')['all_owned_units_inactive']
    source=actual(Path(audit['evidence']['source']))
    ref(source,audit['evidence']['source_sha256'])
    requests=[]
    with opened(source) as stream:
        for request in ijson.items(stream,'detailed_results.tc_ieee_full.requests.item',use_float=True):
            requests.append({key:request[key] for key in fields})
    assert len(requests)==4000
    contracts[name]={r['request_id']:tuple(r[key] for key in (
        'adapter_id','scheduled_arrival_offset_s','canonical_prompt_sha256',
        'requested_completion_tokens','generation_contract','completion_token_source')) for r in requests}
    outputs[name]={r['request_id']:r['completion_token_ids_sha256'] for r in requests}
    physical_dir=run/'launch.launch/physical_deployment'
    deployment_path=physical_dir/'deployment.json';deployment=read(deployment_path)
    assert deployment['plan']==audit['workload_identity']
    terminal_path=actual(physical_dir/'request_terminals.jsonl')
    with opened(terminal_path) as stream:terminals=[json.loads(line) for line in stream]
    outcome=actual(physical_dir/'main_outcome.json')
    source_hashes={r['path']:r['sha256'] for r in audit['refs']}
    ref(outcome,source_hashes[str(physical_dir/'main_outcome.json')])
    with opened(outcome) as stream:
        activations=list(ijson.items(stream,'mechanism_events._ieee_activations.item',use_float=True))
    with opened(outcome) as stream:
        control=list(ijson.items(stream,'mechanism_events._ieee_control_events.item',use_float=True))
    assert all(a['state']=='runtime_ready' for a in activations)
    split=summarize_dispatch_gate_intervals(requests,deployment,terminals,activations)
    rows=split.pop('rows')
    assert abs(split['metrics']['acquire_to_resume_ms']['mean']-audit['stage_means_ms']['acquire_to_resume_ms'])<1e-6
    start=deployment['arrival_start_s']
    samples=[dict(offset_s=e['observed_at']-start,queue=e['queue_depth'],
        active=e['active_requests'],capacity=e['ready_capacity'],pending=e['pending_instances'],
        ready_instances=e['ready_instances'],action=e['action'],outcome=e['outcome'])
        for e in control if e['observed_at']>=start and e['ready_capacity']>0]
    assert all(c['capacity']==14*c['ready_instances'] for c in samples)
    context=summarize_dispatch_capacity_context(rows,samples)
    capacity_rows=context.pop('rows')
    context['peak_wait_sample']=max(capacity_rows,key=lambda row:row['acquire_not_yet_resumed'])
    context['excluded_before_arrival_or_zero_ready_samples']=len(control)-len(samples)
    index={e['request_id']:i for i,e in enumerate(terminals)}
    # Terminal order differs from offered order: use canonical request IDs only
    # to locate their frozen source positions, not completion order.
    from faaslora.datasets.workload_generator import FrozenReplayPlan
    wi=audit['workload_identity']
    plan=FrozenReplayPlan.load(wi['source_path'],count=4000,profile='W2',
        adapter_map=wi['adapter_map'],adapter_map_sha256=wi['adapter_map_sha256'])
    assert plan.identity()==wi
    index={entry.request_id:i for i,entry in enumerate(plan.entries)}
    by_request={r['request_id']:r for r in requests}
    for row in rows:
        row['source_index']=index[row['request_id']]
        row['ttft_ms']=by_request[row['request_id']]['overall_ttft_ms']
    windows=[]
    for i in range(8):
        selected=[r for r in rows if i*500<=r['source_index']<(i+1)*500]
        assert len(selected)==500
        windows.append(dict(source_first=i*500+1,source_last=(i+1)*500,
            mean_acquire_to_resume_ms=fmean(r['acquire_to_resume_ms'] for r in selected),
            mean_pre_acquire_ms=fmean(r['pre_acquire_ms'] for r in selected),
            mean_ttft_ms=fmean(r['ttft_ms'] for r in selected)))
    physical_path=Path(audit['evidence']['physical_source']);ref(physical_path)
    assert p.digest(physical_path)==audit['evidence']['physical_sha256']
    physical=read(physical_path)
    assert closed_physical_integral(physical)==audit['stats']['physical_gpu_seconds']
    end=start+plan.entries[-1].offset_s
    events=collections.defaultdict(int);events[start]+=0;events[end]+=0
    for spans in physical['device_intervals'].values():
        for a,b in spans:
            a,b=max(a,start),min(b,end)
            if b>a:events[a]+=1;events[b]-=1
    count=0;previous=start;hist=collections.defaultdict(float)
    for at,delta in sorted(events.items()):
        hist[count]+=at-previous;count+=delta;previous=at
        assert 0<=count<=4
    assert count==0
    assert abs(sum(k*v for k,v in hist.items())-physical['window_gpu_seconds']['arrival'])<1e-6
    save(RAW/(name.lower()+'_gate_rows.json'),rows)
    save(RAW/(name.lower()+'_capacity_samples.json'),capacity_rows)
    save(RAW/(name.lower()+'_activations.json'),activations)
    runs[name]=dict(all=dict(joint=audit['common_threshold_joint_count']),stats=audit['stats'],
        split=split,capacity_context=context,reporting_windows_500=windows,
        longest_wait=max(rows,key=lambda row:row['acquire_to_resume_ms']),
        control_changes=[dict(e,offset_s=e['observed_at']-start) for e in control if e['action']!='no_action'],
        activations=[dict(category=a['category'],trigger_s=a['trigger_at']-start,
            ready_s=a['engine_ready_at']-start) for a in activations],
        physical_held_count_seconds_in_arrival=dict(sorted(hist.items())),
        hypothetical_additional_device_time_for_floor2_on_fixed_observed_timeline=sum(max(2-k,0)*v for k,v in hist.items()),
        floor_caveat='Descriptive fixed-timeline occupancy gap only; not a min2 counterfactual, predicted resource cost, or SLO estimate.')
    for path in (deployment_path,terminal_path,folder/'local_cleanup.json',folder/'remote_stop.json'):ref(path)
    print(json.dumps(dict(run=name,split=split['metrics'],capacity=context,held_seconds=dict(hist))),flush=True)
assert contracts['D621']==contracts['D629'] and len(contracts['D621'])==4000
changed=sum(outputs['D621'][rid]!=outputs['D629'][rid] for rid in outputs['D621'])
assert changed==125
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
save(RAW/'diagnosis.json',dict(passed=True,kind='d630_retained_w2_gate_capacity_diagnosis_v1',
    runs=runs,matched_transitions={'same_contract':dict(n=4000)},same_backend_output_hash_changes=changed,
    n_correct=None,ranking_eligible=False,inference_runs_added=0,confidence_interval=None,
    source_refs=refs,protected=protected,
    caveats=['Capacity coverage is at recorded samples, not exact grant/release reconstruction.',
        'Acquire-to-resume includes capacity and wakeup delay; uncovered samples are not proof of free capacity.',
        'Activation overlap is not causal time and is never subtracted from end-to-end latency.',
        'One known-workload observation per implementation; no repeated or independent held-out runs.',
        'Numerical differences remain unexplained; native identity and count are not an arithmetic oracle.']))
save(RAW/'analysis_receipt.json',dict(passed=True,identity=identity,protected=protected,
    diagnosis_sha256=p.digest(RAW/'diagnosis.json'),source_refs=refs,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,matched_requests=4000,output_changes=changed)),flush=True)
