#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d175_20261002
unit=primelora-d175-full1-evidence2-20261002.scope
{
  date -Is
  rg -qx 'InvocationID=1885992d4838428292617a8d7e26389e' "$raw/full_full1_evidence2_scope.txt"
  jq -e '.pass_checks == true' paper_results/ieee_tc/p2_backend/20261002_d175_evidence_verification.json
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=1885992d4838428292617a8d7e26389e\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=all_zero_observed_in_terminal_transcript_before_removal\n'
} | tee "$raw/cleanup_evidence_full1.log"


