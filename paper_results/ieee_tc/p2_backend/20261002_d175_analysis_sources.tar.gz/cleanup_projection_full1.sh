#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d175_20261002
unit=primelora-d175-full1-project-20261002.scope
{
 date -Is
 rg -qx 'InvocationID=3251dd696b3f4be5b5e711a64f021742' "$raw/full_full1_projection_scope.txt"
 rg -q 'Exit status: 0' "$raw/full_full1_projection_time.txt"
 test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
 test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
 test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
 test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
 systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
 printf 'actual_invocation=3251dd696b3f4be5b5e711a64f021742\nexit_code=0\ncleanup=automatic_removal_verified\n'
 awk '{print}' "$raw/full_full1_projection_memory_events.txt" "$raw/full_full1_projection_swap.txt"
} | tee "$raw/full_full1_projection_cleanup.txt"

