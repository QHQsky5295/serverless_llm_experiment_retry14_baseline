#!/usr/bin/env bash
# Reuse D173 metadata recipe3 directly on original bytes; no prior failed pass.
# Remove JSON whitespace outside strings only; preserve every numeric lexeme.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d175_20261002
unit=primelora-d175-full1-metadata3-20261002.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_metadata3_scope.txt"
test -s "$raw/7b_full_w0_full1/launch.json"
test "$(systemctl --user show primelora-tc-svc-e8a95cc934fa4199a401d73d2f476086.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
/usr/bin/python3 - "$raw/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json" "$raw/full_full1_main_outcome_compact3.json" <<'PY'
import io
import json
import sys

def strip_json_whitespace(source, target, chunk_size=1024*1024):
    quoted = escaped = False
    total_in = total_out = 0
    while block := source.read(chunk_size):
        total_in += len(block)
        output = bytearray()
        for byte in block:
            if quoted:
                output.append(byte)
                if escaped:
                    escaped = False
                elif byte == 92:
                    escaped = True
                elif byte == 34:
                    quoted = False
            elif byte not in (9, 10, 13, 32):
                output.append(byte)
                if byte == 34:
                    quoted = True
        target.write(output)
        total_out += len(output)
    if quoted or escaped:
        raise ValueError("unterminated JSON string")
    return total_in, total_out

fixtures = [
    {'strings': [' leading ', 'trailing ', '  both  ', '\\', '\\"', '"',
                 '\n\r\t', '中文', ' a : [ , ] { } b '],
     'nested': [{'empty': [], 'object': {}, 'null': None, 'false': False}],
     'large_int': 9007199254740993},
    [1, -2, 0.125, '  ', {'x': 1e-100}],
]
for value in fixtures:
    encoded = json.dumps(value, indent=24, ensure_ascii=False).encode()
    expected = json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode()
    for chunk in (1, 2, 7, 4096):
        output = io.BytesIO()
        strip_json_whitespace(io.BytesIO(encoded), output, chunk)
        assert output.getvalue() == expected
        assert json.loads(output.getvalue()) == value
# Explicit lexemes must survive without JSON parse/re-encoding.
encoded = b'{ "negative_zero" : -0.0, "integer": 9007199254740993, "x": 1.234567890123456789e-100 }'
expected = b'{"negative_zero":-0.0,"integer":9007199254740993,"x":1.234567890123456789e-100}'
for chunk in (1, 2, 7, 4096):
    output = io.BytesIO()
    strip_json_whitespace(io.BytesIO(encoded), output, chunk)
    assert output.getvalue() == expected
try:
    strip_json_whitespace(io.BytesIO(b'{"x":"unterminated'), io.BytesIO(), 1)
except ValueError:
    pass
else:
    raise AssertionError("unterminated string accepted")
print('12 chunked exact-byte/semantic fixtures and unterminated negative control PASS')
with open(sys.argv[1], 'rb') as source, open(sys.argv[2], 'xb') as target:
    counts = strip_json_whitespace(source, target)
print(json.dumps(dict(input_bytes=counts[0], output_bytes=counts[1],
                     transform='JSON whitespace outside strings only')))
PY
source_file="$raw/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json"
compact_file="$raw/full_full1_main_outcome_compact3.json"
test "$(stat -c %s "$compact_file")" -lt 134217728
sha256sum "$source_file" "$compact_file" > "$raw/full_full1_metadata_compaction3.sha256"
exec /usr/bin/time -v -o "$raw/full_full1_metadata3_time.txt" \
  /usr/bin/python3 "$raw/collect_full1_preliminary3.py" > "$raw/full_full1_metadata3.log" 2>&1
