#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d175_20261002
unit=primelora-d175-full1-metadata4-20261002.scope
{
 date -Is
 rg -qx 'InvocationID=54d1904506fe4551bfb3101314262af2' "$raw/full_full1_metadata4_scope.txt"
 rg -q 'Exit status: 0' "$raw/full_full1_metadata4_time.txt"
 test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
 test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
 test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
 test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
 systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
 printf 'actual_invocation=54d1904506fe4551bfb3101314262af2\nexit_code=0\ncleanup=automatic_removal_verified\n'
 awk '{print}' "$raw/full_full1_metadata4_memory_events.txt" "$raw/full_full1_metadata4_swap.txt"
} | tee "$raw/full_full1_metadata_cleanup.txt"
