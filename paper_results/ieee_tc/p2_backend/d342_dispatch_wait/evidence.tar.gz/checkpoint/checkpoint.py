"""Seal bounded D342 analysis and verify exact-path V2 checkpoint inputs."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend/d342_dispatch_wait'
old = json.loads((raw/'context_receipt.json').read_text())
assert old['pass_all']
identity=old['identity']; group=Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'context_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,inactive=True),f,indent=2)
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
preserved={}
with tarfile.open(raw/'analysis1_source_versions.tar.gz','r:gz') as tar:
    for member in tar.getmembers():
        data=tar.extractfile(member).read(); check(data); ast.parse(data)
        preserved[hashlib.sha256(data).hexdigest()]=(member.name,data)
source_refs=[]
for part in ['analysis1','context1']:
    directory=out/part; manifest=json.loads((directory/'manifest.json').read_text())
    for name,digest in manifest['outputs'].items():
        assert p.digest(directory/name) == digest,name
    for ref in manifest['source_refs']:
        path=Path(ref['path'])
        actual=p.digest(path)
        if actual != ref['sha256']:
            assert ref['sha256'] in preserved and path.suffix == '.py',ref['path']
        source_refs.append(dict(ref,byte_version='current' if actual==ref['sha256'] else 'archived_analysis1'))
paths=[raw/name for name in ['analyze.py','context.py','checkpoint.py','analysis1.log',
    'context1.log','analysis_receipt.json','context_receipt.json','analysis_cleanup.json','context_cleanup.json']]
paths += [ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'scripts/ieee_tc/analyze_d297_full.py',
          ROOT/'tests/test_ieee_tc_control_timeline.py']
archive=out/'evidence.tar.gz'
with archive.open('xb') as file, tarfile.open(fileobj=file,mode='w:gz') as tar:
    for path in paths:
        data=path.read_bytes();check(data)
        if path.suffix == '.py': ast.parse(data)
        tar.add(path,arcname='checkpoint/'+path.name,recursive=False)
    for name,data in preserved.values():
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    for path in paths:
        assert hashlib.sha256(tar.extractfile('checkpoint/'+path.name).read()).hexdigest()==p.digest(path)
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert protected['changed']==[known] and protected['entry_count']==147
assert p.digest(Path(known))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
with (out/'evidence.json').open('x') as f:
    json.dump(dict(kind='d342_retained_data_checkpoint_v1',new_gpu_runs=0,no_figures=True,
        formal_qualification=False,n_correct=None,analysis_tests=72,context_tests=34,
        tests_overlap_not_independent=True,archive_sha256=p.digest(archive),source_refs=source_refs,
        raw_refs=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
        protected=protected,analysis_scope_closed=True,context_scope_closed=True),f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
relative=['docs/ieee_tc/D342_DISPATCH_WAIT_DIAGNOSIS.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'scripts/analyze_control_path_overhead.py','scripts/ieee_tc/analyze_d297_full.py',
    'tests/test_ieee_tc_control_timeline.py']
relative += [str(path.relative_to(ROOT)) for path in sorted(out.rglob('*')) if path.is_file()]
subprocess.run(['git','add','--',*relative],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(relative) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert data==(ROOT/name).read_bytes();check(data)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['sha256sum','-c','evidence.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
own=p.scope_identity(Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name)
own_group=Path(own['path'])
with (raw/'checkpoint_verification.json').open('x') as f:
    json.dump(dict(staged_paths=staged,identity=own,pass_all=True,source_versions_preserved=len(preserved),
        resources={k:(own_group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')},
        protected=protected),f,indent=2)
print(json.dumps(dict(staged_paths=len(staged),source_versions_preserved=len(preserved),pass_all=True)))
