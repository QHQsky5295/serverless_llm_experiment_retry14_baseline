"""Close the finished split scope, then inspect compact retained capacity data."""
import io
import json
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw = Path(__file__).resolve().parent
old = json.loads((raw/'analysis_receipt.json').read_text())['identity']
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
resources = {k:(Path(old['path'])/k).read_text() for k in
             ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',old['unit'],'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'analysis_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,resources=resources,inactive=True),f,indent=2)

unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])
def sample():
    return {k:(group/k).read_text().strip() for k in ('memory.peak','memory.events',
        'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events')}
before = sample()
assert before['memory.high'] == str(3*1024**3) and before['memory.max'] == str(4*1024**3)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}

# Archive the exact earlier analysis bytes, reversed from only the subsequent
# context extension and checked against the manifest frozen BEFORE extension.
# This is a version-preservation artifact, not modification of the old manifest.
manifest = json.loads((ROOT/'paper_results/ieee_tc/p2_backend/d342_dispatch_wait/analysis1/manifest.json').read_text())
expected = {r['path']:r['sha256'] for r in manifest['source_refs']}
snapshots = {}
control = ROOT/'scripts/analyze_control_path_overhead.py'
data = control.read_text()
left = data.index('\ndef summarize_dispatch_capacity_context(')
right = data.index('\ndef summarize_route_copy_revisits(',left)
data = data[:left]+data[right:]
snapshots['analysis1/scripts/analyze_control_path_overhead.py'] = (control,data.encode())
driver = ROOT/'scripts/ieee_tc/analyze_d297_full.py'
data = driver.read_text()
data = data.replace('summarize_route_copy_revisits, summarize_dispatch_gate_intervals,\n    summarize_dispatch_capacity_context)',
                    'summarize_route_copy_revisits, summarize_dispatch_gate_intervals)')
left = data.index('\ndef inspect_retained_dispatch_context(')
right = data.index("\nif __name__ == '__main__':",left)
data = data[:left]+data[right:]
data = data.replace("    parser.add_argument('--dispatch-context-output', type=Path,\n        help='D342 compact split data and conservative sampled permit bounds')\n",'')
data = data.replace('args.capacity_lifecycle_output, args.dispatch_gate_output,\n                                  args.dispatch_context_output)) > 1:',
                    'args.capacity_lifecycle_output, args.dispatch_gate_output)) > 1:')
data = data.replace('    if args.dispatch_context_output is not None:\n        inspect_retained_dispatch_context(args.dispatch_context_output)\n    elif args.dispatch_gate_output is not None:',
                    '    if args.dispatch_gate_output is not None:')
snapshots['analysis1/scripts/ieee_tc/analyze_d297_full.py'] = (driver,data.encode())
for name,(path,data) in snapshots.items():
    assert hashlib.sha256(data).hexdigest() == expected[str(path)],name
with tarfile.open(raw/'analysis1_source_versions.tar.gz','x:gz') as tar:
    for name,(path,data) in snapshots.items():
        info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644
        tar.addfile(info,io.BytesIO(data))

commands = [[sys.executable,'-m','unittest','tests.test_ieee_tc_control_timeline','-q'],
    [sys.executable,'-m','scripts.ieee_tc.analyze_d297_full','--dispatch-context-output',
     'paper_results/ieee_tc/p2_backend/d342_dispatch_wait/context1']]
returncodes=[]
try:
    with (raw/'context1.log').open('x') as log:
        for command in commands:
            print(json.dumps(dict(command=command)),file=log,flush=True)
            done=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            returncodes.append(done.returncode); done.check_returncode()
finally:
    with (raw/'context_receipt.json').open('x') as f:
        json.dump(dict(identity=identity,before=before,after=sample(),commands=commands,
            returncodes=returncodes,pass_all=len(returncodes)==len(commands) and not any(returncodes)),f,indent=2)
print(json.dumps(dict(returncodes=returncodes,receipt=str(raw/'context_receipt.json'))))
