"""Reuse exact-identity recursive-empty closure for D812 storage only."""
import json
import subprocess
from pathlib import Path
_raw = Path(__file__).resolve().parent
_identity = json.loads((_raw/'storage_identity.json').read_text())
_group = Path(_identity['path'])
if not _group.exists():
    # systemd may remove an empty scope before the external closer runs.
    # Verify that actual terminal state instead of issuing a stale stop.
    _state = subprocess.check_output(['systemctl', '--user', 'show', _identity['unit'],
        '-p', 'ActiveState', '-p', 'InvocationID', '-p', 'LoadState'], text=True)
    _fields = dict(line.split('=', 1) for line in _state.splitlines())
    assert _fields['ActiveState'] == 'inactive' and not _fields['InvocationID']
    assert not _group.exists()
    _receipt = Path('/home/qhq/serverless_llm_experiment_retry14_baseline/paper_results/ieee_tc/storage/20261025_d812_closed_outcome_verification.json')
    _verified = json.loads(_receipt.read_text())
    assert _verified['passed'] and _verified['identity'] == _identity
    with (_raw/'storage_closure.json').open('x') as _stream:
        json.dump(dict(passed=True, identity=_identity, path_gone=True,
            systemd_state=_fields, automatically_removed=True, signals_sent=False,
            resources_before_exit=_verified['resources'],
            resource_source=str(_receipt),
            actual_recursive_procs_empty=None,
            note='The domain was already removed after the completed command. No post-removal cgroup counters or explicit empty-tree sample are invented.'),
            _stream, indent=2)
        _stream.write('\n')
    print(json.dumps(dict(passed=True, path_gone=True, automatically_removed=True)))
    raise SystemExit(0)
_template = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d593_20261017/close.py')
_source = _template.read_text()
_old = "assert name in ('analysis', 'publication')"
assert _source.count(_old) == 1
_source = _source.replace(_old, "assert name == 'storage'")
exec(compile(_source, str(_template), 'exec'), globals())
