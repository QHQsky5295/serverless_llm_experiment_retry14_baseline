"""D597 prelaunch checkpoint, reusing D531 source checks and D530 explicit backup."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d597_parallel_pressure_native100'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name)
save(RAW/'backup_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
previous=read(RAW.parent.parent/'p2_backend_qualification/d595_20261017/backup_receipt.json')
assert previous['passed'] and git('rev-parse','HEAD')==previous['head']
assert git('branch','--show-current')=='retry14_continuous_queue_v2'
assert not git('diff','--cached','--name-only')
binding_path=RAW/'qualification.json'
binding=read(binding_path)
assert binding['passed'] and binding['prefix_count']==100 and binding['reused_cpu_regression_tests']==368
for path,sha in {**binding['refs'],**binding['preserved']}.items():assert p.digest(Path(path))==sha,path
closed=read(RAW/'qualification2_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
build_path=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
compiler_path=ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain/qualification.json'
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert set(git('diff','--name-only','HEAD','--','scripts','faaslora','tests','configs/ieee_tc').splitlines())=={'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'}
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh')])
files += [RAW/'qualification.json',RAW/'qualification2_closure.json',
    ROOT/'configs/ieee_tc/20261017_d597_7b_parallel_pressure_validation_100.yaml',
    ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh']
storage=RAW.parent.parent/'storage_maintenance/d596_20261017'
closed_storage=read(storage/'storage_closure.json')
assert closed_storage['passed'] and closed_storage['path_gone'] and not Path(closed_storage['identity']['path']).exists()
files += [storage/name for name in ('compress.py','close.py','prechecks.json','storage_result.json','receipt.json','storage_closure.json')]
for path in files:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not token or token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
OUT.mkdir(parents=True,exist_ok=False)
members={}
with tarfile.open(OUT/'prelaunch_evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<2*1024*1024;clean(data)
        name=f'{i:02d}_{path.name}'
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'prelaunch_evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'prelaunch.json',dict(passed=True,reused_qualification=dict(path=str(binding_path),sha256=p.digest(binding_path),reused_input_tests=103,reused_cpu_regression_tests=368),
    common_build_sha256=p.digest(build_path),compiler_qualification_sha256=p.digest(compiler_path),
    baseline_execution_checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip(),
    source_sha256={str(path):p.digest(path) for path in files},archive_members=members,
    archive_sha256=p.digest(OUT/'prelaunch_evidence.tar.gz'),protected=protected,
    no_production_code_change_since_d595=True,no_new_inputs=True,performance_started=False))
paths=['docs/ieee_tc/D597_INITIAL_CONTROL_NATIVE100.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'configs/ieee_tc/20261017_d597_7b_parallel_pressure_validation_100.yaml',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh']
paths += [str((OUT/name).relative_to(ROOT)) for name in ('prelaunch.json','prelaunch_evidence.tar.gz')]
for name in paths:
    data=(ROOT/name).read_bytes();assert len(data)<2*1024*1024
    if not name.endswith('.tar.gz'):clean(data)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for name in paths:
    assert hashlib.sha256(subprocess.check_output(['git','show',':'+name],cwd=ROOT)).hexdigest()==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: qualify parallel-pressure native validation and preserve storage receipts (D597)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD')
assert git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]==head
save(RAW/'backup_receipt.json',dict(passed=True,head=head,remote_equal=True,scope=identity,files=paths,
    reused_tests=dict(input=103,compiler=16,candidate_regression=368),source_manifest_sha256=p.digest(OUT/'prelaunch.json')))
print(json.dumps(dict(passed=True,head=head,files=paths)))
