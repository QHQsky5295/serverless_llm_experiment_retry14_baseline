"""Publish existing verified prelaunch bundle; correct only the stage filename.

The first publisher stopped before staging on a document basename copied from
D550. Its source/bundle/scope are retained unchanged; no experiment was started.
"""
import ast, hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d597_parallel_pressure_native100'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD')=='8639ce510fa5fe0d20adfe93e922a280751acf77'
assert not git('diff','--cached','--name-only')
closed=read(RAW/'backup_closure.json')
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
prepared=read(OUT/'prelaunch.json')
for path,sha in prepared['source_sha256'].items():assert p.digest(Path(path))==sha,path
assert p.digest(OUT/'prelaunch_evidence.tar.gz')==prepared['archive_sha256']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
with tarfile.open(OUT/'prelaunch_evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(prepared['archive_members'])
    for name,ref in prepared['archive_members'].items():
        data=bundle.extractfile(name).read();clean(data)
        assert hashlib.sha256(data).hexdigest()==ref['sha256']
binding=read(RAW/'qualification.json')
for path,sha in {**binding['refs'],**binding['preserved']}.items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
save(OUT/'publication_recovery.json',dict(kind='publisher_filename_correction',
    first_publisher_failed_before_staging=True,wrong_basename='D597_INITIAL_CONTROL_NATIVE100.md',
    actual_basename='D597_PARALLEL_PRESSURE_NATIVE100.md',no_gpu_experiment_started=True,
    first_publisher_sha256=p.digest(RAW/'backup.py'),first_scope_closure=closed,
    resume_source=Path(__file__).read_text(),protected=protected))
names=['docs/ieee_tc/D597_PARALLEL_PRESSURE_NATIVE100.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'configs/ieee_tc/20261017_d597_7b_parallel_pressure_validation_100.yaml',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh']
names += [str((OUT/name).relative_to(ROOT)) for name in ('prelaunch.json','prelaunch_evidence.tar.gz','publication_recovery.json')]
for name in names:
    if not name.endswith('.tar.gz'):clean((ROOT/name).read_bytes())
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: qualify native pressure-barrier validation and archive closed evidence (D596/D597)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD');remote=git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head==remote
save(RAW/'backup_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity,
    publisher_recovery_sha256=p.digest(OUT/'publication_recovery.json')))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
