"""Bounded CPU regression and matched measured export; no inference or figures."""
import contextlib,json,pathlib,sys,unittest
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

def main():
    raw=pathlib.Path(__file__).resolve().parent
    names=['tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer',
        'tests.test_ieee_tc_preflight.CapacityProbeObservation','tests.test_ieee_tc_warm_reference',
        'tests.test_ieee_tc_request_lifecycle','tests.test_ieee_tc_launch']
    with (raw/'export1_cpu_tests.log').open('x') as f:
        result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
    record=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        successful=result.wasSuccessful(),gpu_runs=0,identity=p.scope_identity(p.cg_path().name))
    with (raw/'export1_cpu_tests.json').open('x') as f:json.dump(record,f,indent=2)
    print(json.dumps(record),flush=True)
    assert result.wasSuccessful()
    from scripts.ieee_tc.export_d298_profiles import main as export
    with (raw/'export1.log').open('x') as f,contextlib.redirect_stdout(f):
        export('d344-merged')
    manifest=ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/initialization/manifest.json'
    data=json.loads(manifest.read_text())
    summary=dict(passed=data['passed'],manifest_sha256=p.digest(manifest),
        requests=data['summary']['requests'],measurements=data['summary']['representative_requests'],
        service_classes=data['coverage']['measured_service_classes'],
        preparation_classes=data['coverage']['measured_preparation_classes'],
        n_correct=data['n_correct'],new_gpu_runs=0,identity=record['identity'])
    assert (summary['requests'],summary['measurements'],summary['service_classes'],
            summary['preparation_classes'])==(1569,1545,200,24)
    with (raw/'export1_receipt.json').open('x') as f:json.dump(summary,f,indent=2)
    print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
