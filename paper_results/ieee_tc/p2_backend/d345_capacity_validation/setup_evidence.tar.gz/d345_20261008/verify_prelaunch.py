"""Reuse D334's Full assembly checks with the predeclared D344 C14 contract."""
import copy,json,os,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
import yaml
from scripts import ieee_tc_preflight as p
from scripts.run_all_experiments import (ScenarioRunner,
    _prepare_scenario_runtime_model_config,_prepare_dedicated_subprocess_model_cfg)

root=p.ROOT;out=Path(__file__).resolve().parent
config=root/'configs/ieee_tc/20261008_d345_7b_capacity_validation_100.yaml'
previous=root/'configs/ieee_tc/20261008_d336_7b_full_w0.yaml'
contract_path=root/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/development_contract.json'
manifest_path=root/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/initialization/manifest.json'
c,old=(yaml.safe_load(x.read_text()) for x in (config,previous))
contract=json.loads(contract_path.read_text());manifest=json.loads(manifest_path.read_text())
assert manifest['passed'] and manifest['coverage']['class_domain_covered']
assert manifest['clock_domains_joined'] is False and manifest['new_gpu_runs']==0
assert manifest['contract']['sha256']==p.digest(contract_path)
expected=copy.deepcopy(old)
for section,field in [('experiment','output_dir'),('storage','nvme_cache_dir'),('storage','host_cache_dir')]:
    assert not Path(c[section][field]).exists()
    expected[section][field]=c[section][field]
for key in ('max_loras','max_num_seqs','runtime_concurrency_cap','requested_runtime_concurrency_cap'):
    expected['model'][key]=14
expected['model']['ieee_admission_profile']=contract['model_config']['ieee_admission_profile']
coord=expected['resource_coordination']
targets=p.derive_ieee_capacity_targets(14,min_instances=coord['min_instances'],max_instances=coord['max_instances'])
coord['ieee_scaling'].update(targets)
coord.update(manifest['bindings'])
assert c==expected and c['workload']['total_requests']==4000
assert c['experiment']['output_dir']==str(out/'7b_capacity_validation_100')
assert c['storage']['nvme_cache_dir']==str(out/'7b_nvme_w0')
assert c['storage']['host_cache_dir']=='/dev/shm/tc-d345-7b-w0'
assert {k:v for k,v in coord.items() if k not in manifest['bindings']}==contract['coordination']
configured=_prepare_scenario_runtime_model_config(c['model'],c['workload'],coord)
child,assembly=_prepare_dedicated_subprocess_model_cfg(configured,device_id=0,runtime_gpu_ids=[0])
assert child==contract['model_config']
bound=ScenarioRunner.__new__(ScenarioRunner)
bound.model_cfg,bound.engine=child,SimpleNamespace(model_cfg=child)
bound.coord_cfg=coord
bound._service_profiles=bound._load_ieee_service_profiles()
prep=bound._load_ieee_preparation_profiles()
assert len(bound._service_profiles.profiles)==200 and len(prep.profiles)==24
assert bound._service_profiles.identity()==manifest['profiles']['service']
assert prep.identity()==manifest['profiles']['preparation']
seal=p.verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['changed']==[str(known)] and seal['entry_count']==147
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(root/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert set(os.sched_getaffinity(0))=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
preflight=p.preflight([root],32*p.GIB)
assert preflight['preflight_pass'],preflight['issues']
refs=[config,previous,contract_path,manifest_path,Path(__file__),
    root/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',root/'scripts/run_all_experiments.py',
    root/'faaslora/scheduling/vllm_ieee_frontend.py',root/'faaslora/scheduling/vllm_ieee_scheduler.py',
    root/'faaslora/scheduling/resource_coordinator.py',
    root/'results/ieee_tc/p2_backend_qualification/d344_20261008/export1_cpu_tests.json']
receipt=dict(kind='d345_prelaunch_binding_v1',passed=True,
    source_head_before_checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    service_classes=200,preparation_classes=24,model_config=child,assembly=assembly,
    capacity_targets=targets,protection=seal,preflight=preflight,
    source_references=[dict(path=str(x),sha256=p.digest(x)) for x in refs],
    base_requests=4000,diagnostic_prefix_count=100,numerical_n_correct=None,
    formal_qualification=False,observer='none',no_figures=True,
    common_warm_reference_changed=False,profile_bindings=manifest['bindings'],
    identity=p.scope_identity(p.cg_path().name))
with (out/'prelaunch_binding.json').open('x') as f:json.dump(receipt,f,indent=2,allow_nan=False)
print(json.dumps(dict(passed=True,classes=[200,24],disk_free=preflight['filesystems'][0]['free_bytes'],
    mem_available=preflight['memory']['MemAvailable'],identity=receipt['identity'])),flush=True)
