"""Reuse exact-owned closure, SHA archive verification and protected-data checks."""
import ast,hashlib,json,subprocess,sys,tarfile
from pathlib import Path
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

raw=Path(__file__).resolve().parent
source=raw.parent/'d344_20261008'
out=p.ROOT/'paper_results/ieee_tc/p2_backend/d345_capacity_validation'
out.mkdir(exist_ok=False)
cleanup=[]
for report in (source/'export1_receipt.json',raw/'prelaunch_binding.json'):
    data=json.loads(report.read_text());assert data['passed']
    identity=data['identity'];group=Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources={k:(group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events')}
    assert resources['memory.swap.current']=='0'
    assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
    stopped=p.stop_scope_identity(identity);assert stopped['released'] and not stopped['hard_kill']
    assert not group.exists()
    cleanup.append(dict(report=str(report),identity=identity,resources=resources,cleanup=stopped))
tests=json.loads((source/'export1_cpu_tests.json').read_text())
assert tests['successful'] and tests['tests']==376 and tests['errors']==tests['failures']==0
binding=json.loads((raw/'prelaunch_binding.json').read_text())
for ref in binding['source_references']:assert p.digest(Path(ref['path']))==ref['sha256']
manifest=p.ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/initialization/manifest.json'
export=json.loads(manifest.read_text())
for ref in export['raw_evidence']:assert p.digest(Path(ref['path']))==ref['sha256']
for profile in export['bindings'].values():assert p.digest(Path(profile['path']))==profile['sha256']
scripts=[p.ROOT/'scripts/ieee_tc_preflight.py',p.ROOT/'scripts/ieee_tc/export_d298_profiles.py',
    p.ROOT/'tests/test_ieee_tc_launch.py',*raw.glob('*.py')]
for path in scripts:ast.parse(path.read_text())
for path in [p.ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',*raw.glob('*.sh')]:
    subprocess.run(['bash','-n',str(path)],check=True)
refs=[source/name for name in ('export1.py','export1.log','export1_receipt.json',
    'export1_cpu_tests.log','export1_cpu_tests.json','scope21_cleanup.json')]
refs+=sorted(x for x in raw.iterdir() if x.is_file())
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert token
for path in refs:assert token not in path.read_bytes(),path
archive=out/'setup_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in refs:tar.add(path,arcname=str(path.relative_to(raw.parent)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(refs)
    for path in refs:
        assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw.parent))).read()).hexdigest()==p.digest(path)
def save(name,value):
    with (out/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
save('prelaunch_binding.json',binding)
save('cleanup.json',cleanup)
save('checkpoint.json',dict(passed=True,tests=tests['tests'],export_manifest_sha256=p.digest(manifest),
    plan_sha256=p.check_plan(),metric_protocol_sha256=p.digest(p.ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    archive_sha256=p.digest(archive),archive_bytes=archive.stat().st_size,
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in refs],
    numerical_n_correct=None,common_slo_qualified=False,full_smoke_launched=False,new_gpu_runs=0,no_figures=True))
with (out/'outputs.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.name!='outputs.sha256':f.write(p.digest(path)+'  '+path.name+'\n')
print(json.dumps(dict(passed=True,tests=376,archive_bytes=archive.stat().st_size,
    closed_scopes=len(cleanup),identity=p.scope_identity(p.cg_path().name))),flush=True)
