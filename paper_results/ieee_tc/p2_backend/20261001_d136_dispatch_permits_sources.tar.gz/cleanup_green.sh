#!/usr/bin/env bash
set -euo pipefail
# Reuse D135 exact-identity and empty-domain cleanup.
date -Is
unit=primelora-d136-green-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = ad9a34c2b20e4238bb61756ba3cafab7
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d136-green-20261001.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
