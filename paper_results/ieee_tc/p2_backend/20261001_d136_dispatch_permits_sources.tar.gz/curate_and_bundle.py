"""Reuse D134 CPU-candidate evidence/bundle workflow; no replay or large parse."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d136_20261001'
parent = root/'paper_results/ieee_tc/p2_backend'
out = parent/'20261001_d136_dispatch_permits.json'
assert not out.exists()
def sha(p):
    assert p.stat().st_size < 8*1024**2, str(p)
    return hashlib.sha256(p.read_bytes()).hexdigest()
for phase in ('red', 'green', 'verify'):
    unit = f'primelora-d136-{phase}-20261001.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'], text=True).strip() == 'inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
verification = json.loads((raw/'verification.json').read_text())
assert verification['protected']['pass'] and verification['protected']['entry_count'] == 147
assert verification['tests'] >= 1068
for ref in verification['source_refs']:
    assert sha(Path(ref['path'])) == ref['sha256']
red, green = (raw/'red.log').read_text(), (raw/'green.log').read_text()
assert "['newcomer', 'older'] != ['older', 'newcomer']" in red
assert 'Ran 1 test in 0.002s' in red and 'FAILED (failures=1)' in red
assert 'Ran 9 tests in 0.005s\n\nOK\n' in green
assert 'Exit status: 1' in (raw/'red_time.txt').read_text()
for phase in ('green', 'verify'):
    assert 'Exit status: 0' in (raw/f'{phase}_time.txt').read_text()

# Reuse D135's already-curated CSV, not its 15GB original or projection pass.
csv_path = parent/'20261001_d135_control_occupancy/request_occupancy.csv'
prior_receipt = parent/'20261001_d135_evidence_verification.json'
assert sha(prior_receipt) == '2de8ecb22a9de42969f81ca806fd1bb45097abb5eef9dfe2f3d794ccec119a35'
prior = json.loads(prior_receipt.read_text())
expected = next(ref['sha256'] for ref in prior['refs'] if Path(ref['path']) == csv_path)
assert sha(csv_path) == expected
with csv_path.open() as handle:
    rows = list(csv.DictReader(handle))
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
valid = [r for r in rows if r['arrival_to_gate_s']]
assert len(valid) == 3999 and all(r['success'] == 'True' for r in valid)
offered = sorted(valid, key=lambda r: (float(r['arrival_offset_s']), r['request_id']))
rank = {r['request_id']: i for i,r in enumerate(offered)}
ordered = sorted(valid, key=lambda r: (float(r['arrival_offset_s'])+float(r['arrival_to_gate_s']), r['request_id']))
displacements = [dict(request_id=r['request_id'], offered_rank_in_observed_population=rank[r['request_id']],
    admission_rank=i, admission_minus_offered_rank=i-rank[r['request_id']],
    arrival_offset_s=float(r['arrival_offset_s']),
    gate_offset_s=float(r['arrival_offset_s'])+float(r['arrival_to_gate_s'])) for i,r in enumerate(ordered)]
order_diagnostic = dict(population=3999, missing_request_ids=[r['request_id'] for r in rows if not r['arrival_to_gate_s']],
    top_advanced=sorted(displacements,key=lambda r:r['admission_minus_offered_rank'])[:10],
    top_delayed=sorted(displacements,key=lambda r:r['admission_minus_offered_rank'],reverse=True)[:10],
    caveat='Offered order is not directly observed gate-entry order; rank displacement alone does not prove barging or identify the failed request stage. Near-ties use request ID. No latency counterfactual.')
refs = [csv_path, prior_receipt, raw/'verification.json', raw/'red.log', raw/'green.log', raw/'verify.log',
    raw/'test_dispatch_permits.sh', raw/'verify_dispatch_permits.sh',
    raw/'cleanup_inspect1.sh', raw/'cleanup_inspect1.log', raw/'cleanup_red.sh', raw/'cleanup_red.log',
    raw/'cleanup_green.sh', raw/'cleanup_green.log', raw/'cleanup_verify.sh', raw/'cleanup_verify.log',
    root/'docs/ieee_tc/D136_DISPATCH_PERMIT_OWNERSHIP.md', Path(__file__)]
result = dict(kind='d136_dispatch_permit_ownership_v1',
    parent_commit='220f4303ecb69339c0d9575fda76cd2db66efaeb',
    production_changed=['scripts/run_all_experiments.py'],
    decision='CPU queue ownership candidate; ordinary Full required',
    full_replay_qualified=False, formal_performance_result=False, cuda_executed=False,
    red_green=dict(red_order=['newcomer','older'],green_order=['older','newcomer'],
        red_tests=1,green_tests=9,independent_performance_repetitions=0),
    verification=verification, d135_order_diagnostic=order_diagnostic,
    d135_timeout_cause_established=False,
    unchanged=dict(formulas=True,capacity_function=True,timeout=True,workload=True,
        profiles=True,runtime_slot_guards=True,native_ownership_guards=True,remote=True),
    resource_limits=dict(memory_high_bytes=3*2**30,memory_max_bytes=4*2**30,swap_max_bytes=0,cpus=[2,3,26,27]),
    references=[
        dict(url='https://github.com/python/cpython/blob/v3.12.12/Lib/asyncio/locks.py',
             role='Condition notification vs Semaphore permit-before-wake ownership and cancellation'),
        dict(url='https://github.com/vllm-project/vllm/blob/v0.30.0/vllm/v1/engine/async_llm.py',
             role='Frontend outstanding-request admission; not native max_num_seqs or borrowed performance'),
        dict(url='https://github.com/vllm-project/vllm/blob/v0.30.0/vllm/v1/core/sched/scheduler.py',
             role='Separate native running sequence/token constraints')],
    source_sha256={str(p):sha(p) for p in refs},
    next='Scoped backup, then one ordinary 7B W0 Full4000, same D135 config and D89 profiles except fresh owned paths')
with out.open('x') as stream:
    json.dump(result,stream,indent=2,allow_nan=False)
bundle = parent/'20261001_d136_dispatch_permits_sources.tar.gz'
assert not bundle.exists()
members = {}
with tarfile.open(bundle,'x:gz') as archive:
    for p in sorted(raw.iterdir()):
        if not p.is_file() or p.stat().st_size >= 2*1024**2 or p.suffix not in {'.py','.sh','.json','.txt','.log','.patch'}:
            continue
        if p.name in {'finalize.log','finalize_time.txt'}:
            continue
        data = p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        members[p.name] = hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(members)
    for name,expected in members.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
with (parent/'20261001_d136_dispatch_permits_sources.sha256').open('x') as stream:
    stream.write(sha(bundle)+'  '+bundle.name+'\n')
with (parent/'20261001_d136_dispatch_permits_sources_members.json').open('x') as stream:
    json.dump(dict(bundle=bundle.name,member_sha256=members,member_checks_pass=True),stream,indent=2)
print(json.dumps(dict(bytes=bundle.stat().st_size,members=len(members),sha256=sha(bundle),output=str(out),
    tests=verification['tests'],protected=147,order_diagnostic=order_diagnostic)))
