#!/usr/bin/env bash
set -euo pipefail
# Reuse D135 exact-identity and empty-domain cleanup.
date -Is
unit=primelora-d136-verify-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 9d9b678be739402f8be23bc46611cb69
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d136-verify-20261001.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
