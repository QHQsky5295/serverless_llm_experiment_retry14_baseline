"""D468 bounded CPU contracts; no native performance or pool launch."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2,allow_nan=False)

def run(name):
    save(RAW/(name+'_identity.json'),p.scope_identity(p.cg_path().name))
    assert os.environ['CUDA_VISIBLE_DEVICES']=='' and os.sched_getaffinity(0)=={2,3,26,27}
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
    assert protected['pass'] and protected['entry_count']==147
    snapshot=RAW/(name+'_sources')
    snapshot.mkdir()
    refs=[]
    paths=['faaslora/experiment/cpu_frontend.py','faaslora/metrics/metrics_collector.py',
        'scripts/dedicated_engine_worker.py','tests/test_ieee_tc_cpu_frontend_lifecycle.py',
        'tests/test_ieee_tc_gpu_lifecycle.py','scripts/run_all_experiments.py']
    for relative in paths:
        source=ROOT/relative
        ast.parse(source.read_text())
        target=snapshot/relative.replace('/','_')
        with target.open('xb') as f:f.write(source.read_bytes())
        refs.append(dict(path=str(source),sha256=p.digest(source),snapshot=str(target)))
    modules=['tests.test_ieee_tc_cpu_frontend_lifecycle','tests.test_ieee_tc_gpu_lifecycle',
        'tests.test_ieee_tc_frontend_preparation','tests.test_ieee_tc_native_timing',
        'tests.test_ieee_tc_launch','tests.test_basic_smoke']
    started=time.monotonic()
    with (RAW/(name+'_tests.txt')).open('x') as f:
        result=unittest.TextTestRunner(stream=f,verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromNames(modules))
    record=dict(passed=result.wasSuccessful(),tests=result.testsRun,failures=len(result.failures),
        errors=len(result.errors),skipped=len(result.skipped),elapsed_s=time.monotonic()-started,
        protected=protected,source_refs=refs,modules=modules,python=sys.executable,
        helper_sha256=p.digest(Path(__file__)),native_qualification=False,performance_result=False)
    save(RAW/(name+'_result.json'),record)
    print(json.dumps({k:record[k] for k in ('passed','tests','failures','errors','skipped','elapsed_s')}),flush=True)
    assert result.wasSuccessful()

def close(name):
    expected=json.loads((RAW/(name+'_identity.json')).read_text())
    assert p.scope_still_owned(expected)
    group=Path(expected['path'])
    members={str(x):x.read_text().split() for x in group.rglob('cgroup.procs')}
    assert members and all(not values for values in members.values())
    resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}
    assert p.scope_still_owned(expected)
    subprocess.run(['systemctl','--user','stop',expected['unit']],check=True)
    assert not group.exists()
    save(RAW/(name+'_closure.json'),dict(passed=True,identity=expected,resources=resources,
        actual_recursive_procs_empty=True,source_sha256=p.digest(Path(__file__))))
    print(json.dumps(dict(closed=name,resources=resources)))

if __name__=='__main__':
    {'run':run,'close':close}[sys.argv[1]](sys.argv[2])
