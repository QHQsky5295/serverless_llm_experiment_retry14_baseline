"""D468 bounded curation using the existing protection and ownership checks."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import time
import urllib.request
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d468_cpu_lifecycle'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for name,count in [('cpu1',554),('cpu2',558)]:
    result=json.loads((RAW/(name+'_result.json')).read_text())
    assert result['passed'] and result['tests']==count and not(result['errors'] or result['failures'] or result['skipped'])
    close=json.loads((RAW/(name+'_closure.json')).read_text())
    assert close['actual_recursive_procs_empty'] and not Path(close['identity']['path']).exists()
final=json.loads((RAW/'cpu2_result.json').read_text())
for ref in final['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256']
refs=[]
for name in ('docs/design/multiprocessing.md','vllm/platforms/cuda.py','vllm/v1/engine/utils.py'):
    url='https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/'+name
    path=RAW/('official_'+name.replace('/','_'))
    with urllib.request.urlopen(url,timeout=25) as response:data=response.read(1024*1024+1)
    assert 0<len(data)<=1024*1024
    with path.open('xb') as f:f.write(data)
    refs.append(dict(url=url,path=str(path),bytes=len(data),sha256=p.digest(path)))
save(RAW/'primary_sources.json',dict(retrieved_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),refs=refs))
OUT.mkdir(exist_ok=False)
members={}
paths=[RAW/(name+suffix) for name in ('cpu1','cpu2') for suffix in
       ('_tests.txt','_result.json','_closure.json','_identity.json')]
paths += [RAW/'check.py',Path(__file__),RAW/'primary_sources.json']
paths += sorted((RAW/'cpu1_sources').iterdir())+sorted((RAW/'cpu2_sources').iterdir())
paths += [Path(ref['path']) for ref in refs]
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as archive:
    for path in paths:
        name=str(path.relative_to(RAW))
        members[name]=dict(path=str(path),sha256=p.digest(path),bytes=path.stat().st_size)
        archive.add(path,arcname=name,recursive=False)
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as archive:
    assert set(archive.getnames())==set(members)
    for name,ref in members.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==ref['sha256']
for name in ('cpu1_result.json','cpu2_result.json','cpu1_closure.json','cpu2_closure.json','primary_sources.json'):
    with (OUT/name).open('xb') as f:f.write((RAW/name).read_bytes())
preserved={}
for name in ('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md',
    str(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),str(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    str(ROOT/'configs/generated/lora_manifest_1000.json'),str(ROOT/'configs/ieee_tc/20261012_d465_7b_full_w0.yaml'),
    str(ROOT/'scripts/run_all_experiments.py'),str(ROOT/'sitecustomize.py')):
    preserved[name]=p.digest(Path(name))
assert preserved[str(ROOT/'configs/generated/lora_manifest_1000.json')]=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
for relative in ('scripts/run_all_experiments.py','sitecustomize.py','configs/ieee_tc/20261012_d465_7b_full_w0.yaml'):
    assert hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+relative],cwd=ROOT)).hexdigest()==p.digest(ROOT/relative)
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
outputs={path.name:p.digest(path) for path in OUT.iterdir()}
manifest=dict(passed=True,kind='cpu_preparation_lifecycle_foundation_d468_v1',
    parent='767e4d417eaad567595d209b43cd611a9dbdac1e',native_qualified=False,
    production_runner_integrated=False,performance_result=False,final_cpu_tests=558,
    protected=protected,preserved=preserved,source_refs=final['source_refs'],
    outputs=outputs,archive_members=members,
    next='Original factory/notice/teardown integration, native qualification, then one new-key full W0; no repeat import microtest.')
save(OUT/'manifest.json',manifest)
save(RAW/'curation_receipt.json',dict(passed=True,manifest_sha256=p.digest(OUT/'manifest.json'),
    archive_bytes=(OUT/'evidence.tar.gz').stat().st_size,members=len(members)))
print(json.dumps(dict(passed=True,manifest_sha256=p.digest(OUT/'manifest.json'),members=len(members))))
