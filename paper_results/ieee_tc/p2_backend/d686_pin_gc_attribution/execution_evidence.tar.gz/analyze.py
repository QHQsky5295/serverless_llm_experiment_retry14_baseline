"""Extend D685 sealing with same-clock GC attribution; no workload score changes."""
import collections
import json
import os
import statistics
import subprocess
import sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d686_pin_gc_attribution'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
qualification=read(RAW/'qualification.json')
assert qualification['passed']
for path,sha in qualification['source_sha256'].items():assert p.digest(Path(path))==sha,path
for phase in ('qualification','start','start2'):
    closure=read(RAW/(phase+'_closure.json'))
    assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()
launch=read(RAW/'native_launch2.json')
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
result=read(RAW/'native_pin2.json')
assert result['pass'] and result['stage']=='complete' and result['kind']=='native_live_pin_gc_attribution_d686_v1'
assert len(result['cases'])==9 and len(result['inventory_equality'])==4
assert all(row['native']==row['direct']==row['expected'] for row in result['cases'])
assert all(row['equal'] for row in result['inventory_equality'])
observation=result['gc_observation']
assert observation['gc_policy_unchanged'] and observation['observer_can_shift_collection_timing']
for key in ('enabled','threshold','freeze_count'):
    assert observation['before'][key]==observation['after'][key]
events=observation['events']
assert len(events)<10000
assert all(event['end_ns']-event['begin_ns']==event['wall_ns']>=0 for event in events)
assert all(a['end_ns']<=b['begin_ns'] for a,b in zip(events,events[1:]))
for generation in range(3):
    count=observation['after']['stats'][generation]['collections']-observation['before']['stats'][generation]['collections']
    assert count==sum(event['generation']==generation for event in events)
rows=result['measurements']
assert len(rows)==40 and all(row['end_ns']-row['begin_ns']==row['wall_ns']>0 for row in rows)
groups={key:[row for row in rows if row['variant']==key] for key in ('native','direct')}
assert all(len(values)==20 and {row['index'] for row in values}==set(range(20)) for values in groups.values())
attribution=[]
for row in rows:
    matching=[]
    for index,event in enumerate(events):
        overlap=max(0,min(row['end_ns'],event['end_ns'])-max(row['begin_ns'],event['begin_ns']))
        if overlap:
            assert event['stage']=='measurement' and event['index']==row['index'] and event['variant']==row['variant']
            matching.append(dict(event_index=index,overlap_ns=overlap,generation=event['generation']))
    overlap=sum(event['overlap_ns'] for event in matching)
    assert 0<=overlap<=row['wall_ns']
    attribution.append(dict(**row,gc_overlap_ns=overlap,gc_wall_fraction=overlap/row['wall_ns'],events=matching))
by_variant={key:{row['index']:row['wall_ns'] for row in values} for key,values in groups.items()}
ratios=[by_variant['direct'][i]/by_variant['native'][i] for i in range(20)]
longest=max(attribution,key=lambda row:row['wall_ns'])
by_stage={}
for event in events:
    key=f"{event['stage']}/{event['variant']}/generation{event['generation']}"
    item=by_stage.setdefault(key,dict(count=0,wall_ns=0,thread_cpu_ns=0))
    item['count']+=1;item['wall_ns']+=event['wall_ns'];item['thread_cpu_ns']+=event['thread_cpu_ns']
summary=dict(passed=True,kind='d686_single_gc_attribution',semantics_passed=True,
    performance_candidate_accepted=False,production_modified=False,formal_performance=False,ci=False,
    cpu_tests=61,native_pin_cases=9,full_graph_equality_cases=4,measurements_per_variant=20,
    gc_policy_unchanged=True,gc_events=len(events),gc_by_stage=by_stage,
    longest_measurement=longest,
    wall_ms={key:dict(mean=statistics.mean(row['wall_ns'] for row in values)/1e6,
        median=statistics.median(row['wall_ns'] for row in values)/1e6,
        min=min(row['wall_ns'] for row in values)/1e6,max=max(row['wall_ns'] for row in values)/1e6)
        for key,values in groups.items()},
    candidate_faster_pairs=sum(r<1 for r in ratios),paired_ratio_median=statistics.median(ratios),
    stop_decision='close pin-query interface direction; do not integrate or run prefix/full workload for this candidate',
    inference_limits=['observed GC overlap explains this diagnostic pause, not historical D685 pause',
        'observer can shift collection timing; no call deleted and no adjusted performance score',
        'native EngineCore freezes startup heap; this no-EngineCore fixture is not its GC state',
        'tiny native tensor correctness, not full model numerical proof'],
    source_sha256=p.digest(RAW/'native_pin2.json'),plan_sha256=p.check_plan(),
    latest_full_3b=dict(run='D682',joint_slo=.9235,native_bound_count=4000,n_correct=None,
        physical_gpu_seconds=15896.253912474262,ranking_eligible=False))
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'summary.json',summary)
save(OUT/'call_gc_attribution.json',attribution)
save(OUT/'native_pin.json',result)
save(OUT/'qualification.json',qualification)
sources=[RAW/'native_pin2.json',RAW/'native_launch2.json',RAW/'qualification.json',RAW/'tests.log',
    RAW/'start_failure.json',RAW.parent/'d685_20261018/native_pin.json',
    ROOT/'docs/ieee_tc/D685_BATCHED_LIVE_PIN_QUALIFICATION.md']
save(OUT/'manifest.json',dict(sources={str(path):p.digest(path) for path in sources},
    no_production_change=True,no_remote_operations=True,no_new_artifacts_or_trace=True,
    observation_only=True,native_attempts=1,pre_service_launch_failures=1))
print(json.dumps(dict(passed=True,gc_events=len(events),longest=longest,wall_ms=summary['wall_ms'],
    candidate_faster_pairs=summary['candidate_faster_pairs'],paired_ratio_median=summary['paired_ratio_median']),indent=2))
