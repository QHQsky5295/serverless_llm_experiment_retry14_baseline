"""Reuse D685 evidence and compile output; only qualify the new observer."""
import ast,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d685_20261018'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);save('qualification_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB) and (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT,RAW],64*p.MIB);save('resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
old=json.loads((OLD/'qualification.json').read_text())
assert old['passed']
for phase in ('qualification','start','analysis','analysis2','publication','publication2'):
    close=json.loads((OLD/(phase+'_closure.json')).read_text())
    assert close['passed'] and close['path_gone'] and not Path(close['identity']['path']).exists()
for path,sha in old['source_sha256'].items():
    if path!=str(ROOT/'scripts/ieee_tc_preflight.py'):assert p.digest(Path(path))==sha,path
assert p.digest(OLD/'native_pin.json')=='e7dd6b39dab3b9eaed32755b2bb742542daef07e7c33c9fbdc861455556b4944'
tests=['tests.test_ieee_tc_gc_observation','tests.test_ieee_tc_pin_batch_witness',
       'tests.test_ieee_tc_preflight.LivePinQueryQualification']
with (RAW/'tests.log').open('x') as log:
    done=subprocess.run([sys.executable,'-B','-m','unittest',*tests,'-v'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
save('test_receipt.json',dict(returncode=done.returncode,log_sha256=p.digest(RAW/'tests.log')))
assert done.returncode==0
paths=[ROOT/'scripts/ieee_tc_preflight.py',ROOT/'scripts/ieee_tc/gc_observation.py',
 ROOT/'tests/test_ieee_tc_gc_observation.py',ROOT/'scripts/ieee_tc/host_pin_batch_witness.py',
 ROOT/'faaslora/memory/gpu_monitor.py',ROOT/'configs/generated/lora_manifest_1000.json',OLD/'native_pin_batch.so']
vllm=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')
paths += [vllm/'utils/gc_utils.py',vllm/'v1/engine/core.py']
for path in RAW.glob('*.py'):ast.parse(path.read_text())
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
save('qualification.json',dict(passed=True,source_sha256={str(path):p.digest(path) for path in paths},
 protected=protected,plan_sha256=p.check_plan(),production_modified=False,new_library_build=False))
print(json.dumps(dict(passed=True,new_library_build=False)))
