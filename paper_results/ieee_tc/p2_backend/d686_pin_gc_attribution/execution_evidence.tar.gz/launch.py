"""Reuse closed D685 launcher; observer is a different explicitly recorded key."""
import hashlib
from pathlib import Path
source=Path(__file__).resolve().parent.parent/'d685_20261018/launch.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='35a4e9044157cf631f0116eb50e88e21ef0240ce080c6725cbe6d1d4ca6faa03'
text=source.read_text()
old="str(RAW/'native_pin_batch.so')"
assert text.count(old)==1
text=text.replace(old,"str(RAW.parent/'d685_20261018/native_pin_batch.so'),'--pin-gc-observation'")
exec(compile(text,str(source),'exec'))
