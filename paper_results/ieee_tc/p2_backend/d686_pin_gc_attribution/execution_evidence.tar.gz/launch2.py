"""Correct supervisor interpreter only; first launch never created a service."""
import hashlib
import json
from pathlib import Path
raw=Path(__file__).resolve().parent
assert not (raw/'native_launch.json').exists()
assert not (raw/'native_launch.launch').exists()
closed=json.loads((raw/'start_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
source=raw.parent/'d685_20261018/launch.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='35a4e9044157cf631f0116eb50e88e21ef0240ce080c6725cbe6d1d4ca6faa03'
text=source.read_text()
old="str(RAW/'native_pin_batch.so')"
assert text.count(old)==1
text=text.replace(old,"str(RAW.parent/'d685_20261018/native_pin_batch.so'),'--pin-gc-observation'")
text=text.replace("'start_identity.json'", "'start2_identity.json'")
text=text.replace("'native_launch.json'", "'native_launch2.json'")
text=text.replace("'native_pin.json'", "'native_pin2.json'")
exec(compile(text,str(source),'exec'))
