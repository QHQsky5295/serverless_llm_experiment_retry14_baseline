"""Reuse D685 explicit small checkpoint checks, including relative launch evidence."""
import json
import os
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d686_pin_gc_attribution'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'publication_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='32225851a83581e5e73c4d472c8f0d84f8244ac8'
summary=read(OUT/'summary.json')
assert summary['passed'] and summary['semantics_passed'] and not summary['performance_candidate_accepted']
assert not subprocess.check_output(['git','diff','--name-only','--','faaslora'],cwd=ROOT,text=True).strip()
qualification=read(RAW/'qualification.json')
for path,sha in qualification['source_sha256'].items():assert p.digest(Path(path))==sha,path
for path,sha in read(OUT/'manifest.json')['sources'].items():assert p.digest(Path(path))==sha,path
for phase in ('qualification','start','start2','analysis'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
    assert not Path(closed['identity']['path']).exists()
launch=read(RAW/'native_launch2.json')
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
for path,sha in launch['evidence_sha256'].items():assert p.digest(RAW/'native_launch2.launch'/path)==sha,path
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}',data)
members=sorted(RAW.glob('*.py'))+sorted(RAW.glob('*.json'))+sorted(RAW.glob('*.log'))
members+=sorted((RAW/'native_launch2.launch').glob('*'))
members=[path for path in members if path.is_file()]
with tarfile.open(OUT/'execution_evidence.tar.gz','x:gz') as archive:
    for path in members:
        check(path.read_bytes());archive.add(path,arcname=str(path.relative_to(RAW)))
with tarfile.open(OUT/'execution_evidence.tar.gz','r:gz') as archive:
    for path in members:assert archive.extractfile(str(path.relative_to(RAW))).read()==path.read_bytes()
save(OUT/'completion.json',dict(passed=True,production_unchanged=True,protected=protected,
    native_result_sha256=p.digest(RAW/'native_pin2.json'),native_launch_sha256=p.digest(RAW/'native_launch2.json'),
    evidence_members={str(path.relative_to(RAW)):p.digest(path) for path in members},
    native_attempts=1,pre_service_launch_failures=1,no_figure=True,no_backbone_or_remote_operation=True))
data_files=sorted(path for path in OUT.iterdir() if path.is_file())
with (OUT/'result.sha256').open('x') as f:
    for path in data_files:f.write(p.digest(path)+'  '+str(path.relative_to(ROOT))+'\n')
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D686_PIN_GC_ATTRIBUTION.md',
    'scripts/ieee_tc_preflight.py','scripts/ieee_tc/gc_observation.py','tests/test_ieee_tc_gc_observation.py']
names += [str(path.relative_to(ROOT)) for path in sorted(OUT.iterdir()) if path.is_file()]
assert 'configs/generated/lora_manifest_1000.json' not in names
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['sha256sum','-c',str(OUT/'result.sha256')],cwd=ROOT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: attribute bounded pin diagnostic pause without production adoption (D686)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity))
print(json.dumps(dict(passed=True,head=head,remote_equal=True,files=len(names))))
