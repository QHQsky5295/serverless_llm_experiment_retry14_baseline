"""Reuse sealed explicit-path publication for the offline consumer/turn audit."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path(__file__).resolve().parent.parent/'d612_20261017/publish.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=data.decode()
for old,new in (
    ('d612_w2_quality_resource_diagnosis','d691_state_query_consumers'),
    ('f72091155cd3bb258651fc461db11b9113c72faf','43ca1d70157c79b6d71b9d769c21e6c69fca3f55'),
    ("assert sum(x['n'] for x in diagnosis['matched_transitions'].values())==8000//2",
     "assert len(diagnosis['caller_inventory'])==9 and diagnosis['span_count']==312160"),
    ("assert diagnosis['runs']['D607']['all']['joint']==3762",
     "assert diagnosis['input_turn_groups']['work_with_utility']['n']==9670"),
    ("assert diagnosis['runs']['D611']['all']['joint']==3819",
     "assert diagnosis['input_turn_groups']['work_with_utility']['multiple_utilities']==0 and diagnosis['tests_passed']==23"),
    ('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md','D691_STATE_QUERY_CONSUMER_AUDIT.md'),
    ("files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json')])",
     "files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),RAW/'analysis_tests.txt'])"),
    ("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']",
     "files += [doc,RAW.parent/'d668_20261018/close.py',RAW.parent/'d612_20261017/publish.py']"),
    ('d612_reused_parent_closed_log_diagnosis_v1','d691_retained_state_consumer_and_interleave_audit_v1'),
    ('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
     'tc: audit state-query consumers and current native interleave without replay (D691)'),
):
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new)
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D691 explicit-path publication expansion passed; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no args or --check-only')
