"""Reuse D673 sealed diagnosis for D672 versus D677; no inference or policy edit."""
import ast
import hashlib
from pathlib import Path
import sys

RAW = Path(__file__).resolve().parent
BASE = RAW.parent
source = BASE/'d673_20261018/diagnose.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'e6751aa6d08902e6ada7e4de902748e0f47851f378a1df5ae0358767fe05cdf1'
tree = ast.parse(data)
assert isinstance(tree.body[-1], ast.If)
tree.body.pop()  # Suppress only D673's final execution/check-only branch.
outer = {'__file__': __file__, '__name__': '__d678_checked_expansion__'}
exec(compile(tree, str(source), 'exec'), outer)
projection, receipts, tail = outer['projection'], outer['receipts'], outer['tail']
env = outer['env']

def once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)

for old, new in (
    ('d672', 'd677'), ('D672', 'D677'), ('d673', 'd678'),
    ('df21f561a8122fce11fe76b44562ead36dd09eab3e8a503e5e1201a0130523b6',
     'f05af02c00646b113528718420915b9d62167538f1eb240f1ddbed5ebf62357c'),
    ('3647', '3628'),
):
    assert old in projection, old
    projection = projection.replace(old, new)
for old, new in (
    ('d672', 'd677'), ('D672', 'D677'), ('d673', 'd678'), ('3647', '3628'),
    ('001f39cd1705de16ed345b33c748d0e3bc7d3e4a76a7ba373d650696b5857c5a',
     'd8074668058863c57e157e66f53e9dbf557c90ecc09f5629918326d85034f611'),
):
    assert old in receipts, old
    receipts = receipts.replace(old, new)

# Move current-run references first, then use the already checked D672 projection.
for old, new in (
    ("ns1['projections']['D672']", "ns1['projections']['D677']"),
    ('p2_backend/d672_3b_full_w0/', 'p2_backend/d677_3b_full_w0/'),
    ("ns1['runs']['D672']", "ns1['runs']['D677']"),
    ("'D672':{k:v for k,v in new_run.items()", "'D677':{k:v for k,v in new_run.items()"),
    ("RAW/'d672_projection.json'", "RAW/'d677_projection.json'"),
    ("BASE/'d666_20261018/d665_projection.json'", "BASE/'d673_20261018/d672_projection.json'"),
    ("BASE/'d666_20261018/request_receipts2.json'", "BASE/'d673_20261018/request_receipts2.json'"),
    ("BASE/'d666_20261018/projection_diagnosis.json'", "BASE/'d673_20261018/projection_diagnosis.json'"),
    ('b642a0da3830e376fd0439a336309ad42f14b46d8353dcea82864b84e38e7ede',
     '3f721c2fb0b3c91ba7b47ea36ac221d906dca807d6b357a4db5922108d9e634d'),
    ('ffa699fc4987640740045313d2cb06b794580748ccd6c098ffcef83ed96e6c62',
     '1f54a0b28db829dffd53f4fcea9a92c0fbfc2f40cb600b12fb60c98ec185fb7e'),
    ('2d3c7c72cf570e5656e09ad378ac654fcc9a935c8adfbac1086f6dec11909842',
     '6b50f855084c4dc190c72b996410f2f233fc124b7c0b7edcac8380d2be27f827'),
    ("read(old_diagnosis)['runs']['D665']", "read(old_diagnosis)['runs']['D672']"),
    ("runs={'D665':", "runs={'D672':"),
    ('== 97', '== -19'),
    ('len(host_ids)==1396', 'len(host_ids)==1438'),
    ("optimized_host['chains_valid']==1396", "optimized_host['chains_valid']==1438"),
    ('d673_independent_host_copy_and_residual_slo_v1', 'd678_proactive_host_candidate_retained_outcome_v1'),
):
    tail = once(tail, old, new)
for expanded in (projection, receipts, tail):
    ast.parse(expanded)
env['projection_code'], env['receipt_code'] = projection, receipts
env['SOURCES'][source] = hashlib.sha256(data).hexdigest()
if sys.argv[1:] == ['--check-only']:
    print('D678 checked D673 reuse and D672/D677 identities; no analysis or writes.')
elif not sys.argv[1:]:
    exec(compile(tail, str(source), 'exec'), env)
else:
    raise SystemExit('expected no args or --check-only')
