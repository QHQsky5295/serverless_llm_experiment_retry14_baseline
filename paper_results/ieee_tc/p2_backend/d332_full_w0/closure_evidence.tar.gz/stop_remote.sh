#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
raw=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d332_20261008
jq -e '.pass and .native_gpu_context_release_confirmed and .service_path_removed' "$raw/7b_full_w0/launch.json" >/dev/null
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
ssh -o BatchMode=yes primelora-artifact-174 /bin/bash <<'REMOTE' > "$raw/remote_stop.log" 2>&1
set -euo pipefail
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d332-full1.service)
ids=(c0482664740240c3a541b56fd221e5f6 9c737a91fec44fa7bbf7390772b6cdad 37266b0a3731471fbab348cd78b02f9b)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
done
systemctl --user stop "${units[2]}"
for i in 0 1; do
  state=$(systemctl --user show "${units[$i]}" -p ActiveState --value)
  if test "$state" != inactive; then
    test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
    systemctl --user stop "${units[$i]}"
  fi
done
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
  systemctl --user show "$unit" -p Id -p ActiveState -p MainPID -p Result
done
test -z "$(ss -ltnH '( sport = :18080 or sport = :18081 )')"
grep -l 'remote-process-monotonic:1106bcf2cf934df29e987e73654810fa' /home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-*.jsonl
sha256sum /home/lab14/primelora_remote/tc/d332_20261008_full1/remote_monitor.log
REMOTE
