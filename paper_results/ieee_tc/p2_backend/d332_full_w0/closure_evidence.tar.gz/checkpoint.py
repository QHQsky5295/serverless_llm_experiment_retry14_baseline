"""Seal D332 offline audit and exact-owned cleanup, reusing D331 format."""
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
out = p.ROOT/'paper_results/ieee_tc/p2_backend/d332_full_w0'
offline = json.loads((raw/'offline_execution_receipt.json').read_text())
assert offline['pass_all']
identity = offline['identity']
assert p.scope_still_owned(identity)
group = Path(identity['path'])
assert not p.owned_pids(group)
resources = {key:(group/key).read_text() for key in ['memory.peak','memory.events',
    'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events']}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'audit_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,empty_before_stop=True,after='inactive'),f,indent=2)
for subdir in ['validated1','context1']:
    directory = out/subdir
    manifest = json.loads((directory/'manifest.json').read_text())
    for name,digest in manifest['outputs'].items():
        assert p.digest(directory/name) == digest
    for ref in manifest['source_refs']:
        assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
paths = [raw/name for name in ['launch_gate1.json','remote_start.log','remote_health.json',
    'remote_stop.log','remote_stop.json','local_cleanup.json','audit_cleanup.json','audit1.log',
    'offline_execution_receipt.json','completion_receipt.json','collect_closure.py','run_audit.py',
    'start_remote.sh','stop_remote.sh','check_remote_health.py','checkpoint.py']]
paths += [raw/'7b_full_w0/launch.json',raw/'7b_full_w0/launch.launch/physical_deployment/summary.json']
paths += [p.ROOT/'scripts/ieee_tc/analyze_d297_full.py',p.ROOT/'scripts/ieee_tc/check_d299_full_context.py']
paths += [p.ROOT/'results/worker_failures/faaslora_worker_b15vmaz6_engine_dead_1791407499/worker.log']
assert len({x.name for x in paths}) == len(paths)
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in paths:
    assert token and token not in path.read_bytes(), path
archive = out/'closure_evidence.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest() == p.digest(path)
record = dict(kind='d332_complete_development_checkpoint_v1',
    executed_source_commit='1134455c146b7cda8a0787b35744e07d6452b49f',
    native_completed=4000,numerical_n_correct=None,formal_qualification=False,
    no_figures=True,archive_sha256=p.digest(archive),
    raw_references=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
    next='Storage safety headroom, then one evidence-backed 7B request-path question; no repeat of D331/D332.')
with (out/'evidence.json').open('x') as f:
    json.dump(record,f,indent=2,allow_nan=False)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
print(json.dumps(dict(native_complete=4000,archive_bytes=archive.stat().st_size,
    archived_files=len(paths),audit_scope_released=True)))
