"""Reuse sealed recursive-empty, exact-identity auxiliary closure."""
import hashlib
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d660_20261018/close.py')
code = source.read_bytes()
assert hashlib.sha256(code).hexdigest() == '2275f5fb7959fb2df7bf13a67cce7f4ebcd226a232ca9d6ecb5ec00d013ca68a'
exec(compile(code, str(source), 'exec'))
