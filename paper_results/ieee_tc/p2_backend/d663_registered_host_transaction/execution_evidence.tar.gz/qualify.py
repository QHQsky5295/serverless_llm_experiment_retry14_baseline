"""D663 bounded extension of D635/D660 qualification, without GPU execution."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

phase = sys.argv[1]
assert phase in ('qualification', 'qualification2', 'analysis')
def save(name, obj):
    with (RAW/name).open('x') as stream:
        json.dump(obj, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(phase+'_identity.json', identity)
group = Path(identity['path'])
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([MAIN], 32*p.GIB)
save(phase+'_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
paths = ['faaslora/memory/gpu_monitor.py', 'faaslora/memory/residency_manager.py',
         'tests/test_ieee_tc_hit_host_transaction.py']
for path in paths:
    ast.parse((MAIN/path).read_text())
tests = ['tests.test_ieee_tc_hit_host_transaction'] if phase == 'qualification' else [
    'tests.test_ieee_tc_gpu_references', 'tests.test_ieee_tc_worker_observation',
    'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_request_lifecycle']
if phase == 'analysis':
    tests = ['tests.test_ieee_tc_host_observation_freshness']
log = RAW/(phase+'.log')
with log.open('x') as stream:
    rc = subprocess.run([sys.executable,'-B','-m','unittest','-v',*tests],cwd=MAIN,
                        stdout=stream,stderr=subprocess.STDOUT).returncode
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
preserved = {
    str(MAIN/'configs/generated/lora_manifest_1000.json'): '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    '/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py': '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    '/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh': '337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
assert all(p.digest(Path(path)) == sha for path,sha in preserved.items())
record = dict(passed=rc == 0 and protected['pass'], returncode=rc, tests=tests,
    scope=identity, log_sha256=p.digest(log), protected=protected, preserved=preserved,
    source_sha256={str(MAIN/path):p.digest(MAIN/path) for path in paths},
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')},
    no_gpu_run=True, performance_conclusion=False)
save(phase+'_receipt.json', record)
print(json.dumps(record,indent=2))
print(log.read_text()[-14000:])
assert record['passed']
