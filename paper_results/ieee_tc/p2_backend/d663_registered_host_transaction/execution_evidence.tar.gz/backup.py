"""Reuse sealed D595 explicit-path candidate backup, with D663 evidence."""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'c16bfc285f6b9ed3f14bd46b730b5c37f0a9c52245f0f90e093fa2c23f34c1c4'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace('d595_parallel_pressure_barrier', 'd663_registered_host_transaction')
code = code.replace('023ae0079e0b2ffa537a81bda7855e8a4b8ede95', '936fffefd5abd68e706330d2f13a88cf64fcd1f6')
start = code.index("reg=read(RAW/'regression2_receipt.json')")
end = code.index('preserved={', start)
code = code[:start] + '''reg=read(RAW/'qualification2_receipt.json')
focused=read(RAW/'qualification_receipt.json')
freshness=read(RAW/'analysis_receipt.json')
for phase in ('qualification','qualification2','analysis'):
    receipt=read(RAW/(phase+'_receipt.json'))
    assert receipt['passed'] and receipt['returncode']==0
    assert p.digest(RAW/(phase+'.log'))==receipt['log_sha256']
    for path,sha in receipt['source_sha256'].items():assert p.digest(Path(path))==sha
    closure=read(RAW/(phase+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
previous=RAW.parent/'d662_20261018/publication_closure.json'
prior_closure=read(previous)
assert prior_closure['passed'] and prior_closure['path_gone']
assert not Path(prior_closure['identity']['path']).exists()
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
''' + code[end:]
start = code.index('members=[RAW/name')
end = code.index('\nfor path in members:', start)
code = code[:start] + '''members=[RAW/name for name in ('qualify.py','close.py','backup.py',
    'qualification_identity.json','qualification_gate.json','qualification.log','qualification_receipt.json','qualification_closure.json',
    'qualification2_identity.json','qualification2_gate.json','qualification2.log','qualification2_receipt.json','qualification2_closure.json',
    'analysis_identity.json','analysis_gate.json','analysis.log','analysis_receipt.json','analysis_closure.json')]
''' + code[end:]
replace("for name in ('focused','regression2')}", "for name in ('qualification','qualification2','analysis')}")
replace("policy='parallel_owner_barrier_v1'", "policy='same_transaction_registered_host_activation_v1'")
replace('focused_before_metadata=focused,aborted_cpu_regression=stopped,protected=protected,',
        "focused=focused,freshness=freshness,protected=protected,\n    prior_publication_closure=dict(path=str(previous),sha256=p.digest(previous),record=prior_closure),")
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['faaslora/memory/gpu_monitor.py','faaslora/memory/residency_manager.py',\n    'tests/test_ieee_tc_hit_host_transaction.py','docs/ieee_tc/EXECUTION_STATUS.md',\n    'docs/ieee_tc/D663_REGISTERED_HOST_TRANSACTION.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: qualify transaction-local HOST activation storage evidence (D663)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D663 sealed candidate backup adaptation parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no args or --check-only')
