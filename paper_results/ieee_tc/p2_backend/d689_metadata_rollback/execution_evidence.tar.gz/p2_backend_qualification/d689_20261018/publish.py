"""D594 explicit-path backup guards reused for D689 exact rollback and closed-evidence storage maintenance."""
import hashlib,json,os,re,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d689_metadata_rollback'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
expected_head='16a5f6943110dfef33eb1c35e2e6b672a9ef50c8'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==expected_head
preserved={ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(path)==sha
qualification=read(RAW/'qualification_receipt.json')
assert qualification['passed'] and qualification['returncode']==0
assert 'Ran 297 tests' in (RAW/'qualification.log').read_text()
for path,sha in qualification['source_sha256'].items():
    assert p.digest(Path(path))==sha,path
for phase in ('qualification','qualification2'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
previous=RAW.parent/'d688_20261018'
pub=read(previous/'publication_receipt.json')
closed=read(previous/'publication_closure.json')
assert pub['passed'] and pub['head']==expected_head and pub['remote']==expected_head
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
current=ROOT/'faaslora/memory/gpu_monitor.py'
restored='213cc94b070a1b3e0b0b1da9decdc5d0ffe0724c36aa57a892619a5c6d6eeb32'
assert p.digest(current)==restored
assert subprocess.check_output(['git','diff','--name-only','--','faaslora'],cwd=ROOT,text=True).splitlines()==['faaslora/memory/gpu_monitor.py']
assert subprocess.check_output(['git','show','5bb08ffb1af21acd50e2fea728335fcae6587a99:faaslora/memory/gpu_monitor.py'],cwd=ROOT)==current.read_bytes()
storage_path=ROOT/'paper_results/ieee_tc/storage/20261018_d689_closed_outcomes.json'
storage=read(storage_path)
verification=read(RAW/'storage_verification.json')
assert verification['passed'] and p.digest(storage_path)==verification['receipt_sha256']
assert len(storage['entries'])==1
row=storage['entries'][0]
assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']
assert not Path(row['source']).exists() and p.digest(Path(row['archive']))==row['archive_sha256']
assert row['allocated_bytes_reclaimed']==1005232128
audit_path=ROOT/'paper_results/ieee_tc/p2_backend/d688_3b_full_w0/completion/audit.json'
assert p.digest(audit_path)=='8ae706f20336ae99e4368482b8dfffd77d7b453b7cafc2dfd2e7a14e4b746f8e'
audit=read(audit_path)
assert audit['passed'] and audit['common_threshold_joint_count']==3645 and audit['stats']['n_correct'] is None
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'summary.json',dict(kind='d689_exact_candidate_rollback_v1',passed=True,
    parent_commit=expected_head,production_restored_sha256=restored,
    rollback_of='cbdf7ecdf05d09677105618e51668de34cc55cc3',
    candidate_system_performance_accepted=False,reason='D688 complete single observation did not improve joint SLO or physical GPU time over D682',
    d688_audit=dict(path=str(audit_path),sha256=p.digest(audit_path)),
    d688_joint_count=3645,d682_joint_count=3694,n_correct=None,ranking_eligible=False,
    new_performance_runs=0,cpu_test_executions=297,
    qualification_sha256=p.digest(RAW/'qualification_receipt.json'),
    historical_candidate_tests_retained=True,current_production_semantic_assertions_retained=True,
    storage_receipt=dict(path=str(storage_path),sha256=p.digest(storage_path)),
    allocated_bytes_reclaimed=row['allocated_bytes_reclaimed'],storage_after=storage['after'],
    next_action='Reuse complete request/stage evidence to identify an unresolved 3B bottleneck; no same-key replay, pin/GC/metadata-format microtuning, threshold change or new baseline search.',
    no_figures=True,full_plan_active=True))
files=['summary.json']
members=[RAW/name for name in ('compress.py','close.py','qualify.py','publish.py',
    'qualification_identity.json','qualification_gate.json','qualification.log',
    'qualification_receipt.json','qualification_closure.json',
    'qualification2_identity.json','qualification2_closure.json','storage_verification.json')]
members += [previous/'publication_receipt.json',previous/'publication_closure.json',
    previous/'3b_full_w0/compression_receipt.json']
baseline=Path('/home/qhq/serverless_llm_baselines')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=baseline,text=True).strip()=='e16af33aaf41f02a62ecdce59f6f3227813244c3'
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
with tarfile.open(OUT/'execution_evidence.tar.gz','x:gz') as bundle:
    for path in members:
        check(path.read_bytes());bundle.add(path,arcname=str(path.relative_to(RAW.parent.parent)),recursive=False)
with tarfile.open(OUT/'execution_evidence.tar.gz') as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(str(path.relative_to(RAW.parent.parent))).read()).hexdigest()==p.digest(path)
files+=['execution_evidence.tar.gz']
with (OUT/'result.sha256').open('x') as f:
    for name in files:f.write(p.digest(OUT/name)+'  '+name+'\n')
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D689_METADATA_ROLLBACK.md',
    'faaslora/memory/gpu_monitor.py','tests/test_ieee_tc_host_metadata_projection.py',
    'paper_results/ieee_tc/storage/20261018_d689_closed_outcomes.json']
names += [str((OUT/name).relative_to(ROOT)) for name in files+['result.sha256']]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: withdraw metadata candidate after complete W0 and preserve evidence (D689)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,identity=identity,files=names,
    protected=protected,preserved={str(k):v for k,v in preserved.items()}))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
