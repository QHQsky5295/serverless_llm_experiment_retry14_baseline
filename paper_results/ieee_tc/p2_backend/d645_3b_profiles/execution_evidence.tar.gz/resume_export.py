"""Continue the sealed offline export; retain the initial schema failure."""
import json, os, subprocess, sys, unittest
from contextlib import redirect_stdout
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
def ref(path):return dict(path=str(path),sha256=p.digest(path))
identity=p.scope_identity(p.cg_path().name);save(RAW/'qualification2_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT,RAW],64*1024*1024);save(RAW/'qualification2_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
closed=read(RAW/'qualification_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
out=ROOT/'paper_results/ieee_tc/p2_backend/d645_3b_profiles'
assert out.is_dir() and not (out/'initialization').exists()
subprocess.run(['sha256sum','-c','measurement_outputs.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
save(RAW/'initial_export_failure.json',dict(passed=False,stage='control_observation_schema',
    exception='KeyError: capacity_before',tool_session=63137,exit_code=1,
    initial_tests=23,closure=ref(RAW/'qualification_closure.json'),
    original_helper=ref(RAW/'prepare_export.py'),original_log=ref(RAW/'export.log'),
    reason='Non-capacity-probe source run has scheduler endpoints, not per-wave capacity snapshots.',
    measurements_modified=False,new_gpu_runs=0))
from tests.test_ieee_tc_control_profile_analysis import (MeasurementSealIsolation, ControlProfileCounterAudit, FileDemandProfileAudit)
from tests.test_ieee_tc_launch import MeasuredSourceProfileExport
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(cls) for cls in (
    MeasurementSealIsolation,ControlProfileCounterAudit,FileDemandProfileAudit,MeasuredSourceProfileExport))
with (RAW/'tests2.log').open('x') as f:result=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
assert result.wasSuccessful()
from scripts.ieee_tc import export_d298_profiles as exporter
with (RAW/'export2.log').open('x') as log:
    with redirect_stdout(log):exporter.main('d644')
manifest=read(out/'initialization/manifest.json')
assert manifest['passed'] and manifest['model']=='3b' and manifest['coverage']['class_domain_covered']
assert manifest['summary']['representative_requests']==360 and manifest['summary']['preparation_requests']==288
control=manifest['control_interleave_audit']
assert control['triggered'] and control['observation_scope']=='source_run_endpoints'
assert control['complete_wave_count']==46 and control['waves'] is None and control['zero_yield_waves'] is None
assert manifest['file_demand_transaction_audit']['request_count']==368
assert not manifest['full_qualified'] and not manifest['common_slo_qualified']
import torch
assert not torch.cuda.is_initialized()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
save(RAW/'qualification.json',dict(passed=True,tests=result.testsRun,no_cuda_initialized=True,
    protected=protected,exporter_sha256=p.digest(ROOT/'scripts/ieee_tc/export_d298_profiles.py'),
    tests_sha256=p.digest(ROOT/'tests/test_ieee_tc_control_profile_analysis.py'),
    manifest=ref(out/'initialization/manifest.json'),new_gpu_runs=0,production_profile_frozen=False,
    full_qualified=False,profiles=manifest['profiles'],summary=manifest['summary'],
    initial_schema_failure=ref(RAW/'initial_export_failure.json')))
print(json.dumps(dict(passed=True,tests=result.testsRun,new_gpu_runs=0,
    coverage=manifest['coverage']['class_domain_covered'],control_delta=control['delta'])))
