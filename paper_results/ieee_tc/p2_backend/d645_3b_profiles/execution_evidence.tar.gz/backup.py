"""Reuse the explicit tested-file checkpoint for the sealed 3B export."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'","OUT=ROOT/'paper_results/ieee_tc/p2_backend/d645_3b_profiles'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'","=='f9e595b456f48b3f719d3b26e4741dcaa236bd17'")
begin=code.index('reg=read(RAW/');end=code.index('preserved={',begin)
code=code[:begin]+'''audit=read(RAW/'qualification.json');assert audit['passed'] and audit['tests']==26
for name,key in [('scripts/ieee_tc/export_d298_profiles.py','exporter_sha256'),('tests/test_ieee_tc_control_profile_analysis.py','tests_sha256')]:
    assert p.digest(ROOT/name)==audit[key]
assert p.digest(Path(audit['manifest']['path']))==audit['manifest']['sha256']
for name in ('qualification','qualification2'):
    closure=read(RAW/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
assert read(RAW/'initial_export_failure.json')['passed'] is False
gate=p.preflight([ROOT],32*1024*1024);assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
''' +code[end:]
begin=code.index('members=[RAW/name');end=code.index('\nfor path in members:',begin)
code=code[:begin]+'''members=[RAW/name for name in ('prepare_export.py','resume_export.py','close.py','backup.py',
    'qualification_identity.json','qualification_gate.json','qualification_closure.json','tests.log','export.log',
    'qualification2_identity.json','qualification2_gate.json','qualification2_closure.json','tests2.log','export2.log',
    'qualification.json','initial_export_failure.json','remote_context.json','backup_gate.json')]
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
''' +code[end:]
replace('OUT.mkdir(parents=True,exist_ok=False)',"assert OUT.is_dir() and read(OUT/'initialization/manifest.json')['passed']")
begin=code.index('test_counts={');end=code.index("save(OUT/'qualification.json'",begin)
code=code[:begin]+'''test_counts={'control_and_profile_export_cpu':26}
record=dict(passed=True,production_candidate=False,native_gpu_validation=False,full_performance_run=False,
    parent_commit='f9e595b456f48b3f719d3b26e4741dcaa236bd17',audit=audit,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='Existing 3B measurements exported offline; no new GPU run, per-wave control attribution or Full/SLO claim.')
''' +code[end:]
outputs="('qualification.json','execution_evidence.tar.gz','source_spec.json','launch_config_binding.json','measurement_checkpoint.json','measurement_outputs.sha256','initialization/service.json','initialization/preparation.json','initialization/manifest.json')"
replace("for name in ('qualification.json','execution_evidence.tar.gz'):f.write",'for name in '+outputs+':f.write')
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['scripts/ieee_tc/export_d298_profiles.py','tests/test_ieee_tc_control_profile_analysis.py','docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D645_3B_MEASURED_PROFILE_EXPORT.md']")
replace("('qualification.json','execution_evidence.tar.gz','result.sha256')",outputs[:-1]+",'result.sha256')")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: export sealed 3B measurements with explicit control observation scope (D645)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
