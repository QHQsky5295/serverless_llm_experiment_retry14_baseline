"""Bind sealed D644 evidence to the unchanged strict export format, CPU only."""
import ast, hashlib, json, os, subprocess, sys, unittest
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
def ref(path):return dict(path=str(path),sha256=p.digest(path))
identity=p.scope_identity(p.cg_path().name);save(RAW/'qualification_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT,RAW],64*1024*1024);save(RAW/'qualification_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
source_raw=RAW.parent/'d644_20261017'
measurement=ROOT/'paper_results/ieee_tc/p2_backend/d644_3b_admission_source'
prepared=ROOT/'paper_results/ieee_tc/p2_backend/d643_3b_initializer'
out=ROOT/'paper_results/ieee_tc/p2_backend/d645_3b_profiles'
assert not out.exists()
for directory in (measurement,prepared):
    subprocess.run(['sha256sum','-c','result.sha256'],cwd=directory,check=True,stdout=subprocess.DEVNULL)
seal=read(measurement/'qualification.json');audit=seal['audit']
assert seal['passed'] and audit['passed'] and audit['admission_enabled_timing_verified']
assert audit['coverage']['class_domain_covered'] and audit['request_cases']==368
assert p.digest(Path(seal['source_run']['path']))==seal['source_run']['sha256']
assert seal['source_run']['sha256']=='d0c6d29b839196c7f96936d5943554e72daf30bd52fb6362fb255304bc995b65'
for name,sha in audit['evidence'].items():assert p.digest(source_raw/name)==sha
for name in ('start','analysis','backup'):
    closure=read(source_raw/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
assert not Path(read(source_raw/'local_cleanup.json')['identity']['path']).exists()
assert read(source_raw/'remote_stop.json')['all_owned_units_inactive']
config=ROOT/'configs/ieee_tc/20261017_d641_3b_native_source.yaml'
inputs=[prepared/name for name in ('source_spec.json','development_contract.json','prepare.json','completed_length_audit.json')]+[config]
execution=(source_raw/'source_commit.txt').read_text().strip()
assert execution=='143b5ac066a3716ef14dc42d5187a5bfeb4b1f01'
for path in inputs:
    committed=subprocess.check_output(['git','show',execution+':'+str(path.relative_to(ROOT))],cwd=ROOT)
    assert hashlib.sha256(committed).hexdigest()==p.digest(path)
remote_script='/home/lab14/primelora_remote/tc/a125b54a6cd2436ea3784d8ead859eca55be9ad4/server.py'
remote_sha=subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','sha256sum',remote_script],text=True).split()[0]
assert remote_sha=='a31fa9212143914f5a7fb21dea126a23eaafedffe199ff9513de9ce03eb62a2c'
remote_units=subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','systemctl','--user','show',
    'primelora-artifact-tc-3b.service','-p','ActiveState','-p','CPUAffinity','-p','MemoryHigh','-p','MemoryMax','-p','MemorySwapMax'],text=True)
assert 'ActiveState=inactive' in remote_units and 'CPUAffinity=2-19 22-39' in remote_units
assert 'MemoryHigh=2147483648' in remote_units and 'MemoryMax=4294967296' in remote_units and 'MemorySwapMax=0' in remote_units
assert (source_raw/'remote_start.log').read_text().startswith('1000\nfull\n')
save(RAW/'remote_context.json',dict(server_sha256=remote_sha,current_unit_properties=remote_units,
    historical_start=ref(source_raw/'remote_start.log'),read_only=True,services_started=False))
from tests.test_ieee_tc_control_profile_analysis import (MeasurementSealIsolation, ControlProfileCounterAudit, FileDemandProfileAudit)
from tests.test_ieee_tc_launch import MeasuredSourceProfileExport
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(cls) for cls in (
    MeasurementSealIsolation,ControlProfileCounterAudit,FileDemandProfileAudit,MeasuredSourceProfileExport))
with (RAW/'tests.log').open('x') as f:result=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
assert result.wasSuccessful()
out.mkdir(parents=True,exist_ok=False)
with (out/'source_spec.json').open('xb') as f:f.write((prepared/'source_spec.json').read_bytes())
assert p.digest(out/'source_spec.json')==p.digest(prepared/'source_spec.json')
save(out/'launch_config_binding.json',dict(passed=True,source_config=ref(config),
    kind='sealed_source_launch_binding_v1',source_execution_commit=execution,
    source_run=seal['source_run'],preparation=ref(prepared/'prepare.json'),
    copied_spec_bytes_unchanged=True,controller_recalibrated=False))
refs=inputs+[measurement/'qualification.json',measurement/'result.sha256',
    source_raw/'measurement_audit.json',source_raw/'backup_receipt.json',RAW/'remote_context.json']
save(out/'measurement_checkpoint.json',dict(passed=True,measurement_complete=True,profile_complete=True,
    full_qualified=False,source_execution_commit=execution,source_run=seal['source_run'],
    source_refs=[ref(path) for path in refs],reused_measurement_checkpoint=ref(measurement/'qualification.json'),
    new_gpu_runs=0,plan_sha256=p.check_plan()))
with (out/'measurement_outputs.sha256').open('x') as f:
    for name in ('source_spec.json','launch_config_binding.json','measurement_checkpoint.json'):
        f.write(p.digest(out/name)+'  '+name+'\n')
from scripts.ieee_tc import export_d298_profiles as exporter
with (RAW/'export.log').open('x') as log:
    from contextlib import redirect_stdout
    with redirect_stdout(log):exporter.main('d644')
manifest=read(out/'initialization/manifest.json')
assert manifest['passed'] and manifest['model']=='3b' and manifest['coverage']['class_domain_covered']
assert manifest['summary']['representative_requests']==360 and manifest['summary']['preparation_requests']==288
assert manifest['control_interleave_audit']['triggered']
assert manifest['file_demand_transaction_audit']['request_count']==368
assert not manifest['full_qualified'] and not manifest['common_slo_qualified']
import torch
assert not torch.cuda.is_initialized()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
save(RAW/'qualification.json',dict(passed=True,tests=result.testsRun,no_cuda_initialized=True,
    protected=protected,exporter_sha256=p.digest(ROOT/'scripts/ieee_tc/export_d298_profiles.py'),
    manifest=ref(out/'initialization/manifest.json'),new_gpu_runs=0,production_profile_frozen=False,
    full_qualified=False,profiles=manifest['profiles'],summary=manifest['summary']))
print(json.dumps(dict(passed=True,tests=result.testsRun,service_classes=manifest['coverage']['measured_service_classes'],
    preparation_classes=manifest['coverage']['measured_preparation_classes'],new_gpu_runs=0)))
