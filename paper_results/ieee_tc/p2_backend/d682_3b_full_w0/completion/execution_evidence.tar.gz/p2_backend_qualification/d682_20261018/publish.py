"""D594 explicit-path backup guards reused for D682 complete 3B Full W0 with HOST lease transfer."""
import hashlib,json,os,re,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d682_3b_full_w0/completion'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
expected_head='070204ad26af8e9ed4549292108f53fc7f1b9342'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==expected_head
preserved={ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(path)==sha
audit=read(RAW/'analysis1.log')
assert audit['passed'] and audit['protocol_bound_count']==4000
assert audit['native_tokens']==458224
assert audit['proactive_host_transaction']['passed']
assert audit['host_lease_transfer']['passed'] and audit['host_lease_transfer']['count']>0
assert audit['fixed_workload_complete4000'] and not audit['ranking_eligible']
assert audit['stats']['n_correct'] is None
for ref in audit['refs']:assert p.digest(Path(ref['path']))==ref['sha256']
assert read(RAW/'analysis_receipt.json')['passed']
for phase in ('start','analysis'):
    closure=read(RAW/(phase+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
local=read(RAW/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
remote=read(RAW/'remote_stop.json')
assert remote['all_owned_units_inactive'] and remote['download_hashes_match_remote']
OUT.mkdir(parents=True,exist_ok=False)
with (OUT/'audit.json').open('xb') as stream:stream.write((RAW/'analysis1.log').read_bytes())
assert p.digest(OUT/'audit.json')==p.digest(RAW/'analysis1.log')
files=['audit.json']
members=[RAW/x for x in ('start.py','close.py','close_launch.py','start_remote.sh',
    'stop_remote.sh','check_remote_health_stdlib.py','collect_closure.py','analyze.py',
    'run_analysis.py','publish.py','launch_gate.json','model_cache_metadata_before.json',
    'start_identity.json','start_receipt.json','start_closure.json','service_aux_identity.json',
    'local_cleanup.json','remote_health.json','remote_start.log','remote_stop.log','remote_stop.json',
    'collection_receipt.json','collection1.log','completion_receipt.json',
    'analysis_identity.json','analysis_receipt.json','analysis_closure.json')]
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT.parent,check=True,stdout=subprocess.DEVNULL)
for phase in ('qualification','backup','start','management','analysis'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
members += [RAW/name for name in ('backup_identity.json','backup_receipt.json','backup_closure.json',
    'stop_services.py','close_management.py','management_identity.json','management_closure.json')]

# Compare complete observations, not the shorter qualification prefix.
for path, sha in read(RAW/'qualification.json')['refs'].items():
    assert p.digest(Path(path)) == sha, path
comparison_names=[]
for campaign,expected_sha in (
    ('d677','f05af02c00646b113528718420915b9d62167538f1eb240f1ddbed5ebf62357c'),
    ('d672','df21f561a8122fce11fe76b44562ead36dd09eab3e8a503e5e1201a0130523b6'),
):
    previous_path=ROOT/f'paper_results/ieee_tc/p2_backend/{campaign}_3b_full_w0/completion/audit.json'
    assert p.digest(previous_path)==expected_sha
    previous=read(previous_path)
    assert previous['workload_identity']==audit['workload_identity']
    assert previous['native_tokens']==audit['native_tokens']
    metrics=('mean_ttft_ms','p95_ttft_ms','mean_tpot_ms','p95_tpot_ms','mean_e2e_ms','physical_gpu_seconds')
    comparison=dict(kind=f'd682_vs_{campaign}_complete_w0_single_observation_v1',
        previous_audit=dict(path=str(previous_path),sha256=expected_sha),
        current_audit_sha256=p.digest(RAW/'analysis1.log'),
        workload_identity=audit['workload_identity'],native_tokens=audit['native_tokens'],
        previous_joint_count=previous['common_threshold_joint_count'],
        current_joint_count=audit['common_threshold_joint_count'],
        joint_delta_percentage_points=(audit['common_threshold_joint_count']-previous['common_threshold_joint_count'])/40,
        metrics=[dict(metric=k,previous=previous['stats'][k],current=audit['stats'][k],
            lower_better_improvement_percent=100*(previous['stats'][k]-audit['stats'][k])/previous['stats'][k]) for k in metrics],
        previous_stage_means_ms=previous['stage_means_ms'],current_stage_means_ms=audit['stage_means_ms'],
        previous_phases=previous['source_order_phases'],current_phases=audit['source_order_phases'],
        previous_remote_transfers=previous['remote_transfers'],current_remote_transfers=audit['remote_transfers'],
        previous_remote_wire_bytes=previous['remote_wire_bytes'],current_remote_wire_bytes=audit['remote_wire_bytes'],
        observed_joint_and_resource_improvement=audit['common_threshold_joint_count']>previous['common_threshold_joint_count'] and audit['stats']['physical_gpu_seconds']<previous['stats']['physical_gpu_seconds'],
        accepted_as_final=False,confidence_interval=None,independent_holdout=False,
        caveat='Known fixed workload, one observation per version. Retain all gains and regressions. No causal percentage attribution, numerical-proof upgrade or complete G1/G2 claim.')
    name=f'comparison_{campaign}.json'
    save(OUT/name,comparison)
    files.append(name)
    comparison_names.append(name)

save(OUT/'manifest.json',dict(passed=True,kind='d682_3b_host_lease_transfer_full_w0_seal_v1',
    source_audit_sha256=p.digest(RAW/'analysis1.log'),source_commit=expected_head,
    performance_runs=1,complete4000=True,formal_qualification=False,n_correct=None,
    numerical_proof_unknown=True,ranking_eligible=False,
    n_native_bound=4000,joint_slo_count=audit['common_threshold_joint_count'],
    joint_slo_pass=audit['common_threshold_joint_count']>=3800,
    physical_gpu_seconds=audit['stats']['physical_gpu_seconds'],
    comparisons_sha256={name:p.digest(OUT/name) for name in comparison_names},
    host_lease_transfer=audit['host_lease_transfer'],
    immutable_prelaunch_manifest_sha256=p.digest(OUT.parent/'result.sha256'),
    no_figures=True,no_runtime_source_change=True,
    outputs={'audit.json':p.digest(OUT/'audit.json')},
    next_action='Compare this complete observation with D677 and D672. Continue the evidence-based 3B main line; no same-key repeats or threshold changes. W1/W2 and numerical qualification remain open.'))
files+=['manifest.json']
baseline=Path('/home/qhq/serverless_llm_baselines')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=baseline,text=True).strip()=='e16af33aaf41f02a62ecdce59f6f3227813244c3'
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
with tarfile.open(OUT/'execution_evidence.tar.gz','x:gz') as bundle:
    for path in members:
        check(path.read_bytes());bundle.add(path,arcname=str(path.relative_to(RAW.parent.parent)),recursive=False)
with tarfile.open(OUT/'execution_evidence.tar.gz') as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(str(path.relative_to(RAW.parent.parent))).read()).hexdigest()==p.digest(path)
files+=['execution_evidence.tar.gz']
with (OUT/'result.sha256').open('x') as f:
    for name in files:f.write(p.digest(OUT/name)+'  '+name+'\n')
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D682_3B_FULL_W0.md']
names += [str((OUT/name).relative_to(ROOT)) for name in files+['result.sha256']]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: seal complete 3B HOST lease transfer observation (D682)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,identity=identity,files=names,
    protected=protected,preserved={str(k):v for k,v in preserved.items()}))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
