"""Reuse D658/D660 assembly and D663 tests for one full W0 replay."""
import ast
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import yaml

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d682_3b_full_w0'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate=p.preflight([ROOT],32*p.GIB)
save(RAW/'resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
prior=RAW.parent/'d681_20261018'
refs={}
receipt=read(prior/'analysis_receipt.json')
assert receipt['passed'] and receipt['returncode']==0
assert p.digest(prior/'analysis.log')==receipt['log_sha256']
for path,sha in receipt['source_sha256'].items():
    assert p.digest(Path(path))==sha,path
    refs[path]=sha
for path,sha in receipt['preserved'].items():assert p.digest(Path(path))==sha
old_receipt=read(RAW.parent/'d680_20261018/qualification2_receipt.json')
for path,sha in old_receipt['source_sha256'].items():
    if path not in refs:
        assert p.digest(Path(path))==sha,path
        refs[path]=sha
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='c0e53d6b0c472fbec109b1ee434c397f7b00117a'
assert not subprocess.check_output(['git','diff','--name-only','69e6da68f9a0d0337a1dbbd70f0a3edee4772121','HEAD','--',
    'faaslora','scripts/run_all_experiments.py','tests'],cwd=ROOT,text=True).strip()
native_audit_path=ROOT/'paper_results/ieee_tc/p2_backend/d681_3b_full_smoke100/completion/audit.json'
native_audit=read(native_audit_path)
assert native_audit['passed'] and native_audit['protocol_bound_count']==100
assert native_audit['host_lease_transfer']['passed'] and native_audit['host_lease_transfer']['count']==23
for ref in native_audit['refs']:assert p.digest(Path(ref['path']))==ref['sha256']
for phase in ('qualification','analysis','qualification2','backup','start','management','analysis2','analysis3','publication'):
    closed=read(prior/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert read(prior/'remote_stop.json')['all_owned_units_inactive']
assert read(prior/'local_cleanup.json')['passed']
assert read(prior/'publication_receipt.json')['head']=='c0e53d6b0c472fbec109b1ee434c397f7b00117a'
refs[str(native_audit_path)]=p.digest(native_audit_path)
for path,sha in {
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'paper_results/ieee_tc/protocols/20261017_3b_slo_d648_frozen.json':'d15123570c4a8d830515ca942d1db553c6717ffc1a40ade5c1546d35e2bed9d8',
    ROOT/'paper_results/ieee_tc/main_comparison/d657_3b_references/resident_references.json':'f030f92f7bc426c427c6fa0ea65c8dd315a39cf52fd922973fc507117f30ea7a',
}.items():
    assert p.digest(path)==sha,path
    refs[str(path)]=sha
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
text=shell.read_text()
start=text.index('  d682)\n');end=text.index('    ;;\n',start)+len('    ;;\n')
restored=text[:start]+text[end:]
assert restored.count(' || "${1:-d293}" == d682')==2
restored=restored.replace(' || "${1:-d293}" == d682','')
assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
for path in [shell,*RAW.glob('*.sh')]:subprocess.run(['bash','-n',str(path)],check=True)
for path in RAW.glob('*.py'):ast.parse(path.read_text())
old_config=ROOT/'configs/ieee_tc/20261018_d681_3b_full_smoke100.yaml'
config=ROOT/'configs/ieee_tc/20261018_d682_3b_full_w0.yaml'
assert config.read_text()==old_config.read_text().replace('d681','d682').replace('smoke100','w0').replace('total_requests: 100','total_requests: 4000')
cfg=yaml.safe_load(config.read_text())
prepared_path=ROOT/'paper_results/ieee_tc/p2_backend/d658_3b_full_entry/preparation.json'
prepared=read(prepared_path)
assert prepared['passed']
for item in prepared['sources']:
    assert p.digest(Path(item['path']))==item['sha256']
src={item['role']:Path(item['path']) for item in prepared['sources']}
from scripts.ieee_tc.prepare_d298_capacity import assemble_3b_current_full
from scripts.run_all_experiments import ScenarioRunner,_prepare_scenario_runtime_model_config
assembled,child,env=assemble_3b_current_full(yaml.safe_load(src['previous'].read_text()),
    read(src['contract']),read(src['profiles']),output_dir=cfg['experiment']['output_dir'],
    nvme_dir=cfg['storage']['nvme_cache_dir'],host_dir=cfg['storage']['host_cache_dir'],count=4000)
assembled['resource_coordination']['ieee_host_lease_transfer']='same_owner_host_to_gpu_v1'
assert assembled==cfg
assert child==prepared['planned_child_model_config'] and env==prepared['child_environment']
assert not any('timing' in key and key!='timing_contract' for key in cfg['model'])
observer_guard=next(line for line in text.splitlines() if line.startswith('if [[') and '== d328' in line)
assert 'd682' not in observer_guard
runner=ScenarioRunner.__new__(ScenarioRunner)
runner.coord_cfg=cfg['resource_coordination'];runner._initial_runtime_pending=True
runner.model_cfg=_prepare_scenario_runtime_model_config(cfg['model'],cfg['workload'],runner.coord_cfg)
runner._service_profiles=runner._load_ieee_service_profiles()
assert runner._load_ieee_preparation_profiles() is not None
from faaslora.datasets.workload_generator import FrozenReplayPlan
plan=FrozenReplayPlan.load(prepared['source_plan']['source_path'],count=4000,profile='W0')
assert plan.source_sha256==prepared['source_plan']['source_sha256']
assert plan.identity()['view_sha256']=='0d998f48a006d638dda9b8d714f667fe3a87f4d2c88044ce19a816b308494a37'
assert not (RAW/'3b_full_w0').exists() and not Path(cfg['storage']['host_cache_dir']).exists()
assert not Path(cfg['storage']['nvme_cache_dir']).exists()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
OUT.mkdir(parents=True,exist_ok=False)
prepared=copy.deepcopy(prepared)
prepared.update(kind='d682_same_owner_host_lease_transfer_full_w0_v1',
    source_plan=plan.identity(),
    configuration=dict(path=str(config),sha256=p.digest(config)),
    candidate_parent='c0e53d6b0c472fbec109b1ee434c397f7b00117a',
    unchanged_non_target_configuration=True)
save(OUT/'preparation.json',prepared)
paths=[shell,config,old_config,prepared_path,OUT/'preparation.json',*src.values(),
       ROOT/'scripts/run_all_experiments.py',ROOT/'scripts/ieee_tc/prepare_d298_capacity.py',
       ROOT/'faaslora/experiment/instance_pool.py',ROOT/'faaslora/datasets/workload_generator.py',
       ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json']
paths+=sorted(RAW.glob('*.py'))+sorted(RAW.glob('*.sh'))
refs.update({str(path):p.digest(path) for path in paths})
record=dict(passed=True,count=4000,reused_cpu_tests=527,reused_scope_tests=71,reused_native_method_tests=72,no_gpu_run=True,
    same_configuration_as_d681_except_population_and_paths=True,unchanged_historical_shell_branches=True,
    source_plan=plan.identity(),planned_child_model_config=child,child_environment=env,
    configuration=prepared['configuration'],refs=refs,protected=protected,identity=identity,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')})
save(RAW/'qualification.json',record)
save(OUT/'prelaunch.json',dict(passed=True,count=4000,full_performance_complete=False,
    qualification_sha256=p.digest(RAW/'qualification.json'),configuration=prepared['configuration'],
    candidate_parent=prepared['candidate_parent'],no_new_input_or_profile=True))
print(json.dumps(dict(passed=True,count=4000,source_plan=plan.identity(),resources=record['resources'])))
