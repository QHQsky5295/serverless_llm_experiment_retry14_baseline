"""D340: strict D336 delta and existing profile/protection/resource checks."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
import yaml
from scripts import ieee_tc_preflight as p
from scripts.run_all_experiments import (ScenarioRunner,
    _prepare_scenario_runtime_model_config, _prepare_dedicated_subprocess_model_cfg)
RAW = Path(__file__).resolve().parent
receipt = json.loads((RAW/'candidate_cpu1.json').read_text())
assert receipt['unit_returncode'] == receipt['native_entry_returncode'] == 0
assert receipt['after']['memory.events'] == receipt['before']['memory.events']
assert receipt['after']['memory.swap.current'] == '0'
old = receipt['identity']
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
closed = {k:(Path(old['path'])/k).read_text().strip() for k in
    ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
with (RAW/'cpu_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,resources=closed,inactive=True),f,indent=2)
config = p.ROOT/'configs/ieee_tc/20261008_d340_7b_prebuild_validation_100.yaml'
previous = p.ROOT/'configs/ieee_tc/20261008_d336_7b_full_w0.yaml'
c, prior = (yaml.safe_load(x.read_text()) for x in (config,previous))
expected = copy.deepcopy(prior)
for section, field in [('experiment','output_dir'),('storage','nvme_cache_dir'),('storage','host_cache_dir')]:
    assert not Path(c[section][field]).exists()
    expected[section][field] = c[section][field]
expected['model']['ieee_quantization_prebuild_policy'] = 'on_demand_v1'
assert c == expected
configured = _prepare_scenario_runtime_model_config(c['model'],c['workload'],c['resource_coordination'])
child, assembly = _prepare_dedicated_subprocess_model_cfg(configured,device_id=0,runtime_gpu_ids=[0])
old_contract = json.loads((p.ROOT/'paper_results/ieee_tc/p2_backend/d298_capacity/development_contract.json').read_text())['model_config']
assert child == {**old_contract,'ieee_quantization_prebuild_policy':'on_demand_v1'}
bound = ScenarioRunner.__new__(ScenarioRunner)
bound.model_cfg, bound.engine = child, SimpleNamespace(model_cfg=child)
bound.coord_cfg = c['resource_coordination']
bound._service_profiles = bound._load_ieee_service_profiles()
assert len(bound._service_profiles.profiles) == 160
assert len(bound._load_ieee_preparation_profiles().profiles) == 24
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(p.ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(p.ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
seal = p.verify_seal(p.ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = '/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert seal['entry_count'] == 147 and seal['changed'] == [known]
assert p.digest(Path(known)) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
gate = p.preflight([p.ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
native = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages')
sources = [config,previous,p.ROOT/'scripts/run_all_experiments.py',
    p.ROOT/'scripts/dedicated_engine_worker.py',p.ROOT/'faaslora/runtime_configuration.py',
    p.ROOT/'faaslora/experiment/instance_pool.py',p.ROOT/'tests/test_ieee_tc_launch.py',
    p.ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    *[native/path for path in ('humming/utils/jit.py','humming/utils/nvrtc.py',
        'humming/ops/utils.py','vllm/utils/system_utils.py','vllm/v1/engine/core_client.py')]]
with (RAW/'prelaunch_binding.json').open('x') as f:
    json.dump(dict(kind='d340_prelaunch_binding_v1',passed=True,model_config=child,
        assembly=assembly,changed_policy_fields=['ieee_quantization_prebuild_policy'],
        source_references=[dict(path=str(x),sha256=p.digest(x)) for x in sources],
        preflight=gate,protected=seal,source_requests=4000,diagnostic_prefix_count=100,
        formal_qualification=False,numerical_n_correct=None),f,indent=2)
identity = p.scope_identity(p.cg_path().name)
with (RAW/'prelaunch_scope.json').open('x') as f:
    json.dump(dict(identity=identity,resources={k:(Path(identity['path'])/k).read_text().strip()
        for k in ('memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(passed=True,service_classes=160,preparation_classes=24,
    disk=gate['filesystems'][0]['free_bytes'],memory=gate['memory']['MemAvailable'])))
