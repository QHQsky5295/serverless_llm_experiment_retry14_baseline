"""Seal D339 negative evidence and D340 tested candidate, exact-path V2 backup."""
import ast
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
PRIOR = RAW.parent/'d339_20261008'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as f: json.dump(data,f,indent=2)
old = json.loads((RAW/'prelaunch_scope.json').read_text())['identity']
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
resources = {k:(Path(old['path'])/k).read_text().strip() for k in
    ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
save(RAW/'prelaunch_cleanup.json',dict(identity=old,resources=resources,inactive=True))
own = p.scope_identity(p.cg_path().name)
group = Path(own['path'])
assert os.sched_getaffinity(0) == {2,3,26,27}
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
binding = json.loads((RAW/'prelaunch_binding.json').read_text())
assert binding['passed']
for source in binding['source_references']:
    assert p.digest(Path(source['path'])) == source['sha256']
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
seal = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert seal['entry_count'] == 147 and seal['changed'] == ['/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py']
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)

curated = []
for source,label,jsons,members in [
    (PRIOR,'d339_startup_safety',
     ['summary.json','resources.json','compression_cleanup.json','candidate_cpu1.json','cpu_cleanup.json'],
     ['compress_historical.py','close_compression.py','close_cpu.py','test_candidate.py',
      'candidate_cpu1.log','native_entry1.log','rejected_fork_candidate.patch']),
    (RAW,'d340_prebuild_candidate',
     ['candidate_cpu1.json','cpu_cleanup.json','prelaunch_binding.json','prelaunch_cleanup.json'],
     ['test_candidate.py','verify_prelaunch.py','checkpoint.py','candidate_cpu1.log','native_entry1.log',
      'start_remote.sh','stop_remote.sh','check_remote_health.py'])]:
    out = ROOT/'paper_results/ieee_tc/p2_backend'/label
    out.mkdir(exist_ok=False)
    for name in jsons:
        check((source/name).read_bytes())
        shutil.copyfile(source/name,out/name)
    archive = out/'execution_evidence.tar.gz'
    with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
        for name in members:
            check((source/name).read_bytes())
            if name.endswith('.py'): ast.parse((source/name).read_text())
            tar.add(source/name,arcname=name,recursive=False)
    with tarfile.open(archive,'r:gz') as tar:
        assert len(tar.getmembers()) == len(members)
        for name in members:
            assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == p.digest(source/name)
    save(out/'manifest.json',dict(kind=label,source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        plan_sha256=p.check_plan(),metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
        sources={name:p.digest(source/name) for name in jsons+members},
        outputs={x.name:p.digest(x) for x in out.iterdir()},protected=seal,
        no_gpu_run=True,no_figures=True))
    with (out/'evidence.sha256').open('x') as f:
        for path in sorted(out.iterdir()):
            if path.name != 'evidence.sha256': f.write(p.digest(path)+'  '+path.name+'\n')
    subprocess.run(['sha256sum','-c','evidence.sha256'],cwd=out,check=True)
    curated.extend(str(x.relative_to(ROOT)) for x in out.iterdir())
names = curated + ['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D339_STARTUP_SAFETY_AND_STORAGE.md',
    'docs/ieee_tc/D340_ON_DEMAND_QUANTIZATION_PREBUILD.md','faaslora/runtime_configuration.py',
    'faaslora/experiment/instance_pool.py','scripts/dedicated_engine_worker.py','scripts/run_all_experiments.py',
    'tests/test_ieee_tc_launch.py','scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    'configs/ieee_tc/20261008_d340_7b_prebuild_validation_100.yaml']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip() == 'retry14_continuous_queue_v2'
for name in names:
    check((ROOT/name).read_bytes())
    if name.endswith('.py'): ast.parse((ROOT/name).read_text())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()) == set(names)
for name in names:
    data = subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert data == (ROOT/name).read_bytes()
    check(data)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (RAW/'backup.log').open('x') as log:
    subprocess.run(['git','commit','-m','Qualify on-demand unused quantization prebuild; retain rejected fork safety evidence'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote = subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head == remote
save(RAW/'backup_receipt.json',dict(head=head,remote=head,paths=names,identity=own,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')},
    sources_checked=True,secrets_checked=True,user_manifest_not_staged=True))
print(json.dumps(dict(head=head,remote=remote,paths=len(names),verified=True)))
