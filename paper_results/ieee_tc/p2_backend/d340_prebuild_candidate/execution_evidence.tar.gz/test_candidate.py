"""D340 CPU regression and actual on-demand prebuild import check, no GPU work."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])
def resources():
    return {k:(group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current','memory.high','memory.max','memory.swap.max')}
before = resources()
assert before['memory.high'] == str(3*1024**3) and before['memory.max'] == str(4*1024**3)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
p.check_plan()
command = ['/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python','-m','unittest',
    'tests.test_ieee_tc_launch','tests.test_ieee_tc_service_events','tests.test_ieee_tc_service_routing','-v']
with (RAW/'candidate_cpu1.log').open('x') as log:
    done = subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
entry_returncode = None
if done.returncode == 0:
    env = dict(os.environ)
    env.update(PYTHONPATH=str(ROOT), OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
        VLLM_WORKER_MULTIPROC_METHOD='spawn', VLLM_NO_USAGE_STATS='1',
        FAASLORA_IEEE_QUANTIZATION_PREBUILD_POLICY='on_demand_v1', HUMMING_DISABLE_PARALLEL_BUILD='1',
        FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY='uncached_background_v1',
        PYTORCH_ALLOC_CONF='pinned_max_cached_size_mb:0,pinned_use_background_threads:True')
    for alias in ('PYTORCH_CUDA_ALLOC_CONF','PYTORCH_HIP_ALLOC_CONF'):
        env.pop(alias,None)
    env['CUDA_VISIBLE_DEVICES'] = subprocess.check_output(
        ['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).splitlines()[0]
    code = """
import json, os, threading, torch
from scripts import run_all_experiments
from faaslora.runtime_configuration import validate_quantization_prebuild_policy
config = dict(backend='vllm', dtype='float16', ieee_quantization_prebuild_policy='on_demand_v1')
assert validate_quantization_prebuild_policy(config, os.environ)
state = dict(cuda_initialized=torch.cuda.is_initialized(),
    python_threads=sorted(t.name for t in threading.enumerate()),
    native_method=os.environ['VLLM_WORKER_MULTIPROC_METHOD'],
    humming_parallel_build=os.environ['HUMMING_DISABLE_PARALLEL_BUILD'])
assert not state['cuda_initialized']
assert 'humming-bg-build-reaper' not in state['python_threads']
assert state['native_method'] == 'spawn'
print(json.dumps(state))
"""
    with (RAW/'native_entry1.log').open('x') as log:
        entry = subprocess.run(['/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python','-c',code],
            env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=120)
        entry_returncode = entry.returncode
census = subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not census
with (RAW/'candidate_cpu1.json').open('x') as f:
    json.dump(dict(identity=identity,before=before,after=resources(),command=command,
        unit_returncode=done.returncode,native_entry_returncode=entry_returncode,
        gpu_census_after=census),f,indent=2)
print(json.dumps(dict(unit_returncode=done.returncode,native_entry_returncode=entry_returncode)))
sys.exit(done.returncode or entry_returncode or 0)
