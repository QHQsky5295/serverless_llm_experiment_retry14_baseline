"""Reuse exact-path checkpoint procedure; close D340 audit, freeze D341 full replay."""
import ast
import copy
import hashlib
import json
import os
import re
import subprocess
import sys
import tarfile
from pathlib import Path
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
FULL = RAW.parent/'d341_20261008'
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d340_prebuild_candidate/smoke1'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path): return json.loads(path.read_text())
def save(path, data):
    with path.open('x') as f: json.dump(data, f, indent=2, allow_nan=False)

old = read(RAW/'offline_execution_receipt.json')
assert old['pass_all'] and p.scope_still_owned(old['identity'])
assert not p.owned_pids(Path(old['identity']['path']))
resources = {k:(Path(old['identity']['path'])/k).read_text().strip() for k in
    ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',old['identity']['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',old['identity']['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
save(RAW/'offline_cleanup.json',dict(identity=old['identity'],resources=resources,inactive=True))
own = p.scope_identity(p.cg_path().name)
group = Path(own['path'])
assert os.sched_getaffinity(0) == {2,3,26,27}
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
seal = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count'] == 147 and seal['changed'] == [str(known)]
assert p.digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
prior = read(RAW/'prelaunch_binding.json')
runner = ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
for ref in prior['source_references']:
    if Path(ref['path']) != runner:
        assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
config = ROOT/'configs/ieee_tc/20261008_d341_7b_full_w0.yaml'
smoke = ROOT/'configs/ieee_tc/20261008_d340_7b_prebuild_validation_100.yaml'
c, previous = [yaml.safe_load(x.read_text()) for x in (config,smoke)]
expected = copy.deepcopy(previous)
for section,key in [('experiment','output_dir'),('storage','nvme_cache_dir'),('storage','host_cache_dir')]:
    assert not Path(c[section][key]).exists()
    expected[section][key] = c[section][key]
assert c == expected and c['workload']['total_requests'] == 4000
subprocess.run(['bash','-n',str(runner)],check=True)
for name in ('start_remote.sh','stop_remote.sh'):
    subprocess.run(['bash','-n',str(FULL/name)],check=True)
audit = read(OUT/'audit.json')
assert audit['stats']['completed'] == 100 and len(audit['prebuild_witnesses']) == 2
assert audit['n_correct'] is None and not audit['common_slo_qualified']
for source in audit['raw_evidence']:
    assert p.digest(Path(source['path'])) == source['sha256']
for row in audit['prebuild_witnesses'].values():
    assert p.digest(Path(row['log'])) == row['sha256']
source_paths = [Path(ref['path']) for ref in prior['source_references']]
source_paths.extend([config,ROOT/'scripts/ieee_tc/analyze_d298_smoke.py',
    ROOT/'tests/test_ieee_tc_timing_bound.py',FULL/'start_remote.sh',FULL/'stop_remote.sh',
    FULL/'check_remote_health.py',FULL/'launch_gate.py'])
save(FULL/'full_binding.json',dict(kind='d341_unchanged_full_binding_v1',passed=True,
    source_requests=4000,diagnostic_prefix_count=None,changed_model_policy_fields=[],
    reference_smoke_sha256=p.digest(OUT/'audit.json'),
    source_references=[dict(path=str(x),sha256=p.digest(x)) for x in dict.fromkeys(source_paths)],
    prelaunch_profile_binding_sha256=p.digest(RAW/'prelaunch_binding.json')))
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members = [(RAW/x,'smoke/'+x) for x in ('launch_gate.py','launch_gate1.json',
    'start_remote.sh','check_remote_health.py','stop_remote.sh','remote_start.log',
    'remote_health.json','remote_stop.log','remote_stop.json','local_cleanup.json',
    'collect_closure.py','run_audit.py','audit1.log','offline_execution_receipt.json',
    'offline_cleanup.json','checkpoint_smoke.py')]
members += [(FULL/x,'full/'+x) for x in ('start_remote.sh','check_remote_health.py',
    'stop_remote.sh','full_binding.json','launch_gate.py')]
archive = OUT/'smoke_execution_evidence.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path,name in members:
        check(path.read_bytes())
        if path.suffix == '.py': ast.parse(path.read_text())
        tar.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path,name in members:
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == p.digest(path)
save(OUT/'smoke_manifest.json',dict(kind='d340_completed_smoke_d341_frozen_full_v1',
    plan_sha256=p.check_plan(),metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    sources={str(x):p.digest(x) for x,_ in members},outputs={x.name:p.digest(x) for x in OUT.iterdir()},
    protected=seal,no_figures=True,formal_qualification=False))
with (OUT/'smoke_evidence.sha256').open('x') as f:
    for path in sorted(OUT.iterdir()):
        if path.name != 'smoke_evidence.sha256': f.write(p.digest(path)+'  '+path.name+'\n')
subprocess.run(['sha256sum','-c','smoke_evidence.sha256'],cwd=OUT,check=True)
names = [str(x.relative_to(ROOT)) for x in OUT.iterdir()] + [
    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D340_ON_DEMAND_QUANTIZATION_PREBUILD.md',
    'scripts/ieee_tc/analyze_d298_smoke.py','tests/test_ieee_tc_timing_bound.py',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',str(config.relative_to(ROOT))]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip() == 'retry14_continuous_queue_v2'
for name in names:
    check((ROOT/name).read_bytes())
    if name.endswith('.py'): ast.parse((ROOT/name).read_text())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()) == set(names)
for name in names:
    data = subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert data == (ROOT/name).read_bytes()
    check(data)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (RAW/'smoke_backup.log').open('x') as log:
    subprocess.run(['git','commit','-m','Verify D340 native smoke and freeze unchanged D341 full replay'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote = subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head == remote
save(RAW/'smoke_backup_receipt.json',dict(head=head,remote=remote,paths=names,identity=own,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')},
    sources_checked=True,secrets_checked=True,user_manifest_not_staged=True))
print(json.dumps(dict(head=head,remote=remote,paths=len(names),verified=True)))
