"""Complete exact-path backup after EOF-whitespace rejection, preserving attempt1."""
import ast
import hashlib
import json
import os
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
FULL = RAW.parent/'d341_20261008'
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d340_prebuild_candidate/smoke1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as f: json.dump(data,f,indent=2)
old = p.scope_identity('primelora-tc-aux-c15a86cbb34e4677873fdbf616c1ee4d.scope')
assert old['invocation_id'] == '96ee5486c61d4f288f84fd8114a4388c'
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
resources = {k:(Path(old['path'])/k).read_text().strip() for k in
    ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
save(RAW/'smoke_backup_attempt1.json',dict(identity=old,resources=resources,
    inactive=True,commit_created=False,reason='git diff --check: one extra YAML EOF blank line',
    raw_evidence_preserved=True))
own = p.scope_identity(p.cg_path().name)
group = Path(own['path'])
assert os.sched_getaffinity(0) == {2,3,26,27}
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
config = ROOT/'configs/ieee_tc/20261008_d341_7b_full_w0.yaml'
staged = subprocess.check_output(['git','show',':'+str(config.relative_to(ROOT))],cwd=ROOT)
assert config.read_bytes()+b'\n' == staged, 'only EOF whitespace may differ from attempt1'
binding = json.loads((FULL/'full_binding.json').read_text())
for ref in binding['source_references']:
    if Path(ref['path']) == config:
        assert hashlib.sha256(staged).hexdigest() == ref['sha256']
        ref['sha256'] = p.digest(config)
    else:
        assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
binding['kind'] = 'd341_unchanged_full_binding_v2'
binding['previous_binding_sha256'] = p.digest(FULL/'full_binding.json')
binding['revision'] = 'Remove trailing empty YAML line only; parsed config and serving unchanged.'
binding['source_references'].append(dict(path=str(FULL/'launch_full_gate.py'),sha256=p.digest(FULL/'launch_full_gate.py')))
save(FULL/'full_binding2.json',binding)
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members = [RAW/'smoke_backup_attempt1.json',Path(__file__),FULL/'full_binding2.json',FULL/'launch_full_gate.py',config]
archive = OUT/'full_freeze_v2.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in members:
        check(path.read_bytes())
        if path.suffix == '.py': ast.parse(path.read_text())
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in members:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest() == p.digest(path)
save(OUT/'full_freeze_v2_manifest.json',dict(sources={str(x):p.digest(x) for x in members},
    archive_sha256=p.digest(archive),original_binding_retained=True,serving_changed=False))
with (OUT/'full_freeze_v2.sha256').open('x') as f:
    for name in ('full_freeze_v2.tar.gz','full_freeze_v2_manifest.json'):
        f.write(p.digest(OUT/name)+'  '+name+'\n')
for name in ('smoke_evidence.sha256','full_freeze_v2.sha256'):
    subprocess.run(['sha256sum','-c',name],cwd=OUT,check=True)
names = [str(x.relative_to(ROOT)) for x in OUT.iterdir()] + [
    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D340_ON_DEMAND_QUANTIZATION_PREBUILD.md',
    'scripts/ieee_tc/analyze_d298_smoke.py','tests/test_ieee_tc_timing_bound.py',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',str(config.relative_to(ROOT))]
existing = set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())
assert existing.issubset(set(names)) and 'configs/generated/lora_manifest_1000.json' not in existing
for name in names:
    check((ROOT/name).read_bytes())
    if name.endswith('.py'): ast.parse((ROOT/name).read_text())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()) == set(names)
for name in names:
    data = subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert data == (ROOT/name).read_bytes()
    check(data)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (RAW/'smoke_backup.log').open('x') as log:
    subprocess.run(['git','commit','-m','Verify D340 native smoke and freeze unchanged D341 full replay'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote = subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head == remote
save(RAW/'smoke_backup_receipt.json',dict(head=head,remote=remote,paths=names,identity=own,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')},
    sources_checked=True,secrets_checked=True,user_manifest_not_staged=True))
print(json.dumps(dict(head=head,remote=remote,paths=len(names),verified=True)))
