"""D113 hypothesis check using the native-retirement real-socket fixture pattern.

Generation replies are held by an explicit event, not a timed sleep. This tests
transport progress dependencies, not inference performance. The source reply is
the existing D102-qualified immutable payload, never a newly invented GPU view.
"""
import asyncio
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts.run_all_experiments import SubprocessInferenceEngineProxy, _encode_rpc_frame

raw = Path(__file__).parent
phase = sys.argv[1] if len(sys.argv) > 1 else 'before'
assert phase in ('before','after')
prior_path = ROOT/'results/ieee_tc/p2_backend_qualification/d102_20260928/snapshot_parse_qualified_probe.json'
prior = json.loads(prior_path.read_text())
source = Path(prior['source_path'])
encoded = source.read_bytes()
assert hashlib.sha256(encoded).hexdigest() == prior['source_sha256']
payload = json.loads(encoded)
del encoded
for key in prior['selected'][0]['path']:
    payload = payload[key]
def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
assert digest(payload) == prior['selected'][0]['payload_sha256']

async def probe(generations):
    loop = asyncio.get_running_loop()
    entered, release, control_seen = asyncio.Event(), asyncio.Event(), asyncio.Event()
    submitted, handlers, generations_seen = [], set(), []
    wire_reply = _encode_rpc_frame({'ok':True,'result':payload})
    async def handle(reader, writer):
        handlers.add(asyncio.current_task())
        try:
            while line := await reader.readline():
                message = json.loads(line)
                if message['cmd'] == 'generate':
                    generations_seen.append(message['kwargs']['probe_id'])
                    if len(generations_seen) == generations: entered.set()
                    await release.wait()
                    reply = _encode_rpc_frame({'ok':True,'result':{'probe_id':message['kwargs']['probe_id']}})
                else:
                    assert message['cmd'] == 'ieee_gpu_reference'
                    assert message['kwargs']['operation'] == 'source_snapshot'
                    control_seen.set()
                    reply = wire_reply
                writer.write(reply)
                await writer.drain()
        finally:
            writer.close()
            await writer.wait_closed()
            handlers.discard(asyncio.current_task())
    server = await asyncio.start_server(handle,'127.0.0.1',0)
    port = server.sockets[0].getsockname()[1]
    with tempfile.TemporaryDirectory() as temp:
        # The aggregate service has up to4*8 native generation exchanges. The
        # fixture uses one loopback endpoint, not four invented physical GPUs.
        proxy = SubprocessInferenceEngineProxy(process=SimpleNamespace(poll=lambda:None),
            host='127.0.0.1',port=port,model_cfg={'timing_contract':'ieee_tc_native_v1'},
            cost_model={},device_id=0,workdir=Path(temp),log_path=Path(temp)/'none')
        proxy._rpc_pool_size = generations
        await asyncio.to_thread(lambda:None)  # Observe the unchanged default capacity in both implementations.
        await proxy._ensure_rpc_channel_pool()
        executor = loop._default_executor
        assert executor._max_workers == 32
        original_submit = executor.submit
        queued = asyncio.Event()
        def submit(fn,*args,**kwargs):
            future = original_submit(fn,*args,**kwargs)
            submitted.append(future)
            queued.set()
            return future
        jobs = [asyncio.create_task(proxy._rpc('generate',probe_id=i)) for i in range(generations)]
        control = None
        try:
            await asyncio.wait_for(entered.wait(),5)
            started = time.perf_counter()
            with patch.object(executor,'submit',side_effect=submit):
                control = asyncio.create_task(proxy.ieee_gpu_reference(operation='source_snapshot'))
                if phase == 'before': await asyncio.wait_for(queued.wait(),5)
                if phase == 'before' and generations == executor._max_workers:
                    queued_not_running = not submitted[0].running() and not submitted[0].done()
                    assert queued_not_running and not control_seen.is_set()
                else:
                    await asyncio.wait_for(asyncio.shield(control),5)
                    queued_not_running = False
                if phase == 'after': assert not submitted
                before_release = control.done() and not control.cancelled()
                server_saw_before_release = control_seen.is_set()
                release.set()
                reply = await asyncio.wait_for(control,5)
                returned = await asyncio.wait_for(asyncio.gather(*jobs),5)
            elapsed = time.perf_counter()-started
            timing = reply['timing']
            # _rpc intentionally attaches/replaces transport timing. Retained
            # source identity/state must be exact; old RPC spans cannot match.
            body = {k:v for k,v in reply.items() if k != 'timing'}
            source_body = {k:v for k,v in payload.items() if k != 'timing'}
            assert body == source_body
            assert sorted(r['probe_id'] for r in returned) == list(range(generations))
            assert not proxy._native_rpc_uncertain
            return dict(generations=generations,thread_workers=executor._max_workers,
                control_open_queued_not_running=queued_not_running,
                control_completed_before_release=before_release,
                server_received_control_before_release=server_saw_before_release,
                elapsed_after_control_request_s=elapsed,response_bytes=timing['parent_rpc_response_bytes'],
                timing=timing,generation_successes=len(returned),source_body_sha256=digest(body))
        finally:
            release.set()
            for task in jobs + ([control] if control else []):
                if not task.done(): task.cancel()
            await asyncio.gather(*jobs,*([control] if control else []),return_exceptions=True)
            await proxy._close_all_rpc_channels()
            server.close()
            await server.wait_closed()
            await asyncio.gather(*list(handlers),return_exceptions=True)

samples = [asyncio.run(probe(n)) for n in (1,32)]
result = dict(kind='d114_actual_rpc_executor_dependency_v1',production_optimization=False,
    formal_performance_result=False,phase=phase,source_path=str(source),source_sha256=prior['source_sha256'],
    payload_sha256=prior['selected'][0]['payload_sha256'],samples=samples,
    refs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
          (Path(__file__),ROOT/'scripts/run_all_experiments.py',ROOT/'tests/test_ieee_tc_native_retirement.py')},
    caveat='Actual parent proxy and TCP, one synthetic event-gated endpoint and retained historical payload. No GPU inference, new physical owners, injected timed delay, workload ranking, or claim that D112 reached executor saturation.')
with (raw/('executor_dependency_after.json' if phase == 'after' else 'executor_dependency.json')).open('x') as handle:
    json.dump(result,handle,indent=2,allow_nan=False)
print(json.dumps(result,indent=2))
