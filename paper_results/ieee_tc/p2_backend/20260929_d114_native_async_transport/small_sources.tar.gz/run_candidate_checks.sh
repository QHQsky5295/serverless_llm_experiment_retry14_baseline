#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d114_20260929
unit=primelora-d114-candidate-20260929.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/candidate_scope.txt"
export PYTHONUNBUFFERED=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
"$python" -m unittest tests.test_ieee_tc_native_retirement tests.test_ieee_tc_service_events tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_native_timing -v
/usr/bin/time -v "$python" "$raw/probe_rpc_capacity.py" after
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
