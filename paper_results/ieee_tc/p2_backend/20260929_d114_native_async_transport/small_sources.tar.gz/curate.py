"""D113 curation pattern: preserve raw attempts, verify scoped changes, retire empty scopes."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d114_20260929'
parent = '2943c7187195b3f9afbf6f06c0bc283d370ff27f'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
before = json.loads((raw/'executor_dependency.json').read_text())
after = json.loads((raw/'executor_dependency_after.json').read_text())
assert before['source_sha256'] == after['source_sha256'] == digest(Path(before['source_path']))
assert after['phase'] == 'after'
for old,new in zip(before['samples'],after['samples']):
    assert old['generations'] == new['generations'] == old['generation_successes'] == new['generation_successes']
    assert old['source_body_sha256'] == new['source_body_sha256']
    assert old['response_bytes'] == new['response_bytes'] == 1328413
    assert new['control_completed_before_release'] and new['server_received_control_before_release']
    assert not new['control_open_queued_not_running']
assert before['samples'][1]['control_open_queued_not_running']
assert not before['samples'][1]['server_received_control_before_release']
for name,expected in after['refs'].items(): assert digest(Path(name)) == expected, name
with tarfile.open(raw/'before_sources.tar.gz','r:gz') as archive:
    probe_name = str((raw/'probe_rpc_capacity.py').relative_to(root))
    assert hashlib.sha256(archive.extractfile(probe_name).read()).hexdigest() == before['refs'][str(raw/'probe_rpc_capacity.py')]
for name in ('scripts/run_all_experiments.py','tests/test_ieee_tc_native_retirement.py'):
    archived = subprocess.check_output(['git','show',parent+':'+name])
    assert hashlib.sha256(archived).hexdigest() == before['refs'][str(root/name)]

frozen = json.loads((root/'results/ieee_tc/p2_backend_qualification/d112_20260928/prelaunch_verification.json').read_text())
changed = []
allowed = {'scripts/run_all_experiments.py','tests/test_ieee_tc_native_retirement.py','tests/test_ieee_tc_request_lifecycle.py'}
for name,expected in frozen['source_sha256'].items():
    path = Path(name) if name.startswith('/') else root/name
    if digest(path) != expected:
        relative = str(path.relative_to(root))
        assert relative in allowed, relative
        changed.append(relative)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
scopes = []
for unit,receipt in (
    ('primelora-d114-rpc-probe-20260929.scope','scope_before.txt'),
    ('primelora-d114-rpc-probe2-20260929.scope','scope_before2.txt'),
    ('primelora-d114-candidate-20260929.scope','candidate_scope.txt'),
    ('primelora-d114-legacy-smoke-20260929.scope','legacy_scope.txt')):
    original = dict(line.split('=',1) for line in (raw/receipt).read_text().splitlines())
    current = dict(line.split('=',1) for line in subprocess.check_output(['systemctl','--user','show',unit,
        '-p','InvocationID','-p','TasksCurrent','-p','ControlGroup'],text=True).splitlines())
    assert original['InvocationID'] == current['InvocationID'] and current['TasksCurrent'] == '0'
    assert current['ControlGroup'] == '/user.slice/user-1001.slice/user@1001.service/app.slice/'+unit
    cg = Path('/sys/fs/cgroup'+current['ControlGroup'])
    assert not (cg/'cgroup.procs').read_text().strip()
    assert 'populated 0' in (cg/'cgroup.events').read_text().splitlines()
    events = dict(line.split() for line in (cg/'memory.events').read_text().splitlines())
    assert all(events[k] == '0' for k in ('high','max','oom','oom_kill'))
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    scopes.append(dict(unit=unit,invocation_id=current['InvocationID'],memory_events=events,closed=True))

assert 'Ran 227 tests in 3.224s\n\nOK' in (raw/'candidate.log').read_text()
assert 'Ran 288 tests in 28.840s\n\nOK' in (raw/'legacy_smoke.log').read_text()
out = root/'paper_results/ieee_tc/p2_backend/20260929_d114_native_async_transport'
out.mkdir(exist_ok=False)
files = [raw/p for p in ('probe_rpc_capacity.py','run_probe.sh','run_candidate_checks.sh','run_legacy_smoke.sh',
    'curate.py','executor_dependency.json','executor_dependency_after.json','probe.log','probe2.log',
    'candidate.log','legacy_smoke.log','scope_before.txt','scope_before2.txt','candidate_scope.txt',
    'legacy_scope.txt','attempt1_sources.tar.gz','before_sources.tar.gz')]
bundle = out/'small_sources.tar.gz'
with tarfile.open(bundle,'x:gz') as archive:
    for p in files: archive.add(p,arcname=p.name)
with tarfile.open(bundle,'r:gz') as archive:
    for p in files: assert hashlib.sha256(archive.extractfile(p.name).read()).hexdigest() == digest(p)
sources = files + [root/p for p in sorted(allowed)] + [root/'docs/ieee_tc/D114_NATIVE_ASYNC_TRANSPORT.md',
    root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')]
result = dict(kind='d114_native_async_transport_candidate_v1',parent_commit=parent,
    candidate_implemented=True,full_validation_pending=True,formal_performance_result=False,
    raw_metadata_correction='after raw production_optimization=false is a copied-before template label; phase/source identify candidate. Original retained; no measured values changed.',
    before=before,after=after,tests=dict(native=227,legacy_smoke=288),scopes=scopes,
    frozen_sources_checked=len(frozen['source_sha256']),expected_changed_sources=changed,protected=protected,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in sources],
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    plan_sha256=digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')))
with (out/'summary.json').open('x') as handle: json.dump(result,handle,indent=2,allow_nan=False)
with (out/'SHA256SUMS').open('x') as handle:
    for p in (bundle,out/'summary.json'): handle.write(digest(p)+'  '+str(p.relative_to(root))+'\n')
print(json.dumps(dict(output=str(out),summary_sha256=digest(out/'summary.json'),protected=147,
    frozen_sources_checked=len(frozen['source_sha256']),expected_changed_sources=changed)))
