"""Retain initial harness; qualify the dependency-leaf relocation."""
import ast
from pathlib import Path
import sys
RAW=Path(__file__).resolve().parent
source=(RAW/'check.py').read_text()
old="'faaslora/experiment/cpu_frontend.py'"
assert source.count(old)==1
source=source.replace(old,"'faaslora/cpu_frontend.py'")
ast.parse(source)
exec(compile(source,str(Path(__file__)), 'exec'),globals())
