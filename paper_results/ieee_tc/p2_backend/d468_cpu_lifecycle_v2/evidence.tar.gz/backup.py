"""D468 explicit checkpoint; reuse existing SHA, scope and protection checks."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import unittest
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d468_cpu_lifecycle'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2)
identity=p.scope_identity(p.cg_path().name)
save('backup_identity.json',identity)
assert sys.executable=='/usr/bin/python3'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='767e4d417eaad567595d209b43cd611a9dbdac1e'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()=='71c52cf6f7331dc2a171ec83db5f1011eaf6d5a6'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
for name in ('cpu1','cpu2','curation'):
    receipt=read(RAW/(name+'_closure.json'))
    assert receipt['passed'] and receipt['actual_recursive_procs_empty']
    assert not Path(receipt['identity']['path']).exists()
manifest=read(OUT/'manifest.json')
assert manifest['passed'] and not manifest['native_qualified'] and not manifest['production_runner_integrated']
for name,sha in manifest['outputs'].items():assert p.digest(OUT/name)==sha,name
for name,sha in manifest['preserved'].items():assert p.digest(Path(name))==sha,name
for ref in manifest['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256']
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
    assert not token or token not in data
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(manifest['archive_members'])
    for name,ref in manifest['archive_members'].items():
        data=tar.extractfile(name).read()
        assert hashlib.sha256(data).hexdigest()==ref['sha256']
        assert p.digest(Path(ref['path']))==ref['sha256']
        clean(data)
with (RAW/'publication_smoke.txt').open('x') as stream:
    tests=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames([
        'tests.test_ieee_tc_cpu_frontend_lifecycle.PreparationIdentity',
        'tests.test_ieee_tc_cpu_frontend_lifecycle.ActivationIPC',
        'tests.test_ieee_tc_cpu_frontend_lifecycle.TicketOwnership',
        'tests.test_ieee_tc_cpu_frontend_lifecycle.PoolOwnership',
        'tests.test_ieee_tc_preflight.ApprovedPlanIdentity',
        'tests.test_ieee_tc_preflight.ForwardedCommandCLI']))
assert tests.wasSuccessful() and not tests.skipped
paths=['faaslora/experiment/cpu_frontend.py','faaslora/metrics/metrics_collector.py',
    'scripts/dedicated_engine_worker.py','tests/test_ieee_tc_cpu_frontend_lifecycle.py',
    'tests/test_ieee_tc_gpu_lifecycle.py','docs/ieee_tc/D468_CPU_PREPARATION_LIFECYCLE.md',
    'docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str(path.relative_to(ROOT)) for path in sorted(OUT.iterdir())]
assert len(paths)==14 and not any('lora_manifest_1000.json' in name for name in paths)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in paths:
    data=(ROOT/name).read_bytes()
    assert len(data)<8*1024*1024
    if not name.endswith('.tar.gz'):clean(data)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(paths)
hashes={}
for name in paths:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    hashes[name]=hashlib.sha256(data).hexdigest()
    assert hashes[name]==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
save('staged_check.json',dict(passed=True,files=hashes,smoke_tests=tests.testsRun,
    protected=protected,source=dict(path=str(Path(__file__)),sha256=p.digest(Path(__file__)),content=Path(__file__).read_text())))
subprocess.run(['git','commit','-m','tc: add CPU preparation ownership and activation contracts (D468)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
result=dict(passed=True,head=head,remote=remote,files=len(paths),smoke_tests=tests.testsRun,
    manifest_sha256=p.digest(OUT/'manifest.json'),identity=identity)
save('backup_receipt.json',result)
print(json.dumps(result),flush=True)
