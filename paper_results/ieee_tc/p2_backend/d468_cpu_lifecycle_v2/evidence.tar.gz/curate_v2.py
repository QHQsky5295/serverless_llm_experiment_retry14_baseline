"""Add the dependency-leaf qualification without overwriting initial evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OLD=ROOT/'paper_results/ieee_tc/p2_backend/d468_cpu_lifecycle'
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d468_cpu_lifecycle_v2'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
save(RAW/'curation2_identity.json',p.scope_identity(p.cg_path().name))
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
old=read(OLD/'manifest.json')
assert p.digest(OLD/'manifest.json')=='439cebf0a0df9d3807a6041d4a029dd6d4754ed4531cf0432c9b4f218455a292'
for name,sha in old['outputs'].items():assert p.digest(OLD/name)==sha
final=read(RAW/'cpu3_result.json')
assert final['passed'] and final['tests']==559 and not(final['errors'] or final['failures'] or final['skipped'])
for ref in final['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256']
for name in ('cpu1','cpu2','cpu3','curation','backup'):
    close=read(RAW/(name+'_closure.json'))
    assert close['actual_recursive_procs_empty'] and not Path(close['identity']['path']).exists()
log=(RAW/'publication_smoke.txt').read_text()
assert 'Ran 13 tests' in log and 'FAILED (errors=4)' in log and "No module named 'numpy'" in log
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
OUT.mkdir(exist_ok=False)
paths=[RAW/(name+suffix) for name in ('cpu1','cpu2','cpu3') for suffix in
       ('_tests.txt','_result.json','_closure.json','_identity.json')]
paths += [RAW/name for name in ('check.py','check_v2.py','curate.py','curate_v2.py',
    'primary_sources.json','backup.py','backup_identity.json','backup_closure.json','publication_smoke.txt')]
for name in ('cpu1_sources','cpu2_sources','cpu3_sources'):paths+=sorted((RAW/name).iterdir())
paths += [Path(ref['path']) for ref in read(RAW/'primary_sources.json')['refs']]
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as archive:
    for path in paths:
        name=str(path.relative_to(RAW))
        members[name]=dict(path=str(path),sha256=p.digest(path),bytes=path.stat().st_size)
        archive.add(path,arcname=name,recursive=False)
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as archive:
    assert set(archive.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==ref['sha256']
for name in ('cpu3_result.json','cpu3_closure.json','primary_sources.json'):
    with (OUT/name).open('xb') as f:f.write((RAW/name).read_bytes())
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
for path,sha in old['preserved'].items():assert p.digest(Path(path))==sha,path
manifest=dict(passed=True,kind='cpu_preparation_lifecycle_foundation_d468_v2',
    parent=old['parent'],native_qualified=False,production_runner_integrated=False,
    performance_result=False,final_cpu_tests=559,protected=protected,preserved=old['preserved'],
    source_refs=final['source_refs'],outputs={path.name:p.digest(path) for path in OUT.iterdir()},
    archive_members=members,initial_manifest=dict(path=str(OLD/'manifest.json'),sha256=p.digest(OLD/'manifest.json')),
    publication_failure=dict(stage='before_staging',reason='eager experiment package import required numpy in system Python',
        remedy='Move the new leaf module to faaslora.cpu_frontend; no global package installation or test suppression.'),
    next=old['next'])
save(OUT/'manifest.json',manifest)
save(RAW/'curation2_receipt.json',dict(passed=True,manifest_sha256=p.digest(OUT/'manifest.json'),
    archive_bytes=(OUT/'evidence.tar.gz').stat().st_size,members=len(members)))
print(json.dumps(dict(passed=True,manifest_sha256=p.digest(OUT/'manifest.json'),members=len(members))))
