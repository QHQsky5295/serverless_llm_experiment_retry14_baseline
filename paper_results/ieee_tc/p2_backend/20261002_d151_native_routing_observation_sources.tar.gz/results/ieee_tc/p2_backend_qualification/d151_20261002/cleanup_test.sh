#!/usr/bin/env bash
# Reuses D150's post-exit auto-removed-scope receipt. Never stops a live job.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
expected_id=$2
case "$phase" in red|green|regression|regression2) code=1;; green2|regression3|verify) code=0;; *) exit 2;; esac
[[ "$expected_id" =~ ^[a-f0-9]{32}$ ]]
raw=results/ieee_tc/p2_backend_qualification/d151_20261002
unit="primelora-d151-${phase}-20261002.scope"
{
date -Is
rg -qx "InvocationID=$expected_id" "$raw/${phase}_scope.txt"
rg -q "Exit status: $code" "$raw/${phase}_time.txt"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
printf 'actual_invocation=%s\nexit_code=%s\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n' "$expected_id" "$code"
} | tee "$raw/${phase}_cleanup.txt"
