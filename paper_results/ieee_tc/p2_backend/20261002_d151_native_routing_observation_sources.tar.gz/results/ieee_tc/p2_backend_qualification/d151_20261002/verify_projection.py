"""D149 qualification/seal protocol reused for the D151 readonly native view."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d151_20261002'
out = root/'paper_results/ieee_tc/p2_backend'
parent = '805bf611c4da5ca38575889d8b32eb6481b8d82e'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
production = {'faaslora/memory/gpu_monitor.py','scripts/run_all_experiments.py'}
changed = production | {'tests/'+name+'.py' for name in (
    'test_ieee_tc_gpu_references','test_ieee_tc_service_routing','test_ieee_tc_service_events',
    'test_ieee_tc_native_retirement','test_ieee_tc_request_lifecycle')}
sources = json.loads((root/'results/ieee_tc/p2_backend_qualification/d150_20261001/prelaunch_verification.json').read_text())['source_sha256']
changed_paths = {root/p for p in changed}
def original(name):
    return subprocess.check_output(['git','show',f'{parent}:{name}'])
for name,sha in sources.items():
    path = (root/name).resolve()
    actual = hashlib.sha256(original(str(path.relative_to(root)))).hexdigest() if path in changed_paths else digest(path)
    assert actual == sha, name

phases = dict(red=(5,1,'FAILED (failures=2, errors=2)'),
    green=(5,1,'FAILED (failures=1)'), green2=(5,0,'OK'),
    regression=(737,1,'FAILED (failures=14, errors=75)'),
    regression2=(737,1,'FAILED (failures=2, errors=1)'), regression3=(737,0,'OK'))
attempts = {}
for phase,(count,code,status) in phases.items():
    unit = f'primelora-d151-{phase}-20261002.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    assert not subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','--value'],text=True).strip()
    scope = (raw/f'{phase}_scope.txt').read_text()
    identity = re.search(r'^InvocationID=([a-f0-9]{32})$',scope,re.M).group(1)
    cg = re.search(r'^ControlGroup=(.+)$',scope,re.M).group(1)
    assert not Path('/sys/fs/cgroup'+cg).exists()
    assert all(line in scope for line in ('MemoryHigh=3221225472','MemoryMax=4294967296','MemorySwapMax=0'))
    cleanup = (raw/f'{phase}_cleanup.txt').read_text()
    assert f'actual_invocation={identity}' in cleanup
    assert 'cleanup=automatic_removal_verified' in cleanup
    assert 'final_memory_events=unavailable_after_removal' in cleanup
    timing = (raw/f'{phase}_time.txt').read_text()
    assert f'Exit status: {code}' in timing
    log = (raw/f'{phase}.log').read_text()
    match = re.search(rf'Ran {count} tests in ([\d.]+)s\n\n{re.escape(status)}\n',log)
    assert match, phase
    for line in (raw/f'{phase}_sources.sha256').read_text().splitlines():
        sha,name = line.split(maxsplit=1)
        payload = (root/name).read_bytes()
        if phase == 'red' and name in production:
            payload = original(name)
        if phase in ('red','green') and name == 'tests/test_ieee_tc_gpu_references.py':
            payload = payload.replace(b'self.manager._registered_adapters[5] = NativeAdapter()',
                                      b'self.manager._registered_adapters.cache[5] = NativeAdapter()')
        if phase == 'regression2' and name == 'tests/test_ieee_tc_request_lifecycle.py':
            payload = payload.replace(b"async def fail_after_file_resolution(*, operation, **kwargs):\n                if operation == 'routing_source_snapshot':",
                                      b"async def fail_after_file_resolution(*, operation, **kwargs):\n                if operation == 'source_snapshot':")
            for func,body in (('measured',"            value = await rpc(operation=operation, **kwargs)\n"),('reject','')):
                prefix = f'async def {func}(*, operation, **kwargs):\n{body}            if operation == '.encode()
                payload = payload.replace(prefix+b"'routing_source_snapshot':",prefix+b"'source_snapshot':")
        assert hashlib.sha256(payload).hexdigest() == sha, (phase,name)
    attempts[phase] = dict(tests=count,exit_code=code,status=status,test_seconds=float(match.group(1)),
        command_wall=re.search(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\): (.+)',timing).group(1),
        peak_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',timing).group(1)),
        invocation_id=identity,cleanup='automatic_removal_verified',final_memory_events=None)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
files = [root/name for name in sorted(changed)]
files += [root/'docs/ieee_tc/D151_NATIVE_ROUTING_OBSERVATION.md']
files += [raw/name for name in ('run_tests.sh','cleanup_test.sh','verify_projection.py',
    'first_test_changes.patch','regression2_lifecycle_changes.patch')]
for phase in phases:
    files += [raw/f'{phase}{suffix}' for suffix in ('.log','_time.txt','_scope.txt','_cleanup.txt','_sources.sha256')]
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for path in files:
    assert path.stat().st_size < 4*1024**2, path
    payload = path.read_bytes()
    assert secret not in payload, path
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in payload.splitlines()), path
    if path.suffix == '.py': compile(payload,str(path),'exec')
    if path.suffix == '.sh': subprocess.run(['bash','-n',str(path)],check=True)
result = dict(kind='d151_native_routing_observation_qualification_v1',parent_commit=parent,
    decision='qualified_for_ordinary_full_not_performance_acceptance',attempts=attempts,
    cuda_executed=False,formal_performance_result=False,performance_gain_established=False,
    retry_or_timeout_changed=False,equations_changed=False,ownership_guards_changed=False,
    budgets_changed=False,reading_cache_added=False,registered_graph_validation_preserved=True,
    physical_snapshot_unchanged=True,full_replay_status='pending',
    failure_disclosure='First replacement injection wrote a cache view; initial lifecycle fixtures lacked worker readonly dispatch. Only tests corrected after initial production candidate.',
    protected=protected,prelaunch_sources_verified=len(sources),
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
curated = out/'20261002_d151_native_routing_observation.json'
with curated.open('x') as stream: json.dump(result,stream,indent=2,allow_nan=False)
files.append(curated)
bundle = out/'20261002_d151_native_routing_observation_sources.tar.gz'
with bundle.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for path in files: archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(files)
    for member,path in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == digest(path)
with (out/'20261002_d151_native_routing_observation_sources.sha256').open('x') as stream:
    stream.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,regression_tests=737)))
