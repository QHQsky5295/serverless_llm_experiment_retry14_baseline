#!/usr/bin/env bash
# Reuse post-exit absence receipt; no manual stop of removed scopes.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d195_20261003
{
  date -Is
  jq -e '.pass == true and .service_returncode == 0 and .replay_returncode == 0 and .watchdog_returncode == 0 and .native_gpu_context_release_confirmed == true and .service_path_removed == true and .service_identity.invocation_id == "cfd37b2208cd460a8283a0ad551fe5ad"' "$raw/7b_full_w0_full1/launch.json"
  for unit in primelora-tc-svc-421be5687325441d84c68bae5ec2ce04.scope primelora-tc-aux-6cc2baae72334c37bb07a03b5e866550.scope; do
    test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
    test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
    test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
    systemctl --user show "$unit" -p Id -p ActiveState -p InvocationID -p TasksCurrent
  done
  # Verify recorded replay PID; removed resource domains cover the service tree.
  for pid in 1515648; do
    test ! -e "/proc/$pid"
    printf 'owned_pid=%s absent\n' "$pid"
  done
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  printf 'cleanup=automatic_removal_verified\nfinal_cgroup_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_local_cleanup.txt"
