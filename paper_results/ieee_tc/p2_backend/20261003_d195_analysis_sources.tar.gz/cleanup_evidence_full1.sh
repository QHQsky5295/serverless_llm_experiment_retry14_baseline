#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d195_20261003
unit=primelora-d195-full1-evidence1-20261003.scope
{
  date -Is
  rg -qx 'InvocationID=3f1e24aa471143a5921ada90650519aa' "$raw/full_full1_evidence1_scope.txt"
  jq -e '.pass_checks == true' paper_results/ieee_tc/p2_backend/20261003_d195_evidence_verification.json
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=3f1e24aa471143a5921ada90650519aa\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=see_captured_evidence1_memory_events_and_swap_files\n'
} | tee "$raw/cleanup_evidence_full1.log"
