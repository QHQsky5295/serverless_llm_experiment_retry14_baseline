#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d160_20261002
unit=primelora-d160-full1-curate-20261002.scope
{
  date -Is
  rg -qx 'InvocationID=3fe8bed426ec497fb7656a9bf10e5e52' "$raw/full_full1_curation_scope.txt"
  rg -q 'Exit status: 0' "$raw/full_full1_curation_time.txt"
  rg -q 'Exit status: 0' "$raw/full_full1_failure_time.txt"
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=3fe8bed426ec497fb7656a9bf10e5e52\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_curation_cleanup.txt"
