#!/usr/bin/env bash
set -euo pipefail
unit=primelora-tc-aux-cf939d83ef2549fab79a51edac046699.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 6cf2dfe92a9342a0ad98533cf5e17191
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-cf939d83ef2549fab79a51edac046699.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
