#!/usr/bin/env bash
# Reuse post-exit absence receipt; no manual stop of removed scopes.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d160_20261002
{
  date -Is
  jq -e '.pass == true and .service_returncode == 0 and .replay_returncode == 0 and .watchdog_returncode == 0 and .native_gpu_context_release_confirmed == true and .service_path_removed == true and .service_identity.invocation_id == "b02b72c8dcf247dfa7f7d7a85605befc"' "$raw/7b_full_w0_full1/launch.json"
  for unit in primelora-tc-svc-e8f24d386a694532b07696e17a696e1f.scope primelora-tc-aux-cf939d83ef2549fab79a51edac046699.scope; do
    test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
    test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
    test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
    systemctl --user show "$unit" -p Id -p ActiveState -p InvocationID -p TasksCurrent
  done
  for pid in 3065490 3065497 3068435 3073231 3073612 3073930; do
    test ! -e "/proc/$pid"
    printf 'owned_pid=%s absent\n' "$pid"
  done
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  printf 'cleanup=automatic_removal_verified\nfinal_cgroup_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_local_cleanup.txt"
