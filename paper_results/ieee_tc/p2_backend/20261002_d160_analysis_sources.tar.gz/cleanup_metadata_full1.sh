#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d160_20261002
unit=primelora-d160-full1-metadata2-20261002.scope
{
  date -Is
  test "$(systemctl --user show primelora-d160-full1-metadata-20261002.scope -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show primelora-d160-full1-metadata-20261002.scope -p InvocationID --value)"
  printf 'attempt1_invocation=c7aac6c0e3804d279e064ed520f5a1d1\nattempt1_exit=1\nattempt1_reason=unchanged_128MiB_guard\n'
  rg -qx 'InvocationID=b4b1a4cfdba2440eaa7b52d891df0af3' "$raw/full_full1_metadata2_scope.txt"
  rg -q 'Exit status: 0' "$raw/full_full1_metadata2_time.txt"
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=b4b1a4cfdba2440eaa7b52d891df0af3\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_metadata_cleanup.txt"
