"""D660 bounded CPU assembly qualification; no GPU or source-matrix repeat."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path, obj):
    with path.open('x') as stream:
        json.dump(obj, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([MAIN], 32*p.GIB)
save(RAW/'resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
shell = MAIN/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
subprocess.run(['bash', '-n', str(shell)], check=True)
source=shell.read_text()
start=source.index('  d660)\n')
end=source.index('    ;;\n',start)+len('    ;;\n')
restored=source[:start]+source[end:]
assert restored.count(' || "${1:-d293}" == d660')==2
restored=restored.replace(' || "${1:-d293}" == d660','')
assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(MAIN))],cwd=MAIN,text=True)
import copy,yaml
from scripts.ieee_tc.prepare_d298_capacity import assemble_3b_current_full
from faaslora.datasets.workload_generator import FrozenReplayPlan
from scripts.run_all_experiments import ScenarioRunner,_prepare_scenario_runtime_model_config
read=lambda path:json.loads(path.read_text())
prior=RAW.parent/'d659_20261018'
audit_path=MAIN/'paper_results/ieee_tc/p2_backend/d659_3b_full_smoke100/audit.json'
audit=read(audit_path)
assert audit['passed'] and audit['protocol_bound_count']==100 and not audit['fixed_workload_complete4000']
assert audit['stats']['n_correct'] is None
for ref in audit['refs']:assert p.digest(Path(ref['path']))==ref['sha256']
for phase in ('start','analysis','publication'):
    closed=read(prior/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
    assert not Path(closed['identity']['path']).exists()
local=read(prior/'local_cleanup.json')
assert local['passed'] and local['auxiliary_path_gone'] and local['service_path_gone']
assert read(prior/'remote_stop.json')['all_owned_units_inactive']
prior_prepared=MAIN/'paper_results/ieee_tc/p2_backend/d658_3b_full_entry/preparation.json'
prepared=read(prior_prepared)
assert prepared['passed']
for ref in [*prepared['sources'],prepared['configuration']]:assert p.digest(Path(ref['path']))==ref['sha256']
src={r['role']:Path(r['path']) for r in prepared['sources']}
cfgpath=MAIN/'configs/ieee_tc/20261018_d660_3b_full_w0.yaml'
out=MAIN/'paper_results/ieee_tc/p2_backend/d660_3b_full_w0'
assert not cfgpath.exists() and not out.exists() and not (RAW/'3b_full_w0').exists()
assert not Path('/dev/shm/tc-d660-3b-w0').exists()
cfg,child,env=assemble_3b_current_full(yaml.safe_load(src['previous'].read_text()),
    read(src['contract']),read(src['profiles']),output_dir=RAW/'3b_full_w0',
    nvme_dir=RAW/'3b_nvme_w0',host_dir='/dev/shm/tc-d660-3b-w0',count=4000)
priorcfg=yaml.safe_load(Path(prepared['configuration']['path']).read_text())
expected=copy.deepcopy(priorcfg)
expected['workload']['total_requests']=4000
expected['experiment']['output_dir']=str(RAW/'3b_full_w0')
expected['storage'].update(nvme_cache_dir=str(RAW/'3b_nvme_w0'),host_cache_dir='/dev/shm/tc-d660-3b-w0')
assert cfg==expected,'non-population configuration changed'
assert child==prepared['planned_child_model_config'] and env==prepared['child_environment']
runner=ScenarioRunner.__new__(ScenarioRunner)
runner.coord_cfg=cfg['resource_coordination'];runner._initial_runtime_pending=True
runner.model_cfg=_prepare_scenario_runtime_model_config(cfg['model'],cfg['workload'],runner.coord_cfg)
runner._service_profiles=runner._load_ieee_service_profiles()
assert runner._load_ieee_preparation_profiles() is not None
plan=FrozenReplayPlan.load(prepared['source_plan']['source_path'],count=4000,profile='W0')
assert plan.source_sha256==prepared['source_plan']['source_sha256']
assert plan.identity()['view_sha256']=='0d998f48a006d638dda9b8d714f667fe3a87f4d2c88044ce19a816b308494a37'
# Reuse six D658 tests only while their source and service paths stay identical.
qualification=read(RAW.parent/'d658_20261018/qualification.json')
assert qualification['passed'] and qualification['tests']==6
for path,sha in qualification['refs'].items():
    if Path(path)!=shell:assert p.digest(Path(path))==sha,path
for helper in RAW.glob('*.py'):ast.parse(helper.read_text())
for helper in RAW.glob('*.sh'):subprocess.run(['bash','-n',str(helper)],check=True)
out.mkdir(parents=True,exist_ok=False)
with cfgpath.open('x') as stream:yaml.safe_dump(cfg,stream,sort_keys=False)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
preserved={
 str(MAIN/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
 '/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
 '/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha
paths=[shell,cfgpath,prior_prepared,audit_path,*src.values()]
paths += [Path(path) for path in qualification['refs'] if Path(path)!=shell]
paths += sorted(RAW.glob('*.py'))+sorted(RAW.glob('*.sh'))
record=dict(passed=True,count=4000,prime_plan=plan.identity(),preserved=preserved,
    refs={str(path):p.digest(path) for path in paths},no_gpu_run=True,
    unchanged_historical_shell_branches=True,unchanged_production_semantics=True,
    same_configuration_as_d659_except_population_and_paths=True,reused_cpu_tests=6,
    profile_loaders_passed=True,configuration=dict(path=str(cfgpath),sha256=p.digest(cfgpath)),
    identity=identity,protected=protected,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')})
save(RAW/'qualification.json',record)
save(out/'prelaunch.json',dict(passed=True,count=4000,source_sha256=record['refs'],
    prime_plan=plan.identity(),configuration=record['configuration'],configuration_changes={},
    n_correct=None,formal_run=False,full_performance_complete=False))
print(json.dumps(dict(passed=True,count=4000,reused_tests=6,plan=plan.identity(),resources=record['resources'])))
