#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d123_20260930
alias=primelora-artifact-174
journal=/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-73cd7890ada447aaac2204aec8281de0.jsonl
monitor=/home/lab14/primelora_remote/tc/d123_20260930/remote_monitor_7b_full_prefix1.log
test "$(systemctl --user show primelora-tc-svc-583e8aa2b1c34855992c1c6bf89f1f2d.scope -p ActiveState --value)" = inactive
test -s "$raw/stop_services_prefix1.log"
test ! -e "$raw/remote_7b_prefix1_transfers.jsonl"
test ! -e "$raw/remote_monitor_prefix1_final.log"
test ! -e "$raw/remote_copy_receipt.txt"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "head -n 1 '$journal'" |
  jq -e '.clock_id == "remote-process-monotonic:3b0f1b297d154d3db8d3be7172c56424"'
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "sha256sum '$journal' '$monitor'" > "$raw/remote_copy_receipt.txt"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$journal" "$raw/remote_7b_prefix1_transfers.jsonl"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$monitor" "$raw/remote_monitor_prefix1_final.log"
read -r expected_journal _ < "$raw/remote_copy_receipt.txt"
expected_monitor=$(sed -n '2s/ .*//p' "$raw/remote_copy_receipt.txt")
actual_journal=$(sha256sum "$raw/remote_7b_prefix1_transfers.jsonl" | cut -d' ' -f1)
actual_monitor=$(sha256sum "$raw/remote_monitor_prefix1_final.log" | cut -d' ' -f1)
test "$actual_journal" = "$expected_journal"
test "$actual_monitor" = "$expected_monitor"
sha256sum "$raw/remote_7b_prefix1_transfers.jsonl" "$raw/remote_monitor_prefix1_final.log"

