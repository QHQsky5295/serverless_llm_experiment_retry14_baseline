#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d123_20260930
# Prepared, NOT run. Normal-result schema only; inspect final state first.
shopt -s nullglob
sources=("$raw"/7b_outputs_prefix1/experiment_results_full_vllm_dedicated_a500_r1000_c*_tc_ieee_full_d123_7b_full_w0_prefix1.json)
test "${#sources[@]}" = 1
source_file="${sources[0]}"
target="$raw/prefix1_request_projection.json"
test -s "$raw/7b_full_w0_prefix1/launch.json"
test -s "$source_file"
test "$(stat -c %s "$source_file")" = 2886956618
jq -e '.execution_completed == true and .cleanup.complete == true and .population.terminal == 1000' "$raw/prefix1_preliminary.json"
test ! -e "$target"
test ! -e "$raw/prefix1_projection_time.txt"
test "$(systemctl --user show primelora-tc-svc-583e8aa2b1c34855992c1c6bf89f1f2d.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d123-prefix1-project-20260930.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/prefix1_projection_scope.txt"
# Unmodified D96 bounded projection retains failed requests. No whole JSON load.
exec /usr/bin/time -v -o "$raw/prefix1_projection_time.txt" \
  jq --stream -n -f results/ieee_tc/p2_backend_qualification/d96_20260928/project_full_attempt3.jq \
  "$source_file" > "$target"

