#!/usr/bin/env bash
# Reuse D119 evidence closure for D123 diagnostic prefix, preserving timing failure.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d123_20260930
unit=primelora-d123-prefix1-evidence-20260930.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/prefix1_evidence_scope.txt"
export PYTHONUNBUFFERED=1
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest tests.test_ieee_tc_gpu_lifecycle tests.test_ieee_tc_external_replay tests.test_ieee_tc_native_timing -v
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python - <<'PY'
import json, subprocess
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d123_20260930'
before = json.loads((raw/'prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    p = Path(name) if name.startswith('/') else root/name
    assert digest(p) == expected, name
full = root/'paper_results/ieee_tc/p2_backend/20260930_d123_7b_full_w0_prefix1.json'
assert digest(full) == '93614036c20e9b978fe5e98c99163f77235ee1e7a7770110e36bcea63c271b65'
x = json.loads(full.read_text())
assert not x['native_contract_completion_pass'] and not x['full_qualified']
assert not x['formal_performance_result'] and x['launcher_cleanup_pass']
assert x['execution_completed'] and x['cleanup']['complete']
assert x['population']['planned'] == 1000 and x['population']['source_count'] == 4000
assert x['diagnostic_instrumentation']
assert x['cpu_profile']['total_samples'] == 279902 and x['cpu_profile']['reported_sampling_errors'] == 67
assert sum(x['cpu_profile']['exclusive_stack_categories'].values()) == 279902
launch = json.loads((raw/'7b_full_w0_prefix1/launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert launch['external_replay']['diagnostic_prefix_count'] == 1000
assert launch['external_replay']['plan']['count'] == 1000 and launch['external_replay']['plan']['source_count'] == 4000
assert all(launch[k] == 0 for k in ('service_returncode','replay_returncode','watchdog_returncode'))
assert x['population']['success'] == x['population']['native_contract_matched'] == 916
assert x['population']['failure_observations'] == {'TimeoutError':84}
assert x['timing_validation']['requests'] == 916
assert not x['timing_validation']['pass_tolerance']
assert x['timing_validation']['tolerance_ms'] == 1.0
assert x['timing_validation']['requests_over_tolerance'] == 3
assert {v['request_id'] for v in x['timing_validation']['violations']} == {'req_00063','req_00330','req_00539'}
assert len(x['timing_validation']['violations']) == 9
assert max(x['timing_validation']['max_error_ms'].values()) == 3.9489049813710153
assert x['physical']['n_correct'] is None and not x['physical']['eligible_correctness']
assert x['physical']['measurement_complete'] and not x['physical']['open_lease_ids']
assert not x['observed_completion_boundaries']['client_response_observed']
assert x['quarantine']['events'] == x['quarantine']['released'] == 2
assert x['remote']['uuid_pairs'] == 60
assert not x['remote']['byte_mismatches'] and x['remote']['request_packing'] == 0
assert all(counts.get('failed', 0) == 0 for counts in x['mechanism_counts'].values())
assert x['readiness_evidence']['confirmed_pre_generation_requests'] == 916
assert x['readiness_evidence']['conflicts'] == 0
for removed in x['cleanup']['roots']:
    assert not Path(removed['path']).exists(), removed['path']
for stage in ('cpu', 'metadata', 'projection', 'curation'):
    lines = (raw/f'{stage}_cleanup_prefix1.log').read_text().splitlines()
    names = {'low','high','max','oom','oom_kill','oom_group_kill'}
    events = dict(line.split() for line in lines if len(line.split()) == 2 and line.split()[0] in names)
    assert set(events) == names and all(int(v) == 0 for v in events.values())
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == x['metric_protocol_sha256']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
reused = []
checked = 0
for ref in x['source_refs']:
    p = Path(ref['path'])
    if p.name == 'experiment_results_full_vllm_dedicated_a500_r1000_c2_tc_ieee_full_d123_7b_full_w0_prefix1.json':
        # Already streamed/hashed by the completed curator, not re-parsed/rehashed.
        st = p.stat()
        assert st.st_size == 2886956618 and st.st_mtime_ns <= full.stat().st_mtime_ns
        reused.append(dict(**ref, bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                           verification='reuse_completed_curator_stream_hash_plus_stat'))
    else:
        assert digest(p) == ref['sha256'], ref['path']
        checked += 1
# Normal D96 streaming schema fixture; preserve both success and failure.
fixture = dict(detailed_results=dict(tc_ieee_full=dict(scenario_name='fixture',total=2,
    requests=[dict(request_id='r0',tokens=[1,2],gpu_reference_evidence=dict(
        source_admission=dict(tier='host'),generation_submission=dict(state='submitted'),
        prior_routing_attempts=[dict(x=1),dict(x=2)],huge_inventory=[dict(x=9)])),
        dict(request_id='r1',error='request-failure')])))
jq_filter = root/'results/ieee_tc/p2_backend_qualification/d96_20260928/project_full_attempt3.jq'
res = subprocess.run(['jq','--stream','-n','-f',str(jq_filter)],
    input=json.dumps(fixture),text=True,capture_output=True,check=True)
y = json.loads(res.stdout)
assert y['scenario'] == dict(scenario_name='fixture',total=2)
assert len(y['requests']) == 2 and y['requests'][1]['error'] == 'request-failure'
r = y['requests'][0]
assert r['tokens'] == [1,2] and r['prior_routing_attempt_count'] == 2
assert r['retained_reference_evidence']['source_admission'] == dict(tier='host')
assert 'gpu_reference_evidence' not in r and 'huge_inventory' not in r
failure = root/'paper_results/ieee_tc/p2_backend/20260930_d123_7b_full_w0_failure_breakdown.json'
assert digest(failure) == '9af5c025465fada4704961c834d7ae74bd0e2c2b26e66ba40f5880b59d2e1fa6'
f = json.loads(failure.read_text())
assert f['population'] == dict(planned=1000,source_count=4000,success=916,timeout=84,returned_error=0)
assert f['returned_categories'] == {}
assert f['failure_observation_clock_id'] == x['physical']['clock_id']
assert f['projection_sha256'] == digest(raw/'prefix1_request_projection.json')
assert f['source_script_sha256'] == digest(raw/'collect_prefix1_failure_breakdown.py')
assert len(f['timeout_requests']) == 84 and len(f['returned_requests']) == 0
assert f['returned_generation_submission_states'] == {}
assert f['first_returned_error'] is None
assert f['timeout_generation_submission_states'] == {'unrecorded':84}
assert 'Exit status: 0' in (raw/'prefix1_failure_time.txt').read_text()
refs = [full,failure,raw/'collect_prefix1_failure_breakdown.py',raw/'prefix1_failure_time.txt',
        raw/'summarize_prefix1_attempt2.py',raw/'verify_prefix1_evidence.sh',
        raw/'prefix1_curation_attempt2_time.txt',raw/'curation_cleanup_prefix1.log',
        root/'tests/test_ieee_tc_gpu_lifecycle.py',root/'tests/test_ieee_tc_external_replay.py',
        root/'tests/test_ieee_tc_native_timing.py']
receipt = dict(kind='d123_prefix1_evidence_verification_v1',pass_checks=True,
    full_qualified=False,formal_performance_result=False,projection_fixture_pass=True,
    timing_qualification_pass=False, timing_tolerance_ms=1.0,
    frozen_source_refs_checked=len(before['source_sha256']),curated_source_refs_rehashed=checked,
    reused_large_source_hash=reused,source_commit=before['runtime_source_commit'],
    protected=protected,refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
out = root/'paper_results/ieee_tc/p2_backend/20260930_d123_evidence_verification.json'
with out.open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(out),sha256=digest(out),frozen_sources=len(before['source_sha256']),
    curated_sources_rehashed=checked,reused_large_source_hash=len(reused),protected=147)))
PY

