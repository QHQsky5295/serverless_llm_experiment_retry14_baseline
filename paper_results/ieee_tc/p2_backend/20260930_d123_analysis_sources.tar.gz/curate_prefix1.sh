#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d123_20260930
unit=primelora-d123-prefix1-curate-20260930.scope
test "$(systemctl --user show primelora-tc-svc-583e8aa2b1c34855992c1c6bf89f1f2d.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show primelora-d123-prefix1-project-20260930.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/prefix1_curation_scope.txt"
/usr/bin/time -v -o "$raw/prefix1_curation_time.txt" \
  /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/summarize_prefix1.py" > "$raw/prefix1_curation.log" 2>&1
exec /usr/bin/time -v -o "$raw/prefix1_failure_time.txt" \
  /usr/bin/python3 "$raw/collect_prefix1_failure_breakdown.py" > "$raw/prefix1_failure.log" 2>&1

