"""Small evidence packaging only: no dataset duplication or raw-outcome read."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d123_20260930'
out = root/'paper_results/ieee_tc/p2_backend'
unit = 'primelora-d123-prefix1-evidence-20260930.scope'
def prop(name):
    return subprocess.check_output(['systemctl','--user','show',unit,'-p',name,'--value'],text=True).strip()
# Verify completed exact-owned cleanup without repeating it.
receipt = (raw/'evidence_cleanup_prefix1.log').read_text()
assert 'ActiveState=inactive' in receipt
names = {'low','high','max','oom','oom_kill','oom_group_kill'}
events = dict(line.split() for line in receipt.splitlines()
              if len(line.split()) == 2 and line.split()[0] in names)
assert set(events) == names and all(int(v) == 0 for v in events.values())
assert prop('ActiveState') == 'inactive'
assert 'd5457d6c24df4449ab7fbf47882b1725' in (raw/'cleanup_evidence_prefix1.sh').read_text()

# Only top-level small scripts, configuration and receipts; no remote journal,
# monitor, projection, raw outcomes, model files, token files or cache roots.
members = sorted(p for p in raw.iterdir() if p.is_file() and
    p.stat().st_size < 64*1024 and p.suffix in {'.py','.sh','.jq','.yaml','.json','.log','.txt'})
bundle = out/'20260930_d123_analysis_sources.tar.gz'
assert not bundle.exists()
hashes = {}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        data = p.read_bytes()
        # Anchor actual PEM header; attempt1 matched its own check literal.
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line
                       for line in data.splitlines())
        hashes[p.name] = hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
manifest = out/'20260930_d123_analysis_sources.sha256'
with manifest.open('x') as f:
    f.write(hashlib.sha256(bundle.read_bytes()).hexdigest()+'  '+bundle.name+'\n')
members_manifest = out/'20260930_d123_analysis_sources_members.json'
with members_manifest.open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,members=len(hashes),
                      sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),cleanup=True)))

