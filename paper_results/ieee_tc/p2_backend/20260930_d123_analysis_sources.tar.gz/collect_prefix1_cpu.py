"""Reuse D110 finalized GIL accounting for D123 diagnostic prefix; no wall-time inference."""
import collections
import json
import re
import subprocess
from pathlib import Path

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw=Path(__file__).resolve().parent
assert subprocess.check_output(['systemctl','--user','show',
    'primelora-tc-svc-583e8aa2b1c34855992c1c6bf89f1f2d.scope',
    '-p','ActiveState','--value'],text=True).strip()=='inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
assert (raw/'7b_full_w0_prefix1/launch.json').is_file()
assert 'Exit status: 0' in (raw/'controller_prefix1_time.txt').read_text()
launch=json.loads((raw/'7b_full_w0_prefix1/launch.json').read_text())
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
terminals_path=raw/'7b_full_w0_prefix1/launch.launch/physical_deployment/request_terminals.jsonl'
terminals=[json.loads(line) for line in terminals_path.open()]
assert len(terminals)==len({r['request_id'] for r in terminals})==1000
profile_path=raw/'controller_prefix1.speedscope.json'
assert 0 < profile_path.stat().st_size < 256*1024**2, 'inspect actual profile size before bounded load'
profile=json.loads(profile_path.read_text())
frames=profile['shared']['frames']
inclusive=collections.Counter()
leaves=collections.Counter()
nearest_project=collections.Counter()
threads=[]
stack_categories=collections.Counter()
non_serialization_nearest=collections.Counter()
def frame_key(f):
    return (f.get('file',''),f['name'])
def project(f):
    return f.get('file','').startswith(str(ROOT)+'/')
for thread in profile['profiles']:
    assert thread['type']=='sampled' and thread['unit']=='seconds'
    assert len(thread['samples'])==len(thread['weights'])
    assert all(abs(w-.01)<1e-12 for w in thread['weights'])
    assert abs(sum(thread['weights'])-(thread['endValue']-thread['startValue']))<1e-6
    threads.append(dict(name=thread['name'],samples=len(thread['samples'])))
    for stack in thread['samples']:
        assert stack and all(type(i) is int and 0<=i<len(frames) for i in stack)
        chain=[frames[i] for i in stack]
        inclusive.update({frame_key(f) for f in chain if project(f)})
        leaves[frame_key(chain[-1])]+=1
        local=[f for f in chain if project(f)]
        key=frame_key(local[-1]) if local else ('','no_project_frame')
        nearest_project[key]+=1
        in_save=any(project(f) and f['name']=='save_results' for f in chain)
        in_import=any(f['name'] in ('_find_and_load','_find_and_load_unlocked') and 'importlib' in f.get('file','') for f in chain)
        category='save_results_ancestry' if in_save else ('import_ancestry' if in_import else 'other')
        stack_categories[category]+=1
        if not in_save:non_serialization_nearest[key]+=1
n_samples=sum(r['samples'] for r in threads)
assert n_samples > 0 and sum(nearest_project.values())==n_samples
assert sum(leaves.values())==n_samples
def top(counter):
    return [dict(file=k[0],function=k[1],samples=v,fraction=v/n_samples)
            for k,v in counter.most_common(30)]
profiler=dict(finalized=True,diagnostic_prefix_reached_terminal=True, source_count=4000, diagnostic_prefix_count=1000, full_qualification=False,output_bytes=profile_path.stat().st_size,
    tool='py-spy 0.4.2',rate_hz=100,gil_only=True,threads=threads,total_samples=n_samples,
    reported_sampling_errors=None,inclusive_project_frames=top(inclusive),leaf_frames=top(leaves),
    exclusive_nearest_project_frames=top(nearest_project),
    caveat='Original first-1000 diagnostic prefix, not 4000-request Full qualification; GIL sample attribution, not wall-time phase durations; '
        'inclusive counts overlap; ordinal indices are not arrival timestamps; profiler overhead unmeasured; '
        'time receipt wraps profiler and waited descendants; it is not isolated controller RSS/CPU')

log=(raw/'7b_full_w0_prefix1/launch.launch/service.log').read_text()
reports=re.findall(r'Samples: ([0-9]+) Errors: ([0-9]+)',log)
assert len(reports)==1 and int(reports[0][0])==n_samples
profiler['terminal_successes']=sum(bool(r['success']) for r in terminals)
profiler['terminal_failures']=sum(not r['success'] for r in terminals)
profiler['reported_sampling_errors']=int(reports[0][1])
profiler['reported_count_lines']=[dict(samples=int(a),errors=int(b)) for a,b in reports]
profiler['stack_read_warning_count']=log.count('Failed to get stack trace')
profiler['sampling_lag_warning_lines']=[line for line in log.splitlines() if 'behind in sampling' in line]
profiler['exclusive_stack_categories']=dict(stack_categories)
profiler['non_save_results_nearest_project_frames']=top(non_serialization_nearest)
profiler['non_save_results_samples']=sum(non_serialization_nearest.values())
profiler['denominator_note']='All fractions use total GIL samples; categories are mutually exclusive ancestry labels, not measured time phases.'
assert sum(stack_categories.values())==n_samples
out=raw/'prefix1_cpu_samples.json'
with out.open('x') as h:json.dump(profiler,h,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(out),samples=n_samples,categories=dict(stack_categories),
    warnings=profiler['stack_read_warning_count'],reports=profiler['reported_count_lines'],
    nearest_non_save=profiler['non_save_results_nearest_project_frames'][:12]),indent=2))

