"""D167 scoped verification pattern, reused for the warm-input-only checkpoint."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, digest, verify_seal, check_plan

RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
BASE = '881d0485716a091fabd300e830afa280951381aa'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
prior = subprocess.check_output(['git','show',BASE+':scripts/ieee_tc_preflight.py'],cwd=ROOT,text=True)
new = (ROOT/'scripts/ieee_tc_preflight.py').read_text()
filtered = ast.Module(body=[n for n in ast.parse(new).body
    if not isinstance(n,ast.FunctionDef) or n.name!='warm_reference_input_index'],type_ignores=[])
assert ast.dump(filtered)==ast.dump(ast.parse(prior))
for path in ('faaslora/memory/gpu_monitor.py','scripts/run_all_experiments.py',
             'faaslora/memory/residency_manager.py','faaslora/preloading/planning_cpu.py',
             'faaslora/preloading/preloading_planner.py','faaslora/experiment/instance_pool.py'):
    assert (ROOT/path).read_bytes()==subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
curated=OUT/'20261002_d168_warm_input_index.json'
assert digest(curated)=='563abfbdeb74c1bc03e42a26c34d48d634c342ac4fa43bd00c5ff8dd82269793'
data=json.loads(curated.read_text())
assert data['measured_warm_reference'] is False and data['thresholds'] is None
assert data['batch_size'] is None and not data['formal_g1_g2_qualified']
assert data['raw_quartiles']==[616,760,760]
assert data['finite_upper_bounds']==[616]
assert data['check_source_sha256']==digest(ROOT/'scripts/ieee_tc_preflight.py')
for path,sha in data['sources'].items():
    assert digest(Path(path))==sha,path
assert re.search(r'\nRan 79 tests in [0-9.]+s\n\nOK\n',(RAW/'tests1.log').read_text())
receipts=[]
for phase in ('tests1','analysis1'):
    receipt=(RAW/f'{phase}_scope.txt').read_text()
    actual=re.search(r'^InvocationID=([a-f0-9]{32})$',receipt,re.M)[1]
    unit=f'primelora-d168-{phase}-20261002.scope'
    state=subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState',
                                 '-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines()==['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert all(int(line.split()[1])==0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text())==0
    assert 'Exit status: 0' in (RAW/f'{phase}_time.txt').read_text()
    receipts.append(dict(phase=phase,actual_invocation_id=actual,cleanup='automatic_removal_verified'))
with (RAW/'cleanup_verified.json').open('x') as f:
    json.dump(receipts,f,indent=2)
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
doc=ROOT/'docs/ieee_tc/D168_WARM_REFERENCE_INPUT_INDEX.md'
table=OUT/'20261002_d168_warm_input_index.csv'
with table.open() as f:
    rows=list(csv.DictReader(f))
assert len(rows)==len(data['groups'])==2
for r,g in zip(rows,data['groups']):
    assert int(r['population'])==g['source_count']
    assert int(r['selected'])==len(g['selected'])==256
    assert int(r['adapters'])==g['selected_unique_adapters']
verification=OUT/'20261002_d168_verification.json'
with verification.open('x') as f:
    json.dump(dict(passed=True,base_commit=BASE,
        only_new_preflight_function='warm_reference_input_index',
        existing_preflight_ast_unchanged=True,serving_source_unchanged=True,
        protected=protected,cleanup=receipts,curated_sha256=digest(curated),
        table_sha256=digest(table),document_sha256=digest(doc)),f,indent=2)
members=sorted(p for p in RAW.iterdir() if p.is_file() and not p.name.startswith('verify1'))
extras=[ROOT/'scripts/ieee_tc_preflight.py', ROOT/'tests/test_ieee_tc_warm_reference.py',
        doc,curated,table,verification]
hashes={}
bundle=OUT/'20261002_d168_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for p in members+extras:
        assert p.stat().st_size < 2*1024**2
        name='raw/'+p.name if p in members else str(p.relative_to(ROOT))
        hashes[name]=digest(p)
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name,sha in hashes.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha
with (OUT/'20261002_d168_evidence_members.json').open('x') as f:
    json.dump(dict(passed=True,member_sha256=hashes),f,indent=2)
with (OUT/'20261002_d168_evidence.sha256').open('x') as f:
    f.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,receipts=receipts,curated_sha256=digest(curated),
    bundle_sha256=digest(bundle),members=len(hashes),bundle_bytes=bundle.stat().st_size),indent=2))
