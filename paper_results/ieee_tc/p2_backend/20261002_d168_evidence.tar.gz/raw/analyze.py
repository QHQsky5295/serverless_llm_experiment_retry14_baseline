"""Use the retained D164 compact projection ONLY for a new warm-input index."""
import csv
import json
from pathlib import Path
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal, warm_reference_input_index
from faaslora.datasets.workload_generator import FrozenReplayPlan

RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX = '20261002_d168_warm_input_index'
refs = {}
def load(path, expected=None):
    assert path.stat().st_size < 128*1024**2
    sha = digest(path)
    assert expected is None or sha == expected, (path,sha)
    refs[str(path)] = sha
    return json.loads(path.read_text())

curated = load(OUT/'20261002_d164_7b_full_w0_full1.json',
    '7076db88971a1a1de7ece273ba82aa8882e7ad92b2cdf32e35d121d105b98bab')
assert curated['native_contract_completion_pass']
projection = load(RAW.parent/'d164_20261002/full_full1_request_projection.json',
    '355f5676102038367e991f0ab4101635dad54f96e55aa353d0dee1046cf52567')
trace = Path('/home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260424_131528_llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1/shared_artifacts/llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json')
assert digest(trace) == 'efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
refs[str(trace)] = digest(trace)
plan = FrozenReplayPlan.load(trace)
assert len(plan.entries) == plan.source_count == len(projection['requests']) == 4000
result = warm_reference_input_index(plan, projection['requests'])
assert result['measured_warm_reference'] is False and result['thresholds'] is None
result.update(model='7b', source_trace_seed=42,
    plan_sha256=check_plan(),
    metric_protocol_sha256=digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    check_source_sha256=digest(ROOT/'scripts/ieee_tc_preflight.py'),
    sources=refs,
    protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json'))
assert result['protected']['pass'] and result['protected']['entry_count'] == 147
summary = []
for group in result['groups']:
    # Counts constrain the upcoming feasibility test; they are not proof that
    # max_num_seqs/max_loras/KV can execute this batch on the actual GPU.
    selected = group['selected']
    batches = [selected[i:i+8] for i in range(0,len(selected),8)]
    assert len(batches) == 32 and all(len(batch) == 8 for batch in batches)
    group['batch8_input_requirements'] = dict(
        maximum_distinct_adapters=max(len({r['adapter_id'] for r in batch}) for batch in batches),
        maximum_declared_context_tokens=max(
            sum(r['native_prompt_tokens']+r['target_tokens'] for r in batch) for batch in batches),
        actual_kv_block_feasibility=None)
    summary.append(dict(group=group['group_id'], population=group['source_count'],
        eligible=group['tpot_eligible_count'], selected=group['selected_unique_requests'],
        adapters=group['selected_unique_adapters'],
        input_min=group['native_prompt_range'][0], input_max=group['native_prompt_range'][1],
        selected_input_min=group['selected_prompt_range'][0], selected_input_max=group['selected_prompt_range'][1],
        target_min=group['selected_target_range'][0], target_max=group['selected_target_range'][1],
        batch8_max_distinct_adapters=group['batch8_input_requirements']['maximum_distinct_adapters'],
        batch8_max_declared_context_tokens=group['batch8_input_requirements']['maximum_declared_context_tokens']))
with (OUT/(PREFIX+'.json')).open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
with (OUT/(PREFIX+'.csv')).open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(summary[0]),lineterminator='\n')
    writer.writeheader()
    writer.writerows(summary)
print(json.dumps(dict(passed=True, groups=summary,
    raw_quartiles=result['raw_quartiles'], finite_upper_bounds=result['finite_upper_bounds'],
    index_sha256=digest(OUT/(PREFIX+'.json')), measured_warm_reference=False),indent=2))
