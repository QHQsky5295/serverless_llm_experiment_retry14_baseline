#!/usr/bin/env bash
# Reuse bounded CPU analysis protocol. No service, remote, or model launch.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d155_20261002
unit=primelora-d155-capacity1-20261002.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/capacity1_scope.txt"
sha256sum scripts/analyze_control_path_overhead.py tests/test_ieee_tc_capacity_audit.py > "$raw/capacity1_sources.sha256"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
/usr/bin/time -v -o "$raw/tests1_time.txt" "$python" -m unittest tests.test_ieee_tc_capacity_audit tests.test_ieee_tc_control_timeline -v > "$raw/tests1.log" 2>&1
source=results/ieee_tc/p2_backend_qualification/d154_20261002/full_full1_main_outcome_compact.json
test "$(sha256sum "$source" | cut -d' ' -f1)" = 2c5d17d718f27a491e8f6ad655ea198c6917543727cfc837769589681b7c7c0f
/usr/bin/time -v -o "$raw/capacity1_time.txt" "$python" scripts/analyze_control_path_overhead.py \
  --admission-capacity --input "$source" \
  --output paper_results/ieee_tc/p2_backend/20261002_d155_admission_capacity > "$raw/capacity1.log" 2>&1
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events" > "$raw/capacity1_memory_events.txt"
date -Is
