"""Reuse D154 small evidence packaging plus protected-artifact verification."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal, check_plan

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = Path(__file__).resolve().parent
output = root/'paper_results/ieee_tc/p2_backend'
unit = 'primelora-d155-capacity1-20261002.scope'
def prop(name):
    return subprocess.check_output(['systemctl', '--user', 'show', unit, '-p', name, '--value'], text=True).strip()
assert prop('ActiveState') == 'inactive' and not prop('InvocationID')
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice', unit).exists()
assert 'InvocationID=a9946ef3c54f4866973bed192b9b1f75' in (raw/'capacity1_scope.txt').read_text()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert 'Ran 32 tests' in (raw/'tests1.log').read_text() and '\nOK\n' in (raw/'tests1.log').read_text()
assert all('Exit status: 0' in (raw/name).read_text() for name in ('tests1_time.txt','capacity1_time.txt'))
assert all(line.split()[1] == '0' for line in (raw/'capacity1_memory_events.txt').read_text().splitlines())
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
frozen = root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
assert hashlib.sha256(frozen.read_bytes()).hexdigest() == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
subprocess.run(['sha256sum','-c',str(raw/'capacity1_sources.sha256')],check=True)
for path in (root/'scripts/analyze_control_path_overhead.py', root/'tests/test_ieee_tc_capacity_audit.py'):
    ast.parse(path.read_text(), filename=str(path))
subprocess.run(['bash','-n',str(raw/'run_capacity_audit1.sh')],check=True)
sources = [root/'scripts/analyze_control_path_overhead.py', root/'tests/test_ieee_tc_capacity_audit.py',
           root/'docs/ieee_tc/D155_ADMISSION_CAPACITY_AUDIT.md',
           output/'20261002_d155_admission_capacity/summary.json',
           output/'20261002_d155_admission_capacity/capacity_by_replica.csv']
receipt = dict(kind='d155_capacity_audit_verification_v1', protected=protected,
    actual_capacity_invocation='a9946ef3c54f4866973bed192b9b1f75', analysis_scope_absent=True,
    gpu_idle=True, tests=32, final_memory_events_all_zero=True,
    source_refs=[dict(path=str(p.relative_to(root)), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources],
    serving_changes=False, new_gpu_run=False, new_configuration_qualified=False)
with (output/'20261002_d155_evidence_verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2)
# Explicit bounded evidence, no raw full result/projection or credentials.
names = ['run_capacity_audit1.sh','seal_evidence.py','run_seal.sh','capacity1_scope.txt',
    'capacity1_sources.sha256','tests1.log','tests1_time.txt','capacity1.log',
    'capacity1_time.txt','capacity1_memory_events.txt']
bundle = output/'20261002_d155_analysis_sources.tar.gz'
hashes = {}
with tarfile.open(bundle, 'x:gz') as archive:
    for name in names:
        path = raw/name
        assert 0 < path.stat().st_size < 64*1024
        data = path.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        hashes[name] = hashlib.sha256(data).hexdigest()
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(bundle, 'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
with (output/'20261002_d155_analysis_sources.sha256').open('x') as handle:
    handle.write(hashlib.sha256(bundle.read_bytes()).hexdigest()+'  '+bundle.name+'\n')
with (output/'20261002_d155_analysis_sources_members.json').open('x') as handle:
    json.dump(dict(bundle=bundle.name, member_sha256=hashes, member_checks_pass=True),handle,indent=2)
print(json.dumps(dict(protected=147, tests=32, members=len(hashes), bytes=bundle.stat().st_size,
    bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest())))
