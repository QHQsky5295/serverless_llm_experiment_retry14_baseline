"""D176 exact-parent component comparison, adapted to identity-only rechecks."""
import ast
import asyncio
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import subprocess
from types import MethodType
import scripts.run_all_experiments as implementation
from tests.test_ieee_tc_request_lifecycle import SelectedSourceAdmissionIntegration

ROOT = Path.cwd()
RAW = ROOT/'results/ieee_tc/p2_backend_qualification/d178_20261003'
PARENT = '8ae851c418a0a2d2090e73d56e327b95dca91c14'
source = subprocess.check_output(['git','show',PARENT+':scripts/run_all_experiments.py'],text=True)
functions = [n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.AsyncFunctionDef)
             and n.name == '_ieee_protect_selected_source']
assert len(functions) == 1
namespace = dict(vars(implementation))
exec(compile(ast.Module(body=functions,type_ignores=[]),'<exact-parent-recheck>','exec'),namespace)
rows=[]
for tier in ('gpu','host','host_file','nvme','remote'):
    for version in ('parent','candidate'):
        case=SelectedSourceAdmissionIntegration()
        try:
            runner,slot,trace,plan,owner,_ = case.build(tier if tier in ('gpu','host') else 'remote')
            if tier not in ('gpu','host'):
                case.file_source(runner,trace,publish=tier!='remote',host=tier=='host_file')
            if version == 'parent':
                runner._ieee_protect_selected_source = MethodType(namespace['_ieee_protect_selected_source'],runner)
            result=asyncio.run(runner._exec_request(trace,4,0.,request_plan=plan))
            assert result.success,result.error
            expected='host' if tier=='host_file' else tier
            assert result.readiness_tier_before_dispatch==expected
            counts=Counter(call.kwargs['operation'] for call in slot.engine.ieee_gpu_reference.await_args_list)
            assert counts['source_snapshot']==0 and counts['demand_load_and_acquire']==1
            state=owner.snapshot()
            assert state['live_leases']==state['live_host_source_leases']==slot.active_requests==0
            rows.append(dict(tier=tier,version=version,
                routing_graph_queries=counts['routing_source_snapshot'],
                identity_only_queries=counts['source_identity_snapshot'],
                total_fresh_source_queries=counts['routing_source_snapshot']+counts['source_identity_snapshot'],
                demand_transactions=counts['demand_load_and_acquire'],
                host_holds=counts['hold_host_source'],host_releases=counts['release_host_source'],
                success=True,dispatch_tier=expected,live_gpu_leases=0,live_host_leases=0))
        finally:
            case.doCleanups()
for old,new in zip(rows[::2],rows[1::2]):
    expected=int(old['tier'] in ('host_file','nvme','remote'))
    assert old['routing_graph_queries']-new['routing_graph_queries']==expected
    assert new['identity_only_queries']-old['identity_only_queries']==expected
    excluded={'version','routing_graph_queries','identity_only_queries'}
    assert {k:v for k,v in old.items() if k not in excluded}=={k:v for k,v in new.items() if k not in excluded}
payload=dict(kind='native_identity_only_recheck_component_v1',parent_commit=PARENT,
    parent_runner_sha256=hashlib.sha256(source.encode()).hexdigest(),
    candidate_runner_sha256=hashlib.sha256((ROOT/'scripts/run_all_experiments.py').read_bytes()).hexdigest(),
    gpu_performance_qualified=False,numerical_full_pool_qualified=False,rows=rows)
with (RAW/'probe1.json').open('x') as out: json.dump(payload,out,indent=2,allow_nan=False)
with (RAW/'probe1.csv').open('x',newline='') as out:
    writer=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
print(json.dumps(payload,indent=2))
