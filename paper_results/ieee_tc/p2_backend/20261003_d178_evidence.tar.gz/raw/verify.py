"""Reuse D176 bounded evidence verification/seal, scoped to D178 changes."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal

RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
BASE='8ae851c418a0a2d2090e73d56e327b95dca91c14'
PLAN='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
V1='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert check_plan()==PLAN and digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')==V1
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
serving={
 'scripts/run_all_experiments.py': (
    {'InferenceEngine.ieee_gpu_reference','SubprocessInferenceEngineProxy._rpc',
     'ScenarioRunner._ieee_protect_selected_source'},
    {'InferenceEngine.ieee_source_identities','SubprocessInferenceEngineProxy.ieee_source_identities'}),
 'scripts/dedicated_engine_worker.py': ({'_run_worker'},set()),
 'faaslora/memory/gpu_monitor.py': ({'IEEEWorkerObservationExtension.ieee_gpu_reference'},set()),
 'faaslora/experiment/instance_pool.py': ({'InstanceSlot.accepts_native_sources'},
    {'NativeSourceSnapshot.identity_view','InstanceSlot._accepts_native_source_view',
     'InstanceSlot.commit_native_source_identity'})}
class Functions(ast.NodeVisitor):
    def __init__(self): self.prefix=[];self.found={}
    def visit_ClassDef(self,node):
        self.prefix.append(node.name);self.generic_visit(node);self.prefix.pop()
    def visit_FunctionDef(self,node): self.found['.'.join(self.prefix+[node.name])]=node
    visit_AsyncFunctionDef=visit_FunctionDef
for rel,(changed,added) in serving.items():
    before=ast.parse(subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT,text=True))
    after=ast.parse((ROOT/rel).read_text())
    old,new=Functions(),Functions();old.visit(before);new.visit(after)
    assert set(new.found)-set(old.found)==added and not set(old.found)-set(new.found),rel
    actual={name for name in old.found if ast.dump(old.found[name])!=ast.dump(new.found[name])}
    assert actual==changed,(rel,actual,changed)
    class Restore(ast.NodeTransformer):
        def __init__(self): self.prefix=[]
        def visit_ClassDef(self,node):
            self.prefix.append(node.name);self.generic_visit(node);self.prefix.pop();return node
        def visit_FunctionDef(self,node):
            key='.'.join(self.prefix+[node.name])
            if key in added:return None
            return old.found[key] if key in changed else node
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_AnnAssign(self,node):
            if (rel.endswith('instance_pool.py') and self.prefix==['InstanceSlot']
                    and isinstance(node.target,ast.Name) and node.target.id=='native_source_identity_state'):
                return None
            return node
    assert ast.dump(before)==ast.dump(Restore().visit(after)),rel
unchanged=['faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py',
           'faaslora/preloading/planning_cpu.py','faaslora/scheduling/resource_coordinator.py']
for rel in unchanged:
    assert (ROOT/rel).read_bytes()==subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT)
probe=json.loads((RAW/'probe1.json').read_text())
assert probe['parent_commit']==BASE and probe['candidate_runner_sha256']==digest(ROOT/'scripts/run_all_experiments.py')
assert probe['gpu_performance_qualified'] is False and len(probe['rows'])==10
for old,new in zip(probe['rows'][::2],probe['rows'][1::2]):
    diff=int(old['tier'] in ('host_file','nvme','remote'))
    assert old['routing_graph_queries']-new['routing_graph_queries']==diff
    assert new['identity_only_queries']-old['identity_only_queries']==diff
    assert old['total_fresh_source_queries']==new['total_fresh_source_queries']
    assert old['success'] and new['success'] and old['dispatch_tier']==new['dispatch_tier']
    assert old['live_gpu_leases']==new['live_gpu_leases']==old['live_host_leases']==new['live_host_leases']==0
for phase,count in (('tests1',66),('regression2',958)):
    log=(RAW/f'{phase}.log').read_text()
    assert f'Ran {count} tests' in log and log.rstrip().endswith('OK'),phase
failed=(RAW/'regression1.log').read_text()
assert 'Ran 958 tests' in failed and failed.rstrip().endswith('FAILED (errors=1)')
assert "SimpleNamespace' object has no attribute 'ieee_source_identities'" in failed
cleanup=[]
for phase in ('tests1','regression1','regression2','probe1'):
    for line in (RAW/f'{phase}_sources.sha256').read_text().splitlines():
        sha,path=line.split(maxsplit=1)
        target=(RAW/'test_service_events_tests1.py' if phase=='tests1' and path=='tests/test_ieee_tc_service_events.py'
                else RAW/'test_request_lifecycle_regression1.py'
                if phase in ('tests1','regression1') and path=='tests/test_ieee_tc_request_lifecycle.py'
                else ROOT/path)
        assert digest(target)==sha,(phase,path)
    actual=re.search(r'^InvocationID=([a-f0-9]{32})$',(RAW/f'{phase}_scope.txt').read_text(),re.M)[1]
    state=subprocess.check_output(['systemctl','--user','show',f'primelora-d178-{phase}-20261003.scope',
        '-p','ActiveState','-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines()==['ControlGroup=','ActiveState=inactive','InvocationID=']
    assert all(int(line.split()[1])==0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text())==0
    code=int(phase=='regression1')
    assert f'Exit status: {code}' in (RAW/f'{phase}_time.txt').read_text()
    cleanup.append(dict(phase=phase,actual_invocation_id=actual,returncode=code,
        cleanup='automatic_removal_verified',final_memory_events_zero=True,final_swap_zero=True))
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
doc=ROOT/'docs/ieee_tc/D178_IDENTITY_ONLY_RECHECK.md'
for old,new in zip(probe['rows'][::2],probe['rows'][1::2]):
    assert f"| {old['tier']} | {old['routing_graph_queries']} → {new['routing_graph_queries']} | {old['identity_only_queries']} → {new['identity_only_queries']} | {new['total_fresh_source_queries']} | 0 |" in doc.read_text()
with (RAW/'cleanup_verified.json').open('x') as out:json.dump(cleanup,out,indent=2)
table=OUT/'20261003_d178_identity_recheck.csv'
with table.open('xb') as out:out.write((RAW/'probe1.csv').read_bytes())
curated=OUT/'20261003_d178_identity_recheck.json'
refs=[ROOT/p for p in serving]+[RAW/'probe.py',RAW/'probe1.json',ROOT/'tests/test_ieee_tc_identity_recheck.py']
with curated.open('x') as out:
    json.dump(dict(kind='native_identity_only_recheck_qualification_v1',base_commit=BASE,
        metric_protocol_sha256=V1,plan_sha256=PLAN,probe=probe,cleanup=cleanup,
        source_sha256={str(p):digest(p) for p in refs},tests_targeted=66,tests_regression=958,
        test_counts_overlap=True,failed_test_attempts=1,no_new_gpu_run=True,
        end_to_end_improvement_qualified=False,n_correct=None,formal_g1_g2_qualified=False,
        common_reference_frozen=False,table_sha256=digest(table),document_sha256=digest(doc)),out,indent=2)
for path in RAW.glob('*.py'):ast.parse(path.read_text())
verification=OUT/'20261003_d178_verification.json'
with verification.open('x') as out:
    json.dump(dict(passed=True,base_commit=BASE,non_target_serving_ast_unchanged=True,
        byte_identical_files=unchanged,protected=protected,cleanup=cleanup,
        curated_sha256=digest(curated),table_sha256=digest(table),document_sha256=digest(doc)),out,indent=2)
members=sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size<2*1024**2
               and not p.name.startswith('verify1') and p.suffix!='.lock')
extras=[doc,curated,verification,table]+[ROOT/p for p in serving]+[
    ROOT/'tests/test_ieee_tc_identity_recheck.py',ROOT/'tests/test_ieee_tc_request_lifecycle.py',
    ROOT/'tests/test_ieee_tc_service_events.py']
hashes={}
bundle=OUT/'20261003_d178_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for path in members+extras:
        name='raw/'+str(path.relative_to(RAW)) if path in members else str(path.relative_to(ROOT))
        hashes[name]=digest(path);tar.add(path,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name,sha in hashes.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha
with (OUT/'20261003_d178_evidence_members.json').open('x') as out:
    json.dump(dict(passed=True,member_sha256=hashes,source_raw_retained_and_bound=True),out,indent=2)
with (OUT/'20261003_d178_evidence.sha256').open('x') as out:out.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    members=len(hashes),bundle_bytes=bundle.stat().st_size,cleanup=cleanup),indent=2))
