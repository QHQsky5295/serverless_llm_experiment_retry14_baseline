"""Reuse D176 exact-scope staged and nested-bundle secret check."""
import io
from pathlib import Path
import re
import subprocess
import tarfile

paths=subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().split('\0')[:-1]
allowed={'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D178_IDENTITY_ONLY_RECHECK.md',
         'scripts/run_all_experiments.py','scripts/dedicated_engine_worker.py',
         'faaslora/experiment/instance_pool.py','faaslora/memory/gpu_monitor.py',
         'tests/test_ieee_tc_request_lifecycle.py','tests/test_ieee_tc_service_events.py',
         'tests/test_ieee_tc_identity_recheck.py'}
assert len(paths)==15,(len(paths),paths)
assert all(p in allowed or p.startswith('paper_results/ieee_tc/p2_backend/20261003_d178_') for p in paths)
assert 'configs/generated/lora_manifest_1000.json' not in paths
token=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(token)>16
count=0
def inspect(data,name):
    global count
    assert token not in data,'credential content found'
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    count+=1
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for member in archive.getmembers():
                assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
                inspect(archive.extractfile(member).read(),member.name)
for path in paths:
    inspect(subprocess.check_output(['git','show',':'+path]),path)
print(f'PASS: {len(paths)} scoped files; {count} staged/archive entries checked; user manifest absent')
