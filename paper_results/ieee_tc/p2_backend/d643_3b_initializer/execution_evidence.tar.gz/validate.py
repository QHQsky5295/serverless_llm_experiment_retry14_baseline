"""CPU-only D643 completed-length reuse and unchanged strict gates."""
import ast, json, os, subprocess, sys, unittest
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(name,obj):
    with (RAW/name).open('x') as f:json.dump(obj,f,indent=2)
identity=p.scope_identity(p.cg_path().name);save('qualification_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT,RAW],64*1024*1024);save('qualification_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
shell=ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh'
code=shell.read_text();old=subprocess.check_output(['git','show','HEAD:scripts/ieee_tc/run_d298_capacity_source.sh'],cwd=ROOT,text=True)
case=code[code.index('  d644)'):code.index('  d642)')]
assert code.replace(case,'',1).replace(' || "${1:-d298}" == d644','')==old
subprocess.run(['bash','-n',str(shell)],check=True)
script=ROOT/'scripts/ieee_tc/prepare_d298_capacity.py'
ast.parse(script.read_text())
from tests.test_ieee_tc_preflight import MeasuredAdmissionInitializer
with (RAW/'tests.log').open('x') as f:
    result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(MeasuredAdmissionInitializer))
assert result.wasSuccessful()
from scripts.ieee_tc.prepare_d298_capacity import prepare_3b_completed_initializer
prepare_3b_completed_initializer()
import torch
assert not torch.cuda.is_initialized()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
save('qualification.json',dict(passed=True,tests=result.testsRun,no_cuda_initialized=True,
    legacy_source_branches_unchanged=True,protected=protected,
    helper_sha256=p.digest(script),runner_sha256=p.digest(shell)))
print(json.dumps(dict(passed=True,tests=result.testsRun,no_cuda_initialized=True)))
