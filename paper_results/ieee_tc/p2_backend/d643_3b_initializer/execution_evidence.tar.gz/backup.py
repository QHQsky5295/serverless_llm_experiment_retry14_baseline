"""Reuse explicit-file backup after actual D643 CPU qualification."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'","OUT=ROOT/'paper_results/ieee_tc/p2_backend/d643_3b_initializer'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'","=='3997f982066ce11060bfbaa0e77ee41ef0164f05'")
begin=code.index('reg=read(RAW/');end=code.index('preserved={',begin)
code=code[:begin]+'''audit=read(RAW/'qualification.json');assert audit['passed'] and audit['tests']==13
for name,key in [('scripts/ieee_tc/prepare_d298_capacity.py','helper_sha256'),('scripts/ieee_tc/run_d298_capacity_source.sh','runner_sha256')]:
    assert p.digest(ROOT/name)==audit[key]
closure=read(RAW/'qualification_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
gate=p.preflight([ROOT],32*1024*1024);assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
''' +code[end:]
begin=code.index('members=[RAW/name');end=code.index('\nfor path in members:',begin)
code=code[:begin]+'''members=[RAW/name for name in ('validate.py','close.py','backup.py','qualification_identity.json',
    'qualification_gate.json','qualification.json','qualification_closure.json','tests.log','backup_gate.json')]
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
''' +code[end:]
replace('OUT.mkdir(parents=True,exist_ok=False)',"assert OUT.is_dir() and read(OUT/'prepare.json')['passed']")
begin=code.index('test_counts={');end=code.index("save(OUT/'qualification.json'",begin)
code=code[:begin]+'''test_counts={'measured_admission_initializer_cpu':13}
record=dict(passed=True,production_candidate=False,native_gpu_validation=False,full_performance_run=False,
    parent_commit='3997f982066ce11060bfbaa0e77ee41ef0164f05',audit=audit,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='Completed-length initializer only; fresh admission-enabled timing and Full qualification remain pending.')
''' +code[end:]
replace("for name in ('qualification.json','execution_evidence.tar.gz'):f.write", "for name in ('qualification.json','execution_evidence.tar.gz','completed_length_audit.json','development_contract.json','source_spec.json','prepare.json'):f.write")
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['scripts/ieee_tc/prepare_d298_capacity.py','scripts/ieee_tc/run_d298_capacity_source.sh','docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D643_3B_COMPLETED_LENGTH_INITIALIZATION.md']")
replace("('qualification.json','execution_evidence.tar.gz','result.sha256')", "('qualification.json','execution_evidence.tar.gz','result.sha256','completed_length_audit.json','development_contract.json','source_spec.json','prepare.json')")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: bind completed 3B lengths to current admission runtime (D643)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
