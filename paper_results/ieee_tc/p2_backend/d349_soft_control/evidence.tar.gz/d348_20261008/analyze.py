"""D348 bounded retained-data audit. No inference or remote mutation."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def main():
    raw = Path(__file__).resolve().parent
    unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
    identity = p.scope_identity(unit)
    group = Path(identity['path'])
    def sample():
        return {k:(group/k).read_text().strip() for k in ('memory.peak','memory.events',
            'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events')}
    before = sample()
    assert before['memory.high'] == str(3*1024**3)
    assert before['memory.max'] == str(4*1024**3) and before['memory.swap.max'] == '0'
    assert os.sched_getaffinity(0) == {2,3,26,27}
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
        '--format=csv,noheader'],text=True).strip()
    commands = [
        [sys.executable,'-m','unittest','tests.test_ieee_tc_decode_overlap','-q'],
        [sys.executable,'-m','scripts.ieee_tc.analyze_d297_full','--calibration-target-output',
         'paper_results/ieee_tc/p2_backend/d348_soft_target_evidence/analysis1'],
    ]
    codes = []
    try:
        with (raw/'analysis1.log').open('x') as log:
            for command in commands:
                print(json.dumps(dict(command=command)),file=log,flush=True)
                result = subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
                codes.append(result.returncode)
                result.check_returncode()
    finally:
        with (raw/'analysis1_receipt.json').open('x') as f:
            json.dump(dict(identity=identity,before=before,after=sample(),commands=commands,
                returncodes=codes,pass_all=len(codes)==len(commands) and not any(codes)),f,indent=2)
    print(json.dumps(dict(returncodes=codes,receipt=str(raw/'analysis1_receipt.json'))))

if __name__=='__main__':
    main()
