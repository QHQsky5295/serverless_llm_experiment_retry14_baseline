"""Seal D348 data reuse and tested D349 configuration, then exact-path stage."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
prior=raw.parent/'d348_20261008'
analysis=ROOT/'paper_results/ieee_tc/p2_backend/d348_soft_target_evidence'
out=ROOT/'paper_results/ieee_tc/p2_backend/d349_soft_control'
out.mkdir(exist_ok=False)
test=json.loads((raw/'cpu_tests1_receipt.json').read_text())
assert test['returncode']==0
identity=test['identity'];group=Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
assert resources['memory.swap.current'].strip()=='0'
assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
stopped=p.stop_scope_identity(identity)
assert stopped['released'] and not stopped['hard_kill'] and not group.exists()
with (raw/'preparation_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,cleanup=stopped),f,indent=2)
assert json.loads((prior/'cleanup.json').read_text())['cleanup']['released']
binding=json.loads((raw/'prelaunch_binding.json').read_text());assert binding['passed']
for ref in binding['source_references']:
    assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
manifest=json.loads((analysis/'analysis1/manifest.json').read_text())
for name,digest in manifest['outputs'].items():assert p.digest(analysis/'analysis1'/name)==digest
for ref in manifest['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256']
assert manifest['analysis_script_sha256']==p.digest(ROOT/'scripts/ieee_tc/analyze_d297_full.py')
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def safe(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
paths=sorted(x for directory in (prior,raw) for x in directory.iterdir() if x.is_file())
archive=out/'evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        data=path.read_bytes();safe(data)
        if path.suffix=='.py':ast.parse(data)
        if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
        tar.add(path,arcname=str(path.relative_to(raw.parent)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw.parent))).read()).hexdigest()==p.digest(path)
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert seal['entry_count']==147 and seal['changed']==[known]
assert p.digest(Path(known))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
with (out/'prelaunch_binding.json').open('x') as f:json.dump(binding,f,indent=2,allow_nan=False)
with (out/'evidence.json').open('x') as f:
    json.dump(dict(kind='d348_d349_evidence_checkpoint_v1',passed=True,new_GPU_runs=0,
        no_figures=True,n_correct=None,formal_qualification=False,analysis_tests=65,preparation_tests=252,
        tests_overlap_not_independent=True,protected=seal,source_plan_sha256=p.check_plan(),
        metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
        archive_sha256=p.digest(archive),archive_bytes=archive.stat().st_size,
        refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths]),f,indent=2)
for directory in (analysis,out):
    with (directory/'outputs.sha256').open('x') as f:
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.name!='outputs.sha256':
                f.write(p.digest(path)+'  '+str(path.relative_to(directory))+'\n')
    subprocess.run(['sha256sum','-c','outputs.sha256'],cwd=directory,check=True,stdout=subprocess.DEVNULL)
relative=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D348_C14_PROFILE_IDENTIFIABILITY.md',
    'docs/ieee_tc/D349_DECOUPLED_CAPACITY_WORKING_POINT.md','scripts/ieee_tc_preflight.py',
    'scripts/ieee_tc/analyze_d297_full.py','scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    'tests/test_ieee_tc_launch.py','tests/test_ieee_tc_decode_overlap.py',
    'configs/ieee_tc/20261008_d349_7b_full_w0.yaml']
relative += [str(path.relative_to(ROOT)) for directory in (analysis,out)
    for path in sorted(directory.rglob('*')) if path.is_file()]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','add','--',*relative],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(relative) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert data==(ROOT/name).read_bytes();safe(data)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
own=p.scope_identity(p.cg_path().name)
with (raw/'checkpoint_verification.json').open('x') as f:
    json.dump(dict(passed=True,staged_paths=staged,identity=own,archive_members=len(paths),
        resources={k:(Path(own['path'])/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(passed=True,staged_paths=len(staged),archive_members=len(paths))))
