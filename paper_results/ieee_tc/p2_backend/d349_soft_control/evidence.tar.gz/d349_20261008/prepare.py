"""Bounded D349 control/config tests and unchanged C14 profile binding."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.run_all_experiments import (ScenarioRunner,
    _prepare_scenario_runtime_model_config, _prepare_dedicated_subprocess_model_cfg)

def main():
    raw = Path(__file__).resolve().parent
    identity = p.scope_identity(p.cg_path().name)
    group = Path(identity['path'])
    def sample():
        return {k:(group/k).read_text().strip() for k in ('memory.peak','memory.events',
            'memory.swap.current','memory.high','memory.max','memory.swap.max')}
    before = sample()
    assert before['memory.high']==str(3*p.GIB) and before['memory.max']==str(4*p.GIB)
    assert before['memory.swap.max']=='0' and os.sched_getaffinity(0)=={2,3,26,27}
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
        '--format=csv,noheader'],text=True).strip()
    prior = json.loads((raw.parent/'d348_20261008/analysis1_receipt.json').read_text())
    assert prior['pass_all']
    oldgroup=Path(prior['identity']['path'])
    assert p.scope_still_owned(prior['identity']) and not p.owned_pids(oldgroup)
    cleanup=p.stop_scope_identity(prior['identity'])
    assert cleanup['released'] and not cleanup['hard_kill'] and not oldgroup.exists()
    with (raw.parent/'d348_20261008/cleanup.json').open('x') as f:
        json.dump(dict(identity=prior['identity'],cleanup=cleanup),f,indent=2)
    command=[sys.executable,'-m','unittest','tests.test_ieee_tc_launch',
        'tests.test_ieee_tc_decode_overlap','tests.test_ieee_tc_control_timeline','-q']
    with (raw/'cpu_tests1.log').open('x') as f:
        result=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
    with (raw/'cpu_tests1_receipt.json').open('x') as f:
        json.dump(dict(identity=identity,before=before,after=sample(),command=command,
            returncode=result.returncode),f,indent=2)
    result.check_returncode()
    config=ROOT/'configs/ieee_tc/20261008_d349_7b_full_w0.yaml'
    previous=ROOT/'configs/ieee_tc/20261008_d346_7b_full_w0.yaml'
    reference=ROOT/'configs/ieee_tc/20261008_d336_7b_full_w0.yaml'
    c,old,ref=(yaml.safe_load(x.read_text()) for x in (config,previous,reference))
    expected=copy.deepcopy(old)
    for section,field in (('experiment','output_dir'),('storage','nvme_cache_dir'),('storage','host_cache_dir')):
        assert not Path(c[section][field]).exists()
        expected[section][field]=c[section][field]
    assert c['experiment']['output_dir']==str(raw/'7b_full_w0')
    assert c['storage']['nvme_cache_dir']==str(raw/'7b_nvme_w0')
    assert c['storage']['host_cache_dir']=='/dev/shm/tc-d349-7b-w0'
    target=ref['model']['runtime_concurrency_cap']
    coord=c['resource_coordination']
    derived=p.derive_ieee_capacity_targets(c['model']['runtime_concurrency_cap'],
        min_instances=coord['min_instances'],max_instances=coord['max_instances'],target_capacity=target)
    expected['resource_coordination']['ieee_scaling'].update(derived)
    assert c==expected and target==8 and c['workload']['total_requests']==4000
    configured=_prepare_scenario_runtime_model_config(c['model'],c['workload'],coord)
    child,assembly=_prepare_dedicated_subprocess_model_cfg(configured,device_id=0,runtime_gpu_ids=[0])
    contract=ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/development_contract.json'
    assert child==json.loads(contract.read_text())['model_config']
    bound=ScenarioRunner.__new__(ScenarioRunner)
    bound.model_cfg,bound.engine,bound.coord_cfg=child,SimpleNamespace(model_cfg=child),coord
    bound._service_profiles=bound._load_ieee_service_profiles()
    assert len(bound._service_profiles.profiles)==200
    assert len(bound._load_ieee_preparation_profiles().profiles)==24
    seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
    known=Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
    assert seal['changed']==[str(known)] and seal['entry_count']==147
    assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
    assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
    assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
    assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
    preflight=p.preflight([ROOT],32*p.GIB)
    assert preflight['preflight_pass'],preflight['issues']
    refs=[config,previous,reference,contract,Path(__file__),
        ROOT/'scripts/ieee_tc_preflight.py',ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
        ROOT/'faaslora/coordination/autoscaler.py',ROOT/'scripts/run_all_experiments.py',
        ROOT/'paper_results/ieee_tc/p2_backend/d348_soft_target_evidence/analysis1/summary.json']
    receipt=dict(kind='d349_decoupled_soft_target_prelaunch_v1',passed=True,
        target_capacity=target,physical_capacity=14,derived=derived,model_config=child,
        assembly=assembly,source_references=[dict(path=str(x),sha256=p.digest(x)) for x in refs],
        service_classes=200,preparation_classes=24,protection=seal,preflight=preflight,
        base_requests=4000,diagnostic_prefix_count=None,n_correct=None,formal_qualification=False,
        no_figures=True,scope=identity,resources=sample())
    with (raw/'prelaunch_binding.json').open('x') as f:
        json.dump(receipt,f,indent=2,allow_nan=False)
    print(json.dumps(dict(passed=True,classes=[200,24],derived=derived,
        disk_free=preflight['filesystems'][0]['free_bytes'],mem_available=preflight['memory']['MemAvailable'])))

if __name__=='__main__':
    main()
