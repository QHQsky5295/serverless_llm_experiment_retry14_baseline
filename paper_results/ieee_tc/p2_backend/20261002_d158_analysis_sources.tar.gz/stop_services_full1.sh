#!/usr/bin/env bash
set -euo pipefail
# Existing D150 exact-identity cleanup, bound to this actual activation.
# Execute remotely ONLY after local terminal and physical GPU cleanup.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d158full1.service)
ids=(79a234da230b4e0a9a56b5f82f9229e8 474129f7ef96401fbdaa8c71ea7c1154 6ea9834c984f452dbb15be64acae72b1)
pids=(2969058 2969060 2969063)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result

