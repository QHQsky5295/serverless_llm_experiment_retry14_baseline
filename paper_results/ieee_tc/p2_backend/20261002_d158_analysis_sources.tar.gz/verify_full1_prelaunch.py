"""Reuse D154 prelaunch checks with D157's qualified capacity/profile contract."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight, check_plan
from faaslora.runtime_configuration import resolve_facade_lora_capacity

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d158_20261002'
previous = root/'results/ieee_tc/p2_backend_qualification/d154_20261002'
calibration = root/'results/ieee_tc/p2_backend_qualification/d157_20261002'
expected_commit = '2c3d4d6bab50275991025d2c79b175909aaaa75f'
prior_runtime = '39cc3c1147f1699a4e7cddb54996be2564a895c3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected_commit
dirty = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty) <= {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'}, dirty
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old_path, new_path = calibration/'7b_main_config_full1.yaml',raw/'7b_main_config_full1.yaml'
old, new = [yaml.safe_load(path.read_text()) for path in (old_path,new_path)]
for config in (old,new):
    assert config['workload']['total_requests'] == 4000
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
assert old == new, 'change beyond three fresh owned paths from actual D157 assembly'
old_full = yaml.safe_load((previous/'7b_main_config_full1.yaml').read_text())
comparable = copy.deepcopy(new)
del old_full['experiment']['output_dir']
del old_full['storage']['nvme_cache_dir']
del old_full['storage']['host_cache_dir']
declared_model_changes = ('max_num_seqs','runtime_concurrency_cap','requested_runtime_concurrency_cap','ieee_admission_profile')
declared_profiles = ('ieee_service_profile','ieee_preparation_profile')
for config in (old_full,comparable):
    for key in declared_model_changes:
        del config['model'][key]
    for key in declared_profiles:
        del config['resource_coordination'][key]
assert old_full == comparable, 'D154 controls/generation/resources changed beyond capacity initialization'
assert not (raw/'7b_full_w0_full1').exists()
assert not (raw/'7b_nvme_full1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d158-7b-full1/tc_ieee_full').exists()
prior = previous/'prelaunch_verification.json'
assert digest(prior) == 'a63468029ab5b1a1e2b2aa1a9a459a6e7fe70aa71d0d36ecf56d21584603b740'
full_before = json.loads(prior.read_text())
refs = dict(full_before['source_sha256'])
allowed_changes = {'scripts/analyze_control_path_overhead.py','scripts/plot_paper_figures.py',
                   'tests/test_ieee_tc_capacity_audit.py','tests/test_v2_analysis_tools.py'}
actual_changed = set(subprocess.check_output(['git','diff','--name-only',prior_runtime,expected_commit,'--',
                                             'faaslora','scripts','tests'],cwd=root,text=True).splitlines())
assert actual_changed == allowed_changes, actual_changed
changes = []
for name, expected in tuple(refs.items()):
    path = Path(name) if name.startswith('/') else root/name
    actual = digest(path)
    if actual != expected:
        relative = str(path.relative_to(root))
        assert relative in allowed_changes, (name,expected,actual)
        before = subprocess.check_output(['git','show',prior_runtime+':'+relative],cwd=root)
        after = subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)
        assert hashlib.sha256(before).hexdigest() == expected
        assert hashlib.sha256(after).hexdigest() == actual
        changes.append(dict(path=relative,before=expected,after=actual))
        refs[name] = actual
for relative in allowed_changes:
    path = root/relative
    assert digest(path) == hashlib.sha256(subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)).hexdigest()
    refs[str(path)] = digest(path)
verification_path = root/'paper_results/ieee_tc/p2_backend/20261002_d157_evidence_verification.json'
assert digest(verification_path) == '61b606b02363a85952fd53bf7d408c19de40875393468530c846aefed7934158'
verification = json.loads(verification_path.read_text())
assert verification['actual_native_qualification_pass'] and verification['native_contract_samples'] == 184
assert verification['class_domain_covered'] and not verification['full_qualified']
for ref in verification['source_refs']:
    path = root/ref['path']
    assert digest(path) == ref['sha256'], ref['path']
    refs[str(path)] = ref['sha256']
assembly_path = calibration/'main_assembly3.json'
assert digest(assembly_path) == 'b5b8b2cd97454151f34735ceea94d9521aa9619d88358488125b7246c3d61aa0'
assembly = json.loads(assembly_path.read_text())
assert assembly['pass'] and len(assembly['records']) == 1
record = assembly['records'][0]
assert record['pass'] and record['requests'] == 4000 and record['adapter_count'] == 500
assert record['one_runtime_capacity'] == 4 and record['four_runtime_capacity'] == 16
assert record['initialized_engines'] == 0 and not record['actual_inference']
model = resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras'] == 24
assert model['max_num_seqs'] == model['runtime_concurrency_cap'] == model['requested_runtime_concurrency_cap'] == model['max_loras'] == 4
manifest_path = root/'paper_results/ieee_tc/p2_backend/d157_7b_initialization/manifest.json'
assert digest(manifest_path) == '51419cc52b607deb61c71554163ceeda4f6dfda91916bf39af8965cc4c7676ad'
manifest = json.loads(manifest_path.read_text())
assert manifest['pass'] and manifest['coverage']['class_domain_covered']
for key in declared_profiles:
    binding = new['resource_coordination'][key]
    assert binding == manifest['bindings'][key]
    assert digest(root/binding['path']) == binding['sha256']
contract = json.loads((root/manifest['contract']['path']).read_text())
assert new['resource_coordination'] == contract['coordination'] | manifest['bindings']
trace, subset = full_before['trace'], full_before['subset']
assert trace['count'] == trace['source_count'] == 4000 and trace['profile'] == 'W0'
assert trace['view_sha256'] == 'a5331be2e2204483f18206825d9aaa18cbaa259fe0babfc303f989055819430d'
assert digest(Path(trace['source_path'])) == trace['source_sha256'] == 'efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
assert digest(Path(subset['path'])) == subset['sha256'] == 'aa94b21e1295aefde664e5b29c030a9e42e02af946369bfe9ae15336b89b3016'
for path in [raw/name for name in ('7b_main_config_full1.yaml','run_7b_full_w0_full1.sh',
    'activate_services_full1.sh','check_health.sh','run_health.sh','verify_full1_prelaunch.py','prepare_full1.sh')] + [
    verification_path,assembly_path,manifest_path,old_path,prior,root/'docs/ieee_tc/PLAN_APPROVED_20261002_PRIME_FIRST.md']:
    refs[str(path)] = digest(path)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
resources = preflight([root,raw],32*1024**3)
assert resources['preflight_pass'], resources['issues']
receipt = dict(kind='d158_7b_full_prelaunch_v1',time_unix=time.time(),run='d158_7b_full_w0_full1',
    evidence_commit=expected_commit,runtime_source_commit=prior_runtime,source_change='no serving source change since D154',
    expected_source_changes=changes,declared_model_changes=declared_model_changes,declared_profile_changes=declared_profiles,
    same_d157_configuration_except_owned_paths=True,d154_controls_unchanged=True,
    diagnostic_instrumentation=False,formal_performance_result=False,source_sha256=refs,
    protected=protected,resource_preflight=resources,trace=trace,subset=subset,
    replay_scope='ordinary_full_4000',diagnostic_prefix_count=None,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),plan_sha256=check_plan(),
    comparison='D154 versus cap4 + fresh capacity-dependent profiles; descriptive n=1, not G1/G2 acceptance',
    hypothesis='Bounded four-way per-card concurrency reduces waiting behind prepare/generate/retire permit occupancy',
    detailed_cpu_profiler=False,reused_initialization='D156 completed lengths and D157 admission-enabled profiles',
    warm_reference_sha=None,resource_reference_sha=None,
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),sha256=digest(raw/'prelaunch_verification.json'),
    protected=147,source_refs=len(refs),population=4000,resource_pass=True,formal=False,changes=changes)))
