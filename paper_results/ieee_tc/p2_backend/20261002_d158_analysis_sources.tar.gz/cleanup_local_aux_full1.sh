#!/usr/bin/env bash
set -euo pipefail
unit=primelora-tc-aux-7fbea46f21c142679502de2f4a04aef8.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 41e91347bc764ddeb9c465ef7470b5f6
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-7fbea46f21c142679502de2f4a04aef8.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is

