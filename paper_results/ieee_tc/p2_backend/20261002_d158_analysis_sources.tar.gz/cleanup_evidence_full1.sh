#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d158_20261002
unit=primelora-d158-full1-evidence1-20261002.scope
{
  date -Is
  rg -qx 'InvocationID=18c75473e26148c1a9191412aa60530a' "$raw/full_full1_evidence_scope.txt"
  jq -e '.pass_checks == true' paper_results/ieee_tc/p2_backend/20261002_d158_evidence_verification.json
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=18c75473e26148c1a9191412aa60530a\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n'
} | tee "$raw/cleanup_evidence_full1.log"
