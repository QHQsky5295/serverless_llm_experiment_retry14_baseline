"""Bound the existing exact-owned remote stop after physical GPU release."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name)
with (RAW/'management_identity.json').open('x') as f:json.dump(identity,f,indent=2)
g=Path(identity['path'])
assert (g/'memory.max').read_text().strip()==str(4*p.GIB)
assert (g/'memory.swap.max').read_text().strip()=='0'
subprocess.run(['bash',str(RAW/'stop_remote.sh')],check=True)
