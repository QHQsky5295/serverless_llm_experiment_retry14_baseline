"""Finish D815 after generic *.log ignore stopped add before commit."""
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d815_file_capacity_reproduction'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def call(args):
    return subprocess.check_output(args, cwd=ROOT, text=True, stderr=subprocess.STDOUT, timeout=60).strip()

assert os.sched_getaffinity(0) == {2, 3, 26, 27}
own = p.scope_identity(p.cg_path().name)
with (RAW/'finish_backup_identity.json').open('x') as stream:
    json.dump(own, stream, indent=2)
assert call(['git', 'rev-parse', 'HEAD']) == 'afc1890b44ddd5474d5836c67ff7855cb6a6824d'
assert not call(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'])
paths = [str(path.relative_to(ROOT)) for path in OUT.iterdir() if path.is_file()]
paths += ['docs/ieee_tc/D815_FILE_CAPACITY_REPRODUCTION_20261025.md', 'docs/ieee_tc/EXECUTION_STATUS.md']
logs = [str((OUT/name).relative_to(ROOT)) for name in ('tests.log', 'fixture_output.log')]
assert set(call(['git', 'diff', '--cached', '--name-only']).splitlines()) == set(paths)-set(logs)
for row in json.loads((OUT/'manifest.json').read_text())['files']:
    assert p.digest(Path(row['path'])) == row['sha256']
for name in ('tests.log', 'fixture_output.log'):
    assert p.digest(RAW/name) == p.digest(OUT/name)
assert sum((OUT/name).stat().st_size for name in ('tests.log', 'fixture_output.log')) == 1366
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
# These are the 1,366-byte curated CPU validation logs already scanned by the
# previous explicit-path backup. No bulk raw-log add or repository ignore edit.
call(['git', 'add', '-f', '--', *logs])
assert set(call(['git', 'diff', '--cached', '--name-only']).splitlines()) == set(paths)
call(['git', 'diff', '--cached', '--check'])
call(['git', 'commit', '-m', 'tc: reproduce Full demand file-capacity failure without changing policy (D815)'])
head = call(['git', 'rev-parse', 'HEAD'])
ref = 'refs/heads/backup/d815-capacity-repro-20261025'
call(['git', '-c', 'http.version=HTTP/1.1', 'push', 'faaslora_origin', 'HEAD:'+ref])
assert call(['git', '-c', 'http.version=HTTP/1.1', 'ls-remote', 'faaslora_origin', ref]).split()[0] == head
with (RAW/'backup.json').open('x') as stream:
    json.dump(dict(passed=True, head=head, ref=ref, paths=paths, v2_synchronized=False,
        previous_attempt='git add excluded two tiny curated logs under generic *.log rule; no commit/push occurred',
        resources_before_exit=p.cgroup_snapshot(Path(own['path']))), stream, indent=2)
print(json.dumps(dict(passed=True, head=head, ref=ref, files=len(paths))))
