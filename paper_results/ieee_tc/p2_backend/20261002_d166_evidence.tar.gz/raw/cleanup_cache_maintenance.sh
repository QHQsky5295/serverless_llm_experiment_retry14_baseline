#!/usr/bin/env bash
# Reuses D151's actual post-exit absence receipt, not a live-process stop.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
expected_id=$2
case "$phase" in audit|apply) ;; *) exit 2;; esac
[[ "$expected_id" =~ ^[a-f0-9]{32}$ ]]
raw=results/ieee_tc/p2_backend_qualification/d166_20261002
unit="primelora-d166-cache-${phase}1-20261002.scope"
{
date -Is
rg -qx "InvocationID=$expected_id" "$raw/cache_${phase}1_scope.txt"
rg -q 'Exit status: 0' "$raw/cache_${phase}1_time.txt"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
printf 'actual_invocation=%s\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n' "$expected_id"
} | tee "$raw/cache_${phase}1_cleanup.txt"
