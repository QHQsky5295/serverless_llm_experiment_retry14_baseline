#!/usr/bin/env bash
# Read-only exact recorded service absence; does not stop any process.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
attempt=$1
case "$attempt" in 1) aux=primelora-tc-aux-9f7693c8c10d4f0e9026bd839cf81e31.scope;;
  2) aux=primelora-tc-aux-e0283de8c8ee47c89c5028b79d7bd852.scope;;
  3) aux=primelora-tc-aux-bd7ca50155b842e4b8ab5be2a4b888d2.scope;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d166_20261002
launch="$raw/7b_slot_content${attempt}_launch.json"
{
date -Is
test "$(jq -r '.service_path_removed' "$launch")" = true
test "$(jq -r '.native_gpu_context_release_confirmed' "$launch")" = true
unit=$(jq -r '.service_identity.unit' "$launch")
invocation=$(jq -r '.service_identity.invocation_id' "$launch")
[[ "$unit" =~ ^primelora-tc-svc-[a-f0-9]{32}\.scope$ ]]
[[ "$invocation" =~ ^[a-f0-9]{32}$ ]]
for u in "$unit" "$aux"; do
  test "$(systemctl --user show "$u" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$u" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$u"
  systemctl --user show "$u" -p Id -p ActiveState -p InvocationID -p ControlGroup
done
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
printf 'recorded_service_invocation=%s\ncleanup=automatic_removal_verified\n' "$invocation"
} | tee "$raw/slot_content${attempt}_cleanup.txt"
