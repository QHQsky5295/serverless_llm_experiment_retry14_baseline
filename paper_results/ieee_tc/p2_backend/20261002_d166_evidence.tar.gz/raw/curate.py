"""D156 bounded qualification curation reused for actual slot-content evidence."""
import csv
import hashlib
import json
from pathlib import Path
from scripts.ieee_tc_preflight import ROOT, check_plan, verify_seal

RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):
            h.update(b)
    return h.hexdigest()
def load(p):
    assert p.stat().st_size < 128*1024**2
    return json.loads(p.read_text())
inputs = load(RAW/'input_qualification2.json')
assert sha(RAW/'input_qualification2.json') == '56d474d9d69e4724162ccb0a5f938b32d9415a8e7a61576ccd5bf5fdd8f66a16'
attempts, refs = [], {}
for attempt in (1,2,3):
    source = RAW/f'7b_slot_content{attempt}.json'
    lp = RAW/f'7b_slot_content{attempt}_launch.json'
    data, launch = load(source), load(lp)
    assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
    assert 'cleanup=automatic_removal_verified' in (RAW/f'slot_content{attempt}_cleanup.txt').read_text()
    physical = data.get('physical_allocation')
    gpu_s = None
    if physical is not None:
        assert physical['released']
        starts = [e['at'] for e in physical['events'] if e['event'] == 'acquire']
        stops = [e['at'] for e in physical['events'] if e['event'] == 'release']
        assert len(starts) == len(stops) == len(physical['gpu_uuids']) == 1
        gpu_s = stops[0]-starts[0]
    watch_path = RAW/f'7b_slot_content{attempt}_launch.launch/watchdog.jsonl'
    with watch_path.open() as f:
        events = [json.loads(line) for line in f]
    samples = [e for e in events if e['event'] == 'resource_sample']
    assert samples and all(not e['decision']['abort_reasons'] for e in samples)
    memory_events = {k:max(e['service']['memory.events'][k] for e in samples)
                     for k in samples[0]['service']['memory.events']}
    attempts.append(dict(attempt=attempt,passed=data['pass'],stage=data['stage'],
        error=None if data['pass'] else data['error'].split('\n')[0],
        completed_requests=sum(q['pass'] for q in data['requests']),
        native_gpu_s=gpu_s,physical_released=physical['released'] if physical else None,
        service_returncode=launch['service_returncode'],watchdog_returncode=launch['watchdog_returncode'],
        actual_service_invocation=launch['service_identity']['invocation_id'],resource_samples=len(samples),
        peak_memory_bytes=max(e['service']['memory.peak'] for e in samples),
        min_host_available_bytes=min(e['host']['available_bytes'] for e in samples),
        memory_events=memory_events,max_swap_bytes=max(e['service']['memory.swap.current'] for e in samples)))
    for p in (source,lp,watch_path,RAW/f'slot_content{attempt}_cleanup.txt'):
        refs[str(p)] = sha(p)
    if attempt < 3:
        assert not data['pass'] and launch['service_returncode'] == 2
assert attempts[0]['stage'] == 'engine_initialization'
assert attempts[1]['stage'] == 'slot_content_before:req_00000'
assert data['pass'] and data['stage'] == 'complete' and launch['pass']
assert data['shutdown_called'] and not data['performance_sample']
assert not data['semantic_full_pool_qualification'] and not data['full_model_qualification']
assert data['artifact_mode'] == 'existing_local_frozen_qualification_only'
assert data['config_sha256'] == inputs['config_sha256']
assert data['trace']['source_sha256'] == inputs['trace_sha256']
assert data['adapters'].keys() == inputs['adapters'].keys()
for aid, identity in inputs['adapters'].items():
    assert data['adapters'][aid]['weights_sha256'] == identity['weights_sha256']
    assert data['adapters'][aid]['config_sha256'] == identity['config_sha256']
assert len(data['requests']) == len(inputs['rows']) == 22
rows, tensors_count, mismatch, absent = [], 0, 0, 0
for q, expected in zip(data['requests'],inputs['rows']):
    assert q['pass'] and q['release']['released']
    assert all(q[k] == expected[k] for k in expected)
    t = q['timing']
    assert q['actual_tokens'] == q['target_tokens'] == t['native_output_tokens']
    assert t['native_terminal_observed']
    for when in ('before','after'):
        sample = q['slot_content_'+when]
        scheduler = sample['scheduler_before']
        assert sample['pass'] and not sample['performance_sample']
        assert not scheduler['admitted'] and not scheduler['unretired_iterations'] and not scheduler['native_deferred_free_batches']
        workers = sample['worker_observation']['workers']
        assert len(workers) == 1 and workers[0]['device_barrier_used']
        audit = workers[0]['slot_content_audit']
        assert audit['exact_content_pass'] and not audit['checkpoint_to_registered_qualified']
        assert not audit['per_token_execution_mapping_qualified'] and not audit['semantic_full_pool_qualification']
        assert len(audit['adapters']) == 1
        a = audit['adapters'][0]
        assert a['adapter_int_id'] == q['reference']['adapter_int_id']
        assert a['rank'] == inputs['adapters'][q['adapter_id']]['rank']
        tensors = a['tensors']
        assert a['tensor_count'] == len(tensors) == len(workers[0]['pool_tensor_views'])
        assert all(v['exact_value_match'] and v['all_finite'] for v in tensors)
        raw_absent = [v for v in tensors if v['absent_unpacked']]
        assert len(raw_absent) == 4 and all(v['source_absent'] and v['actual_nonzero_elements']==0 for v in raw_absent)
        row = dict(request_id=q['request_id'],adapter_id=q['adapter_id'],phase=when,slot=a['slot'],rank=a['rank'],
            tensor_count=len(tensors),mismatched_elements=sum(v['mismatched_elements'] for v in tensors),
            absent_tensors=sum(v['source_absent'] for v in tensors),absent_unpacked_tensors=len(raw_absent),
            expected_nonzero_elements=sum(v['expected_nonzero_elements'] for v in tensors),
            actual_nonzero_elements=sum(v['actual_nonzero_elements'] for v in tensors),
            bitwise_sha_equal_tensors=sum(v['actual_slot_sha256']==v['expected_padded_sha256'] for v in tensors),passed=True)
        rows.append(row)
        tensors_count += len(tensors)
        mismatch += row['mismatched_elements']
        absent += row['absent_tensors']
assert mismatch == 0
assert all(r['expected_nonzero_elements'] > 0 for r in rows if r['adapter_id'] in ('finance_lora','medical_lora'))
assert all(r['actual_nonzero_elements'] == 0 for r in rows if r['adapter_id'] not in ('finance_lora','medical_lora'))
assert not data['scheduler_after']['admitted']
assert not data['sources_after_eviction']['sources']
assert not data['sources_after_eviction']['registered_cpu_adapter_ids']
assert all(x is None for x in data['sources_after_eviction']['slot_adapter_ids'])
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
for name in ('faaslora/memory/gpu_monitor.py','scripts/run_all_experiments.py','scripts/ieee_tc_preflight.py','configs/ieee_tc/20261002_d166_7b_slot_content.yaml'):
    assert f'{sha(ROOT/name)}  {name}' in (RAW/'slot_content3_sources.sha256').read_text()
    refs[str(ROOT/name)] = sha(ROOT/name)
for p in (RAW/'input_qualification2.json',RAW/'public_download_cache_complete1.json'):
    refs[str(p)] = sha(p)
result = dict(kind='d166_actual_native_slot_content_validation_v1',passed=True,attempts=attempts,
    original_requests=22,logical_adapters=len(data['adapters']),distinct_weight_sha=4,
    snapshots=len(rows),tensor_comparisons=tensors_count,mismatched_elements=mismatch,
    absent_tensor_comparisons=absent,observed_slot_indices=sorted({r['slot'] for r in rows}),
    registered_to_slot_exact_content_qualified=True,checkpoint_to_registered_qualified=False,
    per_token_execution_mapping_qualified=False,semantic_full_pool_qualification=False,
    performance_sample=False,common_slo_qualified=False,formal_g1_g2_qualified=False,n_correct=None,
    scope='Local isolated native CPU-registry to GPU-slot before/after correctness only; not main performance.',
    plan_sha256=check_plan(),metric_protocol_sha256=inputs['metric_protocol_sha256'],protected=protected,sources=refs)
with (OUT/'20261002_d166_slot_content.json').open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
with (OUT/'20261002_d166_slot_content.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader(); writer.writerows(rows)
print(json.dumps({k:v for k,v in result.items() if k not in ('sources','protected')},indent=2))
