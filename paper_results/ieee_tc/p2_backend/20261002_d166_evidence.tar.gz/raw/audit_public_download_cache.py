"""Reuse D152 public-download audit and exact allowlist application unchanged."""
import argparse
import hashlib
import importlib.util
from pathlib import Path

prior_path = Path(__file__).parent.parent/'d152_20261002/audit_public_download_cache.py'
assert hashlib.sha256(prior_path.read_bytes()).hexdigest() == 'c2504b11b21129bc762300d03380c55c757ae93050019d814c4d37e025c95da4'
spec = importlib.util.spec_from_file_location('d152_cache_audit', prior_path)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
audit.OUT = Path(__file__).parent.resolve()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('audit', 'apply'))
    parser.add_argument('--reviewed-audit-sha256')
    args = parser.parse_args()
    if args.action == 'audit':
        audit.audit()
    else:
        audit.apply(args.reviewed_audit_sha256)
