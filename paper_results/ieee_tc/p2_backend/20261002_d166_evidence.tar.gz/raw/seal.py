"""D165 evidence-seal pattern, preserving both failed and completed D166 attempts."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
BASE='17468f24b517eb255eb1df67b9999dcda3608834'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''): h.update(b)
    return h.hexdigest()
def save(p,d):
    with p.open('x') as f: json.dump(d,f,indent=2,allow_nan=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
tests=[]
for phase,count in [('targeted1',17),('regression1',815)]:
    log=(RAW/f'{phase}.log').read_text()
    match=re.search(r'Ran (\d+) tests in ([\d.]+)s',log)
    assert match and int(match[1])==count and '\nOK\n' in log
    elapsed=(RAW/f'{phase}_time.txt').read_text()
    assert 'Exit status: 0' in elapsed
    identity=re.search(r'^InvocationID=([a-f0-9]{32})$',(RAW/f'{phase}_scope.txt').read_text(),re.M)[1]
    assert f'actual_invocation={identity}' in (RAW/f'{phase}_cleanup.txt').read_text()
    events=dict(line.split() for line in (RAW/f'{phase}_final_memory_events.txt').read_text().splitlines())
    assert all(int(v)==0 for v in events.values()) and int((RAW/f'{phase}_final_swap.txt').read_text())==0
    tests.append(dict(phase=phase,count=count,seconds=float(match[2]),invocation_id=identity,
        maximum_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',elapsed)[1])))
sources=['faaslora/memory/gpu_monitor.py','scripts/run_all_experiments.py','scripts/ieee_tc_preflight.py',
         'tests/test_ieee_tc_worker_observation.py','tests/test_ieee_tc_preflight.py']
for n in sources:
    ast.parse((ROOT/n).read_text())
    assert f'{sha(ROOT/n)}  {n}' in (RAW/'regression1_sources.sha256').read_text()
for n in sources[1:3]+['faaslora/preloading/planning_cpu.py','faaslora/preloading/preloading_planner.py',
                       'faaslora/memory/residency_manager.py','faaslora/experiment/instance_pool.py']:
    assert (ROOT/n).read_bytes()==subprocess.check_output(['git','show',f'{BASE}:{n}'],cwd=ROOT)
def functions(tree,prefix=()):
    out={}
    for n in tree.body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)): out[prefix+(n.name,)]=ast.dump(n)
        elif isinstance(n,ast.ClassDef): out.update(functions(n,prefix+(n.name,)))
    return out
name=sources[0]
old=functions(ast.parse(subprocess.check_output(['git','show',f'{BASE}:{name}'],cwd=ROOT)))
new=functions(ast.parse((ROOT/name).read_text()))
allowed={('_ieee_slot_readback',),('_ieee_lora_slot_content_audit',)}
assert old.keys()==new.keys()
assert all(old[k]==new[k] for k in old if k not in allowed)
curated=OUT/'20261002_d166_slot_content.json'
data=json.loads(curated.read_text())
assert data['passed'] and data['registered_to_slot_exact_content_qualified']
assert not data['formal_g1_g2_qualified'] and not data['semantic_full_pool_qualification']
for path,expected in data['sources'].items(): assert sha(Path(path))==expected,path
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
assert sha(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
for phase in ['prepare1','prepare2','targeted1','regression1','curate1']:
    unit=f'primelora-d166-{phase}-20261002.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
    assert not subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','--value'],text=True).strip()
    assert 'cleanup=automatic_removal_verified' in (RAW/f'{phase}_cleanup.txt').read_text()
doc=ROOT/'docs/ieee_tc/D166_NATIVE_SLOT_CONTENT_RUN.md'
cfg=ROOT/'configs/ieee_tc/20261002_d166_7b_slot_content.yaml'
csv_path=OUT/'20261002_d166_slot_content.csv'
subprocess.run(['git','diff','--check','--',sources[0],sources[3],str(doc)],cwd=ROOT,check=True)
verification=OUT/'20261002_d166_verification.json'
save(verification,dict(passed=True,base_commit=BASE,tests=tests,protected=protected,
    unchanged_functions=len(old)-len(allowed),changed_functions=sorted('/'.join(k) for k in allowed),
    document_sha256=sha(doc),curated_sha256=sha(curated),csv_sha256=sha(csv_path),config_sha256=sha(cfg)))
members=sorted(p for p in RAW.iterdir() if p.is_file() and not p.name.startswith('seal1')
    and p.stat().st_size<2*1024**2 and p.suffix in {'.py','.sh','.log','.txt','.json','.sha256'})
extras=[ROOT/sources[0],ROOT/sources[3],doc,cfg,curated,csv_path,verification]
bundle=OUT/'20261002_d166_evidence.tar.gz'
hashes={}
with tarfile.open(bundle,'x:gz') as tar:
    for p in members+extras:
        name='raw/'+p.name if p in members else str(p.relative_to(ROOT))
        hashes[name]=sha(p)
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name,expected in hashes.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==expected
save(OUT/'20261002_d166_evidence_members.json',dict(passed=True,member_sha256=hashes))
with (OUT/'20261002_d166_evidence.sha256').open('x') as f: f.write(sha(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,tests=tests,protected=protected,curated_sha256=sha(curated),
    bundle_sha256=sha(bundle),bundle_bytes=bundle.stat().st_size,members=len(hashes)),indent=2))
