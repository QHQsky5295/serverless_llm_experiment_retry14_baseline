"""Reuse D156 frozen-input/protected-evidence checks for the D165 diagnostic."""
import hashlib
import json
from pathlib import Path
import subprocess
import yaml
from faaslora.datasets.workload_generator import FrozenReplayPlan
from scripts.ieee_tc_preflight import ROOT, check_plan, verify_seal

RAW = Path(__file__).parent.resolve()
CFG = ROOT/'configs/ieee_tc/20261002_d166_7b_slot_content.yaml'
TRACE = Path('/home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260424_131528_llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1/shared_artifacts/llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json')
BASE = '17468f24b517eb255eb1df67b9999dcda3608834'
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024**2), b''):
            h.update(b)
    return h.hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == BASE
sources = ['faaslora/memory/gpu_monitor.py','scripts/run_all_experiments.py','scripts/ieee_tc_preflight.py']
for name in sources:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git','show',f'{BASE}:{name}'],cwd=ROOT)
parent = ROOT/'configs/ieee_tc/20261002_d156_7b_cap4.yaml'
assert sha(parent) == '4aba5abd28e11cb8518b2d4fc5938276b5b67e52f4f077f871d9d730fbfbe733'
expected_config = yaml.safe_load(parent.read_text())
spec_path = ROOT/'paper_results/ieee_tc/p2_backend/20261002_d156_7b_cap4_bootstrap_spec.json'
assert sha(spec_path) == '10d85d3354222b7c7e222b80099d6e62b156a56454fb5c9ad3d1bbbb41420959'
overrides = json.loads(spec_path.read_text())['model_overrides']
expected_config['model_profiles']['llama2_7b_main_v2_publicmix']['model'].update(overrides)
assert yaml.safe_load(CFG.read_text()) == expected_config
full = yaml.safe_load((ROOT/'results/ieee_tc/p2_backend_qualification/d164_20261002/7b_main_config_full1.yaml').read_text())
assert all(full['model'][k] == v for k,v in overrides.items())
assert sha(TRACE) == 'efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
index_path = ROOT/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
assert sha(index_path) == 'e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c'
index = {a['id']:{f['path']:f['sha256'] for f in a['files']} for a in json.loads(index_path.read_text())['artifacts']}
plan = FrozenReplayPlan.load(TRACE,count=22)
source = yaml.safe_load(CFG.read_text())['model_profiles']['llama2_7b_main_v2_publicmix']
pool = (ROOT/source['storage']['remote_dir']).resolve(strict=True)
rows, identities = [], {}
for entry in plan.entries:
    row = json.loads(entry.source_json)
    aid = row['adapter_id']
    if aid not in identities:
        path = (pool/aid).resolve(strict=True)
        assert path.is_relative_to(pool)
        cfg = json.loads((path/'adapter_config.json').read_text())
        weights = sha(path/'adapter_model.safetensors')
        config = sha(path/'adapter_config.json')
        assert weights == index[aid]['adapter_model.safetensors']
        assert config == index[aid]['adapter_config.json']
        identities[aid] = dict(weights_sha256=weights,config_sha256=config,rank=cfg['r'])
    rows.append(dict(request_id=entry.request_id,adapter_id=aid,source_row_sha256=entry.source_sha256,
                     target_tokens=min(row['expected_output_tokens'],256)))
assert rows[-1]['request_id'] == 'req_00021' and rows[-1]['adapter_id'] == 'medical_lora'
assert all(r['adapter_id'] != 'medical_lora' for r in rows[:-1])
assert {i['rank'] for i in identities.values()} == {8,16}
assert len({i['weights_sha256'] for i in identities.values()}) == 4
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
metric_sha = sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')
assert metric_sha == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
result = dict(kind='d166_slot_content_input_qualification_v1',pass_=True,base_commit=BASE,
    plan_sha256=check_plan(),metric_protocol_sha256=metric_sha,protected=protected,
    source_sha256={n:sha(ROOT/n) for n in sources},config_sha256=sha(CFG),trace_sha256=sha(TRACE),
    content_index_sha256=sha(index_path),prefix_count=22,rows=rows,adapters=identities,
    selection='Shortest original prefix including finance and first medical, also both zero-weight ranks; no output selection.',
    artifact_mode='existing_local_frozen_qualification_only',performance_sample=False,
    semantic_full_pool_qualification=False,formal_g1_g2_qualified=False)
with (RAW/'input_qualification2.json').open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(pass_=True,prefix_count=22,adapters=len(identities),distinct_weight_sha=4,
    protected=protected,manifest_sha256=sha(RAW/'input_qualification2.json'))))
