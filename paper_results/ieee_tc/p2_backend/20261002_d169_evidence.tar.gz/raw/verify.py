"""D168 scoped evidence verification/bundle pattern, reused for the native probe."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT,digest,check_plan,verify_seal

RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
BASE='547142f901853cb94233a0a6755eacca18a74afd'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
source=ROOT/'scripts/ieee_tc_preflight.py'
old=ast.parse(subprocess.check_output(['git','show',BASE+':scripts/ieee_tc_preflight.py'],cwd=ROOT,text=True))
new=ast.parse(source.read_text())
allowed={'initialize_qualification_runtime','backend_model_check','main'}
added={'validate_warm_reference_index','warm_reference_batches','validate_warm_native_sample','qualify_warm_reference'}
def filtered(tree):
    return ast.Module(body=[n for n in tree.body if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))
                           or n.name not in allowed|added],type_ignores=[])
assert ast.dump(filtered(old))==ast.dump(filtered(new))
for name in ('scripts/run_all_experiments.py','faaslora/memory/gpu_monitor.py',
             'faaslora/memory/residency_manager.py','faaslora/preloading/planning_cpu.py',
             'faaslora/preloading/preloading_planner.py','faaslora/experiment/instance_pool.py'):
    assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
curated=OUT/'20261002_d169_warm_probe.json'
data=json.loads(curated.read_text())
assert data['passed'] and data['native_completed']==32 and len(data['batches'])==4
assert not data['measured_warm_reference'] and data['warm_thresholds'] is None
assert not data['formal_g1_g2_qualified'] and data['n_correct'] is None
for path,sha in data['sources'].items(): assert digest(Path(path))==sha,path
first=(RAW/'tests1.log').read_text()
assert 'Ran 85 tests' in first and 'FAILED (errors=1)' in first
assert "AttributeError: module 'asyncio' has no attribute 'timeout'" in first
# Some passing CLI-negative tests print argparse usage before their separate
# "ok" line. Count the 72 unique test headers and the single named warm error;
# the complete unittest summary fixes the remaining tests as passing.
headers=re.findall(r'^test.*\(tests\.test_ieee_tc_preflight\..+\) \.\.\. ',first,re.M)
assert len(headers)==len(set(headers))==72
errors=re.findall(r'^ERROR: (.+)$',first,re.M)
assert len(errors)==1 and 'tests.test_ieee_tc_warm_reference.' in errors[0]
assert re.search(r'\nRan 13 tests in [0-9.]+s\n\nOK\n',(RAW/'warmtests2.log').read_text())
cleanup=[]
for phase,code in (('tests1',1),('warmtests2',0),('prepare1',0),('curate1',0),('verify1',1)):
    receipt=(RAW/f'{phase}_scope.txt').read_text()
    actual=re.search(r'^InvocationID=([a-f0-9]{32})$',receipt,re.M)[1]
    unit=f'primelora-d169-{phase}-20261002.scope'
    state=subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState',
                                  '-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines()==['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert all(int(line.split()[1])==0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text())==0
    assert f'Exit status: {code}' in (RAW/f'{phase}_time.txt').read_text()
    cleanup.append(dict(phase=phase,actual_invocation_id=actual,returncode=code,
                        cleanup='automatic_removal_verified'))
with (RAW/'cleanup_verified.json').open('x') as f: json.dump(cleanup,f,indent=2)
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
doc=ROOT/'docs/ieee_tc/D169_COMMON_WARM_RUNTIME.md'
table=OUT/'20261002_d169_warm_probe.csv'
with table.open() as f: rows=list(csv.DictReader(f))
assert len(rows)==4 and all(int(r['native_completed'])==8 for r in rows)
verification=OUT/'20261002_d169_verification.json'
with verification.open('x') as f:
    json.dump(dict(passed=True,base_commit=BASE,allowed_preflight_wiring=sorted(allowed),
        new_preflight_helpers=sorted(added),other_preflight_ast_unchanged=True,serving_source_unchanged=True,
        protected=protected,cleanup=cleanup,curated_sha256=digest(curated),table_sha256=digest(table),
        document_sha256=digest(doc)),f,indent=2)
members=sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size<2*1024**2
               and not p.name.startswith('verify2') and p.suffix!='.lock')
extras=[source,ROOT/'tests/test_ieee_tc_warm_reference.py',
        ROOT/'configs/ieee_tc/20261002_d169_7b_warm_reference.yaml',doc,curated,table,verification]
hashes={}
bundle=OUT/'20261002_d169_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for p in members+extras:
        name='raw/'+str(p.relative_to(RAW)) if p in members else str(p.relative_to(ROOT))
        hashes[name]=digest(p)
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha
with (OUT/'20261002_d169_evidence_members.json').open('x') as f:
    json.dump(dict(passed=True,member_sha256=hashes,
                  large_raw_results_retained_locally_and_bound_in_curated_sources=True),f,indent=2)
with (OUT/'20261002_d169_evidence.sha256').open('x') as f: f.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,cleanup=cleanup,curated_sha256=digest(curated),
    bundle_sha256=digest(bundle),members=len(hashes),bundle_bytes=bundle.stat().st_size),indent=2))
