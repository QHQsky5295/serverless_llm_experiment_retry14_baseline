#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d169_20261002
test -e "$raw/7b_probe1_launch.json"
test -e "$raw/7b_probe1.json"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test ! -e /proc/622054
for unit in primelora-tc-svc-b027ea1e83d5417d81acde55031c4c3c.scope primelora-tc-aux-e693a130b54c4c7c824d4fe6d4b54b24.scope; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test -z "$(systemctl --user show "$unit" -p ControlGroup --value)"
done
{ date --iso-8601=seconds; echo cleanup=automatic_removal_verified; } > "$raw/probe1_cleanup.txt"
