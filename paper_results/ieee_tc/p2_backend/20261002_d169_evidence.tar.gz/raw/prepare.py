"""Bind the new warm probe to existing sealed inputs and actual pool ranks."""
import ast
import json
from pathlib import Path
import subprocess
import yaml
from faaslora.datasets.workload_generator import FrozenReplayPlan
from scripts.ieee_tc_preflight import (ROOT, digest, check_plan, verify_seal,
    validate_warm_reference_index, warm_reference_batches)

RAW=Path(__file__).parent.resolve()
index_path=ROOT/'paper_results/ieee_tc/p2_backend/20261002_d168_warm_input_index.json'
assert digest(index_path)=='563abfbdeb74c1bc03e42a26c34d48d634c342ac4fa43bd00c5ff8dd82269793'
index=json.loads(index_path.read_text())
plan=FrozenReplayPlan.load(Path(index['source']['source_path']))
validate_warm_reference_index(index,plan)
cfg_path=ROOT/'configs/ieee_tc/20261002_d169_7b_warm_reference.yaml'
cfg=yaml.safe_load(cfg_path.read_text())['model_profiles']['llama2_7b_main_v2_publicmix']['model']
parent_path=ROOT/'configs/ieee_tc/20261002_d166_7b_slot_content.yaml'
parent=yaml.safe_load(parent_path.read_text())['model_profiles']['llama2_7b_main_v2_publicmix']['model']
differences={k:dict(old=parent[k],new=cfg[k]) for k in cfg if cfg[k]!=parent[k]}
assert differences=={'gpu_memory_utilization':dict(old=.70,new=.92),
    'max_loras':dict(old=4,new=8),'max_lora_rank':dict(old=64,new=16),
    'max_num_seqs':dict(old=4,new=8),'runtime_concurrency_cap':dict(old=4,new=8)}
audit_path=ROOT/'paper_results/ieee_tc/p2_backend/20260926_artifact_tensor_audit.json'
audit=json.loads(audit_path.read_text())
groups=[g for g in audit['weight_groups'] if g['pool']=='llama2_7b_a500_v2_publicmix']
assert sum(g['logical_adapters'] for g in groups)==500
assert max(rank for g in groups for rank in g['configured_ranks'])==cfg['max_lora_rank']==16
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
protocol=ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
assert digest(protocol)=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
base='547142f901853cb94233a0a6755eacca18a74afd'
for name in ('scripts/run_all_experiments.py','faaslora/memory/gpu_monitor.py',
             'faaslora/memory/residency_manager.py','faaslora/experiment/instance_pool.py'):
    assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show',base+':'+name],cwd=ROOT)
for name in ('scripts/ieee_tc_preflight.py','tests/test_ieee_tc_warm_reference.py'):
    ast.parse((ROOT/name).read_text())
probe=[dict(group=b['group_id'],batch=b['batch_index'],
    source_indices=[r['source_index'] for r in b['selected']],
    adapters=len({r['adapter_id'] for r in b['selected']}),
    declared_context_tokens=sum(r['native_prompt_tokens']+r['target_tokens'] for r in b['selected']))
    for b in warm_reference_batches(index,'probe')]
refs=[index_path,Path(index['source']['source_path']),cfg_path,parent_path,audit_path,protocol,
      ROOT/'scripts/ieee_tc_preflight.py',ROOT/'tests/test_ieee_tc_warm_reference.py',
      ROOT/'scripts/run_all_experiments.py',ROOT/'faaslora/memory/gpu_monitor.py']
result=dict(passed=True,base_commit=base,plan_sha256=check_plan(),protected=protected,
    sources={str(p):digest(p) for p in refs},configuration_differences=differences,
    probe=probe,probe_requests=sum(len(p['source_indices']) for p in probe),
    actual_gpu_probe_complete=False,common_reference_frozen=False)
with (RAW/'inputs1.json').open('x') as f: json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
