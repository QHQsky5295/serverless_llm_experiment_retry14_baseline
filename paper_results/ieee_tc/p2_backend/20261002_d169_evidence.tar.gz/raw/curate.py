"""Reuse bounded native qualification curation; probe is not a warm threshold."""
import csv
import json
from pathlib import Path
import subprocess
from scripts.ieee_tc_preflight import (ROOT,digest,verify_seal,check_plan,
                                      validate_warm_native_sample)

RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
def load(path):
    assert path.stat().st_size < 128*1024**2
    return json.loads(path.read_text())
inputs=load(RAW/'inputs1.json')
data=load(RAW/'7b_probe1.json')
launch=load(RAW/'7b_probe1_launch.json')
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert 'cleanup=automatic_removal_verified' in (RAW/'probe1_cleanup.txt').read_text()
assert data['config_sha256']==inputs['sources'][str(ROOT/'configs/ieee_tc/20261002_d169_7b_warm_reference.yaml')]
assert data['check_source_sha256']==inputs['sources'][str(ROOT/'scripts/ieee_tc_preflight.py')]
assert data['warm_reference_index_sha256']=='563abfbdeb74c1bc03e42a26c34d48d634c342ac4fa43bd00c5ff8dd82269793'
physical=data.get('physical_allocation')
gpu_s=None
if physical:
    starts=[e['at'] for e in physical['events'] if e['event']=='acquire']
    ends=[e['at'] for e in physical['events'] if e['event']=='release']
    assert physical['released'] and len(starts)==len(ends)==len(physical['gpu_uuids'])==1
    gpu_s=ends[0]-starts[0]
watch=RAW/'7b_probe1_launch.launch/watchdog.jsonl'
with watch.open() as f: events=[json.loads(line) for line in f]
samples=[e for e in events if e['event']=='resource_sample']
assert samples
resource=dict(samples=len(samples),peak_memory_bytes=max(e['service']['memory.peak'] for e in samples),
    min_host_available_bytes=min(e['host']['available_bytes'] for e in samples),
    memory_events={k:max(e['service']['memory.events'][k] for e in samples)
                   for k in samples[0]['service']['memory.events']},
    max_swap_bytes=max(e['service']['memory.swap.current'] for e in samples),
    warnings=sum(e['decision']['warning'] for e in samples),
    aborts=[e['decision']['abort_reasons'] for e in samples if e['decision']['abort_reasons']])
rows=[]
for batch in data.get('warm_batches',[]):
    cases=[data['requests'][i] for i in batch['request_indices']]
    complete=[c for c in cases if c['pass_native']]
    for c in complete:
        measured=validate_warm_native_sample(c,c['timing'],c['actual_tokens'],c['reference']['adapter_int_id'])
        assert measured=={k:c[k] for k in measured}
        assert c['actual_tokens']==c['timing']['native_output_tokens']
    before=batch.get('scheduler_before',{})
    after=batch.get('scheduler_after',{})
    rows.append(dict(group=batch['group_id'],batch=batch['batch_index'],requests=len(cases),
        native_completed=len(complete),unique_adapters=len({c['adapter_id'] for c in cases}),
        actual_gpu_slots=len([a for a in batch.get('sources_before',{}).get('slot_adapter_ids',[]) if a is not None]),
        kv_tokens_per_block=before.get('kv_tokens_per_block'),
        kv_full_context_required=batch.get('full_declared_kv_blocks'),
        kv_free_before=before.get('kv_unreserved_free_blocks'),
        kv_free_after=after.get('kv_unreserved_free_blocks'),
        all_decode_intersection_s=batch.get('all_decode_intersection_s'),
        mean_native_ttft_ms=sum(c['ttft_ms'] for c in complete)/len(complete) if complete else None,
        mean_native_tpot_ms=sum(c['tpot_ms'] for c in complete)/len(complete) if complete else None,
        passed=batch['pass_native']))
if data['pass']:
    assert launch['pass'] and data['stage']=='complete' and data['shutdown_called']
    assert len(data['requests'])==inputs['probe_requests']==32
    assert len(rows)==len(inputs['probe'])==4
    assert all(r['passed'] and r['native_completed']==8 for r in rows)
    assert all(c['release']['released'] for c in data['requests'])
    assert all(not b['scheduler_after']['admitted'] and not b['scheduler_after']['unretired_iterations']
               and not b['scheduler_after']['native_deferred_free_batches'] for b in data['warm_batches'])
    assert not data['sources_after_eviction']['sources']
    assert all(a is None for a in data['sources_after_eviction']['slot_adapter_ids'])
    assert not data['measured_warm_reference'] and not data['common_reference_frozen']
    assert not data['formal_g1_g2_qualified'] and not data['semantic_full_pool_qualification']
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
refs=dict(inputs['sources'])
for name in ('inputs1.json','7b_probe1.json','7b_probe1_launch.json','probe1_cleanup.txt',
             'prepare.py','curate.py','run_cpu.sh','run_7b_probe1.sh'):
    refs[str(RAW/name)]=digest(RAW/name)
refs[str(watch)]=digest(watch)
result=dict(kind='d169_common_warm_runtime_probe_v1',passed=data['pass'],stage=data['stage'],
    error=data.get('error'),requested_probe_requests=32,native_completed=sum(c['pass_native'] for c in data.get('requests',[])),
    batch_size=8,batches=rows,physical_gpu_s=gpu_s,physical_released=bool(physical and physical['released']),
    service_returncode=launch['service_returncode'],watchdog_returncode=launch['watchdog_returncode'],
    actual_service_invocation=launch['service_identity']['invocation_id'],resource=resource,
    actual_7b_probe_complete=data['pass'],common_reference_frozen=False,
    measured_warm_reference=False,warm_thresholds=None,n_correct=None,formal_g1_g2_qualified=False,
    semantic_full_pool_qualification=False,scope='capacity probe only; not 1536-sample warm calibration',
    plan_sha256=check_plan(),sources=refs,protected=protected)
with (OUT/'20261002_d169_warm_probe.json').open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
with (OUT/'20261002_d169_warm_probe.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['status'],lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
print(json.dumps({k:v for k,v in result.items() if k not in ('sources','protected')},indent=2))
