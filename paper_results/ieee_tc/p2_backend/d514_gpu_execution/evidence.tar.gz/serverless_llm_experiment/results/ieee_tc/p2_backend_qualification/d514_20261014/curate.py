"""D474 curation contract reused for the distinct D514 GPU execution consumer."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d514_gpu_execution'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def load(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
scope=p.scope_identity(p.cg_path().name)
save(RAW/'curation_identity.json',scope)
assert os.environ['CUDA_VISIBLE_DEVICES']=='' and os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert shutil.disk_usage(ROOT).free>=150*1024**3
parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert parent=='d15a659e54045da322fe16da3e0d41b8c18bad61'
before=ast.parse(subprocess.check_output(['git','show','HEAD:scripts/run_all_experiments.py'],cwd=ROOT,text=True))
method=next(n for n in ast.walk(before) if isinstance(n,ast.AsyncFunctionDef) and n.name=='_run_ieee_gpu_preparation_plan')
execute=next(n for n in method.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='execute')
observed=next(n for n in execute.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='current' for t in n.targets))
keyword=next(n for n in ast.walk(observed) if isinstance(n,ast.keyword) and n.arg=='operation')
assert keyword.value.value=='source_snapshot'
keyword.value.value='source_identity_snapshot'
assert ast.dump(before,include_attributes=False)==ast.dump(ast.parse((ROOT/'scripts/run_all_experiments.py').read_text()),include_attributes=False)
assert not subprocess.check_output(['git','diff','HEAD','--','faaslora','configs/ieee_tc'],cwd=ROOT,text=True)
results={n:load(RAW/(n+'_result.json')) for n in ('red','unit','unit2','native_unit','regression','regression2')}
assert (results['red']['tests'],results['red']['failures'],results['red']['errors'])==(4,3,1)
assert not results['unit']['passed'] and not results['unit2']['passed']
assert results['native_unit']['passed'] and results['native_unit']['tests']==4
assert not results['regression']['passed'] and results['regression']['failures']==3
assert results['regression2']['passed'] and results['regression2']['tests']==957
assert results['regression2']['skipped']==0
for path,sha in results['regression2']['sources'].items():assert p.digest(Path(path))==sha,path
assert p.digest(RAW/'red_candidate_test.py')==results['red']['sources'][str(ROOT/'tests/test_ieee_tc_host_execution_projection.py')]
closures={n:load(RAW/(n+'_closure.json')) for n in ('audit','red','targeted','unit','unit2','native_unit','regression','regression2')}
for row in closures.values():
    assert row['passed'] and row['actual_recursive_procs_empty'] and not Path(row['identity']['path']).exists()
    assert row['resources']['memory.swap.current']=='0'
    events={line.split()[0]:int(line.split()[1]) for line in row['resources']['memory.events'].splitlines()}
    assert events['oom']==events['oom_kill']==events['max']==0
    if row is not closures['targeted']: assert all(v==0 for v in events.values())
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
identities={
    p.PLAN:'d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'}
identities.update({
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'})
for path,sha in identities.items():assert p.digest(path)==sha,path
assert p.digest(RAW/'unit_candidate_test.py')==results['unit']['sources'][str(ROOT/'tests/test_ieee_tc_host_execution_projection.py')]
assert p.digest(RAW/'unit2_candidate_test.py')==results['unit2']['sources'][str(ROOT/'tests/test_ieee_tc_host_execution_projection.py')]
OUT.mkdir(parents=True,exist_ok=False)
rawfiles=sorted(pth for pth in RAW.iterdir() if pth.suffix in ('.py','.json','.log'))
sources=[ROOT/path for path in ('scripts/run_all_experiments.py',
    'tests/test_ieee_tc_gpu_references.py','tests/test_ieee_tc_host_execution_projection.py',
    'tests/test_ieee_tc_transfer_pressure.py')]
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for path in rawfiles+sources:
        name=str(path).removeprefix('/home/qhq/')
        data=path.read_bytes()
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest())
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']==p.digest(Path(ref['path']))
refs={str(path):p.digest(path) for path in rawfiles+sources}
for path in (ROOT/'paper_results/ieee_tc/p2_backend/d512_native_core/operation_detail1/summary.json',
             ROOT/'paper_results/ieee_tc/p2_backend/d512_native_core/analysis1/resource_remote.json'):
    refs[str(path)]=p.digest(path)
save(OUT/'qualification.json',dict(kind='d514_gpu_execution_projection_cpu_v1',passed=True,
    parent=parent,exact_ast_single_constant_change=True,
    production_change='queued GPU preparation execute fresh source_snapshot -> fresh source_identity_snapshot only',
    results=results,closures=closures,protected=protected,source_refs=refs,
    preserved_identities={str(x):sha for x,sha in identities.items()},
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz'),
    performance_hypothesis_accepted=False,native_validation_pending=True,full4000_pending=True,
    failed_test_attempts='red:3dependencyfail+wrongfactoryerror; targeted interrupted spawn reentry/high; unit: stale concurrency count and missing fixture setup; unit2: wrong fixture planning mode; regression:3 old capture-filter failures, changed only accepted observation endpoint; all retained, no production change beyond single constant',
    scope=scope,free_bytes=shutil.disk_usage(ROOT).free))
print(json.dumps(dict(passed=True,tests=957,source_refs=len(refs),members=len(members),protected=147)))
