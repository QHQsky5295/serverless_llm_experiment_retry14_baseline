"""D473 exact-identity closure, reused for D514 auxiliary tasks."""
import json
import subprocess
import sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
name=sys.argv[1]
assert name in ('unit2','native_unit','targeted2','regression2','curation','backup')
expected=json.loads((RAW/(name+'_identity.json')).read_text())
assert p.scope_still_owned(expected)
group=Path(expected['path'])
members={str(x):x.read_text().split() for x in group.rglob('cgroup.procs')}
assert members and all(not values for values in members.values())
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(expected)
subprocess.run(['systemctl','--user','stop',expected['unit']],check=True)
assert not group.exists()
result=dict(passed=True,identity=expected,resources=resources,actual_recursive_procs_empty=True,
            source_sha256=p.digest(Path(__file__)))
with (RAW/(name+'_closure.json')).open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
