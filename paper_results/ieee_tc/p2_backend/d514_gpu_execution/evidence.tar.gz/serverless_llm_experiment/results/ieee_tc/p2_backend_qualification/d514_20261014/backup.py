"""D514 task-only checkpoint procedure reused; D514 evidence explicitly scoped."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d514_gpu_execution'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def load(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
scope=p.scope_identity(p.cg_path().name);save(RAW/'backup_identity.json',scope)
q=load(OUT/'qualification.json')
assert q['passed'] and q['exact_ast_single_constant_change']
for path,sha in q['source_refs'].items():assert p.digest(Path(path))==sha,path
for path,sha in q['results']['regression2']['sources'].items():assert p.digest(Path(path))==sha,path
for path,sha in q['preserved_identities'].items():assert p.digest(Path(path))==sha,path
assert p.digest(OUT/'evidence.tar.gz')==q['archive_sha256']
closure=load(RAW/'curation_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty']
assert not Path(closure['identity']['path']).exists()
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==q['parent']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/qhq/serverless_llm_baselines',text=True).strip()=='09baa9379bdc3518f18f408d2cad3763c2754554'
save(OUT/'final_verification.json',dict(passed=True,qualified_cpu_tests=957,
    source_refs_checked=len(q['source_refs']),protected=protected,curation_closure=closure,
    native_validation_pending=True,performance_hypothesis_accepted=False,scope=scope,
    helper_sha256=p.digest(Path(__file__)),free_bytes=shutil.disk_usage(ROOT).free))
paths=['scripts/run_all_experiments.py','tests/test_ieee_tc_transfer_pressure.py',
    'tests/test_ieee_tc_gpu_references.py','tests/test_ieee_tc_host_execution_projection.py','docs/ieee_tc/D514_GPU_EXECUTION_CONSUMER_PROOF.md',
    'docs/ieee_tc/EXECUTION_STATUS.md']+[str(x.relative_to(ROOT)) for x in sorted(OUT.iterdir())]
assert len(paths)==9
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def secret_check(data):
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
    assert not token or token not in data
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    for member in tar:
        data=tar.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest()==q['archive_members'][member.name]['sha256']
        secret_check(data)
for name in paths:secret_check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(paths) and all('lora_manifest_1000.json' not in name for name in staged)
checks={}
for name in paths:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert len(data)<2*1024*1024
    checks[name]=hashlib.sha256(data).hexdigest()
    assert checks[name]==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
save(RAW/'staged_check.json',dict(passed=True,files=checks))
subprocess.run(['git','commit','-m','tc: qualify fresh GPU preparation identity without unused physical collection (D514)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
receipt=dict(passed=True,head=head,remote=remote,scope=scope,files=len(paths),free_bytes=shutil.disk_usage(ROOT).free)
save(RAW/'backup_receipt.json',receipt);print(json.dumps(receipt))
