"""D514 uses D474's bounded unittest/provenance entry; no new replay framework."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
phase=sys.argv[1]
assert phase in ('audit','red','targeted','regression')
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
scope=p.scope_identity(p.cg_path().name)
save(phase+'_identity.json',scope)
group=Path(scope['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert p.preflight([ROOT],p.GIB)['preflight_pass']
assert os.environ['CUDA_VISIBLE_DEVICES']==''
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
if phase == 'audit':
    import collections
    import ijson
    prior=ROOT/'results/ieee_tc/p2_backend_qualification/d512_20261014'
    source=prior/'7b_full_w0_prefix1/launch.launch/physical_deployment/main_outcome.json'
    refs=json.loads((ROOT/'paper_results/ieee_tc/p2_backend/d512_native_core/analysis1/resource_remote.json').read_text())['source_refs']
    expected=next(r['sha256'] for r in refs if Path(r['path']).resolve()==source.resolve())
    assert p.digest(source)==expected
    counts=collections.Counter()
    states=collections.Counter()
    with source.open('rb') as f:
        for row in ijson.items(f,'mechanism_events._ieee_gpu_preparation_plans.item',use_float=True):
            counts['plans']+=1
            states['plan:'+row['state']]+=1
            for attempt in row['attempts']:
                counts['attempts_started']+=1
                states['attempt:'+attempt['state']]+=1
                if attempt.get('receipt') is not None:
                    counts['native_prepare_receipts']+=1
                    counts['acquired']+=attempt['receipt'].get('acquired') is True
    assert counts['plans']>0 and counts['native_prepare_receipts']>0
    assert p.digest(source)==expected
    save('audit_result.json',dict(passed=True,counts=dict(counts),states=dict(states),
        source=str(source),sha256=expected,scope=scope,protected=protected,
        caveat='Each retained prepare receipt follows the inspected full observation boundary; no duration or GPU-time saving is inferred.'))
    print(json.dumps(dict(counts=counts,states=states)))
    raise SystemExit(0)
tests=['tests.test_ieee_tc_host_execution_projection.GPUExecutionProjection']
if phase!='red':
    tests += ['tests.test_ieee_tc_transfer_pressure','tests.test_ieee_tc_gpu_references',
        'tests.test_ieee_tc_identity_recheck','tests.test_ieee_tc_host_observation_freshness']
if phase=='regression':
    tests += ['tests.test_ieee_tc_request_lifecycle','tests.test_ieee_tc_service_events',
              'tests.test_ieee_tc_worker_observation','tests.test_basic_smoke']
sources=[ROOT/x for x in ('scripts/run_all_experiments.py','tests/test_ieee_tc_gpu_references.py',
    'tests/test_ieee_tc_host_execution_projection.py','faaslora/memory/gpu_monitor.py',
    'faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py',
    'faaslora/experiment/instance_pool.py')]+[Path(__file__)]
for source in sources:ast.parse(source.read_text())
before={str(x):p.digest(x) for x in sources}
save(phase+'_sources.json',dict(sources=before,tests=tests,parent=subprocess.check_output(
    ['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),diff=subprocess.check_output(
    ['git','diff','HEAD','--','scripts/run_all_experiments.py','tests/test_ieee_tc_transfer_pressure.py'],cwd=ROOT,text=True)))
start=time.monotonic()
with (RAW/(phase+'_tests.log')).open('x') as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(tests))
assert before=={str(x):p.digest(x) for x in sources}
report=dict(passed=result.wasSuccessful(),tests=result.testsRun,failures=len(result.failures),
    errors=len(result.errors),skipped=len(result.skipped),elapsed_s=time.monotonic()-start,
    sources=before,scope=scope,protected=protected,expected_red=phase=='red')
save(phase+'_result.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ('sources','scope','protected')}))
raise SystemExit(0 if result.wasSuccessful() or phase=='red' else 1)
