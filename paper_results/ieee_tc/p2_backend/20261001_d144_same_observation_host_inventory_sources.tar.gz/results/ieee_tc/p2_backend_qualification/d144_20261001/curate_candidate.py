"""Reuse the D143 seal/test/source/bundle workflow for one serving candidate."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root=Path.cwd()
raw=root/'results/ieee_tc/p2_backend_qualification/d144_20261001'
prior=root/'results/ieee_tc/p2_backend_qualification/d143_20261001'
out=root/'paper_results/ieee_tc/p2_backend'
parent='f70595dc98fb9b2ae013171142bbb87085faa991'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))=='fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
changed={'faaslora/memory/gpu_monitor.py','tests/test_ieee_tc_worker_observation.py','tests/test_ieee_tc_gpu_references.py'}
sources=json.loads((prior/'prelaunch_verification.json').read_text())['source_sha256']
for name,sha in sources.items():
    if name in changed:
        before=subprocess.check_output(['git','show',f'{parent}:{name}'])
        assert hashlib.sha256(before).hexdigest()==sha,name
    else:
        assert digest(root/name)==sha,name
for phase in ('green','regression'):
    subprocess.run(['sha256sum','-c',str(raw/f'{phase}_sources.sha256')],check=True)
red_sources=dict(line.split(maxsplit=1)[::-1] for line in (raw/'red_sources.sha256').read_text().splitlines())
for name,sha in red_sources.items():
    if name=='faaslora/memory/gpu_monitor.py':
        assert hashlib.sha256(subprocess.check_output(['git','show',f'{parent}:{name}'])).hexdigest()==sha
    else:
        assert digest(root/name)==sha
assert 'FAILED (failures=2)' in (raw/'red.log').read_text()
assert '9 != 6' in (raw/'red.log').read_text() and 'Called 2 times' in (raw/'red.log').read_text()
assert 'Ran 2 tests in 0.005s\n\nOK\n' in (raw/'green.log').read_text()
assert 'Ran 628 tests in 77.150s\n\nOK\n' in (raw/'regression.log').read_text()
cleanup={}
for phase in ('red','green','regression','equivalence'):
    unit=f'primelora-d144-{phase}-20261001.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
    events={r.split()[0]:int(r.split()[1]) for r in (raw/f'{phase}_cleanup.txt').read_text().splitlines()
            if r.startswith(('low ','high ','max ','oom ','oom_kill ','oom_group_kill '))}
    assert len(events)==6 and not any(events.values()),phase
    cleanup[phase]=events
    expected=1 if phase=='red' else 0
    assert f'Exit status: {expected}' in (raw/f'{phase}_time.txt').read_text()
equivalence=json.loads((raw/'equivalence.json').read_text())
assert len(equivalence['cases'])==7 and all(r['exact_result_equal'] for r in equivalence['cases'])
assert equivalence['torch_version']=='2.8.0+cu128' and not equivalence['cuda_executed']
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
files=[root/name for name in sorted(changed)]
files.append(root/'docs/ieee_tc/D144_SAME_OBSERVATION_HOST_INVENTORY.md')
files += [raw/name for name in ('run_tests.sh','check_inventory_equivalence.py','run_equivalence.sh','equivalence.json',
    'curate_candidate.py','curate_candidate.sh')]
for phase in ('red','green','regression','equivalence'):
    files += [raw/f'{phase}{suffix}' for suffix in ('.log','_time.txt','_scope.txt','_cleanup.txt')]
for phase in ('red','green','regression'):
    files.append(raw/f'{phase}_sources.sha256')
files.append(root/'paper_results/ieee_tc/p2_backend/20261001_d143_prefix_diagnostic.json')
assert digest(files[-1])=='6182bb7d990a9d31a0c995b533f1607591670787fd63400b2ff5a0684dda5dcd'
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for path in files:
    assert path.stat().st_size < 2*1024**2,path
    payload=path.read_bytes()
    assert secret not in payload,path
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in payload.splitlines()),path
    if path.suffix=='.py': compile(payload,str(path),'exec')
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
native=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')
native_refs=[dict(path=str(path),sha256=digest(path)) for path in
    (native/'lora/model_manager.py',native/'v1/executor/uniproc_executor.py')]
result=dict(kind='d144_same_observation_host_inventory_candidate_v1',parent_commit=parent,
    candidate_decision='cpu_equivalence_and_regression_pass_full_validation_pending',
    regression_tests=628,regression_seconds=77.150,equivalence=equivalence,
    cuda_executed=False,formal_performance_result=False,performance_gain_established=False,
    equations_changed=False,physical_guards_removed=False,cross_observation_memoization=False,
    protected=protected,prelaunch_sources_verified=len(sources),cleanup_events=cleanup,
    native_implementation_source_refs=native_refs,
    source_refs=[dict(path=str(path),sha256=digest(path)) for path in files])
curated=out/'20261001_d144_same_observation_host_inventory.json'
with curated.open('x') as stream: json.dump(result,stream,indent=2,allow_nan=False)
files.append(curated)
bundle=out/'20261001_d144_same_observation_host_inventory_sources.tar.gz'
with bundle.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for path in files: archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers())==len(files)
    for member,path in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==digest(path)
with (out/'20261001_d144_same_observation_host_inventory_sources.sha256').open('x') as stream:
    stream.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,regression_tests=628)))
