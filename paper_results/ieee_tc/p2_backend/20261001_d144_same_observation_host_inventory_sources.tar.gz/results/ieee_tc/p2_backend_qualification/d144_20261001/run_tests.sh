#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in red|green|regression) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d144_20261001
unit="primelora-d144-${phase}-20261001.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sha256sum faaslora/memory/gpu_monitor.py tests/test_ieee_tc_worker_observation.py tests/test_ieee_tc_gpu_references.py > "$raw/${phase}_sources.sha256"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1
if test "$phase" = regression; then
  tests=(tests.test_ieee_tc_worker_observation tests.test_ieee_tc_gpu_references tests.test_ieee_tc_transfer_pressure tests.test_ieee_tc_planning_cpu tests.test_ieee_tc_preparation_snapshot_copy tests.test_basic_smoke)
else
  tests=(tests.test_ieee_tc_worker_observation.NativeHostFootprint.test_pinning_is_observed_once_per_view_not_twice_for_new_storage tests.test_ieee_tc_gpu_references.NativeDemandTransactions.test_actual_extension_calls_native_loader_without_inplace_or_fake_inference)
fi
exec /usr/bin/time -v -o "$raw/${phase}_time.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest "${tests[@]}" -v > "$raw/${phase}.log" 2>&1
