"""Reuse tiny CPU HOST fixtures against the exact backed pre-candidate helper.

This measures query counts and equality, not native CUDA/serving latency.
"""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace
from unittest.mock import patch
import torch
from faaslora.memory import gpu_monitor as monitor
from tests.test_ieee_tc_worker_observation import NativeHostFootprint

raw=Path(__file__).resolve().parent
previous=subprocess.check_output(['git','show','f70595dc98fb9b2ae013171142bbb87085faa991:faaslora/memory/gpu_monitor.py'])
tree=ast.parse(previous)
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_ieee_lora_host_inventory')
namespace=dict(vars(monitor))
exec(compile(ast.Module(body=[function],type_ignores=[]),'backed_f70595_host_inventory','exec'),namespace)
old=namespace['_ieee_lora_host_inventory']
new=monitor._ieee_lora_host_inventory
observe=torch.Tensor.is_pinned
results=[]
for case in ('shared','partial','packed','empty','staged_alias','unsupported_tensor','pinning_disagreement'):
    native,models=NativeHostFootprint().native_models()
    staged=None
    if case=='partial':
        models[8].loras['shared'].lora_a=models[8].loras['shared'].lora_a[:1,:4]
        models[8].loras['shared'].lora_b=models[8].loras['shared'].lora_b[:4,:1]
    elif case=='packed':
        layer=models[8].loras['shared']
        models[8].loras={'qkv':SimpleNamespace(lora_a=[layer.lora_a,None],lora_b=[layer.lora_b,None])}
    elif case=='empty':
        models.clear()
    elif case=='staged_alias':
        staged={8:models.pop(8)}
    elif case=='unsupported_tensor':
        models[8].loras['shared'].bias=torch.empty((4,))
    incompatible=models[7].loras['shared'].lora_b if case=='pinning_disagreement' else None
    values=[]
    counts=[]
    for implementation in (old,new):
        called=[]
        def counted(tensor):
            called.append(id(tensor))
            return tensor is incompatible if incompatible is not None else observe(tensor)
        with patch.object(torch.Tensor,'is_pinned',counted):
            try:
                value=dict(result=implementation(native,staged_models=staged))
            except ValueError as error:
                value=dict(error_type=type(error).__name__,error=str(error))
        values.append(value)
        counts.append(len(called))
    assert values[0]==values[1],case
    assert ('error' in values[0])==(case in ('unsupported_tensor','pinning_disagreement'))
    results.append(dict(case=case,exact_result_equal=True,native_pin_queries_before=counts[0],
        native_pin_queries_after=counts[1],expected_error=values[0].get('error'),
        common_output_sha256=hashlib.sha256(json.dumps(values[0],sort_keys=True,allow_nan=False).encode()).hexdigest()))
result=dict(kind='d144_same_observation_equivalence_v1',cases=results,
    original_file_sha256=hashlib.sha256(previous).hexdigest(),torch_version=torch.__version__,
    fixture='existing_NativeHostFootprint_tiny_CPU_storages',cuda_executed=False,
    serving_performance_measured=False,old_source_commit='f70595dc98fb9b2ae013171142bbb87085faa991')
with (raw/'equivalence.json').open('x') as stream: json.dump(result,stream,indent=2,allow_nan=False)
print(json.dumps(result))
