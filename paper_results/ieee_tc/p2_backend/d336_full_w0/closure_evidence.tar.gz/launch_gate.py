"""Fresh launch gate: tested config-only candidate, unchanged serving logic."""
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

out = Path(__file__).resolve().parent
previous = json.loads((out/'prelaunch_binding.json').read_text())
assert previous['passed'] and previous['changed_policy_fields'] == [
    'queue_upper','active_upper','active_lower']
for ref in previous['source_references']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
git = ['git','-C',str(p.ROOT)]
assert subprocess.check_output(git+['branch','--show-current'],text=True).strip() == 'retry14_continuous_queue_v2'
assert not subprocess.check_output(git+['diff','--name-only','HEAD','--',
    'faaslora','scripts','configs/ieee_tc','tests'],text=True).strip()
# No runtime code changed relative to the completed D335 execution checkpoint.
assert not subprocess.check_output(git+['diff','--name-only',
    'cc6046607cee16d7409e2a542ca8468dfd93cffe','HEAD','--',
    'faaslora','scripts/run_all_experiments.py','scripts/dedicated_engine_worker.py'],text=True).strip()
head = subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip()
remote = subprocess.check_output(git+['ls-remote','faaslora_origin',
    'refs/heads/retry14_continuous_queue_v2'],text=True).split()[0]
assert remote == head
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(p.ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(p.ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
seal = p.verify_seal(p.ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count'] == 147 and seal['changed'] == [str(known)]
assert p.digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not (out/'7b_full_w0').exists()
gate = p.preflight([p.ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
receipt = dict(kind='d336_launch_gate_v1',passed=True,source_head=head,remote_head=remote,
    prelaunch_receipt_sha256=p.digest(out/'prelaunch_binding.json'),
    diagnostic_prefix_count=None,source_requests=4000,observer='none',
    preflight=gate,protection=seal)
with (out/'launch_gate1.json').open('x') as f:
    json.dump(receipt,f,indent=2,allow_nan=False)
print(json.dumps(dict(passed=True,head=head,disk=gate['filesystems'][0]['free_bytes'],
    memory=gate['memory']['MemAvailable'])))
