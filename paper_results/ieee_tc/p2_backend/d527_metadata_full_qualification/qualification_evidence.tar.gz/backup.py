"""Reuse D526 checked explicit-path archive/backup, for D527 qualification."""
import ast, hashlib, io, json, os, pathlib, re, subprocess, sys, tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d527_metadata_full_qualification'
identity=p.scope_identity(p.cg_path().name); group=pathlib.Path(identity['path'])
with (raw/'backup_identity.json').open('x') as f: json.dump(identity,f,indent=2)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],p.GIB); assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
qualification=json.loads((out/'input_qualification.json').read_text())
assert qualification['passed'] and qualification['tests']==308 and qualification['exact_runtime_profiles_loaded']
assert qualification['non_target_config_equal'] and not qualification['cuda_initialized']
for path,sha in qualification['refs'].items(): assert p.digest(pathlib.Path(path))==sha,path
closed=json.loads((raw/'qualification_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert closed['identity']==qualification['identity'] and not pathlib.Path(closed['identity']['path']).exists()
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
protected=p.verify_seal(raw.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members=sorted([*raw.glob('*.py'),*raw.glob('*.sh')])+[raw/n for n in ('qualification.json','qualification_tests.log','qualification_closure.json')]
for path in members:
    data=path.read_bytes(); check(data)
    if path.suffix=='.py': ast.parse(data)
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
archive=out/'qualification_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in members: bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    for path in members: assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
record=dict(passed=True,tests=308,full_performance_qualified=False,n_correct=None,
    protected=protected,qualification_resources=closed['resources'],
    archive=dict(sha256=p.digest(archive),bytes=archive.stat().st_size),
    helpers={path.name:p.digest(path) for path in members if path.suffix in ('.py','.sh')},
    next='ONE original100 Full, actual native contract/metadata audit then ONE new4000 W0')
with (out/'prelaunch.json').open('x') as f: json.dump(record,f,indent=2)
with (out/'prelaunch.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.is_file() and path.name!='prelaunch.sha256': f.write(p.digest(path)+'  '+path.name+'\n')
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D527_FULL_METADATA_QUALIFICATION.md',
    'configs/ieee_tc/20261014_d527_7b_cpu_frontend_validation_100.yaml',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh']
names += [str(path.relative_to(ROOT)) for path in sorted(out.iterdir()) if path.is_file()]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
for name in names: check((ROOT/name).read_bytes())
subprocess.run(['sha256sum','-c','prelaunch.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(names) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged: assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: qualify exact metadata profiles for original Full100 (D527)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
with (raw/'backup_receipt.json').open('x') as f: json.dump(dict(passed=True,head=head,remote=remote,staged=staged,identity=identity),f,indent=2)
print(json.dumps(dict(passed=True,head=head,remote_equal=True,files=len(staged))),flush=True)
