"""D522/D524 bounded configuration qualification, reusing D526 measured profiles."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
PUB = ROOT/'paper_results/ieee_tc/p2_backend/d527_metadata_full_qualification'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate = p.preflight([ROOT], p.GIB)
assert gate['preflight_pass'], gate['issues']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'

calibration = ROOT/'paper_results/ieee_tc/p2_backend/d526_metadata_profiles'
manifest = json.loads((calibration/'initialization/manifest.json').read_text())
assert manifest['passed'] and manifest['coverage']['class_domain_covered']
assert manifest['summary']['requests'] == 1669 and manifest['metadata_publication_audit']['triggered']
assert manifest['source_run']['sha256'] == p.digest(Path(manifest['source_run']['path']))
assert json.loads((RAW.parent/'d526_20261014/backup_receipt.json').read_text())['head'] == 'a0081007e683aac892065af8558e9cd5027394c8'
for name in ('analysis','seal','export','backup'):
    closed = json.loads((RAW.parent/'d526_20261014'/(name+'_closure.json')).read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()

old_path = ROOT/'configs/ieee_tc/20261014_d523_7b_cpu_frontend_validation_100.yaml'
new_path = ROOT/'configs/ieee_tc/20261014_d527_7b_cpu_frontend_validation_100.yaml'
old, new = [yaml.safe_load(path.read_text()) for path in (old_path,new_path)]
for key, binding in manifest['bindings'].items():
    assert new['resource_coordination'][key] == binding
    assert p.digest(Path(binding['path'])) == binding['sha256']
left, right = copy.deepcopy(old), copy.deepcopy(new)
for config in (left,right):
    config['experiment'].pop('output_dir')
    config['storage'].pop('nvme_cache_dir')
    config['storage'].pop('host_cache_dir')
    for key in manifest['bindings']:
        config['resource_coordination'].pop(key)
assert left == right, 'non-profile configuration changed'

from faaslora.experiment.instance_pool import FrozenServiceProfiles
from faaslora.preloading.preloading_planner import FrozenPreparationProfiles
from scripts.run_all_experiments import _prepare_dedicated_subprocess_model_cfg
contract = json.loads((ROOT/'paper_results/ieee_tc/p2_backend/d524_metadata_profiles/development_contract.json').read_text())
model = dict(new['model'], ieee_admission_profile=contract['model_config']['ieee_admission_profile'])
child, _ = _prepare_dedicated_subprocess_model_cfg(model, device_id=0, runtime_gpu_ids=[0])
assert FrozenServiceProfiles.model_identity(child) == FrozenServiceProfiles.model_identity(contract['model_config'])
loaded = {}
for name, cls in (('service',FrozenServiceProfiles),('preparation',FrozenPreparationProfiles)):
    binding = manifest['bindings']['ieee_'+name+'_profile']
    profile = cls.load(Path(binding['path']), expected_sha256=binding['sha256'],
        model_config=child, expected_context=binding['context'], beta=binding['ewma_beta'])
    loaded[name] = profile.identity()

subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['bash','-n','scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'],cwd=ROOT,check=True)
with (RAW/'qualification_tests.log').open('x') as log:
    result = unittest.TextTestRunner(stream=log,verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromNames([
            'tests.test_ieee_tc_launch.IEEEIntegratedLaunchContract',
            'tests.test_ieee_tc_launch.ScenarioRuntimeConfiguration',
            'tests.test_ieee_tc_launch.SharedDedicatedFactory',
            'tests.test_ieee_tc_launch.FullPrefixQualification',
            'tests.test_basic_smoke']))
import torch
assert not torch.cuda.is_initialized()
refs = [old_path,new_path,calibration/'initialization/manifest.json',Path(__file__),
    ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',ROOT/'scripts/run_all_experiments.py',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
refs += [Path(binding['path']) for binding in manifest['bindings'].values()]
record = dict(passed=result.wasSuccessful() and not result.skipped,identity=identity,
    tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
    gate=gate,protected=protected,cuda_initialized=False,non_target_config_equal=True,
    exact_runtime_profiles_loaded=True,profiles=loaded,bindings=manifest['bindings'],
    n_correct=None,full_performance_qualified=False,new_inputs_generated=False,
    refs={str(path):p.digest(path) for path in refs})
save(RAW/'qualification.json',record)
assert record['passed']
PUB.mkdir(parents=True,exist_ok=False)
save(PUB/'input_qualification.json',record)
print(json.dumps(dict(passed=True,tests=result.testsRun,exact_runtime_profiles_loaded=True,
    non_target_config_equal=True,cuda_initialized=False)),flush=True)
