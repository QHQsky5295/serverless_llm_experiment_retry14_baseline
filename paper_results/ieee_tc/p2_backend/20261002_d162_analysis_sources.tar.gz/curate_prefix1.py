"""Reuse D143 qualification/table and D153 bounded caller accounting for D162.

Diagnostic only. No normal-result JSON parse and no performance qualification.
"""
import collections
import csv
import importlib.util
import json
from pathlib import Path
import subprocess
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d162_20261002'
old = root/'results/ieee_tc/p2_backend_qualification/d143_20261001'
e = raw/'7b_full_w0_prefix1/launch.launch'
out = root/'paper_results/ieee_tc/p2_backend'
load = lambda p: json.loads(p.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == 'ccde02142b1846965795551d3317979086c6b150'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for unit in ('primelora-tc-svc-6a3cd29c678841fea006eb99dfd594a1.scope',
             'primelora-tc-aux-c20065e2272e4effa0392a8171f0fcd7.scope',
             'primelora-d162-cpu-collection-20261002.scope',
             'primelora-d162-prefix1-metadata-20261002.scope'):
    for prop, expected in (('ActiveState','inactive'),('InvocationID',''),('ControlGroup','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == expected
preflight = load(raw/'prelaunch_verification.json')
for name, sha in preflight['source_sha256'].items():
    assert digest(root/name) == sha, name
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
# Reuse the already-qualified reader; compare its complete source, not its name.
expected = (old/'collect_prefix1_cpu.py').read_text().replace('d143','d162').replace('D143','D162')
assert (raw/'collect_prefix1_cpu.py').read_text() == expected
assert 'Ran 6 tests in 0.061s\n\nOK\n' in (old/'cpu_collection_test.log').read_text()
for name in ('cpu_collection_time.txt','prefix1_metadata_time.txt'):
    assert 'Exit status: 0' in (raw/name).read_text()
assert 'cleanup=automatic_removal_verified' in (raw/'prefix1_local_cleanup.txt').read_text()
cpu = load(raw/'prefix1_cpu_samples.json')
preliminary = load(raw/'prefix1_preliminary.json')
assert cpu['terminal_count'] == preliminary['population']['terminal'] == 1000
assert cpu['terminal_successes'] == preliminary['population']['success']
assert cpu['terminal_failures'] == 1000-cpu['terminal_successes']
assert preliminary['cleanup']['complete']
assert not preliminary['full_qualified'] and not preliminary['formal_performance_result']
source = preliminary['normal_source_stat']
stat = Path(source['path']).stat()
assert (stat.st_size,stat.st_ino,stat.st_mtime_ns) == (source['bytes'],source['inode'],source['mtime_ns'])
assert abs(sum(preliminary['window_gpu_seconds'].values())-preliminary['physical_gpu_seconds']) < 1e-6
receipt = load(e/'exec_receipt.json')
t0 = receipt['external_replay']['replay_t0_s']
spec = importlib.util.spec_from_file_location('d162_reader',raw/'collect_prefix1_cpu.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
terminals = []
for row, partial in reader.rows(e/'physical_deployment/request_terminals.jsonl'):
    assert not partial
    terminals.append(row)
assert len(terminals) == len({r['request_id'] for r in terminals}) == 1000
assert all(r['clock_id'] == receipt['external_replay']['clock_id'] for r in terminals)
end = max(r['at'] for r in terminals)
details = []
roles = collections.Counter()
for process in cpu['processes']:
    for ref in process['source_refs']:
        assert digest(Path(ref['path'])) == ref['sha256']
    labels = process['role_evidence']
    role = ('frontend' if 'frontend' in labels else labels[0] if len(labels)==1 else 'unclassified')
    roles[role] += 1
    meta_path = Path(process['source_refs'][0]['path'])
    meta = load(meta_path)
    inclusive, callers, nearest = collections.Counter(), collections.Counter(), collections.Counter()
    examples, window, missing, truncated = {}, 0, 0, 0
    for row, partial in reader.rows(meta_path.with_suffix('.stacks.jsonl')):
        if partial:
            assert partial == process['final_partial_line_bytes']
            break
        if not t0 <= row['observed_monotonic_s'] <= end:
            continue
        main = [t for t in row['threads'] if t['ident'] == meta['main_thread_ident']]
        if not main:
            missing += 1
            continue
        main, = main
        window += 1
        truncated += int(main['truncated'])
        frames = main['frames']
        local = [(i,f.removeprefix(str(root)+'/'),n,line) for i,(f,n,line) in enumerate(frames)
                 if f.startswith(str(root)+'/')]
        nearest[(str(root)+'/'+local[0][1],local[0][2]) if local else ('','no_project_frame')] += 1
        inclusive.update(set((f,n) for _,f,n,_ in local))
        for i,f,n,line in local:
            caller = frames[i+1] if i+1 < len(frames) else ['','truncated',0]
            callers[(f,n,line,*caller)] += 1
            if (f,n) not in examples:
                examples[(f,n)] = dict(index=row['index'],at=row['observed_monotonic_s'],
                    truncated=main['truncated'],frames=frames[:min(len(frames),i+5)])
    assert window == process['main_phase_counts'].get('request_window',0)
    assert sum(nearest.values()) == window and all(v <= window for v in inclusive.values())
    # Independently reconcile reused collector's exact top counters and denominator.
    assert reader.top(nearest,window) == process['request_window_nearest_project']
    details.append(dict(pid=process['pid'],role=role,window_samples=window,
        missing_main_samples=missing,truncated_main_samples=truncated,
        inclusive=[dict(file=k[0],function=k[1],samples=v) for k,v in inclusive.most_common()],
        callers=[dict(file=k[0],function=k[1],line=k[2],caller_file=k[3],
            caller_function=k[4],caller_line=k[5],occurrences=v) for k,v in callers.most_common()],
        examples=[dict(file=k[0],function=k[1],**v) for k,v in examples.items()]))
table = out/'20261002_d162_prefix_roles.csv'
with table.open('x',newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['pid','role','all_samples','request_window_samples','max_sampling_delay_s',
        'missing_main_samples','truncated_main_samples','final_partial_line_bytes'])
    for process, detail in zip(cpu['processes'],details):
        writer.writerow([process['pid'],detail['role'],process['samples'],detail['window_samples'],
            process['max_schedule_lag_s'],process['missing_main_samples'],
            process['truncated_main_samples'],process['final_partial_line_bytes']])
files = [raw/name for name in ('collect_prefix1_cpu.py','collect_prefix1_cpu.sh',
    'collect_prefix1_preliminary.py','inspect_prefix1_metadata.sh','curate_prefix1.py',
    'prefix1_cpu_samples.json','prefix1_preliminary.json','prelaunch_verification.json',
    '7b_main_config_prefix1.yaml','run_7b_full_w0_prefix1.sh','profile_controller_python.sh',
    'prefix1_metadata_compaction.sha256','cpu_collection_scope.txt','prefix1_metadata_scope.txt',
    'prefix1_local_cleanup.txt','stop_services_prefix1.log','remote_copy_receipt.txt')]
files += [e.parent/'launch.json',e/'exec_receipt.json',e/'physical_deployment/summary.json',
    e/'physical_deployment/deployment.json',e/'physical_deployment/request_terminals.jsonl',
    old/'cpu_collection_test.log',table]
result = dict(kind='d162_current_prefix_diagnostic_v1',
    serving_commit='11a5432ecac7ca6214417ffc471c834b6edeb3e3',
    launch_commit='ccde02142b1846965795551d3317979086c6b150',
    formal_performance_result=False,full_qualification=False,latency_identity_audit_complete=False,
    full_raw_request_json_reparsed=False,source_count=4000,prefix_count=1000,
    protected=protected,prelaunch_refs_verified=len(preflight['source_sha256']),
    reader_qualification_reused=True,roles=dict(roles),preliminary=preliminary,cpu=cpu,
    request_window_details=details,caveats=cpu['caveats'],
    source_refs=[dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p)) for p in files])
curated = out/'20261002_d162_prefix_diagnostic.json'
with curated.open('x') as stream:
    json.dump(result,stream,indent=2,allow_nan=False)
print(json.dumps(dict(curated_sha256=digest(curated),table_sha256=digest(table),
    roles=dict(roles),protected=147,prelaunch_refs=len(preflight['source_sha256']),
    diagnostic_only=True)))
