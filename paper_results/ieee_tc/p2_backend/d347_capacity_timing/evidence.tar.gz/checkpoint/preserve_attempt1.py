"""Preserve the failed offline implementation and close its exact empty scopes."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
raw = Path(__file__).resolve().parent
identities = [json.loads((raw/'analysis_receipt.json').read_text())['identity'],
    p.scope_identity('primelora-tc-aux-34700000000000000000000000000002.scope')]
closed = []
for identity in identities:
    group = Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources = {k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
    result = p.stop_scope_identity(identity)
    assert result['released'] and not result['hard_kill']
    closed.append(dict(identity=identity,resources=resources,result=result))
paths = [p.ROOT/'scripts/ieee_tc/analyze_d297_full.py',
    p.ROOT/'tests/test_ieee_tc_decode_overlap.py', raw/'analyze.py',
    raw/'analysis_receipt.json', raw/'analysis1.log']
archive = raw/'attempt1_source_and_failure.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths: tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest() == p.digest(path)
with (raw/'attempt1_cleanup.json').open('x') as f:
    json.dump(dict(closed=closed,archive_sha256=p.digest(archive),
        reason='One real cancelled activation lacks readiness; old offline analyzer rejected it. No inference repeat.'),f,indent=2)
print(json.dumps(dict(closed=len(closed),archive_sha256=p.digest(archive))))
