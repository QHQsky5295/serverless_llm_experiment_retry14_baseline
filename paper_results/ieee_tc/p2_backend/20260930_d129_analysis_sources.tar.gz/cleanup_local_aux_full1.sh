#!/usr/bin/env bash
set -euo pipefail
# Reuse D129 exact-identity / empty-domain cleanup; only D129 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-047ddce723ea4a3c8181ee28fead7c79.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-2bf6a7a467ba49faac73c8b82c7e633a.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 2115a3e3b4824151a07488a3b51f5eae
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-2bf6a7a467ba49faac73c8b82c7e633a.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
