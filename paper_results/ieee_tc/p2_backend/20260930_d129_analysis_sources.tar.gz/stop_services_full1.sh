#!/usr/bin/env bash
set -euo pipefail
# Existing D110 exact-identity cleanup, adapted to D129. Execute remotely ONLY
# after local main exit and GPU cleanup; never while inference is running.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d129full1.service)
ids=(f312507516c24ddba2d7301ca19d8e50 092d60c8e4c749eb9405fe0cd8aca125 07c329a0de6a4ba8859cff783a9f4505)
pids=(549245 549247 549250)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result
