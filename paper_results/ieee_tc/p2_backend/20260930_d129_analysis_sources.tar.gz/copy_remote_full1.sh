#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d129_20260930
alias=primelora-artifact-174
journal=/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-7e320ca56b5c41b2ba645c6326c8405e.jsonl
monitor=/home/lab14/primelora_remote/tc/d129_20260930/remote_monitor_7b_full_full1.log
test "$(systemctl --user show primelora-tc-svc-047ddce723ea4a3c8181ee28fead7c79.scope -p ActiveState --value)" = inactive
test -s "$raw/stop_services_full1.log"
test ! -e "$raw/remote_7b_full1_transfers.jsonl"
test ! -e "$raw/remote_monitor_full1_final.log"
test ! -e "$raw/remote_copy_receipt.txt"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "head -n 1 '$journal'" |
  jq -e '.clock_id == "remote-process-monotonic:e7645c2f706646dd842090130a860f5d"'
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "sha256sum '$journal' '$monitor'" > "$raw/remote_copy_receipt.txt"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$journal" "$raw/remote_7b_full1_transfers.jsonl"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$monitor" "$raw/remote_monitor_full1_final.log"
read -r expected_journal _ < "$raw/remote_copy_receipt.txt"
expected_monitor=$(sed -n '2s/ .*//p' "$raw/remote_copy_receipt.txt")
actual_journal=$(sha256sum "$raw/remote_7b_full1_transfers.jsonl" | cut -d' ' -f1)
actual_monitor=$(sha256sum "$raw/remote_monitor_full1_final.log" | cut -d' ' -f1)
test "$actual_journal" = "$expected_journal"
test "$actual_monitor" = "$expected_monitor"
sha256sum "$raw/remote_7b_full1_transfers.jsonl" "$raw/remote_monitor_full1_final.log"
