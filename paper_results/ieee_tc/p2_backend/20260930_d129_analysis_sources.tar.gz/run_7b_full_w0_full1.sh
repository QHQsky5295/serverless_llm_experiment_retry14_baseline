#!/usr/bin/env bash
set -euo pipefail
MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d129_20260930
CACHE=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/model_20260926/candidate_cache
cd "${MAIN}"
test "$(git rev-parse HEAD)" = 75deef6873c6e0a3cdbf604498fe0464e6f46bd5
test ! -e "${RAW}/7b_full_w0_full1/launch.json"
test ! -e "${RAW}/7b_nvme_full1/tc_ieee_full"
test ! -e /dev/shm/tc-d129-7b-full1/tc_ieee_full
mkdir -p "${RAW}/7b_full_w0_full1"
export PATH="/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin:${PATH}"
export CUDA_HOME=/usr/local/cuda-13.0
export FLASHINFER_NVCC=/usr/local/cuda-13.0/bin/nvcc
export MAX_JOBS=2
IFS= read -r PRIME_REMOTE_TOKEN < /home/qhq/.config/primelora-tc-d75/artifact.token || test -n "${PRIME_REMOTE_TOKEN:-}"
export PRIME_REMOTE_TOKEN
export FAASLORA_REMOTE_ARTIFACT_ENABLED=1
export FAASLORA_REMOTE_ARTIFACT_ENDPOINT=http://192.168.4.174:18081
export FAASLORA_REMOTE_ARTIFACT_DELIVERY_MODE=prepublished_gzip_v1
export FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY=uncached_background_v1
export PYTORCH_ALLOC_CONF=pinned_max_cached_size_mb:0,pinned_use_background_threads:True
export VLLM_CACHE_ROOT="${CACHE}"
export TRITON_CACHE_DIR="${CACHE}/triton"
export TORCHINDUCTOR_CACHE_DIR="${CACHE}/inductor"
export FAASLORA_PYTHON=/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python
export FAASLORA_TC_QUALIFICATION=1
export FAASLORA_TC_EXTERNAL_REPLAY=1
export FAASLORA_TC_REPLAY_PROFILE=W0
unset FAASLORA_TC_DIAGNOSTIC_PREFIX_COUNT
export FAASLORA_TC_LAUNCH_OUTPUT="${RAW}/7b_full_w0_full1/launch.json"
export FAASLORA_TC_PREDICTED_GROWTH_GIB=32
export FAASLORA_TC_NVML_BINDING=/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py
export FAASLORA_TC_NVML_SHA256=4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea
export FAASLORA_SHARED_TRACE_PATH=/home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260424_131528_llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1/shared_artifacts/llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json
export FAASLORA_SHARED_ADAPTER_SUBSET_PATH="${FAASLORA_SHARED_TRACE_PATH%_trace.json}_adapter_subset.json"
export FAASLORA_TRACE_ROLE=exploratory
export FAASLORA_FORMAL_RUN=0
export FAASLORA_RESULTS_TAG=d129_7b_full_w0_full1
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 VLLM_NO_USAGE_STATS=1
exec bash scripts/run_all_experiments_user_scope.sh --config "${RAW}/7b_main_config_full1.yaml" --scenario tc_ieee_full --full-stack
