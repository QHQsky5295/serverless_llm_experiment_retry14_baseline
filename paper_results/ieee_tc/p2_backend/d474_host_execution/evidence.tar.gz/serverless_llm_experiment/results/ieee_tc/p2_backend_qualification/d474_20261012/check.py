"""D474 uses D463's bounded unittest/provenance entry; no new replay framework."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
phase=sys.argv[1]
assert phase in ('red','targeted','regression')
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
scope=p.scope_identity(p.cg_path().name)
save(phase+'_identity.json',scope)
assert os.environ['CUDA_VISIBLE_DEVICES']==''
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
tests=['tests.test_ieee_tc_host_execution_projection']
if phase!='red':
    tests += ['tests.test_ieee_tc_transfer_pressure','tests.test_ieee_tc_gpu_references',
        'tests.test_ieee_tc_identity_recheck','tests.test_ieee_tc_host_observation_freshness']
if phase=='regression':
    tests += ['tests.test_ieee_tc_request_lifecycle','tests.test_ieee_tc_service_events',
              'tests.test_ieee_tc_worker_observation','tests.test_basic_smoke']
sources=[ROOT/x for x in ('scripts/run_all_experiments.py','tests/test_ieee_tc_transfer_pressure.py',
    'tests/test_ieee_tc_host_execution_projection.py','faaslora/memory/gpu_monitor.py',
    'faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py',
    'faaslora/experiment/instance_pool.py')]+[Path(__file__)]
for source in sources:ast.parse(source.read_text())
before={str(x):p.digest(x) for x in sources}
save(phase+'_sources.json',dict(sources=before,tests=tests,parent=subprocess.check_output(
    ['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),diff=subprocess.check_output(
    ['git','diff','HEAD','--','scripts/run_all_experiments.py','tests/test_ieee_tc_transfer_pressure.py'],cwd=ROOT,text=True)))
start=time.monotonic()
with (RAW/(phase+'_tests.log')).open('x') as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(tests))
assert before=={str(x):p.digest(x) for x in sources}
report=dict(passed=result.wasSuccessful(),tests=result.testsRun,failures=len(result.failures),
    errors=len(result.errors),skipped=len(result.skipped),elapsed_s=time.monotonic()-start,
    sources=before,scope=scope,protected=protected,expected_red=phase=='red')
save(phase+'_result.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ('sources','scope','protected')}))
raise SystemExit(0 if result.wasSuccessful() or phase=='red' else 1)
