"""Bounded tests of D365 immutable file-demand identity; no GPU inference or remote changes."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
tag=sys.argv[1];assert tag in ('before','targeted','cpu','native')
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
def resources():
    return {k:(group/k).read_text().strip() for k in
        ('memory.high','memory.max','memory.peak','memory.events','memory.swap.max','memory.swap.current')}
before=resources()
assert before['memory.high']==str(3*p.GIB) and before['memory.max']==str(4*p.GIB)
assert before['memory.swap.max']=='0' and os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
allowed='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert protected['changed']==[allowed]
assert p.digest(Path(allowed))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
tests=['tests.test_ieee_tc_gpu_references','tests.test_ieee_tc_request_lifecycle',
       'tests.test_ieee_tc_pending_admission','tests.test_ieee_tc_admission',
       'tests.test_ieee_tc_hit_host_transaction','tests.test_ieee_tc_native_retirement',
       'tests.test_ieee_tc_scheduler_observation', 'tests.test_ieee_tc_file_observation',
       'tests.test_http_artifact_store', 'tests.test_ieee_tc_transfer_pressure']
if tag in ('before', 'targeted'):
    tests=['tests.test_ieee_tc_gpu_references.ProtectedFileDemandTransactions',
        'tests.test_ieee_tc_request_lifecycle.SelectedSourceAdmissionIntegration',
        'tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication']
if tag=='before':
    tests=['tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication.test_file_demand_witness_survives_bounded_allocation_refresh',
        'tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication.test_file_demand_witness_rejects_allocation_outside_reserved_envelope']
python=('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python' if tag=='native'
        else '/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python')
command=[python,'-m','unittest',*tests,'-q']
source_paths=[ROOT/x for x in ('faaslora/memory/residency_manager.py','faaslora/memory/gpu_monitor.py',
    'faaslora/scheduling/vllm_ieee_scheduler.py','scripts/run_all_experiments.py',
    'tests/test_ieee_tc_gpu_references.py','tests/test_ieee_tc_request_lifecycle.py',
    'tests/test_ieee_tc_scheduler_observation.py')]
source_hashes={str(x.relative_to(ROOT)):p.digest(x) for x in source_paths}
import tarfile
with (RAW/(tag+'_sources.tar.gz')).open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as archive:
    for path in source_paths: archive.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
with (RAW/(tag+'.log')).open('x') as f:
    result=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
            VLLM_NO_USAGE_STATS='1',CUDA_VISIBLE_DEVICES=''))
record=dict(identity=identity,before=before,after=resources(),gate=gate,protected=protected,
    command=command,returncode=result.returncode,passed=result.returncode==0,
    sources=source_hashes,no_gpu_run=True,
    plan_sha256=p.check_plan(),protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'))
with (RAW/(tag+'_receipt.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(tag=tag,returncode=result.returncode,resources=record['after'])))
if tag=='before':
    assert result.returncode != 0, 'unchanged serving code must reproduce the defect'
else:
    result.check_returncode()

