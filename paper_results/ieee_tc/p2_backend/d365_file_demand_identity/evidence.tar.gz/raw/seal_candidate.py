"""D365 bounded checkpoint; reuse D360 sealing and exact scope cleanup rules."""
import ast
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d365_file_demand_identity'
gate=p.preflight([ROOT],4*p.GIB)
assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
out.mkdir(parents=True,exist_ok=False)
records={};closed=[]
for tag in ('before','targeted','cpu','native'):
    record=json.loads((raw/(tag+'_receipt.json')).read_text())
    assert record['passed'] is (tag!='before')
    records[tag]=record
    identity=record['identity'];group=Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    cleanup=p.stop_scope_identity(identity)
    assert cleanup['released'] and not cleanup['hard_kill']
    closed.append(dict(tag=tag,identity=identity,resources=resources,cleanup=cleanup))
with (raw/'test_cleanup.json').open('x') as f:json.dump(closed,f,indent=2)
assert records['cpu']['sources']==records['native']['sources']
for name,sha in records['native']['sources'].items(): assert p.digest(ROOT/name)==sha,name
# The failing reproduction must execute exactly the committed production code.
committed=subprocess.check_output(['git','show','e8f8a5135111205cf6feebea45d39db1b076ec11:faaslora/memory/residency_manager.py'],cwd=ROOT)
assert hashlib.sha256(committed).hexdigest()==records['before']['sources']['faaslora/memory/residency_manager.py']
import re
counts={tag:int(re.search(r'Ran (\d+) tests',(raw/(tag+'.log')).read_text())[1]) for tag in records}
assert counts==dict(before=2,targeted=77,cpu=662,native=662)
assert 'FAILED (errors=4)' in (raw/'before.log').read_text()
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert protected['changed']==[known] and protected['entry_count']==147
assert p.digest(Path(known))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
with (raw/'protected.json').open('x') as f:json.dump(protected,f,indent=2)
paths=[raw/name for name in ('test_cleanup.json','test_candidate.py','seal_candidate.py','protected.json')]
paths += [raw/(tag+suffix) for tag in records for suffix in ('.log','_receipt.json')]
paths += [ROOT/'docs/ieee_tc/D365_FILE_DEMAND_IDENTITY.md']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
payloads={('raw/'+x.name if x.parent==raw else str(x.relative_to(ROOT))):x.read_bytes()
          for x in paths}
for tag,record in records.items():
    with tarfile.open(raw/(tag+'_sources.tar.gz'),'r:gz') as tar:
        for name,sha in record['sources'].items():
            data=tar.extractfile(name).read()
            assert hashlib.sha256(data).hexdigest()==sha
            payloads[tag+'/'+name]=data
assert token and all(token not in data for data in payloads.values())
archive=out/'evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for name,data in payloads.items():
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644
        tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(payloads)
    for name,data in payloads.items(): assert tar.extractfile(name).read()==data
evidence=dict(kind='d365_file_demand_identity_repair_v1',
    code_parent='e8f8a5135111205cf6feebea45d39db1b076ec11',
    cpu_tests=662,native_environment_cpu_tests=662,new_gpu_runs=0,no_figures=True,
    production_performance_qualified=False,formal_qualification=False,n_correct=None,
    first_test_failure='unchanged serving code rejects all four bounded allocation refresh cases',
    historical_d364_root_cause_proven=False,test_counts=counts,
    archive_sha256=p.digest(archive),source_sha256=records['native']['sources'],
    plan_sha256=p.check_plan(),protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    tests={tag:dict(passed=r['passed'],resources=r['after']) for tag,r in records.items()},
    exact_test_scope_cleanup=closed,protected=protected,
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths])
with (out/'evidence.json').open('x') as f:json.dump(evidence,f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for name in ('evidence.json','evidence.tar.gz'): f.write(p.digest(out/name)+'  '+name+'\n')
own=p.scope_identity(p.cg_path().name)
with (raw/'seal_scope.json').open('x') as f:
    json.dump(dict(identity=own,resources={k:(Path(own['path'])/k).read_text() for k in (
        'memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(tests_closed=len(closed),archive_bytes=archive.stat().st_size,
    archive_members=len(payloads),cpu_tests=662,native_cpu_tests=662)))

