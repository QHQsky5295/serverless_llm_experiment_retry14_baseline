"""Bind unchanged D632/D633 minimum-two model point to the existing full W0."""
import ast, copy, json, os, subprocess, sys
from pathlib import Path
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'qualification_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='1ef5e5f58d4db141395e8a7acac812779c4af35f'
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
production=ROOT/'scripts/run_all_experiments.py'
parent=RAW.parent/'d633_20261017'
previous=RAW.parent/'d631_20261017'
old=read(parent/'qualification.json')
assert old['passed'] and old['count']==4000
assert old['three_replica_checks']['passed'] and old['three_replica_checks']['case_count']==192
# Reuse completed D633 and unchanged D631 regression evidence, not performance retries.
for path,sha in {**old['refs'],**old['preserved']}.items():
    if Path(path)!=shell:assert p.digest(Path(path))==sha,path
reg=read(previous/'qualification_receipt.json')
assert reg['passed'] and reg['returncode']==0
test_sources=reg['sources']
for path,sha in test_sources.items():assert p.digest(Path(path))==sha,path
assert p.digest(previous/'qualification.log')==reg['log_sha256']
import re
assert sum(map(int,re.findall(r'Ran (\d+) tests?',(previous/'qualification.log').read_text())))==458
assert old['control_tests_run']==0 and old['reused_control_tests']==32
assert old['three_replica_checks']['lower_bound']==2 and old['three_replica_checks']['upper_bound']==3
phases=('qualification','backup','start','collection','analysis','publication','publication2','publication3')
for phase in phases:
    closed=read(parent/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
local=read(parent/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
assert read(parent/'remote_stop.json')['all_owned_units_inactive']
auditpath=ROOT/'paper_results/ieee_tc/p2_backend/d633_min2_full_w1/result1/summary.json'
audit=read(auditpath)
completed=read(parent/'actual_qualification.json')
assert audit['passed'] and audit['audit']==completed
assert completed['passed'] and completed['protocol_bound_count']==4000
assert audit['comparison']['joint95_observed'] and audit['comparison']['budget_feasible_observed']
assert read(parent/'minimum_two_evidence.json')['passed']
assert read(parent/'publication3_receipt.json')['head']=='1ef5e5f58d4db141395e8a7acac812779c4af35f'
gate=p.preflight([ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
paths=[ROOT/'configs/ieee_tc/20261017_d633_7b_min2_full_w1.yaml',
       ROOT/'configs/ieee_tc/20261017_d634_7b_min2_full_w0.yaml']
configs=[yaml.safe_load(path.read_text()) for path in paths]
normalized=copy.deepcopy(configs)
for row in normalized:
    row['experiment'].pop('output_dir')
    row['storage'].pop('nvme_cache_dir');row['storage'].pop('host_cache_dir')
assert normalized[0]==normalized[1], 'no W0-specific model or policy tuning'
assert configs[1]['resource_coordination']['max_instances']==3
assert configs[1]['resource_coordination']['min_instances']==2
assert configs[1]['model']['visible_device_ids']==configs[1]['hardware']['gpu_device_ids']==[0,1,2,3]
for path in (Path(configs[1]['experiment']['output_dir']),Path(configs[1]['storage']['nvme_cache_dir']),Path(configs[1]['storage']['host_cache_dir'])):
    assert not path.exists(),path
body=shell.read_text();start=body.index('  d634)\n');end=body.index('    ;;\n',start)+len('    ;;\n')
branch=body[start:end]
assert paths[1].name in branch and 'PREFIX_COUNT=\n' in branch and 'SCENARIO=tc_ieee_full\n' in branch
native_block="if [[ \"${1:-d293}\" == d634 ]]; then\n  export FAASLORA_TC_NATIVE_TOOLCHAIN_CONTRACT=\"$ROOT/configs/ieee_tc/native_toolchain_cuda130_v1.json\"\n  export FAASLORA_TC_NATIVE_TOOLCHAIN_SHA256=328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c\nfi\n"
assert body.count(native_block)==1
restored=(body[:start]+body[end:]).replace(native_block,'',1)
assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
observer_line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd328' in line)
assert 'd634' not in observer_line
w1line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd533' in line)
w2line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd554' in line)
assert 'd634' not in w1line and 'd634' not in w2line
oldw0path=RAW.parent/'d529_20261014/7b_full_w0/launch.json'
oldw0=read(oldw0path)['external_replay']['plan']
plan=FrozenReplayPlan.load(oldw0['source_path'],profile='W0')
assert plan.identity()==oldw0 and len(plan.entries)==plan.source_count==4000
assert plan.identity()['source_sha256']=='efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
assert plan.identity()['view_sha256']=='a5331be2e2204483f18206825d9aaa18cbaa259fe0babfc303f989055819430d'
assert 'adapter_map' not in plan.identity()
assert FrozenReplayPlan.from_launch_context(dict(plan=plan.identity(),tiny_witness=False,replay_scope='full_source_v1'))==plan
from scripts.run_all_experiments import ScenarioRunner, _prepare_scenario_runtime_model_config, _normalize_runtime_concurrency_cap
full=configs[1];scenario=next(row for row in full['scenarios'] if row['name']=='tc_ieee_full')
coord=dict(full['resource_coordination'],**scenario.get('resource_coordination',{}))
runner=ScenarioRunner.__new__(ScenarioRunner)
runner.model_cfg=_prepare_scenario_runtime_model_config(_normalize_runtime_concurrency_cap(full['model']),full['workload'],coord)
runner.coord_cfg=coord;runner._initial_runtime_pending=True
runner._service_profiles=runner._load_ieee_service_profiles();runner._load_ieee_preparation_profiles()
buildpath=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=read(buildpath);assert build['passed'] and build['actual_closure']['passed'] and build['actual_closure']['path_gone']
assert not Path(build['actual_closure']['identity']['path']).exists()
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256'],path
helpers=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),shell])
for path in helpers:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    else:subprocess.run(['bash','-n',str(path)],check=True)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
refs=[*helpers,*paths,parent/'qualification.json',auditpath,oldw0path,buildpath,
    parent/'actual_qualification.json',parent/'minimum_two_evidence.json',
    parent/'local_cleanup.json',parent/'remote_stop.json',parent/'publication3_receipt.json',
    previous/'qualification_receipt.json',previous/'qualification.log',
    RAW.parent/'d624_20261017/qualify.py',RAW.parent/'d550_20261015/close.py']
refs += [parent/(phase+'_closure.json') for phase in phases]
refs += [Path(path) for path in old['refs'] if Path(path)!=shell]
refs += list(map(Path,test_sources))
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
import torch
assert not torch.cuda.is_initialized()
save(RAW/'qualification.json',dict(passed=True,scope=identity,protected=protected,preserved=old['preserved'],
    prime_plan=plan.identity(),source_count=4000,count=4000,configuration_changes={},
    same_model_working_point_as_d632_d633=True,unchanged_other_model_control_settings=True,
    three_replica_checks=old['three_replica_checks'],control_tests_run=0,reused_control_tests=32,
    reused_cpu_regression_tests=458,reused_focused_tests=0,reused_input_tests=386,
    native_mechanism_reuse_only=True,device_domain_fix_sha256=p.digest(production),
    exact_profiles_loaded=True,observer=None,ordinary_full_replay=True,ranking_eligible=False,
    preflight=gate,refs={str(path):p.digest(path) for path in refs},
    resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,count=4000,profile='W0',same_model_working_point_as_d632_d633=True,
    view_sha256=plan.identity()['view_sha256'],new_tests=0,reused_regression=458,reused_focused=0,
    reused_control_tests=32,reused_config_checks=192,exact_profiles_loaded=True)))
