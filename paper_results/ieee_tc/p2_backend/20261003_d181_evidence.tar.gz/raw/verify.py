"""Reuse D178 bounded evidence verification/seal, scoped to D181 changes."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal

RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
BASE='512b1be2d73924c59e7e36b1e80cf4e56669bd15'
PLAN='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
V1='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert check_plan()==PLAN and digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')==V1
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
serving={
 'scripts/run_all_experiments.py': (
    {'InferenceEngine.ieee_gpu_reference','InferenceEngine.ieee_source_identities',
     'SubprocessInferenceEngineProxy._rpc','ScenarioRunner.__init__',
     'ScenarioRunner._ieee_collect_native_sources','ScenarioRunner._ieee_request_snapshot'},
    {'InferenceEngine.ieee_request_sources','SubprocessInferenceEngineProxy.ieee_request_sources'}),
 'scripts/dedicated_engine_worker.py': ({'_run_worker'},set()),
 'faaslora/memory/gpu_monitor.py': (
    {'_ieee_lora_host_inventory','IEEEWorkerObservationExtension.ieee_gpu_reference'},set()),
 'faaslora/experiment/instance_pool.py': (
    {'NativeSourceSnapshot.identity_view','NativeSourceSnapshot._footprints','NativeSourceSnapshot.routing_wire',
     'InstanceSlot.accepts_native_sources','InstanceSlot._accepts_native_source_view','InstanceSlot.commit_native_sources'},
    {'NativeSourceSnapshot._request_scope','NativeSourceSnapshot.from_request_native',
     'NativeSourceSnapshot.request_wire','NativeSourceSnapshot.from_request_wire'})}
class Functions(ast.NodeVisitor):
    def __init__(self): self.prefix=[];self.found={}
    def visit_ClassDef(self,node):
        self.prefix.append(node.name);self.generic_visit(node);self.prefix.pop()
    def visit_FunctionDef(self,node): self.found['.'.join(self.prefix+[node.name])]=node
    visit_AsyncFunctionDef=visit_FunctionDef
for rel,(changed,added) in serving.items():
    before=ast.parse(subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT,text=True))
    after=ast.parse((ROOT/rel).read_text())
    old,new=Functions(),Functions();old.visit(before);new.visit(after)
    assert set(new.found)-set(old.found)==added and not set(old.found)-set(new.found),rel
    actual={name for name in old.found if ast.dump(old.found[name])!=ast.dump(new.found[name])}
    assert actual==changed,(rel,actual,changed)
    class Restore(ast.NodeTransformer):
        def __init__(self): self.prefix=[]
        def visit_ClassDef(self,node):
            self.prefix.append(node.name);self.generic_visit(node);self.prefix.pop();return node
        def visit_FunctionDef(self,node):
            key='.'.join(self.prefix+[node.name])
            if key in added:return None
            return old.found[key] if key in changed else node
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_AnnAssign(self,node):
            if (rel.endswith('instance_pool.py') and isinstance(node.target,ast.Name) and (
                    (self.prefix==['InstanceSlot'] and node.target.id in
                        ('native_source_footprint_frontier','native_source_capacity_frontier'))
                    or (self.prefix==['NativeSourceSnapshot'] and node.target.id=='footprint_adapter_ids'))):
                return None
            return node
    assert ast.dump(before)==ast.dump(Restore().visit(after)),rel
unchanged=['faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py',
           'faaslora/preloading/planning_cpu.py','faaslora/scheduling/resource_coordinator.py']
for rel in unchanged:
    assert (ROOT/rel).read_bytes()==subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT)
for phase,count in (('tests2',102),('regression1',973),('regression2',974)):
    log=(RAW/f'{phase}.log').read_text()
    assert f'Ran {count} tests' in log and log.rstrip().endswith('OK'),phase
failed=(RAW/'tests1.log').read_text()
assert 'Ran 102 tests' in failed and failed.rstrip().endswith('FAILED (errors=1)')
assert "SimpleNamespace' object has no attribute 'ieee_request_sources'" in failed
cleanup=[]
for phase in ('tests1','tests2','regression1','regression2'):
    for line in (RAW/f'{phase}_sources.sha256').read_text().splitlines():
        sha,path=line.split(maxsplit=1)
        target=ROOT/path
        if path=='faaslora/experiment/instance_pool.py' and phase!='regression2':
            target=RAW/'regression1_instance_pool.py'
        if path=='tests/test_ieee_tc_request_footprints.py' and phase!='regression2':
            target=RAW/('regression1_request_footprints.py' if phase=='regression1'
                        else 'tests2_request_footprints.py')
        if path=='tests/test_ieee_tc_request_lifecycle.py' and phase=='tests1':
            target=RAW/'tests1_request_lifecycle.py'
        assert digest(target)==sha,(phase,path)
    actual=re.search(r'^InvocationID=([a-f0-9]{32})$',(RAW/f'{phase}_scope.txt').read_text(),re.M)[1]
    state=subprocess.check_output(['systemctl','--user','show',f'primelora-d181-{phase}-20261003.scope',
        '-p','ActiveState','-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines()==['ControlGroup=','ActiveState=inactive','InvocationID=']
    assert all(int(line.split()[1])==0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text())==0
    code=int(phase=='tests1')
    assert f'Exit status: {code}' in (RAW/f'{phase}_time.txt').read_text()
    cleanup.append(dict(phase=phase,actual_invocation_id=actual,returncode=code,
        cleanup='automatic_removal_verified',final_memory_events_zero=True,final_swap_zero=True))
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
doc=ROOT/'docs/ieee_tc/D181_REQUEST_SCOPED_ROUTING.md'
rows=[dict(phase=phase,tests=count,errors=errors,status=status) for phase,count,errors,status in (
    ('tests1',102,1,'fixture_error_preserved'),('tests2',102,0,'pass'),
    ('regression1',973,0,'pass_before_capacity_frontier_guard'),('regression2',974,0,'pass_final_source'))]
for row in rows:
    assert f"| {row['phase']} | {row['tests']} | {row['errors']} | {row['status']} |" in doc.read_text()
with (RAW/'cleanup_verified.json').open('x') as out:json.dump(cleanup,out,indent=2)
table=OUT/'20261003_d181_request_scoped_routing.csv'
with table.open('x',newline='') as out:
    writer=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
curated=OUT/'20261003_d181_request_scoped_routing.json'
refs=[ROOT/p for p in serving]+[RAW/'verify.py',RAW/'run_cpu.sh',ROOT/'tests/test_ieee_tc_request_footprints.py',
    ROOT/'tests/test_ieee_tc_request_lifecycle.py']
study=OUT/'20261003_d180_request_scoped_footprint.json'
assert digest(study)=='a60f6ab26e9c09bb9db6eb6f38329a74c125e374efadb7ac0051841edf137302'
with curated.open('x') as out:
    json.dump(dict(kind='native_request_scoped_routing_qualification_v1',base_commit=BASE,
        metric_protocol_sha256=V1,plan_sha256=PLAN,rows=rows,cleanup=cleanup,
        dependency_study_sha256=digest(study),source_sha256={str(p):digest(p) for p in refs},
        tests_targeted=102,tests_regression=974,new_test_methods=16,
        test_counts_overlap=True,failed_test_attempts=1,no_new_gpu_run=True,
        end_to_end_improvement_qualified=False,n_correct=None,formal_g1_g2_qualified=False,
        common_reference_frozen=False,table_sha256=digest(table),document_sha256=digest(doc)),out,indent=2)
for path in RAW.glob('*.py'):ast.parse(path.read_text())
verification=OUT/'20261003_d181_verification.json'
with verification.open('x') as out:
    json.dump(dict(passed=True,base_commit=BASE,non_target_serving_ast_unchanged=True,
        byte_identical_files=unchanged,protected=protected,cleanup=cleanup,
        curated_sha256=digest(curated),table_sha256=digest(table),document_sha256=digest(doc)),out,indent=2)
members=sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size<2*1024**2
               and not p.name.startswith('verify1') and p.suffix!='.lock')
extras=[doc,curated,verification,table]+[ROOT/p for p in serving]+[
    ROOT/'tests/test_ieee_tc_identity_recheck.py',ROOT/'tests/test_ieee_tc_request_lifecycle.py',
    ROOT/'tests/test_ieee_tc_request_footprints.py']
hashes={}
bundle=OUT/'20261003_d181_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for path in members+extras:
        name='raw/'+str(path.relative_to(RAW)) if path in members else str(path.relative_to(ROOT))
        hashes[name]=digest(path);tar.add(path,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name,sha in hashes.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha
with (OUT/'20261003_d181_evidence_members.json').open('x') as out:
    json.dump(dict(passed=True,member_sha256=hashes,source_raw_retained_and_bound=True),out,indent=2)
with (OUT/'20261003_d181_evidence.sha256').open('x') as out:out.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    members=len(hashes),bundle_bytes=bundle.stat().st_size,cleanup=cleanup),indent=2))
