"""Retain Full100 outcome; installation evidence is not an update-count witness."""
import collections, hashlib, json, os
from pathlib import Path
import subprocess, sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d528_metadata_full_qualification'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,data):
    with path.open('x') as stream:json.dump(data,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name); group=Path(identity['path'])
save(RAW/'result_identity.json',identity)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
q=read(RAW/'actual_qualification.json')
assert q['passed'] and q['protocol_bound_count']==100 and q['native_tokens']==17369
for ref in q['refs']:assert p.digest(Path(ref['path']))==ref['sha256']
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
run=RAW/'7b_cpu_frontend_validation_100'
outcome_path=run/'launch.launch/physical_deployment/main_outcome.json'
outcome=read(outcome_path)
source=next(run.glob('experiment_results*.json'))
requests=read(source)['detailed_results']['tc_ieee_full']['requests']
owners=outcome['coordination_after_shutdown']['ieee_native_host_budget_owners']
assert len(owners)==2
owner_ids={row['owner_id'] for row in owners}; assert len(owner_ids)==len(owners)
served=collections.Counter(r['gpu_reference_evidence']['receipt']['owner_id'] for r in requests)
assert set(served)==owner_ids and sum(served.values())==100
installation=[]
for owner in owners:
    receipt=owner['receipt']; initial=receipt['metadata_publication']
    assert owner['state']=='retired' and receipt['configured'] and receipt['owner_id']==owner['owner_id']
    assert receipt['worker_pid']==owner['process_identity']['pid']
    assert receipt['tensor_budget_bytes']==2147483648
    assert initial['policy']=='cpu_live_mapping_v1' and initial['installed']
    assert not initial['poisoned'] and not initial['gpu_buffers_replaced']
    assert initial['native_mapping_invalidation_preserved']
    assert (initial['banks'],initial['rows'],initial['slots'],initial['staging_bytes'])==(2,1024,14,99040)
    assert initial['updates']==initial['copied_bytes']==initial['reuse_waits']==0
    before,after=initial['accounted_before_bytes'],initial['accounted_after_bytes']
    assert after-before==99040
    partition=receipt['workspace_partition']
    workspace=partition['registered_upper_bytes']+2*partition['demand_load_peak_bytes']
    assert initial['required_minimum_with_staging_bytes']==before+99040+workspace
    assert after+workspace<=receipt['tensor_budget_bytes'] and receipt['allocation']['admitted']
    assert receipt['allocation']['before']['accounted_tensor_bytes']==after
    installation.append(dict(owner_id=owner['owner_id'],worker_pid=receipt['worker_pid'],
        bound_requests=served[owner['owner_id']],pinned_increment_bytes=after-before,
        tensor_budget_bytes=receipt['tensor_budget_bytes'],installed=True,retired=True,
        final_updates=None,triggered_measured=None))
budget=outcome['coordination_after_shutdown']['ieee_managed_host_budget']
assert budget['limit_bytes']==17179869184 and budget['native_reserved_bytes']==0
old_raw=RAW.parent/'d475_20261012'
previous=read(old_raw/'actual_qualification.json')
previous_source=next((old_raw/'7b_cpu_frontend_validation_100').glob('experiment_results*.json'))
prior={r['request_id']:r for r in read(previous_source)['detailed_results']['tc_ieee_full']['requests']}
assert set(prior)=={r['request_id'] for r in requests}
keys=('adapter_id','scheduled_arrival_offset_s','source_expected_output_tokens','completion_tokens',
      'requested_completion_tokens','canonical_prompt_tokens','input_tokens','completion_token_source')
same_outputs=0
for row in requests:
    old=prior[row['request_id']]
    for key in keys:assert row[key]==old[key],(row['request_id'],key)
    assert row['completion_token_ids_sha256'] and old['completion_token_ids_sha256']
    same_outputs+=row['completion_token_ids_sha256']==old['completion_token_ids_sha256']
comparisons={key:dict(previous=previous['stats'][key],current=q['stats'][key],
    lower_better_relative_change=(previous['stats'][key]-q['stats'][key])/previous['stats'][key])
    for key in ('mean_ttft_ms','p95_ttft_ms','mean_tpot_ms','physical_gpu_seconds')}
record=dict(passed=True,native100_contract_passed=True,installation_accounting_passed=True,
    metadata_use_count_qualified=False,missing_evidence='Full retains installation snapshots only; post-generation update counts not persisted',
    n_correct=None,full4000_qualified=False,performance_ranking_eligible=False,
    installed_workers=installation,global_host_budget=budget,qualification=q,
    matched_input_fields=list(keys),matching_output_token_hashes=same_outputs,
    previous_source=dict(path=str(previous_source),sha256=p.digest(previous_source)),
    outcome=dict(path=str(outcome_path),sha256=p.digest(outcome_path)),
    source=dict(path=str(source),sha256=p.digest(source)),comparison_to_d475=compares if False else comparisons,
    next='Preserve counters in existing completion receipt without extra RPC/barrier; CPU regression then ONE new4000 W0, no repeat100',
    scope=identity)
save(RAW/'result.json',record);save(OUT/'native100_result.json',record)
print(json.dumps(dict(passed=True,installed_workers=installation,matching_output_token_hashes=same_outputs,
    stats=q['stats'],joint_count=q['common_threshold_joint_count'],comparison=comparisons,
    metadata_use_count_qualified=False)),flush=True)
