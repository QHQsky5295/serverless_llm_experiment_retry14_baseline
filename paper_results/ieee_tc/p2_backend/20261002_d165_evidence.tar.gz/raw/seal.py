"""D163 evidence-seal pattern reused for opt-in slot-content qualification."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
BASE = '70029ba3ff68c4914e1d4a08c40b18298758aa56'

def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024**2), b''):
            result.update(block)
    return result.hexdigest()

def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)

assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip() == BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
tests = []
for phase, count in (('targeted1',13), ('regression1',811), ('verify1',72)):
    log = (RAW/f'{phase}.log').read_text()
    elapsed = (RAW/f'{phase}_time.txt').read_text()
    match = re.search(r'Ran (\d+) tests in ([\d.]+)s', log)
    assert match and int(match[1]) == count and '\nOK\n' in log
    assert 'Exit status: 0' in elapsed
    receipt = (RAW/f'{phase}_scope.txt').read_text()
    invocation = re.search(r'^InvocationID=([a-f0-9]{32})$', receipt, re.M)[1]
    cleanup = (RAW/f'{phase}_cleanup.txt').read_text()
    assert f'actual_invocation={invocation}' in cleanup and 'cleanup=automatic_removal_verified' in cleanup
    unit = f'primelora-d165-{phase}-20261002.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'], text=True).strip() == 'inactive'
    assert not subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','--value'], text=True).strip()
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    events = dict(line.split() for line in (RAW/f'{phase}_final_memory_events.txt').read_text().splitlines())
    assert all(int(value) == 0 for value in events.values())
    assert int((RAW/f'{phase}_final_swap.txt').read_text()) == 0
    tests.append(dict(phase=phase,count=count,exit_code=0,body_seconds=float(match[2]),
        maximum_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',elapsed)[1]),
        actual_invocation_id=invocation,cleanup_verified=True,final_memory_events=events,
        final_swap_bytes=0,raw_log_sha256=sha(RAW/f'{phase}.log')))

from scripts.ieee_tc_preflight import verify_seal
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
refs = {
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'): '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md': '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'paper_results/ieee_tc/p2_backend/20261002_d164_7b_full_w0_full1.json': '7076db88971a1a1de7ece273ba82aa8882e7ad92b2cdf32e35d121d105b98bab',
}
for path, expected in refs.items():
    assert sha(path) == expected, path
sources = ['faaslora/memory/gpu_monitor.py','scripts/run_all_experiments.py',
           'scripts/ieee_tc_preflight.py','tests/test_ieee_tc_worker_observation.py',
           'tests/test_ieee_tc_preflight.py']
unchanged = ['faaslora/preloading/planning_cpu.py','faaslora/preloading/preloading_planner.py',
             'faaslora/memory/residency_manager.py','faaslora/experiment/instance_pool.py']
for name in sources+unchanged:
    ast.parse((ROOT/name).read_text())
for name in sources:
    assert f'{sha(ROOT/name)}  {name}' in (RAW/'regression1_sources.sha256').read_text()
for name in unchanged:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git','show',f'{BASE}:{name}'],cwd=ROOT)

# Check every pre-existing function/method outside the explicit opt-in wiring.
allowed = {
    sources[0]: {('IEEEWorkerObservationExtension','ieee_worker_observation')},
    sources[1]: {('InferenceEngine','ieee_worker_observation'),
                 ('SubprocessInferenceEngineProxy','ieee_worker_observation')},
    sources[2]: {('initialize_qualification_runtime',),('backend_model_check',),('main',)},
}
def functions(tree, prefix=()):
    result = {}
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            result[prefix+(node.name,)] = ast.dump(node)
        elif isinstance(node,ast.ClassDef):
            result.update(functions(node,prefix+(node.name,)))
    return result
checked = 0
for name, excluded in allowed.items():
    old = functions(ast.parse(subprocess.check_output(['git','show',f'{BASE}:{name}'],cwd=ROOT)))
    new = functions(ast.parse((ROOT/name).read_text()))
    assert excluded.issubset(old)
    for key, value in old.items():
        if key not in excluded:
            assert new[key] == value, (name,key)
            checked += 1

native_root = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm/lora')
native_sha = {'layers/base_linear.py':'11929fcd89bef08ca7e1e672cf6063c718bce4ba02a2fb8254dada7793a6c5f3',
              'layers/column_parallel_linear.py':'317e651f98f461da3037853d7970297e19f1423a1f04dd14cb151f4ece8a028d',
              'model_manager.py':'6695bb7d6373d8f29bb13d6ae31e2ef2a98f8c23a6f37f9147d67cafca5f3302'}
for name, expected in native_sha.items():
    assert sha(native_root/name) == expected
doc = ROOT/'docs/ieee_tc/D165_NATIVE_SLOT_CONTENT_QUALIFIER.md'
subprocess.run(['git','diff','--check','--',*sources,str(doc)],cwd=ROOT,check=True)
curated = OUT/'20261002_d165_slot_content_qualification.json'
result = dict(kind='d165_slot_content_checker_qualification_v1',base_commit=BASE,
    source_sha256={p:sha(ROOT/p) for p in sources+unchanged},tests=tests,
    protected=protected,frozen_references={str(p):s for p,s in refs.items()},
    installed_native_source_sha256=native_sha, unchanged_functions_checked=checked,
    qualification='CPU_checker_and_negative_controls_only',actual_gpu_slot_audit_completed=False,
    checkpoint_to_registered_qualified=False,per_token_execution_mapping_qualified=False,
    semantic_full_pool_qualification=False,formal_g1_g2_qualified=False,
    warm_reference_completed=False,performance_run_completed=False,
    next='One necessary actual7B isolated slot-content measurement, then remaining numerical/common-reference evidence.',
    caveats=['Test groups overlap; counts are not independent experiments.',
             'Zero weights are output-equivalent; numerical closeness is not identity discrimination.',
             'No serving policy, formula, metric or remote delivery configuration changed.'])
save(curated,result)
csv_path = OUT/'20261002_d165_slot_content_qualification.csv'
with csv_path.open('x',newline='') as handle:
    writer = csv.DictWriter(handle,fieldnames=['phase','count','exit_code','body_seconds','maximum_rss_kib'],lineterminator='\n')
    writer.writeheader()
    writer.writerows({key:row[key] for key in writer.fieldnames} for row in tests)
save(OUT/'20261002_d165_verification.json',dict(pass_=True,document_sha256=sha(doc),
    curated_sha256=sha(curated),csv_sha256=sha(csv_path),protected=protected,
    unchanged_functions_checked=checked,non_diagnostic_source_unchanged=unchanged))
members = sorted(p for p in RAW.iterdir() if p.is_file() and not p.name.startswith('seal1')
                 and p.stat().st_size < 2*1024**2
                 and p.suffix in {'.py','.sh','.log','.txt','.json','.sha256'})
extras = [ROOT/p for p in sources]+[doc,curated,csv_path]
bundle = OUT/'20261002_d165_evidence.tar.gz'
hashes = {}
with tarfile.open(bundle,'x:gz') as tar:
    for p in members+extras:
        name = ('raw/'+p.name) if p in members else str(p.relative_to(ROOT))
        data = p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        hashes[name] = hashlib.sha256(data).hexdigest()
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames()) == set(hashes)
    for name, digest in hashes.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
save(OUT/'20261002_d165_evidence_members.json',dict(member_sha256=hashes,pass_=True))
with (OUT/'20261002_d165_evidence.sha256').open('x') as handle:
    handle.write(sha(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(pass_=True,tests=tests,unchanged_functions_checked=checked,
    curated_sha256=sha(curated),bundle_sha256=sha(bundle),bundle_bytes=bundle.stat().st_size,members=len(hashes)),indent=2))
