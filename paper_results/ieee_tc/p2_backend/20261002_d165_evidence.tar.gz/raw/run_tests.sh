#!/usr/bin/env bash
# Reuse D163's bounded CPU qualification; no model or remote service launch.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in targeted1|regression1|verify1) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d165_20261002
unit="primelora-d165-${phase}-20261002.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sha256sum faaslora/memory/gpu_monitor.py scripts/run_all_experiments.py scripts/ieee_tc_preflight.py tests/test_ieee_tc_worker_observation.py tests/test_ieee_tc_preflight.py > "$raw/${phase}_sources.sha256"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
if test "$phase" = regression1; then
  args=(-m unittest tests.test_ieee_tc_worker_observation tests.test_ieee_tc_gpu_references tests.test_ieee_tc_native_timing tests.test_ieee_tc_native_retirement tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_launch tests.test_basic_smoke -v)
elif test "$phase" = verify1; then
  python=/usr/bin/python3
  args=(-m unittest tests.test_ieee_tc_preflight -v)
else
  args=(-m unittest tests.test_ieee_tc_worker_observation.NativeSlotContentAudit tests.test_ieee_tc_preflight.SlotContentQualification -v)
fi
set +e
/usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/${phase}_final_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/${phase}_final_swap.txt"
exit "$code"
