"""D607: reuse D606 CPU proofs; bind ordinary complete W2 without frame observer."""
import ast, copy, json, os, subprocess, sys
from pathlib import Path
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'qualification2_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='71846add523aa9cc716635df02d604eb6b2310a6'
previous=RAW.parent/'d606_20261017'
for name in ('focused_receipt.json','regression2_receipt.json'):
    reg=read(previous/name);assert reg['passed'] and reg['returncode']==0
    for path,sha in reg['sources'].items():assert p.digest(Path(path))==sha,path
for phase in ('focused','regression2','publication'):
    closed=read(previous/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
storage_view=ROOT/'paper_results/ieee_tc/storage/d604_closed_w2_evidence/summary.json'
assert storage_view.is_file()
gate=p.preflight([ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
old=read(RAW.parent/'d550_20261015/qualification.json')
for path,sha in old['preserved'].items():assert p.digest(Path(path))==sha,path
w2=read(RAW.parent/'d554_20261015/qualification.json')['prime_plan']
plan=FrozenReplayPlan.load(w2['source_path'],profile='W2',adapter_map=w2['adapter_map'],adapter_map_sha256=w2['adapter_map_sha256'])
assert plan.identity()==w2 and len(plan.entries)==4000
assert FrozenReplayPlan.from_launch_context(dict(plan=w2,tiny_witness=False))==plan
paths=[ROOT/'configs/ieee_tc/20261015_d554_7b_initial_control_full_w2.yaml',
       ROOT/'configs/ieee_tc/20261017_d607_7b_canonical_files_full_w2.yaml']
configs=[yaml.safe_load(path.read_text()) for path in paths]
normalized=copy.deepcopy(configs)
for row in normalized:
    row['experiment'].pop('output_dir')
    row['storage'].pop('nvme_cache_dir');row['storage'].pop('host_cache_dir')
assert normalized[0]==normalized[1]
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
body=shell.read_text();start=body.index('  d607)\n');end=body.index('    ;;\n',start)+len('    ;;\n')
branch=body[start:end]
assert paths[1].name in branch and 'PREFIX_COUNT=\n' in branch
restored=(body[:start]+body[end:]).replace(' || "${1:-d293}" == d607','')
assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
helpers=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),shell])
for path in helpers:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    else:subprocess.run(['bash','-n',str(path)],check=True)
observer_line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd328' in line)
assert 'd607' not in observer_line
buildpath=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=read(buildpath);assert build['passed'] and build['actual_closure']['path_gone']
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256']
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
refs=[*helpers,*paths,previous/'focused_receipt.json',previous/'regression2_receipt.json',buildpath,storage_view,
      previous/'focused_closure.json',previous/'regression2_closure.json',previous/'publication_closure.json',
      RAW.parent/'d550_20261015/close.py',
      ROOT/'faaslora/datasets/workload_generator.py',ROOT/'faaslora/scheduling/resource_coordinator.py',
      ROOT/'scripts/run_all_experiments.py',ROOT/'faaslora/utils/logger.py',
      ROOT/'faaslora/memory/residency_manager.py',ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json',
      ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
for key in ('ieee_service_profile','ieee_preparation_profile'):
    ref=configs[1]['resource_coordination'][key];path=Path(ref['path'])
    assert p.digest(path)==ref['sha256'];refs.append(path)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
import torch
assert not torch.cuda.is_initialized()
save(RAW/'qualification.json',dict(passed=True,scope=identity,protected=protected,preserved=old['preserved'],
    prime_plan=plan.identity(),source_count=4000,count=4000,same_configuration_as_d554=True,
    reused_cpu_regression_tests=433,reused_focused_tests=240,reused_input_tests=386,
    observer=None,ordinary_full_replay=True,
    ranking_eligible=False,preflight=gate,refs={str(path):p.digest(path) for path in refs},
    resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,count=4000,profile='W2',reused_tests=433,reused_focused_tests=240,observer=None)))
