"""D680 checkpoint via the existing explicit-path, protected-source publisher."""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'c16bfc285f6b9ed3f14bd46b730b5c37f0a9c52245f0f90e093fa2c23f34c1c4'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, (old, code.count(old))
    code = code.replace(old, new)
replace('d595_parallel_pressure_barrier', 'd680_host_lease_transfer')
code = code.replace('023ae0079e0b2ffa537a81bda7855e8a4b8ede95',
                    'e5ed666d6db27f15a4d951c7023158d30dad6000')
start = code.index("reg=read(RAW/'regression2_receipt.json')")
end = code.index('preserved={', start)
code = code[:start] + '''phases=('qualification','analysis','qualification2','analysis2')
receipts={name:read(RAW/(name+'_receipt.json')) for name in phases}
assert all(receipts[name]['passed'] for name in ('qualification','qualification2','analysis2'))
assert receipts['analysis']['passed'] is False
reg=receipts['analysis2']
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/qhq/serverless_llm_baselines',text=True).strip()=='e16af33aaf41f02a62ecdce59f6f3227813244c3'
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')=='193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d'
# Restore exact earlier source *as evidence*, never overwrite the worktree.
gpu=ROOT/'faaslora/memory/gpu_monitor.py'
current_gpu=gpu.read_text()
begin=current_gpu.index('        def completed_reference_reply(value):')
end=current_gpu.index("        if not hasattr(self, '_ieee_gpu_reference_owner'):",begin)
old_gpu=current_gpu[:begin]+current_gpu[end:]
old_gpu=old_gpu.replace("return completed_reference_reply(copy.deepcopy(cached['receipt']))", "return copy.deepcopy(cached['receipt'])")
finish="""        diagnostic_control_event(diagnostic_id, 'native_ready')
        return {**result, 'clock_id': local_monotonic_clock_id(),
                'native_host_allocator_policy': self._ieee_host_allocator_policy,
                'worker_pid': os.getpid(), 'worker_rank': int(self.rank),
                'completion_fence_scope': 'current_worker_cuda_stream',
                'production_launch_authorized': False}"""
old_gpu=old_gpu.replace('        return completed_reference_reply(result)',finish)
test=ROOT/'tests/test_ieee_tc_hit_host_transaction.py'
current_test=test.read_text()
begin=current_test.index('    def test_worker_capacity_witness_transfers_and_replays_complete_ack(self):')
end=current_test.index('    def test_host_without_source_identity_keeps_full_walks(self):',begin)
old_test=current_test[:begin]+current_test[end:]
versions={}
for phase,receipt in receipts.items():
    assert p.digest(RAW/(phase+'.log'))==receipt['log_sha256']
    for path,sha in receipt['source_sha256'].items():
        content=Path(path).read_text()
        if phase in ('qualification','analysis') and path==str(gpu):content=old_gpu
        if phase=='qualification' and path==str(test):content=old_test
        raw=content.encode()
        assert hashlib.sha256(raw).hexdigest()==sha,(phase,path,'source reconstruction mismatch')
        versions[str(Path(phase)/Path(path).relative_to(ROOT))]=raw
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
    assert closed['resources']['memory.swap.current']=='0'
    events=dict(line.split() for line in closed['resources']['memory.events'].splitlines())
    assert all(events[key]=='0' for key in ('high','max','oom','oom_kill'))
assert 'Ran 526 tests' in (RAW/'qualification.log').read_text()
assert 'Ran 72 tests' in (RAW/'qualification2.log').read_text()
assert 'Ran 527 tests' in (RAW/'analysis2.log').read_text()
failed=(RAW/'analysis.log').read_text()
assert 'FAILED (failures=1)' in failed and 'self.assertEqual(replay, result)' in failed
assert 'clock_id' in failed
for phase in ('qualification','qualification2','analysis2'):
    assert '\\nOK\\n' in (RAW/(phase+'.log')).read_text()
''' + code[end:]
start = code.index('members=[RAW/name')
end = code.index('\nfor path in members:', start)
code = code[:start] + '''import io
with tarfile.open(RAW/'source_versions.tar.gz','x:gz') as bundle:
    for name,raw in sorted(versions.items()):
        secret_check(raw)
        info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0
        bundle.addfile(info,io.BytesIO(raw))
with tarfile.open(RAW/'source_versions.tar.gz') as bundle:
    for name,raw in versions.items():assert bundle.extractfile(name).read()==raw
members=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log'),RAW/'source_versions.tar.gz'])
assert sum(path.stat().st_size for path in members)<8*1024*1024''' + code[end:]
replace("for name in ('focused','regression2')}", "for name in phases}")
replace("policy='parallel_owner_barrier_v1'", "policy='same_owner_host_to_gpu_v1'")
replace('focused_before_metadata=focused,aborted_cpu_regression=stopped,protected=protected,',
        'qualification_receipts=receipts,protected=protected,')
start = code.index("names=['faaslora/scheduling/resource_coordinator.py'")
end = code.index('\nnames +=', start)
code = code[:start] + "names=[str(Path(path).relative_to(ROOT)) for path in reg['source_sha256']]\nnames += ['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D680_HOST_LEASE_TRANSFER.md']" + code[end:]
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: qualify same-owner HOST-to-GPU lease transfer and complete replay identity (D680)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D680 checked publisher expansion; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no args or --check-only')
