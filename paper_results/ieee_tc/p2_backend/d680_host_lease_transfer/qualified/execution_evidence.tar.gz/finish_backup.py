"""Complete D680 publication after singular '1 test' parsing failure; no retest."""
import ast
import hashlib
from pathlib import Path
source = Path(__file__).with_name('backup.py')
tree = ast.parse(source.read_text())
assert isinstance(tree.body[-1], ast.If)
tree.body.pop()
env = {'__file__': __file__, '__name__': '__d680_checked_expansion__'}
exec(compile(tree, str(source), 'exec'), env)
code = env['code']
code = code.replace('d680_host_lease_transfer', 'd680_host_lease_transfer/qualified')
code = code.replace("RAW/'backup_identity.json'", "RAW/'publication_identity.json'")
code = code.replace("RAW/'backup_gate.json'", "RAW/'publication_gate.json'")
code = code.replace("RAW/'backup_receipt.json'", "RAW/'publication_receipt.json'")
old = "re.search(r'Ran (\\d+) tests',"
assert code.count(old) == 1
code = code.replace(old, "re.search(r'Ran (\\d+) tests?',")
start = code.index("with tarfile.open(RAW/'source_versions.tar.gz','x:gz')")
end = code.index("with tarfile.open(RAW/'source_versions.tar.gz') as bundle:", start)
code = code[:start] + code[end:]  # Verify the sealed archive; never overwrite it.
code = code.replace("preserved={ROOT/", """previous=read(RAW/'backup_closure.json')
assert previous['passed'] and previous['actual_recursive_procs_empty'] and previous['path_gone']
assert not Path(previous['identity']['path']).exists()
assert not (RAW/'backup_receipt.json').exists()
preserved={ROOT/""")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
