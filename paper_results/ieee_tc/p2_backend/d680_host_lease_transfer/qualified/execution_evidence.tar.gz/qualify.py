"""D680: extend existing bounded CPU qualification, no GPU performance run."""
import ast
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d663_20261018/qualify.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '1cfd5d94227448d349d837b613283b03d85a28f3069e74fa118ef531b952eeea'
code = data.decode()
code = code.replace("assert phase in ('qualification', 'qualification2', 'analysis')",
    "assert phase in ('qualification', 'qualification2', 'analysis', 'analysis2')")
start = code.index("paths = ['faaslora/memory/gpu_monitor.py'")
end = code.index('log = RAW/', start)
code = code[:start] + """paths = ['faaslora/memory/gpu_monitor.py', 'faaslora/memory/residency_manager.py',
    'faaslora/scheduling/vllm_ieee_scheduler.py', 'scripts/run_all_experiments.py',
    'tests/test_ieee_tc_hit_host_transaction.py', 'tests/test_ieee_tc_request_lifecycle.py',
    'tests/test_ieee_tc_scheduler_observation.py']
for path in paths:
    ast.parse((MAIN/path).read_text())
tests = ['tests.test_ieee_tc_hit_host_transaction.HitHostTransaction',
    'tests.test_ieee_tc_gpu_references', 'tests.test_ieee_tc_worker_observation',
    'tests.test_ieee_tc_request_lifecycle', 'tests.test_ieee_tc_scheduler_observation',
    'tests.test_ieee_tc_pending_gpu_pipeline']
if phase == 'qualification2':
    tests = ['tests.test_ieee_tc_hit_host_transaction.HitHostTransaction',
        'tests.test_ieee_tc_hit_host_transaction.NativeHostActivationWitness',
        'tests.test_ieee_tc_request_lifecycle.SelectedSourceAdmissionIntegration']
elif phase == 'analysis':
    tests = ['tests.test_ieee_tc_hit_host_transaction.HitHostTransaction.test_worker_capacity_witness_transfers_and_replays_complete_ack']
""" + code[end:]
ast.parse(code)
exec(compile(code, str(source), 'exec'))
