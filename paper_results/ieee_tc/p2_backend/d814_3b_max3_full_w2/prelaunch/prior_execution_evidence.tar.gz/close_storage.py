"""Reuse actual empty/removed storage-scope verification for D813."""
from pathlib import Path

_template = Path(__file__).resolve().parent.parent/'d812_20261024/close_storage.py'
_source = _template.read_text()
assert '20261025_d812_closed_outcome_verification.json' in _source
_source = _source.replace('20261025_d812_closed_outcome_verification.json',
    '20261025_d813_closed_outcome_verification.json')
exec(compile(_source, str(_template), 'exec'), globals())
