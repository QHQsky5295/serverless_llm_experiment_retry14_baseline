"""Reuse D659 sealed publication checks; keep D664 prelaunch files immutable."""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d659_20261018/publish.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'e34668af9152224ab85f37d21c097362dc66222c8c4fd6e7daa525cc4c159bfb'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d659_3b_full_smoke100'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d664_3b_full_smoke100/completion'")
replace("expected_head='8a30f65fbeeeb8b79e83ad40c4d388a6a080b525'",
        "expected_head='76041a4484f4d22f5f54c30693e46a0076cd5c68'")
replace("assert audit['passed'] and audit['protocol_bound_count']==100",
        "assert audit['passed'] and audit['protocol_bound_count']==100\nassert audit['host_transaction']['passed'] and len(audit['host_transaction']['request_ids'])==21")
start = code.index("previous=RAW.parent/'d658_20261018'")
end = code.index("save(OUT/'manifest.json'", start)
code = code[:start] + '''prelaunch=OUT.parent
assert p.digest(prelaunch/'result.sha256')=='d411cd99730464ae8a7f6625f158ddfc6137427f8c9bb2b4926e4b0b58717f45'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=prelaunch,check=True,stdout=subprocess.DEVNULL)
for phase in ('qualification','backup'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
members += [RAW/name for name in ('backup_identity.json','backup_receipt.json','backup_closure.json')]
''' + code[end:]
replace("kind='d659_3b_prefix100_seal_v1'", "kind='d664_3b_host_transaction_prefix100_seal_v1'")
replace("n_native_bound=100,joint_slo_count=audit['common_threshold_joint_count'],",
        "n_native_bound=100,joint_slo_count=audit['common_threshold_joint_count'],\n    host_transaction=audit['host_transaction'],\n    immutable_prelaunch_manifest_sha256=p.digest(prelaunch/'result.sha256'),\n    reused_publication_helper=dict(path=str(source),sha256=hashlib.sha256(data).hexdigest()),")
replace('docs/ieee_tc/D659_3B_FULL_PREFIX_QUALIFICATION.md',
        'docs/ieee_tc/D664_3B_HOST_TRANSACTION_NATIVE_QUALIFICATION.md')
replace('tc: seal current 3B Full native prefix qualification and SLO limits (D659)',
        'tc: seal native HOST transaction qualification without overwriting prelaunch (D664)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D664 completion publication adaptation parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no args or --check-only')
