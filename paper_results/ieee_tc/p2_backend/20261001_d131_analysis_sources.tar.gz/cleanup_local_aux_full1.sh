#!/usr/bin/env bash
set -euo pipefail
# Reuse D131 exact-identity / empty-domain cleanup; only D131 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-a2f8a035386d4d65b9eb4a5fb32dc837.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-4e3970affbb14df2a5f7c0213e32cd5d.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = cab10eb83a9e447cb44ff32762983cac
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-4e3970affbb14df2a5f7c0213e32cd5d.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
