#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d131_20261001
alias=primelora-artifact-174
journal=/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-62aac73cdcde40a69723b65b6703ffdd.jsonl
monitor=/home/lab14/primelora_remote/tc/d131_20261001/remote_monitor_7b_full_full1.log
test "$(systemctl --user show primelora-tc-svc-a2f8a035386d4d65b9eb4a5fb32dc837.scope -p ActiveState --value)" = inactive
test -s "$raw/stop_services_full1.log"
test ! -e "$raw/remote_7b_full1_transfers.jsonl"
test ! -e "$raw/remote_monitor_full1_final.log"
test ! -e "$raw/remote_copy_receipt.txt"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "head -n 1 '$journal'" |
  jq -e '.clock_id == "remote-process-monotonic:7f9e4919132b479697d1fd6c71147056"'
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "sha256sum '$journal' '$monitor'" > "$raw/remote_copy_receipt.txt"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$journal" "$raw/remote_7b_full1_transfers.jsonl"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$monitor" "$raw/remote_monitor_full1_final.log"
read -r expected_journal _ < "$raw/remote_copy_receipt.txt"
expected_monitor=$(sed -n '2s/ .*//p' "$raw/remote_copy_receipt.txt")
actual_journal=$(sha256sum "$raw/remote_7b_full1_transfers.jsonl" | cut -d' ' -f1)
actual_monitor=$(sha256sum "$raw/remote_monitor_full1_final.log" | cut -d' ' -f1)
test "$actual_journal" = "$expected_journal"
test "$actual_monitor" = "$expected_monitor"
sha256sum "$raw/remote_7b_full1_transfers.jsonl" "$raw/remote_monitor_full1_final.log"
