#!/usr/bin/env bash
# Reuse D113 analyzer/guarded CPU-only workflow; no GPU replay.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d131_20261001
source=results/ieee_tc/p2_backend_qualification/d131_20261001
unit=primelora-d131-occupancy1-20261001.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show primelora-d131-full1-curate-20261001.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/scope_before1.txt"
export PYTHONUNBUFFERED=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
/usr/bin/time -v -o "$raw/audit_time1.txt" "$python" scripts/analyze_control_path_overhead.py \
  --native-timeline --allow-failed --input "$source/full_full1_request_projection.json" \
  --deployment "$source/7b_full_w0_full1/launch.launch/physical_deployment/deployment.json" \
  --terminals "$source/7b_full_w0_full1/launch.launch/physical_deployment/request_terminals.jsonl" \
  --watchdog "$source/7b_full_w0_full1/launch.launch/watchdog.jsonl" \
  --control-outcome "$source/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json" \
  --output paper_results/ieee_tc/p2_backend/20261001_d131_control_occupancy > "$raw/audit_result1.log"
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
