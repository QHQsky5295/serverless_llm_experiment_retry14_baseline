"""D206: adapt D205 bounded qualification sealing, preserving both source versions."""
import ast
import csv
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path
from scripts.ieee_tc_preflight import ROOT, check_plan, digest, verify_seal

raw = ROOT/'results/ieee_tc/p2_backend_qualification/d206_20261003'
base = ROOT/'paper_results/ieee_tc/p2_backend'
doc = ROOT/'docs/ieee_tc/D206_NATIVE_EXECUTION_OBSERVER.md'
scopes = {}
for phase, testcount in [('tests1', 494), ('tests2', 496)]:
    receipt = dict(line.split('=', 1) for line in (raw/f'{phase}_scope.txt').read_text().splitlines())
    assert receipt['InvocationID'] and receipt['MemoryHigh'] == '3221225472'
    assert receipt['MemoryMax'] == '4294967296' and receipt['MemorySwapMax'] == '0'
    assert not Path('/sys/fs/cgroup'+receipt['ControlGroup']).exists()
    assert not subprocess.check_output(['systemctl', '--user', 'show',
        f'primelora-d206-{phase}-20261003.scope', '-p', 'InvocationID', '--value'], text=True).strip()
    assert 'Exit status: 0' in (raw/f'{phase}_time.txt').read_text()
    assert all(line.split()[1] == '0' for line in (raw/f'{phase}_memory_events.txt').read_text().splitlines())
    assert (raw/f'{phase}_swap.txt').read_text().strip() == '0'
    assert int((raw/f'{phase}_memory_peak.txt').read_text()) <= 4 * 1024**3
    log = (raw/f'{phase}.log').read_text()
    assert f'Ran {testcount} tests' in log and '\nOK\n' in log
    for position in ('before', 'after'):
        seal = json.loads((raw/f'{phase}_protected_{position}.json').read_text())
        assert seal['kind'] == 'protected_artifact_verification' and seal['pass']
    scopes[phase] = dict(receipt, exitcode=0, test_count=testcount, released=True)
subprocess.run(['sha256sum', '-c', str(raw/'tests2_sources.sha256')], cwd=ROOT,
               check=True, stdout=subprocess.DEVNULL)
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
                                  '--format=csv,noheader'], text=True).strip()

def without_docstring(node):
    if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant):
        node.body.pop(0)

allowed = {
    'faaslora/memory/gpu_monitor.py': ['IEEEWorkerObservationExtension'],
    'scripts/run_all_experiments.py': ['InferenceEngine', 'SubprocessInferenceEngineProxy'],
}
for name, classes in allowed.items():
    previous = ast.parse(subprocess.check_output(['git', 'show', 'HEAD:'+name], text=True))
    current = ast.parse((ROOT/name).read_text())
    if name.endswith('gpu_monitor.py'):
        new = [n for n in current.body if isinstance(n, ast.ClassDef)
               and n.name == '_IEEENativeExecutionObserver']
        assert len(new) == 1
        current.body.remove(new[0])
    for tree in (previous, current):
        for node in tree.body:
            if isinstance(node, ast.ClassDef) and node.name in classes:
                without_docstring(node)
                matches = [n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                           and n.name == 'ieee_worker_observation']
                assert len(matches) == 1
                node.body.remove(matches[0])
    assert ast.dump(previous) == ast.dump(current), name
unchanged = ['scripts/ieee_tc_preflight.py', 'faaslora/memory/residency_manager.py',
    'faaslora/preloading/preloading_planner.py', 'faaslora/experiment/instance_pool.py',
    'scripts/dedicated_engine_worker.py']
for name in unchanged:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git', 'show', 'HEAD:'+name])
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protection = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protection['pass']
for name in ('curate.py', 'check_staged.py'):
    compile((raw/name).read_bytes(), str(raw/name), 'exec')
for name in allowed:
    compile((ROOT/name).read_bytes(), name, 'exec')
subprocess.run(['bash', '-n', str(raw/'run_cpu.sh')], check=True)
text = doc.read_text()
for expected in ('494/494', '496/496', '14/14', '20.416', 'n_correct=null'):
    assert expected in text

prior = json.loads((ROOT/'paper_results/ieee_tc/p2_backend/20261003_d205_execution_metadata.json').read_text())
sources = prior['sources']
for source in sources:
    assert digest(Path(source['path'])) == source['sha256']
extra = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm/forward_context.py')
sources = sources + [dict(path=str(extra), sha256=digest(extra),
    upstream_url='https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/vllm/forward_context.py')]
rows = [dict(check=phase, tests=value['test_count'], passed=True, evidence='CPU fixture regression',
             gpu_qualified=False, numeric_qualified=False) for phase, value in scopes.items()]
summary = dict(kind='d206_execution_observer_cpu_qualification_v1', passed=True,
    sources=sources, scopes=scopes, new_tests=14, summary=rows,
    parent_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    plan_sha256=check_plan(), default_performance_hook_installed=False,
    gpu_measurement=False, graph_replay_qualified=False, numerical_correctness_qualified=False,
    n_correct=None, observer_bridge_to_existing_prefix_pending=True)
with (base/'20261003_d206_execution_observer.json').open('x') as output:
    json.dump(summary, output, indent=2)
with (base/'20261003_d206_execution_observer.csv').open('x', newline='') as output:
    writer = csv.DictWriter(output, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

members = [(raw/name, name) for name in ('run_cpu.sh', 'curate.py', 'check_staged.py')]
for phase in scopes:
    for suffix in ('scope.txt', 'time.txt', 'memory_events.txt', 'swap.txt', 'memory_peak.txt',
                   'protected_before.json', 'protected_after.json', 'sources.sha256', 'sources.tar.gz'):
        members.append((raw/f'{phase}_{suffix}', f'{phase}_{suffix}'))
    members.append((raw/f'{phase}.log', f'{phase}.log'))
for name in (*allowed, 'tests/test_ieee_tc_worker_observation.py',
             'docs/ieee_tc/D206_NATIVE_EXECUTION_OBSERVER.md'):
    members.append((ROOT/name, name))
for source in sources:
    path = Path(source['path'])
    rel = path.relative_to('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages')
    members.append((path, 'installed_source/'+str(rel)))
bundle = base/'20261003_d206_analysis_sources.tar.gz'
hashes = {}
with tarfile.open(bundle, 'x:gz') as archive:
    for path, name in members:
        # Existing 1.19MB runner, not a raw experiment log; bounded 2MiB/member.
        assert name not in hashes and path.is_file() and path.stat().st_size < 2 * 1024**2
        hashes[name] = digest(path)
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(bundle, 'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, sha in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == sha
with (base/'20261003_d206_analysis_sources.sha256').open('x') as file:
    file.write(digest(bundle)+'  '+bundle.name+'\n')
with (base/'20261003_d206_analysis_sources_members.json').open('x') as file:
    json.dump(dict(bundle=bundle.name, member_sha256=hashes, member_checks_pass=True), file, indent=2)
artifacts = [base/f'20261003_d206_execution_observer.{ext}' for ext in ('json', 'csv')] + [doc, bundle]
result = dict(kind='d206_execution_observer_evidence_verification_v1', passed=True,
    plan_sha256=check_plan(), protection=protection, scope_receipts=scopes,
    changed_runtime_only_observer_and_three_opt_in_rpcs=True, unchanged_sources=unchanged,
    tests_final=496, new_tests=14, failed_tests=0, syntax_smoke=True,
    gpu_measurement=False, numeric_correctness_qualified=False, n_correct=None,
    bundle_members=len(hashes), bundle_bytes=bundle.stat().st_size,
    artifacts={str(path.relative_to(ROOT)): digest(path) for path in artifacts})
with (base/'20261003_d206_evidence_verification.json').open('x') as file:
    json.dump(result, file, indent=2)
print(json.dumps(result))
