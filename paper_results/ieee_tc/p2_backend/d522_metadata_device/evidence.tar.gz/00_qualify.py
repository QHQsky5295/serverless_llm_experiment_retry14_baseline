"""Reuse bounded CPU qualification: source identity + native CPU oracle, no GPU."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
import urllib.request

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
PUB = ROOT / 'paper_results/ieee_tc/p2_backend/d522_metadata_device'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def main():
    own = p.scope_identity(p.cg_path().name)
    save(RAW / 'cpu_identity.json', own)
    group = Path(own['path'])
    assert (group / 'memory.high').read_text().strip() == str(3 * p.GIB)
    assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
    assert (group / 'memory.swap.max').read_text().strip() == '0'
    assert os.sched_getaffinity(0) == {2, 3, 26, 27}
    assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
    assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    assert p.preflight([ROOT], p.GIB)['preflight_pass']
    assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
    assert protected['pass'] and protected['entry_count'] == 147
    assert p.digest(ROOT / 'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
    subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
    sources = json.loads((ROOT / 'results/ieee_tc/p2_backend_qualification/d520_20261014/source_identity.json').read_text())
    assert all(p.digest(Path(item['path'])) == item['sha256'] and item['byte_equal'] for item in sources)
    save(RAW / 'source_identity.json', sources)
    import yaml
    device = json.loads((RAW / 'device2.json').read_text())
    assert device['pass'] and len(device['cases']) == 10
    assert all(r['metadata_equal'] and r['eager_equal'] and r['captured_graph_equal'] for r in device['cases'])
    assert len(device['publication']) == 2 and all(r['exact_queued_output_match'] and r['queued_graph_replays'] == 32 for r in device['publication'])
    for tag in ('device1', 'device2'):
        closure = json.loads((RAW / (tag + '_closure.json')).read_text())
        assert closure['passed'] and closure['service_path_gone'] and closure['auxiliary_path_gone']
        assert not Path(closure['service_identity']['path']).exists()
        assert not Path(closure['auxiliary_identity']['path']).exists()
    config_new = ROOT / 'configs/ieee_tc/20261014_d523_7b_cpu_frontend_validation_100.yaml'
    config_old = ROOT / 'configs/ieee_tc/20261012_d475_7b_cpu_frontend_validation_100.yaml'
    left, right = [yaml.safe_load(path.read_text()) for path in (config_old, config_new)]
    assert right['model'].pop('ieee_lora_metadata_policy') == 'cpu_live_mapping_v1'
    for config in (left, right):
        config['experiment'].pop('output_dir')
        config['storage'].pop('nvme_cache_dir')
        config['storage'].pop('host_cache_dir')
    assert left == right
    subprocess.run(['bash', '-n', str(ROOT / 'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh')], check=True)
    compile((ROOT / 'scripts/ieee_tc_preflight.py').read_text(), 'ieee_tc_preflight.py', 'exec')
    with (RAW / 'cpu_tests.log').open('x') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromNames([
                'tests.test_ieee_tc_worker_observation', 'tests.test_ieee_tc_gpu_references',
                'tests.test_ieee_tc_lora_metadata_publication', 'tests.test_basic_smoke']))
    import torch
    assert not torch.cuda.is_initialized()
    qualification = dict(passed=result.wasSuccessful() and not result.skipped,
                         tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                         skipped=len(result.skipped), sources=sources, protected=protected,
                         serving_integration=True, gpu_qualified=False, performance_qualified=False,
                         cuda_initialized=False, native_dma_qualified=False, scope=own,
                         prior_device_qualification_sha256=p.digest(RAW/'device2.json'),
                         device_qualification_not_cpu_test=True, non_target_config_equal=True,
                         refs={str(ROOT / name):p.digest(ROOT / name) for name in (
                             'faaslora/utils/lora_metadata.py', 'faaslora/memory/lora_metadata_publication.py',
                             'faaslora/memory/gpu_monitor.py', 'tests/test_ieee_tc_lora_metadata_publication.py',
                             'tests/test_ieee_tc_gpu_references.py', 'tests/test_ieee_tc_worker_observation.py',
                             'scripts/ieee_tc_preflight.py', 'configs/ieee_tc/20261014_d523_7b_cpu_frontend_validation_100.yaml',
                             'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh', 'scripts/run_all_experiments.py', 'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
                             'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')})
    save(RAW / 'cpu_result.json', qualification)
    if not qualification['passed']:
        raise RuntimeError('CPU qualification failed; preserve attempt')
    PUB.mkdir(parents=True, exist_ok=False)
    save(PUB / 'cpu_qualification.json', qualification)
    assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
    print(json.dumps(dict(passed=True, tests=result.testsRun, native_dma_qualified=False, gpu=False)))


if __name__ == '__main__':
    main()
