"""Reuse exact-identity empty-scope closure for the guarded device test."""
import json
from pathlib import Path
import subprocess
import sys
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
tag = sys.argv[1]
assert tag in ('device1', 'device2')
launch = json.loads((RAW / (tag + '_launch.json')).read_text())
receipt = json.loads((RAW / (tag + '_launch.launch/exec_receipt.json')).read_text())
assert not Path(receipt['service_identity']['path']).exists()
identity = p.scope_identity(Path(receipt['auxiliary_path']).name)
group = Path(identity['path'])
members = {str(path):path.read_text().split() for path in group.rglob('cgroup.procs')}
assert members and all(not values for values in members.values())
resources = {key:(group / key).read_text().strip() for key in ('memory.peak', 'memory.events', 'memory.swap.current')}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl', '--user', 'stop', identity['unit']], check=True)
assert not group.exists()
with (RAW / (tag + '_closure.json')).open('x') as stream:
    json.dump(dict(passed=True, auxiliary_identity=identity, auxiliary_actual_recursive_procs_empty=True,
        auxiliary_path_gone=True, service_path_gone=True, service_identity=receipt['service_identity'],
        resources=resources, launch_sha256=p.digest(RAW / (tag + '_launch.json')),
        source_sha256=p.digest(Path(__file__))), stream, indent=2)
print(json.dumps(dict(passed=True, tag=tag, resources=resources)))
