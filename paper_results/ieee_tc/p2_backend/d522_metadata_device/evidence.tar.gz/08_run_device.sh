#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d522_20261014
CACHE=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/model_20260926/candidate_cache
cd "${MAIN}"
# D522 bounded device metadata arithmetic diagnostic, not a performance result.
unset FAASLORA_REMOTE_ARTIFACT_ENABLED FAASLORA_REMOTE_ARTIFACT_ENDPOINT
unset FAASLORA_REMOTE_ARTIFACT_DELIVERY_MODE PRIME_REMOTE_TOKEN
test ! -e "${RAW}/device1_launch.json"
test ! -e "${RAW}/device1.json"
/usr/bin/python3 scripts/ieee_tc_preflight.py verify --seal results/ieee_tc/slora_qualification/d435_20261011/protected_before.json > "${RAW}/device1_protected_before.json"
sha256sum faaslora/memory/gpu_monitor.py scripts/run_all_experiments.py scripts/ieee_tc_preflight.py faaslora/memory/lora_metadata_publication.py > "${RAW}/device1_sources.sha256"
# Restore the already-qualified 7B compiler environment; do not change the backend.
export PATH="/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin:${PATH}"
export CUDA_HOME=/usr/local/cuda-13.0
export FLASHINFER_NVCC=/usr/local/cuda-13.0/bin/nvcc
export MAX_JOBS=2
export CUDA_VISIBLE_DEVICES=0
command -v ninja
ninja --version
export FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY=uncached_background_v1
export PYTORCH_ALLOC_CONF=pinned_max_cached_size_mb:0,pinned_use_background_threads:True
export VLLM_CACHE_ROOT="${CACHE}"
export TRITON_CACHE_DIR="${CACHE}/triton"
export TORCHINDUCTOR_CACHE_DIR="${CACHE}/inductor"
exec systemd-run --user --scope --collect --unit=primelora-tc-aux-d5220000000000000000000000000001.scope \
  -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 \
  taskset -c 2,3,26,27 env \
  FAASLORA_TC_NVML_BINDING=/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py \
  FAASLORA_TC_NVML_SHA256=4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea \
  PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 \
  HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 VLLM_NO_USAGE_STATS=1 \
  /usr/bin/python3 "${MAIN}/scripts/ieee_tc_preflight.py" gated-launch \
  --output "${RAW}/device1_launch.json" --predicted-growth-gib 2 \
  --exec /home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python \
  "${MAIN}/scripts/ieee_tc_preflight.py" backend-metadata-check \
  --runtime-receipt "${MAIN}/results/ieee_tc/p2_backend_qualification/runtime_20260926/cuda_import_attempt3.json" \
  --output "${RAW}/device1.json"

