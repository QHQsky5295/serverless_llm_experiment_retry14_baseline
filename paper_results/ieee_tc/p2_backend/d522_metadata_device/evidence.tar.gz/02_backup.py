"""D519 explicit-path tested backup reused for D521's CPU-only candidate."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
PUB = ROOT / 'paper_results/ieee_tc/p2_backend/d522_metadata_device'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def main():
    own = p.scope_identity(p.cg_path().name)
    save(RAW / 'backup_identity.json', own)
    group = Path(own['path'])
    assert (group / 'memory.high').read_text().strip() == str(3*p.GIB)
    assert (group / 'memory.max').read_text().strip() == str(4*p.GIB)
    assert (group / 'memory.swap.max').read_text().strip() == '0'
    assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
    assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    assert p.preflight([ROOT], p.GIB)['preflight_pass']
    parent = '0bad961c2d0f15eb5360752e5658a3ed2a933598'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == parent
    assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    assert p.digest(ROOT/'docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D519.md') == 'e0ed5415b779effec429b48ea716abde2e3e9b1a379d5abbc11073cdca2f3a99'
    qualification = read(PUB/'cpu_qualification.json')
    assert qualification['passed'] and qualification['tests'] == 521
    assert (qualification['failures'], qualification['errors'], qualification['skipped']) == (0, 0, 0)
    assert qualification['serving_integration'] and not qualification['gpu_qualified']
    assert qualification['native_dma_qualified'] is False
    for path, sha in qualification['refs'].items():
        assert p.digest(Path(path)) == sha, path
    for item in qualification['sources']:
        assert item['byte_equal'] and p.digest(Path(item['path'])) == item['official_sha256']
    closure = read(RAW/'cpu_closure.json')
    assert closure['passed'] and closure['actual_recursive_procs_empty']
    assert not Path(closure['identity']['path']).exists()
    failed = read(RAW/'device1.json')
    device = read(RAW/'device2.json')
    assert not failed['pass'] and failed['cases'] == [] and failed['error_type'] == 'ModuleNotFoundError'
    assert device['pass'] and len(device['cases']) == 10
    assert all(r['metadata_equal'] and r['eager_equal'] and r['captured_graph_equal'] for r in device['cases'])
    assert len(device['publication']) == 2 and all(r['exact_queued_output_match'] and r['queued_graph_replays'] == 32 for r in device['publication'])
    for tag in ('device1', 'device2'):
        closed = read(RAW/(tag+'_closure.json'))
        assert closed['passed'] and closed['auxiliary_actual_recursive_procs_empty']
        assert not Path(closed['service_identity']['path']).exists()
        assert not Path(closed['auxiliary_identity']['path']).exists()
    launch = read(RAW/'device2_launch.json')
    assert launch['pass'] and launch['service_returncode'] == launch['watchdog_returncode'] == 0
    assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
    protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
    assert protected['pass'] and protected['entry_count'] == 147
    preserved = {
        ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
        BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
        BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
    for path, sha in preserved.items():
        assert p.digest(path) == sha
    token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
    def secrets(data):
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}', data)
    source_paths = [RAW/name for name in ('qualify.py', 'close.py', 'backup.py', 'cpu_identity.json',
        'cpu_tests.log', 'source_identity.json', 'cpu_result.json', 'cpu_closure.json',
        'run_device.sh', 'run_device2.sh', 'close_device.py',
        'device1.json', 'device2.json', 'device1_launch.json', 'device2_launch.json',
        'device1_closure.json', 'device2_closure.json', 'device1_sources.sha256', 'device2_sources.sha256')]
    source_paths += [RAW/(tag+'_launch.launch')/name for tag in ('device1', 'device2')
                     for name in ('service.log', 'exec_receipt.json')]
    source_paths += [Path(item['path']) for item in qualification['sources']]
    members = {}
    with tarfile.open(PUB/'evidence.tar.gz', 'x:gz') as archive:
        for index, path in enumerate(source_paths):
            data = path.read_bytes()
            assert len(data) < 2*1024**2
            secrets(data)
            name = f'{index:02d}_' + path.name
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mtime = 0
            archive.addfile(item, io.BytesIO(data))
            members[name] = dict(source=str(path), sha256=hashlib.sha256(data).hexdigest())
    with tarfile.open(PUB/'evidence.tar.gz', 'r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        for name, ref in members.items():
            assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == ref['sha256']
    save(PUB/'manifest.json', dict(kind='bounded_metadata_cuda_qualification_not_full_model_v1',
        initial_failed_attempt=failed, device=device, device_launch=launch,
        device_closures=[read(RAW/(tag+'_closure.json')) for tag in ('device1','device2')],
        next='D523 original100 Full native installation/HOST qualification',
        qualification_sha256=p.digest(PUB/'cpu_qualification.json'), protected=protected,
        preserved={str(path):sha for path,sha in preserved.items()}, cpu_closure=closure,
        archive_members=members, archive_sha256=p.digest(PUB/'evidence.tar.gz'),
        previous_status_archive_sha256=p.digest(ROOT/'docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D519.md')))
    paths = ['faaslora/memory/gpu_monitor.py', 'scripts/ieee_tc_preflight.py',
             'tests/test_ieee_tc_worker_observation.py',
             'configs/ieee_tc/20261014_d523_7b_cpu_frontend_validation_100.yaml',
             'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
             'docs/ieee_tc/D522_METADATA_DEVICE_QUALIFICATION.md', 'docs/ieee_tc/EXECUTION_STATUS.md']
    paths += [str(path.relative_to(ROOT)) for path in sorted(PUB.iterdir())]
    assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT, text=True).strip()
    subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
    for name in paths:
        data = (ROOT/name).read_bytes()
        secrets(data)
        assert len(data) < 2*1024**2
    subprocess.run(['git', 'add', '--', *paths], cwd=ROOT, check=True)
    assert set(subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT, text=True).splitlines()) == set(paths)
    for name in paths:
        data = subprocess.check_output(['git', 'show', ':'+name], cwd=ROOT)
        secrets(data)
        assert hashlib.sha256(data).hexdigest() == p.digest(ROOT/name)
    subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, check=True)
    subprocess.run(['git', 'commit', '-m', 'tc: qualify metadata CUDA arithmetic and prepare native integration check (D522)'], cwd=ROOT, check=True)
    subprocess.run(['git', 'push', 'faaslora_origin', 'retry14_continuous_queue_v2'], cwd=ROOT, check=True)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    remote = subprocess.check_output(['git', 'ls-remote', 'faaslora_origin', 'refs/heads/retry14_continuous_queue_v2'], cwd=ROOT, text=True).split()[0]
    assert head == remote
    save(RAW/'backup_receipt.json', dict(passed=True, head=head, remote=remote, paths=paths,
        identity=own, manifest_sha256=p.digest(PUB/'manifest.json'),
        resources={key:(group/key).read_text().strip() for key in ('memory.peak', 'memory.events', 'memory.swap.current')}))
    print(json.dumps(dict(passed=True, head=head, files=len(paths))))


if __name__ == '__main__':
    main()
