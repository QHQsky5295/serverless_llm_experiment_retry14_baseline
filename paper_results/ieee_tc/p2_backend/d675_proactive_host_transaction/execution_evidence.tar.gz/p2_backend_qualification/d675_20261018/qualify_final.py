"""Keep planning fixtures in their CPU environment; qualify native bindings separately."""
import ast
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d663_20261018/qualify.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '1cfd5d94227448d349d837b613283b03d85a28f3069e74fa118ef531b952eeea'
code = data.decode()
code = code.replace("assert phase in ('qualification', 'qualification2', 'analysis')",
                    "assert phase in ('analysis2', 'qualification3')")
start = code.index("tests = ['tests.test_ieee_tc_hit_host_transaction']")
end = code.index('log = RAW/', start)
code = code[:start] + """if phase == 'analysis2':
    assert sys.executable == '/home/qhq/anaconda3/envs/sllm_vllm0102_newserverless_20260518/bin/python'
    tests = ['tests.test_ieee_tc_hit_host_transaction.RegisteredProactiveHostTransaction']
else:
    assert sys.executable == '/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python'
    tests = ['tests.test_ieee_tc_hit_host_transaction.NativeHostActivationWitness',
        'tests.test_ieee_tc_hit_host_transaction.NativeWorkerRecheck']
""" + code[end:]
code = code.replace('no_gpu_run=True, performance_conclusion=False)',
    'no_gpu_run=True, performance_conclusion=False, python=sys.executable)')
ast.parse(code)
exec(compile(code, str(source), 'exec'))
