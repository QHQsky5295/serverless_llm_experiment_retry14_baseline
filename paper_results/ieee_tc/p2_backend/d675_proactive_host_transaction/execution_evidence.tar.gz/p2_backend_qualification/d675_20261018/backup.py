"""Reuse D595 explicit-path, verified-source, secret-checked checkpoint."""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'c16bfc285f6b9ed3f14bd46b730b5c37f0a9c52245f0f90e093fa2c23f34c1c4'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace('d595_parallel_pressure_barrier', 'd675_proactive_host_transaction')
code = code.replace('023ae0079e0b2ffa537a81bda7855e8a4b8ede95', 'b0150348462c7811e3a572aae0df237d99f125bc')
start = code.index("reg=read(RAW/'regression2_receipt.json')")
end = code.index('preserved={', start)
code = code[:start] + '''phases=('qualification','analysis','qualification2','analysis2','qualification3')
receipts={name:read(RAW/(name+'_receipt.json')) for name in phases}
assert receipts['analysis']['passed'] and receipts['qualification3']['passed']
reg=receipts['qualification3']
assert not receipts['qualification']['passed'] and not receipts['qualification2']['passed'] and not receipts['analysis2']['passed']
test=ROOT/'tests/test_ieee_tc_hit_host_transaction.py'
current=test.read_text()
compat=current[:current.index('class RegisteredProactiveHostTransaction')]+current[current.index('class NativeHostActivationWitness'):]
compat=compat.replace('import asyncio\\n','')
initial=compat.replace("expected_epoch=before['epoch'],\\n            capacity_only=False", "expected_epoch=before['epoch'], preparation_plan_id='test-plan',\\n            capacity_only=False")
setup="""        # Reuse the fixture's serialized inline planner, not its optional real
        # process startup. This test concerns storage/reference ownership;
        # process placement and startup are separate existing qualifications.
        pressure.setUpModule()
        self.addCleanup(pressure.tearDownModule)
"""
assert current.count(setup)==1
uninitialized=current.replace(setup,'')
versions={'qualification':initial,'analysis':compat,'qualification2':uninitialized,'analysis2':uninitialized,'qualification3':current}
for phase,receipt in receipts.items():
    assert p.digest(RAW/(phase+'.log'))==receipt['log_sha256']
    for path,sha in receipt['source_sha256'].items():
        if path==str(test):
            assert hashlib.sha256(versions[phase].encode()).hexdigest()==sha,(phase,'test reconstruction mismatch')
        else:assert p.digest(Path(path))==sha
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
    assert closed['resources']['memory.swap.current']=='0'
    events=dict(line.split() for line in closed['resources']['memory.events'].splitlines())
    assert all(events[key]=='0' for key in ('high','max','oom','oom_kill'))
for phase in ('qualification','analysis','qualification2'):
    with (RAW/(phase+'_test_source.py')).open('x') as stream:stream.write(versions[phase])
initial_log=(RAW/'qualification.log').read_text()
errors=re.findall(r'^ERROR: (.*)$',initial_log,re.M)
assert len(errors)==12 and sum('NativeHostActivationWitness.' in x for x in errors)==3
assert sum('ProactiveHostTransaction.' in x for x in errors)==9
assert initial_log.count("ModuleNotFoundError: No module named 'vllm.lora.model_manager'")==3
assert initial_log.count("ValueError: registered preparation requires its frozen objective")==9
for phase in ('qualification2','analysis2'):
    log=(RAW/(phase+'.log')).read_text()
    errors=re.findall(r'^ERROR: (.*)$',log,re.M)
    assert len(errors)==1 and 'test_staged_registration_precedes_fresh_graph_and_readonly_activation' in errors[0]
    assert 'TimeoutError' in log and 'planning_cpu.py' in log
assert 'Ran 692 tests' in (RAW/'analysis.log').read_text()
assert 'Ran 33 tests' in (RAW/'qualification3.log').read_text()
for phase in ('analysis','qualification3'):assert '\\nOK\\n' in (RAW/(phase+'.log')).read_text()
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
baseline=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/qhq/serverless_llm_baselines',text=True).strip()
assert baseline=='e16af33aaf41f02a62ecdce59f6f3227813244c3'
prior=RAW.parent/'d674_20261018'
late_closed=read(prior/'publication2_closure.json')
assert late_closed['passed'] and late_closed['path_gone'] and not Path(late_closed['identity']['path']).exists()
''' + code[end:]
start = code.index('members=[RAW/name')
end = code.index('\nfor path in members:', start)
code = code[:start] + "members=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log')])+[prior/'publication2_receipt.json',prior/'publication2_closure.json']\nassert sum(path.stat().st_size for path in members)<8*1024*1024" + code[end:]
replace('bundle.add(path,arcname=path.name,recursive=False)',
        'bundle.add(path,arcname=str(path.relative_to(RAW.parent.parent)),recursive=False)')
replace('bundle.extractfile(path.name).read()',
        'bundle.extractfile(str(path.relative_to(RAW.parent.parent))).read()')
replace("for name in ('focused','regression2')}", "for name in phases}")
replace("policy='parallel_owner_barrier_v1'", "mechanism='same_transaction_proactive_host_activation_v1'")
replace('focused_before_metadata=focused,aborted_cpu_regression=stopped,protected=protected,',
        'qualification_attempts=receipts,protected=protected,baseline_commit=baseline,\n    late_d674_publication_closure=late_closed,')
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['faaslora/memory/gpu_monitor.py','faaslora/memory/residency_manager.py',\n    'tests/test_ieee_tc_hit_host_transaction.py','docs/ieee_tc/EXECUTION_STATUS.md',\n    'docs/ieee_tc/D675_PROACTIVE_HOST_TRANSACTION.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: qualify transaction-local proactive HOST activation evidence (D675)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D675 explicit-path checkpoint adaptation parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
