"""Final native binding and transaction suite, with complete reused fixture setup."""
import ast
from pathlib import Path
source = Path(__file__).with_name('qualify_final.py')
code = source.read_text()
old = "tests = ['tests.test_ieee_tc_hit_host_transaction.NativeHostActivationWitness',\n        'tests.test_ieee_tc_hit_host_transaction.NativeWorkerRecheck']"
assert code.count(old) == 1
code = code.replace(old, "tests = ['tests.test_ieee_tc_hit_host_transaction']")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
