"""Same exact-identity closure, with one additional native qualification phase."""
import hashlib
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d668_20261018/close.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '2275f5fb7959fb2df7bf13a67cce7f4ebcd226a232ca9d6ecb5ec00d013ca68a'
code = data.decode()
assert code.count("'qualification2','backup'") == 1
code = code.replace("'qualification2','backup'", "'qualification2','qualification3','backup'")
exec(compile(code, str(source), 'exec'))
