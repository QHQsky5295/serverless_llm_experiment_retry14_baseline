"""Correct the CPU test fixture, retain first attempt, use explicit native test phase."""
import ast
from pathlib import Path

source = Path(__file__).with_name('qualify.py')
code = source.read_text()
assert code.count("if phase == 'qualification':") == 1
code = code.replace("if phase == 'qualification':", "if phase == 'analysis':")
old = "tests = ['tests.test_ieee_tc_hit_host_transaction',\n        'tests.test_ieee_tc_gpu_references'"
assert code.count(old) == 1
code = code.replace(old, "tests = ['tests.test_ieee_tc_hit_host_transaction.HitHostTransaction',\n        'tests.test_ieee_tc_hit_host_transaction.ProactiveHostTransaction',\n        'tests.test_ieee_tc_hit_host_transaction.AllocatorReobservation',\n        'tests.test_ieee_tc_hit_host_transaction.NativeWorkerRecheck',\n        'tests.test_ieee_tc_gpu_references'")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
