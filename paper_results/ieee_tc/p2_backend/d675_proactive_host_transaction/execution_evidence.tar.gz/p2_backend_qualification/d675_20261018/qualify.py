"""D675: reuse bounded qualification for the proactive postcheck candidate."""
import ast
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d663_20261018/qualify.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '1cfd5d94227448d349d837b613283b03d85a28f3069e74fa118ef531b952eeea'
code = data.decode()
start = code.index("tests = ['tests.test_ieee_tc_hit_host_transaction']")
end = code.index('log = RAW/', start)
code = code[:start] + """if phase == 'qualification':
    assert sys.executable == '/home/qhq/anaconda3/envs/sllm_vllm0102_newserverless_20260518/bin/python'
    tests = ['tests.test_ieee_tc_hit_host_transaction',
        'tests.test_ieee_tc_gpu_references', 'tests.test_ieee_tc_worker_observation',
        'tests.test_ieee_tc_host_observation_freshness', 'tests.test_ieee_tc_host_execution_projection',
        'tests.test_ieee_tc_request_footprints', 'tests.test_ieee_tc_transfer_pressure',
        'tests.test_ieee_tc_request_lifecycle']
elif phase == 'qualification2':
    assert sys.executable == '/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python'
    tests = ['tests.test_ieee_tc_hit_host_transaction']
else:
    raise ValueError('unregistered qualification phase')
""" + code[end:]
code = code.replace('no_gpu_run=True, performance_conclusion=False)',
    'no_gpu_run=True, performance_conclusion=False, python=sys.executable)')
ast.parse(code)
exec(compile(code, str(source), 'exec'))
