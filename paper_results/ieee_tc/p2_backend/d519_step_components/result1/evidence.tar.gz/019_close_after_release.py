"""D519 owned, empty-scope precheck before the existing closure workflow."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

launch = json.loads((RAW/'7b_full_w0_prefix1/launch.json').read_text())
assert launch['pass'] and launch['service_path_removed']
assert launch['native_gpu_context_release_confirmed']
start = json.loads((RAW/'launch_gate.json').read_text())['identity']
checks = []
for unit, expected in [(start['unit'], start), (Path(launch['auxiliary']['path']).name, json.loads((RAW/'service_aux_identity.json').read_text()))]:
    identity = p.scope_identity(unit)
    if expected is not None:
        assert identity == expected, (identity, expected)
    else:
        assert identity['path'] == launch['auxiliary']['path']
    group = Path(identity['path'])
    members = {str(path): path.read_text().split() for path in group.rglob('cgroup.procs')}
    assert members and all(not pids for pids in members.values()), members
    assert p.scope_still_owned(identity)
    checks.append(dict(identity=identity, recursive_cgroup_procs=members,
        resources={name:(group/name).read_text().strip() for name in
            ('memory.peak','memory.events','memory.swap.current','cgroup.events')}))
with (RAW/'preclosure_owned_empty.json').open('x') as handle:
    json.dump(dict(checks=checks, launch_pass=True, scope=p.scope_identity(p.cg_path().name)), handle, indent=2)
subprocess.run(['bash', str(RAW/'stop_remote.sh')], check=True)
subprocess.run(['/usr/bin/python3', str(RAW/'collect_closure.py')], check=True)
