"""Run the existing replay/input checks; no GPU or trace generation."""
import json
from pathlib import Path
import sys
import unittest
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

if __name__=='__main__':
    own=p.scope_identity(p.cg_path().name)
    with (RAW/'cpu_identity.json').open('x') as f:json.dump(own,f,indent=2)
    group=Path(own['path'])
    assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
    assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip()=='0'
    import os, subprocess
    assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    assert p.preflight([ROOT],p.GIB)['preflight_pass']
    subprocess.run(['git','diff','--exit-code','db44e8f068eb30c69466f32ad3d147ffbc45f9e2','--','scripts/run_all_experiments.py'],cwd=ROOT,check=True)
    with (RAW/'cpu.log').open('x') as log:
        result=unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(['tests.test_ieee_tc_external_replay', 'tests.test_ieee_tc_d456_diagnostic_contract', 'tests.test_ieee_tc_core_timing', 'tests.test_ieee_tc_core_timing_analysis', 'tests.test_ieee_tc_host_execution_projection', 'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_gpu_references', 'tests.test_ieee_tc_identity_recheck', 'tests.test_ieee_tc_host_observation_freshness', 'tests.test_ieee_tc_request_lifecycle', 'tests.test_ieee_tc_service_events', 'tests.test_ieee_tc_worker_observation', 'tests.test_basic_smoke']))
    with (RAW/'cpu_result.json').open('x') as f:
        json.dump(dict(passed=result.wasSuccessful(),count=result.testsRun,
            errors=len(result.errors),failures=len(result.failures),skipped=len(result.skipped),scope=own),f,indent=2)
    sys.exit(0 if result.wasSuccessful() else 1)
