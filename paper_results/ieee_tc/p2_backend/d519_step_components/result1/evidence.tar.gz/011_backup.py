"""D519 explicit task-only checkpoint; reuse the existing guarded Git procedure."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d519_step_components'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2)
scope=p.scope_identity(p.cg_path().name);save(RAW/'backup_identity.json',scope)
q=json.loads((OUT/'input_qualification.json').read_text());assert q['cpu_qualification_pass']
for ref in q['refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='880a38eb02868d235784a7e0d3b10967b6617590'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/qhq/serverless_llm_baselines',text=True).strip()=='09baa9379bdc3518f18f408d2cad3763c2754554'
for name in ('cpu','qualification'):
    closure=json.loads((RAW/(name+'_closure.json')).read_text())
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
paths=['scripts/run_all_experiments.py','tests/test_ieee_tc_host_execution_projection.py','configs/ieee_tc/20261014_d519_7b_full_w0_prefix1.yaml',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh','scripts/ieee_tc/profile_d328_controller_python.sh','tests/test_ieee_tc_d456_diagnostic_contract.py',
    'docs/ieee_tc/D519_RESTORED_STEP_DIAGNOSTIC.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'paper_results/ieee_tc/p2_backend/d519_step_components/input_qualification.json']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(paths) and all('lora_manifest_1000.json' not in x for x in staged)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
hashes={}
for name in paths:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert len(data)<2*1024*1024
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
    assert not token or token not in data
    hashes[name]=hashlib.sha256(data).hexdigest();assert hashes[name]==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
save(RAW/'staged_check.json',dict(passed=True,files=hashes))
subprocess.run(['git','commit','-m','tc: restore sealed serving semantics and preregister step diagnosis (D519)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
receipt=dict(passed=True,head=head,remote=remote,files=len(paths),scope=scope)
save(RAW/'backup_receipt.json',receipt);print(json.dumps(receipt))
