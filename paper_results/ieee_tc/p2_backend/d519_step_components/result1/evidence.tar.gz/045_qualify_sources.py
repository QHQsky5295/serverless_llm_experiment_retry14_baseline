"""Reuse D456 original1000 identity and D476 frozen configuration; no new trace."""
import importlib.util
import json
import os
import re
import subprocess
import sys
from pathlib import Path
import yaml

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d519_step_components'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)

identity=p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json',identity)
assert os.sched_getaffinity(0)=={2,3,26,27}
assert (Path(identity['path'])/'memory.max').read_text().strip()==str(4*p.GIB)
assert (Path(identity['path'])/'memory.swap.max').read_text().strip()=='0'
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
source=re.search(r'^export FAASLORA_SHARED_TRACE_PATH=(.+)$',shell.read_text(),re.M)[1]
plan=FrozenReplayPlan.load(source,count=1000)
assert plan.profile=='W0' and plan.rate_scale==1 and plan.source_count==4000
context=dict(plan=plan.identity(),tiny_witness=False,replay_scope='diagnostic_prefix_v1',diagnostic_prefix_count=1000)
assert FrozenReplayPlan.from_launch_context(context)==plan
baseline=Path('/home/qhq/serverless_llm_baselines/scripts/prepare_ieee_tc_serverless_stack.py')
spec=importlib.util.spec_from_file_location('d519_existing_baseline',baseline)
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
cfg_path=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d434_20261011/http_7b_1000.json')
cfg=json.loads(cfg_path.read_text())
legacy=native.load_http_replay_plan(cfg)
assert plan.entries==legacy.entries
assert plan.identity()['view_sha256']=='0a5dfcf8048abdc8fc1e3a8ccaf92bfb925a9db326c8d27507663bede96a0981'
assert len({json.loads(e.source_json)['adapter_id'] for e in plan.entries})==60
assert sum(min(json.loads(e.source_json)['expected_output_tokens'],256) for e in plan.entries)==122510
newcfg=ROOT/'configs/ieee_tc/20261014_d519_7b_full_w0_prefix1.yaml'
oldcfg=ROOT/'configs/ieee_tc/20261012_d476_7b_full_w0.yaml'
left,right=yaml.safe_load(oldcfg.read_text()),yaml.safe_load(newcfg.read_text())
for section,field in [('experiment','output_dir'),('storage','nvme_cache_dir'),('storage','host_cache_dir')]:
    assert not Path(right[section][field]).exists()
    assert left[section].pop(field)!=right[section].pop(field)
assert left==right
subprocess.run(['git','diff','--exit-code','db44e8f068eb30c69466f32ad3d147ffbc45f9e2','--',
    'scripts/run_all_experiments.py','scripts/run_all_experiments_user_scope.sh'],cwd=ROOT,check=True)
subprocess.run(['git','diff','--exit-code','880a38eb02868d235784a7e0d3b10967b6617590','--',
    'scripts/ieee_tc_preflight.py','scripts/analyze_control_path_overhead.py'],cwd=ROOT,check=True)
# D518 observer is the sole faaslora difference from the sealed source.
changed = subprocess.check_output(['git','diff','db44e8f068eb30c69466f32ad3d147ffbc45f9e2','--name-only','--','faaslora'],cwd=ROOT,text=True).splitlines()
assert set(changed)=={'faaslora/utils/core_timing.py','faaslora/scheduling/vllm_ieee_scheduler.py'}
subprocess.run(['git','diff','--exit-code','880a38eb02868d235784a7e0d3b10967b6617590','--','faaslora'],cwd=ROOT,check=True)
cpu=json.loads((RAW/'cpu_result.json').read_text())
assert cpu['passed'] and cpu['errors']==cpu['failures']==cpu['skipped']==0
seal=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')
protected=p.verify_seal(seal);assert protected['pass'] and protected['entry_count']==147
preserved={
    ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d'}
for path,digest in preserved.items():assert p.digest(path)==digest,path
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
wrapper=ROOT/'scripts/ieee_tc/profile_d328_controller_python.sh'
for path in [shell,wrapper,*RAW.glob('*.sh')]:subprocess.run(['bash','-n',str(path)],check=True)
for path in RAW.glob('*.py'):compile(path.read_text(),str(path),'exec')
installed=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages')
refs=[Path(source),Path(cfg['trace']),cfg_path,baseline,newcfg,oldcfg,shell,wrapper,p.PLAN,seal]
refs += [ROOT/name for name in ('faaslora/utils/core_timing.py','faaslora/utils/logger.py',
    'faaslora/datasets/workload_generator.py','scripts/run_all_experiments.py','scripts/ieee_tc_preflight.py',
    'scripts/run_all_experiments_user_scope.sh','scripts/analyze_control_path_overhead.py',
    'tests/test_ieee_tc_external_replay.py','tests/test_ieee_tc_d456_diagnostic_contract.py',
    'tests/test_ieee_tc_core_timing.py','tests/test_ieee_tc_core_timing_analysis.py',
    'docs/ieee_tc/D519_RESTORED_STEP_DIAGNOSTIC.md',
    'paper_results/ieee_tc/main_comparison/d511_resource_gap/summary.json',
    'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json')]
refs += [installed/name for name in ('vllm/v1/engine/core.py','vllm/v1/executor/uniproc_executor.py',
    'vllm/v1/core/sched/scheduler.py','vllm/v1/worker/gpu/model_runner.py','vllm/utils/torch_utils.py','torch/cuda/memory.py')]
helpers=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh')])
refs += [ROOT/'tests/test_ieee_tc_host_execution_projection.py',ROOT/'faaslora/scheduling/vllm_ieee_scheduler.py']
refs += helpers+[RAW/'cpu_result.json',RAW/'cpu.log',*preserved]
result=dict(kind='d519_original1000_native_timing_preregistration_v1',cpu_qualification_pass=True,
    actual_gpu_run_complete=False,performance_ranking_eligible=False,view=plan.identity(),
    baseline_view=legacy.identity(),exact_baseline_entries=True,unique_adapters=60,target_tokens=122510,
    non_target_config_equal=True,serving_semantics_restored_to_d476=True,observer='host_spans_v1',step_observer='v2_components_v1',
    tests=cpu,protected=protected,scope=identity,preserved={str(k):v for k,v in preserved.items()},
    helpers=[dict(path=str(x),sha256=p.digest(x),content=x.read_text()) for x in helpers],
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in dict.fromkeys(refs)])
OUT.mkdir(parents=True,exist_ok=True);save(OUT/'input_qualification.json',result)
print(json.dumps(dict(passed=True,tests=cpu['count'],view=plan.identity(),scope=identity)))
