"""D519 explicit outcome backup, retaining incomplete observation and its failure."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
PUB=ROOT/'paper_results/ieee_tc/p2_backend/d519_step_components'
OUT=PUB/'result1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)

def main():
    own=p.scope_identity(p.cg_path().name);save(RAW/'backup_result_identity.json',own)
    group=Path(own['path'])
    assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
    assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip()=='0'
    assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    assert p.preflight([ROOT],p.GIB)['preflight_pass']
    parent='3654b8645f5792a7c7d7e47416613398b682ec08'
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==parent
    subprocess.run(['git','diff','--exit-code',parent,'--','faaslora','scripts/run_all_experiments.py','configs/ieee_tc'],cwd=ROOT,check=True)
    assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
    assert protected['pass'] and protected['entry_count']==147
    qualification=read(PUB/'input_qualification.json')
    for path,sha in qualification['preserved'].items():assert p.digest(Path(path))==sha,path
    assert read(RAW/'cpu_result.json')['count']==1028 and read(RAW/'cpu_result.json')['passed']
    assert read(RAW/'analysis_tests1_receipt.json')['returncode']==0
    assert read(RAW/'component_partial_tests_receipt.json')['returncode']==0
    closures={}
    for name in ('cpu','qualification','backup','collection','analysis','operation','operation_partial'):
        value=read(RAW/(name+'_closure.json'))
        assert value['passed'] and value['actual_recursive_procs_empty'] and not Path(value['identity']['path']).exists()
        closures[name]=value
    assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
    cleanup=read(RAW/'local_cleanup.json')
    assert not Path(cleanup['identity']['path']).exists() and not Path(cleanup['service_aux']['path']).exists()
    collection=read(RAW/'collection_receipt.json')
    assert p.digest(Path(collection['source_path']))==collection['source_sha256']
    historical=[]
    for ref in qualification['refs']:
        path=Path(ref['path'])
        if p.digest(path)==ref['sha256']:continue
        assert path in (ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'tests/test_ieee_tc_core_timing_analysis.py')
        data=subprocess.check_output(['git','show',parent+':'+str(path.relative_to(ROOT))],cwd=ROOT)
        assert hashlib.sha256(data).hexdigest()==ref['sha256']
        historical.append(dict(**ref,recovery='git:'+parent))
    first=read(PUB/'analysis1/manifest.json')
    for name,sha in first['outputs'].items():assert p.digest(PUB/'analysis1'/name)==sha,name
    for ref in first['source_refs']:
        path=Path(ref['path'])
        if p.digest(path)==ref['sha256']:continue
        assert path==ROOT/'scripts/analyze_control_path_overhead.py'
        recovered=RAW/'recovered_prepartial_analyzer.py'
        assert p.digest(recovered)==ref['sha256']
        historical.append(dict(**ref,recovery=str(recovered),reason='exact pre-partial source recovered and SHA matched; no altered measurements'))
    components=read(PUB/'components_partial1/summary.json')
    assert not components['complete_diagnostic_qualified'] and components['partial_observations_only']
    assert components['total_steps']==47038 and components['complete_request_observations']==279
    assert components['analyzer_sha256']==p.digest(ROOT/'scripts/analyze_control_path_overhead.py')
    for name,sha in components['outputs'].items():assert p.digest(PUB/'components_partial1'/name)==sha,name
    for ref in components['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
    token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
    def secrets(data):
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
    OUT.mkdir(exist_ok=False)
    sources={str(path):p.digest(path) for path in sorted(RAW.iterdir())
        if path.is_file() and path.suffix in ('.py','.sh','.json','.log') and path.stat().st_size<2*1024**2}
    sources.update({str(PUB/'analysis1'/name):sha for name,sha in first['outputs'].items()
        if (PUB/'analysis1'/name).stat().st_size<2*1024**2})
    members={}
    with tarfile.open(OUT/'evidence.tar.gz','x:gz') as archive:
        for i,(path,sha) in enumerate(sorted(sources.items())):
            data=Path(path).read_bytes();secrets(data)
            assert hashlib.sha256(data).hexdigest()==sha
            name=f'{i:03d}_'+Path(path).name
            item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0
            archive.addfile(item,io.BytesIO(data));members[name]=dict(path=path,sha256=sha)
    with tarfile.open(OUT/'evidence.tar.gz','r:gz') as archive:
        assert set(archive.getnames())==set(members)
        for name,ref in members.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==ref['sha256']
    copies={
        'native_audit.json':PUB/'analysis1/native_audit.json',
        'resource_remote.json':PUB/'analysis1/resource_remote.json',
        'completion.json':PUB/'analysis1/completion.json',
        'partial_components.json':PUB/'components_partial1/summary.json',
        'component_metrics.csv':PUB/'components_partial1/metrics.csv'}
    for name,path in copies.items():
        data=path.read_bytes();secrets(data)
        with (OUT/name).open('xb') as f:f.write(data)
        assert p.digest(OUT/name)==p.digest(path)
    save(OUT/'manifest.json',dict(kind='d519_completed_execution_partial_diagnostic_v1',
        complete_diagnostic_qualified=False,new_performance_candidate=False,
        independent_numerical_correctness_qualified=False,
        input_qualification_sha256=p.digest(PUB/'input_qualification.json'),
        source_result=collection,protected=protected,closures=closures,historical_source_recovery=historical,
        archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz'),
        copies={name:dict(source=str(path),sha256=p.digest(path)) for name,path in copies.items()},
        full_step_csv_local_only=dict(path=str(PUB/'components_partial1/steps.csv'),sha256=p.digest(PUB/'components_partial1/steps.csv'))))
    paths=['scripts/analyze_control_path_overhead.py','tests/test_ieee_tc_core_timing_analysis.py',
        'docs/ieee_tc/D519_STEP_DIAGNOSTIC_RESULT.md','docs/ieee_tc/EXECUTION_STATUS.md']
    paths += [str(path.relative_to(ROOT)) for path in sorted(OUT.iterdir())]
    assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
    subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
    for name in paths:
        data=(ROOT/name).read_bytes();secrets(data);assert len(data)<2*1024**2
    subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
    assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(paths)
    for name in paths:
        data=subprocess.check_output(['git','show',':'+name],cwd=ROOT);secrets(data)
        assert hashlib.sha256(data).hexdigest()==p.digest(ROOT/name)
    subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
    subprocess.run(['git','commit','-m','tc: preserve capped step diagnosis and observed components (D519)'],cwd=ROOT,check=True)
    subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
    assert head==remote
    save(RAW/'backup_result_receipt.json',dict(passed=True,head=head,remote=remote,paths=paths,
        identity=own,result_manifest_sha256=p.digest(OUT/'manifest.json'),
        resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
    print(json.dumps(read(RAW/'backup_result_receipt.json')))

if __name__=='__main__':main()
