"""Explicit-path D816 tested checkpoint, excluding all unrelated work."""
import ast, hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d816_required_file_capacity'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def call(args): return subprocess.check_output(args,cwd=ROOT,text=True,stderr=subprocess.STDOUT,timeout=55).strip()
def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2); f.write('\n')
assert os.sched_getaffinity(0)=={2,3,26,27}
own=p.scope_identity(p.cg_path().name); save(RAW/'backup_identity.json',own)
assert call(['git','rev-parse','HEAD'])=='6c932c346eeed7a3ebfea0e3aebfd3083eeaf4b0'
assert not call(['git','diff','--cached','--name-only'])
assert not call(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'])
source=json.loads((OUT/'qualification_additional/sources.json').read_text())
for name,sha in source['sources'].items(): assert p.digest(ROOT/name)==sha,name
allowed={
 'faaslora/memory/residency_manager.py': {'LocalSourceReferences.'+s for s in (
 '__init__','file_movement_interest','_file_replacement_capacity_from_inventory',
 '_reclaim_for_file_preparation','_touch_file_source','_reclaim_for_file_demand',
 'file_preparation_snapshot','_prepare_file_allocation','mutation')},
 'scripts/run_all_experiments.py': {'ScenarioRunner._queue_ieee_file_preparation','ScenarioRunner._ensure_local_async'}}
def functions(tree,prefix=''):
    result={}
    for node in tree.body:
        if isinstance(node,ast.ClassDef): result.update(functions(node,prefix+node.name+'.'))
        elif isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)): result[prefix+node.name]=ast.dump(node)
    return result
changes={}
for name,wanted in allowed.items():
    old=functions(ast.parse(subprocess.check_output(['git','show','HEAD:'+name],cwd=ROOT,text=True)))
    new=functions(ast.parse((ROOT/name).read_text()))
    changed={k for k in old.keys()|new.keys() if old.get(k)!=new.get(k)}
    assert changed==wanted,(name,changed)
    changes[name]=sorted(changed)
protected=json.loads((OUT/'qualification_additional/qualification.json').read_text())['user_protected']
for name,sha in protected.items(): assert p.digest(Path(name))==sha
seal=RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json'
verified=p.verify_seal(seal); assert verified['pass'] and verified['entry_count']==147
save(OUT/'source_impact.json',dict(passed=True,modified_methods=changes,sources=source['sources'],protected=verified))
secret=re.compile(r'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]+|(?im:^[ \t]*(?:password|passwd|secret|api_key|PRIME_REMOTE_TOKEN)[ \t]*=[ \t]*[\x22\x27]?[A-Za-z0-9+/]{8,})')
prior=RAW.parent/'d815_20261025'
evidence={name:prior/name for name in ('finish_backup.py','backup.json','finish_backup_identity.json')}
evidence.update({name:RAW/name for name in ('backup.py','qualification_identity.json','qualification_identity_additional.json')})
bundle=OUT/'execution_evidence.tar.gz'
for path in evidence.values(): assert path.stat().st_size<1024*1024 and not secret.search(path.read_text()),path
with tarfile.open(bundle,'x:gz') as f:
    for name,path in evidence.items(): f.add(path,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as f:
    assert set(f.getnames())==set(evidence)
    for name,path in evidence.items(): assert hashlib.sha256(f.extractfile(name).read()).hexdigest()==p.digest(path)
members=[dict(path=str(x.relative_to(ROOT)),sha256=p.digest(x)) for x in sorted(OUT.rglob('*')) if x.is_file()]
save(OUT/'manifest.json',dict(files=members))
paths=list(source['sources'])+['docs/ieee_tc/D816_REQUIRED_FILE_CAPACITY_20261025.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str(x.relative_to(ROOT)) for x in sorted(OUT.rglob('*')) if x.is_file()]
for name in paths:
    if name.endswith('.tar.gz'): continue
    assert not secret.search((ROOT/name).read_text()),name
assert 'configs/generated/lora_manifest_1000.json' not in paths
call(['git','diff','--check','--',*paths]); call(['git','add','--',*paths])
assert set(call(['git','diff','--cached','--name-only']).splitlines())==set(paths)
call(['git','diff','--cached','--check'])
call(['git','commit','-m','tc: separate mandatory request file capacity from optional preparation (D816)'])
head=call(['git','rev-parse','HEAD']); ref='refs/heads/backup/d816-required-file-capacity-20261025'
save(RAW/'commit.json',dict(head=head,ref=ref,paths=paths))
call(['git','-c','http.version=HTTP/1.1','push','faaslora_origin','HEAD:'+ref])
assert call(['git','-c','http.version=HTTP/1.1','ls-remote','faaslora_origin',ref]).split()[0]==head
save(RAW/'backup.json',dict(passed=True,head=head,ref=ref,paths=paths,v2_synchronized=False,resources_before_exit=p.cgroup_snapshot(Path(own['path']))))
print(json.dumps(dict(passed=True,head=head,ref=ref,files=len(paths))))
