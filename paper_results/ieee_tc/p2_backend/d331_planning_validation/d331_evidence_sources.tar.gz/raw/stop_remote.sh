#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
raw=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d331_20261008
jq -e '.pass and .native_gpu_context_release_confirmed and .service_path_removed' "$raw/7b_planning_validation_100/launch.json" >/dev/null
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
ssh -o BatchMode=yes primelora-artifact-174 /bin/bash <<'REMOTE' > "$raw/remote_stop.log" 2>&1
set -euo pipefail
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d331-smoke1.service)
ids=(5e7c9599debd4308920fd81243b2caa5 32e963a31ece4f309ea11e1299bdfc52 762b324c234f40dc9e5401b5eed12706)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
done
systemctl --user stop "${units[2]}"
for i in 0 1; do
  state=$(systemctl --user show "${units[$i]}" -p ActiveState --value)
  if test "$state" != inactive; then
    test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
    systemctl --user stop "${units[$i]}"
  fi
done
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
  systemctl --user show "$unit" -p Id -p ActiveState -p MainPID -p Result
done
test -z "$(ss -ltnH '( sport = :18080 or sport = :18081 )')"
grep -l 'remote-process-monotonic:05aa93573e344cd3920e49a2309fce8b' /home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-*.jsonl
sha256sum /home/lab14/primelora_remote/tc/d331_20261008_smoke1/remote_monitor.log
REMOTE
