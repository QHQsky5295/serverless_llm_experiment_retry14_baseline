import ast
import copy
import hashlib
import io
import json
import subprocess
import sys
import tarfile
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
import yaml
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
out = p.ROOT/'paper_results/ieee_tc/p2_backend/d331_planning_validation'
head = 'af0b7717c8c79db5fbd8b0e61532ea0a1976e5d0'
before = p.ROOT/'configs/ieee_tc/20261008_d331_7b_planning_validation_100.yaml'
after = p.ROOT/'configs/ieee_tc/20261008_d331_7b_planning_validation_100_attempt2.yaml'
c, previous = [yaml.safe_load(path.read_text()) for path in (after, before)]
expected = copy.deepcopy(previous)
for section, field in [('experiment','output_dir'),('storage','nvme_cache_dir'),('storage','host_cache_dir')]:
    assert not Path(c[section][field]).exists()
    expected[section][field] = c[section][field]
assert expected == c and c['workload']['total_requests'] == 4000
old_source = subprocess.check_output(['git','show',f'{head}:scripts/run_all_experiments.py'],cwd=p.ROOT,text=True)
old_fragment = "'_ieee_source_observation_stats','_ieee_runtime_quarantine_events','_ieee_scalein_events')})"
new_fragment = "'_ieee_source_observation_stats','_ieee_route_cache_stats',\n            '_ieee_runtime_quarantine_events','_ieee_scalein_events')})"
assert old_source.count(old_fragment) == 1
assert old_source.replace(old_fragment,new_fragment) == (p.ROOT/'scripts/run_all_experiments.py').read_text()
prelaunch = json.loads((raw/'prelaunch_binding.json').read_text())
source_checks = []
for ref in prelaunch['source_references']:
    path = Path(ref['path'])
    if p.digest(path) == ref['sha256']:
        method = 'current_file'
    else:
        relative = path.relative_to(p.ROOT)
        content = subprocess.check_output(['git','show',f'{head}:{relative}'],cwd=p.ROOT)
        assert hashlib.sha256(content).hexdigest() == ref['sha256']
        method = 'executed_commit_not_current_workspace'
    source_checks.append(dict(ref,verified_via=method))
audit = json.loads((out/'smoke2/audit.json').read_text())
assert audit['stats']['completed'] == 100 and audit['n_correct'] is None
assert audit['planning_publication_trigger']['status'] == 'unobserved_export_missing'
assert audit['planning_publication_trigger']['qualification_pass'] is False
for ref in audit['raw_evidence']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
seal = p.verify_seal(p.ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count'] == 147 and seal['changed'] == [str(known)]
assert p.digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(p.ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert p.digest(p.ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
repo_paths = [p.ROOT/path for path in [
    'scripts/run_all_experiments.py','scripts/ieee_tc/analyze_d298_smoke.py',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    'tests/test_ieee_tc_launch.py','tests/test_ieee_tc_timing_bound.py',
    'docs/ieee_tc/D331_PLANNING_PUBLICATION_SMOKE.md']]
for path in repo_paths:
    if path.suffix == '.py': ast.parse(path.read_text())
subprocess.run(['bash','-n',str(repo_paths[2])],check=True)
raw_names = ['launch_gate1.json','prelaunch_binding.json','remote_health.json','remote_start.log',
    'remote_stop.log','remote_stop.json','local_cleanup.json','audit_scopes_cleanup.json',
    'audit_tests1.log','audit_tests2.log','audit1.log','audit2.log',
    'start_remote.sh','stop_remote.sh','collect_closure.py','finalize_evidence.py']
paths = repo_paths+[before,after]+[raw/name for name in raw_names]+list((out/'smoke2').glob('*'))
refs = [dict(path=str(path),sha256=p.digest(path)) for path in paths]
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
private_key_marker = b'-----BEGIN ' + b'OPENSSH PRIVATE KEY-----'
for path in paths:
    content = path.read_bytes()
    assert token not in content and private_key_marker not in content, path
archive = out/'d331_evidence_sources.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        name = ('raw/'+path.name if path.parent == raw else
                'curated/'+path.name if path.parent == out/'smoke2' else
                'repo/'+str(path.relative_to(p.ROOT)))
        tar.add(path,arcname=name,recursive=False)
    data = old_source.encode()
    entry = tarfile.TarInfo('executed/run_all_experiments.py')
    entry.size = len(data)
    tar.addfile(entry,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    for member in tar.getmembers():
        data = tar.extractfile(member).read()
        assert token not in data and private_key_marker not in data
record = dict(kind='d331_evidence_v1',executed_source_commit=head,
    executed_source_references=source_checks,analysis_workspace_references=refs,
    source_code_note='audit raw_evidence lists analysis-time workspace code; actual serving code is bound separately to executed commit af0b771.',
    native_contract_complete=100,numerical_n_correct=None,mechanism_gate_pass=False,
    mechanism_gate_reason='existing route counters not exported; unknown, not zero',
    retry_reason='One repeat for missing measurement, not performance selection',
    attempt2_preparation=dict(config_only_three_exclusive_paths=True,
        production_change_only_final_post_shutdown_counter_export=True,tests_pass=18,launched=False),
    protection=seal,archive_sha256=p.digest(archive),no_figures=True)
with (out/'evidence.json').open('x') as f:
    json.dump(record,f,indent=2,allow_nan=False)
files = sorted(list((out/'smoke2').glob('*'))+[archive,out/'evidence.json'])
with (out/'evidence.sha256').open('x') as f:
    for path in files:
        f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
print(json.dumps(dict(source_checks=len(source_checks),references=len(refs),
    archive_bytes=archive.stat().st_size,native_complete=100,mechanism_gate_pass=False,
    tests=18,next='actual d331-attempt2 after fresh gates')))
