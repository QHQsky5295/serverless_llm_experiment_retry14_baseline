#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d331_20261008/attempt2
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1
exec /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m scripts.ieee_tc.analyze_d298_smoke --campaign d331-attempt2 > "$raw/audit1.log" 2>&1
