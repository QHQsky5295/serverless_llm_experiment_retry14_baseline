#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
raw=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d331_20261008/attempt2
jq -e '.pass and .native_gpu_context_release_confirmed and .service_path_removed' "$raw/../7b_planning_validation_100_attempt2/launch.json" >/dev/null
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
ssh -o BatchMode=yes primelora-artifact-174 /bin/bash <<'REMOTE' > "$raw/remote_stop.log" 2>&1
set -euo pipefail
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d331-smoke2.service)
ids=(28a9147ab867414aae4bb7b69f119965 6a85d4bbc0be407aa3d41f19486f7a79 ebaee053d7e74b69ae940aec2f4abc0a)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
done
systemctl --user stop "${units[2]}"
for i in 0 1; do
  state=$(systemctl --user show "${units[$i]}" -p ActiveState --value)
  if test "$state" != inactive; then
    test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
    systemctl --user stop "${units[$i]}"
  fi
done
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
  systemctl --user show "$unit" -p Id -p ActiveState -p MainPID -p Result
done
test -z "$(ss -ltnH '( sport = :18080 or sport = :18081 )')"
grep -l 'remote-process-monotonic:5eff367954a24e6ebb71e17991d7c8b1' /home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-*.jsonl
sha256sum /home/lab14/primelora_remote/tc/d331_20261008_smoke2/remote_monitor.log
REMOTE
