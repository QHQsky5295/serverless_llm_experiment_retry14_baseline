"""Seal the completed diagnostic; no new serving policy or performance run."""
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
out = p.ROOT/'paper_results/ieee_tc/p2_backend/d331_planning_validation/attempt2'
unit = 'primelora-tc-aux-4da2a1a88b384fb89a771fbe7a45160b.scope'
identity = p.scope_identity(unit)
assert identity['invocation_id'] == '05d9a7eb4b23456f8faf096a742894dc'
group = Path(identity['path'])
assert not p.owned_pids(group) and p.scope_still_owned(identity)
resources = {key: (group/key).read_text() for key in ['memory.peak','memory.events',
    'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events']}
subprocess.run(['systemctl','--user','stop',unit],check=True)
assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'audit_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,empty_before_stop=True,after='inactive'),f,indent=2)
audit = json.loads((out/'audit.json').read_text())
assert audit['stats']['completed'] == 100 and audit['n_correct'] is None
assert all(value > 0 for value in audit['planning_publication_trigger']['counters'].values())
for ref in audit['raw_evidence']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
launch = json.loads((raw.parent/'7b_planning_validation_100_attempt2/launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
paths = [raw/name for name in ['launch_gate1.json','remote_start.log','remote_health.json',
    'remote_stop.log','remote_stop.json','local_cleanup.json','audit_cleanup.json','audit1.log',
    'start_remote.sh','stop_remote.sh','check_remote_health.py','run_audit.sh','checkpoint.py']]
paths += [raw.parent/'7b_planning_validation_100_attempt2/launch.json']
archive = out/'closure_evidence.tar.gz'
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in paths:
    assert token not in path.read_bytes(), path
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest() == p.digest(path)
record = dict(kind='d331_attempt2_checkpoint_v1',executed_source_commit='01d390de3cf06d12cca41619c44d234200f7775d',
    native_completed=100,numerical_n_correct=None,planning_trigger_observed=True,
    formal_qualification=False,no_figures=True,archive_sha256=p.digest(archive),
    raw_references=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
    next='D332 ordinary full4000, same serving candidate and policy; compare D326')
with (out/'evidence.json').open('x') as f:
    json.dump(record,f,indent=2,allow_nan=False)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+path.name+'\n')
print(json.dumps(dict(native_complete=100,mechanism_observed=True,archive_bytes=archive.stat().st_size,
    audit_scope_released=True,next='actual D332 full4000')))
