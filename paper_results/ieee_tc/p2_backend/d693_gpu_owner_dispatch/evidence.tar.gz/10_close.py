"""Reuse owned, recursively empty scope closure without touching old scopes."""
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d668_20261018/close.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='2275f5fb7959fb2df7bf13a67cce7f4ebcd226a232ca9d6ecb5ec00d013ca68a'
code=data.decode().replace("'publication','publication2')", "'publication','publication2','regression')")
assert code != data.decode()
exec(compile(code,str(source),'exec'))
