"""Final fixture regression; native-method checks use the actual vLLM env."""
import ast
import builtins
import hashlib
from pathlib import Path
source=Path(__file__).resolve().parent/'qualify.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='dca43eda246b55bc5bb264561a41fec9fe1c125e28a1f603935eb30635e472ed'
captured=[]
namespace={'__file__':str(source),'__name__':'d693_final_expansion',
           'exec':lambda compiled,*unused:captured.append(compiled)}
builtins.exec(compile(data,str(source),'exec'),namespace)
assert len(captured)==1
code=namespace['code']
code=code.replace("assert phase in ('qualification', 'qualification2', 'analysis')",
                  "assert phase == 'regression'")
old="'tests.test_ieee_tc_request_footprints', 'tests.test_ieee_tc_hit_host_transaction']"
assert code.count(old)==1
code=code.replace(old,"""'tests.test_ieee_tc_request_footprints']
tests += ['tests.test_ieee_tc_hit_host_transaction.'+name for name in
    ('HitHostTransaction','ProactiveHostTransaction','RegisteredProactiveHostTransaction',
     'AllocatorReobservation','NativeWorkerRecheck')]
assert p.digest(MAIN/'faaslora/preloading/preloading_manager.py') == 'f4415b48184f5fc6774f23fd526692cf50a771b20f6fd2a0f5ef893bf37a3cc4'
""")
ast.parse(code)
builtins.exec(compile(code,str(source),'exec'))
