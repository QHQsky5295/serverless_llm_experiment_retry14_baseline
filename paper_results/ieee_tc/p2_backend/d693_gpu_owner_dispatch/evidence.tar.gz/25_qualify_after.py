"""Keep all 714 checks: 711 fixtures here, 3 native methods in their own env.

Retain the first failed qualification and its exact source identity. The only
test change removes an obsolete sibling-concurrency barrier, not its error or
cleanup assertions. No additional production change is allowed.
"""
import ast
import hashlib
from pathlib import Path
source=Path(__file__).resolve().parent/'qualify.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='dca43eda246b55bc5bb264561a41fec9fe1c125e28a1f603935eb30635e472ed'
# Expand the verified existing qualification without running it yet.
import builtins
captured=[]
def capture(compiled, *unused):
    captured.append(compiled)
namespace={'__file__':str(source),'__name__':'d693_qualification_expansion', 'exec':capture}
builtins.exec(compile(data,str(source),'exec'),namespace)
assert len(captured)==1
code=namespace['code']
code=code.replace("assert phase in ('qualification', 'qualification2', 'analysis')",
                  "assert phase in ('analysis', 'analysis2')")
start=code.index('tests = [')
end=code.index('log = RAW/',start)
code=code[:start]+"""tests = ['tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_gpu_references',
    'tests.test_ieee_tc_host_execution_projection', 'tests.test_ieee_tc_request_lifecycle',
    'tests.test_ieee_tc_worker_observation', 'tests.test_ieee_tc_host_observation_freshness',
    'tests.test_ieee_tc_request_footprints']
tests += ['tests.test_ieee_tc_hit_host_transaction.'+name for name in
    ('HitHostTransaction','ProactiveHostTransaction','RegisteredProactiveHostTransaction',
     'AllocatorReobservation','NativeWorkerRecheck')]
if phase == 'analysis2':
    tests = ['tests.test_ieee_tc_hit_host_transaction.NativeHostActivationWitness']
assert p.digest(MAIN/'faaslora/preloading/preloading_manager.py') == 'f4415b48184f5fc6774f23fd526692cf50a771b20f6fd2a0f5ef893bf37a3cc4'
"""+code[end:]
ast.parse(code)
builtins.exec(compile(code,str(source),'exec'))
