"""Reuse D612 publication with explicit candidate diffs and all failed checks."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path(__file__).resolve().parent.parent/'d612_20261017/publish.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new)
replace('d612_w2_quality_resource_diagnosis','d693_gpu_owner_dispatch')
replace('f72091155cd3bb258651fc461db11b9113c72faf','9035a3069820ffcb9d78ba7564c139e0ae2b918b')
replace("assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')",
    """changed=['faaslora/preloading/preloading_manager.py',
    'tests/test_ieee_tc_transfer_pressure.py','tests/test_ieee_tc_host_execution_projection.py']
assert set(git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc').splitlines())==set(changed)
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')=='193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d'
""")
start=code.index("diagnosis=read(RAW/'diagnosis.json')")
end=code.index('protected=p.verify_seal',start)
code=code[:start]+'''phases=('qualification','qualification2','analysis','analysis2','regression')
receipts={name:read(RAW/(name+'_receipt.json')) for name in phases}
for name in phases:
    closure=read(RAW/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
    assert closure['resources']['memory.swap.current']=='0'
    events=dict(line.split() for line in closure['resources']['memory.events'].splitlines())
    assert all(events[k]=='0' for k in ('high','max','oom','oom_kill'))
    assert p.digest(RAW/(name+'.log'))==receipts[name]['log_sha256']
for name in ('qualification','analysis2','regression'):assert receipts[name]['passed']
for name in ('qualification2','analysis'):assert receipts[name]['passed'] is False
counts={name:int(re.search(r'Ran (\\d+) tests', (RAW/(name+'.log')).read_text()).group(1)) for name in phases}
assert counts==dict(qualification=43,qualification2=714,analysis=711,analysis2=3,regression=712)
for name in ('qualification','analysis2','regression'):assert '\\nOK\\n' in (RAW/(name+'.log')).read_text()
assert 'FAILED (errors=4)' in (RAW/'qualification2.log').read_text()
assert 'FAILED (failures=1)' in (RAW/'analysis.log').read_text()
for name in ('analysis2','regression'):
    for path,sha in receipts[name]['source_sha256'].items():assert p.digest(Path(path))==sha,path
assert p.digest(ROOT/changed[0])=='f4415b48184f5fc6774f23fd526692cf50a771b20f6fd2a0f5ef893bf37a3cc4'
# Reconstruct exact earlier test bytes as evidence; never change the worktree.
test=ROOT/'tests/test_ieee_tc_transfer_pressure.py'
current=test.read_text()
old=subprocess.check_output(['git','show','HEAD:tests/test_ieee_tc_transfer_pressure.py'],cwd=ROOT,text=True)
begin='    def test_superseded_target_cannot_hide_sibling_owned_operation_failure(self):'
end='    def _check_native_source_expiry(self, *, boundary, fail_close=False, handoff=False):'
historical=old[old.index(begin):old.index(end)]
initial=current[:current.index(begin)]+historical+current[current.index(end):]
intermediate_region=historical.replace('                        await entered.wait()\\n',
    '                        # Final GPU actions now serialize on this owner. The\\n'
    '                        # superseded action cannot await its pending sibling.\\n'
    '                        # Its completion dispatches that sibling before the\\n'
    '                        # enclosing plan observes and settles the exception.\\n',1)
needle="                self.assertEqual(runner._ieee_gpu_preparation_plans[-1]['state'], 'failed')"
offset=intermediate_region.index(needle)
intermediate_region=intermediate_region[:offset]+"                self.assertTrue(entered.is_set())\\n"+intermediate_region[offset:]
intermediate=current[:current.index(begin)]+intermediate_region+current[current.index(end):]
assert hashlib.sha256(initial.encode()).hexdigest()==receipts['qualification2']['source_sha256'][str(test)]
assert hashlib.sha256(intermediate.encode()).hexdigest()==receipts['analysis']['source_sha256'][str(test)]
qualification=dict(passed=True,production_candidate=True,native_gpu_validation=False,
    full_performance_run=False,tests_passed=715,initial_focused_tests=43,
    counts=counts,receipts=receipts,n_correct=None,ranking_eligible=False,
    candidate='one_final_gpu_action_per_native_owner',
    unchanged_global_movement_concurrency=True,unchanged_other_tier_concurrency=True,
    unchanged_epoch_and_physical_guards=True,
    failure_explanation=['Historical test required simultaneous same-owner actions; preserved under exact historical pump plus separate serial-policy coverage.',
        'Three native-method tests require vLLM 0.30.0 and passed in that environment with CUDA disabled.',
        'An intermediate test erroneously required an unstarted sibling to report failure; that failed observation is retained.'],
    caveat='CPU ordering/ownership and native-method checks only; no GPU latency, independent numerical correctness or G1/G2 acceptance.')
''' +code[end:]
replace('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md','D693_GPU_OWNER_DISPATCH_QUALIFICATION.md')
replace("files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json')])", """versions={'initial_transfer_pressure.py':initial.encode(),
    'intermediate_transfer_pressure.py':intermediate.encode(),
    'final_transfer_pressure.py':current.encode()}
with tarfile.open(RAW/'test_source_versions.tar.gz','x:gz') as bundle:
    for name,content in versions.items():
        clean(content);info=tarfile.TarInfo(name);info.size=len(content);info.mtime=0
        bundle.addfile(info,io.BytesIO(content))
with tarfile.open(RAW/'test_source_versions.tar.gz') as bundle:
    for name,content in versions.items():assert bundle.extractfile(name).read()==content
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log'),RAW/'test_source_versions.tar.gz'])
files += [ROOT/name for name in changed]""")
replace("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']",
    "files += [doc,RAW.parent/'d668_20261018/close.py',RAW.parent/'d663_20261018/qualify.py',RAW.parent/'d612_20261017/publish.py']")
replace('d612_reused_parent_closed_log_diagnosis_v1','d693_single_owner_gpu_dispatch_qualification_v1')
replace('diagnosis=diagnosis,protected=protected,','qualification=qualification,protected=protected,')
replace('production_changed=False','production_changed=True')
replace("names=[str(doc.relative_to(ROOT)),'docs/ieee_tc/EXECUTION_STATUS.md']",
    "names=[str(doc.relative_to(ROOT)),'docs/ieee_tc/EXECUTION_STATUS.md',*changed]")
replace('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
    'tc: qualify per-owner final GPU preparation dispatch without sibling epoch races (D693)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D693 explicit candidate publication expansion checked; nothing published.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no args or --check-only')
