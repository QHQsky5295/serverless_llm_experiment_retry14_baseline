#!/usr/bin/env bash
set -euo pipefail
# Reuse D138 exact-identity / empty-domain cleanup with actual D138 identity.
date -Is
test "$(systemctl --user show primelora-tc-svc-1f05557629544bcb813b18787c26af99.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d138-full1-metadata-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 317073ed84204f1881b2f9d124f71680
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d138-full1-metadata-20261001.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
