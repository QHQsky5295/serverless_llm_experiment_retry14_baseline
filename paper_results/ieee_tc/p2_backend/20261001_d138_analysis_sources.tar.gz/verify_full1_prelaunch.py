"""Reuse D137 prelaunch gates for the unchanged D118 3B Full configuration."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight
from faaslora.runtime_configuration import resolve_facade_lora_capacity
from faaslora.datasets.workload_generator import FrozenReplayPlan

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d138_20261001'
previous = root/'results/ieee_tc/p2_backend_qualification/d137_20261001'
prior_3b = root/'results/ieee_tc/p2_backend_qualification/d118_20260930'
expected_commit = '2608d027d82df5a79719153e114ff06a7a70679b'
prior_runtime = '233ccc29bfe016950efe73331739e0399cd9e81f'
prior_3b_runtime = '48f808abaf6defe16da0329a07d7af197200b72c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected_commit
dirty = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty) <= {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'}, dirty
subprocess.run(['git','diff','--exit-code',prior_runtime+'..'+expected_commit,'--','faaslora','scripts','tests'],cwd=root,check=True)
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old_path = prior_3b/'3b_main_config_full11.yaml'
new_path = raw/'3b_main_config_full1.yaml'
assert digest(old_path) == '6da8d8964cd54d00cfb1589bb0c8a4cdefca0916c2cecc6ebb6be7749d9e6dec'
old, new = [yaml.safe_load(path.read_text()) for path in (old_path,new_path)]
for config in (old,new):
    assert config['workload']['total_requests'] == 4000
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
assert old == new, 'configuration differs beyond three fresh owned paths'
assert not (raw/'3b_full_w0_full1/launch.json').exists()
assert not (raw/'3b_nvme_full1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d138-3b-full1/tc_ieee_full').exists()
before = json.loads((previous/'prelaunch_verification.json').read_text())
refs = dict(before['source_sha256'])
for name, expected in refs.items():
    path = Path(name) if name.startswith('/') else root/name
    assert digest(path) == expected, name
prior_3b_result = root/'paper_results/ieee_tc/p2_backend/20260930_d118_3b_full_w0_full11.json'
assert digest(prior_3b_result) == 'ff39d2b0fbb952f6bf1d0601115eff9888895b13d0a9b6c2d062c2fbef376eaf'
current_7b_result = root/'paper_results/ieee_tc/p2_backend/20261001_d137_7b_full_w0_full1.json'
assert digest(current_7b_result) == '9d6e028dd9caa49283510f4db585e79170067addc70345f0397f95f27b5bb04d'
model = resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras'] == 32 and model['runtime_concurrency_cap'] == 8
assert model['max_num_seqs'] == 8 and model['max_loras'] == 8
for key in ('ieee_service_profile','ieee_preparation_profile'):
    binding = new['resource_coordination'][key]
    assert digest(Path(binding['path'])) == binding['sha256']
trace_path = Path('/home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260509_134259_llama32_3b_main_s8/shared_artifacts/llama32_3b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json')
subset_path = trace_path.with_name(trace_path.name.replace('_trace.json','_adapter_subset.json'))
assert digest(trace_path) == '4ea5d026da3820301e753ad6b03ea776e25a5c3f01921933bd124598eb26018d'
assert digest(subset_path) == '6c5fc286e3cef00efdd6b84e26c841f3b09d20b17a57b8f6a394b8d27bb1e86b'
plan = FrozenReplayPlan.load(trace_path, profile='W0')
trace = plan.identity()
assert trace['count'] == trace['source_count'] == 4000 and trace['rate_scale'] == 1
subset = dict(path=str(subset_path),sha256=digest(subset_path))
changes = subprocess.check_output(['git','diff','--name-only',prior_3b_runtime+'..'+expected_commit,'--','faaslora','scripts'],cwd=root,text=True).splitlines()
for path in [raw/name for name in ('3b_main_config_full1.yaml','run_3b_full_w0_full1.sh',
    'activate_services_full1.sh','check_health.sh','verify_full1_prelaunch.py','prepare_full1.sh')]+[old_path,prior_3b_result,current_7b_result,trace_path,subset_path]:
    refs[str(path)] = digest(path)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
resources = preflight([root,raw],32*1024**3)
assert resources['preflight_pass'], resources['issues']
receipt = dict(kind='d138_3b_full_prelaunch_v1',time_unix=time.time(),
    run='d138_3b_full_w0_full1',evidence_commit=expected_commit,
    runtime_source_commit=expected_commit,source_change='Current shared candidate unchanged since D137; model-specific requalification against D118',
    expected_source_changes=[],same_configuration_except_owned_paths=True,
    diagnostic_instrumentation=False,formal_performance_result=False,
    source_sha256=refs,protected=protected,resource_preflight=resources,trace=trace,subset=subset,
    replay_scope='ordinary_full_4000',diagnostic_prefix_count=None,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    comparison='Single ordinary 3B Full at current candidate; D118 is earlier code, not current qualification; no isolated multi-change causal estimate or formal SLO claim',
    prior_3b_runtime=prior_3b_runtime,changed_paths_since_prior_3b=changes,
    detailed_cpu_profiler=False,
    pending_metric_reconciliation='Preserve controller completion and outer terminal separately',
    reused_initialization='D88/D89; identical D118 3B parent config except owned paths, no new profiles/data/cache',
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),
    sha256=digest(raw/'prelaunch_verification.json'),protected=147,source_refs=len(refs),
    population=4000,same_config=True,resource_pass=True,formal=False)))
