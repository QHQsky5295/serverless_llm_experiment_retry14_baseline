#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
# Prepared during replay, NEVER execute before terminal/physical cleanup.
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d138_20261001
test -s "$raw/3b_full_w0_full1/launch.json"
test "$(systemctl --user show primelora-tc-svc-1f05557629544bcb813b18787c26af99.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
jq -e '.native_gpu_context_release_confirmed == true and .service_path_removed == true' "$raw/3b_full_w0_full1/launch.json"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 primelora-artifact-174 bash -s < "$raw/stop_services_full1.sh" > "$raw/stop_services_full1.log" 2>&1
