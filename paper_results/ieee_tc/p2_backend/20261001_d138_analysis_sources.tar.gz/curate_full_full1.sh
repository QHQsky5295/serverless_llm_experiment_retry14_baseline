#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d138_20261001
unit=primelora-d138-full1-curate-20261001.scope
test "$(systemctl --user show primelora-tc-svc-1f05557629544bcb813b18787c26af99.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show primelora-d138-full1-project-20261001.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_curation_scope.txt"
/usr/bin/time -v -o "$raw/full_full1_curation_time.txt" \
  /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/summarize_full_full1.py" > "$raw/full_full1_curation.log" 2>&1
exec /usr/bin/time -v -o "$raw/full_full1_failure_time.txt" \
  /usr/bin/python3 "$raw/collect_full1_failure_breakdown.py" > "$raw/full_full1_failure.log" 2>&1
