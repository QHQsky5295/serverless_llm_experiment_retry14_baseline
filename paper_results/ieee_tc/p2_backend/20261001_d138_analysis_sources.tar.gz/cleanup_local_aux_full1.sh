#!/usr/bin/env bash
set -euo pipefail
# Reuse D138 exact-identity / empty-domain cleanup; only D138 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-1f05557629544bcb813b18787c26af99.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-4590b9aa7523492da77c0f2ed966ea6f.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = f2dee3270e6246c1970e1510d60207c4
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-4590b9aa7523492da77c0f2ed966ea6f.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
