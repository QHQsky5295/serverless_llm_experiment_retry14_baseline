"""Seal D349 offline results, reusing D336 evidence and lifecycle checks."""
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

own_preflight=p.preflight([p.ROOT],4*p.GIB)
assert own_preflight['preflight_pass'], own_preflight['issues']
raw = Path(__file__).resolve().parent
out = p.ROOT/'paper_results/ieee_tc/p2_backend/d349_full_w0'
offline = json.loads((raw/'offline_execution_receipt.json').read_text())
assert offline['pass_all']
identity = offline['identity']
assert p.scope_still_owned(identity)
group = Path(identity['path'])
assert not p.owned_pids(group)
resources = {key:(group/key).read_text() for key in ['memory.peak','memory.events',
    'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events']}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'analysis_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,empty_before_stop=True,after='inactive'),f,indent=2)
for subdir in ['validated1','context1']:
    directory = out/subdir
    manifest = json.loads((directory/'manifest.json').read_text())
    for name,digest in manifest['outputs'].items():
        assert p.digest(directory/name) == digest
    for ref in manifest['source_refs']:
        assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
paths = [raw/name for name in ['launch_gate1.json','remote_start.log','remote_health.json',
    'remote_stop.log','remote_stop.json','local_cleanup.json','collection_scope_cleanup.json',
    'analysis_cleanup.json','audit1.log','offline_execution_receipt.json',
    'completion_receipt.json','collect_closure.py','run_audit.py',
    'start_remote.sh','stop_remote.sh','check_remote_health.py',
    'closure_checkpoint.py','prelaunch_binding.json','launch_gate.py']]
paths += [raw/'7b_full_w0/launch.json',raw/'7b_full_w0/launch.launch/physical_deployment/summary.json']
paths += [p.ROOT/'scripts/ieee_tc/analyze_d297_full.py',p.ROOT/'scripts/ieee_tc/check_d299_full_context.py']
assert len({x.name for x in paths}) == len(paths)
from scripts.ieee_tc.analyze_d297_full import lifecycle_gaps
life = {}
for name in ('d336', 'd346', 'd349'):
    directory = p.ROOT/f'results/ieee_tc/p2_backend_qualification/{name}_20261008/7b_full_w0/launch.launch/physical_deployment'
    sp, dp = directory/'summary.json', directory/'deployment.json'
    summary, deployment = json.loads(sp.read_text()), json.loads(dp.read_text())
    row = lifecycle_gaps(summary, deployment)
    envelope = sum(spans[-1][1]-spans[0][0] for spans in summary['device_intervals'].values())
    assert abs(envelope-row['released_gap_gpu_s']-row['observed_gpu_s']) < 1e-6
    row.update(envelope_gpu_s=envelope, window_gpu_seconds=summary['window_gpu_seconds'],
        sources=[dict(path=str(path),sha256=p.digest(path)) for path in (sp,dp)])
    life[name] = row
contrasts = {}
for reference in ('d336', 'd346'):
    delta = life['d349']['observed_gpu_s']-life[reference]['observed_gpu_s']
    boundary = life['d349']['envelope_gpu_s']-life[reference]['envelope_gpu_s']
    reduced_gaps = life[reference]['released_gap_gpu_s']-life['d349']['released_gap_gpu_s']
    assert abs(delta-boundary-reduced_gaps) < 1e-6
    contrasts[reference] = dict(candidate_minus_reference_gpu_s=delta,
        envelope_boundary_delta_gpu_s=boundary,reduced_release_gaps_gpu_s=reduced_gaps)
with (out/'lifecycle.json').open('x') as f:
    json.dump(dict(runs=life,contrasts=contrasts,causal_savings=None,confidence_interval=None,
        caveat='Observed physical identity only, not a causal effect or formal G1/G2 qualification.'),f,indent=2)

# Small retained CSV projections: all phases, all length groups, both references.
# No inference, reconstructed missing fields, per-request pseudo-replication or CI.
import csv
from collections import Counter
from statistics import mean
from scripts.ieee_tc.analyze_d297_full import percentile
data, audits, phase_rows, length_rows, refs = {}, {}, [], [], []
for name in ('d336','d346','d349'):
    directory=p.ROOT/f'paper_results/ieee_tc/p2_backend/{name}_full_w0/validated1'
    manifest=json.loads((directory/'manifest.json').read_text())
    for filename in ('audit.json','requests.csv','control_audit.json'):
        assert p.digest(directory/filename)==manifest['outputs'][filename]
        refs.append(dict(path=str(directory/filename),sha256=p.digest(directory/filename)))
    refs.append(dict(path=str(directory/'manifest.json'),sha256=p.digest(directory/'manifest.json')))
    audits[name]=json.loads((directory/'audit.json').read_text())
    with (directory/'requests.csv').open() as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==4000 and [r['request_id'] for r in rows]==[f'req_{i:05d}' for i in range(4000)]
    data[name]=rows
    def summarize(rs):
        counts=Counter(r['outcome'] for r in rs)
        assert len(rs)>0 and all(r['success']=='True' for r in rs)
        return dict(n=len(rs),timing_joint_pass=counts['timing_pass'],
            timing_joint_miss=len(rs)-counts['timing_pass'],
            ttft_miss=sum(r['ttft_pass']=='False' for r in rs),
            tpot_miss=sum(r['tpot_pass']=='False' for r in rs),
            mean_ttft_ms=mean(float(r['ttft_s'])*1000 for r in rs),
            p95_ttft_ms=percentile([float(r['ttft_s'])*1000 for r in rs],.95),
            mean_tpot_ms=mean(float(r['tpot_s'])*1000 for r in rs),
            p95_tpot_ms=percentile([float(r['tpot_s'])*1000 for r in rs],.95),
            mean_arrival_to_admission_ms=mean(float(r['arrival_to_admission_s'])*1000 for r in rs))
    for phase in range(8):
        phase_rows.append(dict(run=name,phase=phase+1,**summarize(rows[phase*500:(phase+1)*500])))
    for lo,hi in ((2,32),(33,128),(129,256)):
        selected=[r for r in rows if lo<=int(r['token_count'])<=hi]
        assert selected
        length_rows.append(dict(run=name,output_group=f'{lo}-{hi}',**summarize(selected)))
    assert sum(r['timing_joint_pass'] for r in phase_rows if r['run']==name)==audits[name]['timing']['timing_joint_pass_count']
comparisons={}
metric_rows=[]
for reference in ('d336','d346'):
    left,right=data[reference],data['d349']
    for a,b in zip(left,right):
        assert all(a[k]==b[k] for k in ('request_id','adapter_id','prompt_tokens','token_count','canonical_prompt_sha256'))
    changes=[a['request_id'] for a,b in zip(left,right) if a['completion_token_ids_sha256']!=b['completion_token_ids_sha256']]
    comparisons[reference]=dict(output_hash_change_count=len(changes),changed_request_ids=changes,
        timing_joint_difference_pp=100*(audits['d349']['timing']['joint_upper_bound']-audits[reference]['timing']['joint_upper_bound']))
    for metric in ('physical_gpu_seconds','mean_ttft_ms','p95_ttft_ms','p99_ttft_ms','mean_tpot_ms','p95_tpot_ms','mean_e2e_s'):
        a,b=audits[reference]['stats'][metric],audits['d349']['stats'][metric]
        metric_rows.append(dict(reference=reference,candidate='d349',metric=metric,
            reference_value=a,candidate_value=b,lower_better_change_percent=(a-b)/a*100))
for filename,rows in (('phase_summary.csv',phase_rows),('length_summary.csv',length_rows),('comparison_to_references.csv',metric_rows)):
    with (out/filename).open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
        w.writeheader();w.writerows(rows)
with (out/'development_comparison.json').open('x') as f:
    json.dump(dict(comparisons=comparisons,source_refs=refs,n_correct=None,
        formal_qualification=False,confidence_interval=None,
        caveat='One development replay each; same retained provisional ruler. Input order verified; no causal claim from conditional length/phase groups.'),f,indent=2)

token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in paths:
    assert token and token not in path.read_bytes(), path
archive = out/'closure_evidence.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest() == p.digest(path)
record = dict(kind='d349_complete_development_checkpoint_v1',
    executed_source_commit='54d69e859438b38e8851f9a9cce1f40e9bca3131',
    analysis_tests=90,native_completed=4000,numerical_n_correct=None,formal_qualification=False,
    no_figures=True,archive_sha256=p.digest(archive),
    raw_references=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
    next='Reject D349 as a qualified G1 improvement: timing-only joint 3668/4000, still below unchanged 3800 target. Preserve resource reduction and all regressions; return to retained load/decode evidence before a new first-principles hypothesis. No target sweep, no repeat of D349, no 3B/baselines yet.')
with (out/'evidence.json').open('x') as f:
    json.dump(record,f,indent=2,allow_nan=False)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
own = p.scope_identity(unit)
own_group = Path(own['path'])
with (raw/'closure_seal_scope.json').open('x') as f:
    json.dump(dict(identity=own,resources={key:(own_group/key).read_text() for key in
        ['memory.peak','memory.events','memory.swap.current','cgroup.events']}),f,indent=2)
print(json.dumps(dict(native_complete=4000,archive_bytes=archive.stat().st_size,
    archived_files=len(paths),audit_scope_released=True,lifecycle_contrasts=contrasts)))
