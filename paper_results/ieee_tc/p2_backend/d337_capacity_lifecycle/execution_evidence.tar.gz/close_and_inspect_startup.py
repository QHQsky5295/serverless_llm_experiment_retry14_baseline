"""Close only D337's owned analysis scope; retain startup evidence from existing logs."""
import csv
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from statistics import mean

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend/d337_capacity_lifecycle'
receipt = json.loads((raw/'execution_receipt.json').read_text())
old = receipt['identity']
assert receipt['pass_all'] and p.scope_still_owned(old)
assert not p.owned_pids(Path(old['path']))
resources = {k: (Path(old['path'])/k).read_text() for k in
    ('memory.peak', 'memory.events', 'memory.swap.current', 'cgroup.events')}
subprocess.run(['systemctl', '--user', 'stop', old['unit']], check=True)
assert subprocess.check_output(['systemctl', '--user', 'show', old['unit'],
    '-p', 'ActiveState', '--value'], text=True).strip() == 'inactive'
with (raw/'analysis_cleanup.json').open('x') as f:
    json.dump(dict(identity=old, resources=resources, inactive=True), f, indent=2)

unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])
assert (group/'memory.max').read_text().strip() == str(4*1024**3)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
source = ROOT/'results/ieee_tc/p2_backend_qualification/d336_20261008/7b_full_w0/launch.launch/service.log'
archives = list(dict.fromkeys(re.findall(r'preserved dedicated worker workdir: (.+)', source.read_text())))
intervals = out/'analysis1/d336_intervals.csv'
with intervals.open() as f:
    rows = list(csv.DictReader(f))
pid_replicas = {}
for row in rows:
    pid_replicas.setdefault(int(row['worker_pid']), set()).add(row['replica'])
assert len(pid_replicas) == 11 and all(len(v) == 1 for v in pid_replicas.values())
with (out/'analysis1/d336_activations.csv').open() as f:
    activations = {r['replica']: r for r in csv.DictReader(f)}
sources = [source, intervals, out/'analysis1/d336_activations.csv']
by_pid, duplicates = {}, []
for archive in archives:
    directory = Path(archive)
    log = directory/'worker.log'
    body = log.read_text()
    core = re.findall(r'EngineCore pid=(\d+)\) INFO .* Initializing a V1 LLM engine', body)
    assert len(core) == 1
    pid = int(core[0])
    assert pid in pid_replicas
    replica = next(iter(pid_replicas[pid]))
    a = activations[replica]
    def one(pattern):
        matches = re.findall(pattern, body)
        assert len(matches) == 1, (log, pattern, len(matches))
        return float(matches[0])
    result = dict(worker_pid=pid, replica=replica, category=a['category'],
        activation_s=float(a['end_offset_s'])-float(a['start_offset_s']),
        weight_load_s=one(r'Loading weights took ([0-9.]+) seconds'),
        model_load_s=one(r'Model loading took [0-9.]+ GiB memory and ([0-9.]+) seconds'),
        init_profile_cache_warmup_s=one(r'init engine \(profile, create kv cache, warmup model\) took ([0-9.]+) s'),
        compile_s=one(r'torch.compile took ([0-9.]+) s in total'),
        graph_capture_passes=len(re.findall(r'Graph capturing finished in', body)),
        aot_cache_loaded='Directly load AOT compilation from path' in body,
        checkpoint_prefetch='Prefetching checkpoint files into page cache finished' in body,
        inference_jit_notices=re.findall(r'Triton kernel JIT compilation during inference: ([^.\n]+)', body))
    sources.extend([log, directory/'process.json', directory/'ready.json', directory/'payload.json'])
    if pid in by_pid:
        assert result == {k:v for k,v in by_pid[pid].items() if k != 'source_log'}
        duplicates.append(str(log))
    else:
        by_pid[pid] = dict(result, source_log=str(log))
assert set(by_pid) == set(pid_replicas)
summary = dict(kind='d337_retained_d336_startup_logs_v1', workers=list(by_pid.values()),
    duplicate_archives_checked=duplicates,
    ranges={key: dict(min=min(r[key] for r in by_pid.values()),
        mean=mean(r[key] for r in by_pid.values()), max=max(r[key] for r in by_pid.values()))
        for key in ('activation_s', 'weight_load_s', 'model_load_s', 'init_profile_cache_warmup_s', 'compile_s')},
    caveats=['Log durations may be rounded and are nested: do not add weights/model/compile/init.',
        'JIT notices identify runtime cache-miss paths, not measured stall durations or a causal contribution.',
        'No subtraction between wall-clock log timestamps and native monotonic request times.',
        'Archive engine_dead name also arises on ordinary shutdown; it is not a request failure verdict.'])
with (out/'startup_logs.json').open('x') as f:
    json.dump(summary, f, indent=2)
with (out/'startup_manifest.json').open('x') as f:
    json.dump(dict(sources=[dict(path=str(x), sha256=p.digest(x)) for x in dict.fromkeys(sources)],
        output_sha256=p.digest(out/'startup_logs.json')), f, indent=2)
with (raw/'startup_receipt.json').open('x') as f:
    json.dump(dict(identity=identity, resources={k:(group/k).read_text() for k in
        ('memory.peak', 'memory.events', 'memory.swap.current', 'cgroup.events')}, pass_all=True), f, indent=2)
print(json.dumps(dict(ranges=summary['ranges'], workers=len(by_pid),
    aot_loaded=sum(r['aot_cache_loaded'] for r in by_pid.values()),
    jit_notices=sum(len(r['inference_jit_notices']) for r in by_pid.values()))))
