"""D337 exact-path backup using the existing seal/scope/secrets procedures."""
import ast
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend/d337_capacity_lifecycle'
old = json.loads((raw/'startup_receipt.json').read_text())['identity']
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
resources = {k:(Path(old['path'])/k).read_text() for k in
    ('memory.peak', 'memory.events', 'memory.swap.current', 'cgroup.events')}
subprocess.run(['systemctl', '--user', 'stop', old['unit']], check=True)
assert subprocess.check_output(['systemctl','--user','show',old['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'startup_cleanup.json').open('x') as f:
    json.dump(dict(identity=old, resources=resources, inactive=True), f, indent=2)
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
seal = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = '/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert seal['changed'] == [known] and seal['entry_count'] == 147
assert p.digest(Path(known)) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
analysis = json.loads((out/'analysis1/manifest.json').read_text())
for name, expected in analysis['outputs'].items():
    assert p.digest(out/'analysis1'/name) == expected
for ref in analysis['source_refs']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
startup = json.loads((out/'startup_manifest.json').read_text())
for ref in startup['sources']:
    assert p.digest(Path(ref['path'])) == ref['sha256']
assert p.digest(out/'startup_logs.json') == startup['output_sha256']
paths = [raw/name for name in ('run_analysis.py','analysis1.log','execution_receipt.json',
    'analysis_cleanup.json','close_and_inspect_startup.py','startup_receipt.json',
    'startup_cleanup.json','backup.py')]
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----', data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}', data)
archive = out/'execution_evidence.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f, mode='w:gz') as tar:
    for path in paths:
        check(path.read_bytes())
        tar.add(path, arcname=path.name, recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest() == p.digest(path)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
assert subprocess.check_output(['git','branch','--show-current'], cwd=ROOT,text=True).strip() == 'retry14_continuous_queue_v2'
assert not subprocess.check_output(['git','diff','--cached','--name-only'], cwd=ROOT,text=True).strip()
names = ['docs/ieee_tc/EXECUTION_STATUS.md', 'docs/ieee_tc/D337_CAPACITY_STARTUP_TRADEOFF.md',
    'scripts/ieee_tc/analyze_d297_full.py','tests/test_ieee_tc_decode_overlap.py']
names += [str(path.relative_to(ROOT)) for path in sorted(out.rglob('*')) if path.is_file()]
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()) == set(names)
for name in names:
    data = subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert data == (ROOT/name).read_bytes()
    check(data)
    if name.endswith('.py'): ast.parse(data)
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
            for member in tar.getmembers():
                assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                value = tar.extractfile(member).read()
                check(value)
                if member.name.endswith('.py'): ast.parse(value)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (raw/'backup_commands.log').open('x') as log:
    subprocess.run(['git','commit','-m','Localize D336 capacity trade-off using retained startup and decode evidence'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote = subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head == remote
unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
own = p.scope_identity(unit)
with (raw/'backup_receipt.json').open('x') as f:
    json.dump(dict(head=head,remote=remote,staged_paths=names,protected_raw=seal,
        secret_check_pass=True,user_manifest_not_staged=True,identity=own,
        resources={k:(Path(own['path'])/k).read_text() for k in
            ('memory.peak','memory.events','memory.swap.current','cgroup.events')}),f,indent=2)
print(json.dumps(dict(head=head,remote=remote,paths=len(names),pass_all=True)))
