"""Reuse D129 bounded curator for D177, without assuming the new outcome; run after cleanup.

Read only the bounded jq streaming projection, never whole-load the full request JSON tree.
Keep failed requests and separate execution/measurement from qualification.
"""
import json
import math
import sys
from collections import Counter
from pathlib import Path
from statistics import mean

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.metrics.metrics_collector import NativeV1TokenTimeline

raw = ROOT/'results/ieee_tc/p2_backend_qualification/d177_20261003'
run = raw/'7b_full_w0_full1'
evidence = run/'launch.launch'
out = ROOT/'paper_results/ieee_tc/p2_backend/20261003_d177_7b_full_w0_full1.json'
projection = raw/'full_full1_request_projection.json'
original = raw/'7b_outputs_full1/experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d177_7b_full_w0_full1.json'
assert not out.exists()
load = lambda path: json.loads(path.read_text())
def compare_request_contracts(previous, current):
    """Reuse D175's ID-sorted audit; retain output changes, never select winners."""
    old = {r['request_id']: r for r in previous}
    new = {r['request_id']: r for r in current}
    assert len(old) == len(previous) and len(new) == len(current)
    assert set(old) == set(new), 'different offered request populations'
    fields = [
        'adapter_id', 'scheduled_arrival_offset_s', 'generation_contract',
        'canonical_prompt_sha256', 'canonical_prompt_tokens', 'input_tokens',
        'source_expected_output_tokens', 'requested_completion_tokens',
        'completion_tokens', 'output_tokens', 'completion_token_source',
        'completion_token_ids_sha256', 'timing_contract',
        'native_token_timing.native_prompt_token_ids_sha256',
        'native_token_timing.actual_prompt_tokens',
        'external_arrival_timing.source_item_sha256',
    ]
    def required(row, path):
        for key in path.split('.'):
            row = row[key]  # Missing provenance is an error, not equal nulls.
        assert row is not None, path
        return row
    audit = {}
    for field in fields:
        changed = [key for key in sorted(old)
                   if required(old[key], field) != required(new[key], field)]
        audit[field] = dict(equal_requests=len(old)-len(changed),
                            changed_request_ids=changed)
    return dict(requests=len(old), request_ids_identical=True, fields=audit,
                output_identity_is_numerical_adapter_proof=False,
                causal_isolation=False,
                caveat='Same-input checks in one replay per version do not establish statistical causality; '
                       'n=1 per version, no CI or formal SLO/performance qualification.')

assert 'Exit status: 0' in (raw/'full_full1_projection_time.txt').read_text()
assert projection.stat().st_size < 256 * 1024**2
preliminary = load(raw/'full_full1_preliminary.json')
compact_outcome = raw/'full_full1_main_outcome_projection4.json'
assert 0 < compact_outcome.stat().st_size < 128 * 1024**2
assert p.digest(compact_outcome) == preliminary['metadata_compact_sha256']
assert p.digest(evidence/'physical_deployment/main_outcome.json') == preliminary['metadata_source_sha256']
assert original.stat().st_size == preliminary['normal_source_stat']['bytes']
assert original.stat().st_ino == preliminary['normal_source_stat']['inode']
assert original.stat().st_mtime_ns == preliminary['normal_source_stat']['mtime_ns']
rows = load(projection)['requests']
outcome = load(compact_outcome)
launch = load(run/'launch.json')
physical = load(evidence/'physical_deployment/summary.json')
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
good = [r for r in rows if r['success'] is True]
assert len(good) == preliminary['population']['success']  # Cross-source check, not a required outcome.
assert outcome['run_completed'] and outcome['error'] is None
assert not outcome['formal_comparison_qualified'] and not outcome['interrupted_replays']
assert outcome['cleanup']['complete'] and not outcome['cleanup_errors'] and not outcome['measurement_errors']
assert outcome['cleanup']['inventory_after']['allocated_file_bytes'] == 0
assert all(not Path(r['path']).exists() for r in outcome['cleanup']['roots'])
assert all(r['released'] for r in physical['allocation_journals'])
assert not physical['open_lease_ids'] and physical['measurement_complete']
assert not physical['eligible_correctness'] and physical['n_correct'] is None
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']

def jsonlines(path):
    with path.open() as handle:
        for line in handle:
            yield json.loads(line)

terminals = list(jsonlines(evidence/'physical_deployment/request_terminals.jsonl'))
replay = list(jsonlines(evidence/'replay.jsonl'))
ingress = list(jsonlines(evidence/'service_ingress.jsonl'))
submitted = [r for r in replay if r['event'] == 'request_submitted']
assert len(terminals) == len(submitted) == 4000
assert {r['request_id'] for r in rows} == {r['request_id'] for r in terminals} == {r['request_id'] for r in submitted}
by_request = {r['request_id']: r for r in rows}
assert all(r['success'] == by_request[r['request_id']]['success'] for r in terminals)
assert all(r['native_contract_matched'] for r in terminals if r['success'])
for t in terminals:
    if t['success']:
        r = by_request[t['request_id']]
        assert r['completion_tokens'] == t['target_tokens']
        assert r['completion_token_ids_sha256'] == t['completion_token_ids_sha256']
        assert r['canonical_prompt_sha256'] == t['canonical_prompt_sha256']

remote = list(jsonlines(raw/'remote_7b_full1_transfers.jsonl'))
transfers = outcome['remote_transfers']
assert len(remote) == len(transfers) > 0
by_uuid = {r['transfer_id']: r for r in remote}
assert len(by_uuid) == len(remote) and set(by_uuid) == {r['http_transfer_id'] for r in transfers}
for r in transfers:
    peer = by_uuid[r['http_transfer_id']]
    assert peer['artifact_id'] == r['artifact_id']
    assert not peer['pack_performed'] and not peer['temporary_created']
    if r['state'] == 'published':
        assert peer['bytes_written'] == r['transferred_bytes']
        assert r['content_verified'] and r['published_archive_verified']
        assert r['payload_bytes_verified'] == r['payload_bytes_expected']
    else:
        assert r['state'] == 'not_published' and r['content_verified'] is False
        assert 0 <= r['transferred_bytes'] <= peer['bytes_written']
        assert 'payload_bytes_verified' not in r or r['payload_bytes_verified'] is None
    assert peer['clock_id'] == load(raw/'health_7b.json')['clock_id']

samples = 0
peak = swap = 0
available = float('inf')
events = Counter()
resource_warnings = 0
for r in jsonlines(evidence/'watchdog.jsonl'):
    if r['event'] != 'resource_sample':
        continue
    samples += 1
    resource_warnings += bool(r['decision']['warning'])
    assert not r['decision']['abort_reasons']
    peak = max(peak, r['service']['memory.peak'])
    swap = max(swap, r['service']['memory.swap.current'])
    available = min(available, r['host']['available_bytes'])
    for k in ('high', 'max', 'oom', 'oom_kill'):
        events[k] = max(events[k], r['service']['memory.events'].get(k, 0))

failures = Counter(r.get('failure_observation', {}).get('exception_type') or r.get('error') or 'unspecified_returned_failure'
                   for r in rows if not r['success'])
metrics = {}
for key in ('overall_ttft_ms', 'overall_e2e_ms', 'dispatch_admission_wait_ms',
            'runtime_slot_wait_ms', 'service_ttft_ms', 'vllm_ttft_ms',
            'pre_runtime_service_shell_ms', 'parent_rpc_overhead_ms', 'tpot_ms',
            'dispatch_window_wait_ms', 'arrival_release_lateness_ms', 'lora_io_ms',
            'parent_rpc_response_pickup_delay_ms', 'parent_rpc_thread_resume_delay_ms'):
    v = sorted(r[key] for r in good if isinstance(r.get(key), (int, float)) and math.isfinite(r[key]))
    metrics[key] = dict(n=len(v), mean=mean(v) if v else None,
                       p50_type1=v[math.ceil(.5*len(v))-1] if v else None,
                       p95_type1=v[math.ceil(.95*len(v))-1] if v else None,
                       p99_type1=v[math.ceil(.99*len(v))-1] if v else None)
deployment = load(evidence/'physical_deployment/deployment.json')
timing_errors = Counter()
timing_violations = []
native_stages = {k: [] for k in (
    'admission_to_engine_dispatch_ms', 'engine_entry_to_queue_ms',
    'native_engine_queue_ms', 'native_prefill_ms', 'native_decode_ms',
    'worker_completion_notification_ms', 'worker_to_controller_completion_ms')}
single_token = 0
confirmed_tiers = Counter()
for r in good:
    t = r['native_token_timing']
    assert r['generation_contract'] == 'fixed_length_greedy_v1'
    assert r['timing_contract'] == 'ieee_tc_native_v1'
    assert r['completion_token_source'] == 'vllm_token_ids'
    assert r['output_contract_match'] is True
    n = r['completion_tokens']
    assert n == r['output_tokens'] == r['requested_completion_tokens'] == t['native_output_tokens']
    check = NativeV1TokenTimeline.service_breakdown(t,
        admitted_at=t['controller_admitted_monotonic_s'],
        completed_at=t['controller_completed_monotonic_s'],
        clock_id=physical['clock_id'])
    ref = r['retained_reference_evidence']
    admission = ref['source_admission']
    assert ref['confirmed_dispatch_snapshot'] is True
    assert admission['kind'] == 'selected_source_admission_v1'
    assert admission['clock_id'] == physical['clock_id']
    assert 0 < admission['admitted_monotonic_s'] <= t['native_dispatch_monotonic_s']
    tier = r['readiness_tier_before_dispatch']
    assert tier in ('gpu', 'host', 'nvme', 'remote')
    assert admission['source']['tier'] == tier
    confirmed_tiers[tier] += 1
    arrival = deployment['arrival_start_s'] + r['scheduled_arrival_offset_s']
    errors = {
        'user_ttft_ms': abs(r['overall_ttft_ms'] - (t['native_first_token_monotonic_s']-arrival)*1000),
        'controller_result_e2e_ms': abs(r['overall_e2e_ms'] - (t['controller_completed_monotonic_s']-arrival)*1000),
        'dispatch_ms': abs(r['dispatch_admission_wait_ms'] - (t['controller_admitted_monotonic_s']-arrival)*1000),
        'service_decomposition_ms': abs(r['service_e2e_ms']-sum(check[k] for k in native_stages)),
        'dispatch_decomposition_ms': abs(r['dispatch_admission_wait_ms']-sum(r[k] for k in
            ('dispatch_window_wait_ms','runtime_slot_wait_ms','arrival_release_lateness_ms'))),
    }
    if n > 1:
        errors['tpot_ms'] = abs(r['tpot_ms'] - (t['native_last_token_monotonic_s']-t['native_first_token_monotonic_s'])*1000/(n-1))
    else:
        single_token += 1
        assert r['tpot_ms'] is None and t['native_tpot_ms'] is None
    for k, value in errors.items():
        assert math.isfinite(value), (r['request_id'], k, value)
        if value > 1.0:
            timing_violations.append(dict(request_id=r['request_id'], metric=k,
                error_ms=value, tolerance_ms=1.0, reference_arrival_s=arrival,
                scheduled_arrival_offset_s=r['scheduled_arrival_offset_s']))
        timing_errors[k] = max(timing_errors[k], value)
    for k in native_stages:
        native_stages[k].append(check[k])
native_metrics = {k: dict(n=len(v), mean=mean(v) if v else None,
                         p95_type1=sorted(v)[math.ceil(.95*len(v))-1] if v else None,
                         p99_type1=sorted(v)[math.ceil(.99*len(v))-1] if v else None)
                  for k,v in native_stages.items()}
retries = [r.get('prior_routing_attempt_count', 0) for r in good]
mechanisms = outcome['mechanism_events']
preliminary = load(raw/'full_full1_preliminary.json')
assert preliminary['population']['success'] == len(good)
quarantines = mechanisms['_ieee_runtime_quarantine_events']
assert all(r['state'] == 'released' for r in quarantines)
assert len({r['instance_id'] for r in quarantines}) == len(quarantines)
for r in quarantines:
    assert r['started_monotonic_s'] <= r['drained_monotonic_s'] <= r['released_monotonic_s']
quarantine_durations = sorted(r['released_monotonic_s']-r['started_monotonic_s'] for r in quarantines)
zero_ready = [r for r in mechanisms['_ieee_control_events']
              if r.get('ready_instances') == 0 and r.get('queue_depth', 0) > 0]
before = load(raw/'prelaunch_verification.json')
for name, expected in before['source_sha256'].items():
    path = Path(name) if name.startswith('/') else ROOT/name
    assert p.digest(path) == expected, name
assert physical['n_native_contract_complete'] == len(good)
assert math.isclose(sum(physical['window_gpu_seconds'].values()), physical['gpu_seconds'], abs_tol=1e-6)
assert len(good) + sum(failures.values()) == 4000
assert launch['service_returncode'] == launch['replay_returncode'] == launch['watchdog_returncode'] == 0
outer_ms, completion_gaps_ms = [], []
all_terminal_ms, failed_terminal_ms = [], []
for terminal in terminals:
    r = by_request[terminal['request_id']]
    arrival = deployment['arrival_start_s'] + r['scheduled_arrival_offset_s']
    terminal_ms = (terminal['at'] - arrival) * 1000
    assert terminal_ms >= 0
    all_terminal_ms.append(terminal_ms)
    if not terminal['success']:
        failed_terminal_ms.append(terminal_ms)
        continue
    controller = r['native_token_timing']['controller_completed_monotonic_s']
    assert terminal['at'] >= controller
    outer_ms.append((terminal['at'] - arrival) * 1000)
    completion_gaps_ms.append((terminal['at'] - controller) * 1000)
assert len(all_terminal_ms) == 4000 and len(failed_terminal_ms) == sum(failures.values())
assert len(outer_ms) == len(completion_gaps_ms) == len(good)
def summary_ms(values):
    v = sorted(values)
    return dict(n=len(v), mean=mean(v) if v else None,
                p95_type1=v[math.ceil(.95*len(v))-1] if v else None,
                p99_type1=v[math.ceil(.99*len(v))-1] if v else None)
completion_boundaries = dict(controller_result='native_token_timing.controller_completed_monotonic_s',
    outer_terminal='request_terminals.jsonl:at after reservation/global admission release',
    client_response_observed=False,
    population_note='Controller/outer gap and internal E2E are success-only; all/failed terminal outcome fields are separately labeled, not successful service latency.',
    all_terminal_outcome_latency_ms=summary_ms(all_terminal_ms),
    failed_terminal_outcome_latency_ms=summary_ms(failed_terminal_ms),
    internal_outer_terminal_latency_ms=summary_ms(outer_ms),
    controller_to_outer_terminal_ms=summary_ms(completion_gaps_ms),
    caveat='Neither internal event is client response receipt; raw controller E2E unchanged.')
cancellation_records = {}
for key in ('_ieee_residency_epochs','_ieee_file_preparation_plans','_ieee_gpu_preparation_plans'):
    assert not any(r.get('state') == 'failed' for r in mechanisms[key]), key
    cancellation_records[key] = [
        dict(scalar_fields={k:v for k,v in r.items() if v is None or isinstance(v,(str,bool,int,float))},
             record_keys=sorted(r), non_scalar_keys=sorted(k for k,v in r.items()
                 if v is not None and not isinstance(v,(str,bool,int,float))))
        for r in mechanisms[key] if r.get('state') == 'cancelled']
    assert all(r['scalar_fields']['error_type'] == 'CancelledError'
               for r in cancellation_records[key]), key
last_terminal = max(r['at'] for r in terminals)
cancellation_timeline = [
    dict(target_replica=r['target_replica'], started_at=r['started_at'],
         terminal_at=r['terminal_at'], terminal_minus_last_request_s=r['terminal_at']-last_terminal)
    for r in mechanisms['_ieee_residency_epochs'] if r.get('state') == 'cancelled']
# Preserve any unpublished transfers and associate actual I/O/movement evidence.
# Do not transplant a previous run's timeout explanation to this run.
unpublished_evidence = []
contract = outcome['coordination_after_shutdown']['ieee_full_launch_contract']
assert contract['request_deadline_origin'] == 'planned_arrival'
for transfer in transfers:
    if transfer['state'] == 'published':
        continue
    pressure = [r for r in outcome['transfer_pressure']
        if r['adapter_id'] == transfer['artifact_id']
        and r['file_owner_id'] == transfer['local_source_owner_id']
        and r['source_tier'] == 'remote' and r['target_tier'] == 'nvme'
        and r.get('io_started_at', math.inf) <= transfer['loading_started_monotonic_s']
        and r.get('io_joined_at', -math.inf) >= transfer['client_completed_monotonic_s']]
    jobs = [r for r in outcome['coordination_after_shutdown']['ieee_movements']
        if r['key'][:3] == [transfer['local_source_owner_id'], 'nvme', transfer['artifact_id']]
        and r['created_at'] <= transfer['loading_started_monotonic_s'] <= r['finished_at']]
    assert len(pressure) == len(jobs) == 1
    pressure, job = pressure[0], jobs[0]
    assert pressure['clock_id'] == transfer['loading_clock_id'] == physical['clock_id']
    subscriptions = []
    for subscription in job['subscriptions'].values():
        metadata = subscription['metadata']
        plan_id = metadata.get('plan_id')
        request_id = plan_id.removeprefix('request:') if isinstance(plan_id,str) and plan_id.startswith('request:') else None
        request = by_request[request_id] if request_id is not None else None
        arrival = deployment['arrival_start_s'] + request['scheduled_arrival_offset_s'] if request else None
        deadline = arrival + contract['request_timeout_s'] if arrival is not None else None
        withdrawn = subscription.get('withdrawn_at')
        subscriptions.append(dict(metadata=metadata, request_id=request_id,
            planned_arrival_s=arrival, protection_deadline_s=deadline,
            loading_start_after_arrival_s=transfer['loading_started_monotonic_s']-arrival if arrival is not None else None,
            withdrawal_after_deadline_ms=(withdrawn-deadline)*1000 if withdrawn is not None and deadline is not None else None,
            request_success=request['success'] if request else None,
            request_failure_observation=request.get('failure_observation') if request else None))
    cancelled = pressure['operation_outcome'] == job['state'] == 'cancelled' and pressure.get('caller_cancelled') is True
    sole_demand_timeout = (cancelled and len(subscriptions)==1
        and subscriptions[0]['metadata'].get('trigger_reason')=='demand'
        and subscriptions[0]['request_success'] is False
        and (subscriptions[0]['request_failure_observation'] or {}).get('exception_type')=='TimeoutError')
    archive_verified = transfer.get('published_archive_verified') is True
    unpublished_evidence.append(dict(transfer=transfer, pressure=pressure, job=job,
        subscriptions=subscriptions, sole_demand_timeout_supported=sole_demand_timeout,
        archive_verified=archive_verified,
        interpretation=('Demand job cancelled with sole subscriber returning TimeoutError; ' if sole_demand_timeout else
            'Cause not established by sole-demand-timeout criteria; retained all associated records; ')
            + ('received archive verified but content not published.' if archive_verified else
               'no verified received archive; transfer outcome retained, not called successful delivery.')))
planning_events = outcome['planning_cpu_events']
assert planning_events, 'D130 mechanism receipt required, not inferred from configuration'
planning_by_operation = {}
expected_cgroup = '0::/user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-svc-f640ab4509df462f9aa7ab5b3ad3161e.scope'
expected_affinity = list(range(4, 24)) + list(range(28, 48))
for operation in sorted({r['operation'] for r in planning_events}):
    assert operation in ('owned_execution_epoch', 'validate_execution', 'validate_execution_bundle', 'initialized_gpu_objective')
    operation_rows = [r for r in planning_events if r['operation'] == operation]
    receipt_rows = [r for r in operation_rows if r['state'] in ('completed', 'cancelled_result_discarded')]
    phases = {k: [] for k in ('parent_detach_ms', 'wait_for_planner_turn_ms',
        'submit_to_worker_start_ms', 'worker_wall_ms', 'worker_cpu_ms',
        'worker_finished_to_join_ms', 'captured_to_join_ms')}
    for r in receipt_rows:
        captured, detached, submitted, started, finished, joined = (
            r[k] for k in ('captured_monotonic_s', 'detached_monotonic_s',
                'submitted_monotonic_s', 'worker_started_monotonic_s',
                'worker_finished_monotonic_s', 'joined_monotonic_s'))
        assert captured <= detached <= submitted <= started <= finished <= joined
        assert r['cgroup'] == expected_cgroup and r['cpu_affinity'] == expected_affinity
        values = dict(parent_detach_ms=(detached-captured)*1000,
            wait_for_planner_turn_ms=(submitted-detached)*1000,
            submit_to_worker_start_ms=(started-submitted)*1000,
            worker_wall_ms=(finished-started)*1000,
            worker_cpu_ms=r['worker_cpu_seconds']*1000,
            worker_finished_to_join_ms=(joined-finished)*1000,
            captured_to_join_ms=(joined-captured)*1000)
        for key, value in values.items():
            assert math.isfinite(value) and value >= 0
            phases[key].append(value)
    frozen_validation_ms = []
    execution_objectives_ms = []
    if operation == 'owned_execution_epoch':
        for r in receipt_rows:
            assert r['frozen_execution_validated'] is True
            value = r['frozen_validation_seconds']
            assert math.isfinite(value) and 0 <= value <= r['worker_finished_monotonic_s']-r['worker_started_monotonic_s']
            frozen_validation_ms.append(value*1000)
            assert r['execution_objectives_prepared'] is True
            objective_seconds = r['execution_objectives_seconds']
            assert math.isfinite(objective_seconds) and 0 <= objective_seconds <= r['worker_finished_monotonic_s']-r['worker_started_monotonic_s']
            execution_objectives_ms.append(objective_seconds*1000)
    planning_by_operation[operation] = dict(events=len(operation_rows),
        frozen_validation_ms=summary_ms(frozen_validation_ms),
        execution_objectives_ms=summary_ms(execution_objectives_ms),
        receipt_rows=len(receipt_rows), state_counts=dict(Counter(r['state'] for r in operation_rows)),
        errors=dict(Counter(r.get('error_type') for r in operation_rows if r.get('error_type'))),
        worker_pids=sorted({r['worker_pid'] for r in receipt_rows}),
        input_bytes=sum(r['input_bytes'] for r in receipt_rows),
        output_bytes=sum(r['output_bytes'] for r in receipt_rows),
        worker_cpu_seconds=sum(r['worker_cpu_seconds'] for r in receipt_rows),
        phases_ms={key:summary_ms(values) if values else None for key,values in phases.items()},
        first_event=operation_rows[0], last_event=operation_rows[-1])
planning_diagnostics = dict(events=len(planning_events), by_operation=planning_by_operation,
    caveat='Observed submitted computations only; cancelled callers waiting for the lock have no worker receipt. '
        'CPU stages/bytes are diagnostic, not GPU billing or a causal cross-run speedup.')

# Reuse the already sealed D175 projection; never reparse its original for comparison.
previous_full = ROOT/'paper_results/ieee_tc/p2_backend/20261002_d175_7b_full_w0_full1.json'
previous_projection = ROOT/'results/ieee_tc/p2_backend_qualification/d175_20261002/full_full1_request_projection.json'
assert p.digest(previous_full) == 'e276336bc1c386e011bbc1495019c9c7bbc23c87434ddc3005151bb304a91c5f'
assert 0 < previous_projection.stat().st_size < 128 * 1024**2
previous_projection_sha = p.digest(previous_projection)
assert previous_projection_sha == '0c6e3127c172706cb5cc1d389d52c25d931f3c73977b3b566f919036866170a3'
assert any(Path(ref['path']).resolve() == previous_projection.resolve() and
           ref['sha256'] == previous_projection_sha for ref in load(previous_full)['source_refs'])
previous_rows = load(previous_projection)['requests']
assert len(previous_rows) == 4000 and all(r['success'] is True for r in previous_rows)
# Failure still yields the full failure tables, never an invented matching token contract.
cross_run_contract = (compare_request_contracts(previous_rows, rows) if len(good) == 4000
    else dict(status='not_available_current_contains_failed_requests',
              planned=4000, current_success=len(good), current_failed=4000-len(good),
              formal_qualification=False))
del previous_rows

result = dict(kind='d177_completed_canonical_full_v1', model='7b', workload='W0',
    execution_commit='b4b10c10d2fe70bd71a4f9a93e042045f123ca4a',
    serving_source_commit='b4b10c10d2fe70bd71a4f9a93e042045f123ca4a',
    declared_candidate_difference='D176 held-HOST copy transaction; same D175 capacity, profiles, control and generation; initial/conflict graph validation and atomic exact-copy/live-capacity checks retained',
    full_qualified=False, native_contract_completion_pass=len(good)==4000, formal_performance_result=False, baselines='paused',
    diagnostic_instrumentation=False, frozen_source_refs_checked=len(before['source_sha256']),
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    population=dict(planned=4000, publisher_submitted=4000, runner_started=len(rows),
        terminal=len(terminals), success=len(good), native_contract_matched=len(good),
        failure_observations=dict(failures),
        replay_event_counts=dict(Counter(r['event'] for r in replay)),
        ingress_event_counts=dict(Counter(r['event'] for r in ingress))),
    execution_completed=outcome['run_completed'],
    qualification=('native_complete_numerical_adapter_and_formal_slo_pending' if len(good)==4000
                   else 'failed_full_completion_numerical_adapter_and_formal_slo_pending'),
    launcher_cleanup_pass=launch['pass'],
    cleanup=outcome['cleanup'] | dict(inventory_before=None, inventory_after=None),
    resources=dict(samples=samples, peak_bytes=peak, min_host_available_bytes=available,
                   max_events=dict(events), max_swap_bytes=swap, warning_samples=resource_warnings),
    physical=physical,
    observed_completion_boundaries=completion_boundaries,
    cancellation_records=cancellation_records,
    cancellation_timeline=cancellation_timeline,
    supersession_stages={k:dict(Counter(r.get('preparation_supersession',{}).get('stage')
        for r in mechanisms[k] if r.get('state')=='superseded')) for k in
        ('_ieee_residency_epochs','_ieee_file_preparation_plans','_ieee_gpu_preparation_plans')},
    source_observation_stats=mechanisms['_ieee_source_observation_stats'],
    planning_cpu_diagnostics=planning_diagnostics,
    d175_request_contract_comparison=cross_run_contract,
    zero_ready_with_queue=dict(events=len(zero_ready), first=zero_ready[0] if zero_ready else None,
        actions=dict(Counter(r['action'] for r in zero_ready)),
        outcomes=dict(Counter(r.get('outcome') for r in zero_ready))),
    selected_source_retries_on_success=dict(requests_with_retry=sum(x > 0 for x in retries),
        total=sum(retries), maximum=max(retries) if retries else None, note='Only retained retries of successful requests; not all failed snapshot attempts.'),
    mechanism_counts={k: dict(Counter(r.get('state', 'not_a_state_event') for r in v))
                      for k, v in mechanisms.items() if isinstance(v, list)},
    remote=dict(uuid_pairs=len(transfers), client_received_bytes=sum(r['transferred_bytes'] for r in transfers),
        server_socket_written_bytes=sum(r['bytes_written'] for r in remote),
        byte_mismatches=preliminary['remote']['byte_mismatches'],
        verified_published_logical_bytes=sum(r['payload_bytes_verified'] for r in transfers if r['state']=='published'),
        states=dict(Counter(r['state'] for r in transfers)),
        not_published=preliminary['remote']['not_published'], request_packing=0,
        unpublished_loading_records=[r for r in transfers if r['state'] != 'published'],
        unpublished_evidence=unpublished_evidence,
        unpublished_cause='per_transfer_evidence_not_presumed_identical',
        server_journal=Path((raw/'remote_copy_receipt.txt').read_text().splitlines()[0].split(maxsplit=1)[1]).name),
    quarantine=dict(events=len(quarantines), released=len(quarantines),
        mean_isolation_to_release_s=mean(quarantine_durations) if quarantine_durations else None,
        p95_isolation_to_release_s=quarantine_durations[math.ceil(.95*len(quarantine_durations))-1] if quarantine_durations else None,
        first_four_runtime_successes=preliminary['first_four_runtime_successes'],
        first_four_activation_categories=preliminary['first_four_activation_categories'],
        replacement_successes=preliminary['replacement_successes'],
        replacement_successful_runtimes=preliminary['replacement_successful_runtimes']),
    conditional_success_latency_ms=metrics,
    native_stage_metrics_ms=native_metrics,
    timing_validation=dict(requests=len(good), single_token_requests=single_token,
        max_error_ms=dict(timing_errors), tolerance_ms=1.0, pass_tolerance=not timing_violations,
        violations=timing_violations, requests_over_tolerance=len({v['request_id'] for v in timing_violations}),
        contract='ieee_tc_native_v1', direct_planned_arrival_boundary=True),
    readiness_tier_counts=dict(Counter(r['readiness_tier_before_dispatch'] for r in good)),
    readiness_evidence=dict(confirmed_pre_generation_requests=sum(confirmed_tiers.values()),
        source_admission_tier_counts=dict(confirmed_tiers), conflicts=0,
        qualification='Selected-source identity/clock/order only; not a complete A4 epoch study or numerical adapter proof.'),
    conditional_latency_caveat=f'{len(good)} native-contract successes only; {sum(failures.values())} failures retained. Numerical adapter correctness and common warm SLO remain pending. No formal ranking or isolated cross-run causal estimate.',
    protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json'),
    next='Back up this complete diagnostic, then follow Prime-first mainline using measured phase evidence; baselines stay paused. No blind replay or formal SLO claim.')
assert result['protected']['pass']
refs = [raw/'prelaunch_verification.json', raw/'health_3b.json', raw/'health_7b.json',
    compact_outcome, raw/'full_full1_metadata_projection4.sha256',
    run/'launch.json', evidence/'physical_deployment/main_outcome.json',
    evidence/'physical_deployment/summary.json', evidence/'physical_deployment/request_terminals.jsonl',
    evidence/'physical_deployment/deployment.json', evidence/'watchdog.jsonl',
    evidence/'service_ingress.jsonl', evidence/'replay.jsonl', evidence/'service.log',
    raw/'7b_main_config_full1.yaml', raw/'run_7b_full_w0_full1.sh',
    raw/'remote_7b_full1_transfers.jsonl', raw/'remote_monitor_full1_final.log', raw/'remote_copy_receipt.txt',
    raw/'copy_remote_full1.sh',
    raw/'stop_services_full1.sh', raw/'stop_remote_after_full1.sh', raw/'stop_services_full1.log',
    raw/'verify_local_full1_cleanup.sh', raw/'full_full1_local_cleanup.txt',
    raw/'cleanup_metadata_full1.sh',
    raw/'full_full1_metadata_cleanup.txt',
    Path(__file__), projection, raw/'project_full_full1.sh',
    ROOT/'results/ieee_tc/p2_backend_qualification/d96_20260928/project_full_attempt3.jq',
    raw/'full_full1_projection_time.txt', raw/'full_full1_projection_scope.txt',
    raw/'full_full1_preliminary.json', raw/'collect_full1_preliminary4.py',
    raw/'inspect_full1_metadata4.sh', raw/'full_full1_metadata4.log',
    raw/'full_full1_metadata4_scope.txt', raw/'full_full1_metadata4_time.txt',
    raw/'project_metadata4.jq', raw/'full_full1_metadata4_project_time.txt',
    raw/'full_full1_metadata4_memory_events.txt', raw/'full_full1_metadata4_swap.txt',
    original,
    ROOT/'scripts/run_all_experiments.py', ROOT/'faaslora/memory/residency_manager.py',
    ROOT/'faaslora/preloading/preloading_planner.py', ROOT/'faaslora/preloading/planning_cpu.py']
refs.extend([previous_full, previous_projection,
    ROOT/'results/ieee_tc/p2_backend_qualification/d138_20261001/summarize_full_full1.py'])
result['source_refs'] = [dict(path=str(path), sha256=p.digest(path)) for path in refs]
with out.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps(dict(output=str(out), sha256=p.digest(out), population=result['population'],
    resources=result['resources'], remote=result['remote'], stats=result['source_observation_stats'],
    retries=result['selected_source_retries_on_success'], conditional_metrics=metrics)))
