"""Seal D346 offline results, reusing D336 evidence and lifecycle checks."""
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
out = p.ROOT/'paper_results/ieee_tc/p2_backend/d346_full_w0'
offline = json.loads((raw/'offline_execution_receipt.json').read_text())
assert offline['pass_all']
identity = offline['identity']
assert p.scope_still_owned(identity)
group = Path(identity['path'])
assert not p.owned_pids(group)
resources = {key:(group/key).read_text() for key in ['memory.peak','memory.events',
    'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events']}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'analysis_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,empty_before_stop=True,after='inactive'),f,indent=2)
for subdir in ['validated1','context1']:
    directory = out/subdir
    manifest = json.loads((directory/'manifest.json').read_text())
    for name,digest in manifest['outputs'].items():
        assert p.digest(directory/name) == digest
    for ref in manifest['source_refs']:
        assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
paths = [raw/name for name in ['launch_gate1.json','remote_start.log','remote_health.json',
    'remote_stop.log','remote_stop.json','local_cleanup.json','collection_scope_cleanup.json',
    'analysis_cleanup.json','audit1.log','offline_execution_receipt.json',
    'completion_receipt.json','collect_closure.py','run_audit.py',
    'start_remote.sh','stop_remote.sh','check_remote_health.py',
    'closure_checkpoint.py','prelaunch_binding.json','launch_gate.py']]
paths += [raw/'7b_full_w0/launch.json',raw/'7b_full_w0/launch.launch/physical_deployment/summary.json']
paths += [p.ROOT/'scripts/ieee_tc/analyze_d297_full.py',p.ROOT/'scripts/ieee_tc/check_d299_full_context.py']
assert len({x.name for x in paths}) == len(paths)
from scripts.ieee_tc.analyze_d297_full import lifecycle_gaps
life = {}
for name in ('d336', 'd346'):
    directory = p.ROOT/f'results/ieee_tc/p2_backend_qualification/{name}_20261008/7b_full_w0/launch.launch/physical_deployment'
    sp, dp = directory/'summary.json', directory/'deployment.json'
    summary, deployment = json.loads(sp.read_text()), json.loads(dp.read_text())
    row = lifecycle_gaps(summary, deployment)
    envelope = sum(spans[-1][1]-spans[0][0] for spans in summary['device_intervals'].values())
    assert abs(envelope-row['released_gap_gpu_s']-row['observed_gpu_s']) < 1e-6
    row.update(envelope_gpu_s=envelope, window_gpu_seconds=summary['window_gpu_seconds'],
        sources=[dict(path=str(path),sha256=p.digest(path)) for path in (sp,dp)])
    life[name] = row
contrasts = {}
for reference in ('d336',):
    delta = life['d346']['observed_gpu_s']-life[reference]['observed_gpu_s']
    boundary = life['d346']['envelope_gpu_s']-life[reference]['envelope_gpu_s']
    reduced_gaps = life[reference]['released_gap_gpu_s']-life['d346']['released_gap_gpu_s']
    assert abs(delta-boundary-reduced_gaps) < 1e-6
    contrasts[reference] = dict(candidate_minus_reference_gpu_s=delta,
        envelope_boundary_delta_gpu_s=boundary,reduced_release_gaps_gpu_s=reduced_gaps)
with (out/'lifecycle.json').open('x') as f:
    json.dump(dict(runs=life,contrasts=contrasts,causal_savings=None,confidence_interval=None,
        caveat='Observed physical identity only, not a causal effect or formal G1/G2 qualification.'),f,indent=2)
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in paths:
    assert token and token not in path.read_bytes(), path
archive = out/'closure_evidence.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest() == p.digest(path)
record = dict(kind='d346_complete_development_checkpoint_v1',
    executed_source_commit='f4f6d4784d22b5f1afb1b7c6f7ed26bd24d14851',
    analysis_tests=83,native_completed=4000,numerical_n_correct=None,formal_qualification=False,
    no_figures=True,archive_sha256=p.digest(archive),
    raw_references=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
    next='Reject C14 capacity-derived working point as a G1 improvement: timing-only joint 3655/4000. Preserve native capacity evidence; diagnose retained phase/load/TPOT data before a new hypothesis. No blind capacity sweep or D346 repeat.')
with (out/'evidence.json').open('x') as f:
    json.dump(record,f,indent=2,allow_nan=False)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
own = p.scope_identity(unit)
own_group = Path(own['path'])
with (raw/'closure_seal_scope.json').open('x') as f:
    json.dump(dict(identity=own,resources={key:(own_group/key).read_text() for key in
        ['memory.peak','memory.events','memory.swap.current','cgroup.events']}),f,indent=2)
print(json.dumps(dict(native_complete=4000,archive_bytes=archive.stat().st_size,
    archived_files=len(paths),audit_scope_released=True,lifecycle_contrasts=contrasts)))
