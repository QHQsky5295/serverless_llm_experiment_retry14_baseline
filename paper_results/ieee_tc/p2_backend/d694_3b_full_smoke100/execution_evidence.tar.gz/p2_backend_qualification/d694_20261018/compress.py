"""D694: reuse explicit closed-evidence compressor, not a directory cleanup."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name)
with (RAW/'qualification2_identity.json').open('x') as f:json.dump(identity,f,indent=2)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
refs=[]
for number in (681,):
    prior=RAW.parent/f'd{number}_20261018'
    audit_path=ROOT/f'paper_results/ieee_tc/p2_backend/d{number}_3b_full_smoke100/completion/audit.json'
    audit=json.loads(audit_path.read_text());assert audit['passed']
    for phase in ('analysis3','publication'):
        closed=json.loads((prior/f'{phase}_closure.json').read_text())
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists()
    assert json.loads((prior/'remote_stop.json').read_text())['all_owned_units_inactive']
    assert json.loads((prior/'local_cleanup.json').read_text())['passed']
    source=prior/'3b_full_smoke100/launch.launch/physical_deployment/main_outcome.json'
    match=[r for r in audit['refs'] if r['path']==str(source)]
    assert len(match)==1 and p.digest(source)==match[0]['sha256']
    refs.append(dict(audit=str(audit_path),audit_sha256=p.digest(audit_path),**match[0]))
receipt=ROOT/'paper_results/ieee_tc/storage/20261018_d694_closed_outcomes.json'
args=[sys.executable,str(ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py'),
    '--closed-run','d681_20261018/3b_full_smoke100','--receipt',str(receipt)]
subprocess.run(args,check=True,cwd=ROOT)
rows=json.loads(receipt.read_text())['entries']
assert len(rows)==len(refs)==1
for row,ref in zip(rows,refs):
    assert row['source']==ref['path'] and row['source_sha256']==ref['sha256']
    assert row['first_roundtrip_sha256']==row['second_roundtrip_sha256']==ref['sha256']
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
with (RAW/'storage_verification.json').open('x') as f:json.dump(dict(passed=True,protected=protected,
    prior_audit_matches=refs,receipt_sha256=p.digest(receipt),
    compressor_sha256=p.digest(ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py')),f,indent=2)
