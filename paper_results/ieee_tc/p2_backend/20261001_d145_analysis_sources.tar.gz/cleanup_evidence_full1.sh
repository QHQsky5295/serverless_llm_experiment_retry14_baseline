#!/usr/bin/env bash
set -euo pipefail
# Same exact-identity, empty-domain protocol; this invocation belongs to D145.
date -Is
test "$(systemctl --user show primelora-tc-svc-46f7a42b36914d08af1aef936f577752.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d145-full1-evidence1-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 910a165269e34f78804a307175748ce0
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d145-full1-evidence1-20261001.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
