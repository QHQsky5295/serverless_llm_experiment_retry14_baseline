#!/usr/bin/env bash
set -euo pipefail
# Reuse D145 exact-identity / empty-domain cleanup; only D145 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-46f7a42b36914d08af1aef936f577752.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-7b16694bb9d447769eb74d80de743d98.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = e212cd03e1ba4a0fa4e973e3a08e7cbd
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-7b16694bb9d447769eb74d80de743d98.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
