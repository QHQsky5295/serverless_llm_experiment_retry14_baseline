#!/usr/bin/env bash
# Reuse D139 RPC audit unchanged; only the D145 inputs/output and sealed SHA differ.
# PREPARED ONLY. Execute after successful terminal/cleanup/curation, never live.
set -euo pipefail
set -o noclobber
test "$#" = 1
sha=$1
[[ "$sha" =~ ^[0-9a-f]{64}$ ]]
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d145_20261001
unit=primelora-d145-rpc-audit1-20261001.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show primelora-tc-svc-46f7a42b36914d08af1aef936f577752.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/rpc_scope1.txt"
export PYTHONUNBUFFERED=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
deployment=$raw/7b_full_w0_full1/launch.launch/physical_deployment
# D139 tests remain qualified; analyzer code is unchanged, no repeat here.
/usr/bin/time -v -o "$raw/7b_rpc_time1.txt" "$python" scripts/analyze_control_path_overhead.py \
  --rpc-breakdown --input "$raw/full_full1_request_projection.json" \
  --deployment "$deployment/deployment.json" --terminals "$deployment/request_terminals.jsonl" \
  --sealed-summary paper_results/ieee_tc/p2_backend/20261001_d145_7b_full_w0_full1.json \
  --sealed-sha256 "$sha" \
  --output paper_results/ieee_tc/p2_backend/20261001_d145_rpc_7b > "$raw/7b_rpc1.log"
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
