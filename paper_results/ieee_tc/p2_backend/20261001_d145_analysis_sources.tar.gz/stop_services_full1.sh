#!/usr/bin/env bash
set -euo pipefail
# Existing D110 exact-identity cleanup, adapted to D145. Execute remotely ONLY
# after local main exit and GPU cleanup; never while inference is running.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d145full1.service)
ids=(6f3e7a1bf1c04a1a9086e84fa46d42b1 360a8200c5264d8fb0735eafbb38b45b fbcc9cc86e9d4d5d8469839c49e75fd3)
pids=(1918283 1918285 1918289)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result
