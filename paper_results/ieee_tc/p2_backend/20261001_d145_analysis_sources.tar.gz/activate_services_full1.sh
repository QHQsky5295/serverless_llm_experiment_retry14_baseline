#!/usr/bin/env bash
set -euo pipefail
base=/home/lab14/primelora_remote/tc/d80_20260927
test "$(loginctl show-user lab14 -p Linger --value)" = yes
test "$(awk '/^MemAvailable:/{print $2}' /proc/meminfo)" -ge 27525120
test "$(df -B1 --output=avail "$base" | tail -1 | tr -d ' ')" -ge 17280532480
test -z "$(ss -ltnH '( sport = :18080 or sport = :18081 )')"
log=/home/lab14/primelora_remote/tc/d145_20261001/remote_monitor_7b_full_full1.log
test ! -e "$log"
mkdir -p "$(dirname "$log")"
for model in 3b 7b; do
  test "$(systemctl --user show primelora-artifact-tc-${model}.service -p ActiveState --value)" = inactive
  cmp "$base/primelora-artifact-tc-${model}.service" "/home/lab14/.config/systemd/user/primelora-artifact-tc-${model}.service"
done
systemctl --user start primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service
systemd-run --user --unit=primelora-artifact-monitor-d145full1.service \
  -p Type=exec -p UMask=0077 -p MemoryHigh=128M -p MemoryMax=256M -p MemorySwapMax=0 \
  -p CPUAffinity='0 20' -p TasksMax=32 -p NoNewPrivileges=yes \
  -p TimeoutStopSec=30 -p Restart=no \
  -p StandardOutput="append:$log" -p StandardError="append:$log" \
  /bin/bash "$base/monitor_remote_services_v2.sh"
systemctl --user show primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d145full1.service \
  -p Id -p InvocationID -p MainPID -p ActiveState -p MemoryHigh -p MemoryMax -p MemorySwapMax
