#!/usr/bin/env bash
set -euo pipefail
# Existing exact-identity/empty-domain cleanup; never stop a live projection.
date -Is
test "$(systemctl --user show primelora-tc-svc-46f7a42b36914d08af1aef936f577752.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d145-full1-project-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = d7ce840a89db418ea1749078629b4d56
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d145-full1-project-20261001.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
