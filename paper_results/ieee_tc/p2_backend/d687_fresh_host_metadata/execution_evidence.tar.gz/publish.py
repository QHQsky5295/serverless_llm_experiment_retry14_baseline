"""Reuse tested D686 small-evidence publication; explicitly freeze one new candidate."""
import ast
import hashlib
from pathlib import Path
source=Path(__file__).resolve().parent.parent/'d686_20261018/publish.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='3c2c7fb8f6213d069ad7200dbac7621b266a83bd474429807dc369255f3b06bd'
code=data.decode()
old="assert not subprocess.check_output(['git','diff','--name-only','--','faaslora'],cwd=ROOT,text=True).strip()"
assert old in code
code=code.replace(old,"assert subprocess.check_output(['git','diff','--name-only','--','faaslora'],cwd=ROOT,text=True).splitlines()==['faaslora/memory/gpu_monitor.py']")
changes={
    'd686_pin_gc_attribution':'d687_fresh_host_metadata',
    '32225851a83581e5e73c4d472c8f0d84f8244ac8':'5bb08ffb1af21acd50e2fea728335fcae6587a99',
    "'qualification.json'":"'qualification_receipt.json'",
    "('qualification','start','start2','analysis')":"('qualification','start','analysis','analysis2')",
    'native_launch2':'native_launch','native_pin2':'native_pin',
    'production_unchanged=True':'production_unchanged=False',
    'pre_service_launch_failures=1':'pre_service_launch_failures=0,offline_manifest_repair=True',
    'D686_PIN_GC_ATTRIBUTION.md':'D687_FRESH_HOST_METADATA_RENDERING.md',
    "'scripts/ieee_tc_preflight.py','scripts/ieee_tc/gc_observation.py','tests/test_ieee_tc_gc_observation.py'":
        "'faaslora/memory/gpu_monitor.py','tests/test_ieee_tc_host_metadata_projection.py','tests/test_ieee_tc_worker_observation.py'",
    'tc: attribute bounded pin diagnostic pause without production adoption (D686)':
        'tc: qualify fresh HOST metadata rendering for full W0 validation (D687)',
}
for old,new in changes.items():
    assert old in code,old
    code=code.replace(old,new)
ast.parse(code)
exec(compile(code,str(source),'exec'))
