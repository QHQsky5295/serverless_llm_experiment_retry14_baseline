"""Reuse bounded D663 CPU qualification for a fresh metadata representation."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d663_20261018/qualify.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='1cfd5d94227448d349d837b613283b03d85a28f3069e74fa118ef531b952eeea'
code=data.decode().replace('p.preflight([MAIN], 32*p.GIB)','p.preflight([MAIN], 64*p.MIB)')
start=code.index("paths = ['faaslora/memory/gpu_monitor.py'")
end=code.index('log = RAW/',start)
code=code[:start]+"""paths = ['faaslora/memory/gpu_monitor.py',
    'tests/test_ieee_tc_host_metadata_projection.py', 'tests/test_ieee_tc_worker_observation.py',
    'faaslora/memory/residency_manager.py', 'faaslora/scheduling/vllm_ieee_scheduler.py',
    'scripts/run_all_experiments.py']
for path in paths:ast.parse((MAIN/path).read_text())
tests = ['tests.test_ieee_tc_host_metadata_projection',
    'tests.test_ieee_tc_worker_observation', 'tests.test_ieee_tc_host_observation_freshness',
    'tests.test_ieee_tc_request_footprints', 'tests.test_ieee_tc_gpu_references',
    'tests.test_ieee_tc_hit_host_transaction.HitHostTransaction']
"""+code[end:]
ast.parse(code)
exec(compile(code,str(source),'exec'))
