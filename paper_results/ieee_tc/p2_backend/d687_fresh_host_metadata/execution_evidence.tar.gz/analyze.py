"""Reuse D685 complete-point sealing, with explicit D687 semantics and labels."""
import ast
import hashlib
from pathlib import Path
source=Path(__file__).resolve().parent.parent/'d685_20261018/analyze.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='be03e7d6a1f7f7dc26d4e31184a471bb279dde44ac4721dc951a9ae021ee3e16'
code=data.decode()
replacements={
    'd685_batched_live_pin':'d687_fresh_host_metadata',
    "'qualification.json'":"'qualification_receipt.json'",
    'native_batched_live_pin_query_d685_v1':'native_fresh_host_metadata_rendering_d687_v1',
    'd685_batched_pin_single_microqualification':'d687_fresh_host_metadata_qualification',
    'production_modified=False':'production_modified=True',
    'no_production_change=True':'no_production_change=False',
    'full-inventory batched candidate slower; no prefix/full workload authorized':'fresh metadata candidate supports one full W0 validation; no system performance acceptance yet',
    "assert summary['candidate_faster_pairs']<10 and summary['paired_ratio_median']>1":
        "summary['full_replay_validation_supported'] = summary['wall_ms']['direct']['mean'] < summary['wall_ms']['native']['mean']\nsummary['measurement_variant_mapping'] = result['measurement_variant_mapping']",
    "'build_receipt.json'":"'launch_inputs.json'",
    'D462_LIVE_PIN_QUERY_QUALIFICATION.md':'D687_FRESH_HOST_METADATA_RENDERING.md',
}
for old,new in replacements.items():
    assert old in code,old
    code=code.replace(old,new)
ast.parse(code)
exec(compile(code,str(source),'exec'))
