"""Finish only the missing manifest; preserve first analysis and all values."""
import json
import os
import subprocess
import sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d687_fresh_host_metadata'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'analysis2_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
qual=read(RAW/'qualification_receipt.json')
assert qual==read(OUT/'qualification_receipt.json') and qual['passed']
assert p.digest(RAW/'qualification.log')==qual['log_sha256']
for path,sha in qual['source_sha256'].items():assert p.digest(Path(path))==sha,path
native=read(RAW/'native_pin.json')
assert native==read(OUT/'native_pin.json') and native['pass']
summary=read(OUT/'summary.json')
assert summary['source_sha256']==p.digest(RAW/'native_pin.json')
assert summary['passed'] and summary['full_replay_validation_supported']
assert not summary['performance_candidate_accepted'] and summary['production_modified']
assert summary['measurement_variant_mapping']==native['measurement_variant_mapping']
for label in ('native','direct'):
    values=[row['wall_ns'] for row in native['measurements'] if row['variant']==label]
    assert len(values)==20
    assert abs(summary['wall_ms'][label]['mean']-sum(values)/len(values)/1e6)<1e-12
sources=[RAW/'native_pin.json',RAW/'native_launch.json',RAW/'qualification_receipt.json',
    RAW/'qualification.log',RAW/'launch_inputs.json',RAW/'analysis_failure.json',
    ROOT/'docs/ieee_tc/D687_FRESH_HOST_METADATA_RENDERING.md',
    ROOT/'paper_results/ieee_tc/p2_backend/d684_3b_control_prefix1/completion/operation_detail1/inventory_summary.json']
save(OUT/'manifest.json',dict(sources={str(path):p.digest(path) for path in sources},
    production_change='fresh metadata rendering only; complete performance not accepted',
    no_remote_operations=True,no_new_artifacts_or_trace=True,native_rerun=False,
    analysis_repair='only missing manifest added; existing result files verified unchanged'))
print(json.dumps(summary,indent=2))
