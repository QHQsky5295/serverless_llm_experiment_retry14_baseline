"""Reuse D685 gated launch; same tiny fixture, distinct metadata candidate."""
import ast
import hashlib
import json
from pathlib import Path
raw=Path(__file__).resolve().parent
source=raw.parent/'d685_20261018/launch.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='35a4e9044157cf631f0116eb50e88e21ef0240ce080c6725cbe6d1d4ca6faa03'
code=source.read_text()
code=code.replace("'qualification.json'","'qualification_receipt.json'")
code=code.replace("str(ROOT/'scripts/ieee_tc_preflight.py')","str(RAW/'native.py')")
old=",'--pin-bulk-library',str(RAW/'native_pin_batch.so')"
assert code.count(old)==1
code=code.replace(old,'')
ast.parse(code)
for path in (raw/'native.py',raw/'qualify.py',raw/'close.py'):ast.parse(path.read_text())
with (raw/'launch_inputs.json').open('x') as f:
    json.dump({str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in
        (raw/'native.py',raw/'launch.py',raw/'qualify.py',source)},f,indent=2)
exec(compile(code,str(source),'exec'))
