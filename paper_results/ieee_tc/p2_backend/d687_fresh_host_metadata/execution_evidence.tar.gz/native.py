"""Existing native fixture, comparing exact parent vs current metadata rendering.

The D462 direct pin witness is NOT the candidate here. Both graph functions use
the unchanged Tensor.is_pinned for every view. No GC policy manipulation.
"""
import argparse
import inspect
import json
import sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
p.verify_current_service()  # BEFORE importing torch-containing project modules.
parser=argparse.ArgumentParser()
parser.add_argument('action',choices=['backend-pin-check'])
parser.add_argument('--runtime-receipt',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
assert not args.output.exists()
from faaslora.memory import gpu_monitor as monitor
from tests.test_ieee_tc_host_metadata_projection import parent_inventory
candidate=monitor._ieee_lora_host_inventory
reference=parent_inventory()
def qualified_comparison(original,query,guard):
    assert original is reference
    return candidate,inspect.getsource(candidate)
with patch.object(monitor,'_ieee_lora_host_inventory',reference), \
     patch.object(p,'_pin_inventory_witness',qualified_comparison):
    result=p.backend_pin_query_check(args.runtime_receipt)
assert monitor._ieee_lora_host_inventory is candidate
result.update(kind='native_fresh_host_metadata_rendering_d687_v1',
    candidate_is_diagnostic_clone=False,reference_commit='5bb08ffb1af21acd50e2fea728335fcae6587a99',
    reference_module_sha256='213cc94b070a1b3e0b0b1da9decdc5d0ffe0724c36aa57a892619a5c6d6eeb32',
    measurement_variant_mapping={'native':'exact_parent_inventory','direct':'current_metadata_rendering'},
    per_view_native_pinning_unchanged=True,gc_policy_modified=False,
    candidate_label='fresh_metadata_rendering_not_pin_interface',
    harness_source_sha256=p.digest(Path(__file__)))
with args.output.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(passed=result['pass'],kind=result['kind'])))
raise SystemExit(0 if result['pass'] else 2)
