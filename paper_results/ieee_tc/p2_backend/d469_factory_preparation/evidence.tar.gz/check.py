"""Reuse the D468 bounded regression/closure procedure with new source identity."""
from pathlib import Path
import sys

OLD = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d468_20261012/check.py')
source = OLD.read_text()
changes = {
    "'faaslora/experiment/cpu_frontend.py'": "'faaslora/cpu_frontend.py'",
    "'tests/test_ieee_tc_gpu_lifecycle.py','scripts/run_all_experiments.py'":
        "'tests/test_ieee_tc_gpu_lifecycle.py','scripts/run_all_experiments.py', 'tests/test_ieee_tc_cpu_frontend_integration.py'",
    "modules=['tests.test_ieee_tc_cpu_frontend_lifecycle'":
        "modules=['tests.test_ieee_tc_cpu_frontend_integration', 'tests.test_ieee_tc_cpu_frontend_lifecycle'",
}
for old, new in changes.items():
    assert source.count(old) == 1, old
    source = source.replace(old, new)
namespace = dict(__file__=__file__, __name__='d469_reused_regression')
exec(compile(source, str(OLD), 'exec'), namespace)
if __name__ == '__main__':
    namespace[sys.argv[1]](sys.argv[2])
