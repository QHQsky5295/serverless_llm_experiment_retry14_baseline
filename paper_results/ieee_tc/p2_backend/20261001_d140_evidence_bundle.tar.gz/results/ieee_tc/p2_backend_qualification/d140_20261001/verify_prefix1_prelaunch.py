"""D123 diagnostic interface, D137 configuration, current backed serving code."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight
from faaslora.runtime_configuration import resolve_facade_lora_capacity
from faaslora.datasets.workload_generator import FrozenReplayPlan

root=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw=root/'results/ieee_tc/p2_backend_qualification/d140_20261001'
previous=root/'results/ieee_tc/p2_backend_qualification/d137_20261001'
expected_commit='78ce501fee27e2ca517423140e498fc1f12f0cac'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==expected_commit
dirty=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty)<={'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'},dirty
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))=='fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old,new=[yaml.safe_load(p.read_text()) for p in
         (previous/'7b_main_config_full1.yaml',raw/'7b_main_config_prefix1.yaml')]
assert old['workload']['total_requests']==4000 and new['workload']['total_requests']==1000
for config in (old,new):
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
    del config['workload']['total_requests']
assert old==new,'configuration differs beyond prefix count and three fresh paths'
assert not (raw/'7b_full_w0_prefix1/launch.json').exists()
assert not (raw/'7b_nvme_prefix1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d140-7b-prefix1/tc_ieee_full').exists()
# Reuse latest frozen dependency map; do not rehash huge completed raw results.
prior=root/'results/ieee_tc/p2_backend_qualification/d138_20261001/prelaunch_verification.json'
assert digest(prior)=='1368a6f5c216d96fd21c32abe36e28fe8ba06f8596f8a25ce0c1aea7b7b1a0d2'
refs=dict(json.loads(prior.read_text())['source_sha256'])
for name,expected in refs.items():
    path=Path(name) if name.startswith('/') else root/name
    assert digest(path)==expected,name
# Scheduler was not in that map; pin it to D138's actual runtime Git tree.
scheduler='faaslora/scheduling/vllm_ieee_scheduler.py'
historical=subprocess.check_output(['git','show','2608d027d82df5a79719153e114ff06a7a70679b:'+scheduler],cwd=root)
assert digest(root/scheduler)==hashlib.sha256(historical).hexdigest()
refs[scheduler]=digest(root/scheduler)
interface=root/'paper_results/ieee_tc/p2_backend/20260930_d122_diagnostic_prefix'
assert digest(interface/'verification.json')=='f266677bbdf57a667de6857a34f57c678e8c17ccfecff5ba5f28ee0303ab51d0'
assert digest(interface/'summary.json')=='57f55221ffc0b81da08de2eb50280e571a8d4ade0f9383597fcecf4b63c996c2'
context=json.loads((interface/'summary.json').read_text())['next_diagnostic_input']
plan=FrozenReplayPlan.from_launch_context(context)
before=json.loads((previous/'prelaunch_verification.json').read_text())
assert len(plan.entries)==1000 and plan.source_count==4000 and plan.profile=='W0'
assert plan.source_sha256==before['trace']['source_sha256']
model=resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras']==24 and model['runtime_concurrency_cap']==2
assert model['max_num_seqs']==2 and model['max_loras']==4
for key in ('ieee_service_profile','ieee_preparation_profile'):
    binding=new['resource_coordination'][key]
    assert digest(Path(binding['path']))==binding['sha256']
profiler=Path('/home/qhq/anaconda3/envs/splitwise_official_20260615/bin/py-spy')
assert subprocess.check_output([str(profiler),'--version'],text=True).strip()=='py-spy 0.4.2'
for path in [raw/name for name in ('7b_main_config_prefix1.yaml','run_7b_full_w0_prefix1.sh',
    'profile_controller_python.sh','activate_services_prefix1.sh','check_health.sh',
    'verify_prefix1_prelaunch.py','prepare_prefix1.sh')]+[interface/'summary.json',interface/'verification.json',profiler]:
    refs[str(path)]=digest(path)
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
resources=preflight([root,raw],32*1024**3)
assert resources['preflight_pass'],resources['issues']
receipt=dict(kind='d140_current_process_tree_prefix_prelaunch_v1',time_unix=time.time(),
    run='d140_7b_full_w0_prefix1',evidence_commit=expected_commit,runtime_source_commit=expected_commit,
    serving_change=False,same_configuration_except_owned_paths_and_population=True,
    diagnostic_instrumentation=True,formal_performance_result=False,source_sha256=refs,
    protected=protected,resource_preflight=resources,trace=plan.identity(),subset=before['subset'],
    replay_scope='diagnostic_prefix_v1',diagnostic_prefix_count=1000,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    hypothesis='Current controller CPU work delays ready generation replies; distinguish controller/frontend/planner/native core samples before choosing optimization.',
    profiler=dict(version='0.4.2',rate_hz=100,gil_only=True,threads=True,subprocesses=True,
                  format='speedscope',native_extensions=False,collect_locals=False,
                  missing_role_samples='report missing; do not infer zero cost'),
    comparison='Current-version diagnostic, not paired to obsolete D123 code or ordinary Full timing.',
    reused_initialization='D88/D89 and unchanged D137 7B parent config; no new profile/data/cache',
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),sha256=digest(raw/'prelaunch_verification.json'),
    protected=147,source_refs=len(refs),population=1000,source_count=4000,resource_pass=True,formal=False)))
