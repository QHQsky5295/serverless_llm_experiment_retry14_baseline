#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d140_20261001
unit=primelora-d140-evidence1-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/evidence_scope1.txt"
export PYTHONPATH=$PWD PYTHONUNBUFFERED=1
/usr/bin/time -v -o "$raw/evidence_time1.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/verify_evidence1.py" > "$raw/evidence1.log" 2>&1
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
