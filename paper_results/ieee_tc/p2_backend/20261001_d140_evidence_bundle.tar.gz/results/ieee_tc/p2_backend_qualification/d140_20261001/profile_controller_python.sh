#!/usr/bin/env bash
set -euo pipefail
# Diagnostic wrapper only. The canonical runner and native worker executables
# remain unchanged; children MUST NOT recursively invoke this profiler.
ROOT=/home/qhq/serverless_llm_experiment_retry14_baseline
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d140_20261001
test "$1" = "$ROOT/scripts/run_all_experiments.py"
test -n "${FAASLORA_TC_LAUNCH_RECEIPT:-}"
test -f "$FAASLORA_TC_LAUNCH_RECEIPT"
test ! -e "$RAW/process_tree_prefix1.speedscope.json"
test ! -e "$RAW/controller_prefix1_time.txt"
export FAASLORA_PYTHON=/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python
exec /usr/bin/time -v -o "$RAW/controller_prefix1_time.txt" /home/qhq/anaconda3/envs/splitwise_official_20260615/bin/py-spy record --format speedscope --rate 100 --subprocesses --gil --threads --full-filenames -o "$RAW/controller_prefix1.speedscope.json" -- "$FAASLORA_PYTHON" "$@"
