#!/usr/bin/env bash
set -euo pipefail
unit=primelora-d140-prefix1-metadata-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 14b2e6f9ab5d48e6b2ceb7f03590f149
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d140-prefix1-metadata-20261001.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
