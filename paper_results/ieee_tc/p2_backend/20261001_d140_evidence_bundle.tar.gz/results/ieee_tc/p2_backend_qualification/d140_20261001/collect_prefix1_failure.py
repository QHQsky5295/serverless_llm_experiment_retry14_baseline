"""D138 terminal/resource/remote audit adapted to an incomplete diagnostic."""
import collections
import hashlib
import json
import re
import subprocess
from pathlib import Path

raw = Path(__file__).resolve().parent
e = raw / '7b_full_w0_prefix1/launch.launch'
compact = raw / 'prefix1_main_outcome_compact.json'
assert 0 < compact.stat().st_size < 128 * 1024**2
subprocess.run(['sha256sum', '-c', str(raw / 'prefix1_metadata_compaction.sha256')], check=True)
x = json.loads(compact.read_text())
launch = json.loads((e.parent / 'launch.json').read_text())
p = json.loads((e / 'physical_deployment/summary.json').read_text())
rows = [json.loads(line) for line in (e / 'physical_deployment/request_terminals.jsonl').open()]
remote = [json.loads(line) for line in (raw / 'remote_7b_prefix1_transfers.jsonl').open()]
health = json.loads((raw / 'health_7b.json').read_text())
assert not launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not x['run_completed'] and not x['formal_comparison_qualified']
assert len(rows) == len({r['request_id'] for r in rows})
assert all(r['released'] for r in p['allocation_journals']) and not p['open_lease_ids']
assert not p['measurement_complete'] and not p['eligible_correctness']
by = {r['transfer_id']: r for r in remote}
t = x['remote_transfers']
assert len(by) == len(remote) == len(t) > 0
assert set(by) == {r['http_transfer_id'] for r in t}
for r in t:
    peer = by[r['http_transfer_id']]
    assert peer['artifact_id'] == r['artifact_id'] and peer['clock_id'] == health['clock_id']
    assert not peer['pack_performed'] and not peer['temporary_created']
    if r['state'] == 'published':
        assert peer['bytes_written'] == r['transferred_bytes']
        assert r['content_verified'] and r['published_archive_verified']
        assert r['payload_bytes_verified'] == r['payload_bytes_expected']
    else:
        assert r['state'] == 'not_published' and not r['content_verified']
        assert 0 <= r['transferred_bytes'] <= peer['bytes_written']
resources = dict(samples=0, peak_bytes=0, min_host_available_bytes=2**63,
                 events={}, max_swap_bytes=0, warnings=0, abort_reasons=[])
for line in (e / 'watchdog.jsonl').open():
    r = json.loads(line)
    if r['event'] != 'resource_sample':
        continue
    resources['samples'] += 1
    resources['warnings'] += r['decision']['warning']
    resources['abort_reasons'].extend(r['decision']['abort_reasons'])
    resources['peak_bytes'] = max(resources['peak_bytes'], r['service']['memory.peak'])
    resources['min_host_available_bytes'] = min(resources['min_host_available_bytes'], r['host']['available_bytes'])
    resources['max_swap_bytes'] = max(resources['max_swap_bytes'], r['service']['memory.swap.current'])
    for k in ('high', 'max', 'oom', 'oom_kill'):
        resources['events'][k] = max(resources['events'].get(k, 0), r['service']['memory.events'].get(k, 0))
log = (e / 'service.log').read_text()
lag = [float(v) for v in re.findall(r'py-spy> ([0-9.]+)s behind in sampling', log)]
failures = {k: [r for r in v if r.get('state') == 'failed']
            for k, v in x['mechanism_events'].items() if isinstance(v, list)}
failures = {k:v for k,v in failures.items() if v}
result = dict(kind='d140_incomplete_diagnostic_audit_v1', formal_performance_result=False,
    planned_prefix=x['planned_request_count'], source_workload_count=4000,
    observed_terminal_count=len(rows), observed_success=sum(r['success'] for r in rows),
    observed_native_matches=sum(r['native_contract_matched'] for r in rows),
    physical={k:v for k,v in p.items() if k.startswith('n_') or k in
        ('gpu_seconds_observed','gpu_seconds','measurement_complete','eligible_correctness')},
    resource=resources, cleanup=x['cleanup'], cleanup_errors=x['cleanup_errors'],
    main_error=x['error'], launcher_classification=launch['classification'], launcher_error=launch.get('error'),
    remote=dict(uuid_pairs=len(t), received_bytes=sum(r['transferred_bytes'] for r in t),
        sent_bytes=sum(r['bytes_written'] for r in remote), request_packing=0,
        states=dict(collections.Counter(r['state'] for r in t))),
    profiler=dict(lag_warning_count=len(lag), max_lag_seconds=max(lag, default=None),
        final_profile_exists=(raw/'process_tree_prefix1.speedscope.json').exists(),
        quality_qualified=False),
    mechanism_counts={k:dict(collections.Counter(r.get('state','not_a_state_event') for r in v))
                      for k,v in x['mechanism_events'].items() if isinstance(v,list)},
    failed_record_counts={k:len(v) for k,v in failures.items()},
    main_outcome_keys=list(x), physical_summary_path=str(e/'physical_deployment/summary.json'))
for name, data in [('prefix1_failure_summary.json', result), ('prefix1_failed_mechanisms.json', failures)]:
    with (raw/name).open('x') as handle:
        json.dump(data, handle, indent=2, allow_nan=False)
print(json.dumps({k:v for k,v in result.items() if k not in ('main_error','cleanup','mechanism_counts','main_outcome_keys')}, indent=2))
print('failed-record keys', {k:[list(r) for r in v] for k,v in failures.items()})
