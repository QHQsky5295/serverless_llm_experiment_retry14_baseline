#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
# D138 copy protocol, bound to the stopped D140 service clock and exact journal.
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d140_20261001
alias=primelora-artifact-174
journal=/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-f97e790a16534376a2fa45ef76b703ca.jsonl
monitor=/home/lab14/primelora_remote/tc/d140_20261001/remote_monitor_7b_full_prefix1.log
test "$(systemctl --user show primelora-tc-svc-181832d131004293988a1ad8842c9cf6.scope -p ActiveState --value)" = inactive
test -s "$raw/stop_services_prefix1.log"
test ! -e "$raw/remote_7b_prefix1_transfers.jsonl"
test ! -e "$raw/remote_monitor_prefix1_final.log"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "head -n 1 '$journal'" |
  jq -e '.clock_id == "remote-process-monotonic:85bad03b54c64d059dd4350266588f6b"'
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "sha256sum '$journal' '$monitor'" > "$raw/remote_copy_receipt.txt"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$journal" "$raw/remote_7b_prefix1_transfers.jsonl"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$monitor" "$raw/remote_monitor_prefix1_final.log"
read -r expected_journal _ < "$raw/remote_copy_receipt.txt"
expected_monitor=$(sed -n '2s/ .*//p' "$raw/remote_copy_receipt.txt")
test "$(sha256sum "$raw/remote_7b_prefix1_transfers.jsonl" | cut -d' ' -f1)" = "$expected_journal"
test "$(sha256sum "$raw/remote_monitor_prefix1_final.log" | cut -d' ' -f1)" = "$expected_monitor"
sha256sum "$raw/remote_7b_prefix1_transfers.jsonl" "$raw/remote_monitor_prefix1_final.log"
