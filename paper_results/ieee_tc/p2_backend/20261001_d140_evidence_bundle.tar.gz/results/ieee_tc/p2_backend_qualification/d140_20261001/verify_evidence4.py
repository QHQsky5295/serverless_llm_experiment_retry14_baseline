"""D139 evidence closure protocol, adapted to D140's incomplete diagnostic."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d140_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
e = raw/'7b_full_w0_prefix1/launch.launch'
pre = raw/'prelaunch_verification.json'
assert digest(pre) == '0ff53fab1178d053685101e2a0888182002e581fe069c2e01b8f536df6af613d'
preflight = json.loads(pre.read_text())
for name, sha in preflight['source_sha256'].items():
    assert digest(Path(name) if name.startswith('/') else root/name) == sha, name
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
for unit in ('primelora-d140-prefix1-metadata-20261001.scope',
             'primelora-tc-svc-181832d131004293988a1ad8842c9cf6.scope',
             'primelora-tc-aux-42f48498462f4b83bde52eec39ca6e64.scope'):
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
audit = json.loads((raw/'prefix1_failure_summary.json').read_text())
assert not audit['formal_performance_result'] and audit['planned_prefix'] == 1000
assert audit['cleanup']['complete'] and not audit['cleanup_errors']
assert all(not Path(r['path']).exists() for r in audit['cleanup']['roots'])
assert not any(audit['resource']['events'].values())
assert audit['observed_success'] == audit['observed_native_matches'] == 90
assert audit['observed_terminal_count'] == 162 and audit['physical']['n_interrupted'] == 72
assert audit['physical']['gpu_seconds'] is None and not audit['physical']['measurement_complete']
assert not audit['profiler']['quality_qualified'] and not audit['profiler']['final_profile_exists']
assert 'Exit status: 0' in (raw/'prefix1_metadata_time.txt').read_text()
metadata_events = {line.split()[0]:int(line.split()[1]) for line in
    (raw/'metadata_cleanup.log').read_text().splitlines()
    if line.startswith(('low ','high ','max ','oom ','oom_kill ','oom_group_kill '))}
assert len(metadata_events) == 6 and not any(metadata_events.values())
assert (raw/'stop_services_prefix1.log').read_text().count('ActiveState=inactive') == 3
curated = {k:v for k,v in audit.items() if k not in ('cleanup','main_outcome_keys')}
curated['cleanup'] = {k:audit['cleanup'][k] for k in ('complete','roots')}
curated['interpretation'] = dict(complete_performance=False,
    observed_failure='controller preparation consistency ValueError, followed by replay termination',
    exact_failed_snapshot_preserved=False, cpu_hotspot_attribution_supported=False,
    source_binding_hypothesis='another selected target path versus the frozen objective; not uniquely established')
curated_path = out/'20261001_d140_incomplete_diagnostic.json'
assert digest(curated_path) == '6bb86591353627bbe4ee324b87b5cdad7d8a190ababf6f5eb504f6c1a8a42991'
assert json.loads(curated_path.read_text()) == curated
files = [*sorted(raw.glob('*.sh')), *sorted(raw.glob('*.py')),
    pre, raw/'prefix1_failure_summary.json', raw/'prefix1_failed_mechanisms.json',
    raw/'prefix1_metadata_scope.txt', raw/'prefix1_metadata_time.txt', raw/'metadata_cleanup.log',
    raw/'stop_services_prefix1.log', raw/'remote_copy_receipt.txt', raw/'prefix1_metadata_compaction.sha256',
    raw/'remote_7b_prefix1_transfers.jsonl', raw/'evidence1.log', raw/'evidence_time1.txt',
    raw/'evidence_scope1.txt', raw/'evidence_cleanup1.log',
    raw/'evidence2.log', raw/'evidence_time2.txt', raw/'evidence_scope2.txt', raw/'evidence_cleanup2.log',
    raw/'evidence3.log', raw/'evidence_time3.txt', raw/'evidence_scope3.txt', raw/'evidence_cleanup3.log',
    raw/'health_7b.json', raw/'process_roles_live1.txt', raw/'7b_main_config_prefix1.yaml',
    raw/'profile_controller_python.sh', e/'service.log', e.parent/'launch.json',
    e/'physical_deployment/summary.json', e/'physical_deployment/request_terminals.jsonl',
    curated_path, root/'docs/ieee_tc/D140_CURRENT_CPU_DIAGNOSTIC.md']
files = list(dict.fromkeys(files))
assert all(p.stat().st_size < 2*1024**2 for p in files)
# Compilation and shell syntax only: no unaffected test suite or GPU rerun.
for p in raw.glob('*.py'):
    if p.name == 'verify_evidence3.py':
        try: compile(p.read_text(),str(p),'exec')
        except SyntaxError: pass  # Preserved failed source, never an executable deliverable.
        else: raise AssertionError('expected preserved attempt3 syntax failure')
    else: compile(p.read_text(),str(p),'exec')
for p in raw.glob('*.sh'): subprocess.run(['bash','-n',str(p)],check=True)
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for p in files:
    body = p.read_bytes()
    assert secret not in body and not any(line.startswith(b'-----BEGIN ') and line.endswith(b'PRIVATE KEY-----') for line in body.splitlines()), p
result = dict(kind='d140_failed_diagnostic_closure_v1',evidence_checks_pass=True,
    execution_completed=False,profile_qualified=False,serving_unchanged=True,
    unchanged_preflight_sources=len(preflight['source_sha256']),protected=protected,
    verification_attempt=4,prior_attempt_errors=['raw monitor exceeds bundle guard', 'scanner self-matched literal in source', 'attempt3 generated scanner syntax error before any action'],
    local_only_refs=[dict(path=str(raw/'remote_monitor_prefix1_final.log'),sha256=digest(raw/'remote_monitor_prefix1_final.log'))],
    checks='bounded audit, remote UUID/byte/content checks, syntax/compile, exact cleanup, secrets',
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
verification = out/'20261001_d140_evidence_verification.json'
with verification.open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
files.append(verification)
bundle = out/'20261001_d140_evidence_bundle.tar.gz'
with bundle.open('xb') as handle:
    with tarfile.open(fileobj=handle,mode='w:gz') as archive:
        for p in files: archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(files)
    for member,p in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == digest(p)
with (out/'20261001_d140_evidence_bundle.sha256').open('x') as f:
    f.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(evidence_checks_pass=True,execution_pass=False,
    protected=147,verification_sha=digest(verification),bundle_sha=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files))))
