#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
# Reuse D138 bounded metadata path, without its completed-run assumptions.
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d140_20261001
unit=primelora-d140-prefix1-metadata-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test "$(systemctl --user show primelora-tc-svc-181832d131004293988a1ad8842c9cf6.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/prefix1_metadata_scope.txt"
source_file="$raw/7b_full_w0_prefix1/launch.launch/physical_deployment/main_outcome.json"
compact_file="$raw/prefix1_main_outcome_compact.json"
LC_ALL=C sed -e 's/^ *//' -e 's/ *$//' "$source_file" > "$compact_file"
test "$(stat -c %s "$compact_file")" -lt 134217728
sha256sum "$source_file" "$compact_file" > "$raw/prefix1_metadata_compaction.sha256"
exec /usr/bin/time -v -o "$raw/prefix1_metadata_time.txt" /usr/bin/python3 "$raw/collect_prefix1_failure.py" > "$raw/prefix1_metadata.log" 2>&1
