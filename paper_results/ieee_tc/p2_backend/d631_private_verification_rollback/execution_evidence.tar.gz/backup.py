"""Reuse D595's explicit-path backup for an exact, tested D628 rollback."""
import ast
from pathlib import Path

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d631_private_verification_rollback'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'",
        "=='8d7e2b6ec3a272aff84b6f909106b094dc2390fa'")
start=code.index('reg=read(RAW/');end=code.index('preserved={',start)
code=code[:start]+"""reg=read(RAW/'qualification_receipt.json')
assert reg['passed']
for path,sha in reg['sources'].items():assert p.digest(Path(path))==sha
closure=read(RAW/'qualification_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
restored={}
for name in ('faaslora/memory/residency_manager.py','tests/test_ieee_tc_request_lifecycle.py'):
    before=subprocess.check_output(['git','show','e12e73f^:'+name],cwd=ROOT)
    assert (ROOT/name).read_bytes()==before
    restored[name]=hashlib.sha256(before).hexdigest()
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
"""+code[end:]
start=code.index('members=[RAW/name');end=code.index('\nfor path in members:',start)
code=code[:start]+"""members=[RAW/name for name in ('run_tests.py','close.py','backup.py',
    'qualification_identity.json','qualification_gate.json','qualification.log','qualification_receipt.json',
    'qualification_closure.json','qualification_source.tar.gz')]"""+code[end:]
start=code.index('test_counts={');end=code.index("save(OUT/'qualification.json'",start)
code=code[:start]+"""test_counts=[int(n) for n in re.findall(r'Ran (\\d+) tests', (RAW/'qualification.log').read_text())]
assert len(test_counts)==5 and sum(test_counts)==458,test_counts
record=dict(passed=True,exact_candidate_rollback=True,native_gpu_validation=False,full_performance_run=False,
    parent_commit='8d7e2b6ec3a272aff84b6f909106b094dc2390fa',restored_file_sha256=restored,
    test_counts=test_counts,test_total=sum(test_counts),regression=reg,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='Exact D628 rollback and CPU regression only. D629/D630 retained; no new performance gain or final G1/G2 claim.')
"""+code[end:]
replace('faaslora/scheduling/resource_coordinator.py','faaslora/memory/residency_manager.py')
replace('tests/test_ieee_tc_transfer_pressure.py','tests/test_ieee_tc_request_lifecycle.py')
replace('docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md','docs/ieee_tc/D631_PRIVATE_VERIFICATION_ROLLBACK.md')
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: restore verified publication semantics after full W2 regression (D631)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
