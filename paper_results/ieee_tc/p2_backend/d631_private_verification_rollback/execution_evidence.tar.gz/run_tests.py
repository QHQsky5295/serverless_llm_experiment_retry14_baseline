"""D631 exact rollback: reuse D610 bounded, isolated-module CPU regression."""
import ast
from pathlib import Path

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d610_20261017/run_tests.py')
code=source.read_text()
changes={
    'code = source.read_text()': 'code = source.read_text().replace("(\'focused\',\'regression\')", "(\'qualification\',)")',
    "    'tests/test_ieee_tc_request_lifecycle.py')]": "    'tests/test_ieee_tc_request_lifecycle.py',\n    'tests/test_ieee_tc_transfer_pressure.py',\n    'tests/test_ieee_tc_static_preparation.py',\n    'tests/test_http_artifact_store.py')]",
    "'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_static_preparation'])": "'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_static_preparation',\n    'tests.test_ieee_tc_file_observation', 'tests.test_http_artifact_store'])",
}
for old,new in changes.items():
    assert code.count(old)==1,old
    code=code.replace(old,new)
ast.parse(code)
exec(compile(code,str(source),'exec'))
