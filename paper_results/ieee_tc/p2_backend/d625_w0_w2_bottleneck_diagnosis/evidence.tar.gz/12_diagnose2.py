"""Reuse the first diagnosis, explicitly validating cancelled activation schema."""
import ast
from pathlib import Path
import sys
original=Path(__file__).resolve().with_name('diagnose.py')
outer=original.read_text()
hook="    exec(compile(code,str(source),'exec'))"
assert outer.count(hook)==1
addition='''    code=code.replace("a['engine_ready_at']", "activation_ready(a)")
    marker="runs={}"
    assert code.count(marker)==1
    helper="""def activation_ready(a):
    if a['state']=='runtime_ready':
        value=a['engine_ready_at']
        assert type(value) in (int,float) and math.isfinite(value)
        assert value>=a['trigger_at']
        return value
    assert a['state']=='cancelled' and a.get('engine_ready_at') is None
    return None

"""
    code=code.replace(marker,helper+marker)
    code=code.replace("RAW/'analysis_", "RAW/'analysis2_")
    ast.parse(code)
    exec(compile(code,str(source),'exec'))'''
outer=outer.replace(hook,addition)
ast.parse(outer)
exec(compile(outer,str(original),'exec'))
