"""Reuse D612's streaming stage auditor for closed D624 W0; reuse sealed W2.

This is a bounded diagnosis, not another performance run or a new threshold.
"""
import ast
import hashlib
from pathlib import Path
import sys

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/diagnose.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='5b9026f7fb88fdb1ccf52423ec18d3767fcfc4c0d4a1f4dd823e1cd6926c6306'
code=data.decode()

def replace(before,after):
    global code
    assert code.count(before)==1,before
    code=code.replace(before,after)

begin=code.index('# Reuse the sealed D608 parent projection;')
end=code.index('    folder=RAW.parent/dirname',begin)
code=code[:begin]+'''runs={}
projections={}
for name,dirname,tag in [('D624','d624_20261017','7b_device_domain_full_w0')]:
'''+code[end:]
replace('20261017_d611_7b_inventory_extent_full_w2.yaml','20261017_d624_7b_device_domain_full_w0.yaml')
replace("plan=FrozenReplayPlan.load(wi['source_path'],count=4000,profile='W2',\n        adapter_map=wi['adapter_map'],adapter_map_sha256=wi['adapter_map_sha256'])",
        "plan=FrozenReplayPlan.load(wi['source_path'],count=4000,profile='W0')")
replace("stages_ms=st['stages_ms'],dominant_ttft_stage=max(ttft_stages,key=ttft_stages.get))",
        """stages_ms=st['stages_ms'],dominant_ttft_stage=max(ttft_stages,key=ttft_stages.get),
                nested_routing_ms=st['nested_routing_ms'],
                native_timing={k:v for k,v in r['native_token_timing'].items()
                    if type(v) in (int,float,bool,str) or v is None},
                diagnostic_scalars={k:v for k,v in r.items()
                    if (type(v) in (int,float,bool) or v is None) and
                    any(label in k for label in ('load','prepar','admission','rpc','routing','control_path','runtime'))})""")
replace("trigger_offset_s=a['trigger_at']-t0,ready_offset_s=a['engine_ready_at']-t0,",
        "trigger_offset_s=a['trigger_at']-t0,ready_offset_s=(a['engine_ready_at']-t0 if a['engine_ready_at'] is not None else None),")
replace('    projections[name]=projected', '''    runs[name]['reporting_windows_500']=[dict(index=i//500,
        **summarize(rows[i:i+500])) for i in range(0,4000,500)]
    runs[name]['bad_by_window_500']=[dict(index=i//500,
        **summarize([r for r in rows[i:i+500] if not r['joint']])) for i in range(0,4000,500)]
    runs[name]['source501_1500']=summarize(rows[500:1500])
    runs[name]['source501_1500_bad']=summarize([r for r in rows[500:1500] if not r['joint']])
    classes={'TTFT_only':[r for r in rows if not r['ttft_good'] and r['tpot_good']],
             'TPOT_only':[r for r in rows if r['ttft_good'] and not r['tpot_good']],
             'both':[r for r in rows if not r['ttft_good'] and not r['tpot_good']]}
    runs[name]['violation_classes']={k:summarize(v) for k,v in classes.items()}
    assert sum(len(v) for v in classes.values())==len(bad)
    intervals=sorted((a['trigger_at']-t0,a['engine_ready_at']-t0) for a in acts
        if a['category']=='natural_scaleout' and a['engine_ready_at'] is not None)
    union=[]
    for a,b in intervals:
        if not union or a>union[-1][1]:union.append([a,b])
        else:union[-1][1]=max(union[-1][1],b)
    for r in rows:
        r['scaleout_overlap_before_first_ms']=1000*sum(overlap(r['arrival_s'],
            r['arrival_s']+r['ttft_ms']/1000,a,b) for a,b in union)
    runs[name]['scaleout_overlap_conditional']={
        'overlap':summarize([r for r in rows if r['scaleout_overlap_before_first_ms']>0]),
        'no_overlap':summarize([r for r in rows if r['scaleout_overlap_before_first_ms']==0]),
        'bad_overlap':summarize([r for r in bad if r['scaleout_overlap_before_first_ms']>0]),
        'bad_no_overlap':summarize([r for r in bad if r['scaleout_overlap_before_first_ms']==0]),
        'ready_natural_intervals':intervals,
        'cancelled_activations_not_zero_filled':[a for a in acts if a['engine_ready_at'] is None],
        'caveat':'Conditional overlap with activations that reached ready, not counterfactual causation. Cancelled paths retained separately.'}
    projections[name]=projected''')
begin=code.index("assert runs['D607']['workload_identity']==runs['D611']['workload_identity']")
end=code.index('protected=p.verify_seal',begin)
code=code[:begin]+'''parent_path=ROOT/'paper_results/ieee_tc/p2_backend/d623_w2_slo_shortfall_diagnosis/summary.json'
parent=read(parent_path)
assert parent['passed'] and parent['diagnosis']['passed']
assert parent['diagnosis']['control_limits']==limits
old_diagnosis=RAW.parent/'d623_20261017/diagnosis.json'
members=[m for m in parent['archive_members'].values() if m['path']==str(old_diagnosis)]
assert len(members)==1 and p.digest(old_diagnosis)==members[0]['sha256']
assert read(old_diagnosis)==parent['diagnosis']
runs['D621']=parent['diagnosis']['runs']['D621']
assert runs['D624']['all']['joint']==3810 and runs['D621']['all']['joint']==3798
assert runs['D624']['workload_identity']['source_sha256']==runs['D621']['workload_identity']['source_sha256']
assert runs['D624']['workload_identity']!=runs['D621']['workload_identity']
ref(parent_path);ref(old_diagnosis);ref(source)
changes={}
'''+code[end:]
replace('d612_w2_residual_and_holding_v1','d625_closed_w0_w2_bottleneck_diagnosis_v1')
replace('matched_transitions=changes,control_limits=limits,source_refs=refs,',
        "paired_request_comparison_performed=False,control_limits=limits,source_refs=refs,\n    phase_definition='W0 has rotation500; W2 rotation100. Reporting windows are labelled; no paired causal comparison across different adapters.',")
replace('Matched requests have fixed input but different realized system trajectories; no independent repeat or causal treatment estimate.',
        'Different predefined workload profiles share source arrivals but not adapter assignment; no paired treatment or independent repeat claim.')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('Sealed source and adaptation AST passed; no diagnosis run.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
