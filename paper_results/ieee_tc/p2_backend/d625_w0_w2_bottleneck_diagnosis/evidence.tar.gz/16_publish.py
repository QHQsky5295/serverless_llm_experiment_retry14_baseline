"""Reuse sealed D612 publication, preserving both diagnostic attempts and all fields."""
import ast
import hashlib
from pathlib import Path
import sys

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/publish.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=data.decode()
def replace(before,after):
    global code
    assert code.count(before)==1,before
    code=code.replace(before,after)

replace('d612_w2_quality_resource_diagnosis','d625_w0_w2_bottleneck_diagnosis')
replace('f72091155cd3bb258651fc461db11b9113c72faf','c9047ff05f8bfecbdc93c9219c2ae3396a2a6e1b')
replace("for name in ('analysis',):", "for name in ('analysis','analysis2'):")
replace("RAW/'analysis_receipt.json'", "RAW/'analysis2_receipt.json'")
replace("assert sum(x['n'] for x in diagnosis['matched_transitions'].values())==8000//2", """assert diagnosis['paired_request_comparison_performed'] is False
assert diagnosis['runs']['D624']['workload_identity']!=diagnosis['runs']['D621']['workload_identity']
assert read(RAW/'analysis_failure.json')['returncode']==1
assert read(RAW/'analysis_failure.json')['performance_results_changed'] is False""")
replace("assert diagnosis['runs']['D607']['all']['joint']==3762", "assert diagnosis['runs']['D624']['all']['joint']==3810")
replace("assert diagnosis['runs']['D611']['all']['joint']==3819", "assert diagnosis['runs']['D621']['all']['joint']==3798")
replace('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md','D625_W0_W2_BOTTLENECK_DIAGNOSIS.md')
replace("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']", """files += [doc,RAW.parent/'d550_20261015/close.py',
    RAW.parent/'d612_20261017/diagnose.py',RAW.parent/'d612_20261017/publish.py',
    RAW.parent/'d624_20261017/publication_closure.json']""")
# Retain the complete 19.7 MB request projection, not a selectively shortened view.
# Whole archive remains below the existing 32 MiB input cap; 4 GiB process cap holds.
replace('assert len(data)<8*1024*1024','assert len(data)<24*1024*1024')
replace('d612_reused_parent_closed_log_diagnosis_v1','d625_closed_w0_w2_bottleneck_diagnosis_v1')
replace('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
        'tc: distinguish W0 admission wait from W2 preparation bottlenecks (D625)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('Sealed publication adaptation AST passed; no publication executed.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
