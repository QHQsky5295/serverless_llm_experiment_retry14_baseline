#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d117_20260930
unit=primelora-d117-curate-20260930.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/curation_scope.txt"
exec /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/curate_terminal.py" > "$raw/curation.log" 2>&1
