#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d117_20260930
unit=primelora-d117-after-20260930.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/after_scope.txt"
/usr/bin/time -v -o "$raw/after_time.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/probe_terminal.py" > "$raw/after.log" 2>&1
exec /usr/bin/time -v -o "$raw/tests_time.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest tests.test_ieee_tc_launch tests.test_basic_smoke tests.test_ieee_tc_transfer_pressure tests.test_ieee_tc_gpu_lifecycle -v > "$raw/tests.log" 2>&1
