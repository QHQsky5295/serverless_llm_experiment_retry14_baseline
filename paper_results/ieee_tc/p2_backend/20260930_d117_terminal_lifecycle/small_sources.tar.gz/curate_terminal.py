"""D117 closure, adapted from D116 CPU candidate curator; no performance claim."""
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(root))
from scripts.ieee_tc_preflight import digest, verify_seal
raw = root/'results/ieee_tc/p2_backend_qualification/d117_20260930'
out = root/'paper_results/ieee_tc/p2_backend/20260930_d117_terminal_lifecycle'
assert not out.exists()
parent = '0ef466c75bd18985a005635bb72ebb36baaf7e18'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == parent
before = json.loads((raw/'before.json').read_text())
after = json.loads((raw/'after.json').read_text())
assert not before['performance_measurement'] and not after['performance_measurement']
assert before['rows'][0]['scale_down_events'] == 1 and after['rows'][0]['scale_down_events'] == 0
assert before['rows'][1] == after['rows'][1]
assert after['rows'][0]['events'] == ['requests_terminal','forward_settled','aggregate']
for p, sha in after['source_sha256'].items():
    assert digest(root/p) == sha, p
assert hashlib.sha256(subprocess.check_output(['git','show',parent+':scripts/run_all_experiments.py'],cwd=root)).hexdigest() == before['source_sha256']['scripts/run_all_experiments.py']
assert digest(raw/'test_ieee_tc_launch_before.py') == before['source_sha256']['tests/test_ieee_tc_launch.py']
log = (raw/'tests.log').read_text()
match = re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK\b', log)
assert match and int(match[1]) == 599
assert not re.search(r'^FAILED|^ERROR:|^FAIL:', log, re.M)
for name in ('before','after','tests'):
    assert 'Exit status: 0' in (raw/f'{name}_time.txt').read_text()
historical_path = root/'paper_results/ieee_tc/p2_backend/20260930_d116_pressure_membership/summary.json'
assert digest(historical_path) == '92a50dce49971f57fe1d654fb51ee253701d6de71a2cb0268cc859ed52241a54'
historical = json.loads(historical_path.read_text())['historical_context']
assert historical['last_online_control']['action'] == 'no_action'
assert len(historical['tail_scale_down']) == 1 and historical['tail_scale_down'][0]['request_index'] == 4000
frozen = json.loads((root/'results/ieee_tc/p2_backend_qualification/d115_20260929/prelaunch_verification.json').read_text())
allowed = {(root/p).resolve() for p in ('scripts/run_all_experiments.py','tests/test_ieee_tc_launch.py','tests/test_ieee_tc_transfer_pressure.py')}
changed = []
for name, old in frozen['source_sha256'].items():
    p = Path(name) if name.startswith('/') else root/name
    now = digest(p)
    if now != old:
        assert p.resolve() in allowed, name
        changed.append(dict(path=name,before=old,after=now))
for p, sha in {
    'faaslora/scheduling/resource_coordinator.py':'60281e8ea2de21e8fd7e10cba5c15970795a27fea2a814297488fb716a5e45fd',
    'tests/test_ieee_tc_transfer_pressure.py':'f622bfaff924684c7fcba30fbd038a6743a4941cc81018be0adb38870b6d35db',
}.items():
    assert digest(root/p) == sha, p
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
receipts = []
for name, invocation in [('before','e4a73535609f4f43a0e19ed3ca57d5b5'),('after','eb302bb915d24e3c8a9bdc4466d2656a')]:
    unit = f'primelora-d117-{name}-20260930.scope'
    def prop(key):
        return subprocess.check_output(['systemctl','--user','show',unit,'-p',key,'--value'],text=True).strip()
    assert prop('InvocationID') == invocation and prop('TasksCurrent') == '0'
    cg = Path('/sys/fs/cgroup'+prop('ControlGroup'))
    assert not (cg/'cgroup.procs').read_text().strip() and 'populated 0' in (cg/'cgroup.events').read_text()
    events = (cg/'memory.events').read_text()
    assert all(int(line.split()[1]) == 0 for line in events.splitlines())
    with (raw/f'{name}_memory_events.txt').open('x') as f: f.write(events)
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert prop('ActiveState') == 'inactive'
    receipts.append(dict(unit=unit,invocation=invocation,tasks=0,populated=0,stopped=True))
with (raw/'probe_scopes_cleanup.json').open('x') as f: json.dump(receipts,f,indent=2)
out.mkdir()
summary = dict(kind='d117_terminal_lifecycle_candidate_v1',before=before,after=after,
    tests=dict(count=int(match[1]),seconds=float(match[2]),passed=True),
    historical_context=historical,frozen_source_refs_checked=len(frozen['source_sha256']),
    expected_changes=changed,protected=protected,cleanup=receipts,source_parent_commit=parent,
    full_qualified=False,formal_performance_result=False,
    test_scope='actual run/shutdown methods, explicit fixture replay/native cleanup; no GPU latency observation',
    change='IEEE terminal path delegates activation/residency/movement settlement and all retirement to existing common shutdown owner; legacy unchanged',
    next='ONE canonical 3B Full11, same config/inputs/profile; no additional optimizer')
with (out/'summary.json').open('x') as f: json.dump(summary,f,indent=2,allow_nan=False)
members = sorted(p for p in raw.iterdir() if p.is_file() and p.stat().st_size < 2*1024*1024 and p.name != 'curation.log')
hashes = {}
with tarfile.open(out/'small_sources.tar.gz','x:gz') as archive:
    for p in members:
        data = p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        hashes[p.name] = hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(out/'small_sources.tar.gz','r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, sha in hashes.items(): assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == sha
with (out/'members.json').open('x') as f: json.dump(hashes,f,indent=2)
with (out/'SHA256SUMS').open('x') as f:
    for name in ('summary.json','small_sources.tar.gz','members.json'): f.write(digest(out/name)+'  '+name+'\n')
print(json.dumps(dict(output=str(out),summary_sha256=digest(out/'summary.json'),tests=summary['tests'],expected_changed_refs=len(changed),protected=147,bundle_members=len(hashes))))
