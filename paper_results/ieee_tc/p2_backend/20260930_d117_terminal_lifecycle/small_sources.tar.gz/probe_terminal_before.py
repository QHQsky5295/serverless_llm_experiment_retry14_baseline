"""Actual run() branch observation; fixture replay, no GPU or latency claim."""
import asyncio
import hashlib
import json
import sys
from pathlib import Path
root=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(root))
from tests.test_ieee_tc_launch import terminal_run_observation

async def main():
    rows=[]
    for policy in ('ieee_confirmed','least_loaded'):
        service,result,events=await terminal_run_observation(policy)
        assert result.total==len(result.requests)==1
        assert result.scale_down_events==1 and events==[
            'requests_terminal','join_pending_activation','legacy_scale_down',
            'forward_settled','aggregate','legacy_extra_cleanup']
        rows.append(dict(policy=policy,events=events,scale_down_events=result.scale_down_events))
    data=dict(kind='d117_terminal_branch_before_v1',rows=rows,performance_measurement=False,
        source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in
            ('scripts/run_all_experiments.py','tests/test_ieee_tc_launch.py')})
    out=root/'results/ieee_tc/p2_backend_qualification/d117_20260930/before.json'
    with out.open('x') as f:json.dump(data,f,indent=2)
    print(json.dumps(data,indent=2))
asyncio.run(main())
