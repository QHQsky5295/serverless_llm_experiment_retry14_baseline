"""Reuse post-release collector/common full4000 analyzer in one bounded scope."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
with (raw/'analysis_identity.json').open('x') as stream:json.dump(identity,stream,indent=2)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
local=json.loads((raw/'local_cleanup.json').read_text())
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
stop=(raw/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive')==stop.count('MainPID=0')==3
commands=[('collection1.log',[sys.executable,str(raw/'collect_closure.py')]),
          ('analysis1.log',[sys.executable,str(raw/'analyze.py')])]
results=[]
try:
    for name,command in commands:
        with (raw/name).open('x') as log:
            result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        results.append(dict(command=command,log=name,returncode=result.returncode))
        result.check_returncode()
finally:
    record=dict(passed=len(results)==len(commands) and all(r['returncode']==0 for r in results),
        identity=identity,commands=results,resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')})
    with (raw/'analysis_receipt.json').open('x') as stream:json.dump(record,stream,indent=2)
print(json.dumps(record),flush=True)
