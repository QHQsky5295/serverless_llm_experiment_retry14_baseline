"""Reuse validated native prefix and D595 tests; no new workload or policy."""
import ast, copy, json, os, subprocess, sys
from pathlib import Path
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'qualification2_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],p.GIB);assert gate['preflight_pass'],gate['issues']
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='19c812d63579701bafe35a8a88da96b29e715ed5'
previous=RAW.parent/'d595_20261017'
reg=read(previous/'regression2_receipt.json');assert reg['passed']
for path,sha in reg['sources'].items():assert p.digest(Path(path))==sha,path
for phase in ('regression2','backup'):
    closure=read(previous/(phase+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
old=read(RAW.parent/'d550_20261015/qualification.json')
w2binding=read(RAW.parent/'d554_20261015/qualification.json')
for path,sha in old['preserved'].items():assert p.digest(Path(path))==sha,path
for name in ('faaslora/datasets/workload_generator.py','docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
             'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'):
    assert p.digest(ROOT/name)==w2binding['refs'][str(ROOT/name)],name
paths=[ROOT/'configs/ieee_tc/20261015_d550_7b_initial_control_validation_100.yaml',
       ROOT/'configs/ieee_tc/20261015_d554_7b_initial_control_full_w2.yaml',
       ROOT/'configs/ieee_tc/20261017_d598_7b_parallel_pressure_full_w2.yaml']
configs=[yaml.safe_load(path.read_text()) for path in paths]
normalized=copy.deepcopy(configs)
for row in normalized:
    row['experiment'].pop('output_dir')
    row['storage'].pop('nvme_cache_dir');row['storage'].pop('host_cache_dir')
assert normalized[0]==normalized[1]==normalized[2]
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
body=shell.read_text();start=body.index('  d598)\n');end=body.index('    ;;\n',start)+len('    ;;\n')
branch=body[start:end]
assert paths[2].name in branch and 'PREFIX_COUNT=\n' in branch and 'SCENARIO=tc_ieee_full\n' in branch
restored=(body[:start]+body[end:]).replace(' || "${1:-d293}" == d598','')
assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
w2=w2binding['prime_plan']
plan=FrozenReplayPlan.load(w2['source_path'],profile='W2',adapter_map=w2['adapter_map'],
    adapter_map_sha256=w2['adapter_map_sha256'])
assert plan.identity()==w2 and len(plan.entries)==4000
assert FrozenReplayPlan.from_launch_context(dict(plan=plan.identity(),tiny_witness=False,replay_scope='full_source_v1'))==plan
native=RAW.parent/'d597_20261017'
audit=read(native/'actual_qualification.json');pressure=read(native/'parallel_pressure_evidence.json')
assert audit['passed'] and audit['protocol_bound_count']==100 and audit['native_tokens']==17369
assert pressure['passed'] and pressure['multi_owner_triggered']
for ref in audit['refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
for phase in ('analysis','publication2'):
    closed=read(native/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
buildpath=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=read(buildpath);assert build['passed'] and build['actual_closure']['path_gone']
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256'],path
helpers=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),shell])
for path in helpers:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    else:subprocess.run(['bash','-n',str(path)],check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
refs=[native/'actual_qualification.json',native/'parallel_pressure_evidence.json',*helpers,*paths,previous/'regression2_receipt.json',buildpath,
      ROOT/'faaslora/datasets/workload_generator.py',ROOT/'faaslora/scheduling/resource_coordinator.py',
      ROOT/'scripts/run_all_experiments.py',ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json',
      ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
for key in ('ieee_service_profile','ieee_preparation_profile'):
    ref=configs[2]['resource_coordination'][key];path=Path(ref['path'])
    assert p.digest(path)==ref['sha256'];refs.append(path)
import torch
assert not torch.cuda.is_initialized()
save(RAW/'qualification.json',dict(passed=True,scope=identity,gate=gate,protected=protected,
    preserved=old['preserved'],prime_plan=plan.identity(),source_count=4000,count=4000,
    same_configuration_as_d550_d554=True,reused_cpu_regression_tests=368,reused_input_tests=386,
    full_w2_identity=w2,native_prefix_count=100,native_mechanism_triggered=True,
    ranking_eligible=False,refs={str(path):p.digest(path) for path in refs}))
print(json.dumps(dict(passed=True,count=4000,profile='W2',reused_tests=368)))
