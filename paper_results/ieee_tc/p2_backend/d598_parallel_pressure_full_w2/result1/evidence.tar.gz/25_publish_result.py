"""Reuse existing explicit-source result publication pattern for D598."""
import ast, hashlib, io, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d598_parallel_pressure_full_w2/result1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD')=='fa02740f1a5e16a8823da67ab6abe845e4932296'
assert not git('diff','--cached','--name-only')
assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')
audit=read(RAW/'actual_qualification.json');mechanism=read(RAW/'parallel_pressure_evidence.json')
assert audit['passed'] and audit['protocol_bound_count']==4000 and audit['native_tokens']==458224
assert audit['stats']['n_correct'] is None and audit['fixed_workload_complete4000']
assert mechanism['passed'] and mechanism['multi_owner_triggered']
assert sum(mechanism['participant_counts'].values())==mechanism['records']
for ref in audit['refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
for name in ('qualification2','backup','start','analysis'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
local=read(RAW/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
binding=read(RAW/'qualification.json')
for path,sha in {**binding['refs'],**binding['preserved']}.items():assert p.digest(Path(path))==sha,path
old_path=RAW.parent/'d554_20261015/actual_qualification.json'
old=read(old_path)
assert old['passed'] and old['protocol_bound_count']==4000 and old['native_tokens']==458224
assert old['evidence']['source_sha256']=='bda577e019baf5ff61763a7faaab8814b6be08d4f54283f1675bdae8a054e975'
assert old['workload_identity']==audit['workload_identity']
comparison=dict(reference_audit_path=str(old_path),reference_audit_sha256=p.digest(old_path),
    reference_source_sha256=old['evidence']['source_sha256'],
    old_joint_count=old['common_threshold_joint_count'],
    new_joint_count=audit['common_threshold_joint_count'],
    joint_percentage_point_delta=(audit['common_threshold_joint_count']-old['common_threshold_joint_count'])/40,
    old_stats=old['stats'],new_stats=audit['stats'],
    p95_ttft_relative_improvement=(old['stats']['p95_ttft_ms']-audit['stats']['p95_ttft_ms'])/old['stats']['p95_ttft_ms'],
    physical_gpu_relative_improvement=(old['stats']['physical_gpu_seconds']-audit['stats']['physical_gpu_seconds'])/old['stats']['physical_gpu_seconds'],
    whole_cache_prestate_equivalence_proved=False,
    candidate_accepted_as_performance_improvement=False,
    conclusion='Full W2 below joint95%; small observed P95 decrease with lower joint attainment and higher lifecycle GPU time. Preserve both runs; diagnose before retaining/reverting; no repeat of this execution key.')
reference_path=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft/resident_references.json'
reference=read(reference_path)['W2']
assert reference['reference_frozen'] and reference['source_run']=='D557'
assert reference['budget_fraction']==0.75
comparison['resource_reference']=dict(path=str(reference_path),sha256=p.digest(reference_path),record=reference)
comparison['U_over_B']=audit['stats']['physical_gpu_seconds']/reference['B_gpu_seconds']
comparison['joint95_observed']=audit['common_threshold_joint_count']>=3800
comparison['budget_feasible_observed']=audit['stats']['physical_gpu_seconds']<=reference['B_gpu_seconds']
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),*RAW.glob('*.json'),
    *(path for path in RAW.glob('*.log') if path.name!='remote_monitor.log')])
run=RAW/'7b_parallel_pressure_full_w2'
files += [reference_path,old_path,run/'launch.json',run/'launch.launch/physical_deployment/summary.json',
    ROOT/'docs/ieee_tc/D598_PARALLEL_PRESSURE_FULL_W2.md']
OUT.mkdir(parents=True,exist_ok=False);members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as bundle:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<8*1024*1024;clean(data)
        if path.suffix=='.py':ast.parse(data)
        name=f'{i:02d}_{path.name}';info=tarfile.TarInfo(name)
        info.size,info.mode,info.mtime=len(data),0o600,0
        bundle.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'summary.json',dict(passed=True,native_full_qualified=True,full_performance_complete=True,
    independent_numerical_correctness='unknown',raw_n_correct=None,ranking_eligible=False,
    audit=audit,mechanism=mechanism,comparison=comparison,protected=protected,execution_commit=git('rev-parse','HEAD'),
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz')))
with (OUT/'result.sha256').open('x') as stream:
    for name in ('summary.json','evidence.tar.gz'):stream.write(p.digest(OUT/name)+'  '+name+'\n')
names=['docs/ieee_tc/D598_PARALLEL_PRESSURE_FULL_W2.md','docs/ieee_tc/EXECUTION_STATUS.md']
names += [str((OUT/name).relative_to(ROOT)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
for name in names:
    if not name.endswith('.tar.gz'):clean((ROOT/name).read_bytes())
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: preserve full W2 outcome and nonfeasibility of parallel-pressure candidate (D598)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD');remote=git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
