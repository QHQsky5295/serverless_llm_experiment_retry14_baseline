"""Reuse full W2 analyzer, retain its strict output, expose new lifecycle evidence."""
import contextlib
import io
import ijson
import json
from pathlib import Path
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
# The parent post-release collector owns and records the shared analysis scope.
source=RAW/'analyze_prefix.py'
out=io.StringIO()
with contextlib.redirect_stdout(out):
    exec(compile(source.read_text(),str(source),'exec'),dict(__file__=str(source),__name__='d598_audit'))
result=json.loads(out.getvalue())
with (RAW/'actual_qualification.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
with (RAW/'7b_parallel_pressure_full_w2/launch.launch/physical_deployment/main_outcome.json').open('rb') as handle:
    cpu_preparation=next(ijson.items(handle,'cpu_frontend_preparation',use_float=True))
with (RAW/'cpu_preparation_evidence.json').open('x') as f:
    json.dump(cpu_preparation,f,indent=2,allow_nan=False)
outcome = RAW/'7b_parallel_pressure_full_w2/launch.launch/physical_deployment/main_outcome.json'
def selected(prefix):
    with outcome.open('rb') as stream:
        return next(ijson.items(stream,prefix,use_float=True))
initial = selected('mechanism_events._ieee_initial_deployment')
control = selected('mechanism_events._ieee_control_events')
activations = selected('mechanism_events._ieee_activations')
assert initial['control_policy']=='observed_arrivals_v1' and initial['state']=='serving'
assert not initial['failures']
assert initial['control_start_at']<=initial['first_ready_at']
early = [row for row in control if row['observed_at']<initial['first_ready_at']]
scheduled = [row for row in early if row['outcome']=='activation_scheduled']
early_natural = [row for row in activations if row['category']=='natural_scaleout'
                 and row['trigger_at']<initial['first_ready_at']]
mechanism = dict(initial=initial,early_control=early,early_scheduled=scheduled,
    early_natural_activations=early_natural,
    native_early_control_triggered=bool(scheduled and early_natural),
    no_forced_delay_or_cache_reset=True,performance_benefit_proved=False,
    caveat='Natural initial readiness may precede business arrivals; absence of early scale-out is not a trigger proof.')
with (RAW/'initial_control_evidence.json').open('x') as f:
    json.dump(mechanism,f,indent=2,allow_nan=False)
print(json.dumps(dict(passed=result['passed'],stats=result['stats'],
    joint=result['common_threshold_joint_count'],tokens=result['native_tokens'],
    activation=result['activation_state_counts'],resources=result['resources'],
    cpu_preparation_count=len(cpu_preparation['records'])),indent=2))

# Reuse retained native acknowledgement events; overlapping RPC durations are
# deliberately not added to the enclosing barrier wall time.
from collections import Counter
request_source=next((RAW/'7b_parallel_pressure_full_w2').glob('experiment_results*.json'))
with request_source.open('rb') as stream:
    pressure=list(ijson.items(stream,'metadata.scenario_coordination.tc_ieee_full.adapter_transfer_pressure.item',use_float=True))
assert pressure
states=Counter();participants=Counter();late_attach=0;rows=[]
for row in pressure:
    assert row['projection_policy']=='parallel_owner_barrier_v1'
    assert row['state']=='finished', row
    states[row['operation_outcome']]+=1
    participants[len(row['participants'])]+=1
    for owner,member in row['participants'].items():
        assert member['state']=='finished'
        start,finish=member['start_receipt'],member['finish_receipt']
        assert start['owner_id']==finish['owner_id']==owner
        assert start['transfer_id']==finish['transfer_id']==row['transfer_id']
        assert start['clock_id']==finish['clock_id']==row['clock_id']
        assert start['state']=='active' and finish['state']=='finished'
        assert row['created_at']<=start['observed_at']<=finish['observed_at']<=row['finished_at']
        if 'io_started_at' in row:
            late_attach+=start['observed_at']>row['io_started_at']
        assert row['io_joined_at']<=finish['observed_at']
    rows.append(dict(transfer_id=row['transfer_id'],participants=len(row['participants']),
        operation_outcome=row['operation_outcome'],source_tier=row['source_tier'],
        target_tier=row['target_tier']))
with (RAW/'parallel_pressure_evidence.json').open('x') as stream:
    json.dump(dict(passed=True,policy='parallel_owner_barrier_v1',records=len(pressure),
        states=dict(states),participant_counts=dict(participants),late_attach_receipts=late_attach,
        multi_owner_triggered=any(n>=2 for n in participants),rows=rows,
        source_sha256=p.digest(request_source),
        caveat='Native identity/order/settlement checks plus D595 deterministic concurrency tests; no independent RPC-send overlap timestamps or causal performance claim.'),stream,indent=2)
print(json.dumps(dict(pressure_qualified=True,records=len(pressure),participants=dict(participants))))
