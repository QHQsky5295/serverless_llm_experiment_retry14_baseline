"""D811 reuses D593's identity-checked empty resource-domain closure."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d593_20261017/close.py')
exec(compile(source.read_text(), str(source), 'exec'), globals())
