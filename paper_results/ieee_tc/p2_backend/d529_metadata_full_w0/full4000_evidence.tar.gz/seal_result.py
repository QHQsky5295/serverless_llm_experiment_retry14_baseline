"""Reuse D528 result-sealing pattern; compare already audited full4000 evidence.

No new inference, numerical-equivalence claim or ranking of unqualified results.
"""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d529_metadata_full_w0'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, record):
    with path.open('x') as stream:
        json.dump(record, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
save(RAW/'review_identity.json', identity)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
for name in ('analysis', 'contract', 'result'):
    closed = read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
q = read(RAW/'actual_qualification.json')
cross = read(OUT/'cross_contract.json')
metadata = read(OUT/'metadata_audit.json')
assert q['passed'] and q['protocol_bound_count'] == 4000 and q['native_tokens'] == 458224
assert cross['passed'] and cross['request_count'] == 4000
assert metadata['passed'] and metadata['metadata_use_count_qualified']
assert metadata['request_release_snapshots'] == 4000
for refs in (q['refs'], cross['refs'], metadata['refs']):
    for ref in refs:
        assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
previous_path = ROOT/'paper_results/ieee_tc/p2_backend/d476_full_w0/actual_qualification.json'
previous = read(previous_path)
assert previous['passed'] and previous['protocol_bound_count'] == 4000
assert previous['native_tokens'] == q['native_tokens']
comparison = {
    key: dict(previous=previous['stats'][key], current=q['stats'][key],
        lower_better_relative_change=(previous['stats'][key]-q['stats'][key])/previous['stats'][key])
    for key in ('mean_ttft_ms', 'p95_ttft_ms', 'mean_queue_ms', 'mean_service_ms',
                'mean_tpot_ms', 'p95_tpot_ms', 'physical_gpu_seconds')
}
counts = dict(previous=previous['common_threshold_joint_count'],
              current=q['common_threshold_joint_count'])
assert counts == dict(previous=3897, current=3820)
assert q['stats']['physical_gpu_seconds'] > previous['stats']['physical_gpu_seconds']
assert q['stats']['p95_ttft_ms'] > previous['stats']['p95_ttft_ms']
record = dict(kind='d529_full4000_metadata_candidate_review_v1', passed=True,
    decision='reject_as_performance_improvement', selected_reference='D476',
    reason='Higher observed GPU occupancy and tail latency, lower observed joint attainment; no repeat or threshold change.',
    qualification=q, comparison_to_d476=comparison,
    joint_counts=counts, joint_difference_percentage_points=100*(counts['current']-counts['previous'])/4000,
    gpu_seconds_per_protocol_bound_request=q['stats']['physical_gpu_seconds']/4000,
    protocol_bound_timing_feasible=counts['current'] >= 3800,
    n_correct=None, numerical_correctness_qualified=False, performance_ranking_eligible=False,
    output_digest_changes=len(cross['same_backend_output_digest_changes_vs_d476']),
    numerical_difference_cause='unknown; no raw token arrays or matched full-model numerical oracle',
    metadata_use_count_qualified=True,
    observed_updates_lower_bound=metadata['observed_updates_lower_bound'],
    observed_copied_bytes_lower_bound=metadata['observed_copied_bytes_lower_bound'],
    observed_reuse_waits_lower_bound=metadata['observed_reuse_waits_lower_bound'],
    installed_workers=len(metadata['installed_workers']),
    remote_counts_equal_to_d476=q['remote_transfers']==previous['remote_transfers'],
    remote_wire_bytes_equal_to_d476=q['remote_wire_bytes']==previous['remote_wire_bytes'],
    confidence_interval=None, independent_holdout=False, repeats=1,
    next='Archive this candidate without repeat; use D476 as the retained reference. Review existing stage/lifecycle evidence for one new falsifiable bottleneck before any new serving edit or run. W1/W2/G2,3B,ablations,sensitivities and reviewer work remain active.',
    scope=identity,
    refs=[dict(path=str(path), sha256=p.digest(path)) for path in
          (previous_path, RAW/'actual_qualification.json', OUT/'cross_contract.json',
           OUT/'metadata_audit.json', RAW/'analysis_closure.json', RAW/'contract_closure.json',
           RAW/'result_closure.json', Path(__file__))])
save(RAW/'result.json', record)
save(OUT/'full4000_result.json', record)
print(json.dumps(dict(passed=True, decision=record['decision'], comparison=comparison,
    joint_difference_percentage_points=record['joint_difference_percentage_points'],
    output_digest_changes=record['output_digest_changes']), indent=2), flush=True)
