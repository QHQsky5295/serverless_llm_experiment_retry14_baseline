"""Post-release D529 audit: reuse D528 installation checks plus retained counters.

No inference, device readback, performance claim or numerical-equivalence claim.
Prepared while the full replay is live; execute only after its analysis closes.
"""
import collections
import ijson
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d529_metadata_full_w0'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.plot_d290_diagnostic import load

def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)

identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'result_identity.json',identity)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
q=read(RAW/'actual_qualification.json')
assert q['passed'] and q['protocol_bound_count']==4000
for ref in q['refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
run=RAW/'7b_full_w0'
source=next(run.glob('experiment_results*.json'))
_,scenario=load(source)
requests=scenario['requests'];assert len(requests)==4000
outcome_path=run/'launch.launch/physical_deployment/main_outcome.json'
with outcome_path.open('rb') as handle:
    coordination=next(ijson.items(handle,'coordination_after_shutdown',use_float=True))
owners=coordination['ieee_native_host_budget_owners']
by_id={owner['owner_id']:owner for owner in owners}
assert len(by_id)==len(owners)
samples=collections.defaultdict(list)
for row in requests:
    evidence=row['gpu_reference_evidence']
    acquire=evidence['receipt'];release=evidence['release_receipt']
    assert evidence['state']=='released' and release['released'] is True
    assert release['owner_id']==acquire['owner_id'] and release['owner_id'] in by_id
    owner=by_id[release['owner_id']]
    assert release['worker_pid']==owner['process_identity']['pid']
    assert release['worker_rank']==0 and release['clock_id']==owner['receipt']['clock_id']
    snapshot=release['metadata_publication']
    assert snapshot['installed'] and snapshot['policy']=='cpu_live_mapping_v1'
    assert not snapshot['poisoned'] and not snapshot['gpu_buffers_replaced']
    assert snapshot['native_mapping_invalidation_preserved']
    assert (snapshot['banks'],snapshot['rows'],snapshot['slots'],snapshot['staging_bytes'])==(2,1024,14,99040)
    for key in ('updates','copied_bytes','reuse_waits'):
        assert type(snapshot[key]) is int and snapshot[key]>=0
    assert type(release['epoch']) is int and release['epoch']>=0
    samples[release['owner_id']].append(dict(request_id=row['request_id'],
        epoch=release['epoch'],**{k:snapshot[k] for k in ('updates','copied_bytes','reuse_waits')}))
installation=[]
for owner in owners:
    receipt=owner['receipt'];initial=receipt['metadata_publication']
    assert owner['state']=='retired' and receipt['configured'] and receipt['owner_id']==owner['owner_id']
    assert receipt['worker_pid']==owner['process_identity']['pid']
    assert receipt['tensor_budget_bytes']==2147483648
    assert initial['policy']=='cpu_live_mapping_v1' and initial['installed']
    assert not initial['poisoned'] and not initial['gpu_buffers_replaced']
    assert initial['native_mapping_invalidation_preserved']
    assert (initial['banks'],initial['rows'],initial['slots'],initial['staging_bytes'])==(2,1024,14,99040)
    assert initial['updates']==initial['copied_bytes']==initial['reuse_waits']==0
    before,after=initial['accounted_before_bytes'],initial['accounted_after_bytes']
    assert after-before==99040
    partition=receipt['workspace_partition']
    workspace=partition['registered_upper_bytes']+2*partition['demand_load_peak_bytes']
    assert initial['required_minimum_with_staging_bytes']==before+99040+workspace
    assert after+workspace<=receipt['tensor_budget_bytes'] and receipt['allocation']['admitted']
    assert receipt['allocation']['before']['accounted_tensor_bytes']==after
    rows=sorted(samples[owner['owner_id']],key=lambda r:(r['epoch'],r['updates'],r['copied_bytes'],r['reuse_waits']))
    for previous,current in zip(rows,rows[1:]):
        assert all(current[key]>=previous[key] for key in ('updates','copied_bytes','reuse_waits'))
    if rows:assert rows[-1]['updates']>0 and rows[-1]['copied_bytes']>0
    installation.append(dict(owner_id=owner['owner_id'],worker_pid=receipt['worker_pid'],
        bound_requests=len(rows),pinned_increment_bytes=after-before,
        tensor_budget_bytes=receipt['tensor_budget_bytes'],installed=True,retired=True,
        last_observed_release=rows[-1] if rows else None,
        caveat='Cumulative observed lower bound, not per-request attributable updates; unserved workers have no release sample.'))
budget=coordination['ieee_managed_host_budget']
assert budget['limit_bytes']==17179869184 and budget['native_reserved_bytes']==0
assert sum(row['bound_requests'] for row in installation)==4000
record=dict(passed=True,installation_accounting_passed=True,metadata_use_count_qualified=True,
    request_release_snapshots=4000,installed_workers=installation,global_host_budget=budget,
    observed_updates_lower_bound=sum(row['last_observed_release']['updates'] for row in installation if row['last_observed_release']),
    observed_copied_bytes_lower_bound=sum(row['last_observed_release']['copied_bytes'] for row in installation if row['last_observed_release']),
    observed_reuse_waits_lower_bound=sum(row['last_observed_release']['reuse_waits'] for row in installation if row['last_observed_release']),
    n_correct=None,numerical_correctness_qualified=False,performance_ranking_eligible=False,
    refs=[dict(path=str(path),sha256=p.digest(path)) for path in (source,outcome_path,RAW/'actual_qualification.json',RAW/'analysis_closure.json',Path(__file__))],
    scope=identity)
save(RAW/'metadata_audit.json',record);save(OUT/'metadata_audit.json',record)
print(json.dumps(dict(passed=True,request_release_snapshots=4000,
    workers=len(installation),observed_updates_lower_bound=record['observed_updates_lower_bound'],
    numerical_correctness_qualified=False,scope=identity)),flush=True)
