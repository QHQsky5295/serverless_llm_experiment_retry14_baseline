"""Reuse exact-path Git/archive guard; publish outcome including evidence gaps."""
import ast, hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d529_metadata_full_w0'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0' and os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
record=read(OUT/'full4000_result.json');cross=read(OUT/'cross_contract.json')
metadata=read(OUT/'metadata_audit.json')
assert record['passed'] and record['qualification']['passed'] and metadata['installation_accounting_passed']
assert record['decision']=='reject_as_performance_improvement'
assert record['metadata_use_count_qualified'] is True and record['n_correct'] is None
assert cross['passed'] and cross['request_count']==4000 and len(cross['same_backend_output_digest_changes_vs_d476'])==242
for refs in (record['qualification']['refs'],cross['refs'],metadata['refs'],record['refs']):
    for ref in refs:assert p.digest(Path(ref['path']))==ref['sha256']
for name in ('analysis','result','contract','review'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members=[RAW/name for name in ('collect_closure.py','analyze.py','analyze_prefix.py','run_analysis.py',
    'seal_result.py','cross_contract.py','audit_metadata.py','close.py','publish_result.py','local_cleanup.json',
    'remote_stop.json','remote_stop.log','remote_health.json','analysis1.log','analysis_receipt.json',
    'analysis_closure.json','completion_receipt.json','collection_receipt.json','result_closure.json',
    'contract_closure.json','review_closure.json','remote_transfers.jsonl','actual_qualification.json',
    'cpu_preparation_evidence.json')]
archive=OUT/'full4000_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in members:
        data=path.read_bytes();check(data)
        assert len(data)<8*1024*1024
        if path.suffix=='.py':ast.parse(data)
        bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
with (OUT/'full4000.sha256').open('x') as f:
    for name in ('full4000_result.json','cross_contract.json','metadata_audit.json','full4000_evidence.tar.gz'):
        f.write(p.digest(OUT/name)+'  '+name+'\n')
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D529_FULL_W0_RESULT.md']
names += [str((OUT/name).relative_to(ROOT)) for name in ('full4000_result.json','cross_contract.json','metadata_audit.json','full4000_evidence.tar.gz','full4000.sha256')]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['sha256sum','-c','full4000.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(names) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: retain full W0 metadata candidate outcome and reject performance promotion (D529)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity,protected=protected))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)),flush=True)
