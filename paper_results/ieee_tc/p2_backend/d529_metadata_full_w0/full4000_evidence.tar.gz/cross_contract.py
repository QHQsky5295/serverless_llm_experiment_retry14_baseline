"""Independent existing-baseline input witness; no performance or output equality claim."""
import json
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.ieee_tc.plot_d290_diagnostic import load, sha256
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

scope=p.scope_identity(p.cg_path().name)
with (RAW/'contract_identity.json').open('x') as f:json.dump(scope,f,indent=2)
group=Path(scope['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
closed=json.loads((RAW/'analysis_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
run = RAW/'7b_full_w0'
source = next(run.glob('experiment_results*.json'))
_, scenario = load(source)
requests = {r['request_id']:r for r in scenario['requests']}
context = json.loads((run/'launch.launch/exec_receipt.json').read_text())['external_replay']
plan = FrozenReplayPlan.from_launch_context(context)
entries = {e.request_id:e for e in plan.entries}
prior = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/launch7b.launch/replay.jsonl')
contracts = {}
for line in prior.open():
    event = json.loads(line)
    if event['event'] == 'request_contract':
        assert event['request_id'] not in contracts
        contracts[event['request_id']] = event
assert len(contracts) == 4000 and len(requests) == 4000
assert requests.keys() == entries.keys() and requests.keys() <= contracts.keys()
for rid, row in requests.items():
    ref = contracts[rid]
    entry = entries[rid]
    assert row['adapter_id'] == ref['adapter_id']
    assert row['requested_completion_tokens'] == row['completion_tokens'] == ref['target_tokens']
    assert row['canonical_prompt_sha256'] == ref['canonical_prompt_sha256']
    assert row['canonical_prompt_tokens'] == ref['canonical_prompt_tokens']
    assert row['native_token_timing']['native_prompt_token_ids_sha256'] == ref['native_prompt_token_ids_sha256']
    assert entry.source_sha256 == ref['source_item_sha256']
    assert row['generation_contract'] == 'fixed_length_greedy_v1'
    assert row['output_contract_match'] is True

frozen = {
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'):'d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499',
}
for path, digest in frozen.items():
    assert sha256(path) == digest, path
old_source=next((RAW.parent/'d476_20261012/7b_full_w0').glob('experiment_results*.json'))
_,old_scenario=load(old_source)
old_rows={r['request_id']:r for r in old_scenario['requests']}
assert old_rows.keys()==requests.keys()
changes=[]
for rid,row in requests.items():
    old=old_rows[rid]
    for field in ('adapter_id','requested_completion_tokens','completion_tokens','canonical_prompt_sha256','canonical_prompt_tokens','generation_contract'):
        assert old[field]==row[field], (rid,field)
    assert old['native_token_timing']['native_prompt_token_ids_sha256']==row['native_token_timing']['native_prompt_token_ids_sha256']
    if old['completion_token_ids_sha256']!=row['completion_token_ids_sha256']:changes.append(rid)
result=dict(kind='d529_existing_original4000_input_witness_v1',passed=True,
    same_backend_output_digest_changes_vs_d476=changes,
    numerical_difference_cause='unknown; no rounding or mechanism causal explanation inferred',
    request_count=len(requests),compared_fields=['request_id','adapter_id','target_tokens',
        'canonical_prompt_sha256','canonical_prompt_tokens','native_prompt_token_ids_sha256',
        'source_item_sha256'],
    generation_contract='fixed_length_greedy_v1',output_token_equality_required=False,
    numerical_correctness_qualified=False,performance_comparison=False,
    scope=p.scope_identity(p.cg_path().name),
    refs=[dict(path=str(path),sha256=sha256(path)) for path in (source,prior,old_source,Path(__file__),*frozen)])
with (ROOT/'paper_results/ieee_tc/p2_backend/d529_metadata_full_w0/cross_contract.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(passed=True,request_count=4000,output_digest_changes=len(changes),scope=scope)))
