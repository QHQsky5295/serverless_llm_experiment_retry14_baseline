#!/usr/bin/env bash
# Reuse the actual post-exit absence checks from cache maintenance.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d152_20261002
for spec in prelaunch:b4a13d90bd174d12a53cdb18263da210 health:c24c207a7c0c4264a9ad63edc2ab7d38; do
  phase=${spec%:*}
  expected_id=${spec#*:}
  unit="primelora-d152-${phase}-20261002.scope"
  {
    date -Is
    rg -qx "InvocationID=$expected_id" "$raw/${phase}_scope.txt"
    test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
    test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
    test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
    test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
    systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
    printf 'actual_invocation=%s\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n' "$expected_id"
  } | tee "$raw/${phase}_cleanup.txt"
done
