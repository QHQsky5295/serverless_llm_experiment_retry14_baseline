#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d152_20261002
unit=primelora-d152-full1-metadata-20261002.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_metadata_scope.txt"
# Bounded normal-metadata input, retaining the prior whitespace-only transform.
# Preserve every value and numeric lexeme; remove ASCII indentation only, keeping
# all line boundaries. Never parse/rewrite the source tree or increase the guard.
test -s "$raw/7b_full_w0_full1/launch.json"
test "$(systemctl --user show primelora-tc-svc-378dc55711df47d59f8699da609543bf.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
/usr/bin/python3 - <<'PY'
import json
import subprocess
fixtures = [
    {'strings': [' leading ', 'trailing ', '  both  ', 'escaped\\\"quote', '\n\r\t', '中文'],
     'nested': [{'empty': [], 'object': {}, 'null': None, 'false': False}],
     'large_int': 9007199254740993},
    [1, -2, 0.125, '  ', {'x': 1e-100}],
]
for value in fixtures:
    source = json.dumps(value, indent=24, ensure_ascii=False)
    compact = subprocess.check_output(['sed', '-e', 's/^ *//', '-e', 's/ *$//'],
                                      input=source.encode())
    assert json.loads(compact) == value
    assert compact.count(b'\n') == source.count('\n')
print('Lossless JSON line-indentation fixtures PASS; original source untouched.')
PY
source_file="$raw/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json"
compact_file="$raw/full_full1_main_outcome_compact.json"
LC_ALL=C sed -e 's/^ *//' -e 's/ *$//' "$source_file" > "$compact_file"
test "$(stat -c %s "$compact_file")" -lt 134217728
sha256sum "$source_file" "$compact_file" > "$raw/full_full1_metadata_compaction.sha256"
exec /usr/bin/time -v -o "$raw/full_full1_metadata_time.txt" \
  /usr/bin/python3 "$raw/collect_full1_preliminary.py" > "$raw/full_full1_metadata.log" 2>&1

