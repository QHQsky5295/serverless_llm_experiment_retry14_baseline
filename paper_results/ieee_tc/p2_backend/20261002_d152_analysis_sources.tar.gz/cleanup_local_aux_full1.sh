#!/usr/bin/env bash
set -euo pipefail
unit=primelora-tc-aux-05f670e5caff478ab52afc329cb531d0.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 5228f8f54fda45418d921a7ecfa0edb1
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-05f670e5caff478ab52afc329cb531d0.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
