"""Reuse D621's full-W2 binding and D615's actual-controller qualification."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d621_20261017/qualify.py')
control_source=source.parent.parent/'d615_20261017/qualify.py'
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace('4fa914baeb62b1a6644f0ab9bae10db475092ce8','6b5a57ce9971b7e3ff5febdae828aec59f552de1')
start=code.index('# Production is unchanged');end=code.index('gate=p.preflight',start)
code=code[:start]+"""# D631 restored exactly the source tested before D628; no new production patch.
candidate=RAW.parent/'d631_20261017'
for path,sha in {**old['refs'],**old['preserved']}.items():
    if Path(path)!=shell:assert p.digest(Path(path))==sha,path
receipt=read(candidate/'qualification_receipt.json')
assert receipt['passed'] and receipt['returncode']==0
test_sources=receipt['sources']
for path,sha in test_sources.items():assert p.digest(Path(path))==sha,path
log=candidate/'qualification.log'
assert p.digest(log)==receipt['log_sha256']
import re
assert sum(map(int,re.findall(r'Ran (\\d+) tests?',log.read_text())))==458
assert read(candidate/'backup_receipt.json')['head']=='6b5a57ce9971b7e3ff5febdae828aec59f552de1'
for phase in ('qualification','backup'):
    closed=read(candidate/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
latest=RAW.parent/'d629_20261017'
local=read(latest/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
stop=(latest/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive')==stop.count('MainPID=0')==3
for phase in ('qualification','backup','start','analysis','publication2'):
    closed=read(latest/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
completed=read(latest/'actual_qualification.json')
assert completed['passed'] and completed['protocol_bound_count']==4000
"""+code[end:]
replace("ROOT/'configs/ieee_tc/20261017_d619_7b_device_domain_full_w1.yaml'", "ROOT/'configs/ieee_tc/20261017_d621_7b_device_domain_full_w2.yaml'")
replace("ROOT/'configs/ieee_tc/20261017_d621_7b_device_domain_full_w2.yaml']", "ROOT/'configs/ieee_tc/20261017_d632_7b_min2_full_w2.yaml']")
replace("assert normalized[0]==normalized[1], 'no W2-specific model or policy tuning'", """assert normalized[0]['resource_coordination']['min_instances']==1
assert normalized[1]['resource_coordination']['min_instances']==2
normalized[1]['resource_coordination']['min_instances']=1
assert normalized[0]==normalized[1], 'unregistered model or policy tuning'""")
replace("assert configs[1]['resource_coordination']['min_instances']==1", "assert configs[1]['resource_coordination']['min_instances']==2")
code=code.replace("'  d621)\\n'", "'  d632)\\n'").replace('== d621', '== d632').replace("'d621' not", "'d632' not").replace("'d621' in", "'d632' in")
# Execute the same actual-controller state enumeration, with the sole new floor.
control=control_source.read_text()
start=control.index('# Use the actual new model configuration');end=control.index('buildpath=',start)
control=control[start:end]
assert control.count("assert low(0.,1)")==1 and control.count('lower_bound=1')==1
control=control.replace('low(0.,1)', 'low(0.,2)').replace('low(38.,1)', 'low(38.,2)').replace('lower_bound=1','lower_bound=2')
control=control.replace("('IEEEControlContract','IEEEActualControl','IEEEInitialObservedControl')", "('IEEEControlContract','IEEEActualControl','IEEEInitialObservedControl','IEEEInitialDeployment')")
control="import unittest\nfrom faaslora.coordination.autoscaler import IEEEReplicaControl, ScalingAction\n"+control
replace('buildpath=',control+'buildpath=')
start=code.index('refs=[*helpers');end=code.index("subprocess.run(['git','diff','--check']",start)
code=code[:start]+"""refs=[*helpers,*paths,parent/'qualification.json',previous/'native_reuse.json',oldw2path,buildpath,
    candidate/'qualification_receipt.json',candidate/'qualification.log',candidate/'qualification_closure.json',
    candidate/'backup_receipt.json',candidate/'backup_closure.json',
    latest/'local_cleanup.json',latest/'remote_stop.log',latest/'actual_qualification.json',
    Path(oldw2['adapter_map']),source,control_source,
    RAW/'three_replica_checks.json',RAW/'control_tests.json',RAW/'control_tests.log']
refs += [Path(path) for path in old['refs'] if Path(path)!=shell]
refs += list(map(Path,test_sources))
"""+code[end:]
replace('configuration_changes={}', "configuration_changes={'resource_coordination.min_instances':{'before':1,'after':2}}")
code=code.replace('same_model_working_point_as_d615=True','same_model_working_point_as_d615=False')
replace("three_replica_checks=old['three_replica_checks'],control_tests_run=0,reused_control_tests=21", "three_replica_checks=control_checks,control_tests_run=tested.testsRun,reused_control_tests=0")
replace('reused_cpu_regression_tests=464,reused_focused_tests=60','reused_cpu_regression_tests=458,reused_focused_tests=0')
replace('new_tests=0,reused_regression=464,reused_focused=60','new_tests=tested.testsRun,reused_regression=458,reused_focused=0')
replace('reused_control_tests=21,reused_config_checks=192','reused_control_tests=0,new_config_checks=len(cases)')
exec(compile(code,str(source),'exec'))
