"""Spawn-safe qualification entry; preserve the original failed helper and logs."""
from pathlib import Path

if __name__ == '__main__':
    entry=Path(__file__).resolve().parent/'qualify.py'
    original=entry.read_text()
    tail="exec(compile(code,str(source),'exec'))"
    assert original.count(tail)==1
    injected="""for old,new in (
        ('qualification_identity.json','qualification2_identity.json'),
        ('three_replica_checks.json','three_replica_checks2.json'),
        ('control_tests.log','control_tests2.log'),
        ('control_tests.json','control_tests2.json')):
        code=code.replace(old,new)
    exec(compile(code,str(source),'exec'))"""
    # The module itself is import-safe for multiprocessing spawn. Executed
    # qualification keeps its original globals/RAW and uses new evidence keys.
    injected='\n'.join(line[4:] if line.startswith('    ') else line for line in injected.splitlines())
    exec(compile(original.replace(tail,injected),str(entry),'exec'))
