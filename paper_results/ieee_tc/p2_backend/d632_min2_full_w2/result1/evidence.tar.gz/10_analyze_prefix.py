"""Reuse D621's complete W2 audit; change only result identity."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d621_20261017/analyze_prefix.py')
code = source.read_text()
for old, new in (
    ('7b_device_domain_full_w2', '7b_min2_full_w2'),
    ('d621_actual_initial_control_full4000_qualification_v1', 'd632_min2_full4000_qualification_v1'),
):
    assert code.count(old) == 1, old
    code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
