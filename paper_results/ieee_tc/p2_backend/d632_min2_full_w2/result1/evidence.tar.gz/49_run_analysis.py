"""Reuse the bounded post-collection audit with the restored source SHA."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d629_20261017/run_analysis.py')
code = source.read_text()
old = '3bf7490deff8c917bbad46b79526772a3803f9b030f559b8e63e976052d99407'
assert code.count(old) == 1
code = code.replace(old, 'fd783131934664f1dee49f78b21366c2aff7264d60a15c2a9bcb975e207bec4f')
exec(compile(code, str(source), 'exec'))
