"""Reuse D88 assembly; retain the controller while refreshing cap-dependent data."""
import copy
import json
from pathlib import Path
import yaml
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

ROOT=p.ROOT
raw=ROOT/"results/ieee_tc/p2_backend_qualification/d157_20261002"
output=ROOT/"paper_results/ieee_tc/p2_backend"
config_path=ROOT/"configs/ieee_tc/20261002_d156_7b_cap4.yaml"
spec_path=output/"20261002_d157_7b_admission_source_spec.json"
spec=json.loads(spec_path.read_text())
runtime=ROOT/"results/ieee_tc/p2_backend_qualification/runtime_20260926/cuda_import_attempt3.json"
prior=json.loads(runtime.read_text())
original=output/"20260927_d88_7b_development_contract.json"
assert p.digest(original)=="16f1d71a46adf9a83a9baf629fd1195909636fc5995b84ed575ab43e996acbf5"
old=json.loads(original.read_text())
source=yaml.safe_load(config_path.read_text())["model_profiles"]["llama2_7b_main_v2_publicmix"]
cfg=dict(source["model"])
cfg.update(visible_device_ids=[0],device_id=0,timing_contract="ieee_tc_native_v1",
    ieee_worker_observation=True,ieee_gpu_references=True,ieee_scheduler_observation=True,
    ieee_input_upper_bounds=[759],generation_contract="fixed_length_greedy_v1",
    canonical_prompt_renderer="role_lines_v1",max_input_len=759,max_output_tokens_cap=256,
    ieee_physical_allocation=True)
cfg.update(spec["model_overrides"])
configured,evidence,assembly=p.prepare_admission_source_runtime(cfg,spec,
    backend_version=prior["modules"]["vllm"]["version"],runtime_receipt_sha256=p.digest(runtime),
    source_trace_sha256=spec["trace_sha256"])
child=assembly["planned_child_model_config"]
diff={k:[old["model_config"].get(k),child.get(k)]
      for k in old["model_config"].keys()|child.keys() if old["model_config"].get(k)!=child.get(k)}
assert set(diff)=={"max_num_seqs","runtime_concurrency_cap","requested_runtime_concurrency_cap","ieee_admission_profile"},diff
assert all(diff[k]==[2,4] for k in ("max_num_seqs","runtime_concurrency_cap","requested_runtime_concurrency_cap"))
assert old["model_config"]["ieee_admission_profile"]["profile_means"]==child["ieee_admission_profile"]["profile_means"]
contract=dict(kind="ieee_development_control_runtime_contract_v1",model="7b",development_only=True,
    model_config=child,runtime_receipt_sha256=p.digest(runtime),coordination=copy.deepcopy(old["coordination"]),
    service_ewma_beta=old["service_ewma_beta"],preparation_ewma_beta=old["preparation_ewma_beta"],
    derivation=dict(kind="capacity_only_controller_retention_v1",
        reason="Hold D88 controller settings fixed; refresh runtime identity and measured source/service profiles only",
        original_contract=dict(path=str(original.relative_to(ROOT)),sha256=p.digest(original)),
        new_capacity=4,old_capacity=2,old_timings_relabelled=False),
    source_raw=evidence["source_run"],completed_length_binding=spec["admission_initialization"],
    base_config_sha256=p.digest(config_path),source_workload_profile=old["source_workload_profile"],
    production_profile_frozen=False,full_qualified=False,plan_sha256=p.check_plan())
target=output/"20261002_d157_7b_development_contract.json"
with target.open("x") as f: json.dump(contract,f,indent=2)
reference=dict(path=str(target.relative_to(ROOT)),sha256=p.digest(target))
spec["full_development_contract"]=reference
again=p.prepare_admission_source_runtime(cfg,spec,backend_version=prior["modules"]["vllm"]["version"],
    runtime_receipt_sha256=p.digest(runtime),source_trace_sha256=spec["trace_sha256"])
assert again[2]["full_development_contract"]==reference
bootstrap=json.loads((ROOT/evidence["source_run"]["path"]).read_text())
trace=Path(bootstrap["trace"]["source_path"])
plan=FrozenReplayPlan.load(trace,count=1000)
_,bins,identities,waves,index=p.source_profile_inputs(spec_path,plan,cfg,
    (ROOT/source["storage"]["remote_dir"]).resolve(strict=True))
assert len(waves)==46 and sum(map(len,waves))==184 and len(identities)==6
assert len(index["artifacts"])==500
seal=p.verify_seal(ROOT/"paper_results/ieee_tc/safety/20260925_execution_start_protected.json")
assert seal["pass"]
record=dict(passed=True,contract=reference,model_diff=diff,control_settings_unchanged=True,
    model_config_sha256=p.digest(config_path),spec_before_binding_sha256=p.digest(spec_path),
    proposed_cases=184,representative_cases=180,waves=46,static_adapter_count=500,
    representative_count=6,admission=evidence,assembly=again[2],protected=seal,full_qualified=False)
with (raw/"prepare1.json").open("x") as f: json.dump(record,f,indent=2)
print(json.dumps(dict(contract=reference,passed=True,waves=46,cases=184)))
