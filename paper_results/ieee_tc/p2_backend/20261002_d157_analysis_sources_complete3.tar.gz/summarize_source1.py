"""Offline evidence assembly using existing native interval validation."""
import argparse
from collections import Counter, defaultdict
from dataclasses import asdict
import csv
import hashlib
import json
from pathlib import Path

from faaslora.preloading.preloading_planner import observed_preparation_interval, FrozenPreparationProfiles
from scripts.ieee_tc_preflight import verify_seal

p = argparse.ArgumentParser()
p.add_argument('--run', type=Path, required=True)
p.add_argument('--remote', type=Path, required=True)
p.add_argument('--figures', type=Path, required=True)
p.add_argument('--model', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert not a.output.exists()
raw = json.loads(a.run.read_text())
launch_path = a.run.with_name(a.run.stem + '_launch.json')
launch = json.loads(launch_path.read_text())
assert raw['pass'] and raw['stage'] == 'complete' and raw['shutdown_called'] and raw['profile_workspaces_removed']
assert launch['pass'] and launch['service_returncode'] == launch['watchdog_returncode'] == 0
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert raw['model_config_source'] == 'initialized_model_config_v1'
remote = [json.loads(line) for line in a.remote.read_text().splitlines()]
remote_map = {r['transfer_id']: r for r in remote}
assert len(remote_map) == len(remote)
transfers = raw['remote_transfers']
ids = {r['http_transfer_id'] for r in transfers}
assert len(ids) == len(transfers) and ids <= set(remote_map)
for r in transfers:
    s = remote_map[r['http_transfer_id']]
    assert r['state'] == 'published' and r['content_verified'] and r['published_archive_verified']
    assert r['artifact_id'] == s['artifact_id'] and r['remote_archive_sha256'] == s['archive_sha256']
    assert r['transferred_bytes'] == s['archive_bytes'] == s['bytes_read'] == s['bytes_written']
    assert not r['remote_pack_performed'] and not s['pack_performed'] and not s['temporary_created']
    assert s['outcome'] == 'sent'
source_counts, prep_counts, content, d = Counter(), Counter(), set(), defaultdict(list)
output_hashes = defaultdict(set)
measured = []
for q in raw['requests']:
    assert q['pass'] and q['actual_tokens'] == q['target_tokens']
    assert q['reservation_released'] and q['source_evidence']['state'] == 'released'
    pending = q['source_evidence']['pending_kv_admission']
    assert pending['state'] == 'closed' and pending['close_receipt']['closed']
    wave_number = int(q['request_id'].split('/')[1][1:])
    if raw['source_profile_spec']['waves'][wave_number]['role'] != 'representative_measurement':
        continue
    measured.append(q)
    source_counts[json.dumps(q['service_class'], sort_keys=True)] += 1
    output_hashes[q['source_request_id'], q['adapter_id'], q['prompt_sha256'], q['target_tokens']].add(
        q['timing']['completion_token_ids_sha256'])
    evidence = q['source_evidence']
    admission, native = evidence['source_admission'], evidence['receipt']
    source = admission['source']
    content.add(source.get('expected_content_sha256') if source['native'] else source['content_sha256'])
    if q['requested_source'] == 'gpu':
        continue
    match = None
    if q['requested_source'] == 'remote':
        matches = [r for r in transfers if r['artifact_id'] == q['adapter_id']
                   and r['target_path'] == native['lora_path']
                   and admission['admitted_monotonic_s'] <= r['loading_started_monotonic_s']
                       <= native['native_load_started_monotonic_s']]
        assert len(matches) == 1
        match = matches[0]
    interval = observed_preparation_interval(adapter_id=q['adapter_id'], request_id=q['request_id'],
        admission=admission, native=native, remote=match, expected_clock_id=admission['clock_id'])
    assert interval['profile_eligible']
    prep_counts[json.dumps(asdict(FrozenPreparationProfiles.source_class(source, ())), sort_keys=True)] += 1
    d[q['requested_source']].append(interval['d_ms'])
watchdog_path = a.run.with_name(a.run.stem + '_launch.launch') / 'watchdog.jsonl'
samples = [json.loads(line) for line in watchdog_path.read_text().splitlines()]
samples = [r for r in samples if r['event'] == 'resource_sample']
assert not any(r['decision']['abort_reasons'] for r in samples)
seal = verify_seal(Path('paper_results/ieee_tc/safety/20260925_execution_start_protected.json'))
assert seal['pass']
manifest = json.loads((a.figures/'manifest.json').read_text())
for name, sha in manifest['files'].items():
    assert hashlib.sha256((a.figures/name).read_bytes()).hexdigest() == sha
lease = raw['physical_allocation']
acquire = [e['at'] for e in lease['events'] if e['event'] == 'acquire']
release = [e['at'] for e in lease['events'] if e['event'] == 'release']
assert len(acquire) == len(release) == len(lease['gpu_uuids']) == 1
assert lease['released'] and release[0] > acquire[0]
assert all(not Path(p).exists() for p in raw['owned_profile_workspaces'].values())
result = dict(kind='admission_enabled_native_source_summary_v1', model=a.model,
    source_commit='26e44a2014a9178148afddf1b18447fd6b6e5ab3',
    requests=len(raw['requests']), representative_requests=len(measured),
    warmup_requests=len(raw['requests'])-len(measured), pending_closed=len(raw['requests']),
    service_classes=len(source_counts), content_classes=len(content),
    preparation_classes=len(prep_counts), preparation_counts=sorted(set(prep_counts.values())),
    source_summary=list(csv.DictReader((a.figures/'summary.csv').open())),
    loading_d_ms_mean={k:sum(v)/len(v) for k,v in d.items()},
    varied_output_groups=sum(len(v)>1 for v in output_hashes.values()),
    total_output_groups=len(output_hashes), output_variation_retained=True,
    remote_uuid_pairs=len(ids), wire_bytes=sum(r['transferred_bytes'] for r in transfers),
    logical_bytes=sum(r['payload_bytes_verified'] for r in transfers),
    measured_remote_fetches=sum(q['requested_source']=='remote' for q in measured),
    remote_pack_performed=False,
    resources=dict(samples=len(samples),peak_bytes=max(r['service']['memory.peak'] for r in samples),
        min_host_available_bytes=min(r['host']['available_bytes'] for r in samples),
        max_swap_bytes=max(r['service']['memory.swap.current'] for r in samples),
        memory_events={k:max(r['service']['memory.events'][k] for r in samples)
                       for k in ('high','max','oom','oom_kill')}),
    service_returncode=0,watchdog_returncode=0,gpu_contexts_released=True,
    workspaces_removed=True,physical_lease_released=lease['released'],
    physical_lease_id=lease['lease_id'],figures=str(a.figures),
    visual_review='automatic QA checked; separate manual visual review pending',
    protected_unchanged=seal['entry_count'],full_qualified=False,frozen_profile=False,
    numerical_adapter_correctness_qualified=False,
    n_correct=None,common_slo_qualified=False,independent_runs=1,ci=None,
    physical_gpu_seconds=release[0]-acquire[0],
    raw_evidence=[dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        for path in [a.run,launch_path,a.remote,watchdog_path,Path(__file__),a.figures/'manifest.json']])
with a.output.open('x') as f:
    json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))

