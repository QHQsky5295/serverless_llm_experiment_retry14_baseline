#!/usr/bin/env bash
set -euo pipefail
MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d157_20261002
CACHE=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/model_20260926/candidate_cache
cd "${MAIN}"
# Restore the already-qualified 7B compiler environment; do not change the backend.
export PATH="/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin:${PATH}"
export CUDA_HOME=/usr/local/cuda-13.0
export FLASHINFER_NVCC=/usr/local/cuda-13.0/bin/nvcc
export MAX_JOBS=2
command -v ninja
ninja --version
IFS= read -r PRIME_REMOTE_TOKEN < /home/qhq/.config/primelora-tc-d75/artifact.token || test -n "${PRIME_REMOTE_TOKEN:-}"
export PRIME_REMOTE_TOKEN
export FAASLORA_REMOTE_ARTIFACT_ENABLED=1
export FAASLORA_REMOTE_ARTIFACT_ENDPOINT=http://192.168.4.174:18081
export FAASLORA_REMOTE_ARTIFACT_DELIVERY_MODE=prepublished_gzip_v1
export FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY=uncached_background_v1
export PYTORCH_ALLOC_CONF=pinned_max_cached_size_mb:0,pinned_use_background_threads:True
export VLLM_CACHE_ROOT="${CACHE}"
export TRITON_CACHE_DIR="${CACHE}/triton"
export TORCHINDUCTOR_CACHE_DIR="${CACHE}/inductor"
exec systemd-run --user --scope --collect --unit=primelora-tc-aux-115376acebd440c3ba73e074146a02ae.scope \
  -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 \
  taskset -c 2,3,26,27 env \
  FAASLORA_TC_NVML_BINDING=/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py \
  FAASLORA_TC_NVML_SHA256=4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea \
  PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 \
  HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 VLLM_NO_USAGE_STATS=1 \
  /usr/bin/python3 "${MAIN}/scripts/ieee_tc_preflight.py" gated-launch \
  --output "${RAW}/7b_cap4_source1_launch.json" --predicted-growth-gib 8 \
  --exec /home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python \
  "${MAIN}/scripts/ieee_tc_preflight.py" backend-model-check \
  --runtime-receipt "${MAIN}/results/ieee_tc/p2_backend_qualification/runtime_20260926/cuda_import_attempt3.json" \
  --config "${MAIN}/configs/ieee_tc/20261002_d156_7b_cap4.yaml" --model-profile llama2_7b_main_v2_publicmix \
  --replay-trace /home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260424_131528_llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1/shared_artifacts/llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json \
  --request-count 1000 --qualification-mode native_source_matrix \
  --source-profile-spec "${MAIN}/paper_results/ieee_tc/p2_backend/20261002_d157_7b_admission_source_spec.json" \
  --output "${RAW}/7b_cap4_source1.json"
