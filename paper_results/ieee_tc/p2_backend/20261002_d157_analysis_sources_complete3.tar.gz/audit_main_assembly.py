"""CPU-only actual main assembly; deliberate stop BEFORE any activation.

Reuse D92 main assembly with fresh D157 cap4 inputs/profiles. Synthetic ingress state is explicitly a wiring
fixture, not external-transport, resource-containment or performance evidence.
"""
import asyncio
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import AsyncMock, Mock, patch

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
import yaml
from scripts import ieee_tc_preflight as p
from scripts import run_all_experiments as r
from faaslora.clock import local_monotonic_clock_id
from faaslora.datasets.workload_generator import FrozenReplayPlan, ExternalReplayIngress
from faaslora.metrics.metrics_collector import PhysicalGPUDeployment

OUT = Path(sys.argv[1]).resolve()
assert not OUT.exists()
historical_config = yaml.safe_load((ROOT/'configs/experiments.yaml').read_text())
records = []

class AssemblyComplete(Exception):
    pass

def verified(reference):
    path = ROOT/reference['path']
    if p.digest(path) != reference['sha256']:
        raise ValueError('source changed: '+str(path))
    return json.loads(path.read_text())

async def main():
    for model, key, port in (('7b','llama2_7b_main_v2_publicmix',18081),):
        manifest_path = ROOT/f'paper_results/ieee_tc/p2_backend/d157_{model}_initialization/manifest.json'
        manifest = json.loads(manifest_path.read_text())
        source = verified(manifest['source_run'])
        cfg = copy.deepcopy(source['requested_model_config'])
        cfg['visible_device_ids'] = [0,1,2,3]
        trace = Path(source['trace']['source_path'])
        subset = trace.with_name(trace.name.replace('_trace.json','_adapter_subset.json'))
        assert subset.is_file()
        contract = verified(manifest['contract'])
        coord = copy.deepcopy(contract['coordination']) | manifest['bindings']
        remote = (ROOT/historical_config['model_profiles'][key]['storage']['remote_dir']).resolve(strict=True)
        del source
        plan = FrozenReplayPlan.load(trace)
        assert len(plan.entries) == 4000
        config_path = OUT.parent/f'{model}_main_config_full1.yaml'
        config = dict(experiment=dict(num_runs=1,output_dir=str(OUT.parent/f'{model}_outputs_full1')),
            model=cfg,lora_adapters=dict(apply_scale_preset=False),
            datasets=dict(arrival_source='azure_llm',token_source='azure_llm',prompt_source='sharegpt_auto'),
            workload=dict(total_requests=4000,workload_seed=42,generation_contract='fixed_length_greedy_v1',
                canonical_prompt_renderer='role_lines_v1',fixed_prompt_max_tokens=759,
                fixed_output_max_tokens=256,max_tokens=256,temperature=0,top_p=1,
                concurrency=2,multi_cycle_phases=1,ttft_slo_ms=5000,request_timeout_s=1800.),
            resource_coordination=coord,
            hardware=dict(gpu_device_ids=[0,1,2,3],gpu_count=4,gpu_budget_mb=24576),cost_model={},
            storage=dict(remote_dir=str(remote),bandwidth_mbps=0,
                nvme_cache_dir=str(OUT.parent/f'{model}_nvme_full1'),
                host_cache_dir=f'/dev/shm/tc-d157-{model}-full1',require_memory_backed_host_cache=True),
            scenarios=[dict(name='tc_ieee_full',baseline_type='faaslora_full',preloading=dict(
                nvme_capacity_mb=16384,host_capacity_mb=16384,online_hotness_window_s=5))])
        previous = yaml.safe_load((ROOT/'results/ieee_tc/p2_backend_qualification/d154_20261002/7b_main_config_full1.yaml').read_text())
        comparable = copy.deepcopy(config)
        for item in (previous, comparable):
            del item['experiment']['output_dir']
            del item['storage']['nvme_cache_dir']
            del item['storage']['host_cache_dir']
            for name in ('max_num_seqs','runtime_concurrency_cap','requested_runtime_concurrency_cap','ieee_admission_profile'):
                del item['model'][name]
            for name in ('ieee_service_profile','ieee_preparation_profile'):
                del item['resource_coordination'][name]
        assert comparable == previous, 'change beyond capacity and its measured profiles'
        assert cfg['max_num_seqs'] == cfg['runtime_concurrency_cap'] == cfg['requested_runtime_concurrency_cap'] == 4
        with config_path.open('x') as handle:
            yaml.safe_dump(config,handle,sort_keys=False)
        # Temp-only diagnostic workspace replaces the published *launch* paths
        # for this CPU assembly; no payload/cache/model can be populated.
        with tempfile.TemporaryDirectory(prefix='d157-assembly-',dir=OUT.parent) as tmp, \
             tempfile.TemporaryDirectory(prefix='d157-host-',dir='/dev/shm') as host:
            root = Path(tmp)
            dry_config = copy.deepcopy(config)
            dry_config['storage'].update(nvme_cache_dir=str(root/'nvme'),host_cache_dir=host)
            dry_path = root/'config.yaml'
            dry_path.write_text(yaml.safe_dump(dry_config,sort_keys=False))
            import time
            notice = time.monotonic()
            context = dict(plan=plan.identity(),clock_id=local_monotonic_clock_id(),
                deployment_notice_s=notice,replay_t0_s=notice+60,tiny_witness=False)
            receipt = root/'receipt.json'
            receipt.write_text(json.dumps(dict(external_replay=context)))
            ingress = ExternalReplayIngress(plan,context)
            ingress._pump_task = asyncio.create_task(asyncio.sleep(0))
            deployment = PhysicalGPUDeployment(root=root/'physical_deployment',plan=plan,context=context)
            record = dict(model=model,kind='main_configuration_assembly_only',
                actual_inference=False,real_ingress=False,formal_comparison_qualified=False,
                profile_manifest=dict(path=str(manifest_path),sha256=p.digest(manifest_path)),
                trace=plan.identity(),subset=dict(path=str(subset),sha256=p.digest(subset)),
                config=dict(path=str(config_path),sha256=p.digest(config_path)))

            async def stop_before_activation(service):
                service._require_ieee_full_qualification()
                assert service._planned_ieee_runtime_model_config() == contract['model_config']
                assert len(service._ieee_artifact_identities) == 500
                assert service.instance_pool.count() == 0 and service.engine.engine is None
                assert service._dispatch_capacity_limit_for_runtime_groups(1) == 4
                assert service._dispatch_capacity_limit_for_runtime_groups(4) == 16
                record.update(launch_contract=service._ieee_full_launch_contract,
                    adapter_count=len(service.adapter_info),requests=len(service.traces),
                    one_runtime_capacity=service._dispatch_capacity_limit_for_runtime_groups(1),
                    four_runtime_capacity=service._dispatch_capacity_limit_for_runtime_groups(4),
                    ready_pool_count=0,initialized_engines=0,**{'pass':True})
                raise AssemblyComplete()

            env = dict(FAASLORA_REMOTE_ARTIFACT_ENABLED='1',FAASLORA_REMOTE_ARTIFACT_ENDPOINT=f'http://192.168.4.174:{port}',
                FAASLORA_REMOTE_ARTIFACT_DELIVERY_MODE='prepublished_gzip_v1',
                FAASLORA_TC_EXTERNAL_REPLAY='1',FAASLORA_TC_LAUNCH_RECEIPT=str(receipt),
                FAASLORA_SHARED_TRACE_PATH=str(trace),FAASLORA_SHARED_ADAPTER_SUBSET_PATH=str(subset),
                FAASLORA_TRACE_ROLE='exploratory',FAASLORA_FORMAL_RUN='0')
            # Every skipped runtime boundary is recorded above. Do not use this
            # output as a real resource/arrival witness or a performance run.
            with patch.dict(os.environ,env), \
                    patch.object(r.ScenarioRunner,'preload',stop_before_activation), \
                    patch.object(r.ScenarioRunner,'_assert_clean_gpu_environment',Mock()), \
                    patch.object(r.InferenceEngine,'initialize',AsyncMock(side_effect=AssertionError('no model'))), \
                    patch.object(r.SubprocessInferenceEngineProxy,'spawn',AsyncMock(side_effect=AssertionError('no worker'))), \
                    patch.object(r.HttpArtifactStoreClient,'download_artifact',side_effect=AssertionError('no transfer')), \
                    patch.object(r,'WorkloadDataset',side_effect=AssertionError('no raw dataset')):
                try:
                    await r._main_async_impl(str(dry_path),only_scenario='tc_ieee_full',use_full_stack=True,
                        external_replay=ingress,physical_deployment=deployment)
                except AssemblyComplete:
                    pass
                except BaseException as exc:
                    record.update(**{'pass':False},error_type=type(exc).__name__,error=str(exc))
                    records.append(record)
                    raise
                else:
                    raise AssertionError('main did not reach the actual pre-activation contract')
            outcome=json.loads((deployment.root/'main_outcome.json').read_text())
            assert outcome['error']['type']=='AssemblyComplete'
            assert outcome['cleanup']['complete'] and not outcome['measurement_errors']
            assert not outcome['run_completed']
            assert not (root/'nvme'/'tc_ieee_full').exists()
            assert not (Path(host)/'tc_ieee_full').exists()
            record['deliberate_pre_activation_failure_outcome']=outcome
            records.append(record)
    return all(row['pass'] for row in records)

passed = False
try:
    passed = asyncio.run(main())
finally:
    with OUT.open('x') as handle:
        json.dump(dict(kind='main_assembly_audit_v1',records=records,**{'pass':passed},
            full_qualification_complete=False,driver_sha256=p.digest(Path(__file__))),handle,indent=2)

