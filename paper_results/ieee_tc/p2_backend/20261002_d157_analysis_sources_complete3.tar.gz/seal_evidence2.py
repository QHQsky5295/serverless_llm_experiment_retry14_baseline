"""D157 reuses the small evidence-package convention; no payload pools."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, check_plan, verify_seal

raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
units = ['primelora-tc-svc-42471725ef7548b087ec11d390767311.scope',
         'primelora-tc-aux-115376acebd440c3ba73e074146a02ae.scope']
units += [f'primelora-d157-{name}-20261002.scope' for name in ('prepare1','analysis1','analysis2','analysis3')]
for unit in units:
    for prop, value in (('ActiveState','inactive'),('InvocationID','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == value
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not Path('/proc/1175604').exists()
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
summary_path = out/'20261002_d157_7b_admission_source.json'
summary = json.loads(summary_path.read_text())
assert summary['requests'] == summary['pending_closed'] == 184
assert summary['representative_requests'] == 180 and summary['n_correct'] is None
assert not summary['full_qualified'] and not summary['common_slo_qualified']
for ref in summary['raw_evidence']:
    assert sha(ROOT/ref['path']) == ref['sha256'], ref['path']
manifest_path = out/'d157_7b_initialization/manifest.json'
manifest = json.loads(manifest_path.read_text())
assert manifest['pass'] and manifest['coverage']['class_domain_covered']
assert manifest['coverage']['measured_service_classes'] == manifest['coverage']['required_service_classes'] == 30
for ref in [manifest['source_summary'],manifest['source_run'],manifest['contract'],*manifest['bindings'].values(),*manifest['scripts']]:
    assert sha(ROOT/ref['path']) == ref['sha256'], ref['path']
figures = ROOT/'figs/ieee_tc/p2_backend/d157_7b_admission_source1'
fig_manifest = json.loads((figures/'manifest.json').read_text())
assert fig_manifest['measured_requests'] == 180 and fig_manifest['warmup_requests'] == 4
assert fig_manifest['source_profile_purpose'] == fig_manifest['expected_purpose'] == 'D157_7b_cap4_admission_enabled_source_calibration_development_only'
assert not fig_manifest['formal_S1'] and fig_manifest['independent_runs'] == 1 and fig_manifest['ci'] is None
for name, expected in fig_manifest['files'].items():
    assert sha(figures/name) == expected
assert sha(ROOT/'scripts/plot_paper_figures.py') == fig_manifest['script_sha256']
for stem in ('source_D_ms','source_T_ms','source_TPOT_ms'):
    fonts = subprocess.check_output(['pdffonts',str(figures/f'{stem}.pdf')],text=True)
    assert 'TimesNewRomanPSMT' in fonts and 'TimesNewRomanPS-BoldMT' in fonts
    assert 'DejaVu' not in fonts
assembly = json.loads((raw/'main_assembly3.json').read_text())
assert assembly['pass'] and len(assembly['records']) == 1
r = assembly['records'][0]
assert r['pass'] and r['requests'] == 4000 and r['adapter_count'] == 500
assert r['one_runtime_capacity'] == 4 and r['four_runtime_capacity'] == 16
assert r['initialized_engines'] == r['ready_pool_count'] == 0
assert not r['actual_inference'] and not r['real_ingress']
assert sha(ROOT/r['config']['path']) == r['config']['sha256']
for prefix in ('plot_tests','plot3','summary3','export3','assembly3'):
    assert 'Exit status: 0' in (raw/f'{prefix}_time.txt').read_text()
assert 'Ran 46 tests' in (raw/'plot_tests.log').read_text() and '\nOK\n' in (raw/'plot_tests.log').read_text()
assert all(line.split()[1] == '0' for line in (raw/'analysis3_memory_events.txt').read_text().splitlines())
assert 'InvocationID=992688a8be01418b98c72551c9a89608' in (raw/'analysis3_scope.txt').read_text()
assert (raw/'stop_services_source1.log').read_text().count('Result=success') == 3
for expected, local in zip((raw/'remote_copy_receipt.txt').read_text().splitlines(),
                          ('remote_7b_source1_transfers.jsonl','remote_monitor_source1_final.log')):
    assert expected.split()[0] == sha(raw/local)
for path in [*raw.glob('*.py'),ROOT/'scripts/plot_paper_figures.py',ROOT/'tests/test_v2_analysis_tools.py']:
    ast.parse(path.read_text(),filename=str(path))
for path in raw.glob('*.sh'):
    subprocess.run(['bash','-n',str(path)],check=True)
sources = [summary_path,manifest_path,out/'d157_7b_initialization/service.json',out/'d157_7b_initialization/preparation.json',
    out/'20261002_d157_7b_admission_source_spec.json',out/'20261002_d157_7b_development_contract.json',
    ROOT/'docs/ieee_tc/D157_CAP4_ADMISSION_SOURCE.md',ROOT/'scripts/plot_paper_figures.py',ROOT/'tests/test_v2_analysis_tools.py',
    raw/'main_assembly3.json',raw/'7b_main_config_full1.yaml',raw/'remote_monitor_source1_final.log']
sources.extend(sorted(figures.iterdir()))
receipt = dict(kind='d157_source_profile_evidence_verification_v1',protected=protected,
    actual_native_qualification_pass=True,native_contract_samples=184,service_classes=30,preparation_classes=24,
    class_domain_covered=True,no_live_gpu_or_qualification_scopes=True,serving_code_changed=False,
    full_qualified=False,visual_review='all three PNG rendered views inspected; no text overlaps or clipping; TNR embedded',
    source_refs=[dict(path=str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p),sha256=sha(p)) for p in sources])
with (out/'20261002_d157_evidence_verification.json').open('x') as f:
    json.dump(receipt,f,indent=2)
names = ['prepare_candidate.py','run_prepare1.sh','prepare1.json','prepare1_scope.txt','prepare1_time.txt','prepare1_memory_events.txt',
    'run_7b_source1.sh','activate_services_source1.sh','check_health.sh','stop_services_source1.sh','copy_remote_source1.sh',
    'summarize_source1.py','export_profiles.py','audit_main_assembly.py','run_analysis1.sh','run_analysis2.sh','run_analysis3.sh',
    'seal_evidence.py','run_seal1.sh','seal_evidence2.py','run_seal2.sh','seal1.log','seal1_time.txt','seal1_scope.txt','source1_console.log','local_cleanup_source1.txt','remote_activation1.txt','remote_prelaunch.txt',
    'health1_3b.json','health1_7b.json','stop_services_source1.log','remote_copy_receipt.txt',
    'plot1.log','plot1_time.txt','plot2.log','plot2_time.txt','analysis1_scope.txt','analysis2_scope.txt',
    'analysis3_scope.txt','analysis3_memory_events.txt','plot_tests.log','plot_tests_time.txt',
    'plot3.log','plot3_time.txt','summary3.log','summary3_time.txt','export3.log','export3_time.txt','assembly3.log','assembly3_time.txt',
    'main_assembly3.json','7b_main_config_full1.yaml']
bundle = out/'20261002_d157_analysis_sources.tar.gz'
hashes = {}
token = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert token
with tarfile.open(bundle,'x:gz') as archive:
    for name in names:
        p = raw/name
        assert 0 <= p.stat().st_size < 128*1024, name
        b = p.read_bytes()
        assert token not in b
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in b.splitlines())
        hashes[name] = sha(p)
        archive.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
with (out/'20261002_d157_analysis_sources.sha256').open('x') as f:
    f.write(sha(bundle)+'  '+bundle.name+'\n')
with (out/'20261002_d157_analysis_sources_members.json').open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(protected=147,native_checks=184,members=len(hashes),bytes=bundle.stat().st_size,bundle_sha256=sha(bundle))))

