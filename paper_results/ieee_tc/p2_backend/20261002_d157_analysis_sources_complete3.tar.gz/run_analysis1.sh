#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d157_20261002
unit=primelora-d157-analysis1-20261002.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/analysis1_scope.txt"
test -s "$raw/local_cleanup_source1.txt"
test -s "$raw/remote_copy_receipt.txt"
export PYTHONPATH="$PWD" PYTHONDONTWRITEBYTECODE=1
py=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
fig=figs/ieee_tc/p2_backend/d157_7b_admission_source1
/usr/bin/time -v -o "$raw/plot1_time.txt" "$py" scripts/plot_paper_figures.py \
  --figure tc_native_source_profile --input "$raw/7b_cap4_source1.json" --out-dir "$fig" > "$raw/plot1.log" 2>&1
/usr/bin/time -v -o "$raw/summary1_time.txt" "$py" "$raw/summarize_source1.py" \
  --run "$raw/7b_cap4_source1.json" --remote "$raw/remote_7b_source1_transfers.jsonl" \
  --figures "$fig" --model 7b \
  --output paper_results/ieee_tc/p2_backend/20261002_d157_7b_admission_source.json > "$raw/summary1.log" 2>&1
/usr/bin/time -v -o "$raw/export1_time.txt" "$py" "$raw/export_profiles.py" --model 7b \
  --output-dir paper_results/ieee_tc/p2_backend/d157_7b_initialization > "$raw/export1.log" 2>&1
/usr/bin/time -v -o "$raw/assembly1_time.txt" "$py" "$raw/audit_main_assembly.py" \
  "$PWD/$raw/main_assembly1.json" > "$raw/assembly1.log" 2>&1
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events" > "$raw/analysis1_memory_events.txt"
