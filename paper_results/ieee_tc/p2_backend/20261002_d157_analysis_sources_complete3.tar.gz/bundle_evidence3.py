"""Finish D157 small-source backup after successful validation; retain failures."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = Path(__file__).resolve().parent
out = root/'paper_results/ieee_tc/p2_backend'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
verified = out/'20261002_d157_evidence_verification.json'
assert sha(verified) == '61b606b02363a85952fd53bf7d408c19de40875393468530c846aefed7934158'
for ref in json.loads(verified.read_text())['source_refs']:
    assert sha(root/ref['path']) == ref['sha256'], ref['path']
for unit in ('primelora-d157-seal1-20261002.scope','primelora-d157-seal2-20261002.scope'):
    for prop, expected in (('ActiveState','inactive'),('InvocationID','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == expected
# Only small scripts/receipts in this owned directory, never model/request payloads.
excluded = {'7b_cap4_source1.json','7b_cap4_source1_launch.json',
            'remote_7b_source1_transfers.jsonl','remote_monitor_source1_final.log',
            'bundle3.log','bundle3_scope.txt','bundle3_time.txt','bundle3_memory_events.txt'}
paths = sorted(p for p in raw.iterdir() if p.is_file() and p.name not in excluded
               and p.suffix in ('.py','.sh','.json','.yaml','.log','.txt'))
assert {'check_health1.sh','main_assembly3.json','seal1.log','seal2.log','bundle_evidence3.py','run_bundle3.sh'} <= {p.name for p in paths}
token = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert token
hashes = {}
for p in paths:
    assert p.stat().st_size < 128*1024, p
    b = p.read_bytes()
    assert token not in b
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in b.splitlines())
    hashes[p.name] = sha(p)
bundle = out/'20261002_d157_analysis_sources_complete3.tar.gz'
with tarfile.open(bundle,'x:gz') as archive:
    for p in paths:
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
with (out/'20261002_d157_analysis_sources_complete3.sha256').open('x') as f:
    f.write(sha(bundle)+'  '+bundle.name+'\n')
with (out/'20261002_d157_analysis_sources_complete3_members.json').open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True,
        verification_sha256=sha(verified),partial_attempt2_retained_not_complete=True),f,indent=2)
print(json.dumps(dict(members=len(hashes),bytes=bundle.stat().st_size,sha256=sha(bundle))))
