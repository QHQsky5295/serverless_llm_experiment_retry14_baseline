"""D157 reuses D89 offline export through existing preflight/loaders; no GPU/network/pool copy."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
import yaml
from scripts import ieee_tc_preflight as p
from faaslora.storage.http_artifact_store import HttpArtifactStoreClient
from faaslora.experiment.instance_pool import FrozenServiceProfiles
from faaslora.preloading.preloading_planner import FrozenPreparationProfiles

parser = argparse.ArgumentParser()
parser.add_argument('--model', choices=('7b',), required=True)
parser.add_argument('--output-dir', type=Path, required=True)
a = parser.parse_args()
assert not a.output_dir.exists(), 'never overwrite a prior export'
model_key = {'3b':'llama32_3b_main_modelscope','7b':'llama2_7b_main_v2_publicmix'}[a.model]
summary_path = ROOT/f'paper_results/ieee_tc/p2_backend/20261002_d157_{a.model}_admission_source.json'
summary = json.loads(summary_path.read_text())
references = summary['raw_evidence']
for ref in references:
    path = ROOT/ref['path']
    assert p.digest(path) == ref['sha256'], str(path)
run_path, launch_path = [ROOT/r['path'] for r in references[:2]]
raw, launch = json.loads(run_path.read_text()), json.loads(launch_path.read_text())
assert launch['pass'] and launch['service_returncode'] == launch['watchdog_returncode'] == 0
assert launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
assert launch['preflight']['policy'] == p.POLICY
assert raw['service']['affinity'] == p.POLICY['service_cpus']
spec_path = ROOT/f'paper_results/ieee_tc/p2_backend/20261002_d157_{a.model}_admission_source_spec.json'
assert p.digest(spec_path) == raw['source_profile_spec_sha256']
spec = json.loads(spec_path.read_text())
assert raw['source_profile_spec'] == spec
contract_path = ROOT/spec['full_development_contract']['path']
assert p.digest(contract_path) == spec['full_development_contract']['sha256']
contract = json.loads(contract_path.read_text())
runtime = ROOT/'results/ieee_tc/p2_backend_qualification/runtime_20260926/cuda_import_attempt3.json'
assert p.digest(runtime) == raw['runtime_receipt_sha256'] == contract['runtime_receipt_sha256']
assert p.digest(ROOT/'configs/ieee_tc/20261002_d156_7b_cap4.yaml') == raw['config_sha256']
config = yaml.safe_load((ROOT/'configs/ieee_tc/20261002_d156_7b_cap4.yaml').read_text())
pool = (ROOT/config['model_profiles'][model_key]['storage']['remote_dir']).resolve(strict=True)
index_path = ROOT/spec['content_index']['path']
assert p.digest(index_path) == spec['content_index']['sha256']
index = json.loads(index_path.read_text())
client = HttpArtifactStoreClient(endpoint='http://127.0.0.1:1')
client.configure_content_manifest(index)
identities = {}
for row in index['artifacts']:
    path = (pool/row['id']).resolve(strict=True)
    assert path.parent == pool
    identities[row['id']] = client.routing_identity(row['id'], (path/'adapter_config.json').read_bytes())
assert len(identities) == 500
assert p.digest(Path(raw['trace']['source_path'])) == spec['trace_sha256'] == raw['trace']['source_sha256']

def object_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False,
                                    separators=(',', ':')).encode()).hexdigest()

# These context values are declared serving conditions, not observed latency or
# old process identities. Original receipts/protocol identify their provenance.
input_contract = dict(source_trace_sha256=spec['trace_sha256'],
    content_index_sha256=spec['content_index']['sha256'],
    generation_contract=raw['model_config']['generation_contract'],
    canonical_prompt_renderer=raw['model_config']['canonical_prompt_renderer'],
    prompt_content_cap=raw['model_config']['max_input_len'],
    output_cap=raw['model_config']['max_output_tokens_cap'],
    artifact_mode=raw['artifact_mode'], declared_source_profile_sha256=raw['source_profile_spec_sha256'])
envelope = dict(inference_policy=launch['preflight']['policy'],
    artifact_service=dict(memory_high_bytes=2*p.GIB,memory_max_bytes=4*p.GIB,
        memory_swap_max_bytes=0,cpus=list(range(2,20))+list(range(22,40)),
        published_server_sha256='a31fa9212143914f5a7fb21dea126a23eaafedffe199ff9513de9ce03eb62a2c',
        delivery_mode='prepublished_gzip_v1',link_mbps=1000,rate_limit=None))
context = dict(backend_environment_sha256=raw['runtime_receipt_sha256'],
    resource_envelope_sha256=object_hash(envelope),input_contract_sha256=object_hash(input_contract))
service, prep, coverage = p.measured_source_profile_payloads(raw,
    source_run_sha256=references[0]['sha256'],identities=identities,
    context=context,model_config=contract['model_config'])
a.output_dir.mkdir(parents=True,exist_ok=False)
loaded,bindings = {},{}
for name,payload,cls,beta in (
    ('service',service,FrozenServiceProfiles,contract['service_ewma_beta']),
    ('preparation',prep,FrozenPreparationProfiles,contract['preparation_ewma_beta'])):
    path = a.output_dir/f'{name}.json'
    with path.open('x') as f: json.dump(payload,f,indent=2,allow_nan=False)
    sha = p.digest(path)
    loaded[name] = cls.load(path,expected_sha256=sha,model_config=contract['model_config'],
                          expected_context=context,beta=beta)
    bindings['ieee_'+name+'_profile'] = dict(path=str(path),sha256=sha,context=context,ewma_beta=beta)
estimates = dict(service=[dict(service_class=asdict(k),**asdict(v),n=loaded['service'].sample_counts[k])
                         for k,v in loaded['service'].profiles.items()],
    preparation=[dict(preparation_class=asdict(k),d_ms=v,n=loaded['preparation'].sample_counts[k])
                 for k,v in loaded['preparation'].profiles.items()])
seal = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert seal['pass']
result = dict(kind='measured_development_profile_export_v1',model=a.model,**{'pass':True},
    source_execution_commit=summary['source_commit'],source_summary=dict(path=str(summary_path),sha256=p.digest(summary_path)),
    source_run=references[0],contract=spec['full_development_contract'],context=context,
    context_definition=dict(backend_environment='SHA256 of qualified native runtime receipt',
        resource_envelope=envelope,input_contract=input_contract,
        structured_hash='SHA256 UTF-8 json sort_keys=True separators=(comma,colon) allow_nan=False'),
    bindings=bindings,profiles={k:v.identity() for k,v in loaded.items()},coverage=coverage,
    estimates=estimates,activation_geometry=loaded['preparation'].activation_layout(),
    profile_scope='development initialization; no production SLO/Full qualification',
    full_qualified=False,production_profile_frozen=False,numerical_adapter_correctness_qualified=False,
    protected_entries_unchanged=seal['entry_count'],
    offline_only=True,new_gpu_runs=0,new_weights=0,new_traces=0,
    scripts=[dict(path=str(path),sha256=p.digest(path)) for path in
             (Path(__file__),ROOT/'scripts/ieee_tc_preflight.py')])
with (a.output_dir/'manifest.json').open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(model=a.model,profiles=result['profiles'],
    manifest=str(a.output_dir/'manifest.json'),protected=seal['entry_count'],**{'pass':True})),flush=True)

