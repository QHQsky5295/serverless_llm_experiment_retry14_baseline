"""Reuse the small evidence-package convention; never package payload pools."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, check_plan, verify_seal

raw = Path(__file__).resolve().parent
output = ROOT/"paper_results/ieee_tc/p2_backend"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for unit in ("primelora-tc-svc-f757d22d0c054074a8e6df7179df7b7e.scope",
             "primelora-tc-aux-a12e3e2da10d430688acd5eaba3d18c6.scope",
             "primelora-d156-curate1-20261002.scope", "primelora-d156-prepare1-20261002.scope"):
    for prop, expected in (("ActiveState","inactive"),("InvocationID","")):
        assert subprocess.check_output(["systemctl","--user","show",unit,"-p",prop,"--value"],text=True).strip() == expected
    assert not Path("/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice",unit).exists()
assert not subprocess.check_output(["nvidia-smi","--query-compute-apps=pid","--format=csv,noheader"],text=True).strip()
assert check_plan() == "0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7"
assert sha(ROOT/"docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md") == "5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22"
protected = verify_seal(ROOT/"paper_results/ieee_tc/safety/20260925_execution_start_protected.json")
assert protected["pass"] and protected["entry_count"] == 147
summary_path = output/"20261002_d156_7b_cap4_bootstrap.json"
summary = json.loads(summary_path.read_text())
assert summary["passed"] and summary["samples"] == 12 and not summary["full_qualified"]
assert summary["n_correct"] is None
for name, expected in summary["sources"].items():
    assert sha(ROOT/name) == expected, name
inputs = json.loads((raw/"bootstrap_inputs.json").read_text())
for name, expected in inputs["references"].items():
    assert sha(ROOT/name) == expected, name
for prefix in ("prepare1","curate1"):
    assert "Exit status: 0" in (raw/f"{prefix}_time.txt").read_text()
    assert all(line.split()[1]=="0" for line in (raw/f"{prefix}_memory_events.txt").read_text().splitlines())
assert "InvocationID=d63097717f94459fab73b420a9a1be56" in (raw/"curate1_scope.txt").read_text()
for path in raw.glob("*.py"):
    ast.parse(path.read_text(),filename=str(path))
for path in raw.glob("*.sh"):
    subprocess.run(["bash","-n",str(path)],check=True)
assert (raw/"stop_services_bootstrap2.log").read_text().count("Result=success") == 3
for expected, local in zip((raw/"remote_copy_receipt.txt").read_text().splitlines(),
                          ("remote_7b_bootstrap2_transfers.jsonl","remote_monitor_bootstrap2_final.log")):
    assert expected.split()[0] == sha(raw/local)
sources = [summary_path, output/"20261002_d156_7b_cap4_bootstrap.csv",
    output/"20261002_d156_completion_length_audit.json", output/"20261002_d156_7b_cap4_bootstrap_spec.json",
    ROOT/"configs/ieee_tc/20261002_d156_7b_cap4.yaml", ROOT/"docs/ieee_tc/D156_CAP4_BOOTSTRAP.md"]
receipt = dict(kind="d156_bootstrap_evidence_verification_v1", protected=protected,
    actual_native_qualification_pass=True, native_contract_samples=12, no_live_gpu_or_qualification_scopes=True,
    serving_code_changed=False, full_qualified=False, source_refs=[
        dict(path=str(p.relative_to(ROOT)),sha256=sha(p)) for p in sources])
with (output/"20261002_d156_evidence_verification.json").open("x") as f:
    json.dump(receipt,f,indent=2)
names = ["run_7b_bootstrap1.sh","run_7b_bootstrap2.sh","verify_bootstrap_inputs.py","curate_bootstrap2.py",
    "seal_evidence.py","run_prepare1.sh","run_curate1.sh","run_seal1.sh",
    "activate_services_bootstrap1.sh","check_health.sh","check_health2.sh","stop_services_bootstrap2.sh",
    "copy_remote_bootstrap2.sh","bootstrap_inputs.json","prepare1_scope.txt","prepare1_time.txt",
    "prepare1_memory_events.txt","curate1_scope.txt","curate1_time.txt","curate1_memory_events.txt",
    "curate1.log","bootstrap1_console.log","local_cleanup_bootstrap2.txt","remote_activation1.txt",
    "remote_prelaunch.txt","health2_3b.json","health2_7b.json","stop_services_bootstrap2.log","remote_copy_receipt.txt"]
bundle = output/"20261002_d156_analysis_sources.tar.gz"
hashes = {}
token = (Path.home()/".config/primelora-tc-d75/artifact.token").read_bytes().strip()
assert token
with tarfile.open(bundle,"x:gz") as archive:
    for name in names:
        p = raw/name
        assert 0 < p.stat().st_size < 128*1024
        b = p.read_bytes()
        assert token not in b
        assert not any(line.startswith(b"-----BEGIN ") and b"PRIVATE KEY-----" in line for line in b.splitlines())
        hashes[name] = sha(p)
        archive.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,"r:gz") as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
with (output/"20261002_d156_analysis_sources.sha256").open("x") as f:
    f.write(sha(bundle)+"  "+bundle.name+"\n")
with (output/"20261002_d156_analysis_sources_members.json").open("x") as f:
    json.dump(dict(bundle=bundle.name, member_sha256=hashes, member_checks_pass=True),f,indent=2)
print(json.dumps(dict(protected=147, native_checks=12, members=len(hashes),
    bytes=bundle.stat().st_size,bundle_sha256=sha(bundle))))
