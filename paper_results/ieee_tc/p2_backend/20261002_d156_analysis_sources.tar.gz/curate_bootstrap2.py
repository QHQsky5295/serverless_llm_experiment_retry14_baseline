"""Validate existing D156 native qualification; no replacement measurement path."""
from bisect import bisect_left
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
from scripts.ieee_tc_preflight import ROOT, check_plan, verify_seal, measured_admission_initializer

RAW = ROOT / "results/ieee_tc/p2_backend_qualification/d156_20261002"
OUT = ROOT / "paper_results/ieee_tc/p2_backend"
source = RAW / "7b_cap4_bootstrap2.json"
launch_path = RAW / "7b_cap4_bootstrap2_launch.json"
assert source.stat().st_size < 128 * 1024**2
data = json.loads(source.read_text())
launch = json.loads(launch_path.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert data["pass"] and data["stage"] == "complete"
assert data["shutdown_called"] and data["profile_workspaces_removed"]
assert launch["pass"] and launch["native_gpu_context_release_confirmed"] and launch["service_path_removed"]
assert data["physical_allocation"]["released"]
assert all(not Path(p).exists() for p in data["owned_profile_workspaces"].values())
cfg = data["model_config"]
assert cfg["runtime_concurrency_cap"] == cfg["max_num_seqs"] == 4
assert cfg["max_loras"] == 4 and cfg["max_model_len"] == 1024
assert cfg["generation_contract"] == "fixed_length_greedy_v1"
assert cfg["enable_prefix_caching"] is False
scheduler = data["scheduler_before"]
required = 4 * math.ceil(cfg["max_model_len"] / scheduler["kv_tokens_per_block"])
assert scheduler["kv_unreserved_free_blocks"] >= required
assert not scheduler["admitted"] and not data["scheduler_after"]["admitted"]
assert not data["sources_after_eviction"]["sources"]
waves, samples, rows = [], {}, []
assert len(data["requests"]) == 12 and len(data["profile_waves"]) == 3
for i, w in enumerate(data["source_profile_spec"]["waves"]):
    cases = sorted((q for q in data["requests"] if q["request_id"].startswith(f"source-profile/w{i}/")),
                   key=lambda q:q["request_id"])
    assert len(cases) == 4 and data["profile_waves"][i]["complete"]
    assert len({q["adapter_id"] for q in cases}) == 4
    overlap = min(q["last_token_monotonic_s"] for q in cases) - max(q["first_token_monotonic_s"] for q in cases)
    assert overlap > 0, "Four tasks submitted is not four overlapping native decode intervals"
    for q, selected in zip(cases, w["requests"]):
        assert q["pass"] and q["reservation_released"]
        assert q["requested_source"] == "gpu"
        assert all(q[k] == selected[k] for k in ("adapter_id", "source_request_id"))
        t, ev = q["timing"], q["source_evidence"]
        assert q["actual_tokens"] == q["target_tokens"] == t["native_output_tokens"]
        assert t["native_terminal_observed"] and ev["state"] == "released"
        assert ev["receipt"]["lora_name"] == q["adapter_id"]
        assert q["native_clock_id"] == t["native_clock_id"] == q["admission_clock_id"]
        assert len(q["native_events"]) == 2 and q["native_events"][-1]["token_count"] == q["actual_tokens"]
        first, last, dispatch = (t[k] for k in ("native_first_token_monotonic_s", "native_last_token_monotonic_s", "native_dispatch_monotonic_s"))
        assert dispatch <= first <= last
        assert abs((last-first)*1000/(q["actual_tokens"]-1)-t["native_tpot_ms"]) <= 1
        assert abs((first-dispatch)*1000-t["native_ttft_ms"]) <= 1
        assert q["first_token_monotonic_s"] == first and q["last_token_monotonic_s"] == last
        row = dict(wave=i, role=w["role"], request_id=q["request_id"], source_request_id=q["source_request_id"],
            adapter_id=q["adapter_id"], native_tokens=q["actual_tokens"], native_ttft_ms=t["native_ttft_ms"],
            native_tpot_ms=t["native_tpot_ms"], decode_overlap_four_s=overlap)
        rows.append(row)
        if w["role"] == "representative_measurement":
            s = dict(source_request_id=q["source_request_id"], native_prompt_tokens=int(t["actual_prompt_tokens"]),
                completed_output_tokens=int(t["native_output_tokens"]), prompt_sha256=t["native_prompt_token_ids_sha256"],
                content_prompt_tokens=int(q["input_content_tokens"]))
            assert samples.setdefault(q["source_request_id"], s) == s
    waves.append(dict(wave=i, role=w["role"], samples=4, native_decode_intersection_s=overlap,
        native_ttft_mean_ms=statistics.mean(q["timing"]["native_ttft_ms"] for q in cases),
        native_tpot_mean_ms=statistics.mean(q["timing"]["native_tpot_ms"] for q in cases)))
assert len(samples) == 6
buckets = [[] for _ in range(len(cfg["ieee_input_upper_bounds"])+1)]
for sample in samples.values():
    buckets[bisect_left(cfg["ieee_input_upper_bounds"], sample["native_prompt_tokens"])].append(sample["completed_output_tokens"])
assert all(buckets)
runtime = ROOT / "results/ieee_tc/p2_backend_qualification/runtime_20260926/cuda_import_attempt3.json"
backend = json.loads(runtime.read_text())["modules"]["vllm"]["version"]
entry = dict(source_run=dict(path=str(source.relative_to(ROOT)), sha256=sha(source)),
    model_config=cfg, same_backend=backend, input_upper_bounds=cfg["ieee_input_upper_bounds"],
    samples=list(samples.values()), unique_original_requests=len(samples), unobserved_bucket_ids=[],
    observed_buckets=[dict(bucket=i, unique_requests=len(b), completed_output_mean=statistics.mean(b)) for i,b in enumerate(buckets)])
audit = dict(kind="native_completed_output_length_initialization_audit_v1", development_only=True,
    production_profile_frozen=False, aggregation="deduplicate_original_request_identity_not_wave_repetitions",
    models={"7b":entry})
audit_path = OUT / "20261002_d156_completion_length_audit.json"
with audit_path.open("x") as f:
    json.dump(audit, f, indent=2)
binding = dict(kind="native_completed_length_binding_v1", audit=dict(path=str(audit_path.relative_to(ROOT)),
    sha256=sha(audit_path)), model="7b", window_s=5)
profile, initialization = measured_admission_initializer(binding, model_config=cfg, backend_version=backend,
    runtime_receipt_sha256=sha(runtime), source_trace_sha256=data["trace"]["source_sha256"], movement_concurrency=3)
remote = [json.loads(line) for line in (RAW/"remote_7b_bootstrap2_transfers.jsonl").read_text().splitlines()]
by_transfer = {r["transfer_id"]:r for r in remote}
assert len(remote) == len(by_transfer) == len(data["remote_transfers"]) == 12
for local in data["remote_transfers"]:
    r = by_transfer[local["http_transfer_id"]]
    assert r["artifact_id"] == local["artifact_id"] and r["bytes_written"] == local["transferred_bytes"]
    assert r["archive_sha256"] == local["remote_archive_sha256"]
    assert local["content_verified"] and local["published_archive_verified"]
    assert r["pack_performed"] is False and local["remote_pack_performed"] is False
events = data["physical_allocation"]["events"]
acq = [e["at"] for e in events if e["event"] == "acquire"]
rel = [e["at"] for e in events if e["event"] == "release"]
assert len(acq) == len(rel) == len(data["physical_allocation"]["gpu_uuids"]) == 1
watch_path = RAW / "7b_cap4_bootstrap2_launch.launch/watchdog.jsonl"
watch = [json.loads(line) for line in watch_path.read_text().splitlines()]
resources = [r for r in watch if r["event"] == "resource_sample"]
assert resources and all(not r["decision"]["abort_reasons"] for r in resources)
memory = {k:max(r["service"]["memory.events"][k] for r in resources) for k in resources[0]["service"]["memory.events"]}
protected = verify_seal(ROOT/"paper_results/ieee_tc/safety/20260925_execution_start_protected.json")
assert protected["pass"]
report = dict(kind="d156_7b_cap4_bootstrap_validation_v1", passed=True, samples=12,
    representative_samples=8, unique_existing_requests=6, waves=waves,
    startup_free_kv_blocks=scheduler["kv_unreserved_free_blocks"], required_max_context_blocks=required,
    kv_tokens_per_block=scheduler["kv_tokens_per_block"], kv_bytes_per_block=scheduler["kv_bytes_per_block"],
    startup_kv_allocation_bytes=scheduler["kv_pool_allocation_bytes"],
    gpu_s=rel[0]-acq[0], n_correct=None, numerical_adapter_correctness_qualified=False,
    common_slo_qualified=False, full_qualified=False, next="admission_enabled_source_class_profile_then_Full",
    remote_transfers=12, remote_online_bytes=sum(r["bytes_written"] for r in remote), remote_pack_operations=0,
    resource_samples=len(resources), memory_peak_bytes=max(r["service"]["memory.peak"] for r in resources),
    memory_events_max=memory, initialization_binding=binding, measured_initialization=initialization,
    initializer=profile, plan_sha256=check_plan(), protected=protected,
    scope="GPU_ready_source_only_capacity_and_lengths_not_performance_or_numerical_adapter_acceptance",
    continuous_kv_or_preemption_measurement=False, old_profile_performance_relabelled=False,
    sources={str(p.relative_to(ROOT)):sha(p) for p in [source,launch_path,audit_path,runtime,
        RAW/"remote_7b_bootstrap2_transfers.jsonl",RAW/"remote_monitor_bootstrap2_final.log",watch_path]})
with (OUT/"20261002_d156_7b_cap4_bootstrap.json").open("x") as f:
    json.dump(report, f, indent=2)
with (OUT/"20261002_d156_7b_cap4_bootstrap.csv").open("x", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps({k: report[k] for k in ("passed","samples","waves","gpu_s","startup_free_kv_blocks","remote_online_bytes","memory_peak_bytes","memory_events_max")}))
