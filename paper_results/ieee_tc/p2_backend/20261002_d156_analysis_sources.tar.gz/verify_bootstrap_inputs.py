"""Bounded offline qualification of D156's index/config, not a serving runner."""
import hashlib
import json
from pathlib import Path
import yaml
from faaslora.datasets.workload_generator import FrozenReplayPlan
from scripts.ieee_tc_preflight import ROOT, check_plan, verify_seal, source_profile_inputs

RAW = ROOT / "results/ieee_tc/p2_backend_qualification/d156_20261002"
CFG = ROOT / "configs/ieee_tc/20261002_d156_7b_cap4.yaml"
SPEC = ROOT / "paper_results/ieee_tc/p2_backend/20261002_d156_7b_cap4_bootstrap_spec.json"
OLD = ROOT / "configs/experiments.yaml"
TRACE = Path("/home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260424_131528_llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1/shared_artifacts/llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json")
profile = "llama2_7b_main_v2_publicmix"
old = yaml.safe_load(OLD.read_text())["model_profiles"][profile]
new = yaml.safe_load(CFG.read_text())["model_profiles"][profile]
diff = {k: [old["model"].get(k), new["model"].get(k)]
        for k in old["model"].keys() | new["model"].keys()
        if old["model"].get(k) != new["model"].get(k)}
assert diff == {"max_num_seqs": [2, 4], "runtime_concurrency_cap": [2, 4]}, diff
assert new["storage"] == old["storage"]
plan = FrozenReplayPlan.load(TRACE, count=1000)
spec, bins, identities, waves, index = source_profile_inputs(
    SPEC, plan, new["model"], (ROOT / new["storage"]["remote_dir"]).resolve(strict=True))
assert len(waves) == 3 and all(len(w) == 4 for w in waves)
assert len(identities) == 6 and "admission_initialization" not in spec
assert set(i["rank"] for i in identities.values()) == {8, 16}
assert [len(w) for w in waves] == [4, 4, 4]
seal = verify_seal(ROOT / "paper_results/ieee_tc/safety/20260925_execution_start_protected.json")
assert seal["pass"], seal
report = dict(kind="d156_bootstrap_input_qualification_v1", passed=True,
    plan_sha256=check_plan(), metric_protocol_sha256=hashlib.sha256(
        (ROOT / "docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md").read_bytes()).hexdigest(),
    model_diff=diff, waves=len(waves), indexed_samples=sum(map(len, waves)),
    unique_existing_adapters=len(identities), existing_trace_sha256=plan.source_sha256,
    protected=seal, references={str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p):
        hashlib.sha256(p.read_bytes()).hexdigest() for p in [CFG, SPEC, OLD, TRACE]},
    serving_code_changed=False, formal_qualified=False)
with (RAW / "bootstrap_inputs.json").open("x") as f:
    json.dump(report, f, indent=2)
print(json.dumps(report))
