#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
# Reuse D143's stopped-service copy protocol. Prepared during D154 replay;
# execute ONLY after exact local/remote cleanup. Discover the exact journal by
# the frozen health clock after shutdown, then pass that path explicitly.
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d156_20261002
alias=primelora-artifact-174
test "$#" = 1
journal=$1
[[ "$journal" =~ ^/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-[0-9a-f]{32}\.jsonl$ ]]
monitor=/home/lab14/primelora_remote/tc/d156_20261002/remote_monitor_7b_bootstrap1.log
test -s "$raw/7b_cap4_bootstrap2_launch.json"
jq -e '.native_gpu_context_release_confirmed == true and .service_path_removed == true' "$raw/7b_cap4_bootstrap2_launch.json"
test "$(systemctl --user show primelora-tc-svc-f757d22d0c054074a8e6df7179df7b7e.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test -s "$raw/stop_services_bootstrap2.log"
test ! -e "$raw/remote_copy_receipt.txt"
test ! -e "$raw/remote_7b_bootstrap2_transfers.jsonl"
test ! -e "$raw/remote_monitor_bootstrap2_final.log"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" bash -s <<'REMOTE'
set -euo pipefail
for unit in primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d156bootstrap1.service; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
REMOTE
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "head -n 1 '$journal'" |
  jq -e '.clock_id == "remote-process-monotonic:695cea944a90406fadb1f81dd97d6b86"'
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias" "sha256sum '$journal' '$monitor'" > "$raw/remote_copy_receipt.txt"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$journal" "$raw/remote_7b_bootstrap2_transfers.jsonl"
scp -q -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 "$alias:$monitor" "$raw/remote_monitor_bootstrap2_final.log"
read -r expected_journal _ < "$raw/remote_copy_receipt.txt"
expected_monitor=$(sed -n '2s/ .*//p' "$raw/remote_copy_receipt.txt")
test "$(sha256sum "$raw/remote_7b_bootstrap2_transfers.jsonl" | cut -d' ' -f1)" = "$expected_journal"
test "$(sha256sum "$raw/remote_monitor_bootstrap2_final.log" | cut -d' ' -f1)" = "$expected_monitor"
sha256sum "$raw/remote_7b_bootstrap2_transfers.jsonl" "$raw/remote_monitor_bootstrap2_final.log"
