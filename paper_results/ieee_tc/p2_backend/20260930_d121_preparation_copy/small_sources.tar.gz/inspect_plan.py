"""Bounded read-only shape inspection of D119's already saved normal outcome."""
import json
from pathlib import Path

p=Path('results/ieee_tc/p2_backend_qualification/d119_20260930/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json')
assert p.stat().st_size == 60920330 and p.stat().st_size < 128*1024**2
data=json.loads(p.read_text())
events=data['mechanism_events']
print(json.dumps({'keys':list(events),'epoch_count':len(events['_ieee_residency_epochs'])}))
for name in ('_ieee_residency_epochs','_ieee_file_preparation_plans','_ieee_gpu_preparation_plans'):
    value=events.get(name)
    print(name, type(value).__name__)
    if isinstance(value,list) and value:
        for index in (0,len(value)//2,len(value)-1):
            x=value[index]
            print(index, {k:(list(v) if isinstance(v,dict) else ('list',len(v)) if isinstance(v,list) else v)
                          for k,v in x.items()})
