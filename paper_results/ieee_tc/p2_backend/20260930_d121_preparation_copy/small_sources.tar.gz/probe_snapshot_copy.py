"""Reuse D102 retained-native-view discovery; measure copy/JSON/hash, not parsing.

These are historical D88 native snapshots, not complete D119 preparation plans.
Do not scale their timing by later adapter count or call it request latency.
"""
import asyncio
import copy
import hashlib
import json
from pathlib import Path
import time

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = Path(__file__).parent
output = raw/'snapshot_copy_probe.json'
assert not output.exists()

def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def find_native(value, path=()):
    if isinstance(value, dict):
        if value.get('kind') == 'native_lora_sources_v1':
            yield path, value
            return
        for key, child in value.items():
            if isinstance(child, (dict, list)):
                yield from find_native(child, path+(key,))
    elif isinstance(value, list):
        for i, child in enumerate(value):
            if isinstance(child, (dict, list)):
                yield from find_native(child, path+(i,))

async def measure(view):
    samples = []
    reference = encode(view)
    expected_sha = hashlib.sha256(reference).hexdigest()
    for trial in range(3):
        loop = asyncio.get_running_loop()
        callback = loop.create_future()
        scheduled = time.perf_counter_ns()
        loop.call_soon(lambda: callback.set_result(time.perf_counter_ns()))
        t0 = time.perf_counter_ns()
        owned = copy.deepcopy(view)
        t1 = time.perf_counter_ns()
        encoded = encode(owned)
        t2 = time.perf_counter_ns()
        digest = hashlib.sha256(encoded).hexdigest()
        t3 = time.perf_counter_ns()
        observed = await callback
        assert encoded == reference and digest == expected_sha
        assert owned == view and owned is not view
        if owned['sources']:
            original_name = view['sources'][0]['adapter_id']
            owned['sources'][0]['adapter_id'] = 'probe-owned-copy-only'
            assert view['sources'][0]['adapter_id'] == original_name
        samples.append(dict(trial=trial, deepcopy_ms=(t1-t0)/1e6,
            canonical_json_ms=(t2-t1)/1e6, sha256_ms=(t3-t2)/1e6,
            total_ms=(t3-t0)/1e6, ready_callback_delay_ms=(observed-scheduled)/1e6))
    assert encode(view) == reference
    return expected_sha, len(reference), samples

results = []
for model in ('3b', '7b'):
    manifest_path = ROOT/f'paper_results/ieee_tc/p2_backend/d89_{model}_initialization/manifest.json'
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    source = ROOT/manifest['source_run']['path']
    # Both immutable D88 sources were already parsed in this 4 GiB envelope.
    # D114 peaked at 1.69 GB for the 253 MB 3B source. Enforce exact known sizes,
    # not an arbitrary cutoff that would reject that qualified reusable input.
    assert source.stat().st_size == {'3b': 253310434, '7b': 20341207}[model]
    encoded = source.read_bytes()
    assert hashlib.sha256(encoded).hexdigest() == manifest['source_run']['sha256']
    data = json.loads(encoded)
    del encoded
    views = list(find_native(data))
    complete = [(path, value) for path, value in views if value.get('native_footprints') is not None]
    assert complete, 'No real retained complete view; do not substitute synthetic state'
    path, view = max(complete, key=lambda row: (len(row[1]['native_footprints']['host_allocations']),
                                               len(row[1]['registered_cpu_adapter_ids'])))
    digest, size, samples = asyncio.run(measure(view))
    results.append(dict(model=model, source_path=str(source),
        source_sha256=manifest['source_run']['sha256'],
        manifest_path=str(manifest_path), manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
        retained_views=len(views), complete_views=len(complete), selected_path=list(path),
        selected_owner_id=view['owner_id'], epoch=view['epoch'],
        cpu_adapters=len(view['registered_cpu_adapter_ids']),
        host_allocations=len(view['native_footprints']['host_allocations']),
        canonical_json_bytes=size, view_sha256=digest, samples=samples))
    del data, views, complete, view
result = dict(kind='d121_retained_native_snapshot_copy_diagnostic_v1',
    production_modified=False, gpu_or_remote_started=False, formal_performance_result=False,
    models=results, limits=[
        'Historical D88 profile snapshots, not D119 online or maximum cache occupancy.',
        'Native component only; no 500-artifact file view, DP, IO, RPC, or complete plan measured.',
        'Ready callback delay demonstrates local non-yielding work, not D119 queue causality.',
        'Three CPU repetitions are not independent workload runs or a seed confidence interval.'])
with output.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps(result, indent=2))
