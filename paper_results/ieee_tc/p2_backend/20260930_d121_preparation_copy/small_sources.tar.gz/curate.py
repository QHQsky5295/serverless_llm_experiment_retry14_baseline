"""Adapt D120 evidence closure; no production change or repeated GPU work."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d121_20260930'
out = root/'paper_results/ieee_tc/p2_backend/20260930_d121_preparation_copy'
assert not out.exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed = []
for name, identity in (
    ('views','7bdbf2fb208c4f60b46303cd6f58b570'),
    ('views2','9a5e09281c984504a2b567a4b22a5f79'),
    ('copy','377ba612241f4fcfb3707431af717567'),
    ('copy2','4fe6cf1a44bb450e8b87500afc051a41')):
    unit = f'primelora-d121-{name}-20260930.scope'
    fields = dict(line.split('=',1) for line in subprocess.check_output(
        ['systemctl','--user','show',unit,'-p','InvocationID','-p','ControlGroup','-p','TasksCurrent'],text=True).splitlines())
    assert fields['InvocationID'] == identity and fields['TasksCurrent'] == '0'
    assert fields['ControlGroup'] == '/user.slice/user-1001.slice/user@1001.service/app.slice/'+unit
    cg = Path('/sys/fs/cgroup'+fields['ControlGroup'])
    assert not (cg/'cgroup.procs').read_text().strip()
    assert 'populated 0' in (cg/'cgroup.events').read_text().splitlines()
    events = dict(line.split() for line in (cg/'memory.events').read_text().splitlines())
    assert all(events[k] == '0' for k in ('high','max','oom','oom_kill'))
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    closed.append(dict(unit=unit, identity=fields, events=events, closed=True))

before = json.loads((root/'results/ieee_tc/p2_backend_qualification/d119_20260930/prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    assert digest(Path(name) if name.startswith('/') else root/name) == expected, name
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
probe = json.loads((raw/'snapshot_copy_probe.json').read_text())
assert probe['production_modified'] is False and probe['formal_performance_result'] is False
assert len(probe['models']) == 2
for model in probe['models']:
    assert len(model['samples']) == 3
    assert digest(Path(model['manifest_path'])) == model['manifest_sha256']
    assert json.loads(Path(model['manifest_path']).read_text())['source_run']['sha256'] == model['source_sha256']
    for sample in model['samples']:
        assert abs(sum(sample[k] for k in ('deepcopy_ms','canonical_json_ms','sha256_ms'))-sample['total_ms']) < 1e-8
        assert sample['ready_callback_delay_ms'] >= sample['total_ms'] > 0
for name in ('inspect_plan.py','inspect_views.py','probe_snapshot_copy.py','curate.py'):
    ast.parse((raw/name).read_text())
for name in ('inspect.sh','inspect_views.sh','run_copy_probe.sh','cleanup_inspect.sh','curate.sh'):
    subprocess.run(['bash','-n',str(raw/name)],check=True)

out.mkdir()
with (out/'summary.json').open('x') as handle:
    json.dump(probe, handle, indent=2, allow_nan=False)
names = ('inspect_plan.py','inspect.sh','inspect.log','inspect_time.txt','inspect_scope.txt',
    'inspect_views.py','inspect_views.sh','views.log','views2.log','views_time.txt','views_scope.txt',
    'probe_snapshot_copy.py','run_copy_probe.sh','copy.log','copy_time.txt','copy_scope.txt',
    'copy2.log','copy2_time.txt','copy2_scope.txt','copy_attempt1_sources.tar.gz',
    'cleanup_inspect.sh','curate.py','curate.sh')
bundle = out/'small_sources.tar.gz'
with tarfile.open(bundle,'x:gz') as archive:
    for name in names:
        archive.add(raw/name, arcname=name)
with tarfile.open(bundle,'r:gz') as archive:
    for name in names:
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == digest(raw/name)
refs = [raw/name for name in names]
refs += [out/'summary.json',bundle, root/'docs/ieee_tc/D121_PREPARATION_COPY_DIAGNOSTIC.md',
         root/'faaslora/preloading/preloading_planner.py',root/'scripts/run_all_experiments.py']
receipt = dict(kind='d121_copy_diagnostic_verification_v1',production_modified=False,
    formal_performance_result=False,production_sources_checked=len(before['source_sha256']),
    protected=protected,closed_scopes=closed,syntax_and_sample_invariants_pass=True,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
with (out/'verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
with (out/'small_sources.sha256').open('x') as handle:
    handle.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(pass_checks=True,production_sources=receipt['production_sources_checked'],
    protected=147,bundle_members=len(names),summary_sha256=digest(out/'summary.json'),
    verification_sha256=digest(out/'verification.json'))))
