"""Find retained immutable planning/source views without expanding the raw run."""
import json
from collections import Counter
from pathlib import Path

p = Path('results/ieee_tc/p2_backend_qualification/d119_20260930/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json')
assert p.stat().st_size == 60920330
data = json.loads(p.read_text())
kinds, matches = Counter(), []
def visit(x, path=()):
    if isinstance(x, dict):
        kind = x.get('kind')
        if isinstance(kind, str):
            kinds[kind] += 1
        if 'source_view' in x or kind in ('native_lora_sources_v1', 'ieee_owned_preparation_view_v1', 'ieee_preparation_epoch_v1'):
            matches.append(dict(path=path, kind=kind, keys=list(x)))
        for k, v in x.items():
            if isinstance(v, (dict, list)):
                visit(v, path+(k,))
    elif isinstance(x, list):
        for i, v in enumerate(x):
            if isinstance(v, (dict, list)):
                visit(v, path+(i,))
visit(data)
print(json.dumps(dict(kinds=kinds, matches=matches), indent=2))
