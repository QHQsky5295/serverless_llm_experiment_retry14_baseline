"""Small evidence packaging only: no dataset duplication or raw-outcome read."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d173_20261002'
out = root/'paper_results/ieee_tc/p2_backend'
unit = 'primelora-d173-full1-evidence1-20261002.scope'
def prop(name):
    return subprocess.check_output(['systemctl','--user','show',unit,'-p',name,'--value'],text=True).strip()
# Verify completed exact-owned cleanup without repeating it.
receipt = (raw/'cleanup_evidence_full1.log').read_text()
assert 'ActiveState=inactive' in receipt
assert prop('ActiveState') == 'inactive'
assert not prop('InvocationID')
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
assert 'InvocationID=fbe2dd8442234dda8d190c5870a07b37' in (raw/'full_full1_evidence_scope.txt').read_text()
# Scope auto-removed; final counters are not reconstructed.

# Only top-level small scripts, configuration and receipts; no remote journal,
# monitor, projection, raw outcomes, model files, token files or cache roots.
members = sorted(p for p in raw.iterdir() if p.is_file() and
    p.stat().st_size < 64*1024 and p.suffix in {'.py','.sh','.jq','.yaml','.json','.log','.txt'})
# Explicit whitespace-transform source receipt.
extras = [raw/'full_full1_metadata_compaction3.sha256']
assert all(p.is_file() and p.stat().st_size < 128*1024 for p in extras)
members = sorted(set(members + extras))
bundle = out/'20261002_d173_analysis_sources.tar.gz'
assert not bundle.exists()
hashes = {}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        data = p.read_bytes()
        # Anchor actual PEM header; attempt1 matched its own check literal.
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line
                       for line in data.splitlines())
        hashes[p.name] = hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
manifest = out/'20261002_d173_analysis_sources.sha256'
with manifest.open('x') as f:
    f.write(hashlib.sha256(bundle.read_bytes()).hexdigest()+'  '+bundle.name+'\n')
members_manifest = out/'20261002_d173_analysis_sources_members.json'
with members_manifest.open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,members=len(hashes),
                      sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),cleanup=True)))

