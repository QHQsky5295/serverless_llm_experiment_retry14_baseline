#!/usr/bin/env bash
# Reuse D145 closure protocol for observed D173 completion; no repeated tests.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d173_20261002
unit=primelora-d173-full1-evidence1-20261002.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_evidence_scope.txt"
export PYTHONUNBUFFERED=1
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python - <<'PY'
import csv, json, math, subprocess
from datetime import datetime, timezone
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d173_20261002'
out = root/'paper_results/ieee_tc/p2_backend'
before = json.loads((raw/'prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    p = Path(name) if name.startswith('/') else root/name
    assert digest(p) == expected, name
assert len(before['source_sha256']) == 339
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert before['runtime_source_commit'] == '73b5883a2bd5c9279b8dc19f5b5d949adfc41947'
full = out/'20261002_d173_7b_full_w0_full1.json'
assert digest(full) == '9be3317a564baa0b8a02de5bb70bb1542160f6aa943f4e4714e2e037e72e18e9'
x = json.loads(full.read_text())
assert x['native_contract_completion_pass'] and not x['full_qualified']
assert not x['formal_performance_result'] and x['launcher_cleanup_pass']
assert x['execution_completed'] and x['cleanup']['complete']
launch = json.loads((raw/'7b_full_w0_full1/launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert all(launch[k] == 0 for k in ('service_returncode','replay_returncode','watchdog_returncode'))
assert x['population']['success'] == x['population']['native_contract_matched'] == 4000
assert x['population']['terminal'] == x['population']['planned'] == 4000
assert x['population']['failure_observations'] == {}
assert x['timing_validation']['requests'] == 4000
assert max(x['timing_validation']['max_error_ms'].values()) <= 1.0
assert x['timing_validation']['pass_tolerance'] and x['timing_validation']['violations'] == []
assert x['timing_validation']['requests_over_tolerance'] == 0
assert x['physical']['n_correct'] is None and not x['physical']['eligible_correctness']
assert x['physical']['measurement_complete'] and not x['physical']['open_lease_ids']
assert not x['observed_completion_boundaries']['client_response_observed']
assert x['quarantine']['events'] == x['quarantine']['released'] == 0
assert x['remote']['uuid_pairs'] == 132
assert not x['remote']['byte_mismatches'] and x['remote']['request_packing'] == 0
assert x['remote']['states'] == {'published':132}
assert x['remote']['client_received_bytes'] == x['remote']['server_socket_written_bytes'] == 131480060
assert x['readiness_evidence']['confirmed_pre_generation_requests'] == 4000
assert x['readiness_evidence']['conflicts'] == 0
comparison = x['d164_request_contract_comparison']
assert comparison['request_ids_identical'] and comparison['requests'] == 4000
for field, audit in comparison['fields'].items():
    if field == 'completion_token_ids_sha256':
        assert audit['equal_requests'] == 3856 and len(audit['changed_request_ids']) == 144
    else:
        assert audit['equal_requests'] == 4000 and audit['changed_request_ids'] == []
planning = x['planning_cpu_diagnostics']
assert planning['events'] == 1904
assert set(planning['by_operation']) == {'owned_execution_epoch', 'initialized_gpu_objective'}
op = planning['by_operation']['owned_execution_epoch']
assert op['events'] == op['receipt_rows'] == 1902
assert op['state_counts'] == {'completed':1902}
assert op['errors'] == {}
assert op['execution_objectives_ms']['n'] == 1902
assert op['execution_objectives_ms']['mean'] > 0
init = planning['by_operation']['initialized_gpu_objective']
assert init['events'] == init['receipt_rows'] == 2
assert init['state_counts'] == {'completed':2} and not init['errors']
assert (raw/'full_full1_main_outcome_compact3.json').stat().st_size == 132810528
assert (raw/'full_full1_main_outcome_compact3.json').stat().st_size < 128*1024**2
for removed in x['cleanup']['roots']:
    assert not Path(removed['path']).exists(), removed['path']
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == x['metric_protocol_sha256']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
reused, checked = [], 0
for ref in x['source_refs']:
    p = Path(ref['path'])
    if p.name == 'experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d173_7b_full_w0_full1.json':
        st = p.stat()
        assert st.st_size == 273153784 and st.st_mtime_ns <= full.stat().st_mtime_ns
        reused.append(dict(**ref,bytes=st.st_size,mtime_ns=st.st_mtime_ns,inode=st.st_ino,
                           verification='reuse_completed_curator_stream_hash_plus_stat'))
    else:
        assert digest(p) == ref['sha256'], ref['path']
        checked += 1
assert len(reused) == 1
failure = out/'20261002_d173_7b_full_w0_failure_breakdown.json'
f = json.loads(failure.read_text())
assert f['population'] == dict(planned=4000,success=4000,timeout=0,returned_error=0)
assert f['returned_categories'] == {}
assert f['failure_observation_clock_id'] == x['physical']['clock_id']
assert f['projection_sha256'] == digest(raw/'full_full1_request_projection.json')
assert f['source_script_sha256'] == digest(raw/'collect_full1_failure_breakdown.py')
assert not f['timeout_requests'] and not f['returned_requests']
assert f['returned_generation_submission_states'] == {}
assert f['returned_error_messages'] == {}
assert f['first_timeout'] is None and f['first_returned_error'] is None
occupancy_dir = out/'20261002_d173_control_occupancy'
occupancy = json.loads((occupancy_dir/'summary.json').read_text())
assert occupancy['population'] == dict(planned=4000,terminal=4000,native_success=4000,failed=0)
assert occupancy['phase_population'] == 'complete_native_success_population' and occupancy['failures'] == []
for ref in occupancy['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256']
phases = occupancy['phase_summaries']
assert all(v['n'] == 4000 for v in phases.values())
phase_sum = math.fsum(phases[k]['total_request_seconds'] for k in (
    'gate_to_source_admission','source_to_native_dispatch','native_dispatch_to_last_token',
    'last_token_to_controller_completion','controller_completion_to_terminal'))
assert math.isclose(phase_sum,phases['gate_to_terminal']['total_request_seconds'],abs_tol=1e-6)
with (occupancy_dir/'request_occupancy.csv').open() as h:
    rows = list(csv.DictReader(h))
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
controls = occupancy['control_observations']
assert controls['source_event_count'] == controls['in_request_window_count'] == 1765
assert controls['outside_request_window'] == []
assert sum(v['samples'] for v in controls['by_phase'].values()) == 1765
for filename in ('full_full1_projection_time.txt','full_full1_curation_time.txt',
                 'full_full1_failure_time.txt','full_full1_metadata3_time.txt','audit_time1.txt'):
    assert 'Exit status: 0' in (raw/filename).read_text(), filename
# Post-cleanup readback, not a reconstructed historical cleanup stdout.
stage_ids = {
 'metadata':('primelora-d173-full1-metadata3-20261002.scope','full_full1_metadata3_scope.txt','6ccc1a0f0b1a46afa8f878a9bd5e9a1f'),
 'projection':('primelora-d173-full1-project-20261002.scope','full_full1_projection_scope.txt','8d73d0e66ecc44de826a5e1c86aadb89'),
 'curation':('primelora-d173-full1-curate-20261002.scope','full_full1_curation_scope.txt','f82d4ade0e4445f9b328040ae0ecdd27'),
 'occupancy':('primelora-d173-occupancy1-20261002.scope','scope_before1.txt','2b67605ba89a4a51b10b1e115ae88166')}
post_cleanup = []
for stage,(unit,filename,invocation) in stage_ids.items():
    assert 'InvocationID='+invocation in (raw/filename).read_text()
    active = subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()
    assert active == 'inactive', unit
    post_cleanup.append(dict(stage=stage,unit=unit,historical_invocation=invocation,
        scope_receipt=filename,current_state=active,verification='post_cleanup_readback_not_original_stdout'))
# These four scopes auto-removed before post-exit inspection; verify absence,
# never manufacture final resource counters or pretend a manual stop occurred.
for stage,(unit,_,_) in stage_ids.items():
    assert not subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','--value'],text=True).strip()
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    receipt_name = 'cleanup_occupancy_full1.log' if stage == 'occupancy' else f'full_full1_{stage}_cleanup.txt'
    receipt = (raw/receipt_name).read_text()
    assert 'ActiveState=inactive' in receipt
# D173 also evaluates the SAME provisional reference; no formal SLO claim.
timing_path = out/'20261002_d173_timing_gap.json'
timing = json.loads(timing_path.read_text())
assert timing['timing_joint_pass_count'] == 2167 and timing['joint_upper_bound'] == 2167/4000
assert timing['minimum_additional_timing_passes'] == 1633
assert timing['outcome_counts'] == dict(timing_pass=2167,ttft_only_miss=1582,tpot_only_miss=91,both_miss=160,failure=0)
assert not timing['common_reference_frozen'] and not timing['correctness_qualified']
assert timing['n_correct'] is None and timing['formal_joint_slo'] is None
assert not timing['formal_g1_g2_qualified'] and timing['resident_budget'] is None
assert timing['physical_gpu_s'] == x['physical']['gpu_seconds']
assert timing['max_timing_reconstruction_error_s'] <= .001
for path,sha in timing['sources'].items(): assert digest(Path(path)) == sha
for path,sha in timing['table_sha256'].items(): assert digest(Path(path)) == sha
for name,count in [('timing_groups',11),('timing_requests',4000),('vs_d164_comparison',11)]:
    with (out/('20261002_d173_'+name+'.csv')).open() as h: table=list(csv.DictReader(h))
    assert len(table)==count
analysis_unit='primelora-d173-analyze1-20261002.scope'
assert 'InvocationID=abdb53ea92994d2d84b8c64dab715d7f' in (raw/'analyze1_scope.txt').read_text()
assert 'Exit status: 0' in (raw/'analyze1_time.txt').read_text()
for line in (raw/'analyze1_memory_events.txt').read_text().splitlines(): assert int(line.split()[1])==0
assert int((raw/'analyze1_swap.txt').read_text())==0
assert subprocess.check_output(['systemctl','--user','show',analysis_unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
assert not subprocess.check_output(['systemctl','--user','show',analysis_unit,'-p','InvocationID','--value'],text=True).strip()
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',analysis_unit).exists()
# Failed format-only attempt remains; the unchanged guard rejected it before load.
assert (raw/'full_full1_main_outcome_compact2.json').stat().st_size==136920668
assert 'InvocationID=d0d94c749bfe45de96b16a6d094aaa33' in (raw/'full_full1_metadata2_scope.txt').read_text()
assert not (raw/'full_full1_metadata2_time.txt').exists()
assert not (raw/'full_full1_metadata2.log').exists()
assert (raw/'full_full1_main_outcome_compact3.json').stat().st_size < 134217728
# Existing unchanged timing helper's qualified source/tests are reused.
prior_timing=out/'20261002_d171_timing_gap.json'
assert digest(prior_timing)=='361bb4bc1ff7c49ac23449227d4dd31d7829cc87fbc86d7847c0658bb5dd7a15'
pt=json.loads(prior_timing.read_text())
for path in (root/'scripts/analyze_control_path_overhead.py',root/'tests/test_ieee_tc_timing_bound.py'):
    assert digest(path)==pt['sources'][str(path)]
# Existing unchanged analysis regression is reused, not rerun to pad work.
prior = out/'20261001_d137_evidence_verification.json'
assert digest(prior) == '18b496f98daf9aa48aab8d98d68b75507df33798bd8b29b470e75d3a98da4c17'
assert json.loads(prior.read_text())['pass_checks']
refs = [full,failure,prior,raw/'collect_full1_failure_breakdown.py',raw/'full_full1_failure_time.txt',
        raw/'summarize_full_full1.py',raw/'verify_full1_evidence.sh',raw/'full_full1_curation_time.txt',
        raw/'run_occupancy_audit1.sh',raw/'cleanup_occupancy_full1.sh',raw/'cleanup_occupancy_full1.log',
        raw/'scope_before1.txt',raw/'audit_time1.txt',root/'docs/ieee_tc/D173_FULL_W0_FULL1.md',
        root/'scripts/analyze_control_path_overhead.py',root/'tests/test_ieee_tc_control_timeline.py',
        raw/'full_full1_metadata_compaction3.sha256']
refs += [raw/name for _,name,_ in stage_ids.values()]
refs += [raw/name for name in ('cleanup_projection_full1.sh','full_full1_projection_cleanup.txt',
 'cleanup_curation_full1.sh','full_full1_curation_cleanup.txt','full_full1_metadata_cleanup.txt')]
refs += [out/'20261002_d164_7b_full_w0_full1.json', out/'20261002_d173_vs_d164_comparison.csv']
refs += [p for p in occupancy_dir.iterdir() if p.is_file()]
refs += [timing_path, prior_timing, raw/'analyze.py', raw/'run_cpu.sh',
    raw/'analyze1_scope.txt',raw/'analyze1_time.txt',raw/'analyze1.log',
    raw/'analyze1_memory_events.txt',raw/'analyze1_swap.txt',
    raw/'inspect_full1_metadata2.sh',raw/'full_full1_metadata2_scope.txt',
    raw/'inspect_full1_metadata3.sh',raw/'collect_full1_preliminary3.py',
    out/'20261002_d173_timing_groups.csv',out/'20261002_d173_timing_requests.csv']
receipt = dict(kind='d173_full1_evidence_verification_v1',pass_checks=True,
    verified_at=datetime.now(timezone.utc).isoformat(),full_qualified=False,formal_performance_result=False,
    frozen_source_refs_checked=len(before['source_sha256']),curated_source_refs_rehashed=checked,
    reused_large_source_hash=reused,source_commit=before['runtime_source_commit'],
    protected=protected,post_cleanup_readback=post_cleanup,
    failed_population_preserved=True,prior_d145_timeout_root_cause_unresolved=True,
    regression_reused=str(prior),refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
dest = out/'20261002_d173_evidence_verification.json'
with dest.open('x') as h:
    json.dump(receipt,h,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(dest),sha256=digest(dest),frozen_sources=339,
    curated_sources_rehashed=checked,reused_large_source_hash=len(reused),protected=147)))
PY

