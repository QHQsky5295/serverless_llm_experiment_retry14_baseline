#!/usr/bin/env bash
set -euo pipefail
# Existing D150 exact-identity cleanup, bound to this actual activation.
# Execute remotely ONLY after local terminal and physical GPU cleanup.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d173full1.service)
ids=(e0a90de84d3c44279a8ec4a214a20940 3c297a4c816a48acb1a04dc4d6d97278 c9b5ec78f1e44e1c9a5093b92ddd2417)
pids=(4167150 4167152 4167155)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result

