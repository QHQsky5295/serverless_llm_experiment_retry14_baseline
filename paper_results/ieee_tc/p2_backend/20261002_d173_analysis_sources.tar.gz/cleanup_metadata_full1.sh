#!/usr/bin/env bash
# Reuse D160 automatic-removal verification, with this actual invocation only.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d173_20261002
unit=primelora-d173-full1-metadata3-20261002.scope
{
  date -Is
  rg -qx 'InvocationID=6ccc1a0f0b1a46afa8f878a9bd5e9a1f' "$raw/full_full1_metadata3_scope.txt"
  rg -q 'Exit status: 0' "$raw/full_full1_metadata3_time.txt"
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=6ccc1a0f0b1a46afa8f878a9bd5e9a1f\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=all_zero_observed_in_terminal_transcript_before_removal\n'
} | tee "$raw/full_full1_metadata_cleanup.txt"

