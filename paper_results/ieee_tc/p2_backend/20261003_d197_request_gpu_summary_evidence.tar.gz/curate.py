"""Reuse D192's small-file curation, exact table and evidence packaging."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT=Path.cwd(); RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX='20261003_d197_request_gpu_summary'
DOC=ROOT/'docs/ieee_tc/D197_REQUEST_GPU_SUMMARY_STUDY.md'
def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()
attempts=[]
for index,invocation,exit_code in ((1,'065b1237046748ceb6704bbbdabc097b',1),
                                  (2,'3b923972d57949eb8f0c928dfbde4bac',0)):
    unit=f'primelora-d197-probe{index}-20261003.scope'
    for prop,value in (('LoadState','not-found'),('InvocationID',''),('ControlGroup','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip()==value
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    assert f'InvocationID={invocation}' in (RAW/f'probe{index}_scope.txt').read_text()
    assert f'Exit status: {exit_code}' in (RAW/f'probe{index}_time.txt').read_text()
    events=dict(line.split() for line in (RAW/f'probe{index}_memory_events.txt').read_text().splitlines())
    assert all(int(value)==0 for value in events.values())
    assert (RAW/f'probe{index}_swap.txt').read_text().strip()=='0'
    for when in ('before','after'):
        receipt=(RAW/f'probe{index}_protected_{when}.json').read_text()
        if not receipt.lstrip().startswith('{'):
            prefix,receipt=receipt.split('\n',1)
            assert prefix.startswith('INFO ') and 'platform' in prefix
        assert json.loads(receipt)['pass']
    attempts.append(dict(attempt=index,invocation_id=invocation,exit_code=exit_code,
        memory_events=events,swap_bytes=0,scope_absent=True))
assert 'StopIteration' in (RAW/'probe1.log').read_text()
assert not (RAW/'probe1.json').exists() and not (RAW/'probe1.csv').exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','bac5f8f0420100b690928a2c099d5e5ae7d8b7ee','--','faaslora','scripts','tests','configs/ieee_tc'],text=True).strip()
assert sha(RAW/'probe2.json')=='6e51c0f81cc8e931e7c01877378aa98099416ac696afad48124fee3146100cdc'
probe=json.loads((RAW/'probe2.json').read_text())
assert not any(probe[k] for k in ('production_changed','gpu_execution','remote_operation'))
assert sha(Path(probe['source']))==probe['source_sha256']
for name,digest in probe['unchanged_sources'].items():
    assert sha(ROOT/name)==digest
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected==probe['protected_artifacts'] and protected['pass'] and protected['entry_count']==147
assert protected['plan_sha256']==probe['plan_sha256']
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')==probe['metric_protocol_sha256']
assert len(probe['snapshots'])==11 and len(probe['measurements'])==66
assert len(probe['negative_checks'])==110 and len(probe['fixture_checks'])==7
groups=[]
table=['# D197 request GPU summary component table','',
    'Retained snapshots; three alternating rounds, five calls per round. No serving gain or seed CI.',
    'All outliers and failed attempt1 retained. Decision: defer production change; insufficient main-bottleneck evidence.','',
    '| 快照 | 目标ID | tier | 已注册 | 完整 bytes | 摘要 bytes | 完整 ms | 摘要 ms | 字节减少 | 时间减少 |',
    '|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|']
document=DOC.read_text()
for case in probe['snapshots']:
    chosen=[r for r in probe['measurements'] if r['snapshot']==case['snapshot'] and r['target']==case['target']]
    timings={}
    for variant in ('full','summary'):
        values=[r for r in chosen if r['variant']==variant]
        assert len(values)==3 and sorted(r['repeat'] for r in values)==[0,1,2]
        assert all(r['iterations']==5 and r['projection_validation_and_msgpack_roundtrip_included'] for r in values)
        timings[variant]=statistics.mean(r['mean_ms'] for r in values)
    a,b=case['full_bytes'],case['summary_bytes']
    old,new=timings['full'],timings['summary']
    row=dict(snapshot=case['snapshot'],target=case['target'],tier=case['tier'],
        registered=case['registered'],gpu_views=case['gpu_views'],full_bytes=a,summary_bytes=b,
        full_ms=old,summary_ms=new,delta_ms=old-new,
        byte_reduction=(a-b)/a,time_reduction=(old-new)/old)
    groups.append(row)
    line=f"| {row['snapshot']} | {row['target']} | {row['tier']} | {row['registered']} | {a} | {b} | {old:.6f} | {new:.6f} | {(a-b)/a*100:.3f}% | {(old-new)/old*100:.3f}% |"
    assert line in document,line
    table.append(line)
with (OUT/(PREFIX+'.csv')).open('x',newline='') as handle:
    writer=csv.DictWriter(handle,fieldnames=list(groups[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(groups)
with (OUT/(PREFIX+'_table.md')).open('x') as handle:
    handle.write('\n'.join(table)+'\n')
members=[RAW/name for name in ('probe.py','run_cpu.sh','probe2.py','run_cpu2.sh',
    'probe2.json','probe2.csv','curate.py','run_curate.sh','check_staged.py')]
for index in (1,2):
    members.extend(RAW/f'probe{index}_{suffix}' for suffix in (
        'scope.txt','time.txt','memory_events.txt','swap.txt','protected_before.json','protected_after.json'))
    members.append(RAW/f'probe{index}.log')
members.append(DOC)
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret)>16
for path in members:
    data=path.read_bytes()
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    if path.suffix=='.py': ast.parse(data,filename=str(path))
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
source_shas={str(p):sha(p) for p in members}
bundle=OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output,tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members: archive.add(path,arcname=path.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers())==len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(path.name).read()).hexdigest()==source_shas[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as handle:
    handle.write(sha(bundle)+'  '+bundle.name+'\n')
result=dict(kind='d197_request_gpu_summary_study_curated_v1',
    status='defer_production_candidate_insufficient_main_bottleneck_evidence',probe=probe,groups=groups,
    source_sha256=source_shas,protected_after=protected,probe_scope_absent=True,
    attempts=attempts,
    plot_decision='Exact component table, all outliers retained; no serving-performance figure or seed CI.',
    production_changed=False,gpu_execution=False,remote_operation=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    output_csv_sha256=sha(OUT/(PREFIX+'.csv')),table_sha256=sha(OUT/(PREFIX+'_table.md')))
with (OUT/(PREFIX+'.json')).open('x') as handle: json.dump(result,handle,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS',groups=len(groups),protected=147,
    curated_sha256=sha(OUT/(PREFIX+'.json')),evidence_bundle=result['evidence_bundle']),indent=2))
