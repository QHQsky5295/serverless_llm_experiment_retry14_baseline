"""D180/D193-derived request GPU representation dependency/component study.

Retained real native observations and existing CPU fixtures only. The native
inventory remains fresh and full; the study removes descriptive GPU tables
ONLY from the request-source transport projection. Not a production parser.
"""
import ast
import copy
import csv
import hashlib
import inspect
import json
from pathlib import Path
import statistics
import subprocess
import time
from unittest.mock import patch
import msgspec
import torch
from scripts.ieee_tc_preflight import verify_seal
from faaslora.experiment import instance_pool
from faaslora.experiment.instance_pool import NativeSourceSnapshot
from faaslora.memory import gpu_monitor
from tests.test_ieee_tc_worker_observation import manager, FakeTensor, fake_torch

ROOT=Path.cwd()
RAW=Path(__file__).resolve().parent
PARENT='bac5f8f0420100b690928a2c099d5e5ae7d8b7ee'
PLAN_SHA='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
METRIC_SHA='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==PARENT
assert not torch.cuda.is_initialized()
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147 and protected['plan_sha256']==PLAN_SHA
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')==METRIC_SHA
sources=['faaslora/memory/gpu_monitor.py','faaslora/experiment/instance_pool.py',
         'faaslora/preloading/preloading_planner.py','scripts/run_all_experiments.py',
         'tests/test_ieee_tc_worker_observation.py','tests/test_ieee_tc_request_footprints.py']
source_shas={}
for name in sources:
    assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show','HEAD:'+name])
    source_shas[name]=sha(ROOT/name)

SUMMARY='live_uniform_gpu_pool_summary_v1'
def summarize_pool(full):
    # Full helper has already measured storage aliases and physical layout.
    # No cross-call cache and no change to the upstream native checks.
    views=full.get('pool_tensor_views')
    if (not isinstance(views,list) or not views or
        any(not isinstance(v,dict) or not isinstance(v.get('dtype'),str)
            or not v['dtype'] for v in views)):
        raise ValueError('native GPU representation has no dtype')
    return {**{k:v for k,v in full.items() if k not in ('pool_tensor_views','pool_allocations')},
            'pool_observation_kind':SUMMARY,
            'pool_dtypes':sorted({v['dtype'] for v in views})}

def consume_summary(payload):
    if (payload.get('pool_observation_kind')!=SUMMARY
        or 'pool_tensor_views' in payload or 'pool_allocations' in payload):
        raise ValueError('request GPU summary is missing or mixes full tables')
    dtypes=payload.get('pool_dtypes')
    if (not isinstance(dtypes,list) or not dtypes
        or any(not isinstance(v,str) or not v for v in dtypes)
        or dtypes!=sorted(set(dtypes))):
        raise ValueError('request GPU summary has invalid dtypes')
    # Internal consumer adapter ONLY for the dependency study. These rows are
    # not published as physical tensor views. Production needs an explicit
    # summary parser branch, complete native validation and transport tests.
    return [{'dtype':dtype} for dtype in dtypes]

# Change only the dtype-input expression of the current consumer, in memory.
# Every source/owner/clock/HOST alias/slot capacity/target check remains current.
tree=ast.parse((ROOT/'faaslora/experiment/instance_pool.py').read_text())
klass=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='NativeSourceSnapshot')
func=copy.deepcopy(next(n for n in klass.body if isinstance(n,ast.FunctionDef) and n.name=='_footprints'))
matches=[n for n in ast.walk(func) if isinstance(n,ast.Assign)
         and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='gpu_views']
assert len(matches)==1 and ast.unparse(matches[0].value)=="payload.get('pool_tensor_views')"
matches[0].value=ast.parse('consume_summary(payload)',mode='eval').body
func.decorator_list=[]
namespace={**vars(instance_pool),'consume_summary':consume_summary}
exec(compile(ast.fix_missing_locations(ast.Module(body=[func],type_ignores=[])),
             '<d197-analysis-only-dtype-consumer>','exec'),namespace)
summary_footprints=namespace['_footprints']
original_footprints=NativeSourceSnapshot._footprints

def target_view(native,aid):
    # Reuse D180 requested-subgraph construction. Global identity is retained.
    p={k:copy.deepcopy(v) for k,v in native.items()
       if k not in ('native_footprints','native_staging_footprints','native_host_allocator')}
    f=copy.deepcopy(native['native_footprints'])
    f.pop('host_tensor_views',None)
    adapters=[a for a in f['host_adapter_footprints'] if a['adapter_int_id']==aid]
    ids=sorted({i for a in adapters for i in a['allocation_ids']})
    remap={old:new for new,old in enumerate(ids)}
    f['host_allocations']=[{**f['host_allocations'][old],
        'allocation_id':remap[old],'adapter_ids':[aid]} for old in ids]
    for a in adapters:
        a['allocation_ids']=[remap[i] for i in a['allocation_ids']]
        a.pop('exclusive_storage_bytes')
        a['within_observation_exclusive_bytes']=a['storage_bytes']
    f['host_adapter_footprints']=adapters
    f.pop('host_tensor_storage_bytes')
    f['requested_host_storage_bytes']=sum(a['allocated_bytes'] for a in f['host_allocations'])
    f['host_footprint_scope']='native_requested_tensor_storage_capacity'
    f['host_requested_adapter_ids']=[aid]
    p['native_request_footprints']=f
    return p

def compact(p):
    return {**p,'native_request_footprints':summarize_pool(p['native_request_footprints'])}

def parse(p,aid,summary=False):
    parser=summary_footprints if summary else original_footprints
    with patch.object(NativeSourceSnapshot,'_footprints',staticmethod(parser)):
        return NativeSourceSnapshot.from_request_native(p,requested_adapter_ids=[aid],
            expected_clock_id=p['clock_id'],received_monotonic_s=p['captured_monotonic_s']+1)

def component(p,aid,use_summary):
    start=time.perf_counter_ns()
    value=compact(p) if use_summary else p
    encoded=msgspec.msgpack.encode(value)
    decoded=msgspec.msgpack.decode(encoded)
    result=parse(decoded,aid,use_summary)
    return (time.perf_counter_ns()-start)/1e6,result,len(encoded)

source=RAW.parent/'d169_20261002/7b_probe1.json'
assert 0<source.stat().st_size<64*1024**2
assert sha(source)=='ead0c5c81acc52c502874e9d45cfba111665f875220e23467c2e716a0d770602'
snapshots=[b['sources_before'] for b in json.loads(source.read_bytes())['warm_batches']]
assert len(snapshots)==4
cases,rows,negatives=[],[],[]
for index,native in enumerate(snapshots):
    full=NativeSourceSnapshot.from_native(native,expected_clock_id=native['clock_id'],
        received_monotonic_s=native['captured_monotonic_s']+1)
    present_tiers=sorted({s.tier for s in full.sources})
    targets=[next(s.adapter_int_id for s in full.sources if s.tier==tier) for tier in present_tiers]
    targets.append(max(full.registered_cpu_adapter_ids)+1)  # metadata-only absent target, not new weights.
    for aid in targets:
        p=target_view(native,aid)
        expected=parse(p,aid)
        selected=compact(p)
        assert parse(selected,aid,True)==expected
        assert NativeSourceSnapshot.from_native(native,expected_clock_id=native['clock_id'],
            received_monotonic_s=native['captured_monotonic_s']+1)==full
        assert expected.identity_view()==full.identity_view()
        raw_bytes=len(msgspec.msgpack.encode(p))
        compact_bytes=len(msgspec.msgpack.encode(selected))
        label='absent' if aid not in full.registered_cpu_adapter_ids else next(s.tier for s in full.sources if s.adapter_int_id==aid)
        case=dict(snapshot=index,target=aid,tier=label,registered=len(full.registered_cpu_adapter_ids),
            gpu_views=len(p['native_request_footprints']['pool_tensor_views']),
            full_bytes=raw_bytes,summary_bytes=compact_bytes,all_source_state_equal=True)
        cases.append(case)
        for repeat in range(3):
            for variant in (('full','summary') if repeat%2==0 else ('summary','full')):
                elapsed=[]
                for _ in range(5):
                    duration,state,size=component(p,aid,variant=='summary')
                    assert state==expected
                    assert size==(compact_bytes if variant=='summary' else raw_bytes)
                    elapsed.append(duration)
                rows.append(dict(snapshot=index,target=aid,tier=label,variant=variant,
                    repeat=repeat,iterations=5,mean_ms=statistics.mean(elapsed),
                    projection_validation_and_msgpack_roundtrip_included=True))
        # Invalid common fields must remain rejected after projection, without
        # clipping or filling missing values. Projection rejection also counts.
        for name,mutate in {
            'slot_capacity':lambda x:x['native_request_footprints'].__setitem__('slot_capacity_bytes',0),
            'slot_ids':lambda x:x['native_request_footprints'].__setitem__('slot_adapter_ids',[]),
            'host_total':lambda x:x['native_request_footprints'].__setitem__('requested_host_storage_bytes',-1),
            'gpu_dtype':lambda x:x['native_request_footprints']['pool_tensor_views'][0].__setitem__('dtype',''),
            'owner_id':lambda x:x.__setitem__('owner_id',''),
            'unconfirmed':lambda x:x.__setitem__('complete_for_native_caches',False),
        }.items():
            broken=copy.deepcopy(p);mutate(broken)
            outcomes=[]
            for summary in (False,True):
                try: parse(compact(broken) if summary else broken,aid,summary)
                except (ValueError,TypeError) as error: outcomes.append(type(error).__name__)
                else: raise AssertionError(('invalid field accepted',index,aid,name,summary))
            assert len(outcomes)==2
            negatives.append(dict(snapshot=index,target=aid,case=name,both_rejected=True))
        for name,value in (('empty',[]),('duplicate',['float16','float16']),('nonstring',[1]),('missing',None)):
            broken=copy.deepcopy(selected)
            broken['native_request_footprints']['pool_dtypes']=value
            try: parse(broken,aid,True)
            except ValueError: pass
            else: raise AssertionError(('invalid summary accepted',name))
            negatives.append(dict(snapshot=index,target=aid,case='summary_'+name,summary_rejected=True))

# Existing CPU fake-CUDA metadata fixture, explicitly NOT GPU timing.
# Full physical checks execute BEFORE every projection. Confirm no stale slot
# state, alias, object substitution or malformed geometry is accepted.
native=manager()
native.modules={'layer':type(native.modules['layer'])(
    lora_a_stacked=(FakeTensor(1000,512),),lora_b_stacked=(FakeTensor(2000,512),))}
fixture_checks=[]
with patch.object(gpu_monitor,'torch',fake_torch()):
    for label,slots,active in [('initial',[7,None],{7:object()}),
                                ('replaced',[None,8],{8:object()}),
                                ('empty',[None,None],{})]:
        native.lora_index_to_id=slots;native._active_adapters=active
        observed=gpu_monitor._ieee_lora_pool_inventory(native,require_uniform_slots=True)
        result=summarize_pool(observed)
        assert result['slot_adapter_ids']==slots and result['active_gpu_adapter_ids']==sorted(active)
        assert result['pool_allocated_bytes']==1024 and result['slot_capacity_bytes']==512
        fixture_checks.append(dict(case=label,fresh_full_inventory=True,projected_state_equal=True))
    for name,tensor in [('offset',FakeTensor(1000,512,offset=1)),
                        ('alias_partial',FakeTensor(1000,1024)),
                        ('noncontiguous',FakeTensor(1000,512,contiguous=False)),
                        ('bad_leading_slots',FakeTensor(1000,512,shape=(1,16,16)))]:
        native.modules['layer'].lora_a_stacked=(tensor,)
        try: summarize_pool(gpu_monitor._ieee_lora_pool_inventory(native,require_uniform_slots=True))
        except ValueError: pass
        else: raise AssertionError(('invalid physical inventory accepted',name))
        fixture_checks.append(dict(case=name,native_physical_rejection_before_projection=True))
assert NativeSourceSnapshot._footprints is original_footprints
assert not torch.cuda.is_initialized()
assert verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')==protected
result=dict(kind='d197_request_gpu_representation_dependency_study_v1',parent_commit=PARENT,
    plan_sha256=PLAN_SHA,metric_protocol_sha256=METRIC_SHA,protected_artifacts=protected,
    unchanged_sources=source_shas,source=str(source),source_sha256=sha(source),
    snapshots=cases,measurements=rows,negative_checks=negatives,fixture_checks=fixture_checks,
    observed_tier_counts=[dict(snapshot=i,gpu=sum(s['gpu_slot'] is not None for s in n['sources']),
        host=sum(s['gpu_slot'] is None for s in n['sources'])) for i,n in enumerate(snapshots)],
    preserved_attempt1_error='Selection assumed HOST existed in all snapshots; snapshot0 has only GPU sources.',
    production_changed=False,gpu_execution=False,remote_operation=False,
    caveats=['Current consumer projection of historical D169 observations, not D195 live message distribution.',
             'All native inventory construction/physical checks retained. No cross-call geometry cache.',
             'Timing covers test-only projection validation, msgpack encode/decode and current consumer with explicit dtype adapter.',
             'No worker inventory time, actual vLLM framing, IPC queueing, CUDA execution or end-to-end serving time measured.',
             'Full planning, activation inheritance and physical admission retain complete GPU tensor tables.',
             'Metadata absent target is not a new adapter weight or a generated workload; n_correct and model acceptance remain unknown.'])
with (RAW/'probe2.json').open('x') as handle:json.dump(result,handle,indent=2,allow_nan=False)
with (RAW/'probe2.csv').open('x',newline='') as handle:
    writer=csv.DictWriter(handle,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
print(json.dumps(dict(status='PASS',cases=len(cases),measurements=len(rows),
                     negative_checks=len(negatives),fixture_checks=len(fixture_checks))))
