#!/usr/bin/env bash
# Reuse the D193 bounded CPU runner; no GPU or remote experiment.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d197_20261003
unit=primelora-d197-probe2-20261003.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/probe2_scope.txt"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
python=/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python
"$python" scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "$raw/probe2_protected_before.json"
set +e
/usr/bin/time -v -o "$raw/probe2_time.txt" "$python" "$raw/probe2.py" > "$raw/probe2.log" 2>&1
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/probe2_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/probe2_swap.txt"
"$python" scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "$raw/probe2_protected_after.json"
exit "$code"
