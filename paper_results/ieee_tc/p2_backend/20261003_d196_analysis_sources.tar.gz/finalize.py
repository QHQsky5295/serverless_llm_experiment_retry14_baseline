"""Reuse small evidence packaging and protected-artifact checks for D196."""
import csv
import hashlib
import json
import math
import subprocess
import tarfile
from pathlib import Path
from statistics import mean
from scripts.ieee_tc_preflight import ROOT, digest, verify_seal, check_plan

RAW=Path(__file__).parent.resolve()
BASE=ROOT/'paper_results/ieee_tc/p2_backend'
OUT=BASE/'20261003_d196_control_path'
DOC=ROOT/'docs/ieee_tc/D196_CONTROL_PATH_DIAGNOSIS.md'
unit='primelora-d196-analyze1-20261003.scope'
def prop(name):
    return subprocess.check_output(['systemctl','--user','show',unit,'-p',name,'--value'],text=True).strip()
assert prop('ActiveState') == 'inactive' and not prop('InvocationID') and not prop('ControlGroup')
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
assert 'InvocationID=026c90f010da4e07a38efc71c16ef3fa' in (RAW/'analyze1_scope.txt').read_text()
assert 'Exit status: 0' in (RAW/'analyze1_time.txt').read_text()
assert all(line.split()[1] == '0' for line in (RAW/'analyze1_memory_events.txt').read_text().splitlines())
assert (RAW/'analyze1_swap.txt').read_text().strip() == '0'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()

load=lambda p:json.loads(p.read_text())
d=load(OUT/'diagnosis.json')
s=load(OUT/'summary.json')
assert digest(OUT/'diagnosis.json') == 'cc0d7f9e5f89867cfdb25891e6b40463d94c7e913aff8879d8d6f12047271b9f'
assert digest(OUT/'summary.json') == 'fc33bd921a1173c97fd8fd0cc678a40a00ecca755f8e2dbd85c597635c17b56e'
for path,sha in d['sources'].items():
    assert digest(Path(path)) == sha
for ref in s['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256']
assert check_plan() == d['plan_sha256']
protection=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protection == d['protection_after'] and protection['pass']
with (OUT/'request_control_spans.csv').open(newline='') as f:
    rows=list(csv.DictReader(f))
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
with (OUT/'control_spans.csv').open(newline='') as f:
    groups=list(csv.DictReader(f))
assert len(groups) == len(d['groups']) == 65
for row,expected in zip(groups,d['groups']):
    assert row['group'] == expected['group'] and row['field'] == expected['field']
    selected=[r for r in rows if row['group'] == 'all' or r['tier'] == row['group']]
    values=sorted(float(r[row['field']]) for r in selected)
    assert int(row['n']) == len(values) == expected['n']
    for name,actual in dict(mean=mean(values),p50=values[math.ceil(.5*len(values))-1],
                            p95=values[math.ceil(.95*len(values))-1],max=values[-1]).items():
        assert float(row[name]) == expected[name] == actual

# Reuse the already sealed D191/D190 table, not its original result/projection.
previous = BASE/'20261003_d191_control_path/control_spans.csv'
previous_verifier = BASE/'20261003_d191_evidence_verification.json'
assert digest(previous_verifier) == 'f63b05688bb95229845ac44a9e043afbb09d2b5d28c44ca629231e7a69f8172b'
assert digest(previous) == '6d5af7ad414164108a8b0110ca5dcf5bab89225db14efb5696554e756ca2c98e'
assert load(previous_verifier)['artifacts'][str(previous.relative_to(ROOT))] == digest(previous)
with previous.open(newline='') as f:
    prior={(r['group'],r['field']):r for r in csv.DictReader(f)}
assert set(prior) == {(r['group'],r['field']) for r in groups}
comparison=[]
for row in groups:
    old=prior[row['group'],row['field']]
    comparison.append(dict(group=row['group'],field=row['field'],unit='ms',
        previous_run='D190',current_run='D195',previous_n=int(old['n']),current_n=int(row['n']),
        previous_mean=float(old['mean']),current_mean=float(row['mean']),
        mean_delta_ms=float(row['mean'])-float(old['mean']),
        previous_p95=float(old['p95']),current_p95=float(row['p95']),
        subgroup_causal_pair=False))
with (OUT/'d190_d195_stage_comparison.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(comparison[0]))
    writer.writeheader()
    writer.writerows(comparison)
labels={'arrival_release_lateness_ms':'计划到达→服务端接收',
        'dispatch_window_wait_ms':'接收→全局 gate',
        'recorded_routing_ms':'gate→源准入：已记录 routing',
        'runtime_wait_outside_recorded_routing_ms':'gate→源准入：其余残余',
        'source_to_generation_handoff_ms':'源准入→generation handoff',
        'generation_handoff_to_native_ms':'generation handoff→native dispatch'}
text=DOC.read_text()
for field,label in labels.items():
    row=next(r for r in comparison if r['group']=='all' and r['field']==field)
    line=(f"| {label} | {row['previous_mean']:.3f} | {row['current_mean']:.3f} | "
          f"{row['mean_delta_ms']:+.3f} | {row['current_p95']:.3f} |")
    assert line in text, line
for field in ('runtime_slot_wait_ms', 'recorded_routing_ms',
              'runtime_wait_outside_recorded_routing_ms',
              'source_to_generation_handoff_ms', 'generation_handoff_to_native_ms',
              'dispatch_admission_wait_ms'):
    row=next(r for r in comparison if r['group']=='gpu' and r['field']==field)
    assert (row['previous_n'], row['current_n']) == (1232, 1165)
    line=f"| {field} | {row['previous_mean']:.3f} | {row['current_mean']:.3f} |"
    assert line in text, line

source_paths=['scripts/run_all_experiments.py','scripts/analyze_control_path_overhead.py',
    'faaslora/preloading/planning_cpu.py','faaslora/memory/gpu_monitor.py',
    'faaslora/experiment/instance_pool.py','faaslora/scheduling/vllm_ieee_frontend.py',
    'faaslora/memory/residency_manager.py','faaslora/datasets/workload_generator.py',
    'scripts/dedicated_engine_worker.py','docs/ieee_tc/D195_FULL_W0_FULL1.md']
for name in source_paths:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git','show','HEAD:'+name])
# Syntax smoke for the new local analysis wrappers; no code execution or pyc writes.
for name in ('analyze.py','finalize.py','check_staged.py'):
    compile((RAW/name).read_bytes(),str(RAW/name),'exec')
subprocess.run(['bash','-n',str(RAW/'run_cpu.sh')],check=True)

members=[RAW/name for name in ('analyze.py','run_cpu.sh','finalize.py','check_staged.py',
    'analyze1_scope.txt','analyze1_time.txt','analyze1_memory_events.txt','analyze1_swap.txt','analyze1.log')]
members += [ROOT/'scripts/analyze_control_path_overhead.py']
bundle=BASE/'20261003_d196_analysis_sources.tar.gz'
assert not bundle.exists()
hashes={}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        assert p.is_file() and p.stat().st_size < 128*1024
        name=p.name
        assert name not in hashes
        hashes[name]=digest(p)
        archive.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name,sha in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == sha
with (BASE/'20261003_d196_analysis_sources_members.json').open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
with (BASE/'20261003_d196_analysis_sources.sha256').open('x') as f:
    f.write(digest(bundle)+'  '+bundle.name+'\n')
artifacts=sorted(OUT.iterdir())+[DOC,bundle]
result=dict(kind='d196_offline_evidence_verification_v1',passed=True,
    protection=protection,request_count=4000,summary_rows=65,
    sources_unchanged=source_paths,syntax_smoke=True,analysis_scope_released=True,
    analysis_invocation_id='026c90f010da4e07a38efc71c16ef3fa',
    artifacts={str(p.relative_to(ROOT)):digest(p) for p in artifacts},
    bundle_members=len(hashes),bundle_bytes=bundle.stat().st_size,
    prior_table_sources={str(p.relative_to(ROOT)):digest(p) for p in (previous,previous_verifier)},
    comparison_rows=len(comparison),document_stage_table_checked=True,
    document_gpu_conditional_table_checked=True)
with (BASE/'20261003_d196_evidence_verification.json').open('x') as f:
    json.dump(result,f,indent=2)
print(json.dumps(result))
