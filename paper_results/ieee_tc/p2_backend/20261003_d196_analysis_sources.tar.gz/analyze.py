"""Reuse the sealed D195 projection and existing RPC analyzer; no inference."""
import csv
import json
import math
from pathlib import Path
from statistics import mean

from scripts.analyze_control_path_overhead import analyze_rpc_breakdown, write_csv
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal

RAW = Path(__file__).parent.resolve()
SOURCE = ROOT / 'results/ieee_tc/p2_backend_qualification/d195_20261003'
OUT = ROOT / 'paper_results/ieee_tc/p2_backend/20261003_d196_control_path'
SEALED = ROOT / 'paper_results/ieee_tc/p2_backend/20261003_d195_7b_full_w0_full1.json'
SHA = '31594e530d42341c2eb876e18daf2d7a3f39a4c9cb728cd14f3b4bda45da4134'
PROJECTION = SOURCE / 'full_full1_request_projection.json'
DEPLOYMENT = SOURCE / '7b_full_w0_full1/launch.launch/physical_deployment'
PROTOCOL = ROOT / 'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
SEAL = ROOT / 'paper_results/ieee_tc/safety/20260925_execution_start_protected.json'

assert not OUT.exists()
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(PROTOCOL) == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
before = verify_seal(SEAL)
assert before['pass'] and before['entry_count'] == 147
audit = analyze_rpc_breakdown(PROJECTION, DEPLOYMENT/'deployment.json',
    DEPLOYMENT/'request_terminals.jsonl', SEALED, SHA, OUT)
assert audit['complete_field_coverage']
assert PROJECTION.stat().st_size < 64 * 1024**2
rows = json.loads(PROJECTION.read_text())['requests']
assert len(rows) == len({r['request_id'] for r in rows}) == 4000

records = []
for row in rows:
    rt = row['runtime_slot_wait_ms']
    routing = row['routing_decision_us'] / 1000
    lateness = row['arrival_release_lateness_ms']
    window = row['dispatch_window_wait_ms']
    admission = row['dispatch_admission_wait_ms']
    t = row['native_token_timing']
    handoff = row['retained_reference_evidence']['generation_submission']
    assert handoff['boundary'] == 'parent_rpc_handoff_v1'
    assert handoff['state'] == 'may_execute'
    assert all(type(v) in (int, float) and math.isfinite(v) and v >= 0
               for v in (rt, routing, lateness, window, admission))
    residual = rt - routing
    # No clipping or treating missing/invalid quantities as zero.
    assert residual >= 0, (row['request_id'], rt, routing)
    assert abs(lateness + window + rt - admission) <= 1.0
    source_to_handoff = 1000 * (handoff['handoff_monotonic_s'] - t['controller_admitted_monotonic_s'])
    handoff_to_native = 1000 * (t['native_dispatch_monotonic_s'] - handoff['handoff_monotonic_s'])
    assert min(source_to_handoff, handoff_to_native) >= 0
    assert abs(source_to_handoff + handoff_to_native - t['admission_to_engine_dispatch_ms']) <= 1.0
    e = row['external_arrival_timing']
    ext = dict(offered_to_task_ms=1000*(e['task_created_s']-e['planned_arrival_s']),
        task_to_client_submit_ms=1000*(e['client_submit_s']-e['task_created_s']),
        client_submit_to_server_receive_ms=1000*(e['server_received_s']-e['client_submit_s']),
        server_receive_to_service_dequeue_ms=1000*(e['service_dequeued_s']-e['server_received_s']))
    assert min(ext.values()) >= 0
    records.append(dict(request_id=row['request_id'],tier=row['readiness_tier_before_dispatch'],
        arrival_release_lateness_ms=lateness,dispatch_window_wait_ms=window,
        runtime_slot_wait_ms=rt,recorded_routing_ms=routing,
        runtime_wait_outside_recorded_routing_ms=residual,
        dispatch_admission_wait_ms=admission,source_to_generation_handoff_ms=source_to_handoff,
        generation_handoff_to_native_ms=handoff_to_native,
        overall_ttft_ms=row['overall_ttft_ms'],**ext))
groups=[]
fields=list(records[0])[2:]
for tier in ('all','gpu','host','nvme','remote'):
    selected=[r for r in records if tier == 'all' or r['tier'] == tier]
    assert selected
    for name in fields:
        values=sorted(r[name] for r in selected)
        groups.append(dict(group=tier,field=name,n=len(values),unit='ms',mean=mean(values),
            p50=values[math.ceil(.5*len(values))-1],p95=values[math.ceil(.95*len(values))-1],max=values[-1]))
write_csv(records,OUT/'request_control_spans.csv')
write_csv(groups,OUT/'control_spans.csv')
after=verify_seal(SEAL)
assert after == before
result=dict(kind='d196_retained_control_path_diagnosis_v1',new_inference_run=False,
    source_run='D195',run_count=1,formal_qualification=False,n_correct=None,
    plan_sha256=check_plan(),metric_protocol_sha256=digest(PROTOCOL),
    protection_before=before,protection_after=after,
    sources={str(p):digest(p) for p in (Path(__file__),PROJECTION,SEALED,PROTOCOL,
        ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'scripts/run_all_experiments.py')},
    groups=groups,
    caveats=[
        'recorded_routing_ms includes awaits; it is not exclusive CPU execution.',
        'Recorded routing excludes collection rejection returning None before the timer update.',
        'Residual includes unrecorded retries, pending registration, selected-source protection, event-loop resumption and capacity waits; it is not a named RPC duration.',
        'Actual selected-tier groups are conditional, not matched causal populations.',
        'External arrival subspans overlap legacy dispatch fields and must not be summed twice.',
        'No new performance result, CI, numerical correctness, common SLO or G1/G2 acceptance.'])
with (OUT/'diagnosis.json').open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps({'passed':True,'requests':len(records),'groups':groups},allow_nan=False))
