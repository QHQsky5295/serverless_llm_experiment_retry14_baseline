"""Reuse the prior qualified CPU interpreter/order after preserving the stop."""
import ast
import hashlib
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d663_20261018/qualify.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '1cfd5d94227448d349d837b613283b03d85a28f3069e74fa118ef531b952eeea'
code = data.decode()
old = "paths = ['faaslora/memory/gpu_monitor.py', 'faaslora/memory/residency_manager.py',\n         'tests/test_ieee_tc_hit_host_transaction.py']"
assert code.count(old) == 1
code = code.replace(old, "paths = ['faaslora/utils/core_timing.py', 'faaslora/scheduling/vllm_ieee_scheduler.py',\n         'tests/test_ieee_tc_core_timing.py']")
old = "tests = ['tests.test_ieee_tc_host_observation_freshness']"
assert code.count(old) == 1
code = code.replace(old, """tests = ['tests.test_ieee_tc_launch',
        'tests.test_ieee_tc_stack_diagnostic', 'tests.test_ieee_tc_control_diagnostic',
        'tests.test_ieee_tc_scheduler_observation', 'tests.test_ieee_tc_d456_diagnostic_contract']
    stopped = json.loads((RAW/'qualification2_stopped.json').read_text())
    assert stopped['stop_completed'] and stopped['path_gone']
    assert not Path(stopped['identity']['path']).exists()
    assert sys.executable == '/home/qhq/anaconda3/envs/sllm_vllm0102_newserverless_20260518/bin/python'""")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
