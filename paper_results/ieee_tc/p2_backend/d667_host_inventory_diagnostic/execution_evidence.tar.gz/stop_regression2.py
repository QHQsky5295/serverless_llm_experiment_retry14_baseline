"""Same owned stop with system Python's pidfd support; retain first stop receipt."""
import hashlib
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/stop_regression.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '17e0751f5bc6a8173acd4868ee1327884c0bf452889b42b74398cfcc8435b7dc'
code = data.decode().replace('regression_', 'qualification2_').replace('regression.log', 'qualification2.log')
code = code.replace('qualification2_stop_before.json', 'qualification2_stop2_before.json')
exec(compile(code, str(source), 'exec'))
