"""Reuse D595 explicit-path checkpoint; this is diagnostic code, not a policy."""
import ast
import hashlib
from pathlib import Path
import sys
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'c16bfc285f6b9ed3f14bd46b730b5c37f0a9c52245f0f90e093fa2c23f34c1c4'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace('d595_parallel_pressure_barrier', 'd667_host_inventory_diagnostic')
code = code.replace('023ae0079e0b2ffa537a81bda7855e8a4b8ede95', '30164bf97420a62d9ae1091d462713d7d1c9da55')
start = code.index("reg=read(RAW/'regression2_receipt.json')")
end = code.index('preserved={', start)
code = code[:start] + '''reg=read(RAW/'analysis2_receipt.json');focused=read(RAW/'qualification_receipt.json')
for phase in ('qualification','analysis2'):
    receipt=read(RAW/(phase+'_receipt.json'))
    assert receipt['passed'] and receipt['returncode']==0
    assert p.digest(RAW/(phase+'.log'))==receipt['log_sha256']
    for path,sha in receipt['source_sha256'].items():assert p.digest(Path(path))==sha
    closure=read(RAW/(phase+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
failed=read(RAW/'analysis_receipt.json')
assert failed['passed'] is False and failed['returncode']==1
closed_failed=read(RAW/'analysis_closure.json')
assert closed_failed['passed'] and closed_failed['path_gone']
assert not Path(closed_failed['identity']['path']).exists()
stopped=read(RAW/'qualification2_stopped.json')
assert stopped['passed'] is False and stopped['stop_completed'] and stopped['path_gone']
assert not Path(stopped['identity']['path']).exists()
previous=RAW.parent/'d666_20261018/publication_closure.json'
prior_closure=read(previous)
assert prior_closure['passed'] and prior_closure['path_gone']
assert not Path(prior_closure['identity']['path']).exists()
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
''' + code[end:]
start = code.index('members=[RAW/name')
end = code.index('\nfor path in members:', start)
code = code[:start] + "members=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log')])+[previous]\nassert sum(path.stat().st_size for path in members)<8*1024*1024" + code[end:]
replace("for name in ('focused','regression2')}", "for name in ('qualification','analysis2')}")
replace('production_candidate=True', 'production_candidate=False,diagnostic_only=True')
replace("policy='parallel_owner_barrier_v1'", "diagnostic='fresh_inventory_v1'")
replace('focused_before_metadata=focused,aborted_cpu_regression=stopped,protected=protected,',
        'focused=focused,aborted_cpu_regression=stopped,stale_test_failure=failed,protected=protected,\n    prior_publication_closure=prior_closure,')
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['faaslora/utils/core_timing.py','faaslora/scheduling/vllm_ieee_scheduler.py',\n    'tests/test_ieee_tc_core_timing.py','tests/test_ieee_tc_d456_diagnostic_contract.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D667_BOUNDED_HOST_INVENTORY_DIAGNOSTIC.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: qualify bounded HOST inventory timing without changing serving policy (D667)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D667 sealed explicit-path publication adaptation parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
