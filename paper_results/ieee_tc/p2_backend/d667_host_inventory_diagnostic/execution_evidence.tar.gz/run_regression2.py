"""Recheck the same CPU regression after correcting one stale test assertion."""
import ast
from pathlib import Path
raw = Path(__file__).resolve().parent
tree = ast.parse((raw/'run_regression_qualified.py').read_text())
assert isinstance(tree.body[-1], ast.Expr) and isinstance(tree.body[-1].value, ast.Call)
assert tree.body[-1].value.func.id == 'exec'
ns = {'__file__': str(__file__), '__name__': '__main__'}
exec(compile(ast.Module(body=tree.body[:-1], type_ignores=[]), str(raw/'run_regression_qualified.py'), 'exec'), ns)
code = ns['code']
code = code.replace("('qualification', 'qualification2', 'analysis')", "('analysis2',)")
code = code.replace("if phase == 'analysis':", "if phase == 'analysis2':")
code = code.replace("'tests/test_ieee_tc_core_timing.py']", "'tests/test_ieee_tc_core_timing.py',\n         'tests/test_ieee_tc_d456_diagnostic_contract.py']")
ast.parse(code)
exec(compile(code, str(raw/'run_regression2_expanded.py'), 'exec'))
