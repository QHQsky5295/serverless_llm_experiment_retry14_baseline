"""Reuse D663's bounded CPU, source and protected-evidence qualification gates."""
import ast
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d663_20261018/qualify.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '1cfd5d94227448d349d837b613283b03d85a28f3069e74fa118ef531b952eeea'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace("paths = ['faaslora/memory/gpu_monitor.py', 'faaslora/memory/residency_manager.py',\n         'tests/test_ieee_tc_hit_host_transaction.py']",
        "paths = ['faaslora/utils/core_timing.py', 'faaslora/scheduling/vllm_ieee_scheduler.py',\n         'tests/test_ieee_tc_core_timing.py']")
replace("tests = ['tests.test_ieee_tc_hit_host_transaction'] if phase == 'qualification' else [\n    'tests.test_ieee_tc_gpu_references', 'tests.test_ieee_tc_worker_observation',\n    'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_request_lifecycle']",
        "tests = ['tests.test_ieee_tc_core_timing'] if phase == 'qualification' else [\n    'tests.test_ieee_tc_stack_diagnostic', 'tests.test_ieee_tc_control_diagnostic',\n    'tests.test_ieee_tc_scheduler_observation', 'tests.test_ieee_tc_launch',\n    'tests.test_ieee_tc_d456_diagnostic_contract']")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
