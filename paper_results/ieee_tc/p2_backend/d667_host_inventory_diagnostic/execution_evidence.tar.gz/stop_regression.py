"""Reuse exact-owned CPU test stop; no GPU run or unrelated process is touched."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/stop_regression.py')
code = source.read_text().replace('regression_', 'qualification2_').replace("regression.log", "qualification2.log")
exec(compile(code, str(source), 'exec'))
