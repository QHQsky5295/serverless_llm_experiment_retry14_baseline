"""Reuse D828 evidence packaging, including the retained pre-change counterexample."""
from pathlib import Path

template = Path(__file__).resolve().parent.parent/'d828_20261025/publish.py'
source = template.read_text()
start = source.index("summary = read(OUT/'summary.json')")
end = source.index('\nclosed = []', start)
source = source[:start] + source[end:]
old = "    assert receipt['passed'] and receipt['protected']['entry_count'] == 147\n    for path, sha in receipt.get('sources', {}).items():\n        assert p.digest(Path(path)) == sha"
new = """    assert receipt['passed'] == (phase != 'before/focused')
    assert receipt['protected']['pass'] and receipt['protected']['entry_count'] == 147
    with tarfile.open(RAW/(phase+'_source.tar.gz'), 'r:gz') as snapshot:
        for path, sha in receipt['sources'].items():
            data = snapshot.extractfile(str(Path(path).relative_to(ROOT))).read()
            assert hashlib.sha256(data).hexdigest() == sha
            if phase != 'before/focused':
                assert p.digest(Path(path)) == sha"""
assert source.count(old) == 1
source = source.replace(old, new)
for old, new in (
    ('d828_post_file_owner_turn', 'd834_completed_membership_reuse'),
    ("for phase in ('analysis', 'focused', 'regression'):",
     "for phase in ('before/focused', 'focused', 'regression'):"),
    ("('d827_20261025', 'publish.py'), ('d824_20261025', 'backup.py')",
     "('d828_20261025', 'publish.py'), ('d824_20261025', 'backup.py')"),
    ('RAW.iterdir()', "RAW.rglob('*')"),
    ("'raw/'+path.name", "'raw/'+str(path.relative_to(RAW))"),
    ('distinct_regression_tests=370, focused_tests_included=57',
     'distinct_regression_tests=438, focused_tests=17, distinct_tests=452, retained_prechange_failures=2'),
    ("decision='One admitted owner anchor candidate CPU-qualified; complete unchanged 3B W2 next.'",
     "decision='Completed binding reuse CPU-qualified; actual admission remains atomic; complete 3B W2 next.'"),
    ('D828_POST_FILE_OWNER_TURN_20261025.md', 'D834_COMPLETED_MEMBERSHIP_REUSE_20261025.md'),
    ('distinct_tests=370', 'distinct_tests=452'),
):
    assert old in source, old
    source = source.replace(old, new)
out = Path('/home/qhq/serverless_llm_experiment_retry14_baseline/paper_results/ieee_tc/p2_backend/d834_completed_membership_reuse')
out.mkdir(parents=True, exist_ok=False)
exec(compile(source, str(template), 'exec'), globals())
