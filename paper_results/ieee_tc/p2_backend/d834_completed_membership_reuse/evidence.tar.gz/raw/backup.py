"""Reuse D824 explicit-path backup for the qualified D834 candidate only."""
from pathlib import Path

template = Path(__file__).resolve().parent.parent/'d824_20261025/backup.py'
source = template.read_text()
for old, new in (
    ('d824_current_ingress_pending', 'd834_completed_membership_reuse'),
    ('107185c45f49a891c0b391b1140b7d765e83daea', '0c93a6d92e2e7708c313f0c543e837cbe7118c9b'),
    ("OUT/'final_manifest.json'", "OUT/'manifest.json'"),
    ('D824_CURRENT_INGRESS_AND_CONTROL_20261025.md', 'D834_COMPLETED_MEMBERSHIP_REUSE_20261025.md'),
    ("         ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',",
     "         ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',\n         *[Path(path) for path in closure['production_sources']],"),
    ('len(set(paths)) == 20', 'len(set(paths)) == 8'),
    ('backup/d824-current-ingress-control-20261025', 'backup/d834-completed-membership-reuse-20261025'),
    ('tc: preserve current 3B ingress and actual scaling-trigger diagnosis (D824)',
     'tc: reuse completed pressure bindings without bypassing admission (D834)'),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'), globals())
