"""Pre-change characterization; the two no-barrier assertions should fail."""
from pathlib import Path

source = Path(__file__).resolve().parent.parent / 'run_tests.py'
exec(compile(source.read_text(), str(source), 'exec'))
