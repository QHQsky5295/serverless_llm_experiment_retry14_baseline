"""Reuse D610 resource-contained checks for idempotent pressure subscription."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d610_20261017/run_tests.py')
code = source.read_text()
# The pre-change characterization lives one directory deeper; use the same
# existing immutable seal, not a path relative to this receipt directory.
old = 'code = source.read_text()'
new = "code = source.read_text()\ncode = code.replace(\"RAW.parent.parent/'slora_qualification/\", \"Path('/home/qhq/serverless_llm_experiment/results/ieee_tc')/'slora_qualification/\")"
assert code.count(old) == 1
code = code.replace(old, new)
old = "'faaslora/memory/residency_manager.py',\n    'tests/test_ieee_tc_file_observation.py',\n    'tests/test_ieee_tc_request_lifecycle.py'"
new = "'faaslora/scheduling/resource_coordinator.py',\n    'tests/test_ieee_tc_transfer_pressure.py',\n    'tests/test_ieee_tc_shared_pressure_integration.py'"
assert code.count(old) == 1
code = code.replace(old, new)
old = "tests=(['tests.test_ieee_tc_file_observation']\n    if phase=='focused' else ['tests.test_ieee_tc_request_lifecycle',\n    'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_static_preparation'])"
new = "tests=(['tests.test_ieee_tc_transfer_pressure.ReusedPressureMembership',\n    'tests.test_ieee_tc_shared_pressure_integration.SharedPressureIntegration']\n    if phase=='focused' else ['tests.test_ieee_tc_transfer_pressure',\n    'tests.test_ieee_tc_request_lifecycle', 'tests.test_ieee_tc_static_preparation'])"
assert code.count(old) == 1
code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
