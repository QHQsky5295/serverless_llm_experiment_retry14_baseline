"""Reuse D595 explicit bounded backup for the completed offline D638 audit."""
import ast
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code = source.read_text()

def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d638_output_reference_audit'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'",
        "=='caf1addb5cf5a78d5893525167ab0c21f22b4970'")
begin = code.index('reg=read(RAW/')
end = code.index('preserved={', begin)
code = code[:begin] + """audit=read(RAW/'qualification.json')
assert audit['passed'] and audit['no_gpu_run'] and audit['no_production_change']
assert audit['same_input_request_count']==4000 and audit['output_change_count']==166
for path,sha in audit['refs'].items():assert p.digest(Path(path))==sha
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',
    'faaslora','scripts','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
""" + code[end:]
begin = code.index('members=[RAW/name')
end = code.index('\nfor path in members:', begin)
code = code[:begin] + """members=[RAW/name for name in ('analyze.py','close.py','backup.py',
    'analysis_identity.json','analysis_closure.json','preflight.json',
    'changed_requests.json','reference_matches.json','native_history.json','qualification.json','backup_gate.json')]
members += [ROOT/'scripts/ieee_tc/plot_d290_diagnostic.py',
    ROOT/'docs/ieee_tc/D638_OUTPUT_BINDING_AND_REFERENCE_AUDIT.md']
assert len({path.name for path in members})==len(members)
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
""" + code[end:]
begin = code.index('test_counts={')
end = code.index("save(OUT/'qualification.json'", begin)
code = code[:begin] + """test_counts={'complete_request_records':8000,'existing_reference_records':100}
record=dict(passed=True,production_candidate=False,native_gpu_validation=False,
    full_performance_run=False,parent_commit='caf1addb5cf5a78d5893525167ab0c21f22b4970',
    audit=audit,protected=protected,preserved={str(k):v for k,v in preserved.items()},
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    archive_members={path.name:dict(path=str(path),sha256=p.digest(path)) for path in members},
    caveat='Saved binding and matched existing-reference evidence only; current numerical cause unknown, no new exactness gate or raw correctness rewrite.')
""" + code[end:]
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D638_OUTPUT_BINDING_AND_REFERENCE_AUDIT.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: audit W0 output changes against frozen content and existing reference (D638)')
ast.parse(code)
exec(compile(code, str(source), 'exec'))
