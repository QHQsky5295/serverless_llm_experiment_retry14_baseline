"""Bounded offline output-change audit; reuse native binding and HF witnesses.

No GPU execution, no new token data, no numerical-tolerance or metric change.
"""
import collections
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import ijson
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.plot_d290_diagnostic import binding_checks, request_vectors

def read(path):
    return json.loads(path.read_text())

def save(name, value):
    with (RAW/name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

refs = {}
def bound(path, expected=None):
    actual = p.digest(path)
    if expected is not None:
        assert actual == expected, str(path)
    refs[str(path)] = actual
    return path

identity = p.scope_identity(p.cg_path().name)
save('analysis_identity.json', identity)
cg = Path(identity['path'])
assert (cg/'memory.high').read_text().strip() == str(3*p.GIB)
assert (cg/'memory.max').read_text().strip() == str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
gate = p.preflight([ROOT], 32*1024*1024)
save('preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
bound(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
      'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83')
bound(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
      '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22')
bound(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
      '193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d')
bound(ROOT/'configs/generated/lora_manifest_1000.json',
      '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df')
bound(ROOT/'scripts/ieee_tc/plot_d290_diagnostic.py')

index_path = bound(ROOT/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json',
    'e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c')
index = read(index_path)
expected = {a['id']: hashlib.sha256(json.dumps(sorted(a['files'], key=lambda f:f['path']),
    sort_keys=True, separators=(',', ':')).encode()).hexdigest() for a in index['artifacts']}
assert len(expected) == len(index['artifacts']) == 500
weights = {a['id']: next(f['sha256'] for f in a['files']
    if f['path'] == 'adapter_model.safetensors') for a in index['artifacts']}
tensor_path = bound(ROOT/'paper_results/ieee_tc/p2_backend/20260926_artifact_tensor_audit.csv',
    '28b3e64142698d75b09bdd62cfb4cf51e59903804818495b22729d2050ab33bc')
tensor = {r['adapter_id']:r for r in csv.DictReader(tensor_path.read_text().splitlines())
    if r['pool'] == 'llama2_7b_a500_v2_publicmix'}
assert tensor.keys() == expected.keys()
assert all(tensor[aid]['weight_sha256'] == weights[aid] for aid in tensor)

metadata_fields = {'backend', 'model', 'generation_contract', 'sampling_seed',
    'generation_seed', 'applied_env_overrides', 'resolved_enforce_eager',
    'max_loras', 'max_num_seqs', 'max_num_batched_tokens', 'runtime_concurrency_cap',
    'enable_prefix_caching', 'enable_chunked_prefill', 'vllm_attention_backend',
    'vllm_use_flashinfer_sampler', 'shared_trace_sha256', 'shared_adapter_subset_sha256',
    'artifact_transport_mode', 'artifact_delivery_modes', 'formal_run',
    'request_time_pack_count', 'total_requests'}
def projection(path, scenario, count):
    rows, checks = {}, collections.Counter()
    with path.open('rb') as stream:
        for row in ijson.items(stream, 'detailed_results.'+scenario+'.requests.item', use_float=True):
            rid, aid = row['request_id'], row['adapter_id']
            assert rid not in rows
            request_vectors([row])
            check = binding_checks(row, expected[aid])
            assert all(check.values()), (rid, check)
            checks.update({k:int(v) for k,v in check.items()})
            n = row['native_token_timing']
            assert row['success'] and n['native_terminal_observed']
            assert n['native_output_tokens'] == row['completion_tokens']
            rows[rid] = dict(request_id=rid, adapter_id=aid,
                prompt_sha256=row['canonical_prompt_sha256'],
                native_prompt_sha256=n['native_prompt_token_ids_sha256'],
                prompt_tokens=n['actual_prompt_tokens'], target=row['requested_completion_tokens'],
                generation_contract=row['generation_contract'], token_source=row['completion_token_source'],
                output_sha256=row['completion_token_ids_sha256'], tier=row['readiness_tier_before_dispatch'],
                weight_sha256=weights[aid], all_tensors_zero=tensor[aid]['all_tensors_zero'] == 'True')
            if 'completion_token_ids' in n:
                assert len(n['completion_token_ids']) == rows[rid]['target']
                assert hashlib.sha256(json.dumps(n['completion_token_ids'], separators=(',', ':')).encode()).hexdigest() == rows[rid]['output_sha256']
    assert len(rows) == count
    with path.open('rb') as stream:
        metadata = {k:v for k,v in ijson.kvitems(stream, 'metadata', use_float=True) if k in metadata_fields}
    return rows, dict(checks), metadata

runs, binding_counts, metadata = {}, {}, {}
for label, expected_sha in (
    ('d624', 'cf92a5afcca387527eaa10384accbbd19c87f064a1b53e657edff44d9e69f3ba'),
    ('d636', 'd312193a4b321a51aadbac67a0c99732c421f472c96fdcea19864a55b98d0aa8')):
    audit = read(bound(RAW.parent/(label+'_20261017')/'actual_qualification.json'))
    assert audit['passed'] and audit['evidence']['source_sha256'] == expected_sha
    path = bound(Path(audit['evidence']['source']), expected_sha)
    runs[label], binding_counts[label], metadata[label] = projection(path, 'tc_ieee_full', 4000)
assert runs['d624'].keys() == runs['d636'].keys()
same_fields = ('request_id', 'adapter_id', 'prompt_sha256', 'native_prompt_sha256',
               'prompt_tokens', 'target', 'generation_contract', 'token_source', 'weight_sha256')
changed = []
groups = collections.defaultdict(lambda: dict(total=0, changed=0))
for rid, current in runs['d636'].items():
    previous = runs['d624'][rid]
    assert all(current[k] == previous[k] for k in same_fields), rid
    different = current['output_sha256'] != previous['output_sha256']
    for family, key in (('weight_sha256', current['weight_sha256']),
                        ('zero_update', str(current['all_tensors_zero'])),
                        ('candidate_tier', current['tier']),
                        ('reference_tier', previous['tier']),
                        ('tier_pair', previous['tier']+'->'+current['tier'])):
        groups[family+'|'+key]['total'] += 1
        groups[family+'|'+key]['changed'] += int(different)
    if different:
        changed.append(dict(**current, reference_output_sha256=previous['output_sha256'],
                            reference_tier=previous['tier']))
comparison = read(bound(RAW.parent/'d636_20261017/comparison_d624.json'))
assert {r['request_id'] for r in changed} == set(comparison['same_backend_changed_output_request_ids'])
assert len(changed) == 166
save('changed_requests.json', changed)

hf_path = bound(RAW.parent/'d385_20261010/7b_peft_sequence_reference_100_retry1.json')
hf = read(hf_path)
native_path = bound(Path(hf['source_native_path']), hf['source_native_sha256'])
native, binding_counts['d384'], metadata['d384'] = projection(native_path, 'tc_ieee_native_token_witness_100', 100)
assert hf['measurement_complete'] and hf['input']['count'] == 100
assert hf['trace_sha256'] == metadata['d636']['shared_trace_sha256']
matches = []
for reference in hf['requests']:
    rid = reference['request_id']
    old, current = native[rid], runs['d636'][rid]
    assert all(old[k] == current[k] for k in same_fields), rid
    assert reference['adapter_id'] == current['adapter_id']
    assert reference['target_tokens'] == reference['native_tokens'] == reference['reference_tokens'] == current['target']
    assert reference['native_ids_sha256'] == old['output_sha256']
    matches.append(dict(request_id=rid, adapter_id=current['adapter_id'],
        all_tensors_zero=current['all_tensors_zero'], weight_sha256=current['weight_sha256'],
        reference_ids_sha256=reference['reference_ids_sha256'],
        d384_ids_sha256=old['output_sha256'], d624_ids_sha256=runs['d624'][rid]['output_sha256'],
        d636_ids_sha256=current['output_sha256'],
        d384_exact=reference['exact_sequence_match'],
        d624_exact=runs['d624'][rid]['output_sha256'] == reference['reference_ids_sha256'],
        d636_exact=current['output_sha256'] == reference['reference_ids_sha256'],
        candidate_matches_old_native=current['output_sha256'] == old['output_sha256']))
assert len(matches) == 100 and sum(r['d384_exact'] for r in matches) == 92
save('reference_matches.json', matches)

history_anchor = 'cf497bb092adcc0f2b5753eb4530b0c364c172f1'
execution_commit = '30ec27aad193bc3b0c672f54a4e609f597fec3fe'
code_history = []
for relative in ('faaslora/serving/inference_engine.py', 'faaslora/serving/vllm_wrapper.py',
                 'faaslora/scheduling/vllm_ieee_scheduler.py', 'faaslora/memory/gpu_monitor.py',
                 'scripts/run_all_experiments.py'):
    old = subprocess.check_output(['git', 'show', history_anchor+':'+relative], cwd=ROOT)
    new = subprocess.check_output(['git', 'show', execution_commit+':'+relative], cwd=ROOT)
    diff = subprocess.check_output(['git', 'diff', '--no-ext-diff', history_anchor, execution_commit,
        '--', relative], cwd=ROOT, text=True)
    code_history.append(dict(path=relative, history_anchor_sha256=hashlib.sha256(old).hexdigest(),
        current_execution_sha256=hashlib.sha256(new).hexdigest(), unchanged=old == new,
        diff=diff))
config_rows = {}
for label, name in (('d384', '20261010_d384_7b_native_token_witness_100.yaml'),
                    ('d636', '20261017_d636_7b_min2_full_w0.yaml')):
    cfg = yaml.safe_load(bound(ROOT/'configs/ieee_tc'/name).read_text())
    config_rows[label] = {k:v for k,v in cfg['model'].items()
        if k in metadata_fields or k in ('dtype', 'ieee_lora_metadata_policy',
            'ieee_control_interleave', 'ieee_file_demand_transaction', 'ieee_token_id_capture')}
save('native_history.json', dict(history_anchor=history_anchor,
    history_anchor_not_verified_as_d384_execution_commit=True,
    current_execution_commit=execution_commit, files=code_history, configs=config_rows,
    runtime_metadata=metadata))
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
result = dict(kind='d638_bounded_output_binding_and_existing_reference_audit', passed=True,
    same_input_request_count=4000, binding_check_pass_counts=binding_counts,
    output_change_count=len(changed), groups=dict(sorted(groups.items())),
    reference_subset_count=100, reference_unique_adapters=len({r['adapter_id'] for r in matches}),
    reference_unique_weight_classes=len({r['weight_sha256'] for r in matches}),
    exact_matches={key:sum(row[key] for row in matches) for key in
        ('d384_exact', 'd624_exact', 'd636_exact', 'candidate_matches_old_native')},
    reference_zero_nonzero={str(z):dict(total=sum(r['all_tensors_zero'] == z for r in matches),
        exact=sum(r['all_tensors_zero'] == z and r['d636_exact'] for r in matches)) for z in (True, False)},
    output_difference_cause='not established', kernel_arithmetic_correctness_proven=False,
    independent_reference_full_workload=False, full_cross_backend_exactness_required=False,
    raw_n_correct_preserved=None, raw_ranking_eligible_preserved=False,
    no_gpu_run=True, no_production_change=True, no_historical_result_rewrite=True,
    scope=identity, protected=protected, refs=refs,
    limitations=['Control witnesses verify identity consistency, not kernel arithmetic.',
        'Reference is an existing 100-request execution under different native capacities and control configuration.',
        'Zero updates cannot numerically distinguish one logical zero adapter from another.',
        'Historical near ties or documented nondeterminism do not explain individual current differences.',
        'No new numerical tolerance, selective deletion, exact-equality gate, or formal reclassification.'])
save('qualification.json', result)
print(json.dumps({k:result[k] for k in ('passed', 'same_input_request_count',
    'output_change_count', 'exact_matches', 'reference_zero_nonzero', 'groups')}))
