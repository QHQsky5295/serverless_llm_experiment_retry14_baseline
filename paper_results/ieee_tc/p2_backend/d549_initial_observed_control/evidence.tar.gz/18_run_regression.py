"""Extend the same bounded CPU qualification to full affected modules."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
source = (RAW/'run_tests.py').read_text()
source = source.replace("'tests/test_ieee_tc_transfer_pressure.py')]",
    "'tests/test_ieee_tc_transfer_pressure.py', 'tests/test_ieee_tc_cpu_frontend_integration.py')]")
source = source.replace('timeout=180)', 'timeout=900)')
exec(compile(source, str(RAW/'run_regression_reused.py'), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'run_regression.py')})
