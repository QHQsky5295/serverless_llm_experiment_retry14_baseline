"""Reuse D541 source/archive/protected-file guards for the D549 CPU checkpoint."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
template = RAW.parent.parent / 'resource_measurement/d541_20261015/publish.py'
source = template.read_text()

def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace("resource_measurement/d541_pidfd_exit", "p2_backend/d549_initial_observed_control")
replace("RAW/'publication_identity.json'", "RAW/'backup_identity.json'")
replace("RAW/'publication_receipt.json'", "RAW/'backup_receipt.json'")
replace("assert git('rev-parse','HEAD')=='31526e77835ec8e70e0096de21dbc3b9375bfc19'",
        "assert git('rev-parse','HEAD')=='5620e90bbad08f26817faebbfcd8af1c604ee456'")
replace("{'faaslora/metrics/metrics_collector.py','tests/test_ieee_tc_gpu_lifecycle.py'}",
        "{'scripts/run_all_experiments.py','tests/test_ieee_tc_launch.py'}")
start = source.index("before=read(RAW/'before_receipt.json')")
end = source.index("protected=p.verify_seal", start)
source = source[:start] + """failed=read(RAW/'qualification_receipt.json')
qualified=read(RAW/'qualification2_receipt.json')
after=read(RAW/'regression_receipt.json')
assert failed['passed'] is False and failed['returncode']==1
assert qualified['passed'] and after['passed'] and after['returncode']==0
assert 'Ran 363 tests' in (RAW/'regression.log').read_text()
assert re.search(r'Ran 363 tests in [0-9.]+s\\s+OK\\n', (RAW/'regression.log').read_text())
for path,sha in after['sources'].items():assert p.digest(Path(path))==sha,path
for path,sha in qualified['sources'].items():assert p.digest(Path(path))==sha,path
for phase in ('qualification','qualification2','regression'):
    receipt=read(RAW/(phase+'_receipt.json'))
    archive=RAW/(phase+'_source.tar.gz')
    assert p.digest(archive)==receipt['sources'][str(archive)]
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            assert member.isfile() and member.size<2*1024*1024
            data=tar.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest()==receipt['sources'][str(MAIN/member.name)]
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert not git('diff','HEAD','--','faaslora')
""" + source[end:]
replace("files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log')])",
        "files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log'),*RAW.glob('*_source.tar.gz')])")
replace("files += [MAIN/'faaslora/metrics/metrics_collector.py',MAIN/'tests/test_ieee_tc_gpu_lifecycle.py',\n          MAIN/'docs/ieee_tc/D541_PIDFD_EXIT_MEASUREMENT_FIX.md']",
        "files += [MAIN/'scripts/run_all_experiments.py', MAIN/'tests/test_ieee_tc_launch.py',\n          MAIN/'docs/ieee_tc/D549_INITIAL_OBSERVED_CONTROL.md', Path('" + str(template) + "')]")
replace("    assert token and token not in data",
        """    assert token and token not in data
    if data.startswith(b'\\x1f\\x8b'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as nested:
            for member in nested.getmembers():
                assert member.isfile() and member.size<2*1024*1024
                clean(nested.extractfile(member).read())""")
start = source.index("save(OUT/'summary.json',dict(")
end = source.index("with (OUT/'result.sha256')", start)
source = source[:start] + """save(OUT/'summary.json',dict(passed=True,new_gpu_performance=False,
    baseline_algorithm_changed=False,candidate_policy='observed_arrivals_v1',
    performance_qualified=False,default_enabled=False,
    first_failed_fixture=failed,qualification=qualified,full_regression=after,
    prior_checkpoint='5620e90bbad08f26817faebbfcd8af1c604ee456',
    source_sha256={str(MAIN/path):p.digest(MAIN/path) for path in sorted(changed)},
    protected=protected,preserved=preserved,scope=identity,
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz')))
""" + source[end:]
replace("'docs/ieee_tc/D541_PIDFD_EXIT_MEASUREMENT_FIX.md'", "'docs/ieee_tc/D549_INITIAL_OBSERVED_CONTROL.md'")
replace('tc: observe high-numbered pidfd exits without weakening physical release (D541)',
        'tc: qualify observed-arrival control during initial runtime activation (D549)')
exec(compile(source, str(RAW/'publish_reused.py'), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'publish.py')})
