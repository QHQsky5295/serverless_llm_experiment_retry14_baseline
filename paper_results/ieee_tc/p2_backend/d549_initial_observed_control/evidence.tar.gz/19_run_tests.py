"""D541 bounded regression receipt pattern, reused for initial control ownership."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

phase = sys.argv[1]
assert phase in ('qualification', 'qualification2', 'regression')
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
with (RAW / (phase + '_identity.json')).open('x') as f:
    json.dump(identity, f, indent=2)
assert (group / 'memory.high').read_text().strip() == str(3 * p.GIB)
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
assert (group / 'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
sources = [MAIN / name for name in ('scripts/run_all_experiments.py',
    'faaslora/coordination/autoscaler.py', 'tests/test_ieee_tc_launch.py',
    'tests/test_ieee_tc_transfer_pressure.py')]
with tarfile.open(RAW / (phase + '_source.tar.gz'), 'x:gz') as archive:
    for path in sources:
        archive.add(path, arcname=str(path.relative_to(MAIN)), recursive=False)
tests = (['tests.test_ieee_tc_launch.IEEEInitialObservedControl',
          'tests.test_ieee_tc_launch.IEEEInitialDeployment',
          'tests.test_ieee_tc_launch.IEEEActualControl',
          'tests.test_ieee_tc_launch.IEEEControlContract']
         if phase != 'regression' else ['tests.test_ieee_tc_launch',
          'tests.test_ieee_tc_cpu_frontend_integration', 'tests.test_ieee_tc_transfer_pressure'])
command = [sys.executable, '-B', '-m', 'unittest', *tests, '-v']
with (RAW / (phase + '.log')).open('x') as log:
    result = subprocess.run(command, cwd=MAIN, stdout=log, stderr=subprocess.STDOUT, timeout=180)
record = dict(passed=result.returncode == 0, phase=phase, command=command,
    returncode=result.returncode, identity=identity,
    sources={str(path): p.digest(path) for path in sources + [Path(__file__),
        RAW / (phase + '.log'), RAW / (phase + '_source.tar.gz')]},
    resources={k: (group / k).read_text() for k in ('memory.peak', 'memory.events', 'memory.swap.current')})
with (RAW / (phase + '_receipt.json')).open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record), flush=True)
assert record['passed']
