"""Reuse D541 exact-owned, recursively empty CPU scope closure."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
template = RAW.parent.parent / 'resource_measurement/d541_20261015/close.py'
source = template.read_text()
old = "('before','after','after2','publication','cleanup')"
assert source.count(old) == 1
source = source.replace(old, "('qualification','qualification2','regression','curation','backup')")
exec(compile(source, str(RAW/'close_reused.py'), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'close.py')})
