"""D363 attempt2: split tests across the actual model and OS guard interpreters."""
import ast, hashlib, json, os, pathlib, re, subprocess, sys, tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d363_file_demand_validation'
identity=p.scope_identity(p.cg_path().name);group=pathlib.Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],32*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not out.exists()
prior=json.loads((raw/'preparation_tests_receipt.json').read_text())
assert not prior['passed']
old=prior['identity'];oldgroup=pathlib.Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(oldgroup)
closed=p.stop_scope_identity(old);assert closed['released'] and not closed['hard_kill']
with (raw/'preparation_attempt1_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,cleanup=closed,reason='OS guard fixtures invoked in model interpreter lacking pidfd_send_signal; no production change'),f,indent=2)
commands=[('tests2.log',[sys.executable,'-m','unittest',
    'tests.test_ieee_tc_gpu_references','tests.test_ieee_tc_request_lifecycle',
    'tests.test_ieee_tc_preflight.ApprovedPlanIdentity','tests.test_ieee_tc_preflight.ForwardedCommandCLI',
    'tests.test_ieee_tc_preflight.IndependentNumericReference','tests.test_ieee_tc_preflight.ExistingContentIndex',
    'tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer','tests.test_ieee_tc_preflight.CapacityProbeObservation',
    'tests.test_ieee_tc_preflight.SlotContentQualification','tests.test_ieee_tc_control_profile_analysis',
    'tests.test_ieee_tc_full_control_analysis','tests.test_ieee_tc_control_receipts','-q']),
    ('os_guards1.log',['/usr/bin/python3','-m','unittest','tests.test_ieee_tc_preflight.ProtocolGates','-q']),
    ('binding1.log',[sys.executable,str(raw/'verify_prelaunch.py')])]
executed=[]
try:
    for name,command in commands:
        with (raw/name).open('x') as f:
            r=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,
                env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        executed.append(dict(log=name,command=command,returncode=r.returncode))
        r.check_returncode()
finally:
    with (raw/'preparation_tests2_receipt.json').open('x') as f:
        json.dump(dict(identity=identity,passed=len(executed)==3 and all(r['returncode']==0 for r in executed),
            commands=executed,resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}),f,indent=2)
prelaunch=json.loads((raw/'prelaunch_binding.json').read_text());assert prelaunch['passed']
for ref in prelaunch['source_references']:assert p.digest(pathlib.Path(ref['path']))==ref['sha256']
testcount=re.search(r'Ran (\d+) tests', (raw/'tests2.log').read_text())
assert testcount and int(testcount[1])>0
oscount=re.search(r'Ran (\d+) tests', (raw/'os_guards1.log').read_text())
assert oscount and int(oscount[1])>0
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count']==147 and protected['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=sorted(x for x in raw.iterdir() if x.is_file())
for path in files:
    check(path.read_bytes())
    if path.suffix=='.py':ast.parse(path.read_bytes())
    if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
out.mkdir(parents=True,exist_ok=False)
archive=out/'preparation_sources.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in files:bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    for path in files:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
refs=prelaunch['source_references'][:]
for binding in prelaunch['profile_bindings'].values():
    assert p.digest(pathlib.Path(binding['path']))==binding['sha256']
    refs.append(dict(path=binding['path'],sha256=binding['sha256']))
refs.append(dict(path=str(ROOT/'docs/ieee_tc/D363_FILE_DEMAND_VALIDATION.md'),sha256=p.digest(ROOT/'docs/ieee_tc/D363_FILE_DEMAND_VALIDATION.md')))
record=dict(passed=True,tests=int(testcount[1]),os_guard_tests=int(oscount[1]),native_environment=True,gpu_runs=0,
    formal_qualification=False,n_correct=None,sole_candidate='protected_file_owner_turn_v1',
    protected=protected,gate=gate,refs=refs,
    raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in files],
    archive=dict(sha256=p.digest(archive),bytes=archive.stat().st_size),identity=identity)
with (out/'preparation.json').open('x') as f:json.dump(record,f,indent=2)
with (out/'preparation.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.name!='preparation.sha256':f.write(p.digest(path)+'  '+path.name+'\n')
with (raw/'preparation_scope.json').open('x') as f:json.dump(dict(passed=True,identity=identity),f,indent=2)
names=['configs/ieee_tc/20261009_d363_7b_file_demand_validation_100.yaml',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    'docs/ieee_tc/D363_FILE_DEMAND_VALIDATION.md','docs/ieee_tc/EXECUTION_STATUS.md']
names.extend(str(x.relative_to(ROOT)) for x in sorted(out.iterdir()) if x.is_file())
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['bash','-n','scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'],cwd=ROOT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['sha256sum','-c','preparation.sha256'],cwd=out,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
print(json.dumps(dict(passed=True,tests=int(testcount[1]),paths=len(names),identity=identity)),flush=True)
