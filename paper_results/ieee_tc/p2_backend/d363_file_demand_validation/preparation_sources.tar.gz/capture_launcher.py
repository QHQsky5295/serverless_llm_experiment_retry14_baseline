"""Record the live launcher identity before later exact-owned closure."""
import json,pathlib,re,sys
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
matches=re.findall(r'Running scope as unit: (primelora-tc-aux-[0-9a-f]{32}\.scope)',(raw/'7b_file_demand_validation_100/launcher.log').read_text())
assert len(matches)==1
identity=p.scope_identity(matches[0]);assert p.scope_still_owned(identity)
with (raw/'launcher_identity.json').open('x') as f:json.dump(identity,f,indent=2)
print(json.dumps(identity),flush=True)
