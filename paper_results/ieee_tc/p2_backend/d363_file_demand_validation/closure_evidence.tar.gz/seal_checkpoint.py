"""Reuse completed-run evidence sealing; no inference or remote mutation."""
import ast, hashlib, json, os, pathlib, re, subprocess, sys, tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d363_file_demand_validation'
identity=p.scope_identity(p.cg_path().name);group=pathlib.Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],4*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
offline=json.loads((raw/'offline_execution_receipt.json').read_text())
assert offline['pass_all'] and offline['returncodes']==[0,0]
assert 'Ran 62 tests' in (raw/'audit1.log').read_text()
old=offline['identity'];oldgroup=pathlib.Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(oldgroup)
closed=p.stop_scope_identity(old);assert closed['released'] and not closed['hard_kill']
with (raw/'analysis_cleanup.json').open('x') as f:json.dump(dict(identity=old,cleanup=closed),f,indent=2)
audit=json.loads((out/'smoke1/audit.json').read_text())
assert audit['stats']['completed']==100 and audit['candidate_trigger_gate_passed']
assert audit['file_demand_transaction_trigger']['requests']==100
assert audit['file_demand_transaction_trigger']['file_transactions']==35
assert audit['n_correct'] is None and not audit['full_qualified']
for ref in audit['raw_evidence']:assert p.digest(pathlib.Path(ref['path']))==ref['sha256']
collection=json.loads((raw/'collection_receipt.json').read_text())
assert collection['source_sha256']==p.digest(pathlib.Path(collection['source_path']))=='4228717a06b169ce308d8241e967513dbda6424e7bb2fa6d1b1b796f42a442ff'
execution=json.loads((raw/'launch_gate.json').read_text())['head']
assert execution=='a5a2355beb8747d0efe2c4b550e998a39c165a7c'
assert json.loads((raw/'remote_stop.json').read_text())['all_owned_units_inactive']
for ref in json.loads((out/'preparation.json').read_text())['refs']:
    assert p.digest(pathlib.Path(ref['path']))==ref['sha256']
subprocess.run(['sha256sum','-c','preparation.sha256'],cwd=out,check=True)
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count']==147 and protected['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=sorted(x for x in raw.iterdir() if x.is_file())
run=raw/'7b_file_demand_validation_100'
files.extend([run/'launch.json',run/'launcher.log',run/'launch.launch/service.log',run/'launch.launch/watchdog.jsonl'])
archive=out/'closure_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in files:
        check(path.read_bytes())
        if path.suffix=='.py':ast.parse(path.read_bytes())
        if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
        bundle.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive) as bundle:
    assert len(bundle.getmembers())==len(files)
    for path in files:assert hashlib.sha256(bundle.extractfile(str(path.relative_to(raw))).read()).hexdigest()==p.digest(path)
record=dict(passed=True,execution_commit=execution,source_sha256=collection['source_sha256'],
    source_path=collection['source_path'],source_bytes=collection['source_bytes'],
    postrelease_cpu_tests=62,n_correct=None,full_qualified=False,protected=protected,
    archive=dict(sha256=p.digest(archive),bytes=archive.stat().st_size,members=len(files)),
    raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in files],
    next='D364 unchanged Full4000, compare D358/D353/D336; retain prefix regressions',
    stats=audit['stats'],file_demand=audit['file_demand_transaction_trigger'])
with (out/'closure_checkpoint.json').open('x') as f:json.dump(record,f,indent=2)
with (out/'closure.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='closure.sha256':f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
names=['scripts/ieee_tc/analyze_d298_smoke.py','tests/test_ieee_tc_full_control_analysis.py',
    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D363_COMPLETE_PREFIX_DECISION.md']
names.extend(str(x.relative_to(ROOT)) for x in sorted(out.rglob('*')) if x.is_file()
    and not subprocess.check_output(['git','ls-files','--',str(x.relative_to(ROOT))],cwd=ROOT,text=True).strip())
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['sha256sum','-c','closure.sha256'],cwd=out,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (raw/'seal_receipt.json').open('x') as f:
    json.dump(dict(passed=True,identity=identity,paths=names,resources={k:(group/k).read_text() for k in
        ('memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(passed=True,paths=len(names),archive_bytes=archive.stat().st_size,identity=identity)),flush=True)
