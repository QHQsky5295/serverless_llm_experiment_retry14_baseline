"""Reuse D824 explicit-path backup; include only the two qualified code files."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d824_20261025/backup.py')
code = source.read_text()
changes = {
    'd824_current_ingress_pending': 'd828_post_file_owner_turn',
    '107185c45f49a891c0b391b1140b7d765e83daea': '50bcf270522a75845eb0187139037ed36157827f',
    "OUT/'final_manifest.json'": "OUT/'manifest.json'",
    'D824_CURRENT_INGRESS_AND_CONTROL_20261025.md': 'D828_POST_FILE_OWNER_TURN_20261025.md',
    "ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',": "ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',\n         ROOT/'scripts/run_all_experiments.py', ROOT/'tests/test_ieee_tc_request_lifecycle.py',",
    'len(set(paths)) == 20': 'len(set(paths)) == 9',
    'backup/d824-current-ingress-control-20261025': 'backup/d828-admitted-owner-anchor-20261025',
    'tc: preserve current 3B ingress and actual scaling-trigger diagnosis (D824)':
        'tc: reuse admitted owner identity for protected file demand (D828)',
}
for old, new in changes.items():
    assert code.count(old) == 1, old
    code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
