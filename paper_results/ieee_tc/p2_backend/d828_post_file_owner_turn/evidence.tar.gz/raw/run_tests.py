"""Adapt D610's bounded, per-module qualification to the admitted-file path."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d610_20261017/run_tests.py')
code = source.read_text()
old = "'faaslora/memory/residency_manager.py',\n    'tests/test_ieee_tc_file_observation.py',\n    'tests/test_ieee_tc_request_lifecycle.py'"
new = "'scripts/run_all_experiments.py', 'faaslora/memory/residency_manager.py',\n    'tests/test_ieee_tc_gpu_references.py', 'tests/test_ieee_tc_request_lifecycle.py'"
assert code.count(old) == 1
code = code.replace(old, new)
old = "tests=(['tests.test_ieee_tc_file_observation']\n    if phase=='focused' else ['tests.test_ieee_tc_request_lifecycle',\n    'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_static_preparation'])"
new = "tests=(['tests.test_ieee_tc_request_lifecycle.SelectedSourceAdmissionIntegration',\n    'tests.test_ieee_tc_gpu_references.ProtectedFileDemandTransactions']\n    if phase=='focused' else ['tests.test_ieee_tc_request_lifecycle',\n    'tests.test_ieee_tc_gpu_references'])"
assert code.count(old) == 1
code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
