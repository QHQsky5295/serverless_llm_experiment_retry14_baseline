"""Extend D826/D594 same-clock decomposition; no new inference or synthetic latency."""
import csv
import gzip
import json
import os
import subprocess
import sys
from pathlib import Path
import ijson

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OLD = ROOT/'paper_results/ieee_tc/p2_backend/d826_3b_single_verification_full_w2/preparation_analysis'
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d828_post_file_owner_turn'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats

def read(path):
    return json.loads(path.read_text())
def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
def ref(path):
    return dict(path=str(path), sha256=p.digest(path), bytes=path.stat().st_size)

identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
save(RAW/'analysis_identity.json', identity)
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 1024*1024)
save(RAW/'resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
seal = RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json'
assert p.verify_seal(seal)['pass']
prior = read(RAW.parent/'d827_20261025/backup_identity.json')
assert not Path(prior['path']).exists()
sources = read(OLD/'pressure_diagnosis.json')['source_refs']
for name, digest in sources.items():
    assert p.digest(Path(name)) == digest
outcome = next(Path(name) for name in sources if name.endswith('main_outcome.json.gz'))
requests = next(Path(name) for name in sources if Path(name).name.startswith('experiment_results_'))
with (OLD/'pressure_requests.csv').open() as handle:
    cohort = {row['request_id']: row for row in csv.DictReader(handle)}
assert len(cohort) == 498
with gzip.open(outcome, 'rb') as handle:
    pressure = {row['transfer_id']: row for row in ijson.items(handle, 'transfer_pressure.item', use_float=True)
                if row['source_tier'] == 'remote'}
rows = []
with gzip.open(requests, 'rb') as handle:
    for request in ijson.items(handle, 'detailed_results.tc_ieee_full.requests.item', use_float=True):
        key = request['request_id']
        if key not in cohort:
            continue
        previous = cohort[key]
        record = pressure[previous['pressure_id']]
        evidence = request['gpu_reference_evidence']
        snapshot = evidence['snapshot_before_acquisition']
        receipt = evidence['receipt']
        proof = receipt['file_demand_transaction']
        assert snapshot['acquisition_observation_scope'] == 'native_identity_only_v1'
        assert snapshot['owner_id'] == receipt['owner_id']
        assert snapshot['clock_id'] == receipt['clock_id'] == record['clock_id']
        assert proof['observed_epoch'] == snapshot['epoch']
        assert proof['validated_epoch'] >= proof['observed_epoch']
        assert proof['live_native_constraints_checked'] and not proof['controller_capacity_snapshot_reused']
        assert receipt['file_source_witness']['lease_id'] == evidence['local_source_reference']['lease_id']
        finish = [member['finish_receipt']['observed_at'] for member in record['participants'].values()]
        assert finish and all(member['state'] == 'finished' for member in record['participants'].values())
        joined, first, last, end, captured, load = (
            record['io_joined_at'], min(finish), max(finish), record['finished_at'],
            snapshot['captured_monotonic_s'], receipt['native_load_started_monotonic_s'])
        assert joined <= first <= last <= end <= captured <= load
        row = dict(request_id=key, ordinal=int(previous['ordinal']),
            adapter_id=request['adapter_id'], ttft_pass=previous['ttft_pass'] == 'True',
            participants=len(finish),
            io_join_to_first_native_finish_ms=1000*(first-joined),
            first_to_last_native_finish_ms=1000*(last-first),
            last_native_finish_to_controller_finish_ms=1000*(end-last),
            controller_finish_to_identity_capture_ms=1000*(captured-end),
            identity_capture_to_native_load_ms=1000*(load-captured),
            identity_rpc_channel_ms=snapshot['timing']['parent_rpc_channel_acquire_ms'],
            identity_rpc_send_ms=snapshot['timing']['parent_rpc_send_flush_ms'],
            identity_rpc_wait_ms=snapshot['timing']['parent_rpc_wait_response_ms'],
            identity_epoch=snapshot['epoch'], validated_epoch=proof['validated_epoch'],
            selected_native_copy_present=snapshot['selected_source_identity'] is not None)
        assert abs(sum(row[name] for name in (
            'io_join_to_first_native_finish_ms', 'first_to_last_native_finish_ms',
            'last_native_finish_to_controller_finish_ms')) - float(previous['pressure_finish_ms'])) < 1e-5
        assert abs(row['controller_finish_to_identity_capture_ms'] + row['identity_capture_to_native_load_ms']
            - float(previous['after_pressure_finish_to_load_ms'])) < 1e-5
        rows.append(row)
assert {row['request_id'] for row in rows} == set(cohort)
assert not OUT.exists()
OUT.mkdir(parents=True)
with (OUT/'requests.csv').open('x') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
def summarize(selected):
    return dict(n=len(selected), metrics={name: timing_stats([row[name] for row in selected])
        for name in rows[0] if name.endswith('_ms')},
        native_copy_present=sum(row['selected_native_copy_present'] for row in selected),
        epoch_advanced=sum(row['validated_epoch'] > row['identity_epoch'] for row in selected))
report = dict(passed=True, full_denominator_unchanged=4000, matched_remote_cohort=498,
    groups={name: summarize(subset) for name, subset in (
        ('all', rows), ('ttft_fail', [row for row in rows if not row['ttft_pass']]))},
    new_gpu_replays=0, n_correct=None, ranking_eligible=False,
    caveats=['Observed native finish is a same-clock transition, not start of the RPC or CPU time.',
        'Receipt round-trip totals and capture intervals overlap; do not add them.',
        'No counterfactual SLO, no latency subtraction, no causal speedup claim.',
        'All 498 previously matched requests retained; other 15 selected-Remote remain in original 4000 denominator.'],
    source_refs=[ref(path) for path in (outcome, requests, OLD/'pressure_requests.csv',
        OLD/'pressure_diagnosis.json', Path(__file__))])
save(OUT/'summary.json', report)
protected = p.verify_seal(seal)
assert protected['pass']
save(RAW/'analysis_receipt.json', dict(passed=True, scope=identity, protected=protected,
    resources={name: (group/name).read_text().strip() for name in
        ('memory.peak', 'memory.events', 'memory.swap.current')},
    disk_free_bytes=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize))
print(json.dumps(report['groups'], indent=2))
