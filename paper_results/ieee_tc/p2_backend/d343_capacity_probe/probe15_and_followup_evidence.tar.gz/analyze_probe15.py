"""Retain the failed C15 native initialization and prepare one measured followup."""
import json, pathlib, subprocess, sys, unittest
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

def main():
    raw=pathlib.Path(__file__).resolve().parent
    out=ROOT/'paper_results/ieee_tc/p2_backend/d343_capacity_probe'
    unit='primelora-tc-aux-34300000000000000000000000000008.scope'
    identity=p.scope_identity(unit); group=pathlib.Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    closure={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    with (raw/'collection_cleanup.json').open('x') as f:
        json.dump(dict(identity=identity,resources=closure,inactive=True),f,indent=2)
    run=json.loads((raw/'source1.json').read_text())
    launch=json.loads((raw/'source1_launch.json').read_text())
    assert not run['pass'] and not run['requests'] and launch['native_gpu_context_release_confirmed']
    assert launch['service_path_removed'] and run['profile_workspaces_removed']
    assert json.loads((raw/'remote_stop.json').read_text())['all_owned_units_inactive']
    obs=run['profile_waves'][0]['capacity_before']
    try:
        p.validate_capacity_probe_observation(obs,run['model_config'],run['source_profile_spec']['capacity_probe_contract'])
    except ValueError as exc:
        guard_error=str(exc)
        assert guard_error=='capacity probe insufficient measured KV: 942 < 960'
    else: raise AssertionError('C15 must still fail after schema correction')
    remote=[json.loads(line) for line in (raw/'remote_transfers.jsonl').read_text().splitlines()]
    byid={r['transfer_id']:r for r in remote}
    assert len(byid)==len(remote)==len(run['remote_transfers'])==15
    for local in run['remote_transfers']:
        r=byid[local['http_transfer_id']]
        assert not r['pack_performed'] and not local['remote_pack_performed']
        assert r['bytes_written']==local['transferred_bytes']==r['archive_bytes']
        assert r['archive_sha256']==local['remote_archive_sha256']
    samples=[]
    for line in (raw/'source1_launch.launch/watchdog.jsonl').open():
        row=json.loads(line)
        if row.get('event')=='resource_sample': samples.append(row)
    assert samples
    peak=max(r['service']['memory.peak'] for r in samples)
    events={k:max(r['service']['memory.events'][k] for r in samples)
        for k in ('high','max','oom','oom_kill')}
    assert not any(events.values())
    assert max(r['service']['memory.swap.current'] for r in samples)==0
    physical=run['physical_allocation']
    assert physical['released'] and len(physical['gpu_uuids'])==1
    intervals={r['event']:r['at'] for r in physical['events']}
    summary=dict(kind='d343_c15_native_probe_rejected_v1',n_plan=84,n_submitted=0,
        native_inference_calls=0,full_qualified=False,n_correct=None,
        measured_free_KV_blocks=obs['kv_unreserved_free_blocks'],needed_blocks=960,
        original_guard_error=run['error'], corrected_guard_error=guard_error,
        native_unretired_iterations=obs['unretired_iterations'],
        startup_latency_ms=run['startup_latency_ms'],
        physical_GPU_seconds=intervals['release']-intervals['acquire'],
        remote_fetches=len(remote),wire_bytes=sum(r['bytes_written'] for r in remote),request_packing=0,
        service_memory_peak_bytes=peak,memory_events=events,service_swap_bytes=0,
        host_available_min_bytes=min(r['host']['available_bytes'] for r in samples),
        physical_release_verified=True,remote_stopped_verified=True,
        decision='C15 rejected for all-max-context probe; one explicit C14 followup from floor(942/64)',
        sources=[dict(path=str(raw/n),sha256=p.digest(raw/n)) for n in
            ('source1.json','source1_launch.json','remote_transfers.jsonl','remote_stop.json','local_cleanup.json')])
    with (out/'probe15_result.json').open('x') as f: json.dump(summary,f,indent=2)
    names=['tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer',
        'tests.test_ieee_tc_preflight.CapacityProbeObservation','tests.test_ieee_tc_warm_reference',
        'tests.test_ieee_tc_launch.SourceProfileDomainCoverage','tests.test_ieee_tc_launch.MeasuredSourceProfileExport']
    with (raw/'cpu_followup.log').open('x') as f:
        result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
    assert result.wasSuccessful()
    from scripts.ieee_tc.prepare_d298_capacity import prepare_capacity_probe
    prepare_capacity_probe(followup=True)
    with (raw/'probe15_analysis_receipt.json').open('x') as f:
        json.dump(dict(passed=True,tests=result.testsRun,identity=p.scope_identity(p.cg_path().name)),f,indent=2)
    print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
