"""Seal C15 rejection, corrected guard tests and the separate C14 followup."""
import ast,json,pathlib,re,subprocess,sys,tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d343_capacity_probe'
record=json.loads((raw/'probe15_analysis_receipt.json').read_text());assert record['passed']
identity=record['identity'];group=pathlib.Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
with (raw/'probe15_analysis_cleanup.json').open('x') as f:json.dump(dict(identity=identity,resources=resources),f,indent=2)
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(b):
    assert token and token not in b
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',b)
paths=[raw/n for n in ('source1.json','source1_launch.json','remote_stop.json','local_cleanup.json',
    'remote_transfers.jsonl','remote_monitor.log','remote_start.log','remote_stop.log','remote_health.json',
    'collect_closure.py','analyze_probe15.py','checkpoint_followup.py','collection_cleanup.json',
    'probe15_analysis_receipt.json','probe15_analysis_cleanup.json','cpu_followup.log','probe15_analysis.log')]
paths += [raw/'cap14'/n for n in ('start_remote.sh','stop_remote.sh','check_remote_health.py')]
archive=out/'probe15_and_followup_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as t:
    for path in paths:
        check(path.read_bytes())
        if path.suffix=='.py':ast.parse(path.read_bytes())
        t.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for path in paths:assert t.extractfile(str(path.relative_to(raw))).read()==path.read_bytes()
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count']==147 and seal['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
names=['scripts/ieee_tc_preflight.py','scripts/ieee_tc/prepare_d298_capacity.py','scripts/ieee_tc/run_d298_capacity_source.sh',
    'tests/test_ieee_tc_preflight.py','configs/ieee_tc/20261008_d343_7b_capacity_probe14.yaml',
    'docs/ieee_tc/D343_NATIVE_CAPACITY_PROBE.md','docs/ieee_tc/EXECUTION_STATUS.md',
    str((out/'probe15_result.json').relative_to(ROOT)),str(archive.relative_to(ROOT)),
    str((out/'cap14/prepare.json').relative_to(ROOT)),str((out/'cap14/source_spec.json').relative_to(ROOT))]
with (out/'followup.sha256').open('x') as f:
    for name in names:
        check((ROOT/name).read_bytes());f.write(p.digest(ROOT/name)+'  '+name+'\n')
names.append(str((out/'followup.sha256').relative_to(ROOT)))
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['sha256sum','-c',str(out/'followup.sha256')],cwd=ROOT,check=True)
subprocess.run(['sha256sum','-c','preparation.sha256'],cwd=out,check=True)
with (raw/'followup_checkpoint_receipt.json').open('x') as f:
    json.dump(dict(passed=True,tests=record['tests'],paths=names,identity=p.scope_identity(p.cg_path().name),
        protection=seal,closed_analysis_resources=resources),f,indent=2)
print(json.dumps(dict(passed=True,paths=len(names),tests=record['tests'])),flush=True)
