"""Seal tested D343 preparation, stage only explicit paths, no inference."""
import ast, json, pathlib, re, subprocess, sys, tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d343_capacity_probe'
tests=json.loads((raw/'cpu_tests2.json').read_text())
assert tests['successful'] and not tests['failures'] and not tests['errors']
identity=tests['identity']; group=pathlib.Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
assert all(int(v)==0 for _,v in (line.split() for line in resources['memory.events'].splitlines()))
assert int(resources['memory.swap.current'])==0
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
with (raw/'cpu_tests2_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,closed=True),f,indent=2)
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count']==147 and seal['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
raw_paths=[raw/n for n in ('validate.py','validate2.py','checkpoint.py','cpu_tests.log',
    'cpu_tests2.log','cpu_tests2_stdout.log','cpu_tests2.json','cpu_tests2_cleanup.json',
    'cpu_attempt1_failure.json','preparation_scopes_cleanup.json','start_remote.sh',
    'stop_remote.sh','check_remote_health.py')]
archive=out/'preparation_evidence.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f,mode='w:gz') as t:
    for path in raw_paths:
        data=path.read_bytes(); check(data)
        if path.suffix=='.py': ast.parse(data)
        if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
        t.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
    for path in raw_paths: assert t.extractfile(path.name).read()==path.read_bytes()
with (out/'checkpoint.json').open('x') as f:
    json.dump(dict(kind='d343_preparation_checkpoint_v1',gpu_runs=0,tests=tests,
        resources=resources,protection=seal,prior_cpu_driver_failure_retained=True,
        archive_sha256=p.digest(archive),no_figures=True,formal_qualification=False,
        raw_sources=[dict(path=str(x),sha256=p.digest(x)) for x in raw_paths]),f,indent=2)
with (out/'preparation.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.is_file() and path.name!='preparation.sha256':
            f.write(p.digest(path)+'  '+path.name+'\n')
names=['scripts/ieee_tc_preflight.py','scripts/ieee_tc/prepare_d298_capacity.py',
    'scripts/ieee_tc/run_d298_capacity_source.sh','tests/test_ieee_tc_preflight.py',
    'configs/ieee_tc/20261008_d343_7b_capacity_probe.yaml',
    'docs/ieee_tc/D343_NATIVE_CAPACITY_PROBE.md','docs/ieee_tc/EXECUTION_STATUS.md']
names += [str(x.relative_to(ROOT)) for x in sorted(out.iterdir()) if x.is_file()]
for name in names:
    data=(ROOT/name).read_bytes(); check(data)
    if name.endswith('.py'): ast.parse(data)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['sha256sum','-c','preparation.sha256'],cwd=out,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(names)
assert 'configs/generated/lora_manifest_1000.json' not in staged
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (raw/'checkpoint_receipt.json').open('x') as f:
    json.dump(dict(passed=True,paths=staged,identity=p.scope_identity(p.cg_path().name)),f,indent=2)
print(json.dumps(dict(passed=True,paths=len(staged),tests=tests['tests'])),flush=True)
