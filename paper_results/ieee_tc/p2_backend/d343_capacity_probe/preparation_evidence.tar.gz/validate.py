"""Bounded D343 regression and exact prior auxiliary-scope closure."""
import json, pathlib, subprocess, sys, unittest
ROOT = pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
raw = pathlib.Path(__file__).resolve().parent
closed = []
for i in range(1,5):
    unit = f'primelora-tc-aux-{343:03d}{i:029d}.scope'
    identity = p.scope_identity(unit)
    group = pathlib.Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    values = {k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    assert all(int(v)==0 for _,v in (line.split() for line in values['memory.events'].splitlines()))
    assert int(values['memory.swap.current']) == 0
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    closed.append(dict(identity=identity,resources=values,inactive=True))
with (raw/'preparation_scopes_cleanup.json').open('x') as f: json.dump(closed,f,indent=2)
names = ['tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer',
         'tests.test_ieee_tc_preflight.CapacityProbeObservation',
         'tests.test_ieee_tc_warm_reference',
         'tests.test_ieee_tc_request_lifecycle',
         'tests.test_ieee_tc_launch']
with (raw/'cpu_tests.log').open('x') as f:
    result = unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
record = dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
              successful=result.wasSuccessful(),gpu_runs=0,
              identity=p.scope_identity(p.cg_path().name))
with (raw/'cpu_tests.json').open('x') as f: json.dump(record,f,indent=2)
print(json.dumps(record),flush=True)
assert result.wasSuccessful()
