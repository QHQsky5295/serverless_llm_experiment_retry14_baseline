"""Repeat CPU regression with a spawn-safe driver; failed first driver retained."""
import json, pathlib, subprocess, sys, unittest
ROOT = pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

def main():
    raw = pathlib.Path(__file__).resolve().parent
    unit = 'primelora-tc-aux-34300000000000000000000000000005.scope'
    identity = p.scope_identity(unit)
    group = pathlib.Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    values = {k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    with (raw/'cpu_attempt1_failure.json').open('x') as f:
        json.dump(dict(driver='validate.py',reason='missing main guard reran cleanup in spawned child; parent interrupted at waiting fixture',
            unit=identity,resources=values,gpu_runs=0,system_code_failure=False),f,indent=2)
    names = ['tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer',
             'tests.test_ieee_tc_preflight.CapacityProbeObservation',
             'tests.test_ieee_tc_warm_reference',
             'tests.test_ieee_tc_request_lifecycle',
             'tests.test_ieee_tc_launch']
    with (raw/'cpu_tests2.log').open('x') as f:
        result = unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
    record = dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        successful=result.wasSuccessful(),gpu_runs=0,identity=p.scope_identity(p.cg_path().name))
    with (raw/'cpu_tests2.json').open('x') as f: json.dump(record,f,indent=2)
    print(json.dumps(record),flush=True)
    assert result.wasSuccessful()

if __name__ == '__main__':
    main()
