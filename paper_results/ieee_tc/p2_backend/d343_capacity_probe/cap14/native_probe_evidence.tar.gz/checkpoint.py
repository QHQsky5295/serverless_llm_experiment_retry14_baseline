"""Seal the completed C14 diagnostic and its limitations; no inference."""
import ast,hashlib,json,pathlib,re,subprocess,sys,tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d343_capacity_probe/cap14'
record=json.loads((raw/'analysis_receipt.json').read_text());assert record['passed']
identity=record['identity'];group=pathlib.Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
values={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
assert int(values['memory.swap.current'])==0
assert all(int(v)==0 for _,v in (line.split() for line in values['memory.events'].splitlines()))
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
with (raw/'analysis_cleanup.json').open('x') as f:json.dump(dict(identity=identity,resources=values,inactive=True),f,indent=2)
manifest=json.loads((out/'analysis1/manifest.json').read_text())
for name,digest in manifest['output_sha256'].items():assert p.digest(out/'analysis1'/name)==digest
for ref in manifest['source_refs']:assert p.digest(pathlib.Path(ref['path']))==ref['sha256']
assert p.check_plan()==manifest['plan_sha256']=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')==manifest['metric_protocol_sha256']=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','scripts','faaslora','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
# Prior checkpoint SHA list is a historical byte snapshot, not a moving-file seal.
prior='9a4968dcee02febb590630ba8b8a9e189c4de83d'
for line in (out.parent/'followup.sha256').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert hashlib.sha256(subprocess.check_output(['git','show',prior+':'+name],cwd=ROOT)).hexdigest()==digest
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
paths=[raw/n for n in ('source1.json','source1_launch.json','remote_start.log','remote_stop.log',
    'remote_stop.json','remote_health.json','remote_transfers.jsonl','remote_monitor.log','local_cleanup.json',
    'analyze.py','analysis.log','analysis_receipt.json','analysis_cleanup.json','collect_closure.py',
    'start_remote.sh','stop_remote.sh','check_remote_health.py','launch_gate.py','launch_gate.json','checkpoint.py')]
paths += [raw/'source1_launch.launch'/n for n in ('service.log','watchdog.jsonl')]
archive=out/'native_probe_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        check(path.read_bytes())
        if path.suffix=='.py':ast.parse(path.read_bytes())
        tar.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in paths:assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw))).read()).hexdigest()==p.digest(path)
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count']==147 and seal['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
with (out/'completion_checkpoint.json').open('x') as f:
    json.dump(dict(kind='d343_completed_capacity_checkpoint_v1',passed=True,formal_qualified=False,
        source_code_commit=prior,archive_sha256=p.digest(archive),archive_bytes=archive.stat().st_size,
        analysis_resources=values,protection=seal,previous_checkpoint_byte_identity_verified=prior,
        raw_sources=[dict(path=str(x),sha256=p.digest(x)) for x in paths]),f,indent=2)
with (out/'completed_outputs.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='completed_outputs.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
names=['docs/ieee_tc/D343_NATIVE_CAPACITY_PROBE.md','docs/ieee_tc/EXECUTION_STATUS.md']
names += [str(x.relative_to(ROOT)) for x in sorted((out/'analysis1').iterdir()) if x.is_file()]
names += [str((out/n).relative_to(ROOT)) for n in ('native_probe_evidence.tar.gz','completion_checkpoint.json','completed_outputs.sha256')]
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['sha256sum','-c','completed_outputs.sha256'],cwd=out,check=True)
with (raw/'checkpoint_receipt.json').open('x') as f:
    json.dump(dict(passed=True,identity=p.scope_identity(p.cg_path().name),paths=names),f,indent=2)
print(json.dumps(dict(passed=True,paths=len(names),archive_bytes=archive.stat().st_size)),flush=True)
