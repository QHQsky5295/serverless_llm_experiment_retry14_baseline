"""Reuse native source validators; summarize this diagnostic, not a Full run."""
import csv,json,pathlib,statistics,subprocess,sys
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.export_d298_profiles import completed_gap_samples
from faaslora.datasets.workload_generator import FrozenReplayPlan

def main():
    raw=pathlib.Path(__file__).resolve().parent
    out=ROOT/'paper_results/ieee_tc/p2_backend/d343_capacity_probe/cap14/analysis1'
    assert not out.exists()
    run=json.loads((raw/'source1.json').read_text())
    launch=json.loads((raw/'source1_launch.json').read_text())
    assert run['pass'] and run['stage']=='complete'
    assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
    assert json.loads((raw/'remote_stop.json').read_text())['all_owned_units_inactive']
    assert len(run['requests'])==80 and run['profile_workspaces_removed']
    specpath=ROOT/'paper_results/ieee_tc/p2_backend/d343_capacity_probe/cap14/source_spec.json'
    assert p.digest(specpath)==run['source_profile_spec_sha256']
    trace=FrozenReplayPlan.load(pathlib.Path(run['trace']['source_path']),count=1000)
    _,_,identities,_,_=p.source_profile_inputs(specpath,trace,run['model_config'],
        (ROOT/'artifacts/frozen/llama2_7b_a500_v2_publicmix').resolve(strict=True))
    samples,coverage=completed_gap_samples(run,source_sha=p.digest(raw/'source1.json'),identities=identities)
    assert len(samples)==66 and not coverage['class_domain_covered']
    # Probe is intentionally GPU-only; never export it as a complete Full profile.
    byid={q['request_id']:q for q in run['requests']}
    rows=[]; waves=[]
    for i,(planned,actual) in enumerate(zip(run['source_profile_spec']['waves'],run['profile_waves'],strict=True)):
        guards=[p.validate_capacity_probe_observation(actual[k],run['model_config'],
            run['source_profile_spec']['capacity_probe_contract']) for k in ('capacity_before','capacity_after')]
        assert actual['complete']
        cases=[byid[f'source-profile/w{i}/l{j}'] for j in range(len(planned['requests']))]
        events=[]; selected=[]
        for q in cases:
            t=q['timing'];d=t['native_dispatch_monotonic_s'];f=q['first_token_monotonic_s'];z=q['last_token_monotonic_s']
            n=q['actual_tokens'];assert n==q['target_tokens'] and n>=2 and d<=f<=z
            assert abs((z-f)*1000/(n-1)-t['native_tpot_ms'])<=1
            row=dict(wave=i,role=planned['role'],round=planned['round'],wave_size=len(cases),
                request_id=q['request_id'],source_request_id=q['source_request_id'],adapter_id=q['adapter_id'],
                native_prompt_tokens=t['actual_prompt_tokens'],output_tokens=n,
                native_ttft_ms=(f-d)*1000,native_tpot_ms=(z-f)*1000/(n-1),
                admission_to_first_ms=(f-q['admitted_monotonic_s'])*1000,
                dispatch_monotonic_s=d,first_monotonic_s=f,last_monotonic_s=z,
                output_sha256=t['completion_token_ids_sha256'])
            rows.append(row);selected.append(row);events.extend(((d,1),(z,-1)))
        active=peak=0
        for _,delta in sorted(events):active+=delta;peak=max(peak,active)
        assert active==0
        makespan=max(r['last_monotonic_s'] for r in selected)-min(r['dispatch_monotonic_s'] for r in selected)
        waves.append(dict(wave=i,role=planned['role'],round=planned['round'],requests=len(cases),
            kv_free_before=guards[0]['measured_free_blocks'],kv_free_after=guards[1]['measured_free_blocks'],
            kv_required=guards[0]['needed_blocks'],peak_native_dispatch_to_last_overlap=peak,
            all_decode_intersection_s=max(0,min(r['last_monotonic_s'] for r in selected)-max(r['first_monotonic_s'] for r in selected)),
            mean_native_ttft_ms=statistics.mean(r['native_ttft_ms'] for r in selected),
            mean_native_tpot_ms=statistics.mean(r['native_tpot_ms'] for r in selected),
            native_wave_makespan_s=makespan,native_wave_output_tokens=sum(r['output_tokens'] for r in selected),
            native_wave_output_tokens_per_s=sum(r['output_tokens'] for r in selected)/makespan))
    pairs=[]
    for r in range(3):
        small={x['source_request_id']:x for x in rows if x['round']==r and x['wave_size']==8}
        large={x['source_request_id']:x for x in rows if x['round']==r and x['wave_size']==14}
        assert len(small)==8 and len(large)==14 and small.keys()<=large.keys()
        pairs.append(dict(round=r,common_requests=8,
            mean_common8_ttft_ms=statistics.mean(x['native_ttft_ms'] for x in small.values()),
            mean_common14_ttft_ms=statistics.mean(large[k]['native_ttft_ms'] for k in small),
            mean_common8_tpot_ms=statistics.mean(x['native_tpot_ms'] for x in small.values()),
            mean_common14_tpot_ms=statistics.mean(large[k]['native_tpot_ms'] for k in small),
            output_sha_changes=sum(small[k]['output_sha256']!=large[k]['output_sha256'] for k in small)))
    remote=[json.loads(x) for x in (raw/'remote_transfers.jsonl').read_text().splitlines()]
    bytransfer={x['transfer_id']:x for x in remote}
    assert len(bytransfer)==len(remote)==len(run['remote_transfers'])
    for x in run['remote_transfers']:
        server=bytransfer[x['http_transfer_id']]
        assert server['bytes_written']==x['transferred_bytes']==server['archive_bytes']
        assert server['archive_sha256']==x['remote_archive_sha256']
        assert not server['pack_performed'] and not x['remote_pack_performed']
    monitors=[]
    for line in (raw/'source1_launch.launch/watchdog.jsonl').open():
        x=json.loads(line)
        if x.get('event')=='resource_sample':monitors.append(x)
    events={k:max(x['service']['memory.events'][k] for x in monitors) for k in ('high','max','oom','oom_kill')}
    assert not any(events.values()) and max(x['service']['memory.swap.current'] for x in monitors)==0
    life={e['event']:e['at'] for e in run['physical_allocation']['events']}
    assert run['physical_allocation']['released'] and len(run['physical_allocation']['gpu_uuids'])==1
    summary=dict(kind='d343_c14_capacity_diagnostic_v1',completed_native_calls=80,measured_calls=66,
        n_correct=None,formal_SLO_qualified=False,full_profile_coverage=False,full_qualified=False,
        native_runtime_capacity=14,unchanged_warm_reference_batch=8,
        waves=waves,common_request_pairs=pairs,
        physical_GPU_seconds=life['release']-life['acquire'],startup_latency_ms=run['startup_latency_ms'],
        remote_fetches=len(remote),wire_bytes=sum(x['bytes_written'] for x in remote),request_packing=0,
        service_memory_peak_bytes=max(x['service']['memory.peak'] for x in monitors),memory_events=events,
        host_available_min_bytes=min(x['host']['available_bytes'] for x in monitors),
        limitations=['Three within-process waves are not independent run replicates; no t-CI.',
            'Same C14 runtime with8/14stress cases; not C8/C14Full causality or SLO calibration.',
            'Native overlap is event overlap, not proof every request executes in every kernel.',
            'Setup fetch count is controlled-wave priming, not Full cache-miss performance.'])
    out.mkdir()
    with (out/'requests.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    for name,data in (('summary.json',summary),('coverage.json',coverage)):
        with (out/name).open('x') as f:json.dump(data,f,indent=2)
    manifest=dict(source_refs=[dict(path=str(raw/n),sha256=p.digest(raw/n)) for n in
        ('source1.json','source1_launch.json','remote_transfers.jsonl','remote_stop.json','analyze.py')],
        output_sha256={x.name:p.digest(x) for x in out.iterdir()},
        metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),plan_sha256=p.check_plan())
    with (out/'manifest.json').open('x') as f:json.dump(manifest,f,indent=2)
    with (raw/'analysis_receipt.json').open('x') as f:
        json.dump(dict(passed=True,identity=p.scope_identity(p.cg_path().name),manifest_sha256=p.digest(out/'manifest.json')),f,indent=2)
    print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
