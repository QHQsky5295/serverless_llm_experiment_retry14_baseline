"""D360: bounded retained-receipt diagnosis, adapted from D359 run_analysis.py."""
import json
import os
import subprocess
import sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

raw=Path(__file__).resolve().parent
identity=p.scope_identity(p.cg_path().name)
group=Path(identity['path'])
def sample():
    return {k:(group/k).read_text().strip() for k in ('memory.peak','memory.events',
        'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events')}
before=sample()
assert before['memory.high']==str(3*p.GIB) and before['memory.max']==str(4*p.GIB)
assert before['memory.swap.max']=='0' and os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],4*p.GIB)
assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
peek=p.scope_identity('primelora-tc-aux-7dc8ef7328e74b508e4839a8c19baf10.scope')
assert not p.owned_pids(Path(peek['path']))
peek_resources={k:(Path(peek['path'])/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
cleanup=p.stop_scope_identity(peek)
assert cleanup['released'] and not cleanup['hard_kill']
with (raw/'discovery_cleanup.json').open('x') as f:
    json.dump(dict(identity=peek,resources=peek_resources,cleanup=cleanup),f,indent=2)
python='/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python'
commands=[
    [python,'-m','unittest','tests.test_ieee_tc_full_control_analysis','tests.test_ieee_tc_control_timeline','-q'],
    [python,'-m','scripts.ieee_tc.analyze_d297_full','--preparation-wait-output',
     str(ROOT/'paper_results/ieee_tc/p2_backend/d360_preparation_wait/analysis1')]]
codes=[]
try:
    with (raw/'analysis1.log').open('x') as log:
        for command in commands:
            print(json.dumps(dict(command=command)),file=log,flush=True)
            result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
            codes.append(result.returncode)
            result.check_returncode()
finally:
    with (raw/'execution_receipt.json').open('x') as f:
        json.dump(dict(identity=identity,before=before,after=sample(),preflight=gate,
            commands=commands,returncodes=codes,pass_all=len(codes)==len(commands) and not any(codes),
            new_gpu_runs=0,no_figures=True),f,indent=2)
print(json.dumps(dict(returncodes=codes,resources=sample())))
