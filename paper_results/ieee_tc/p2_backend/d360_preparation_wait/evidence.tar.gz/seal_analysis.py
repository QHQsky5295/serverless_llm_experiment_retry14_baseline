"""Seal D360 offline evidence; adapted from the completed D359 seal helper."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d360_preparation_wait'
gate=p.preflight([ROOT],4*p.GIB)
assert gate['preflight_pass'],gate['issues']
execution=json.loads((raw/'execution_receipt.json').read_text())
assert execution['pass_all']
identity=execution['identity']
assert p.scope_still_owned(identity) and not p.owned_pids(Path(identity['path']))
resources={k:(Path(identity['path'])/k).read_text() for k in (
    'memory.peak','memory.events','memory.swap.current','cgroup.events')}
cleanup=p.stop_scope_identity(identity)
assert cleanup['released'] and not cleanup['hard_kill']
with (raw/'analysis_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,cleanup=cleanup),f,indent=2)
folder=out/'analysis1'
seal=json.loads((folder/'manifest.json').read_text())
for name,digest in seal['outputs'].items():
    assert p.digest(folder/name)==digest
for ref in seal['source_refs']:
    assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
for run in ('d353','d358'):
    rows=json.loads((folder/f'{run}_requests.json').read_text())
    assert len(rows)==4000
    assert [r['request_id'] for r in rows]==[f'req_{i:05d}' for i in range(4000)]
    assert all(abs(r['admission_to_acquired_ms']+r['executable_to_engine_ms']-
                   r['admission_to_engine_ms'])<1e-6 for r in rows)
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['changed']==['/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py']
assert p.digest(Path(protected['changed'][0]))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
with (raw/'protected.json').open('x') as f:
    json.dump(protected,f,indent=2)
paths=[raw/name for name in ('run_analysis.py','analysis1.log','execution_receipt.json',
    'discovery_cleanup.json','analysis_cleanup.json','seal_analysis.py','protected.json')]
paths += [ROOT/name for name in ('scripts/ieee_tc/analyze_d297_full.py',
    'tests/test_ieee_tc_full_control_analysis.py')]
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in paths:
    assert token and token not in path.read_bytes()
archive=out/'evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths: tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest()==p.digest(path)
with (out/'evidence.json').open('x') as f:
    json.dump(dict(kind='d360_retained_preparation_rechecks_v1',cpu_tests=61,new_gpu_runs=0,
        no_figures=True,source_commit='38f7610739ec9709e9b84ddd5ace8b61cbbb8470',
        archive_sha256=p.digest(archive),refs=[dict(path=str(path),sha256=p.digest(path)) for path in paths]),f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
own=p.scope_identity(p.cg_path().name)
with (raw/'seal_scope.json').open('x') as f:
    json.dump(dict(identity=own,resources={k:(Path(own['path'])/k).read_text() for k in (
        'memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(cleanup=cleanup,archive_bytes=archive.stat().st_size)))
