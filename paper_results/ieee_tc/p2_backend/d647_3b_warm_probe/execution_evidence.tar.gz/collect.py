"""Close the exact probe launcher and reuse the native warm audit offline."""
import ast, contextlib, json, os, re, subprocess, sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(name,obj):
    with (RAW/name).open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);save('analysis_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
launch=read(RAW/'source1_launch.json')
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
launcher=read(RAW/'launcher_identity.json');group=Path(launcher['path'])
assert p.scope_still_owned(launcher)
members={str(path):path.read_text().split() for path in group.rglob('cgroup.procs')}
assert members and all(not values for values in members.values())
resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(launcher)
subprocess.run(['systemctl','--user','stop',launcher['unit']],check=True)
assert not group.exists()
save('local_cleanup.json',dict(passed=True,identity=launcher,actual_recursive_procs_empty=True,path_gone=True,resources=resources))
gate=p.preflight([ROOT,RAW],128*1024*1024);assert gate['preflight_pass'],gate['issues']
save('analysis_gate.json',gate)
for name in ('scripts/ieee_tc/audit_warm_measurement.py','tests/test_ieee_tc_warm_reference.py'):
    ast.parse((ROOT/name).read_text())
with (RAW/'tests.log').open('x') as f:
    tested=subprocess.run([sys.executable,'-m','unittest','tests.test_ieee_tc_warm_reference','-v'],
        cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
assert tested.returncode==0
tests=int(re.search(r'Ran (\d+) tests',(RAW/'tests.log').read_text()).group(1))
assert tests==17
from scripts.ieee_tc.audit_warm_measurement import audit
index=ROOT/'paper_results/ieee_tc/p2_backend/d646_3b_warm_inputs/warm_input_index.json'
assert p.digest(index)=='5406f0f13dc489a91ae1f2e199217b5ca471a66acd043de474e301d7d5b135a4'
with (RAW/'audit.log').open('x') as f,contextlib.redirect_stdout(f):
    audit(RAW,RAW.parent/'d170_20261002/project_warm.jq',RAW/'native_audit.json',
        source_name='source1.json',launch_prefix='source1',index_path=index,phase='probe')
checked=read(RAW/'native_audit.json')
assert checked['passed'] and checked['native_checked']==32 and checked['batch_checked']==4
assert checked['measured']==0 and not checked['round_means']
assert not checked['resource']['aborts']
projection=read(RAW/'measurement_projection1.json')
batch_summary=[dict(serial=b['serial'],group_id=b['group_id'],batch_index=b['batch_index'],
    full_declared_kv_blocks=b['full_declared_kv_blocks'],
    kv_unreserved_free_blocks=b['scheduler_before']['kv_unreserved_free_blocks'],
    kv_tokens_per_block=b['scheduler_before']['kv_tokens_per_block'],
    actual_distinct_adapters=len({projection['requests'][i]['adapter_id'] for i in b['request_indices']}),
    all_decode_intersection_s=b['all_decode_intersection_s']) for b in projection['warm_batches']]
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
record=dict(passed=True,kind='d647_current_3b_warm_capacity_v1',tests=tests,
    native_checked=32,batch_checked=4,batch_size=8,batches=batch_summary,
    source_execution_commit=(RAW/'source_commit.txt').read_text().strip(),audit=checked,
    source_sha256=p.digest(RAW/'source1.json'),protected=protected,
    auditor_sha256=p.digest(ROOT/'scripts/ieee_tc/audit_warm_measurement.py'),
    tests_sha256=p.digest(ROOT/'tests/test_ieee_tc_warm_reference.py'),
    current_warm_measured=False,thresholds=None,full_performance_run=False,formal_g1_g2_qualified=False)
save('qualification.json',record)
print(json.dumps(dict(passed=True,tests=tests,native_checked=32,batches=batch_summary,
    physical_gpu_s=checked['physical_gpu_s'],resource=checked['resource'])))
