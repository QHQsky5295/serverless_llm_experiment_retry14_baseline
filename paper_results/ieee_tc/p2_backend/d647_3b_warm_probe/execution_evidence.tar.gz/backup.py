"""Reuse explicit checkpoint checks for closed native warm capacity evidence."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'","OUT=ROOT/'paper_results/ieee_tc/p2_backend/d647_3b_warm_probe'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'","=='ab8be4c57b19569f82feba5a83a5c4656ce2ca97'")
begin=code.index('reg=read(RAW/');end=code.index('preserved={',begin)
code=code[:begin]+'''audit=read(RAW/'qualification.json')
assert audit['passed'] and audit['tests']==17 and audit['native_checked']==32 and audit['batch_checked']==4
assert p.digest(RAW/'source1.json')==audit['source_sha256']
for name,key in [('scripts/ieee_tc/audit_warm_measurement.py','auditor_sha256'),('tests/test_ieee_tc_warm_reference.py','tests_sha256')]:
    assert p.digest(ROOT/name)==audit[key]
for phase in ('start','analysis'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert not Path(read(RAW/'local_cleanup.json')['identity']['path']).exists()
gate=p.preflight([ROOT],32*1024*1024);assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
''' +code[end:]
begin=code.index('members=[RAW/name');end=code.index('\nfor path in members:',begin)
code=code[:begin]+'''members=[RAW/name for name in ('start.py','close.py','collect.py','backup.py',
    'start_identity.json','start_receipt.json','start_closure.json','launch_gate.json','preflight.json',
    'launcher_identity.json','local_cleanup.json','analysis_identity.json','analysis_closure.json','analysis_gate.json',
    'qualification.json','native_audit.json','audit.log','tests.log','source1_launch.json','source_commit.txt',
    'source1_launcher.log','backup_gate.json')]
members += [RAW/'source1_launch.launch'/name for name in ('service.log','exec_receipt.json','watchdog.jsonl','watchdog.stderr')]
assert len({path.name for path in members})==len(members)
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
''' +code[end:]
begin=code.index('test_counts={');end=code.index("save(OUT/'qualification.json'",begin)
code=code[:begin]+'''test_counts={'native_probe_cases':32,'cpu_warm_tests':17}
record=dict(passed=True,experiment_pass=True,native_warm_capacity_validation=True,full_performance_run=False,
    parent_commit='ab8be4c57b19569f82feba5a83a5c4656ce2ca97',audit=audit,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    source_run=dict(path=str(RAW/'source1.json'),sha256=p.digest(RAW/'source1.json')),
    archive_members={path.name:dict(path=str(path),sha256=p.digest(path)) for path in members},
    caveat='One native batch8 capacity probe; common warm measurement/threshold freeze and Full workload remain pending.')
''' +code[end:]
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['scripts/ieee_tc/audit_warm_measurement.py','tests/test_ieee_tc_warm_reference.py','docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D647_3B_WARM_CAPACITY_PROBE.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: verify current 3B batch8 warm capacity with sealed input coverage (D647)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
