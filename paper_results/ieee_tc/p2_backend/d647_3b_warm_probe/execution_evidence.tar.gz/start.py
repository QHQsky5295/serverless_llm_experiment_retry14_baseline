"""Bind the existing gated launcher to the sealed current 3B warm capacity probe."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d641_20261017/start.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("=='02f438519d2cca90aa2b710466900dac1daca2a6'","=='ab8be4c57b19569f82feba5a83a5c4656ce2ca97'")
replace("previous=RAW.parent/'d640_20261017'","previous=RAW.parent/'d646_20261017'")
begin=code.index("prepared=ROOT/");end=code.index('assert p.check_plan()',begin)
code=code[:begin]+'''prepared=ROOT/'paper_results/ieee_tc/p2_backend/d646_3b_warm_inputs'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=prepared,check=True,stdout=subprocess.DEVNULL)
audit=read(prepared/'qualification.json');assert audit['passed'] and audit['audit']['inputs']['passed']
inputs=audit['audit']['inputs']
assert inputs['current_tokenizer_checked_requests']==4000 and inputs['probe_batches']==4
for ref in inputs['source_refs']+[inputs['index'],inputs['config']]:
    assert p.digest(Path(ref['path']))==ref['sha256']
assert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==audit['audit']['runner_sha256']
''' +code[end:]
code=code.replace("'tc-d641-source'","'tc-d647-warm'")
code=code.replace("('start.py','remote_control.py','close.py')","('start.py','close.py')")
replace("input_qualification=audit['inputs']","input_qualification=inputs")
replace("subprocess.run([sys.executable,str(RAW/'remote_control.py'),'start'],check=True)\nsubprocess.run([sys.executable,str(RAW/'remote_control.py'),'health'],check=True,stdout=subprocess.DEVNULL)",
        "# GPU-ready warm reference has no remote service or network acquisition.")
replace('run_d298_capacity_source.sh d641','run_d298_capacity_source.sh d647')
ast.parse(code)
exec(compile(code,str(source),'exec'))
