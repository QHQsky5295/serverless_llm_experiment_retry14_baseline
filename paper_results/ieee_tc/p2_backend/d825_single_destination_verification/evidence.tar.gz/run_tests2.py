"""Keep first attempt; fix only timestamp-independent test assertions."""
from pathlib import Path
source = Path(__file__).with_name('run_tests.py')
code = source.read_text()
code = code.replace("exec(compile(code, str(source), 'exec'))", """code = code.replace("phase=sys.argv[1];assert phase in ('focused','regression')",
                    "phase=sys.argv[1];assert phase in ('focused2','regression')")
code = code.replace("tests=(['tests.test_http_artifact_store', 'tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication']",
                    "tests=(['tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication']")
code = code.replace("if phase=='focused'", "if phase=='focused2'")
code = code.replace(", 'tests.test_ieee_tc_static_preparation'", "")
exec(compile(code, str(source), 'exec'))""")
exec(compile(code, str(source), 'exec'))
