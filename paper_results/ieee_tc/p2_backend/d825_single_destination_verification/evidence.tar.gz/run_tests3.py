"""Directly adapt the existing D595 test receipt, with D610 per-module isolation."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/run_tests.py')
code = source.read_text()
code = code.replace("phase in ('focused','regression')", "phase in ('focused2','regression')")
start, end = code.index('paths=[ROOT/name'), code.index('\nrefs=')
code = code[:start] + """paths=[ROOT/name for name in (
    'faaslora/storage/http_artifact_store.py', 'scripts/run_all_experiments.py',
    'faaslora/memory/residency_manager.py', 'tests/test_http_artifact_store.py',
    'tests/test_ieee_tc_request_lifecycle.py')]
""" + code[end:]
start, end = code.index('tests=('), code.index('\ncommand=')
code = code[:start] + """tests=(['tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication']
    if phase=='focused2' else ['tests.test_ieee_tc_request_lifecycle',
                              'tests.test_ieee_tc_transfer_pressure'])""" + code[end:]
old = '    result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)'
assert code.count(old) == 1
code = code.replace(old, """    completed=[]
    for module in tests:
        invocation=[sys.executable,'-B','-m','unittest',module,'-v']
        log.write('Module: '+module+'\\n');log.flush()
        outcome=subprocess.run(invocation,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)
        completed.append(dict(command=invocation,returncode=outcome.returncode))
        if outcome.returncode:break
    from types import SimpleNamespace
    result=SimpleNamespace(returncode=max(abs(row['returncode']) for row in completed))
    command=completed""")
exec(compile(code, str(source), 'exec'))
