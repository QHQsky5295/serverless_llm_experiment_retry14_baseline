"""Reuse the D610 bounded CPU qualification; no inference or new input pool."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d610_20261017/run_tests.py')
code = source.read_text()
old = "'faaslora/memory/residency_manager.py',\n    'tests/test_ieee_tc_file_observation.py',\n    'tests/test_ieee_tc_request_lifecycle.py'"
new = "'faaslora/storage/http_artifact_store.py', 'scripts/run_all_experiments.py',\n    'faaslora/memory/residency_manager.py', 'tests/test_http_artifact_store.py',\n    'tests/test_ieee_tc_request_lifecycle.py'"
assert code.count(old) == 1
code = code.replace(old, new)
old = "tests=(['tests.test_ieee_tc_file_observation']"
new = "tests=(['tests.test_http_artifact_store', 'tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication']"
assert code.count(old) == 1
code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
