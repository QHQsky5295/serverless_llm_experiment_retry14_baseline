"""Seal D352 completed diagnostic and bind D353 unchanged-candidate Full4000."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
oldraw=raw.parent/'d352_20261008'
oldout=ROOT/'paper_results/ieee_tc/p2_backend/d352_hit_host_transaction'
out=ROOT/'paper_results/ieee_tc/p2_backend/d353_full_validation'
out.mkdir(exist_ok=False,parents=True)
identity=p.scope_identity(p.cg_path().name)
assert os.sched_getaffinity(0)=={2,3,26,27}
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
assert git('rev-parse','HEAD')=='3d232cf9790be0702ebbbdef4abbc2be8620cf48'
assert git('branch','--show-current')=='retry14_continuous_queue_v2'
assert not git('diff','--cached','--name-only') and not git('diff','HEAD','--','faaslora')
receipt=json.loads((oldraw/'offline_execution_receipt.json').read_text())
assert receipt['pass_all']
old=receipt['identity'];group=Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(group)
cleanup=p.stop_scope_identity(old)
assert cleanup['released'] and not cleanup['hard_kill'] and not group.exists()
with (oldraw/'analysis_cleanup.json').open('x') as f:json.dump(dict(identity=old,cleanup=cleanup),f,indent=2)
audit=json.loads((oldout/'smoke1/audit.json').read_text())
assert audit['stats']['completed']==100 and audit['hit_host_transaction_trigger']['misclassified']==0
assert audit['hit_host_transaction_trigger']['counts']['same_transaction_confirmed_gpu_hit_v1']==62
for ref in audit['raw_evidence']:
    assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
assert json.loads((oldraw/'remote_stop.json').read_text())['all_owned_units_inactive']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
config=ROOT/'configs/ieee_tc/20261008_d353_7b_full_w0.yaml'
prior=ROOT/'configs/ieee_tc/20261008_d349_7b_full_w0.yaml'
c,previous=(yaml.safe_load(x.read_text()) for x in (config,prior))
expected=copy.deepcopy(previous)
for section,field in (('experiment','output_dir'),('storage','nvme_cache_dir'),('storage','host_cache_dir')):
    assert not Path(c[section][field]).exists()
    expected[section][field]=c[section][field]
assert c==expected and c['workload']['total_requests']==4000
assert c['experiment']['output_dir']==str(raw/'7b_full_w0')
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count']==147 and protected['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
gate=p.preflight([ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def safe(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
def archive(destination,files):
    with destination.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
        for path in files:
            data=path.read_bytes();safe(data)
            if path.suffix=='.py':ast.parse(data)
            if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
            tar.add(path,arcname=path.name,recursive=False)
    with tarfile.open(destination,'r:gz') as tar:
        assert len(tar.getmembers())==len(files)
        for path in files:
            assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest()==p.digest(path)
closed_files=sorted(x for x in oldraw.iterdir() if x.is_file())
archive(oldout/'closure_evidence.tar.gz',closed_files)
with (oldout/'closure_evidence.json').open('x') as f:
    json.dump(dict(passed=True,archive_sha256=p.digest(oldout/'closure_evidence.tar.gz'),
        refs=[dict(path=str(x),sha256=p.digest(x)) for x in closed_files]),f,indent=2)
files=sorted(x for x in raw.iterdir() if x.is_file())
archive(out/'preparation_evidence.tar.gz',files)
refs=[config,prior,ROOT/'faaslora/memory/gpu_monitor.py',ROOT/'faaslora/memory/residency_manager.py',
    ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',oldout/'smoke1/audit.json']
for key in ('ieee_service_profile','ieee_preparation_profile'):
    profile=c['resource_coordination'][key]
    assert p.digest(Path(profile['path']))==profile['sha256']
    refs.append(Path(profile['path']))
with (out/'preparation.json').open('x') as f:
    json.dump(dict(passed=True,kind='d353_ordinary_full4000_preparation_v1',base_requests=4000,
        diagnostic_prefix_count=None,n_correct=None,formal_qualification=False,
        configuration_changed_only_paths=True,observer_enabled=False,
        protected=protected,preflight=gate,identity=identity,
        refs=[dict(path=str(x),sha256=p.digest(x)) for x in refs],
        raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in files]),f,indent=2)
with (out/'preparation.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.name!='preparation.sha256':f.write(p.digest(path)+'  '+path.name+'\n')
with (oldout/'closure.sha256').open('x') as f:
    for path in sorted(oldout.rglob('*')):
        if path.is_file() and path.name!='closure.sha256':f.write(p.digest(path)+'  '+str(path.relative_to(oldout))+'\n')
relative=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D352_TRANSACTION_LOCAL_HOST_EVIDENCE.md',
    'configs/ieee_tc/20261008_d353_7b_full_w0.yaml','scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    'scripts/ieee_tc/analyze_d298_smoke.py','tests/test_ieee_tc_hit_host_analysis.py']
relative += [str(x.relative_to(ROOT)) for x in sorted(oldout.rglob('*')) if x.is_file() and not git('ls-files','--',str(x.relative_to(ROOT)))]
relative += [str(x.relative_to(ROOT)) for x in sorted(out.iterdir()) if x.is_file()]
subprocess.run(['git','add','--',*relative],cwd=ROOT,check=True)
assert sorted(git('diff','--cached','--name-only').splitlines())==sorted(relative)
for name in relative:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT);safe(data)
    assert hashlib.sha256(data).hexdigest()==p.digest(ROOT/name)
    if name.endswith('.py'):ast.parse(data)
    if name.endswith('.sh'):subprocess.run(['bash','-n',str(ROOT/name)],check=True)
subprocess.run(['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','Validate D352 HOST transaction and freeze D353 Full4000 replay'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD')
subprocess.run(['git','push','faaslora_origin','HEAD:retry14_continuous_queue_v2'],cwd=ROOT,check=True)
remote=git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head==remote
with (raw/'backup_receipt.json').open('x') as f:
    json.dump(dict(passed=True,head=head,remote=remote,paths=relative,identity=identity),f,indent=2)
print(json.dumps(dict(passed=True,head=head,remote=remote,paths=len(relative))))
