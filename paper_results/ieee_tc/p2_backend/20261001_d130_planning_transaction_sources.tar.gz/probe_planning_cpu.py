"""Reuse D128 paired ready-callback method for one sealed computation transaction.

Reuse the existing four-adapter owned-planning fixture; do not generate weights,
traces, remote deliveries or synthetic large physical snapshots. This is NOT a
500-adapter performance result. Production Full must include worker startup.
"""
import asyncio
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from tests.test_ieee_tc_planning_cpu import PlanningCPU
from faaslora.preloading.planning_cpu import run_planning_cpu, execution_preparation_input


async def main():
    fixture = PlanningCPU()
    args, runner, _ = await asyncio.to_thread(fixture.inputs)
    received = {k: v for k, v in args.items() if k != 'demand'}
    stack = runner._stack
    expected = stack.plan_ieee_owned_preparation(**received)
    selected = stack.preloading_planner.validate_ieee_execution_plan(expected)
    rows = []

    async def measure(case, method, trial):
        loop = asyncio.get_running_loop()
        callback = loop.create_future()
        start = time.perf_counter_ns()
        loop.call_soon(lambda: callback.set_result(time.perf_counter_ns()))
        worker = getattr(stack, '_ieee_planning_cpu', None)
        event_start = len(worker.events) if worker is not None else 0
        if method == 'two_round_trips':
            plan = await run_planning_cpu(stack, 'owned_epoch', args)
            value = await run_planning_cpu(stack, 'validate_execution', {'plan': plan})
        else:
            plan = await stack.plan_ieee_owned_preparation_async(**received)
            value = await execution_preparation_input(stack, plan)
        end = time.perf_counter_ns()
        assert value == (expected, selected)
        events = stack._ieee_planning_cpu.events[event_start:]
        expected_calls = 2 if method == 'two_round_trips' else 1
        assert len(events) == expected_calls
        responded = await callback
        rows.append(dict(case=case, method=method, trial=trial,
            elapsed_ms=(end-start)/1e6, ready_callback_delay_ms=(responded-start)/1e6,
            callback_before_result=responded < end, exact_value_equal=True,
            worker_calls=len(events),
            worker_input_bytes=sum(e['input_bytes'] for e in events),
            worker_output_bytes=sum(e['output_bytes'] for e in events)))

    try:
        await measure('frozen_plan_pipeline', 'sealed_cold', -1)
        for case in ('frozen_plan_pipeline',):
            for trial in range(3):
                order = ['two_round_trips', 'sealed_transaction'] if trial % 2 == 0 else ['sealed_transaction', 'two_round_trips']
                for method in order:
                    await measure(case, method, trial)
        summary = []
        for case in ('frozen_plan_pipeline',):
            groups = {m: [r for r in rows if r['case'] == case and r['method'] == m]
                      for m in ('two_round_trips', 'sealed_transaction')}
            for metric in ('elapsed_ms', 'ready_callback_delay_ms', 'worker_calls', 'worker_input_bytes', 'worker_output_bytes'):
                means = {m: statistics.mean(r[metric] for r in group) for m, group in groups.items()}
                summary.append(dict(case=case, metric=metric, **means,
                    relative_reduction=(means['two_round_trips']-means['sealed_transaction'])/means['two_round_trips']))
        result = dict(kind='d130_sealed_planning_transaction_component_v1', samples=rows, summary=summary,
            worker_events=stack._ieee_planning_cpu.events, adapter_count=4,
            source_snapshot_id=expected['source_snapshot_id'], plan_sha256=expected['plan_sha256'],
            formal_performance_result=False, full_candidate_accepted=False,
            limitations=['Four-adapter controlled fixture, not complete 500-adapter workload.',
                'Warm component times do not exclude cold process startup from production lifecycle.',
                'Three local trials are not independent workload seeds or system-level confidence intervals.',
                'Execution-time physical owners/checks are unchanged; later state may supersede a plan.'],
            source_refs=[dict(path=str(ROOT/p), sha256=hashlib.sha256((ROOT/p).read_bytes()).hexdigest())
                for p in ('faaslora/preloading/planning_cpu.py','faaslora/preloading/preloading_planner.py',
                          'faaslora/experiment/experiment_stack.py','scripts/run_all_experiments.py',
                          'tests/test_ieee_tc_planning_cpu.py','tests/test_ieee_tc_transfer_pressure.py')])
        with (Path(__file__).parent/'planning_cpu_probe.json').open('x') as stream:
            json.dump(result, stream, indent=2, allow_nan=False)
        print(json.dumps(dict(summary=summary, cold=rows[0]), indent=2))
    finally:
        worker = getattr(stack, '_ieee_planning_cpu', None)
        if worker is not None:
            await worker.close()
        await asyncio.to_thread(fixture.doCleanups)


if __name__ == '__main__':
    asyncio.run(main())
