"""Reuse D128 small-evidence table/bundle workflow for D130; no replay."""
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

root=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw=root/'results/ieee_tc/p2_backend_qualification/d130_20261001'
parent=root/'paper_results/ieee_tc/p2_backend'
out=parent/'20261001_d130_sealed_planning_transaction'
assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for unit in ('tests1','probe1','verify'):
    name=f'primelora-d130-{unit}-20261001.scope'
    state=subprocess.check_output(['systemctl','--user','show',name,'-p','ActiveState','--value'],text=True).strip()
    assert state=='inactive', (name,state)
probe=raw/'planning_cpu_probe.json'
x=json.loads(probe.read_text())
assert len(x['samples'])==7 and all(r['exact_value_equal'] for r in x['samples'])
assert not x['formal_performance_result'] and not x['full_candidate_accepted']
for ref in x['source_refs']:assert sha(Path(ref['path']))==ref['sha256'],ref['path']
verification=json.loads((raw/'verification.json').read_text())
assert verification['protected']['pass'] and verification['protected']['entry_count']==147
for ref in verification['source_refs']:assert sha(Path(ref['path']))==ref['sha256']
log=(raw/'verify.log').read_text()
assert '\nOK\n' in log and not re.search(r'^FAILED ',log,re.M)
test_count=int(re.search(r'Ran (\d+) tests in',log).group(1))
for name in ('tests1','probe1','verify'):
    assert 'Exit status: 0' in (raw/f'{name}_time.txt').read_text()
out.mkdir()
for name,rows in [('samples',x['samples']),('summary_table',x['summary'])]:
    with (out/f'{name}.csv').open('x',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader();writer.writerows(rows)
with (out/'summary.json').open('x') as stream:
    json.dump(dict(x,decision='candidate_for_ordinary_Full_not_system_performance_accepted',
        final_test_count=test_count,verification=verification,probe_sha256=sha(probe),
        source_base='837b23165de159ffe9982d7f93c1a50aee4505c5'),
        stream,indent=2,allow_nan=False)
bundle=parent/'20261001_d130_planning_transaction_sources.tar.gz'
assert not bundle.exists()
members={}
with tarfile.open(bundle,'x:gz') as archive:
    for p in sorted(raw.iterdir()):
        if not p.is_file() or p.stat().st_size>=2*1024**2 or p.suffix not in {'.py','.sh','.json','.txt','.log','.patch'}:continue
        if p.name in {'finalize.log','finalize_time.txt'}:continue
        data=p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        members[p.name]=hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames())==set(members)
    for name,expected in members.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected
with (parent/'20261001_d130_planning_transaction_sources.sha256').open('x') as stream:
    stream.write(sha(bundle)+'  '+bundle.name+'\n')
with (parent/'20261001_d130_planning_transaction_sources_members.json').open('x') as stream:
    json.dump(dict(bundle=bundle.name,member_sha256=members,member_checks_pass=True),stream,indent=2)
print(json.dumps(dict(bytes=bundle.stat().st_size,members=len(members),sha256=sha(bundle),
    output=str(out),tests=test_count,protected=147)))
