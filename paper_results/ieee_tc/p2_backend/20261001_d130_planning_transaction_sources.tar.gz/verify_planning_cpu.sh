#!/usr/bin/env bash
# Reuse D128 final regression and protection protocol; D130 transaction candidate.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d130_20261001
unit=primelora-d130-verify-20261001.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/verify_scope.txt"
export PYTHONUNBUFFERED=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
/usr/bin/time -v -o "$raw/verify_time.txt" "$python" -m unittest tests.test_ieee_tc_planning_cpu tests.test_ieee_tc_transfer_pressure tests.test_ieee_tc_planning tests.test_ieee_tc_preparation_snapshot_copy tests.test_ieee_tc_preparation_cost tests.test_ieee_tc_native_retirement tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_native_timing tests.test_ieee_tc_launch tests.test_ieee_tc_external_replay tests.test_basic_smoke -v > "$raw/verify.log" 2>&1
"$python" - <<'PY'
import json
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root=Path.cwd()
raw=root/'results/ieee_tc/p2_backend_qualification/d130_20261001'
seal=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert seal['pass'] and seal['entry_count']==147
metric=root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
plan=Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')
assert digest(metric)=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert digest(plan)=='fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
paths=['faaslora/preloading/planning_cpu.py','faaslora/experiment/experiment_stack.py',
       'faaslora/preloading/preloading_planner.py','scripts/run_all_experiments.py',
       'tests/test_ieee_tc_planning_cpu.py','tests/test_ieee_tc_transfer_pressure.py']
result=dict(kind='d130_planning_cpu_verification_v1', protected=seal,
    metric_protocol_sha256=digest(metric), plan_sha256=digest(plan),
    source_refs=[dict(path=str(root/p),sha256=digest(root/p)) for p in paths],
    formal_performance_result=False)
with (raw/'verification.json').open('x') as stream:
    json.dump(result,stream,indent=2,allow_nan=False)
print(json.dumps(dict(protected=147,source_refs=len(paths))))
PY
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
