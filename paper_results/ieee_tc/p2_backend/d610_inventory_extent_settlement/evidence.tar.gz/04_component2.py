"""Preserve attempt1; reset mutable fixture state between implementation calls."""
from pathlib import Path
source = Path(__file__).resolve().parent/'component.py'
code = source.read_text()
code = code.replace("exec(compile(header, str(driver), 'exec'))", """header=header.replace('component_identity.json','component2_identity.json')
exec(compile(header, str(driver), 'exec'))""")
old = '    original_bounds = copy.deepcopy(owner._file_allocations)'
assert code.count(old)==1
code = code.replace(old, old+"""
    original_sources = copy.deepcopy(owner._confirmed_sources)
    original_epoch = owner.source_epoch""")
old = '            owner._file_allocations = copy.deepcopy(original_bounds)'
assert code.count(old)==1
code = code.replace(old, old+"""
            owner._confirmed_sources = copy.deepcopy(original_sources)
            owner.source_epoch = original_epoch""")
old = "        assert outputs['parent'] == outputs['candidate']"
assert code.count(old)==1
code = code.replace(old, """        def differences(a,b,path=''):
            if isinstance(a,dict) and isinstance(b,dict):
                return [row for key in set(a)|set(b) for row in differences(a.get(key),b.get(key),path+'/'+str(key))]
            if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
                return [row for index,(x,y) in enumerate(zip(a,b)) for row in differences(x,y,path+'/'+str(index))]
            return [] if a==b else [dict(path=path,parent=repr(a),candidate=repr(b))]
        delta=differences(outputs['parent'],outputs['candidate'])
        save('fixture_diff_'+str(initialize)+'.json',dict(differences=delta,exact=not delta))
        assert not delta,delta""")
code = code.replace("save('component_result.json',result)", "save('component_result2.json',result)")
exec(compile(code,str(source),'exec'))
