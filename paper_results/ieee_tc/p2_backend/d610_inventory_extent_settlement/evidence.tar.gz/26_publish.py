"""Reuse D608 explicit-path checked publication; D609 storage + D610 candidate."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d608_20261017/publish.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace('d608_w2_residual_and_holding','d610_inventory_extent_settlement')
replace('22f29d56b38a5bdd1ae705f5f3defb43ee3308eb','388923911568748a96e67d90c240527a78baead3')
replace("assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')",
        "assert set(git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc').splitlines()) == {'faaslora/memory/residency_manager.py','tests/test_ieee_tc_file_observation.py'}")
start=code.index("diagnosis=read(")
end=code.index('\nprotected=',start)
code=code[:start]+"""component=read(RAW/'component_result3.json')
assert component['passed'] and not component['formal_performance']
assert component['candidate_source_sha256']==p.digest(ROOT/'faaslora/memory/residency_manager.py')
for phase in ('focused','regression'):
    receipt=read(RAW/(phase+'_receipt.json'));assert receipt['passed']
    for name,sha in receipt['sources'].items():assert p.digest(Path(name))==sha
    assert receipt['log_sha256']==p.digest(RAW/(phase+'.log'))
for phase in ('focused','regression','component','component2','component3'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
storage_root=RAW.parent.parent/'storage_maintenance/d609_20261017'
storage=read(storage_root/'storage_result.json')
assert read(storage_root/'receipt.json')['result_sha256']==p.digest(storage_root/'storage_result.json')
closed=read(storage_root/'storage_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
assert len(storage['entries'])==3
for row in storage['entries']:
    assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']==row['audit_sha256']
    assert not Path(row['source']).exists()
    assert p.digest(Path(row['archive']))==row['archive_sha256']
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
for name,sha in [('METRIC_PROTOCOL_FROZEN_V1.md','5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'),
                 ('METRIC_PROTOCOL_SINGLE_RUN_V2.md','193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d')]:
    assert p.digest(ROOT/'docs/ieee_tc'/name)==sha
"""+code[end:]
replace("D608_W2_RESIDUAL_AND_GPU_HOLDING.md", "D610_INVENTORY_EXTENT_SETTLEMENT.md")
start=code.index("files=sorted(")
end=code.index('\nassert sum(path.stat()',start)
code=code[:start]+"""files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log')])
files+=sorted([*storage_root.glob('*.py'),*storage_root.glob('*.json'),*storage_root.glob('*.log')])
files += [doc,ROOT/'faaslora/memory/residency_manager.py',ROOT/'tests/test_ieee_tc_file_observation.py',
    RAW.parent/'d595_20261017/run_tests.py',RAW.parent/'d605_20261017/compare_inventory.py',
    RAW.parent/'d606_20261017/close.py',storage_root.parent/'d592_20261017/close.py',
    storage_root.parent/'d604_20261017/compress.py',ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py']
"""+code[end:]
replace("kind='d608_closed_existing_log_diagnosis_v1'", "kind='d610_inventory_extent_settlement_cpu_qualification_v1'")
replace('diagnosis=diagnosis,transport=transport,protected=protected,',
        "component=component,storage=storage,focused=read(RAW/'focused_receipt.json'),regression=read(RAW/'regression_receipt.json'),protected=protected,")
replace('production_changed=False,inference_runs_added=0,ranking_eligible=False',
        'production_changed=True,inference_runs_added=0,ranking_eligible=False,performance_accepted=False')
replace("names=[str(doc.relative_to(ROOT)),'docs/ieee_tc/EXECUTION_STATUS.md']",
        "names=[str(doc.relative_to(ROOT)),'docs/ieee_tc/EXECUTION_STATUS.md','faaslora/memory/residency_manager.py','tests/test_ieee_tc_file_observation.py']")
replace('tc: explain residual W2 violations and GPU holding using sealed logs (D608)',
        'tc: qualify single-inventory extent settlement and archive closed evidence (D609-D610)')
exec(compile(code,str(source),'exec'))
