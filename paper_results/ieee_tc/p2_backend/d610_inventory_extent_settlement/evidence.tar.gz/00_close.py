"""Reuse D606 actual scope closure with its allowed focused/regression phases."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d606_20261017/close.py')
exec(compile(source.read_text(),str(source),'exec'))
