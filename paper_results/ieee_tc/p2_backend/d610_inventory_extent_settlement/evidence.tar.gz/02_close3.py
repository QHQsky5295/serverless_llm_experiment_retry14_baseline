from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d592_20261017/close.py')
code=source.read_text().replace("('cleanup', 'storage', 'curation', 'publication')", "('component3',)")
exec(compile(code,str(source),'exec'))
