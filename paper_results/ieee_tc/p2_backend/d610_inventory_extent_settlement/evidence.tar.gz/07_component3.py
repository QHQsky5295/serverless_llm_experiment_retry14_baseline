"""Correct both implementations' isolated global bindings for the extent fixture."""
from pathlib import Path
source = Path(__file__).resolve().parent/'component2.py'
wrapper = source.read_text()
marker = "exec(compile(code,str(source),'exec'))"
assert wrapper.count(marker)==1
namespace = {'__file__': str(Path(__file__)), '__name__': '__main__'}
exec(compile(wrapper.replace(marker,''),str(source),'exec'),namespace)
code = namespace['code']
code = code.replace('component2_identity.json','component3_identity.json')
code = code.replace('component_result2.json','component_result3.json')
code = code.replace("'fixture_diff_'", "'fixture_diff3_'")
marker = 'tests, rows = [], []'
assert code.count(marker)==1
code=code.replace(marker, """@contextlib.contextmanager
def extent_state(initialized):
    function=lambda *args: initialized
    assert old._settle_file_allocations.__globals__ is namespace
    with (patch.object(module,'_file_extents_initialized',function),
          patch.dict(namespace,{'_file_extents_initialized':function})):
        assert old._settle_file_allocations.__globals__['_file_extents_initialized'] is module._file_extents_initialized
        yield

"""+marker)
for old,new in [
    ("patch.object(module, '_file_extents_initialized', return_value=initialize)", "extent_state(initialize)"),
    ("patch.object(module, '_file_extents_initialized', return_value=state=='initialized')", "extent_state(state=='initialized')"),
    ("patch.object(module,'_file_extents_initialized',return_value=state=='initialized')", "extent_state(state=='initialized')"),
]:
    assert code.count(old)==1,old
    code=code.replace(old,new)
exec(compile(code,str(namespace['source']),'exec'))
