"""D605 bounded component harness, D153 tiny fixture, retained D557 metadata only."""
from pathlib import Path

driver = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d605_20261017/compare_inventory.py')
header = driver.read_text().split("old_commit = ", 1)[0]
header = header.replace('storage_maintenance/d604_20261017', 'storage_maintenance/d609_20261017')
exec(compile(header, str(driver), 'exec'))
import copy

commit = '388923911568748a96e67d90c240527a78baead3'
relative = 'faaslora/memory/residency_manager.py'
parent_source = subprocess.check_output(['git', 'show', commit+':'+relative], cwd=ROOT)
candidate_sha = p.digest(ROOT/relative)
tree = ast.parse(parent_source)
namespace = dict(module.__dict__)
for name, kind in [('_local_file_inventory', ast.FunctionDef), ('LocalSourceReferences', ast.ClassDef)]:
    node = next(n for n in tree.body if isinstance(n, kind) and n.name == name)
    exec(compile(ast.Module(body=[node], type_ignores=[]), '<d610-parent-'+name+'>', 'exec'), namespace)
old = namespace['LocalSourceReferences']
names = ['inventory', '_file_inventory', '_settle_file_allocations',
         '_prepare_file_allocation', 'file_budget_snapshot', 'preparation_snapshot', 'publish_transfer']

@contextlib.contextmanager
def implementation(variant):
    with contextlib.ExitStack() as stack:
        if variant == 'parent':
            for name in names:
                stack.enter_context(patch.object(module.LocalSourceReferences, name, getattr(old, name)))
        yield

tests, rows = [], []
case = FreshFileObservation()
try:
    with contextlib.redirect_stdout(io.StringIO()):
        fixture, owner, manifests, limits, file, bound = case.unsettled()
    manifests.update({f'absent-{i}': dict(manifests['a']) for i in range(496)})
    manifests = FrozenPreparationDescriptions(manifests)
    original_bounds = copy.deepcopy(owner._file_allocations)
    for initialize in (False, True):
        outputs = {}
        for variant in ('parent', 'candidate'):
            owner._file_allocations = copy.deepcopy(original_bounds)
            with (implementation(variant), patch.object(module, '_file_extents_initialized', return_value=initialize)):
                outputs[variant] = without_capture_times(owner.preparation_snapshot(manifests=manifests, limits=limits))
            outputs[variant]['bounds'] = copy.deepcopy(owner._file_allocations)
        assert outputs['parent'] == outputs['candidate']
        tests.append('tiny_full_snapshot_and_bounds_exact_initialized_'+str(initialize))
finally:
    case.doCleanups()

pool = Path('/tmp/tc-d557-7bv/remote_artifacts')
campaign = RAW.parent.parent/'vllm_qualification/d557_20261016'
closed = json.loads((campaign/'publication_closure.json').read_text())
launch = json.loads((campaign/'launch7b.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not Path(launch['service_identity']['path']).exists()
assert pool.resolve() == pool and pool.is_dir()
owner = module.LocalSourceReferences({'nvme': pool})
inventory = owner.inventory()
files = [row for row in inventory['allocations'] if row['kind']=='file' and row['allocated_bytes']]
selected = files[0]
key = selected['device'], selected['inode']
bound = dict(size_bytes=selected['logical_bytes'], data_bytes=selected['allocated_bytes'],
    ceiling_bytes=6*selected['allocated_bytes'], writer_closed=True, settled=False,
    filesystem='ext4', tier='nvme', transfer_id='component-only-no-transfer')
limits = {'nvme': inventory['allocated_file_bytes']+bound['ceiling_bytes']}
for state in ('settled', 'uninitialized', 'initialized'):
    def reset():
        owner._file_allocations = {key: dict(bound)}
        if state == 'settled':
            owner._file_allocations[key].update(settled=True, ceiling_bytes=bound['data_bytes'])
    expected = None
    for repeat in range(3):
        for variant in (('parent','candidate') if repeat%2==0 else ('candidate','parent')):
            reset()
            with implementation(variant), patch.object(module, '_file_extents_initialized', return_value=state=='initialized'):
                start=time.perf_counter()
                result=owner.file_budget_snapshot(limits)
                elapsed=time.perf_counter()-start
            result.pop('captured_at')
            result['bounds']=copy.deepcopy(owner._file_allocations)
            if expected is None: expected=result
            assert result==expected
            rows.append(dict(state=state,variant=variant,repeat=repeat,elapsed_seconds=elapsed,exact=True))
    for variant in ('parent','candidate'):
        reset(); counts=Counter(); original_stat=os.stat
        def counted(path,*args,**kwargs):
            if kwargs.get('follow_symlinks') is False: counts[str(path)]+=1
            return original_stat(path,*args,**kwargs)
        with (implementation(variant), patch.object(os,'stat',counted),
              patch.object(module,'_file_extents_initialized',return_value=state=='initialized')):
            value=owner.file_budget_snapshot(limits)
        expected_count=4 if variant=='parent' and state!='settled' else 2
        target_count=expected_count+(variant=='candidate' and state=='initialized')
        assert counts.pop(selected['paths'][0])==target_count
        assert set(counts.values())=={expected_count}
        tests.append(dict(state=state,variant=variant,ordinary_path_stats=expected_count,settling_path_stats=target_count))

assert p.digest(ROOT/relative)==candidate_sha
assert p.verify_seal(seal)['pass']
import torch
assert not torch.cuda.is_initialized()
groups=[]
for state in ('settled','uninitialized','initialized'):
    for variant in ('parent','candidate'):
        values=[r['elapsed_seconds'] for r in rows if r['state']==state and r['variant']==variant]
        groups.append(dict(state=state,variant=variant,values_seconds=values,mean_seconds=statistics.mean(values)))
result=dict(passed=True,parent_commit=commit,parent_source_sha256=hashlib.sha256(parent_source).hexdigest(),
    candidate_source_sha256=candidate_sha,tests=tests,rows=rows,groups=groups,
    file_count=inventory['unique_file_count'],path_count=sum(len(x['paths']) for x in inventory['allocations']),
    source=str(pool),read_only_metadata=True,extent_state_controlled_for_component=True,
    real_kernel_settlement_performance=False,formal_performance=False,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')})
save('component_result.json',result)
print(json.dumps(dict(passed=True,tests=len(tests),groups=groups),indent=2))
