"""Reuse D641 gated source launch with D643 strict admission-on evidence."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d641_20261017/start.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("assert head==remote=='02f438519d2cca90aa2b710466900dac1daca2a6'",
        "assert head==remote=='143b5ac066a3716ef14dc42d5187a5bfeb4b1f01'")
replace("previous=RAW.parent/'d640_20261017'","previous=RAW.parent/'d643_20261017'")
replace("prepared=ROOT/'paper_results/ieee_tc/p2_backend/d640_3b_migration'",
        "prepared=ROOT/'paper_results/ieee_tc/p2_backend/d643_3b_initializer'")
replace("audit=read(prepared/'qualification.json');assert audit['passed'] and audit['inputs']['passed']\nfor path,sha in audit['audit']['refs'].items():assert p.digest(Path(path))==sha\nassert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==audit['inputs']['runner_sha256']",
        "audit=read(prepared/'qualification.json');assert audit['passed'] and audit['audit']['passed']\ninputs=read(prepared/'prepare.json');assert inputs['passed'] and inputs['cases']==368\nfor reference in inputs['source_refs']:assert p.digest(ROOT/reference['path'])==reference['sha256']\nassert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==audit['audit']['runner_sha256']")
replace("input_qualification=audit['inputs']","input_qualification=inputs")
code=code.replace('tc-d641-source','tc-d644-source').replace('run_d298_capacity_source.sh d641','run_d298_capacity_source.sh d644')
exec(compile(code,str(source),'exec'))
