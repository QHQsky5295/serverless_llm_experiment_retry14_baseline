"""Reuse complete source closure and the unmodified admission-on validator."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d642_20261017/collect.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
code=code.replace('d642_20261017','d644_20261017')
replace('p2_backend/d640_3b_migration/source_spec.json','p2_backend/d643_3b_initializer/source_spec.json')
replace("assert len(samples)==360", "assert len(samples)==360\nassert 'ieee_admission_profile' in run['model_config']\nsave('completed_service_samples.json',dict(samples=samples,source_sha256=p.digest(RAW/'source1.json'),production_profile_frozen=False))")
replace("kind='d642_complete_3b_source_measurement_v1'", "kind='d644_complete_3b_admission_source_measurement_v1'")
replace('main_performance_point=False,full_profile_eligible=False',
        'main_performance_point=False,full_profile_eligible=False,admission_enabled_timing_verified=True,timing_profiles_exported=False')
replace('Source-only measured intervals, not Full/admission initialization or SLO evidence. Host file/tensor representations are separate. Prior D641 changed compiler/page cache initial state; no causal startup speedup claim.',
        'Admission-enabled source measurements, not Full workload or common SLO qualification. Historical controller retained but not run by source collector. Host file/tensor representations differ; no startup causal attribution.')
replace("'coverage.json','launch_gate.json')", "'coverage.json','launch_gate.json','completed_service_samples.json')")
ast.parse(code)
exec(compile(code,str(source),'exec'))
