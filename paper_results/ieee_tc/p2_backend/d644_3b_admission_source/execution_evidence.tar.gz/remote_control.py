"""Same frozen remote service, unique campaign ownership and receipt paths."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d641_20261017/remote_control.py')
code=source.read_text().replace('d641_20261017','d644_20261017').replace('d641-source','d644-source').replace('d636->d641','d636->d644')
exec(compile(code,str(source),'exec'))
