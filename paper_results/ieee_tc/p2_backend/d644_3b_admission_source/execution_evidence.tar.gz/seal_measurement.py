"""Reuse explicit tested checkpoint for complete admission-enabled evidence."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'","OUT=ROOT/'paper_results/ieee_tc/p2_backend/d644_3b_admission_source'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'","=='143b5ac066a3716ef14dc42d5187a5bfeb4b1f01'")
begin=code.index('reg=read(RAW/');end=code.index('preserved={',begin)
code=code[:begin]+'''audit=read(RAW/'measurement_audit.json')
assert audit['passed'] and audit['experiment_pass'] and audit['request_cases']==368
assert audit['admission_enabled_timing_verified']
for name,sha in audit['evidence'].items():assert p.digest(RAW/name)==sha
for phase in ('start','analysis'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert not Path(read(RAW/'local_cleanup.json')['identity']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
gate=p.preflight([ROOT],32*1024*1024);assert gate['preflight_pass'],gate['issues']
save(RAW/'measurement_seal_gate.json',gate)
''' +code[end:]
begin=code.index('members=[RAW/name');end=code.index('\nfor path in members:',begin)
code=code[:begin]+'''members=[RAW/name for name in ('start.py','remote_control.py','close.py','collect.py','seal_measurement.py',
    'start_identity.json','start_receipt.json','start_closure.json','launch_gate.json','preflight.json',
    'launcher_identity.json','local_cleanup.json','analysis_identity.json','analysis_closure.json','measurement_audit.json',
    'coverage.json','completed_service_samples.json','source1_launch.json','source_commit.txt','source1_launcher.log',
    'remote_start.log','remote_start_procedure.json','remote_stop_procedure.json','remote_health.json',
    'remote_stop.log','remote_stop.json','remote_transfers.jsonl','remote_monitor.log','measurement_seal_gate.json')]
members += [RAW/'source1_launch.launch'/name for name in ('service.log','exec_receipt.json','watchdog.jsonl','watchdog.stderr')]
assert len({path.name for path in members})==len(members)
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
''' +code[end:]
begin=code.index('test_counts={');end=code.index("save(OUT/'qualification.json'",begin)
code=code[:begin]+'''test_counts={'native_cases':368,'measured_cases':360,'retained_warmups':8}
record=dict(passed=True,experiment_pass=True,native_source_validation=True,full_performance_run=False,
    parent_commit='143b5ac066a3716ef14dc42d5187a5bfeb4b1f01',audit=audit,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    source_run=dict(path=str(RAW/'source1.json'),sha256=p.digest(RAW/'source1.json')),
    archive_members={path.name:dict(path=str(path),sha256=p.digest(path)) for path in members},
    caveat='Admission-enabled source measurement, not Full workload or common SLO qualification; timing export pending.')
''' +code[end:]
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D644_3B_ADMISSION_SOURCE_MEASUREMENT.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: retain complete current 3B admission source measurements (D644)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
