"""Reuse bounded CPU qualification: source identity + native CPU oracle, no GPU."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
import urllib.request

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
PUB = ROOT / 'paper_results/ieee_tc/p2_backend/d520_metadata_lowering'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def main():
    own = p.scope_identity(p.cg_path().name)
    save(RAW / 'cpu_identity.json', own)
    group = Path(own['path'])
    assert (group / 'memory.high').read_text().strip() == str(3 * p.GIB)
    assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
    assert (group / 'memory.swap.max').read_text().strip() == '0'
    assert os.sched_getaffinity(0) == {2, 3, 26, 27}
    assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
    assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    assert p.preflight([ROOT], p.GIB)['preflight_pass']
    assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
    assert protected['pass'] and protected['entry_count'] == 147
    assert p.digest(ROOT / 'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
    subprocess.run(['git', 'diff', '--exit-code', 'db44e8f068eb30c69466f32ad3d147ffbc45f9e2', '--', 'scripts/run_all_experiments.py'], cwd=ROOT, check=True)
    sites = Path(sys.prefix) / 'lib/python3.12/site-packages'
    sources = []
    for name in ('lora/ops/triton_ops/lora_kernel_metadata.py', 'lora/punica_wrapper/punica_gpu.py',
                 'lora/punica_wrapper/utils.py', 'lora/model_manager.py', 'v1/worker/gpu/async_utils.py'):
        local = sites / 'vllm' / name
        url = 'https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/vllm/' + name
        with urllib.request.urlopen(url, timeout=30) as response:
            data = response.read(262145)
        assert len(data) < 262145
        downloaded = hashlib.sha256(data).hexdigest()
        sources.append(dict(path=str(local), sha256=p.digest(local), official_url=url,
                            official_sha256=downloaded, byte_equal=downloaded == p.digest(local)))
    save(RAW / 'source_identity.json', sources)
    assert all(item['byte_equal'] for item in sources)
    with (RAW / 'cpu_tests.log').open('x') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromNames([
                'tests.test_ieee_tc_lora_metadata_lowering',
                'tests.test_ieee_tc_core_timing', 'tests.test_basic_smoke']))
    qualification = dict(passed=result.wasSuccessful() and not result.skipped,
                         tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                         skipped=len(result.skipped), sources=sources, protected=protected,
                         serving_integration=False, gpu_qualified=False, performance_qualified=False,
                         original_metadata_oracle_cases=96, scope=own,
                         refs={str(ROOT / name):p.digest(ROOT / name) for name in (
                             'faaslora/utils/lora_metadata.py', 'tests/test_ieee_tc_lora_metadata_lowering.py',
                             'scripts/run_all_experiments.py', 'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
                             'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')})
    save(RAW / 'cpu_result.json', qualification)
    if not qualification['passed']:
        raise RuntimeError('CPU qualification failed; preserve attempt')
    PUB.mkdir(parents=True, exist_ok=False)
    save(PUB / 'cpu_qualification.json', qualification)
    assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
    print(json.dumps(dict(passed=True, tests=result.testsRun, native_metadata_cases=96, gpu=False)))


if __name__ == '__main__':
    main()
