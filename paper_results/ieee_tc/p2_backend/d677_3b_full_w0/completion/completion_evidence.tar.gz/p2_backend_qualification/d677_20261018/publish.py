"""Reuse complete-run sealing; preserve D677 prelaunch and every observed outcome."""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d660_20261018/publish.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'b2b65c513b52e42c15486f8b50422d5df9307ebb38505c3516a312d51a53ed27'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d660_3b_full_w0'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d677_3b_full_w0/completion'")
replace("expected_head='24208f8d9bdbbbb2e667060b57d7d6b1f18184c8'",
        "expected_head='cdb1211b75b9667c666d2c383be2b245cc6737b4'")
replace("assert audit['passed'] and audit['protocol_bound_count']==4000",
        """assert audit['passed'] and audit['protocol_bound_count']==4000
assert audit['host_transaction']['passed']
assert audit['proactive_host_transaction']['passed']
assert audit['proactive_host_transaction']['storage_counts']['same_transaction_proactive_host_activation_v1']>0
assert p.digest(ROOT/'faaslora/memory/gpu_monitor.py')=='7ed440e00431f03af907155a730b0075e5bf4919c9a3203260bae4cfb3cc6def'
assert p.digest(ROOT/'faaslora/memory/residency_manager.py')=='0cacfa5fc923e0c911ff1a62a0c26fdc9f5f7830e4eb4687edcec81810bd4f17'""")
replace("assert OUT.is_dir() and not (OUT/'audit.json').exists()\nsubprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)",
        """assert OUT.parent.is_dir() and not OUT.exists()
prelaunch=OUT.parent
assert p.digest(prelaunch/'result.sha256')=='73b128db25d2a7401a066b8aad9b3ab6e1c90ec89ab105c510cffa06dafe0692'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=prelaunch,check=True,stdout=subprocess.DEVNULL)
assert read(RAW/'backup_receipt.json')['passed']
OUT.mkdir()""")
replace("'backup_identity.json','backup_receipt.json','backup_closure.json')]",
        """'backup_identity.json','backup_receipt.json','backup_closure.json')]
members += [source, RAW.parent/'d668_20261018'/'close.py']""")
replace("assert joint==3575 and audit['protocol_bound_count']==4000",
        """assert 0<=joint<=4000 and audit['protocol_bound_count']==4000
previous_path=ROOT/'paper_results/ieee_tc/p2_backend/d672_3b_full_w0/completion/audit.json'
assert p.digest(previous_path)=='df21f561a8122fce11fe76b44562ead36dd09eab3e8a503e5e1201a0130523b6'
previous=read(previous_path)
assert previous['workload_identity']==audit['workload_identity']
assert previous['native_tokens']==audit['native_tokens']
metrics=('mean_ttft_ms','p95_ttft_ms','mean_tpot_ms','p95_tpot_ms','mean_e2e_ms','physical_gpu_seconds')
comparison=dict(kind='d677_vs_d672_complete_w0_single_observation_v1',
    previous_audit=dict(path=str(previous_path),sha256=p.digest(previous_path)),
    current_audit_sha256=p.digest(RAW/'analysis1.log'),
    workload_identity=audit['workload_identity'],native_tokens=audit['native_tokens'],
    previous_joint_count=previous['common_threshold_joint_count'],current_joint_count=joint,
    joint_delta_percentage_points=(joint-previous['common_threshold_joint_count'])/40,
    metrics=[dict(metric=k,previous=previous['stats'][k],current=audit['stats'][k],
        lower_better_improvement_percent=100*(previous['stats'][k]-audit['stats'][k])/previous['stats'][k]) for k in metrics],
    previous_stage_means_ms=previous['stage_means_ms'],current_stage_means_ms=audit['stage_means_ms'],
    previous_phases=previous['source_order_phases'],current_phases=audit['source_order_phases'],
    previous_remote_transfers=previous['remote_transfers'],current_remote_transfers=audit['remote_transfers'],
    previous_remote_wire_bytes=previous['remote_wire_bytes'],current_remote_wire_bytes=audit['remote_wire_bytes'],
    observed_joint_and_resource_improvement=joint>previous['common_threshold_joint_count'] and u<previous['stats']['physical_gpu_seconds'],
    performance_goal_met=False,accepted_as_final=False,confidence_interval=None,independent_holdout=False,
    caveat='Known fixed workload, one observation per version. Retain all gains and regressions without result filtering; no causal percentage attribution, numerical-proof upgrade, or complete G1/G2 claim.')
save(OUT/'comparison_d672.json',comparison)
files+=['comparison_d672.json']""")
replace("kind='d660_3b_complete_w0_seal_v1'", "kind='d677_proactive_host_transaction_complete_w0_seal_v1'")
replace("joint_slo_fraction=joint/4000,joint_slo_pass=False,",
        """joint_slo_fraction=joint/4000,joint_slo_pass=joint>=3800,
    host_transaction=audit['host_transaction'],
    proactive_host_transaction=audit['proactive_host_transaction'],
    immutable_prelaunch_sha256=p.digest(prelaunch/'result.sha256'),
    comparison_sha256=p.digest(OUT/'comparison_d672.json'),
    observed_joint_and_resource_improvement=comparison['observed_joint_and_resource_improvement'],
    accepted_as_final=False,""")
replace("caveat='W0 complete native-binding/count/timing observation, not independent numerical qualification, canonical matched cross-system comparison, or G1/G2 success; all 8 phases below .95.'",
        "caveat='W0 complete native-binding/count/timing observation; numerical proof remains unknown, cross-system map audit and W1/W2 remain open. Single-run changes and common-threshold attainment do not establish full G1/G2 success.'")
replace("no_figures=True,no_runtime_source_change=True,",
        "no_figures=True,publication_runtime_source_changed=False,")
replace("next_action='Retained-data diagnosis of persistent 3B wait/preparation/control and scaling occupancy, then one falsifiable candidate if supported; no W1/W2 launch before resolving this W0 shortfall.'",
        "next_action='Interpret this immutable observation against D672 and retained stage/phase evidence before choosing the next main-line action. No same-key repeat, threshold change or numerical-proof upgrade; verify storage before any new heavy task.'")
replace("names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D660_3B_FULL_W0.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D677_3B_FULL_W0.md','docs/ieee_tc/GPU_RESOURCE_METRIC_PRECEDENTS_20261018.md']")
replace('tc: seal complete 3B Full W0 and retained SLO shortfall (D660)',
        'tc: seal proactive HOST full 3B observation and resource metric evidence (D677)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D677 completion adaptation parsed; no outputs, staging or publication.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no args or --check-only')
