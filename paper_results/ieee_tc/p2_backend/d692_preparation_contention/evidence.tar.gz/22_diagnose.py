"""Reuse sealed D684 streams and the existing input-turn auditor, no replay.

Inventory all current full-source consumers before proposing another change.
This does not estimate counterfactual latency or treat a step as a token event.
"""
import ast
import collections
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
BASE = ROOT/'paper_results/ieee_tc/p2_backend/d684_3b_control_prefix1/completion'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import summarize_core_host_spans


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def stats(values):
    values = sorted(values)
    if not values:
        return dict(n=0, mean=None, p50=None, p95=None, maximum=None)
    return dict(n=len(values), mean=math.fsum(values)/len(values),
        p50=values[math.ceil(.5*len(values))-1],
        p95=values[math.ceil(.95*len(values))-1], maximum=values[-1])


identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
save(RAW/'analysis_identity.json', identity)
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 32*1024*1024)
assert not any('host_memory_below_stop' in v or 'filesystem_below_stop' in v for v in gate['issues'])
save(RAW/'analysis_resource_gate.json', gate)
refs = {}


def ref(path, expected=None):
    digest = p.digest(path)
    if expected is not None:
        assert digest == expected, path
    refs[str(path)] = digest
    return path


sealed = {}
for line in (BASE/'result.sha256').read_text().splitlines():
    sha, name = line.split('  ', 1)
    sealed[name] = sha
for name in ('core_timing/summary.json', 'operation_detail1/operations.csv'):
    ref(BASE/name, sealed[name])
source = ref(ROOT/'scripts/run_all_experiments.py',
    'f677e6010ee9a3ba9bfbd391bad03eace9719acce23e3d7e036d0dbf921ad0e4')
for name, sha in (
    ('faaslora/memory/gpu_monitor.py', '213cc94b070a1b3e0b0b1da9decdc5d0ffe0724c36aa57a892619a5c6d6eeb32'),
    ('faaslora/memory/residency_manager.py', '4a0269d2098d5dc4a6fc13fd3b88f0f7b446f535c0c37e77196dcdcd356ca6a6'),
    ('faaslora/scheduling/vllm_ieee_scheduler.py', 'b67b3fbf5b60a208bfdf476ee3af60d9c5180648045ed8f66094f13cf331e46f'),
    ('scripts/analyze_control_path_overhead.py', 'b3126b6c9c1e83aa2a499ae95bb4f4341f76a296d53d56453b567f01964f153e'),
    ('docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md', '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'),
    ('docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md', '193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d'),
):
    ref(ROOT/name, sha)
ref(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
    'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83')
for name in ('D514_GPU_EXECUTION_CONSUMER_PROOF.md', 'D516_FULL_W0_RESULT.md',
             'D519_RESTORED_STEP_DIAGNOSTIC.md', 'D329_HOST_STORAGE_DEPENDENCY_AUDIT.md',
             'D333_NATIVE_PENDING_GPU_TURN.md', 'D355_ATOMIC_CONTROL_INTERLEAVE.md'):
    ref(ROOT/'docs/ieee_tc'/name)
ref(ROOT/'faaslora/scheduling/core_interleave.py')
ref(ROOT/'faaslora/utils/core_timing.py')
ref(ROOT/'tests/test_ieee_tc_host_execution_projection.py')
ref(ROOT/'tests/test_ieee_tc_core_timing_analysis.py')

# Exhaustive static call inventory at this exact source SHA, not a timing claim.
class Calls(ast.NodeVisitor):
    def __init__(self):
        self.stack, self.rows = [], []

    def nested(self, node):
        self.stack.append(node.name)
        self.generic_visit(node)
        self.stack.pop()

    visit_ClassDef = visit_FunctionDef = visit_AsyncFunctionDef = nested

    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute) and node.func.attr == 'ieee_gpu_reference':
            operation = next((kw.value.value for kw in node.keywords
                if kw.arg == 'operation' and isinstance(kw.value, ast.Constant)), None)
            if operation in ('source_snapshot', 'routing_source_snapshot'):
                self.rows.append(dict(line=node.lineno, function='.'.join(self.stack), operation=operation))
        self.generic_visit(node)


calls = Calls()
calls.visit(ast.parse(source.read_text()))
decisions = {
    5073: ('physical', 'routing preparation class requires registered allocation graph and GPU geometry'),
    14045: ('physical', 'deferred HOST wake consumes actual allocator and exclusive storage accounting'),
    15196: ('physical', 'activation validates actual initialized native GPU layout'),
    19442: ('historical_rejected', 'same exact callsite as D514, reverted after complete D516; do not repeat'),
    19923: ('physical', 'planner uses whole registered capacity/alias graph and publishes routing evidence'),
    20026: ('diagnostic_physical', 'explicit proactive diagnostic preserves physical before-state'),
    20336: ('proof_required', 'file fallback lifetime boundary; hold_host_source is not a new physical graph check'),
    20451: ('identity_only_unattributed', 'staging identity consumer, but D684 has no per-caller timing attribution'),
    20491: ('physical', 'post-startup objective requires actual layout and capacity'),
}
assert {row['line'] for row in calls.rows} == set(decisions)
for row in calls.rows:
    row['classification'], row['reason'] = decisions[row['line']]
    row['changed'] = False
    row['attributed_wall_ms'] = None

# Independently check that the proposed GPU-execution projection already exists
# in history. Comments are not executable AST and are intentionally irrelevant.
old = subprocess.check_output(['git','show','cab2a4a^:scripts/run_all_experiments.py'], cwd=ROOT, text=True)
candidate = subprocess.check_output(['git','show','cab2a4a:scripts/run_all_experiments.py'], cwd=ROOT, text=True)
needle = "current = checked(await engine.ieee_gpu_reference(operation='source_snapshot'))"
assert old.count(needle) == 1
rewritten = old.replace(needle, needle.replace('source_snapshot', 'source_identity_snapshot'))
assert ast.dump(ast.parse(rewritten)) == ast.dump(ast.parse(candidate))
history = dict(commit='cab2a4a', production_ast_change='one source_snapshot -> source_identity_snapshot string',
    historical_parent_sha256=hashlib.sha256(old.encode()).hexdigest(),
    historical_candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),
    replayed=False, accepted=False)
del old, candidate, rewritten

with (RAW/'analysis_tests.txt').open('x') as log:
    suite = unittest.defaultTestLoader.loadTestsFromName('tests.test_ieee_tc_core_timing_analysis')
    tests = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
assert tests.wasSuccessful() and not tests.skipped
ref(RAW/'analysis_tests.txt')

manifest = read(BASE/'core_timing/summary.json')
all_turns, process_rows, source_count, span_count = [], [], 0, 0
for item in manifest['sources']:
    path = Path(item['path'])
    if path.suffix != '.jsonl':
        continue
    ref(path, item['sha256'])
    with path.open() as stream:
        header = json.loads(next(stream))
        assert header['event'] == 'native_core_host_timing_v1'
        assert header['host_inventory_timing'] == 'fresh_inventory_v1'
        events = [json.loads(line) for line in stream]
    audit = summarize_core_host_spans(events, include_input_turns=True, host_inventory=True)
    assert audit['complete'] and not audit['truncated'] and audit['closed']
    turns = audit['input_turns']
    for row in turns['records']:
        row['process'] = path.stem
    all_turns.extend(turns['records'])
    process_rows.append(dict(process=path.stem, spans=audit['spans'],
        input_turns=turns['input_turns'], nonempty_input_turns=len(turns['records']),
        empty_input_turns=turns['empty_input_turns'], work_input_turns=turns['work_input_turns']))
    source_count += 1
    span_count += audit['spans']
    del events, audit
assert source_count == 4 and span_count == 312160
groups = {}
for label, members in (
    ('all_nonempty', all_turns),
    ('work_nonempty', [r for r in all_turns if r['unfinished_before'] > 0]),
    ('work_with_utility', [r for r in all_turns if r['unfinished_before'] > 0 and r['utility_count'] > 0]),
    ('work_with_source_snapshot', [r for r in all_turns if r['unfinished_before'] > 0 and
        'collective_rpc/ieee_gpu_reference/source_snapshot' in r['utility_sequence'].split(';')]),
):
    groups[label] = dict(n=len(members), utility_count_histogram=dict(sorted(collections.Counter(
        r['utility_count'] for r in members).items())),
        multiple_utilities=sum(r['utility_count'] > 1 for r in members),
        following_root=dict(collections.Counter(str(r['following_root_boundary']) for r in members)),
        following_step_return=dict(collections.Counter(str(r['following_step_model_executed']) for r in members)),
        utility_wall_ms=stats([r['utility_ns']/1e6 for r in members]),
        client_after_first_utility_total_ms=sum(r['clients_after_first_utility_ns'] for r in members)/1e6)
with (BASE/'operation_detail1/operations.csv').open() as stream:
    operations = [r for r in csv.DictReader(stream)
        if r['label'].split('/')[-1] in ('source_snapshot','routing_source_snapshot','source_identity_snapshot')]
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
ref(ROOT/'configs/generated/lora_manifest_1000.json',
    '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df')
ref(Path(__file__))
save(RAW/'input_turns.json', all_turns)
ref(RAW/'input_turns.json')
report = dict(passed=True, kind='d691_current_source_consumers_and_native_turns_v1',
    production_changed=False, configuration_changed=False, inference_runs_added=0,
    n_correct=None, ranking_eligible=False, caller_inventory=calls.rows,
    caller_timing_identifiable=False, historical_repeat_check=history,
    tests_passed=tests.testsRun, processes=process_rows, span_count=span_count,
    input_turn_groups=groups, retained_operation_metrics=operations,
    protected=protected, source_refs=[dict(path=k,sha256=v) for k,v in sorted(refs.items())],
    caveats=['Work is measured at input-turn entry, not at every child operation.',
        'model_executed is the native step return, not per-request token progress or GPU-kernel time.',
        'A single synchronous utility can be expensive even when the next step is executed.',
        'Operation labels do not identify the controller caller, so no per-callsite duration is invented.',
        'No latency subtraction, counterfactual resource estimate, new performance run or configuration selection.',
        'D514/D516 rejection is historical single-run evidence, not proof every projection must regress.'])
save(RAW/'diagnosis.json', report)
save(RAW/'analysis_receipt.json', dict(passed=True, identity=identity,
    diagnosis_sha256=p.digest(RAW/'diagnosis.json'),
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True, tests=tests.testsRun, spans=span_count, groups=groups)), flush=True)
