"""Bounded CPU causal probe, not a production patch or performance experiment.

Apply one queue-dispatch candidate only in this process. Reuse the real runner,
reference owner and established native-cache fixtures; no new model artifacts.
"""
import asyncio
import collections
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.preloading.preloading_manager import OwnedMovementQueue, MovementOutcome
from tests.test_ieee_tc_gpu_references import OwnedNativePreparationPlans
from tests.test_ieee_tc_transfer_pressure import OwnedMovements


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def owner_eligible_pump(self):
    """Only final GPU actions share a serialized native owner; staging does not.

    No lock waiter occupies a global movement slot. Other owners and HOST/NVMe
    actions remain eligible; the original priority order is unchanged among
    eligible jobs. Deferral, cancellation, ownership and wake code is unmodified.
    """
    if self._closed:
        return
    running_jobs = [j for j in self._keys.values() if j['state'] == 'executing']
    running = len(running_jobs)
    gpu_owners = {j['key'][0] for j in running_jobs if j['key'][1] == 'gpu'}
    candidates = [j for j in self._keys.values() if j['state'] == 'pending'
                  and j['ready'] and j['intents']]
    def order(j):
        intents = tuple(j['intents'].values())
        return (not any(i['demand'] for i in intents), -max(i['density'] for i in intents),
                j['key'][2], ('gpu', 'host', 'nvme').index(j['key'][1]), j['key'][0])
    for job in sorted(candidates, key=order):
        if running >= self.max_concurrent:
            break
        gpu = job['key'][1] == 'gpu'
        if gpu and job['key'][0] in gpu_owners:
            continue
        job['state'] = 'executing'
        job['task'] = self._loop.create_task(self._execute(job))
        running += 1
        if gpu:
            gpu_owners.add(job['key'][0])


def fixture_count(pump):
    fixture = OwnedNativePreparationPlans()
    case, runner, slot, _ = fixture.make()
    initial_loads = len(case.case.loads)
    async def run():
        queue = runner._stack.preloading_manager.ieee_movements
        try:
            result = await runner._run_ieee_gpu_preparation_plan(slot=slot,
                objective=case.epoch(), target_adapter_ids=[2,4], trigger_reason='residency')
            attempts = runner._ieee_gpu_preparation_plans[-1]['attempts']
            assert {r['adapter_int_id'] for r in result} == {2,4}
            assert sum(r['reused'] for r in result) == 1
            assert len(case.case.loads)-initial_loads == 1
            assert not case.owner.snapshot()['live_leases']
            assert not case.owner.snapshot()['pending_preparation_targets']
            return dict(attempts=len(attempts), loads=1, completed_targets=len(result),
                reused_targets=1, reasons=dict(collections.Counter(
                    str(a['receipt'].get('reason')) for a in attempts)),
                source_queries=sum(call.kwargs.get('operation') == 'source_snapshot'
                    for call in slot.engine.ieee_gpu_reference.await_args_list),
                prepare_calls=slot.engine.ieee_prepare_host.await_count,
                live_leases=0, pending_targets=0)
        finally:
            await queue.close()
    try:
        with patch.object(OwnedMovementQueue, '_pump', pump):
            return asyncio.run(asyncio.wait_for(run(), 3))
    finally:
        fixture.doCleanups()


class CandidateBoundaries(OwnedMovements):
    # Inherit the existing 9 ownership/wake/order tests unchanged.
    async def test_busy_owner_does_not_reserve_global_slot_or_block_other_tiers(self):
        queue = OwnedMovementQueue(3)
        release, started = asyncio.Event(), []
        async def action(_, name):
            started.append(name)
            await release.wait()
            return MovementOutcome('completed', name)
        for name, owner, tier, density in (
            ('a1','A','gpu',10), ('a2','A','gpu',9),
            ('b1','B','gpu',8), ('ah','A','host',7)):
            self.submit(queue,name,lambda attempt,name=name:action(attempt,name),
                owner=owner,tier=tier,density=density,ready=False)
        try:
            queue.wake(owner_id='A', ready=True)
            queue.wake(owner_id='B', ready=True)
            await asyncio.sleep(0)
            self.assertEqual(set(started), {'a1','b1','ah'})
            self.assertEqual(sum(j['state']=='executing' for j in queue._keys.values()),3)
            release.set()
            values = await asyncio.gather(*(queue.wait(n) for n in ('a1','a2','b1','ah')))
            self.assertEqual(set(values), {'a1','a2','b1','ah'})
        finally:
            release.set()
            await queue.close()

    async def test_gpu_deferral_releases_owner_and_still_requires_observed_wake(self):
        queue, started = OwnedMovementQueue(3), []
        allow = False
        async def a(_):
            started.append('a')
            return MovementOutcome('completed','a') if allow else MovementOutcome('deferred',reason='capacity')
        async def b(_):
            started.append('b')
            return MovementOutcome('completed','b')
        self.submit(queue,'a',a,owner='A',tier='gpu',density=2,ready=False)
        self.submit(queue,'b',b,owner='A',tier='gpu',density=1,ready=False)
        try:
            queue.wake(owner_id='A',ready=True)
            self.assertEqual(await queue.wait('b'),'b')
            self.assertEqual(started,['a','b'])
            self.assertEqual(queue._intents['a']['state'],'deferred')
            allow = True
            queue.wake(owner_id='A')
            self.assertEqual(await queue.wait('a'),'a')
            self.assertEqual(started,['a','b','a'])
        finally:
            await queue.close()

    async def test_cancelled_gpu_writer_keeps_owner_until_actual_settlement(self):
        queue = OwnedMovementQueue(3)
        entered, cancelled, settle, sibling = (asyncio.Event() for _ in range(4))
        async def first(_):
            entered.set()
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                cancelled.set()
                await settle.wait()
                raise
        async def second(_):
            sibling.set()
            return MovementOutcome('completed',2)
        self.submit(queue,'first',first,owner='A',tier='gpu')
        await entered.wait()
        self.submit(queue,'second',second,owner='A',tier='gpu')
        cancel = asyncio.create_task(queue.withdraw('first'))
        try:
            await cancelled.wait()
            self.assertFalse(sibling.is_set())
            settle.set()
            await cancel
            self.assertEqual(await queue.wait('second'),2)
        finally:
            settle.set()
            await asyncio.gather(cancel,return_exceptions=True)
            await queue.close()


def main():
    identity = p.scope_identity(p.cg_path().name)
    group = Path(identity['path'])
    save(RAW/'analysis2_identity.json',identity)
    assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
    assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip() == '0'
    assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
        '--format=csv,noheader'],text=True).strip()
    gate = p.preflight([ROOT],32*1024*1024)
    assert not any('host_memory_below_stop' in v or 'filesystem_below_stop' in v for v in gate['issues'])
    save(RAW/'analysis2_resource_gate.json',gate)
    source = ROOT/'faaslora/preloading/preloading_manager.py'
    assert p.digest(source) == '825ead7f23686b8f501dd8d833cfa27111cc55fbbfda1191bed6a25b1f48654f'
    original = OwnedMovementQueue._pump
    parent = fixture_count(original)
    candidate = fixture_count(owner_eligible_pump)
    assert parent['attempts'] > candidate['attempts'] == 2
    assert parent['loads'] == candidate['loads'] == 1
    with patch.object(OwnedMovementQueue,'_pump',owner_eligible_pump):
        suite = unittest.TestSuite([
            unittest.defaultTestLoader.loadTestsFromTestCase(CandidateBoundaries),
            unittest.defaultTestLoader.loadTestsFromTestCase(OwnedNativePreparationPlans),
            unittest.defaultTestLoader.loadTestsFromName('tests.test_ieee_tc_host_execution_projection')])
        with (RAW/'owner_probe_tests.txt').open('x') as log:
            result = unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    assert result.wasSuccessful() and not result.skipped
    assert OwnedMovementQueue._pump is original
    assert p.digest(source) == '825ead7f23686b8f501dd8d833cfa27111cc55fbbfda1191bed6a25b1f48654f'
    protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
    assert protected['pass'] and protected['entry_count'] == 147
    refs = {str(path):p.digest(path) for path in (source, Path(__file__), RAW/'diagnosis.json',
        ROOT/'tests/test_ieee_tc_gpu_references.py', ROOT/'tests/test_ieee_tc_transfer_pressure.py',
        ROOT/'tests/test_ieee_tc_host_execution_projection.py', RAW/'owner_probe_tests.txt')}
    report = dict(passed=True,kind='d692_cpu_owner_eligibility_probe_v1',
        parent=parent,candidate=candidate,tests_passed=result.testsRun,
        production_changed=False,inference_runs_added=0,performance_gain_unknown=True,
        independent_numerical_qualification_unknown=True,protected=protected,
        source_refs=[dict(path=k,sha256=v) for k,v in sorted(refs.items())],
        caveats=['CPU native-cache fixtures prove operation order, not GPU latency or numerical correctness.',
            'The probe does not identify which recorded stale attempts were caused by siblings versus ordinary demand.',
            'Other-owner and HOST/NVMe work remains concurrent; this is not max_concurrent=1.',
            'Registration conflicts and ordinary-demand conflicts are not eliminated.',
            'No production acceptance or full regression/GPU qualification is implied.'])
    save(RAW/'owner_probe.json',report)
    save(RAW/'analysis2_receipt.json',dict(passed=True,identity=identity,
        report_sha256=p.digest(RAW/'owner_probe.json'),
        resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
    print(json.dumps(dict(passed=True,parent=parent,candidate=candidate,tests_passed=result.testsRun)),flush=True)


if __name__ == '__main__':
    main()
