"""Audit retained D684 preparation journals; no model execution or policy change.

Reuse D691 statistics/seal helpers and existing owner regression tests. Stream
one journal record at a time; keep a compact projection, never copy the outcome.
"""
import ast
import collections
import hashlib
import io
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import unittest

import ijson

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

parent = RAW.parent/'d691_20261018/diagnose.py'
assert p.digest(parent) == '7ffceb6021a6a38bf13b33bafcb8f48ce99569b326b23ddf404be96222cbbbcc'
defs = [n for n in ast.parse(parent.read_text()).body
        if isinstance(n, ast.FunctionDef) and n.name in ('read', 'save', 'stats')]
assert {n.name for n in defs} == {'read', 'save', 'stats'}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(parent), 'exec'))

PREFIXES = {f'mechanism_events.{name}.item': name for name in (
    '_ieee_residency_epochs', '_ieee_file_preparation_plans',
    '_ieee_gpu_preparation_plans', '_ieee_native_host_preparations')}


def journal_rows(stream):
    """Parse only the authoritative journals, not repeated coordination copies."""
    active = builder = None
    for prefix, event, value in ijson.parse(stream, use_float=True):
        if active is None:
            if prefix not in PREFIXES or event != 'start_map':
                continue
            active, builder = prefix, ijson.ObjectBuilder()
        builder.event(event, value)
        if prefix == active and event == 'end_map':
            yield PREFIXES[active], builder.value
            active = builder = None
    assert active is None


def project(name, row):
    scalar = ('plan_id', 'objective_sha256', 'planning_sha256', 'plan_sha256',
        'owner_id', 'target_replica', 'trigger_reason', 'activation_id', 'state',
        'started_at', 'finished_at', 'terminal_at', 'adapter_id', 'error_type')
    result = {k: row[k] for k in scalar if k in row}
    result['journal'] = name
    result['targets'] = row.get('targets')
    result['source_keys'] = sorted(row)
    registration = row.get('registration') or {}
    result['registered'] = registration.get('registered')
    result['registration_reason'] = registration.get('reason')
    supersession = row.get('preparation_supersession') or {}
    result['supersession_stage'] = supersession.get('stage')
    result['supersession_reason'] = (supersession.get('receipt') or {}).get('reason')
    result['closed'] = (row.get('close_receipt') or {}).get('closed')
    result['attempts'] = []
    for attempt in row.get('attempts', []):
        receipt = attempt.get('receipt') or {}
        res = {k: attempt[k] for k in ('attempt_id', 'adapter_int_id', 'state',
               'lease_id', 'prepare_rpc_submitted') if k in attempt}
        res['source_keys'] = sorted(attempt)
        res['receipt_keys'] = sorted(receipt)
        res['receipt'] = {k: receipt[k] for k in (
            'acquired', 'held', 'reason', 'preparation_reused_gpu',
            'native_load_invoked', 'proactive_admission_evaluated',
            'source_tier_before_acquisition', 'native_host_reused',
            'expected_epoch', 'epoch', 'planned_epoch', 'native_operation_applied') if k in receipt}
        res['released'] = (attempt.get('release_receipt') or {}).get('released')
        res['supersession_stage'] = (attempt.get('preparation_supersession') or {}).get('stage')
        result['attempts'].append(res)
    return result


def summarize(rows):
    attempts = [a for row in rows for a in row['attempts']]
    receipts = [a['receipt'] for a in attempts if a['receipt_keys']]
    durations = [(row.get('finished_at', row.get('terminal_at'))-row['started_at'])*1000
        for row in rows if 'started_at' in row and
        row.get('finished_at', row.get('terminal_at')) is not None]
    assert all(v >= 0 for v in durations)
    def count(items, key):
        return dict(sorted(collections.Counter(str(r.get(key)) for r in items).items()))
    return dict(records=len(rows), states=count(rows, 'state'),
        triggers=count(rows, 'trigger_reason'), registrations=count(rows, 'registered'),
        registration_reasons=count(rows, 'registration_reason'),
        supersession_stages=count(rows, 'supersession_stage'),
        supersession_reasons=count(rows, 'supersession_reason'),
        attempt_count=len(attempts), attempt_states=count(attempts, 'state'),
        receipt_count=len(receipts), receipt_reasons=count(receipts, 'reason'),
        gpu_reuse_count=sum(r.get('preparation_reused_gpu') is True for r in receipts),
        load_invoked=count(receipts, 'native_load_invoked'),
        acquired=count(receipts, 'acquired'), held=count(receipts, 'held'),
        admission_evaluated=count(receipts, 'proactive_admission_evaluated'),
        source_tiers=count(receipts, 'source_tier_before_acquisition'),
        zero_attempt_records=sum(not row['attempts'] for row in rows),
        targets=sum(len(row['targets']) for row in rows if row['targets'] is not None),
        duration_ms=stats(durations))


def unit_checks():
    # Do not count repeated outcome snapshots or similarly named nested fields.
    data = dict(mechanism_events={name: [dict(plan_id=name, attempts=[dict(
        state='completed', receipt=dict(preparation_reused_gpu=True,
        native_load_invoked=False, acquired=True))])] for name in PREFIXES.values()},
        coordination_after_shutdown=dict(_ieee_gpu_preparation_plans=[dict(plan_id='duplicate')]))
    rows = [project(name, row) for name, row in journal_rows(io.BytesIO(json.dumps(data).encode()))]
    assert len(rows) == 4 and all(r['plan_id'] != 'duplicate' for r in rows)
    counts = summarize(rows)
    assert counts['gpu_reuse_count'] == 4 and counts['load_invoked'] == {'False': 4}
    assert counts['duration_ms']['n'] == 0 and counts['source_tiers'] == {'None': 4}
    assert summarize([])['records'] == 0


unit_checks()
if sys.argv[1:] == ['--check-only']:
    print('D692 streaming/projection/missing-field checks passed; no writes.')
    raise SystemExit(0)
assert not sys.argv[1:]
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
save(RAW/'analysis_identity.json', identity)
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 32*1024*1024)
assert not any('host_memory_below_stop' in v or 'filesystem_below_stop' in v for v in gate['issues'])
save(RAW/'analysis_resource_gate.json', gate)
refs = {str(parent): p.digest(parent)}
def ref(path, expected=None):
    digest = p.digest(path)
    if expected is not None:
        assert digest == expected, path
    refs[str(path)] = digest
    return path

for name, sha in (
    ('scripts/run_all_experiments.py', 'f677e6010ee9a3ba9bfbd391bad03eace9719acce23e3d7e036d0dbf921ad0e4'),
    ('faaslora/memory/gpu_monitor.py', '213cc94b070a1b3e0b0b1da9decdc5d0ffe0724c36aa57a892619a5c6d6eeb32'),
    ('faaslora/memory/residency_manager.py', '4a0269d2098d5dc4a6fc13fd3b88f0f7b446f535c0c37e77196dcdcd356ca6a6'),
    ('docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md', '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'),
    ('docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md', '193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d'),
):
    ref(ROOT/name, sha)
ref(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
    'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83')
for name in ('D104_PREPARATION_SOURCE_DOMAIN.md', 'D329_HOST_STORAGE_DEPENDENCY_AUDIT.md',
             'D691_STATE_QUERY_CONSUMER_AUDIT.md'):
    ref(ROOT/'docs/ieee_tc'/name)
outcome = ref(RAW.parent/'d684_20261018/3b_full_w0_prefix1/launch.launch/physical_deployment/main_outcome.json',
    'd2235bf4c1c17f7ee2960f126cee898805f0538caa69d2683cfa992738dfcc39')
rows = []
with outcome.open('rb') as stream:
    for name, row in journal_rows(stream):
        rows.append(project(name, row))
assert {r['journal'] for r in rows} == set(PREFIXES.values())
by_journal = {name:summarize([r for r in rows if r['journal'] == name]) for name in PREFIXES.values()}
gpu = [r for r in rows if r['journal'] == '_ieee_gpu_preparation_plans']
assert len({r['plan_id'] for r in gpu}) == len(gpu)
by_gpu_state = {state:summarize([r for r in gpu if r['state'] == state])
    for state in sorted({r['state'] for r in gpu})}
with (RAW/'analysis_tests.txt').open('x') as log:
    done = subprocess.run(['/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python',
        '-m', 'unittest', '-v', 'tests.test_ieee_tc_gpu_references.OwnedNativePreparationPlans'],
        cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
assert done.returncode == 0
ref(ROOT/'tests/test_ieee_tc_gpu_references.py')
ref(RAW/'analysis_tests.txt')
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
ref(ROOT/'configs/generated/lora_manifest_1000.json',
    '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df')
save(RAW/'preparation_projection.json', rows)
ref(RAW/'preparation_projection.json')
ref(Path(__file__))
save(RAW/'diagnosis.json', dict(passed=True, kind='d692_preparation_journal_audit_v1',
    inference_runs_added=0, production_changed=False, configuration_changed=False,
    n_correct=None, ranking_eligible=False, planned_requests=1000,
    source_scope='D684 diagnostic prefix, not complete W0 performance',
    by_journal=by_journal, by_gpu_state=by_gpu_state,
    protected=protected, source_refs=[dict(path=k,sha256=v) for k,v in sorted(refs.items())],
    caveats=['Plan registration protects against proactive replacement, not ordinary demand eviction; it is not a physical pin.',
        'GPU reuse requires live owner revalidation; received registration does not prove readiness at later execution.',
        'Attempts, plan targets, actual loads and useful later service are distinct quantities.',
        'Missing receipt fields remain unknown, not zero or false.',
        'Preparation durations overlap other work; no counterfactual TTFT or GPU time is derived.',
        'Operation-level profile labels do not identify a plan/attempt caller.']))
save(RAW/'analysis_receipt.json', dict(passed=True, identity=identity,
    diagnosis_sha256=p.digest(RAW/'diagnosis.json'),
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True, by_journal=by_journal, by_gpu_state=by_gpu_state)), flush=True)
