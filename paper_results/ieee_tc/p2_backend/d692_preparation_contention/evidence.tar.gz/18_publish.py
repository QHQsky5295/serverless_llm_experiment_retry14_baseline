"""Reuse sealed explicit-path publication; include both closed CPU checks."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path(__file__).resolve().parent.parent/'d612_20261017/publish.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=data.decode()
for old,new in (
    ('d612_w2_quality_resource_diagnosis','d692_preparation_contention'),
    ('f72091155cd3bb258651fc461db11b9113c72faf','8a40221a27aa1080bf12fe613d4efc24a4502f9a'),
    ("for name in ('analysis',):", "for name in ('analysis','analysis2'):"),
    ("assert sum(x['n'] for x in diagnosis['matched_transitions'].values())==8000//2",
     "assert diagnosis['by_journal']['_ieee_gpu_preparation_plans']['receipt_count']==1512"),
    ("assert diagnosis['runs']['D607']['all']['joint']==3762",
     "assert diagnosis['by_journal']['_ieee_gpu_preparation_plans']['gpu_reuse_count']==12"),
    ("assert diagnosis['runs']['D611']['all']['joint']==3819",
     "probe=read(RAW/'owner_probe.json')\nassert probe['passed'] and probe['tests_passed']==40\n"
     "assert probe['parent']['attempts']==3 and probe['candidate']['attempts']==2\n"
     "assert read(RAW/'analysis2_receipt.json')['report_sha256']==p.digest(RAW/'owner_probe.json')\n"
     "for item in probe['source_refs']:assert p.digest(Path(item['path']))==item['sha256']"),
    ('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md','D692_PREPARATION_CONTENTION_AUDIT.md'),
    ("files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json')])",
     "files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*tests.txt')])"),
    ("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']",
     "files += [doc,RAW.parent/'d668_20261018/close.py',RAW.parent/'d612_20261017/publish.py',RAW.parent/'d691_20261018/diagnose.py']"),
    ('d612_reused_parent_closed_log_diagnosis_v1','d692_retained_preparation_contention_and_cpu_probe_v1'),
    ('diagnosis=diagnosis,protected=protected,','diagnosis=diagnosis,owner_probe=probe,protected=protected,'),
    ('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
     'tc: preserve preparation contention audit and isolated owner-order probe (D692)'),
):
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new)
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D692 explicit-path publication expansion passed; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no args or --check-only')
