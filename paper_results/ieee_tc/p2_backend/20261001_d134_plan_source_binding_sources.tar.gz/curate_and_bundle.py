"""Reuse D108 source-binding curation and D132 small-evidence bundle; no replay."""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

root=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw=root/'results/ieee_tc/p2_backend_qualification/d134_20261001'
parent=root/'paper_results/ieee_tc/p2_backend'
out=parent/'20261001_d134_plan_source_binding.json'
assert not out.exists()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for phase in ('red','green','verify'):
    name=f'primelora-d134-{phase}-20261001.scope'
    assert subprocess.check_output(['systemctl','--user','show',name,'-p','ActiveState','--value'],text=True).strip()=='inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
verification=json.loads((raw/'verification.json').read_text())
assert verification['protected']['pass'] and verification['protected']['entry_count']==147
assert verification['tests']==1059 and verification['unchanged_d133_frozen_sources']==157
for ref in verification['source_refs']:
    assert sha(Path(ref['path']))==ref['sha256']
red,green=(raw/'red.log').read_text(),(raw/'green.log').read_text()
assert 'Ran 1 test in 0.179s' in red and 'FAILED (errors=1)' in red
assert 'ValueError: native integer ID reused for a different adapter source' in red
assert 'UnresolvedTransferOperation: native HOST loading/release outcome unresolved' in red
assert 'Ran 1 test in 0.124s\n\nOK\n' in green
assert 'Exit status: 1' in (raw/'red_time.txt').read_text()
for phase in ('green','verify'):
    assert 'Exit status: 0' in (raw/f'{phase}_time.txt').read_text()
prior=raw.parent/'d133_20261001/full_full1_outcome_projection.json'
assert prior.stat().st_size<64*1024**2
assert sha(prior)=='a9c0ce5096d9861559e6bfc3420ac75c14ad5734e64c2a9a9ee11ac8bad336b4'
x=json.loads(prior.read_text())
adapter='medical_lora_0014'
replica='ieee-activation-649ad3b68d854c458b8a0278f4861618'
plans=x['mechanism_events']['_ieee_gpu_preparation_plans']
failed_plan=next(p for p in plans if p['plan_id']=='91755aed1ab846b3b3e40a3f8af43bf9')
preps=[p for p in x['mechanism_events']['_ieee_native_host_preparations']
       if p['adapter_id']==adapter and p['target_replica']==replica]
assert len(preps)==2 and preps[0]['attempts'][-1]['receipt']['epoch']==301
assert preps[0]['attempts'][-1]['release_receipt']['epoch']==303
assert preps[0]['content_sha256']==preps[1]['content_sha256']
assert preps[0]['source_path']!=preps[1]['source_path']
failed=preps[1]['attempts'][-1]
assert failed['state']=='native_outcome_unresolved' and failed['command']['expected_epoch']==1411
stale=preps[1]['attempts'][0]['receipt']
assert stale['epoch']==1411 and not stale['held'] and stale['reason']=='stale_snapshot'
aid=failed['command']['adapter_int_id']
assert aid==683755 and aid in stale['pending_preparation_targets']
assert aid not in stale['slot_adapter_ids'] and str(aid) not in stale['reference_counts']
assert not stale['host_source_reference_counts'] and not stale['staged_host_adapter_ids']
assert failed_plan['registration']['epoch']==1391 and aid in failed_plan['targets']
assert failed_plan['close_receipt']['epoch']==1411 and failed_plan['close_receipt']['closed']
assert not failed_plan['close_receipt']['pending_preparation_targets']
index=root/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
ids=[r['id'] for r in json.loads(index.read_text())['artifacts']]
native=collections.defaultdict(list)
for name in ids:native[int(hashlib.md5(name.encode()).hexdigest(),16)%999999+1].append(name)
assert len(ids)==len(native)==500 and native[aid]==[adapter]
requests=[dict(request_id=r['request_id'],
               source=r['retained_reference_evidence']['source_admission']['source'])
          for r in x['interrupted_replays'][0]['requests']
          if r['adapter_id']==adapter and r['instance_id']==replica and r['success']]
assert [r['source']['epoch'] for r in requests]==[340,524]
refs=[prior,index,raw/'verification.json',raw/'red.log',raw/'green.log',raw/'verify.log',
      raw/'test_plan_source_binding.sh',raw/'verify_plan_source_binding.sh',
      raw/'cleanup_verify.sh',raw/'cleanup_verify.log',Path(__file__),
      root/'docs/ieee_tc/D134_PLAN_SELECTED_SOURCE_BINDING.md']
result=dict(kind='d134_plan_selected_source_binding_v1',
    evidence_parent_commit='f5e10dbb051f1568d92ab29a6fe44827af8e1a07',
    d133_runtime_commit='30b07158788d080e5c51b93eedfa59a0a02bb2ca',
    production_changed=['faaslora/memory/residency_manager.py'],
    decision='correctness_candidate_passed_cpu_regression_ordinary_Full_required',
    full_replay_qualified=False,formal_performance_result=False,cuda_executed=False,
    red_green=dict(red='same_source_guard_and_unresolved_transfer_reproduced',
                   green='same_real_owner_selector_case_completed_and_released',
                   cpu_test_only=True,independent_performance_repetitions=0),
    d133_observations=dict(logical_adapters=500,native_integer_ids=500,collisions=[],
        failed_adapter=adapter,native_id=aid,content_sha256=preps[0]['content_sha256'],
        old_path=preps[0]['source_path'],new_path=preps[1]['source_path'],
        native_host_preparations=preps,prior_success_source_observations=requests,
        failed_plan=failed_plan,latest_pre_failure_negative_receipt=stale,
        exact_failure_internal_sources_exported=False,
        causal_scope='CPU counterexample proves a defect path; no fabricated complete D133 internal dictionary'),
    verification=verification,
    resource_limits=dict(memory_high_bytes=3*2**30,memory_max_bytes=4*2**30,
                         swap_max_bytes=0,cpus=[2,3,26,27]),
    unchanged=dict(formulas=True,profile=True,capacity=True,timeout=True,workload=True,remote=True),
    references=[
        dict(url='https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/vllm/lora/worker_manager.py',
             role='Native object identity and single-operation serialization, not multi-RPC atomicity or performance proof'),
        dict(url='https://www.usenix.org/conference/osdi24/presentation/wu-bingyang',
             role='Request/adapter dynamic orchestration context; not evidence for this local invariant')],
    source_sha256={str(p):sha(p) for p in refs},
    next='Scoped backup then one ordinary7B Full4000; do not replay the failed run unchanged or stack another optimizer')
with out.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False)
bundle=parent/'20261001_d134_plan_source_binding_sources.tar.gz'
assert not bundle.exists()
members={}
with tarfile.open(bundle,'x:gz') as archive:
    for p in sorted(raw.iterdir()):
        if not p.is_file() or p.stat().st_size>=2*1024**2 or p.suffix not in {'.py','.sh','.json','.txt','.log','.patch'}:continue
        if p.name in {'finalize.log','finalize_time.txt'}:continue
        data=p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        members[p.name]=hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames())==set(members)
    for name,expected in members.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected
with (parent/'20261001_d134_plan_source_binding_sources.sha256').open('x') as stream:
    stream.write(sha(bundle)+'  '+bundle.name+'\n')
with (parent/'20261001_d134_plan_source_binding_sources_members.json').open('x') as stream:
    json.dump(dict(bundle=bundle.name,member_sha256=members,member_checks_pass=True),stream,indent=2)
print(json.dumps(dict(bytes=bundle.stat().st_size,members=len(members),sha256=sha(bundle),
    output=str(out),tests=verification['tests'],protected=147)))

