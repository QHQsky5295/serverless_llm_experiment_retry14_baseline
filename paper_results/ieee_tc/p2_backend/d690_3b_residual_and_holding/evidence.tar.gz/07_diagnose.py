"""Reuse D683/D661 streaming analysis for closed D688, without inference.

Keep the frozen evaluation, actual physical holding, and all matched requests.
This is a residual diagnosis, not a counterfactual performance prediction.
"""
import ast
import collections
import hashlib
import json
import math
from pathlib import Path
from statistics import fmean
import sys

RAW = Path(__file__).resolve().parent
BASE = RAW.parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
SOURCES = {
    BASE/'d661_20261018/diagnose.py': 'd776ad4e728f628697ee7502ef378e55ece53bd528fcc8ac9906a0f104f49f40',
    BASE/'d679_20261018/diagnose.py': '742be4843d75dcfc803eb07cfccb27496c7e73dbfd37c58dfb31f636b341b437',
    BASE/'d683_20261018/diagnosis.json': 'a23ec9209cd6425fc69496abe394305269cb56b63fe5c1656c11d8bd7357c3cf',
    BASE/'d683_20261018/d682_projection.json': 'dcd16d194d36aa9ae114911f9a7bc73d2ccfba7a40d2ee7a640205323f93017a',
    BASE/'d683_20261018/d682_controls.json': '067d5caf2cba14c414cf2d92b73dfeea0199e12d8cec7fccf6c34243176f214a',
    BASE/'d683_20261018/projection_diagnosis.json': '9e14a8676f1f946cab6b0223fef98db981a1a8158cd4a092f299852f5543cf81',
}
source = BASE/'d661_20261018/diagnose.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCES[source]
tree = ast.parse(source.read_text())
assert isinstance(tree.body[-1], ast.If)
tree.body.pop()
outer = {'__file__': __file__, '__name__': '__checked_d690_expansion__'}
exec(compile(tree, str(source), 'exec'), outer)
code = outer['code']
for old, new in (
    ('d660', 'd688'), ('D660', 'D688'),
    ('p2_backend/d688_3b_full_w0/audit.json', 'p2_backend/d688_3b_full_w0/completion/audit.json'),
    ('31e3a5c042961983fcbfd1bd926141e66b153aab892e1432c8914b1b086e89d9',
     '8ae706f20336ae99e4368482b8dfffd77d7b453b7cafc2dfd2e7a14e4b746f8e'),
    ('==3575', '==3645'), ('32*1024*1024', '64*1024*1024'),
    ("RAW/'diagnosis.json'", "RAW/'projection_diagnosis.json'"),
    ("RAW/'analysis_receipt.json'", "RAW/'projection_receipt.json'"),
    ('d661_3b_w0_residual_and_holding_v1', 'd690_d688_reused_projection_v1'),
):
    assert old in code, old
    code = code.replace(old, new)
ast.parse(code)
old = BASE/'d679_20261018/diagnose.py'
assert hashlib.sha256(old.read_bytes()).hexdigest() == SOURCES[old]
tree = ast.parse(old.read_text())
names = {'stretches', 'stretch_summary', 'control_audit', 'request_audit', 'unit_checks'}
defs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert {n.name for n in defs} == names
exec(compile(ast.Module(body=defs, type_ignores=[]), str(old), 'exec'))
unit_checks()
if sys.argv[1:] == ['--check-only']:
    print('D690 sealed streaming expansion and cooldown checks passed; no writes.')
    raise SystemExit(0)
assert not sys.argv[1:]
ns = {'__file__': __file__, '__name__': '__d690_projection__'}
exec(compile(code, str(source), 'exec'), ns)
p, read, save = ns['p'], ns['read'], ns['save']
summarize, percentile = ns['summarize'], ns['percentile']
for path, sha in SOURCES.items():
    assert p.digest(path) == sha, path
old_rows = read(BASE/'d683_20261018/d682_projection.json')
old_controls = read(BASE/'d683_20261018/d682_controls.json')
old_run = read(BASE/'d683_20261018/projection_diagnosis.json')['runs']['D682']
new_rows = sorted(ns['projections']['D688'].values(), key=lambda r:r['source_index'])
new_controls = read(RAW/'d688_controls.json')
new_run = ns['runs']['D688']
assert old_run['workload_identity'] == new_run['workload_identity']
before, after = ({r['request_id']:r for r in rows} for rows in (old_rows, new_rows))
assert len(before) == len(after) == 4000 and set(before) == set(after)
for rid in before:
    for key in ('source_index','request_id','adapter_id','arrival_s','target','prompt_tokens','ttft_limit_ms','tpot_limit_ms'):
        assert before[rid][key] == after[rid][key], (rid,key)
transitions = {}
for a in (True, False):
    for b in (True, False):
        ids = [rid for rid in before if before[rid]['joint'] == a and after[rid]['joint'] == b]
        transitions[('good' if a else 'bad')+'_to_'+('good' if b else 'bad')] = dict(
            n=len(ids), old=summarize([before[r] for r in ids]),
            new=summarize([after[r] for r in ids]))
assert sum(v['n'] for v in transitions.values()) == 4000
assert transitions['bad_to_good']['n']-transitions['good_to_bad']['n'] == -49
runs = {}
for tag, rows, controls, run in (('D682',old_rows,old_controls,old_run), ('D688',new_rows,new_controls,new_run)):
    requests = request_audit(rows)
    # Preserve separately observed populations. There is no assumption that
    # cached/no-overlap requests are controlled or free of management work.
    conditional = {}
    for name, members in (
        ('all_joint_bad',[r for r in rows if not r['joint']]),
        ('ttft_only',[r for r in rows if not r['ttft_good'] and r['tpot_good']]),
        ('tpot_only',[r for r in rows if r['ttft_good'] and not r['tpot_good']]),
        ('both_bad',[r for r in rows if not r['ttft_good'] and not r['tpot_good']]),
        ('gpu_joint_bad',[r for r in rows if r['tier']=='gpu' and not r['joint']]),
    ):
        conditional[name] = dict(summary=summarize(members),
            natural_scaleout_overlap_count=sum(r['scaleout_overlap_before_first_ms']>0 for r in members),
            short_le31_count=sum(r['target']<=31 for r in members))
    runs[tag] = dict(control=control_audit(controls,ns['limits'],max(r['arrival_s'] for r in rows)),
        requests=requests,holding_quarters=run['holding_quarters'],
        control_changes=run['control_changes'],residual_classes=run['violation_classes'],
        resource_seconds=run['stats']['physical_gpu_seconds'],
        scalar_diagnostics=run['scalar_diagnostics'],by_tier=run['by_tier'],
        bad_by_tier=run['bad_by_tier'],conditional_populations=conditional,
        control_ttft_p95_summary_ms=run['control_ttft_p95_summary_ms'],
        observed_scaleout_intervals_s=run['actual_scaleout_intervals_s'])
refs = {str(path):sha for path,sha in SOURCES.items()}
for row in ns['refs']:refs[row['path']] = row['sha256']
for path in (Path(__file__), RAW/'projection_diagnosis.json', RAW/'d688_projection.json', RAW/'d688_controls.json'):
    refs[str(path)] = p.digest(path)
report = dict(passed=True,kind='d690_d688_retained_residual_and_holding_v1',
    inference_runs_added=0,production_changed=False,configuration_changed=False,
    n_correct=None,ranking_eligible=False,confidence_interval=None,replicates_per_version=1,
    runs=runs,matched_transitions=transitions,
    source_refs=[dict(path=path,sha256=sha) for path,sha in sorted(refs.items())],
    caveats=['Matched inputs do not fix endogenous routing, loading, batching or control feedback.',
        'No hypothetical GPU saving or subtraction of event spans from user latency.',
        'Observed short decode excess is not a measured removable CPU cost.',
        'Stage timing is not CPU-function or GPU-kernel timing; nested routing is not additive.',
        'D687 production candidate was rejected by complete D688 evidence and already reverted in D689.',
        'Single-run development observations, not causal attribution or independent numerical qualification.'])
save(RAW/'diagnosis.json',report)
group = Path(ns['identity']['path'])
save(RAW/'analysis_receipt.json',dict(passed=True,identity=ns['identity'],
    diagnosis_sha256=p.digest(RAW/'diagnosis.json'),source_sha256=p.digest(Path(__file__)),
    resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,transitions={k:v['n'] for k,v in transitions.items()},
    runs={tag:dict(joint=data['requests']['all']['joint'],control=data['control']) for tag,data in runs.items()})),flush=True)
