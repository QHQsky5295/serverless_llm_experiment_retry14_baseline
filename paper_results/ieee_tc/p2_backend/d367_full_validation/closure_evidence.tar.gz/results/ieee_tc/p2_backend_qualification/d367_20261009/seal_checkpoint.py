"""Seal D367's offline evidence without archiving the large raw payloads.

The raw result, watchdog and remote monitor remain at their immutable paths and
are recorded by SHA.  The small closure archive contains the curated projections,
receipts and source/configuration metadata needed to audit the claim boundary.
"""
import ast
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import tarfile

ROOT = pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = ROOT/'results/ieee_tc/p2_backend_qualification/d367_20261009'
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d367_full_validation'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p  # noqa: E402


def digest(path: pathlib.Path) -> str:
    return p.digest(path)


def read(path: pathlib.Path):
    return json.loads(path.read_text())


def secret_check(data: bytes):
    token_path = pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token')
    if token_path.exists():
        token = token_path.read_bytes().strip()
        assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----', data)
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})', data)


def main():
    assert not subprocess.check_output(
        ['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT, text=True).strip()
    assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
    protocol = ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
    assert digest(protocol) == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'

    audit = read(RAW/'offline_execution_receipt.json')
    assert audit['passed'] and audit['returncodes'] == [0]
    completion = read(RAW/'completion_receipt.json')
    assert completion['n_plan'] == completion['n_terminal'] == completion['n_native_contract_complete'] == 4000
    assert completion['n_failed_from_terminal_journal'] == 0
    assert completion['n_correct'] is None and completion['formal_qualification'] is False
    assert completion['ranking_eligible'] is False and completion['no_figures'] is True
    source = ROOT/'results/ieee_tc/p2_backend_qualification/d367_20261009/7b_full_w0/experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d367_7b_full_w0.json'
    physical = ROOT/'results/ieee_tc/p2_backend_qualification/d367_20261009/7b_full_w0/launch.launch/physical_deployment/physical_resource_summary.json'
    assert digest(source) == completion['source_sha256']
    assert read(physical)['physical_gpu_seconds_total'] == completion['physical_gpu_seconds_total']

    validated = ROOT/'paper_results/ieee_tc/p2_backend/d367_full_w0/validated1'
    context = ROOT/'paper_results/ieee_tc/p2_backend/d367_full_w0/context1'
    for directory in (validated, context):
        manifest = read(directory/'manifest.json')
        for name, sha in manifest['outputs'].items():
            assert digest(directory/name) == sha

    # Keep the archive bounded: large raw result/monitor/watchdog files remain
    # in place and are listed in excluded_refs with immutable hashes.
    selected = []
    selected.extend(sorted(validated.iterdir()))
    selected.extend(sorted(context.iterdir()))
    selected.extend([
        ROOT/'configs/ieee_tc/20261009_d367_7b_full_w0.yaml',
        ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',
        ROOT/'docs/ieee_tc/D367_FULL_FILE_DEMAND_VALIDATION.md',
        ROOT/'scripts/ieee_tc/analyze_d297_full.py',
        ROOT/'scripts/ieee_tc/check_d299_full_context.py',
        RAW/'completion_receipt.json', RAW/'collection_receipt.json',
        RAW/'local_cleanup.json', RAW/'remote_stop.json', RAW/'remote_health.json',
        RAW/'launch_gate.json', RAW/'prelaunch_binding.json', RAW/'preparation_scope.json',
        RAW/'preparation_tests1_receipt.json', RAW/'remote_transfers.jsonl',
        RAW/'remote_start.log', RAW/'remote_stop.log', RAW/'binding1.log', RAW/'tests1.log',
        RAW/'closure_attempt1_failure.json', RAW/'audit1.log', RAW/'offline_execution_receipt.json',
        RAW/'run_audit.py', RAW/'seal_checkpoint.py', RAW/'finish_backup.py',
    ])
    selected = [path for path in selected if path.exists() and path.is_file()]
    selected = sorted(set(selected))
    for path in selected:
        data = path.read_bytes()
        secret_check(data)
        if path.suffix == '.py':
            ast.parse(data)
        if path.suffix == '.sh':
            subprocess.run(['bash', '-n', str(path)], check=True)

    raw_root = RAW/'7b_full_w0'
    excluded = []
    for path in sorted([source, RAW/'remote_monitor.log', raw_root/'launch.launch/watchdog.jsonl',
                        raw_root/'launch.launch/replay.jsonl', raw_root/'launch.launch/service.log']):
        if path.exists() and path not in selected:
            excluded.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)))

    archive = OUT/'closure_evidence.tar.gz'
    assert not archive.exists()
    with tarfile.open(archive, 'x:gz') as bundle:
        for path in selected:
            bundle.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    with tarfile.open(archive) as bundle:
        members = {member.name: member for member in bundle.getmembers()}
        assert len(members) == len(selected)
        for path in selected:
            member = members[str(path.relative_to(ROOT))]
            extracted = bundle.extractfile(member).read()
            assert hashlib.sha256(extracted).hexdigest() == digest(path)

    protected = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
    known = pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
    assert protected['entry_count'] == 147 and protected['changed'] == [str(known)]
    assert digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
    record = {
        'kind': 'd367_full_closure_checkpoint_v1',
        'passed': True,
        'source_sha256': completion['source_sha256'],
        'source_path': str(source),
        'source_bytes': source.stat().st_size,
        'physical_gpu_seconds_total': completion['physical_gpu_seconds_total'],
        'n_plan': completion['n_plan'], 'n_terminal': completion['n_terminal'],
        'n_native_contract_complete': completion['n_native_contract_complete'],
        'n_correct': None, 'formal_qualification': False, 'ranking_eligible': False,
        'no_figures': True, 'protected': protected,
        'archive': {'path': str(archive), 'sha256': digest(archive),
                    'bytes': archive.stat().st_size, 'members': len(selected)},
        'included_refs': [dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))
                          for path in selected],
        'excluded_large_refs': excluded,
        'plan_sha256': p.check_plan(), 'metric_protocol_sha256': digest(protocol),
        'next': '7B optimization/qualification decision; then 3B, baselines, ablations and sensitivity',
    }
    checkpoint = OUT/'closure_checkpoint.json'
    with checkpoint.open('x') as handle:
        json.dump(record, handle, indent=2)
    checksum = OUT/'closure.sha256'
    with checksum.open('x') as handle:
        for path in sorted(OUT.iterdir()):
            if path.is_file() and path != checksum:
                handle.write(f'{digest(path)}  {path.relative_to(OUT)}\n')

    names = [
        'scripts/ieee_tc/analyze_d297_full.py',
        'scripts/ieee_tc/check_d299_full_context.py',
        'docs/ieee_tc/EXECUTION_STATUS.md',
    ]
    names.extend(str(path.relative_to(ROOT)) for path in sorted((ROOT/'paper_results/ieee_tc/p2_backend/d367_full_w0').rglob('*'))
                 if path.is_file())
    names.extend(str(path.relative_to(ROOT)) for path in sorted(OUT.iterdir())
                 if path.is_file() and path.name != 'seal_receipt.json')
    names = sorted(set(names))
    tracked = set(subprocess.check_output(['git', 'ls-files', '--', *names], cwd=ROOT, text=True).splitlines())
    changed = set(subprocess.check_output(['git', 'diff', '--name-only', '--', *names], cwd=ROOT, text=True).splitlines())
    names = [name for name in names if name not in tracked or name in changed]
    for name in names:
        secret_check((ROOT/name).read_bytes())
    subprocess.run(['git', 'add', '--', *names], cwd=ROOT, check=True)
    staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT, text=True).splitlines()
    assert set(staged) == set(names)
    assert 'configs/generated/lora_manifest_1000.json' not in staged
    subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, check=True)
    receipt = {'passed': True, 'staged_paths': names, 'archive': record['archive'],
               'source_sha256': record['source_sha256'], 'identity': 'd367_full_w0',
               'plan_sha256': record['plan_sha256'], 'metric_protocol_sha256': record['metric_protocol_sha256']}
    with (RAW/'seal_receipt.json').open('x') as handle:
        json.dump(receipt, handle, indent=2)
    print(json.dumps({'passed': True, 'staged_paths': len(names), 'archive_bytes': archive.stat().st_size}, indent=2))


if __name__ == '__main__':
    main()
