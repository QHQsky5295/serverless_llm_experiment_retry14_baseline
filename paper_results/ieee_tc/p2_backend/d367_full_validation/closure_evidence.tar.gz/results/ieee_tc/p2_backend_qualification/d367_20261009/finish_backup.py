"""Verify the pushed D367 closure commit and record final backup evidence."""
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p  # noqa: E402


def main():
    assert len(sys.argv) == 2, 'usage: finish_backup.py <pushed_commit>'
    expected = sys.argv[1]
    seal = json.loads((RAW/'seal_receipt.json').read_text())
    assert seal['passed']
    assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=ROOT, text=True).strip()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    remote = subprocess.check_output(['git', 'ls-remote', 'faaslora_origin',
                                      'refs/heads/retry14_continuous_queue_v2'], cwd=ROOT,
                                     text=True).split()[0]
    assert head == remote == expected
    committed = set(subprocess.check_output(['git', 'show', '--format=', '--name-only', head],
                                            cwd=ROOT, text=True).splitlines())
    assert set(seal['staged_paths']).issubset(committed)
    assert 'configs/generated/lora_manifest_1000.json' not in seal['staged_paths']
    assert not subprocess.check_output(
        ['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    record = {
        'kind': 'd367_closure_backup_receipt_v1', 'passed': True,
        'commit': head, 'remote': remote, 'staged_paths': seal['staged_paths'],
        'source_sha256': seal['source_sha256'], 'archive': seal['archive'],
        'no_gpu_compute': True,
        'next': 'Do not repeat D367 replay/cleanup; proceed to 7B optimization decision.',
        'plan_sha256': seal['plan_sha256'], 'metric_protocol_sha256': seal['metric_protocol_sha256'],
    }
    with (RAW/'closure_backup_receipt.json').open('x') as handle:
        json.dump(record, handle, indent=2)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
