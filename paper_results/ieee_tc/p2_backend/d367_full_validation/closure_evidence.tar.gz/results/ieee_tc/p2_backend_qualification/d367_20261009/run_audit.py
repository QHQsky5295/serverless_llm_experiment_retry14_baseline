"""Bounded offline closure audit for D367 Full W0.

This audit never reruns the 4,000-request replay and never changes the
measurement.  It checks the retained receipts/curated projections, runs the
existing read-only timing/control tests, and records failures without turning
them into a successful result.
"""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
CURATED = ROOT/'paper_results/ieee_tc/p2_backend'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p  # noqa: E402


def digest(path: Path) -> str:
    return p.digest(path)


def read(path: Path):
    return json.loads(path.read_text())


def no_compute_processes():
    return not subprocess.check_output(
        ['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'],
        text=True).strip()


def main():
    assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
    protocol = ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
    assert digest(protocol) == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
    assert no_compute_processes()

    receipt = read(RAW/'completion_receipt.json')
    assert receipt['n_plan'] == receipt['n_terminal'] == receipt['n_native_contract_complete'] == 4000
    assert receipt['n_failed_from_terminal_journal'] == 0
    assert receipt['n_correct'] is None and receipt['formal_qualification'] is False
    assert receipt['ranking_eligible'] is False and receipt['no_figures'] is True
    source = Path('results/ieee_tc/p2_backend_qualification/d367_20261009/7b_full_w0/'
                  'experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d367_7b_full_w0.json')
    source = ROOT/source
    assert digest(source) == receipt['source_sha256']
    physical = ROOT/'results/ieee_tc/p2_backend_qualification/d367_20261009/7b_full_w0/launch.launch/physical_deployment/physical_resource_summary.json'
    assert receipt['physical_gpu_seconds_total'] == read(physical)['physical_gpu_seconds_total']
    assert read(RAW/'remote_stop.json')['all_owned_units_inactive']

    validated = CURATED/'d367_full_w0/validated1'
    vmanifest = read(validated/'manifest.json')
    for name, sha in vmanifest['outputs'].items():
        assert digest(validated/name) == sha
    audit = read(validated/'audit.json')
    assert audit['stats']['completed'] == 4000
    assert audit['n_correct'] is None and audit['formal_qualification'] is False
    assert audit['timing']['correctness_qualified'] is False
    assert audit['timing']['timing_joint_pass_count'] == 3835
    assert audit['timing']['required_joint_count'] == 3800

    context = CURATED/'d367_full_w0/context1'
    cmanifest = read(context/'manifest.json')
    for name, sha in cmanifest['outputs'].items():
        assert digest(context/name) == sha
    comparison = read(context/'context.json')
    assert comparison['input_identity_equal'] is True
    assert comparison['reference']['shared_trace_sha256'] == comparison['candidate']['shared_trace_sha256']
    assert comparison['reference']['shared_adapter_subset_sha256'] == comparison['candidate']['shared_adapter_subset_sha256']
    assert comparison['remote']['pack_performed'] is False
    assert comparison['candidate']['source_sha256'] == receipt['source_sha256']

    # The tests are read-only and are intentionally separate from the result
    # analyzer; their output is retained as an audit receipt.
    python = '/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python'
    commands = [[python, '-m', 'unittest',
                 'tests.test_ieee_tc_timing_bound',
                 'tests.test_ieee_tc_hit_host_analysis',
                 'tests.test_ieee_tc_full_control_analysis', '-v']]
    log_path = RAW/'audit1.log'
    returncodes = []
    with log_path.open('x') as log:
        for command in commands:
            print(json.dumps({'command': command}), file=log, flush=True)
            completed = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                       env={**os.environ, 'PYTHONPATH': str(ROOT)})
            returncodes.append(completed.returncode)
            completed.check_returncode()
    record = {
        'kind': 'd367_offline_closure_audit_v1',
        'passed': not any(returncodes),
        'commands': commands,
        'returncodes': returncodes,
        'source_sha256': receipt['source_sha256'],
        'physical_gpu_seconds_total': receipt['physical_gpu_seconds_total'],
        'completed': audit['stats']['completed'],
        'timing_joint_pass_count': audit['timing']['timing_joint_pass_count'],
        'correctness_qualified': False,
        'formal_g1_g2_qualified': False,
        'input_identity_equal': comparison['input_identity_equal'],
        'output_hash_change_count': len(comparison['output_hash_changes']),
        'no_figures': True,
        'plan_sha256': p.check_plan(),
        'metric_protocol_sha256': digest(protocol),
    }
    with (RAW/'offline_execution_receipt.json').open('x') as handle:
        json.dump(record, handle, indent=2)
    print(json.dumps(record, indent=2), flush=True)


if __name__ == '__main__':
    main()
