"""D367 full4000: reuse guarded launcher and unchanged published remote services."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d367_full_validation'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin',
    'refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',
    'faaslora','scripts','configs/ieee_tc','tests'],cwd=ROOT,text=True).strip()
binding=json.loads((OUT/'preparation.json').read_text())
for ref in binding['refs']+binding['raw_refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
subprocess.run(['sha256sum','-c','preparation.sha256'],cwd=OUT,check=True)
old=json.loads((RAW/'preparation_scope.json').read_text())['identity']
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
cleanup=p.stop_scope_identity(old)
assert cleanup['released'] and not cleanup['hard_kill'] and not Path(old['path']).exists()
gate=p.preflight([ROOT],32*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not (RAW/'7b_full_w0').exists()
assert subprocess.run(['tmux','has-session','-t','tc-d367-full'],stderr=subprocess.DEVNULL).returncode!=0
with (RAW/'launch_gate.json').open('x') as f:
    json.dump(dict(passed=True,head=head,remote=remote,gate=gate,identity=identity,
                   preparation_cleanup=cleanup),f,indent=2)
subprocess.run(['bash',str(RAW/'start_remote.sh')],check=True)
subprocess.run(['/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python',str(RAW/'check_remote_health.py')],check=True,cwd=ROOT)
subprocess.run(['tmux','new-session','-d','-s','tc-d367-full','-c',str(ROOT),
    'bash scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh d367'],check=True)
with (RAW/'start_receipt.json').open('x') as f:
    json.dump(dict(launched=True,head=head,remote=remote,tmux='tc-d367-full',identity=identity),f,indent=2)
print(json.dumps(dict(launched=True,head=head,tmux='tc-d367-full')))
