#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d207_20261003
CACHE=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/model_20260926/candidate_cache
cd "${MAIN}"
# D207 isolated local execution metadata diagnostic, not a performance result.
unset FAASLORA_REMOTE_ARTIFACT_ENABLED FAASLORA_REMOTE_ARTIFACT_ENDPOINT
unset FAASLORA_REMOTE_ARTIFACT_DELIVERY_MODE PRIME_REMOTE_TOKEN
test ! -e "${RAW}/7b_execution4_launch.json"
test ! -e "${RAW}/7b_execution4.json"
/usr/bin/python3 scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "${RAW}/execution4_protected_before.json"
sha256sum faaslora/memory/gpu_monitor.py scripts/run_all_experiments.py scripts/ieee_tc_preflight.py configs/ieee_tc/20261002_d166_7b_slot_content.yaml > "${RAW}/execution4_sources.sha256"
# Restore the already-qualified 7B compiler environment; do not change the backend.
export PATH="/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin:${PATH}"
export CUDA_HOME=/usr/local/cuda-13.0
export FLASHINFER_NVCC=/usr/local/cuda-13.0/bin/nvcc
export MAX_JOBS=2
command -v ninja
ninja --version
export FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY=uncached_background_v1
export PYTORCH_ALLOC_CONF=pinned_max_cached_size_mb:0,pinned_use_background_threads:True
export VLLM_CACHE_ROOT="${CACHE}"
export TRITON_CACHE_DIR="${CACHE}/triton"
export TORCHINDUCTOR_CACHE_DIR="${CACHE}/inductor"
exec systemd-run --user --scope --collect --unit=primelora-tc-aux-f17bf7b4769440279cf3a3f3a270ad95.scope \
  -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 \
  taskset -c 2,3,26,27 env \
  FAASLORA_TC_NVML_BINDING=/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py \
  FAASLORA_TC_NVML_SHA256=4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea \
  PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 \
  HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 VLLM_NO_USAGE_STATS=1 \
  /usr/bin/python3 "${MAIN}/scripts/ieee_tc_preflight.py" gated-launch \
  --output "${RAW}/7b_execution4_launch.json" --predicted-growth-gib 8 \
  --exec /home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python \
  "${MAIN}/scripts/ieee_tc_preflight.py" backend-model-check \
  --runtime-receipt "${MAIN}/results/ieee_tc/p2_backend_qualification/runtime_20260926/cuda_import_attempt3.json" \
  --config "${MAIN}/configs/ieee_tc/20261002_d166_7b_slot_content.yaml" --model-profile llama2_7b_main_v2_publicmix \
  --replay-trace /home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260424_131528_llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1/shared_artifacts/llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json \
  --request-count 22 --qualification-mode native_execution_metadata \
  --output "${RAW}/7b_execution4.json"
