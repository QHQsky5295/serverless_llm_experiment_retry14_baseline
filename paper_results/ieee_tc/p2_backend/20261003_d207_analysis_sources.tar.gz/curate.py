"""Reuse D166 actual-run checks and D206 bounded checkpoint sealing for D207."""
import ast
import csv
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path
from scripts.ieee_tc_preflight import ROOT, check_plan, digest, verify_seal, validate_native_execution_journal

raw = Path(__file__).parent.resolve()
base = ROOT/'paper_results/ieee_tc/p2_backend'
doc = ROOT/'docs/ieee_tc/D207_NATIVE_EXECUTION_PREFIX.md'
prefix = '20261003_d207'
def load(path):
    assert path.stat().st_size < 128*1024**2
    return json.loads(path.read_text())
def absent(unit, path):
    assert not Path(path).exists()
    assert not subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','--value'], text=True).strip()

scopes = {}
for phase, count in [('tests1',33),('tests2',34),('regression1',376),('tests3',414),('tests4',416)]:
    receipt = dict(line.split('=',1) for line in (raw/f'{phase}_scope.txt').read_text().splitlines())
    assert receipt['MemoryHigh']=='3221225472' and receipt['MemoryMax']=='4294967296'
    assert receipt['MemorySwapMax']=='0' and receipt['InvocationID']
    absent(f'primelora-d207-{phase}-20261003.scope','/sys/fs/cgroup'+receipt['ControlGroup'])
    assert 'Exit status: 0' in (raw/f'{phase}_time.txt').read_text()
    assert all(line.split()[1]=='0' for line in (raw/f'{phase}_memory_events.txt').read_text().splitlines())
    assert (raw/f'{phase}_swap.txt').read_text().strip()=='0'
    assert int((raw/f'{phase}_memory_peak.txt').read_text())<=4*1024**3
    log=(raw/f'{phase}.log').read_text()
    assert f'Ran {count} tests' in log and '\nOK\n' in log
    for side in ('before','after'):
        assert load(raw/f'{phase}_protected_{side}.json')['pass']
    scopes[phase]=dict(receipt, tests=count, passed=True, released=True)
subprocess.run(['sha256sum','-c',str(raw/'tests4_sources.sha256')],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()

refs, attempts = {}, []
for attempt in (1,2,3,4):
    source=raw/f'7b_execution{attempt}.json'
    launch_path=raw/f'7b_execution{attempt}_launch.json'
    data, launch=load(source),load(launch_path)
    assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
    assert launch['watchdog_returncode']==0
    identity=launch['service_identity']
    absent(identity['unit'],identity['path'])
    cleanup=raw/f'execution{attempt}_cleanup.txt'
    assert 'cleanup=automatic_removal_verified' in cleanup.read_text()
    assert data['physical_allocation']['released']
    watch=raw/f'7b_execution{attempt}_launch.launch/watchdog.jsonl'
    samples=[]
    with watch.open() as file:
        for line in file:
            row=json.loads(line)
            if row['event']=='resource_sample': samples.append(row)
    assert samples and all(not s['decision']['abort_reasons'] for s in samples)
    compute=[p for s in samples for d in s['gpu']['devices'] for p in d['processes'] if p['kind']=='compute']
    assert compute and all(p['service_member'] for p in compute)
    expected_cpus=list(range(4,24))+list(range(28,48))
    assert all(p['identity']['affinity']==expected_cpus for p in compute)
    memory={key:max(s['service']['memory.events'][key] for s in samples)
            for key in samples[0]['service']['memory.events']}
    assert all(v==0 for v in memory.values())
    attempts.append(dict(attempt=attempt,passed=data['pass'],stage=data['stage'],
        prepared_requests=len(data['requests']),completed_requests=sum(q['pass'] for q in data['requests']),
        journal_snapshots=len(data['execution_journal']),
        failure=(None if data['pass'] else data['error'].split('\n')[0]),
        service_returncode=launch['service_returncode'],watchdog_returncode=0,
        physical_released=True,service_invocation=identity['invocation_id'],resource_samples=len(samples),
        peak_memory_bytes=max(s['service']['memory.peak'] for s in samples),
        min_host_available_bytes=min(s['host']['available_bytes'] for s in samples),
        max_swap_bytes=max(s['service']['memory.swap.current'] for s in samples),memory_events=memory))
    for path in (source,launch_path,watch,cleanup,raw/f'execution{attempt}_sources.sha256'):
        refs[str(path)]=digest(path)
assert [a['completed_requests'] for a in attempts[:3]]==[0,0,0]
assert [a['prepared_requests'] for a in attempts[:3]]==[0,0,1]
assert all(not a['passed'] for a in attempts[:3])

inputs_path=ROOT/'results/ieee_tc/p2_backend_qualification/d166_20261002/input_qualification2.json'
assert digest(inputs_path)=='56d474d9d69e4724162ccb0a5f938b32d9415a8e7a61576ccd5bf5fdd8f66a16'
inputs=load(inputs_path)
assert data['config_sha256']==inputs['config_sha256']
assert data['trace']['source_sha256']==inputs['trace_sha256']
assert data['artifact_mode']=='existing_local_frozen_qualification_only'
assert not data['performance_sample'] and not data['semantic_full_pool_qualification']
assert not data['full_model_qualification']
assert set(data['adapters'])==set(inputs['adapters'])
for aid, expected in inputs['adapters'].items():
    assert data['adapters'][aid]['weights_sha256']==expected['weights_sha256']
    assert data['adapters'][aid]['config_sha256']==expected['config_sha256']
validation=None
rows=[]
graph_mode_forward_counts={}
if data['pass']:
    assert launch['pass'] and data['stage']=='complete' and len(data['requests'])==22
    validation=validate_native_execution_journal(data['execution_journal'],data['execution_expected_leases'],
        data['workers_before']['workers'][0],data['scheduler_before'],data['scheduler_after'])
    assert validation==data['execution_validation']
    for snapshot in data['execution_journal']:
        for event in snapshot['events']:
            if event['kind']=='forward_before':
                mode=event['observation']['cudagraph_runtime_mode']
                graph_mode_forward_counts[mode]=graph_mode_forward_counts.get(mode,0)+1
    final=data['execution_journal'][-1]
    for request, expected in zip(data['requests'],inputs['rows']):
        assert request['pass'] and request['release']['released']
        assert all(request[key]==expected[key] for key in expected)
        assert request['actual_tokens']==request['target_tokens']==request['timing']['native_output_tokens']
        receipt=request['execution_retirement']['native_retirement']
        assert receipt['external_request_id']==request['timing']['backend_request_id']
        counts=final['native_requests'][receipt['request_id']]
        rows.append(dict(request_id=request['request_id'],adapter_id=request['adapter_id'],
            external_request_id=receipt['external_request_id'],internal_request_id=receipt['request_id'],
            adapter_int_id=counts['adapter_int_id'],target_tokens=request['target_tokens'],
            actual_tokens=request['actual_tokens'],forward_calls=counts['forwards'],
            logits_calls=counts['logits'],scheduled_tokens=counts['scheduled_tokens'],mapping_pass=True))
    assert not data['sources_after_eviction']['sources']
    assert not data['sources_after_eviction']['registered_cpu_adapter_ids']
    assert all(v is None for v in data['sources_after_eviction']['slot_adapter_ids'])

allowed={
    'faaslora/memory/gpu_monitor.py': {'_IEEENativeExecutionObserver'},
    'scripts/ieee_tc_preflight.py': {'initialize_qualification_runtime','backend_model_check','main',
        'require_native_execution_drained','validate_native_execution_journal','qualify_execution_observer'},
}
for name, exclusions in allowed.items():
    trees=[ast.parse(subprocess.check_output(['git','show','HEAD:'+name],text=True)),ast.parse((ROOT/name).read_text())]
    for tree in trees:
        tree.body=[n for n in tree.body if getattr(n,'name',None) not in exclusions]
    assert ast.dump(trees[0])==ast.dump(trees[1]),name
unchanged=['scripts/run_all_experiments.py','faaslora/memory/residency_manager.py',
    'faaslora/preloading/preloading_planner.py','faaslora/experiment/instance_pool.py',
    'scripts/dedicated_engine_worker.py','faaslora/scheduling/vllm_ieee_frontend.py',
    'faaslora/scheduling/vllm_ieee_scheduler.py','configs/ieee_tc/20261002_d166_7b_slot_content.yaml']
for name in unchanged:
    assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show','HEAD:'+name])
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protection=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protection['pass'] and protection['entry_count']==147
assert 'SEALED' in doc.read_text()
sources=[]
installed=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages')
for name in ['vllm/v1/worker/gpu/model_runner.py','vllm/v1/worker/gpu/lora_utils.py',
             'vllm/v1/worker/gpu/cudagraph_utils.py','vllm/v1/worker/gpu/input_batch.py',
             'vllm/v1/engine/input_processor.py']:
    sources.append(dict(path=str(installed/name),sha256=digest(installed/name),
        upstream_url='https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/'+name))
for name in ['curate.py','check_staged.py']:
    compile((raw/name).read_bytes(),str(raw/name),'exec')
summary=dict(kind='d207_native_execution_prefix_qualification_v1',passed=data['pass'],
    attempts=attempts,scopes=scopes,validation=validation,requests=rows,sources=sources,
    source_references=refs,plan_sha256=check_plan(),parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    graph_mode_forward_counts=graph_mode_forward_counts,
    performance_sample=False,numerical_correctness_qualified=False,full_pool_qualified=False,
    common_slo_qualified=False,formal_g1_g2_qualified=False,n_correct=None,
    default_performance_hook_installed=False,remote_operation=False)
with (base/f'{prefix}_execution_prefix.json').open('x') as file: json.dump(summary,file,indent=2,allow_nan=False)
for suffix, table in [('attempts',attempts),('requests',rows)]:
    path=base/f'{prefix}_{suffix}.csv'
    with path.open('x',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=list(table[0]) if table else ['request_id','mapping_pass'],lineterminator='\n')
        writer.writeheader();writer.writerows(table)

members=[(raw/name,name) for name in ('run_cpu.sh','curate.py','check_staged.py')]
for phase in scopes:
    for suffix in ('scope.txt','time.txt','memory_events.txt','swap.txt','memory_peak.txt',
                   'protected_before.json','protected_after.json','sources.sha256','sources.tar.gz'):
        members.append((raw/f'{phase}_{suffix}',f'{phase}_{suffix}'))
    members.append((raw/f'{phase}.log',f'{phase}.log'))
for attempt in (1,2,3,4):
    for name in (f'run_7b_execution{attempt}.sh',f'execution{attempt}_sources.sha256',f'execution{attempt}_cleanup.txt'):
        members.append((raw/name,name))
    members.append((raw/f'7b_execution{attempt}_launch.launch/service.log',f'execution{attempt}_service.log'))
for source in sources:
    path=Path(source['path']);members.append((path,'installed_source/'+str(path.relative_to(installed))))
for name in (*allowed,'tests/test_ieee_tc_worker_observation.py','tests/test_ieee_tc_artifact_audit.py',
             'docs/ieee_tc/D207_NATIVE_EXECUTION_PREFIX.md'):
    members.append((ROOT/name,name))
# Preserve the detailed first-request diagnostic exception, not only its summary.
members.append((Path('/tmp/faaslora_worker_v4yh70xu/worker.log'),'execution3_worker.log'))
bundle=base/f'{prefix}_analysis_sources.tar.gz'
hashes={}
with tarfile.open(bundle,'x:gz') as archive:
    for path,name in members:
        assert name not in hashes and path.stat().st_size<2*1024**2
        hashes[name]=digest(path);archive.add(path,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames())==set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha
with (base/f'{prefix}_analysis_sources.sha256').open('x') as file: file.write(digest(bundle)+'  '+bundle.name+'\n')
with (base/f'{prefix}_analysis_sources_members.json').open('x') as file:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),file,indent=2)
artifacts=[doc,bundle,base/f'{prefix}_execution_prefix.json',base/f'{prefix}_attempts.csv',base/f'{prefix}_requests.csv']
verification=dict(kind='d207_evidence_verification_v1',passed=True,protection=protection,
    actual_gpu_diagnostic_passed=data['pass'],qualification_not_performance=True,
    syntax_smoke=True,allowed_runtime_nodes={k:sorted(v) for k,v in allowed.items()},unchanged_sources=unchanged,
    bundle_members=len(hashes),bundle_bytes=bundle.stat().st_size,
    artifacts={str(p.relative_to(ROOT)):digest(p) for p in artifacts})
with (base/f'{prefix}_evidence_verification.json').open('x') as file: json.dump(verification,file,indent=2)
print(json.dumps(verification))
