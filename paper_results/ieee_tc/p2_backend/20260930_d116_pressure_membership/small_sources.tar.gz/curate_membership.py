"""Reuse prior CPU-candidate closure: source checks, status table, small bundle."""
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(root))
from scripts.ieee_tc_preflight import digest, verify_seal
raw = root/'results/ieee_tc/p2_backend_qualification/d116_20260930'
d115 = root/'results/ieee_tc/p2_backend_qualification/d115_20260929'
out = root/'paper_results/ieee_tc/p2_backend/20260930_d116_pressure_membership'
assert not out.exists()
before = json.loads((raw/'before_probe.json').read_text())
after = json.loads((raw/'after_probe.json').read_text())
assert before['reproduction_pass'] and after['reproduction_pass']
assert all(not x['performance_measurement'] and not x['gpu_used'] for x in (before,after))
assert before['rows'][1]['result'] is None and after['rows'][1]['result']=='completed'
for x in (before,after):
    assert x['rows'][2]['operation_calls']==[] and x['rows'][2]['error']
for p,sha in after['source_sha256'].items():
    assert digest(root/p)==sha,p
for p,sha in before['source_sha256'].items():
    content=subprocess.check_output(['git','show','d365814:'+p],cwd=root)
    assert hashlib.sha256(content).hexdigest()==sha,p
frozen=json.loads((d115/'prelaunch_verification.json').read_text())
allowed={ (root/p).resolve() for p in ('scripts/run_all_experiments.py',
    'faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py') }
changed=[]
for name,old in frozen['source_sha256'].items():
    p=Path(name) if name.startswith('/') else root/name
    now=digest(p)
    if now!=old:
        assert p.resolve() in allowed,name
        changed.append(dict(path=name,before=old,after=now))
# D115's 69-entry manifest did not include resource_coordinator. Its before
# identity is independently checked against Git above, and its after SHA too.
listed={(Path(p) if p.startswith('/') else root/p).resolve() for p in frozen['source_sha256']}
assert allowed & listed == {
    (Path(r['path']) if r['path'].startswith('/') else root/r['path']).resolve() for r in changed}
tests={}
for name,expected in [('tests',350),('regression',None)]:
    log=(raw/f'{name}.log').read_text()
    matched=re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK\s*$',log)
    assert matched,name
    count,seconds=int(matched[1]),float(matched[2])
    if expected is not None: assert count==expected
    assert 'Exit status: 0' in (raw/f'{name}_time.txt').read_text()
    tests[name]=dict(count=count,seconds=seconds,pass_checks=True)
receipts=[]
for name,invocation in [('before','751e4fa5485d4083b2e54e7ee903efdd'),
    ('after','8ca74ba5854948b5a51b53f8ff51d50d'),
    ('regression','3a56bf2535b740b3a2bde7c3be23c290'),
    ('curate','1fd6cd18b10b4f39af2659f25a25a182')]:
    unit=f'primelora-d116-{name}-20260930.scope'
    def prop(key):
        return subprocess.check_output(['systemctl','--user','show',unit,'-p',key,'--value'],text=True).strip()
    assert prop('InvocationID')==invocation and prop('TasksCurrent')=='0'
    cg=Path('/sys/fs/cgroup'+prop('ControlGroup'))
    assert not (cg/'cgroup.procs').read_text().strip()
    assert 'populated 0' in (cg/'cgroup.events').read_text()
    events=(cg/'memory.events').read_text()
    assert all(int(line.split()[1])==0 for line in events.splitlines())
    with (raw/f'{name}_memory_events.txt').open('x') as f:f.write(events)
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert prop('ActiveState')=='inactive'
    receipts.append(dict(unit=unit,invocation=invocation,tasks=0,populated=0,stopped=True))
with (raw/'probe_scopes_cleanup.json').open('x') as f:json.dump(receipts,f,indent=2)
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
# Reuse D115's bounded projection, never its 9 GB original outcome.
projection=d115/'full_full10_outcome_projection.json'
assert digest(projection)=='1683109776c5c0352ee7ec14f2064b82b10e688c1e7614a14cad0c17bd90e7fa'
hist=json.loads(projection.read_text())
historical=dict(final_pressure=hist['coordination_after_shutdown']['ieee_shared_file_pressure'],
    tail_scale_down=hist['completed_scenario_metadata']['scale_down_event_log'],
    last_online_control=hist['mechanism_events']['_ieee_control_events'][-1],
    activations=[{k:r[k] for k in ('activation_id','category','state','native_owner_id')}
                 for r in hist['mechanism_events']['_ieee_activations']],
    failing_member_at_error='not instrumented; no retrospective identity claim')
assert historical['last_online_control']['action']=='no_action'
assert len(historical['tail_scale_down'])==1
assert historical['tail_scale_down'][0]['request_index']==4000
del hist
out.mkdir()
summary=dict(kind='d116_pressure_membership_candidate_v1',before=before,after=after,
    tests=tests,frozen_source_refs_checked=len(frozen['source_sha256']),expected_changes=changed,
    protected=protected,cleanup=receipts,historical_context=historical,
    production_candidate=True,full_qualified=False,formal_performance_result=False,
    source_parent_commit='d36581421413e0a4bc70354bdf191fa06375435e',
    additional_source_verification='resource_coordinator absent in D115 prelaunch69; before Git and after probe SHA checked independently',
    first_curation_failure='manifest coverage assertion assumed resource_coordinator was in prelaunch69; before side effects; attempt1 preserved',
    next='Audit explicit legacy terminal retirement ordering, then canonical Full; no blind replay.')
with (out/'summary.json').open('x') as f:json.dump(summary,f,indent=2,allow_nan=False)
members=sorted(p for p in raw.iterdir() if p.is_file() and p.stat().st_size<2*1024*1024
               and p.name != 'curation2.log')
bundle=out/'small_sources.tar.gz'
hashes={}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        data=p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        hashes[p.name]=hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames())==set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha
with (out/'members.json').open('x') as f:json.dump(hashes,f,indent=2)
with (out/'SHA256SUMS').open('x') as f:
    for name in ('summary.json','small_sources.tar.gz','members.json'):
        f.write(digest(out/name)+'  '+name+'\n')
print(json.dumps(dict(output=str(out),summary_sha256=digest(out/'summary.json'),
    source_changes=len(changed),tests=tests,bundle_members=len(hashes),protected=147)))
