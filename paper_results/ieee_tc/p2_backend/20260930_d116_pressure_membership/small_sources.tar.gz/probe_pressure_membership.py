"""CPU-only actual runner/domain interleaving, reusing transfer-pressure fixtures.

No sleeps, GPU, real file IO, injected performance delay or throughput claims.
Events fix callback order; only native RPC/file boundaries are fixture objects.
"""
import asyncio
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from faaslora.experiment.instance_pool import InstancePool
from tests.test_ieee_tc_transfer_pressure import TransferPressure


async def case(retire_role):
    runner, target, target_ledger = TransferPressure().runner()
    _, other, other_ledger = TransferPressure().runner()
    pool = runner.instance_pool = InstancePool()
    pool.add_instance(target, None, instance_id='target')
    pool.add_instance(other, None, instance_id='other')
    await runner._attach_ieee_file_pressure(target)
    await runner._attach_ieee_file_pressure(other)
    domain = runner._shared_file_pressure
    reached, proceed = asyncio.Event(), asyncio.Event()
    original = domain.attach
    calls, body_calls = [], []

    async def attach(engine):
        role = 'target' if engine is target else 'other'
        calls.append(role)
        # Actual _run_ieee_file_transfer already captured the pool by here.
        # Hold its first target attach, without changing domain semantics.
        if len(calls) == 1:
            reached.set()
            await proceed.wait()
        return await original(engine)

    domain.attach = attach
    async def body():
        body_calls.append(dict(target=target_ledger.snapshot()['active_transfers'],
                               other=other_ledger.snapshot()['active_transfers']))
        return 'completed'
    task = asyncio.create_task(runner._run_ieee_file_transfer('a', 'nvme', 'native_host', target, body))
    await reached.wait()
    if retire_role is not None:
        slot = pool.get_slot(retire_role)
        slot.status = 'draining'  # Real pool now excludes it; captured list may not.
        await domain.retire(slot.engine)
    proceed.set()
    error = None
    try:
        result = await task
    except RuntimeError as exc:
        result, error = None, str(exc)
    return dict(retire_role=retire_role, attach_calls=calls, result=result,error=error,
        operation_calls=body_calls, live_pool=[s.instance_id for s in pool.get_slots()],
        members=domain.snapshot()['members'],transfer_records=len(runner._adapter_transfer_pressure_evidence))


async def main():
    rows = [await case(role) for role in (None,'other','target')]
    assert rows[0]['result'] == 'completed' and rows[0]['operation_calls'] == [dict(target=1,other=1)]
    assert rows[1]['result'] == 'completed' and rows[1]['operation_calls'] == [dict(target=1,other=0)]
    assert rows[2]['error'] == 'native file pressure subscription is not available'
    assert rows[2]['operation_calls'] == [] and rows[2]['transfer_records'] == 0
    assert rows[1]['live_pool'] == ['target']
    out = ROOT/'results/ieee_tc/p2_backend_qualification/d116_20260930/after_probe.json'
    source_paths = ['scripts/run_all_experiments.py','faaslora/scheduling/resource_coordinator.py',
                    'faaslora/experiment/instance_pool.py','tests/test_ieee_tc_transfer_pressure.py']
    data = dict(kind='d116_pressure_membership_cpu_probe_after_v1', rows=rows,
        reproduction_pass=True, performance_measurement=False, gpu_used=False,
        historical_run_causal_attribution='consistent counterexample, no D115 failing-member timestamp',
        source_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in source_paths})
    with out.open('x') as f:
        json.dump(data,f,indent=2,allow_nan=False)
    print(json.dumps(data,indent=2))


if __name__ == '__main__':
    asyncio.run(main())
