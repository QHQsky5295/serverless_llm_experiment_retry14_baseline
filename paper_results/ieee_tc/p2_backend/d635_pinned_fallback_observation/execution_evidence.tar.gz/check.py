"""Bounded regression entry; preserve before/after logs and source hashes."""
import json
import os
import subprocess
import sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
phase=sys.argv[1]
assert phase in ('qualification','qualification2','analysis2','start')
identity=p.scope_identity(p.cg_path().name)
group=Path(identity['path'])
assert os.sched_getaffinity(0)=={2,3,26,27}
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
with (RAW/(phase+'_identity.json')).open('x') as f:json.dump(identity,f,indent=2)
if phase in ('qualification','analysis2','start'):
    tests=['tests.test_ieee_tc_transfer_pressure.IntegratedNativeHostReplacement.test_fallback_uses_pinned_observation_not_earlier_snapshot']
else:
    tests=['tests.test_ieee_tc_transfer_pressure','tests.test_ieee_tc_gpu_references',
        'tests.test_ieee_tc_request_lifecycle']
log=RAW/(phase+'.log')
with log.open('x') as f:
    returncodes=[]
    for test in tests:
        completed=subprocess.run([sys.executable,'-m','unittest','-v',test],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
        returncodes.append(completed.returncode)
        if completed.returncode:break
returncode=max(returncodes)
record=dict(returncode=returncode,returncodes=returncodes,tests=tests,scope=identity,
    log_sha256=p.digest(log),sources={str(ROOT/path):p.digest(ROOT/path) for path in
        ('scripts/run_all_experiments.py','tests/test_ieee_tc_transfer_pressure.py',
         'faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py')})
with (RAW/(phase+'_receipt.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record,indent=2))
print(log.read_text()[-8500:])
if phase in ('qualification','analysis2','start'):
    assert returncode!=0 and 'HOST eviction fallback lacks its held exact file copy' in log.read_text()
else:
    assert returncode==0
