"""Reuse D595's explicit-path tested backup; retain failed fixture attempts."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d635_pinned_fallback_observation'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'",
        "=='e499f12955c8e0ce370fd78cac6b412699bc983e'")
start=code.index('reg=read(RAW/');end=code.index('preserved={',start)
code=code[:start]+'''reg=read(RAW/'qualification2_receipt.json')
assert reg['returncode']==0 and reg['returncodes']==[0,0,0]
assert p.digest(RAW/'qualification2.log')==reg['log_sha256']
for path,sha in reg['sources'].items():assert p.digest(Path(path))==sha
for name in ('analysis','qualification','analysis2','start','qualification2'):
    closure=read(RAW/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
witness=read(RAW/'start_receipt.json')
assert witness['returncode']==1 and 'HOST eviction fallback lacks its held exact file copy' in (RAW/'start.log').read_text()
audit=read(RAW/'receipt_audit.json')
assert len(audit['differences'])==len(audit['unresolved'])==1
assert audit['differences'][0]['differences']=={'footprint':{'source':37748736,'lease':37752832}}
assert p.digest(Path(audit['source']['path']))==audit['source']['sha256']
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
''' + code[end:]
start=code.index('members=[RAW/name');end=code.index('\nfor path in members:',start)
code=code[:start]+'''members=[RAW/name for name in ('analyze.py','check.py','close.py','backup.py','receipt_audit.json',
    'analysis_identity.json','analysis_closure.json',
    'qualification_identity.json','qualification.log','qualification_receipt.json','qualification_closure.json',
    'analysis2_identity.json','analysis2.log','analysis2_receipt.json','analysis2_closure.json',
    'start_identity.json','start.log','start_receipt.json','start_closure.json',
    'qualification2_identity.json','qualification2.log','qualification2_receipt.json','qualification2_closure.json')]
''' + code[end:]
start=code.index('test_counts={');end=code.index("save(OUT/'qualification.json'",start)
code=code[:start]+'''test_counts=[int(n) for n in re.findall(r'Ran (\\d+) tests', (RAW/'qualification2.log').read_text())]
assert test_counts==[180,144,215]
record=dict(passed=True,production_correctness_repair=True,native_gpu_validation=False,full_performance_run=False,
    parent_commit='e499f12955c8e0ce370fd78cac6b412699bc983e',
    test_counts=test_counts,test_total=sum(test_counts),regression=reg,protected=protected,
    receipt_audit_source=audit['source'],counts=audit['counts'],differences=audit['differences'],
    before_fix_reproduction=witness,initial_fixture_failures=['qualification','analysis2'],
    preserved={str(k):v for k,v in preserved.items()},
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='One held confirmation replaces mixed observations; CPU qualification only, exact kernel cause unknown, no performance or numerical-correctness claim.')
''' + code[end:]
replace('faaslora/scheduling/resource_coordinator.py','scripts/run_all_experiments.py')
replace("'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md'",
        "'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D635_PINNED_FALLBACK_OBSERVATION.md',\n    'docs/ieee_tc/D634_MINIMUM_TWO_REPLICA_FULL_W0.md'")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: bind HOST replacement fallback to its held confirmation (D635)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
