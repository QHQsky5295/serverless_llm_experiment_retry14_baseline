"""D611 closure: reuse D452 exact-owned cleanup/download checks."""
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

own_identity = p.scope_identity(p.cg_path().name)
own_group = Path(own_identity['path'])
assert (own_group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (own_group/'memory.swap.max').read_text().strip() == '0'
gate = p.preflight([p.ROOT], 4*p.GIB)
# Closure is not a new launch: the run may have crossed the start-floor while
# writing its retained logs.  Record that gate honestly and reject only a
# live-resource/safety issue, not the expected post-run disk condition.
assert not any('host_memory_below_stop' in issue or 'filesystem_below_stop' in issue
               for issue in gate['issues']), gate['issues']
raw = Path(__file__).resolve().parent
run = raw/'7b_inventory_extent_full_w2'
launch = json.loads((run/'launch.json').read_text())
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
local = json.loads((raw/'local_cleanup.json').read_text())
assert local['passed'] and local['service_path_gone'] and local['auxiliary_path_gone'] and local['actual_recursive_procs_empty']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
starter = json.loads((raw/'start_closure.json').read_text())
assert starter['passed'] and starter['path_gone'] and starter['actual_recursive_procs_empty']
stop = (raw/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive') == 3 and stop.count('MainPID=0') == 3
transfer_paths = [line for line in stop.splitlines()
    if line.startswith('/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-') and line.endswith('.jsonl')]
assert len(transfer_paths) == 1
paths = {
    'remote_transfers.jsonl': transfer_paths[0],
    'remote_monitor.log': '/home/lab14/primelora_remote/tc/d611_20261017/remote_monitor.log',
}
hashes = {}
for name, remote_path in paths.items():
    destination = raw/name
    assert not destination.exists()
    expected = subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','sha256sum',remote_path],text=True).split()[0]
    subprocess.run(['scp','-q','-o','BatchMode=yes',f'primelora-artifact-174:{remote_path}',str(destination)],check=True)
    assert p.digest(destination) == expected
    hashes[name] = expected
with (raw/'remote_stop.json').open('x') as f:
    json.dump(dict(all_owned_units_inactive=True,ports_18080_18081_absent=True,
        local_gpu_release_verified_before_remote_stop=True,download_hashes_match_remote=True,
        hashes=hashes,stop_log_sha256=p.digest(raw/'remote_stop.log')),f,indent=2)
print(json.dumps(dict(local_aux_inactive=True,remote_inactive=True,hashes=hashes)))

source = next(run.glob('experiment_results*.json'))
receipt = dict(identity=own_identity, source_path=str(source), source_sha256=p.digest(source),
    source_bytes=source.stat().st_size, preflight=gate,
    resources={k:(own_group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current','cgroup.events')})
with (raw/'collection_receipt.json').open('x') as f:
    json.dump(receipt,f,indent=2)
print(json.dumps({k:receipt[k] for k in ('identity','source_path','source_sha256','source_bytes','resources')}))

with (raw/'completion_receipt.json').open('x') as f:
    physical=json.loads((run/'launch.launch/physical_deployment/physical_resource_summary.json').read_text())
    completion=dict(kind='d611_initial_control_full4000_closure_v1',
        source_commit=json.loads((raw/'launch_gate.json').read_text())['head'],
        n_plan=physical['n_plan'],n_terminal=physical['n_terminal'],
        n_native_contract_complete=physical['n_native_contract_complete'],
        n_failed_from_terminal_journal=physical['n_terminal']-physical['n_native_contract_complete'],
        planned=physical['n_plan'],terminal=physical['n_terminal'],
        successful_returns=physical['n_native_contract_complete'],
        failed=physical['n_terminal']-physical['n_native_contract_complete'],
        source_sha256=receipt['source_sha256'],
        launch_sha256=p.digest(run/'launch.json'),
        physical_gpu_seconds_total=physical['physical_gpu_seconds_total'],
        native_gpu_context_release_confirmed=True,service_path_removed=True,
        remote_transfers_sha256=hashes['remote_transfers.jsonl'],
        remote_monitor_sha256=hashes['remote_monitor.log'],
        remote_stop=json.loads((raw/'remote_stop.json').read_text()),
        remote_cleanup=json.loads((raw/'remote_stop.json').read_text()),
        n_correct=None,formal_qualification=False,ranking_eligible=False,
        no_figures=True,caveat='PrimeLoRA observed initial control full4000 W2 candidate evaluation; no independent numerical proof or cross-system ranking before input/initial-state review.')
    json.dump(completion,f,indent=2)
print(json.dumps(dict(completion=True,n_plan=completion['n_plan'],
    n_terminal=completion['n_terminal'],n_native_contract_complete=completion['n_native_contract_complete'])))
