"""Launch existing native source collector after pushed checkpoint/fresh gates."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d356_control_profiles'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote and head.startswith('215c165')
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','scripts','faaslora','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['sha256sum','-c',str(out/'preparation.sha256')],cwd=ROOT,check=True)
receipt=json.loads((raw/'checkpoint_receipt.json').read_text());assert receipt['passed']
old=receipt['identity'];assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
cleanup=p.stop_scope_identity(old)
assert cleanup['released'] and not cleanup['hard_kill'] and not Path(old['path']).exists()
gate=p.preflight([ROOT],8*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not (raw/'source1.json').exists() and not (raw/'source1_launch.json').exists()
assert subprocess.run(['tmux','has-session','-t','tc-d356-source'],stderr=subprocess.DEVNULL).returncode!=0
with (raw/'launch_gate.json').open('x') as f:
    json.dump(dict(passed=True,head=head,remote=remote,gate=gate,identity=identity,checkpoint_cleanup=cleanup),f,indent=2)
subprocess.run(['bash',str(raw/'start_remote.sh')],check=True)
subprocess.run([sys.executable,str(raw/'check_remote_health.py')],cwd=ROOT,check=True)
subprocess.run(['tmux','new-session','-d','-s','tc-d356-source','-c',str(ROOT),
    'bash scripts/ieee_tc/run_d298_capacity_source.sh d356'],check=True)
with (raw/'start_receipt.json').open('x') as f:
    json.dump(dict(launched=True,head=head,remote=remote,tmux='tc-d356-source',identity=identity),f,indent=2)
print(json.dumps(dict(launched=True,head=head,tmux='tc-d356-source')))
