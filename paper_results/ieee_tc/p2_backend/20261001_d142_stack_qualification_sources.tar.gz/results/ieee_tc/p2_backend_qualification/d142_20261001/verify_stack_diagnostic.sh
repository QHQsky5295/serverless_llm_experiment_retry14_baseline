#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d142_20261001
unit=primelora-d142-stack-verify-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test -z "${FAASLORA_TC_STACK_SAMPLING:-}"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/test_scope.txt"
sha256sum faaslora/__init__.py faaslora/utils/logger.py tests/test_ieee_tc_stack_diagnostic.py > "$raw/test_sources.sha256"
export PYTHONUNBUFFERED=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1
exec /usr/bin/time -v -o "$raw/test_time.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest tests.test_ieee_tc_stack_diagnostic tests.test_ieee_tc_service_events tests.test_ieee_tc_planning_cpu tests.test_ieee_tc_external_replay tests.test_basic_smoke -v > "$raw/test.log" 2>&1
