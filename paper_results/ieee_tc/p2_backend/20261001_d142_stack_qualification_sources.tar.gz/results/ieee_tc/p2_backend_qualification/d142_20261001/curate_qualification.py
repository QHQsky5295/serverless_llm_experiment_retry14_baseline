"""Reuse D141 qualification/evidence workflow for the opt-in stack observer."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal, digest

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d142_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == 'd12075c6cf283204b7d7023cd4598872c664d981'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['systemctl','--user','show','primelora-d142-stack-verify-20261001.scope','-p','ActiveState','--value'],text=True).strip() == 'inactive'
assert 'Ran 335 tests in 75.091s\n\nOK\n' in (raw/'test.log').read_text()
assert 'Exit status: 0' in (raw/'test_time.txt').read_text()
subprocess.run(['sha256sum','-c',str(raw/'test_sources.sha256')],check=True)
cleanup = (raw/'test_cleanup.txt').read_text()
assert 'InvocationID=6ee228d145ed41fe92b735dd2fa9076c' in cleanup and 'TasksCurrent=0' in cleanup
events = {r.split()[0]:int(r.split()[1]) for r in cleanup.splitlines()
          if r.startswith(('low ', 'high ', 'max ', 'oom ', 'oom_kill ', 'oom_group_kill '))}
assert len(events) == 6 and not any(events.values())
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
files = [root/p for p in ('faaslora/__init__.py','faaslora/utils/logger.py',
    'tests/test_ieee_tc_stack_diagnostic.py','docs/ieee_tc/D142_STACK_DIAGNOSTIC_QUALIFICATION.md')]
files += [raw/name for name in ('test.log','test_time.txt','test_scope.txt','test_sources.sha256',
    'test_cleanup.txt','test_launcher.log','verify_stack_diagnostic.sh','curate_qualification.py')]
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for p in files:
    assert p.stat().st_size < 2*1024**2
    data = p.read_bytes()
    assert secret not in data
    assert not any(r.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in r for r in data.splitlines())
    if p.suffix == '.py': compile(data, str(p), 'exec')
    if p.suffix == '.sh': subprocess.run(['bash','-n',str(p)],check=True)
for p in raw.glob('*.sh'): subprocess.run(['bash','-n',str(p)],check=True)
compile((raw/'verify_prefix1_prelaunch.py').read_bytes(),'verify_prefix1_prelaunch.py','exec')
result = dict(kind='d142_stack_observer_cpu_qualification_v1',
    parent_commit='d12075c6cf283204b7d7023cd4598872c664d981',
    decision='opt_in_diagnostic_cpu_qualified_gpu_observation_pending',
    tests=335,test_seconds=75.091,formal_performance_result=False,cuda_executed=False,
    cpu_time_profile=False,measured_observer_overhead=None,
    protected=protected,cleanup_memory_events=events,
    serving_policy_change=False,source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
curated=out/'20261001_d142_stack_qualification.json'
with curated.open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
files.append(curated)
bundle=out/'20261001_d142_stack_qualification_sources.tar.gz'
with bundle.open('xb') as f:
    with tarfile.open(fileobj=f,mode='w:gz') as archive:
        for p in files: archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(files)
    for member,p in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==digest(p)
with (out/'20261001_d142_stack_qualification_sources.sha256').open('x') as f:
    f.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,tests=335)))
