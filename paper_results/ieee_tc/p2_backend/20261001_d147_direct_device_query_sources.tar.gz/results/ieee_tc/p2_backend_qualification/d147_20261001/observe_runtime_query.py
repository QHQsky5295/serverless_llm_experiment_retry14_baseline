"""Reuse D143 bounded stack reader and compare only the device-query boundary.

No model loading, inference, new trace, remote access or state/cache reuse.
Eight alternating query pairs/device are diagnostics, not service replicates.
"""
import ast
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import subprocess
import time
from types import SimpleNamespace

from scripts import run_all_experiments as run
from faaslora.experiment.experiment_stack import ExperimentConfig
from faaslora.memory.gpu_monitor import GPUMemoryMonitor
import pynvml
import torch

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d147_20261001'
prior = root/'results/ieee_tc/p2_backend_qualification/d143_20261001'
parent = '7f42cbdd143ab917927237abcf136bc2dc18e608'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
assert not torch.cuda.is_initialized()
spec = importlib.util.spec_from_file_location('d143_reader', prior/'collect_prefix1_cpu.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
summary_path = prior/'prefix1_cpu_samples.json'
assert reader.digest(summary_path) == '1f48bcc5b5ea6832bd913098656f18f27c057bffa3257c79b20459a2477509be'
summary = json.loads(summary_path.read_text())
process = next(p for p in summary['processes'] if p['pid'] == 1586316)
for item in process['source_refs']:
    assert reader.digest(Path(item['path'])) == item['sha256']
evidence = prior/'7b_full_w0_prefix1/launch.launch'
receipt_path = evidence/'exec_receipt.json'
terminals_path = evidence/'physical_deployment/request_terminals.jsonl'
receipt = json.loads(receipt_path.read_text())
terminals = [r for r, partial in reader.rows(terminals_path) if not partial]
assert len(terminals) == len({r['request_id'] for r in terminals}) == 1000
assert all(r['clock_id'] == receipt['external_replay']['clock_id'] for r in terminals)
start = receipt['external_replay']['replay_t0_s']
end = max(r['at'] for r in terminals)
meta_path = evidence/'diagnostic_stacks/1586316-34561749.json'
meta = json.loads(meta_path.read_text())
counts = Counter()
examples = []
for row, partial in reader.rows(meta_path.with_suffix('.stacks.jsonl')):
    assert not partial
    if not start <= row['observed_monotonic_s'] <= end:
        continue
    main, = [t for t in row['threads'] if t['ident'] == meta['main_thread_ident']]
    counts['request_window_main_samples'] += 1
    frames = main['frames']
    matches = [i for i,(f,n,_) in enumerate(frames)
        if f.endswith('/scripts/run_all_experiments.py') and n == '_gpu_runtime_snapshot']
    if not matches:
        continue
    counts['runtime_snapshot_inclusive_samples'] += 1
    index, = matches
    shell = any(f.endswith('/subprocess.py') and n == 'check_output'
                for f,n,_ in frames[:index])
    counts['runtime_snapshot_subprocess_samples'] += int(shell)
    caller = frames[index+1][1] if index+1 < len(frames) else 'truncated'
    counts['caller:' + caller] += 1
    if shell:
        nearest_request = next((n for _,n,_ in frames[index+1:]
            if n in ('_finish_runtime_request_reservation', '_exec_request_in_reservation',
                     '_emit_live_snapshot')), 'other')
        counts['request_site:' + nearest_request] += 1
        examples.append(dict(index=row['index'],at=row['observed_monotonic_s'],
            truncated=main['truncated'],frames=frames[:min(len(frames),index+5)]))
assert counts['request_window_main_samples'] == 570

old_source = subprocess.check_output(['git','show',f'{parent}:scripts/run_all_experiments.py'])
tree = ast.parse(old_source)
cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name == 'ScenarioRunner')
function = next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name == '_gpu_runtime_snapshot')
namespace = dict(vars(run))
exec(compile(ast.Module(body=[function],type_ignores=[]),f'{parent}:runtime_snapshot','exec'),namespace)
old_query = namespace['_gpu_runtime_snapshot']
cfg = ExperimentConfig({'memory':{'gpu':{'device_ids':[0],
    'monitor':{'observation_mode':'nvml_device'}}}})
monitor = GPUMemoryMonitor(cfg)
runner = run.ScenarioRunner.__new__(run.ScenarioRunner)
runner._routing_policy = 'ieee_confirmed'
runner._ieee_nvml_initialized = False
runner._stack = SimpleNamespace(gpu_monitor=monitor)
measurements = []
try:
    devices = [{'index':i,'uuid':pynvml.nvmlDeviceGetUUID(pynvml.nvmlDeviceGetHandleByIndex(i))}
               for i in range(pynvml.nvmlDeviceGetCount())]
    assert len(devices) == 4
    for repetition in range(8):
        for item in devices:
            methods = [('old_cli',old_query),('candidate_nvml',run.ScenarioRunner._gpu_runtime_snapshot)]
            if repetition % 2:
                methods.reverse()
            for name,fn in methods:
                t0 = time.perf_counter_ns()
                value = fn(runner,item['index'])
                elapsed = (time.perf_counter_ns()-t0)/1e6
                assert value is not None and len(value) == 3
                measurements.append(dict(repetition=repetition, device=item['index'],
                    method=name, elapsed_ms=elapsed, value=value))
    assert monitor.devices == [0] and monitor.device_count == 1
    assert not torch.cuda.is_initialized()
finally:
    if runner._ieee_nvml_initialized:
        pynvml.nvmlShutdown()
        runner._ieee_nvml_initialized = False
    pynvml.nvmlShutdown()  # matches this script's passive monitor construction
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
aggregates = []
for i in range(4):
    for name in ('old_cli','candidate_nvml'):
        samples = [r['elapsed_ms'] for r in measurements if r['device']==i and r['method']==name]
        aggregates.append(dict(device=i,method=name,n=len(samples),
            mean_ms=statistics.mean(samples),median_ms=statistics.median(samples),max_ms=max(samples)))
out = dict(kind='d147_runtime_device_query_diagnostic_v1',parent_commit=parent,
    historical_counts=dict(counts),historical_examples=examples,
    historical_window=dict(start_s=start,end_s=end),
    query_measurements=measurements,query_summary=aggregates,devices=devices,
    source_refs=[dict(path=str(p),sha256=reader.digest(p)) for p in
        (summary_path,meta_path,meta_path.with_suffix('.stacks.jsonl'),receipt_path,
         terminals_path,prior/'collect_prefix1_cpu.py',Path(__file__),
         root/'scripts/run_all_experiments.py')],
    old_runner_sha256=hashlib.sha256(old_source).hexdigest(),
    caveats=['Stack occurrence is not CPU/wall time; GIL sampling is biased.',
        'Idle-device query microtest is not a serving speedup or independent replay.',
        'No cross-call readings cache; initial monitor scope remains [0].',
        'CLI MiB formatting may quantize memory; NVML returns actual bytes.',
        'Successive hardware reads need not be simultaneous.'],
    cuda_initialized=False,formal_performance_result=False)
with (raw/'device_query_observation.json').open('x') as stream:
    json.dump(out,stream,indent=2,allow_nan=False)
print(json.dumps(dict(counts=dict(counts),query_summary=aggregates)))
