#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in red|green|regression|observe|green2|regression2|observe2|verify) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d147_20261001
unit="primelora-d147-${phase}-20261001.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sha256sum scripts/run_all_experiments.py tests/test_ieee_tc_worker_observation.py > "$raw/${phase}_sources.sha256"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
if [[ "$phase" = regression* ]]; then
  args=(-m unittest tests.test_ieee_tc_worker_observation tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_service_events tests.test_ieee_tc_native_retirement tests.test_basic_smoke -v)
elif [[ "$phase" = observe* ]]; then
  python=/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python
  args=("$raw/observe_runtime_query.py")
  if test "$phase" = observe2; then args=("$raw/observe_runtime_query_v2.py"); fi
elif test "$phase" = verify; then
  args=("$raw/verify_query.py")
else
  args=(-m unittest tests.test_ieee_tc_worker_observation.ControllerRuntimeDeviceQuery -v)
fi
exec /usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
