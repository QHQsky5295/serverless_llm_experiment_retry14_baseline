"""Reuse D143 bounded stack reader and compare only the device-query boundary.

No model loading, inference, new trace, remote access or state/cache reuse.
Eight alternating query pairs/device are diagnostics, not service replicates.
"""
import ast
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import subprocess
import time
from types import SimpleNamespace

from scripts import run_all_experiments as run
from faaslora.experiment.experiment_stack import ExperimentConfig
from faaslora.memory.gpu_monitor import GPUMemoryMonitor
import pynvml
import torch

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d147_20261001'
prior = root/'results/ieee_tc/p2_backend_qualification/d143_20261001'
parent = '7f42cbdd143ab917927237abcf136bc2dc18e608'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
assert not torch.cuda.is_initialized()
first = raw/'device_query_observation.json'
assert hashlib.sha256(first.read_bytes()).hexdigest() == 'b4620467bfc5a8df442a28c56145b7627697df2d5c0cff5233ddd85fbe7ce1d5'
historical = json.loads(first.read_text())
counts = historical['historical_counts']
# Reuse completed D143 accounting rather than repeat the same source analysis.

old_source = subprocess.check_output(['git','show',f'{parent}:scripts/run_all_experiments.py'])
tree = ast.parse(old_source)
cls = next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name == 'ScenarioRunner')
function = next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name == '_gpu_runtime_snapshot')
namespace = dict(vars(run))
exec(compile(ast.Module(body=[function],type_ignores=[]),f'{parent}:runtime_snapshot','exec'),namespace)
old_query = namespace['_gpu_runtime_snapshot']
cfg = ExperimentConfig({'memory':{'gpu':{'device_ids':[0],
    'monitor':{'observation_mode':'nvml_device'}}}})
monitor = GPUMemoryMonitor(cfg)
runner = run.ScenarioRunner.__new__(run.ScenarioRunner)
runner._routing_policy = 'ieee_confirmed'
runner._ieee_nvml_initialized = False
runner._stack = SimpleNamespace(gpu_monitor=monitor)
measurements = []
try:
    devices = [{'index':i,'uuid':pynvml.nvmlDeviceGetUUID(pynvml.nvmlDeviceGetHandleByIndex(i))}
               for i in range(pynvml.nvmlDeviceGetCount())]
    assert len(devices) == 4
    for repetition in range(8):
        for item in devices:
            methods = [('old_cli',old_query),('candidate_nvml',run.ScenarioRunner._gpu_runtime_snapshot)]
            if repetition % 2:
                methods.reverse()
            for name,fn in methods:
                t0 = time.perf_counter_ns()
                value = fn(runner,item['index'])
                elapsed = (time.perf_counter_ns()-t0)/1e6
                assert value is not None and len(value) == 3
                measurements.append(dict(repetition=repetition, device=item['index'],
                    method=name, elapsed_ms=elapsed, value=value))
    assert monitor.devices == [0] and monitor.device_count == 1
    assert not torch.cuda.is_initialized()
finally:
    if runner._ieee_nvml_initialized:
        pynvml.nvmlShutdown()
        runner._ieee_nvml_initialized = False
    pynvml.nvmlShutdown()  # matches this script's passive monitor construction
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
aggregates = []
for i in range(4):
    for name in ('old_cli','candidate_nvml'):
        samples = [r['elapsed_ms'] for r in measurements if r['device']==i and r['method']==name]
        aggregates.append(dict(device=i,method=name,n=len(samples),
            mean_ms=statistics.mean(samples),median_ms=statistics.median(samples),max_ms=max(samples)))
paired_values = []
for repetition in range(8):
    for i in range(4):
        pair = {r['method']: r['value'] for r in measurements
                if r['repetition']==repetition and r['device']==i}
        old, new = pair['old_cli'], pair['candidate_nvml']
        # CLI rounds displayed MiB; do not round direct bytes in production.
        assert all(abs(old[j]-new[j]) <= .5/1024 for j in (0,1))
        assert old[2] == new[2]  # idle diagnostic only, not a live-query invariant
        paired_values.append(dict(repetition=repetition,device=i,
            used_difference_mib=1024*(new[0]-old[0])))
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
out = dict(kind='d147_runtime_device_query_v2_diagnostic',parent_commit=parent,
    historical_counts=counts,query_measurements=measurements,query_summary=aggregates,
    devices=devices,idle_pairs_match_cli_resolution=True,paired_values=paired_values,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in
        (first, Path(__file__), root/'scripts/run_all_experiments.py')],
    old_runner_sha256=hashlib.sha256(old_source).hexdigest(),
    caveats=historical['caveats'] + ['First candidate rejected: v1 used includes reserved.',
        'Version 2 used excludes driver reservation on this pinned driver.'],
    cuda_initialized=False,formal_performance_result=False)
with (raw/'device_query_observation_v2.json').open('x') as stream:
    json.dump(out,stream,indent=2,allow_nan=False)
print(json.dumps(dict(counts=dict(counts),query_summary=aggregates)))

