"""Reuse D146 source/test/cleanup/protected/bundle checks for D147."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d147_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
parent = '7f42cbdd143ab917927237abcf136bc2dc18e608'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
changed = {'scripts/run_all_experiments.py','tests/test_ieee_tc_worker_observation.py'}
sources = json.loads((root/'results/ieee_tc/p2_backend_qualification/d145_20261001/prelaunch_verification.json').read_text())['source_sha256']
sources = {str((root/name).resolve()):sha for name,sha in sources.items()}
d146 = out/'20261001_d146_native_rpc_failure_context.json'
assert digest(d146) == '3cc80f33368b81926bbfa0f0affdb47b52a5a5ef53baa772a12d52dca16b17b2'
for ref in json.loads(d146.read_text())['source_refs']:
    if ref['path'].endswith(('/scripts/run_all_experiments.py','/tests/test_ieee_tc_native_retirement.py')):
        sources[str(Path(ref['path']).resolve())] = ref['sha256']
for name,sha in sources.items():
    path = Path(name)
    if path in {root/p for p in changed}:
        assert hashlib.sha256(subprocess.check_output(['git','show',f'{parent}:{path.relative_to(root)}'])).hexdigest() == sha, name
    else:
        assert digest(path) == sha, name

old_runner = raw/'candidate1_runner.py'
old_tests = raw/'candidate1_tests.py'
phases = ('red','green','regression','observe','green2','observe2','regression2')
cleanup = {}
for phase in phases:
    unit = f'primelora-d147-{phase}-20261001.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    events = {r.split()[0]:int(r.split()[1]) for r in (raw/f'{phase}_cleanup.txt').read_text().splitlines()
        if r.startswith(('low ','high ','max ','oom ','oom_kill ','oom_group_kill '))}
    assert len(events) == 6 and not any(events.values()), phase
    assert re.search(r'InvocationID=[a-f0-9]{32}',(raw/f'{phase}_scope.txt').read_text())
    assert f'Exit status: {1 if phase == "red" else 0}' in (raw/f'{phase}_time.txt').read_text()
    for line in (raw/f'{phase}_sources.sha256').read_text().splitlines():
        sha,name = line.split(maxsplit=1)
        if phase == 'red' and name == 'scripts/run_all_experiments.py':
            actual = hashlib.sha256(subprocess.check_output(['git','show',f'{parent}:{name}'])).hexdigest()
        elif phase in ('red','green','regression','observe'):
            actual = digest(old_runner if name.endswith('run_all_experiments.py') else old_tests)
        else:
            actual = digest(root/name)
        assert actual == sha, (phase,name)
    cleanup[phase] = events
assert 'FAILED (failures=6)' in (raw/'red.log').read_text()
for phase,n in (('green',6),('green2',6),('regression',543),('regression2',543)):
    assert re.search(rf'Ran {n} tests in [\d.]+s\n\nOK\n',(raw/f'{phase}.log').read_text())
observations = []
for name,sha in [('device_query_observation.json','b4620467bfc5a8df442a28c56145b7627697df2d5c0cff5233ddd85fbe7ce1d5'),
                 ('device_query_observation_v2.json','15e915f8c1ea29ce4fd43cf3dab7b3924b2857c7cc2bbd14f39b139bfea7dc51')]:
    path = raw/name
    assert digest(path) == sha
    value = json.loads(path.read_text())
    for ref in value['source_refs']:
        actual = Path(ref['path'])
        if name == 'device_query_observation.json' and actual == root/'scripts/run_all_experiments.py':
            actual = old_runner
        assert digest(actual) == ref['sha256'], actual
    observations.append(value)
assert observations[1]['idle_pairs_match_cli_resolution'] and len(observations[1]['paired_values']) == 32
assert all(not r['cuda_initialized'] and not r['formal_performance_result'] for r in observations)
assert observations[0]['historical_counts'] == observations[1]['historical_counts']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
files = [root/name for name in sorted(changed)]
files += [root/'docs/ieee_tc/D147_DIRECT_DEVICE_QUERY.md']
files += [raw/name for name in ('run_tests.sh','cleanup_test.sh','verify_query.py',
    'observe_runtime_query.py','observe_runtime_query_v2.py','candidate1_runner.py','candidate1_tests.py',
    'device_query_observation.json','device_query_observation_v2.json','api_cleanup.txt')]
for phase in phases:
    files += [raw/f'{phase}{suffix}' for suffix in ('.log','_time.txt','_scope.txt','_cleanup.txt','_sources.sha256')]
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for path in files:
    assert path.stat().st_size < 4*1024**2, path
    payload = path.read_bytes()
    assert secret not in payload, path
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in payload.splitlines()), path
    if path.suffix == '.py': compile(payload,str(path),'exec')
    if path.suffix == '.sh': subprocess.run(['bash','-n',str(path)],check=True)
result = dict(kind='d147_direct_device_query_qualification_v1',parent_commit=parent,
    decision='candidate2_qualified_for_ordinary_full_not_performance_acceptance',
    first_candidate_rejected_reason='nvml_v1_used_includes_driver_reserved_unlike_cli',
    targeted_tests=6,regression_tests=543,regression_seconds=22.880,
    regression_command_seconds=33.41,regression_peak_rss_kib=1193040,
    cuda_executed=False,formal_performance_result=False,performance_gain_established=False,
    retry_or_timeout_changed=False,equations_changed=False,ownership_guards_changed=False,
    budgets_or_monitor_scope_changed=False,reading_cache_added=False,
    historical_counts=observations[1]['historical_counts'],query_summary=observations[1]['query_summary'],
    idle_pairs_match_cli_resolution=True,protected=protected,
    prelaunch_sources_verified=len(sources),cleanup_events=cleanup,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
curated = out/'20261001_d147_direct_device_query.json'
with curated.open('x') as stream: json.dump(result,stream,indent=2,allow_nan=False)
files.append(curated)
bundle = out/'20261001_d147_direct_device_query_sources.tar.gz'
with bundle.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for path in files: archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(files)
    for member,path in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == digest(path)
with (out/'20261001_d147_direct_device_query_sources.sha256').open('x') as stream:
    stream.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,regression_tests=543)))
