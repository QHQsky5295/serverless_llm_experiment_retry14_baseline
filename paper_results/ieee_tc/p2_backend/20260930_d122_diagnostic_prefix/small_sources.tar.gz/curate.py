"""Adapt D121 evidence closure for the explicit diagnostic-only replay view."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal
from faaslora.datasets.workload_generator import FrozenReplayPlan

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d122_20260930'
out = root/'paper_results/ieee_tc/p2_backend/20260930_d122_diagnostic_prefix'
assert not out.exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
tests = {}
for name, count in (('preflight',66),('core',455)):
    log = (raw/f'{name}.log').read_text()
    time_log = (raw/f'{name}_time.txt').read_text()
    match = re.search(r'Ran (\d+) tests in ([\d.]+)s\n\nOK\n', log)
    assert match and int(match[1]) == count and 'Exit status: 0' in time_log
    tests[name] = dict(count=count,seconds=float(match[2]),passed=True)
assert 'FAILED (failures=2, errors=2)' in (raw/'tests.log').read_text()

closed = []
for name, identity in (('tests','9a2c9cba04804319ad02a086b9a517e7'),
                       ('tests2','ef9f4b1c260a46b8a787cbe35938b770')):
    unit = f'primelora-d122-prefix-{name}-20260930.scope'
    fields = dict(line.split('=',1) for line in subprocess.check_output(
        ['systemctl','--user','show',unit,'-p','InvocationID','-p','ControlGroup','-p','TasksCurrent'],text=True).splitlines())
    assert fields['InvocationID'] == identity and fields['TasksCurrent'] == '0'
    assert fields['ControlGroup'] == '/user.slice/user-1001.slice/user@1001.service/app.slice/'+unit
    cg = Path('/sys/fs/cgroup'+fields['ControlGroup'])
    assert not (cg/'cgroup.procs').read_text().strip()
    assert 'populated 0' in (cg/'cgroup.events').read_text().splitlines()
    events = dict(line.split() for line in (cg/'memory.events').read_text().splitlines())
    assert all(events[k] == '0' for k in ('high','max','oom','oom_kill'))
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    closed.append(dict(unit=unit,identity=fields,events=events,closed=True))

production = ['faaslora/datasets/workload_generator.py','scripts/ieee_tc_preflight.py',
              'scripts/run_all_experiments.py','scripts/run_all_experiments_user_scope.sh']
test_sources = ['tests/test_ieee_tc_external_replay.py','tests/test_ieee_tc_launch.py',
                'tests/test_ieee_tc_preflight.py']
allowed = set(production + test_sources)
before = json.loads((root/'results/ieee_tc/p2_backend_qualification/d119_20260930/prelaunch_verification.json').read_text())
changed = []
for name, expected in before['source_sha256'].items():
    path = Path(name) if name.startswith('/') else root/name
    actual = digest(path)
    if actual != expected:
        relative = str(path.relative_to(root))
        assert relative in allowed, name
        parent = subprocess.check_output(['git','show','716e6a5:'+relative])
        assert hashlib.sha256(parent).hexdigest() == expected, name
        changed.append(dict(path=name,before=expected,after=actual))
assert len(changed) == 5  # runner has two aliases in the inherited manifest.
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
trace = next(Path(name) for name in before['source_sha256'] if name.endswith('_trace.json') and 'llama2_7b' in name)
full = FrozenReplayPlan.load(trace)
prefix = FrozenReplayPlan.load(trace,count=1000)
context = dict(plan=prefix.identity(),tiny_witness=False,
               replay_scope='diagnostic_prefix_v1',diagnostic_prefix_count=1000)
assert FrozenReplayPlan.from_launch_context(context) == prefix
assert prefix.entries == full.entries[:1000] and full.source_count == 4000
for name in production + test_sources:
    if name.endswith('.py'):
        ast.parse((root/name).read_text())
subprocess.run(['bash','-n',str(root/production[-1])],check=True)
for name in ('test_prefix.sh','test_prefix2.sh','curate.sh'):
    subprocess.run(['bash','-n',str(raw/name)],check=True)

out.mkdir()
summary = dict(kind='d122_diagnostic_prefix_contract_v1',parent_commit='716e6a5cb6cc9dd264509520c57f4e08320f3a87',
    serving_optimizer_changed=False,measurement_interface_changed=True,formal_performance_result=False,
    gpu_or_remote_experiment_run=False,tests=tests,
    initial_suite=dict(total=232,passed=228,failures=2,errors=2,
        cause='launcher tests were run with the model interpreter lacking pidfd_send_signal'),
    next_diagnostic_input=context,next_diagnostic_first_offset_s=prefix.entries[0].offset_s,
    next_diagnostic_last_offset_s=prefix.entries[-1].offset_s,
    note='Original indexed input checked only; diagnostic GPU replay not yet run')
with (out/'summary.json').open('x') as handle:
    json.dump(summary,handle,indent=2,allow_nan=False)
names = ('test_prefix.sh','tests.log','tests_time.txt','tests_scope.txt',
         'test_prefix2.sh','preflight.log','preflight_time.txt','core.log','core_time.txt',
         'tests2_scope.txt','tests2_memory_events.txt','curate.py','curate.sh')
bundle = out/'small_sources.tar.gz'
with tarfile.open(bundle,'x:gz') as archive:
    for name in names:
        archive.add(raw/name,arcname=name)
with tarfile.open(bundle,'r:gz') as archive:
    for name in names:
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == digest(raw/name)
refs = [raw/name for name in names] + [root/name for name in production+test_sources]
refs += [out/'summary.json',bundle,root/'docs/ieee_tc/D122_DIAGNOSTIC_PREFIX_CONTRACT.md']
verification = dict(kind='d122_prefix_interface_verification_v1',tests_passed=521,
    inherited_sources_checked=len(before['source_sha256']),expected_changes=changed,
    protected=protected,closed_scopes=closed,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
with (out/'verification.json').open('x') as handle:
    json.dump(verification,handle,indent=2,allow_nan=False)
with (out/'small_sources.sha256').open('x') as handle:
    handle.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(tests_passed=521,protected=147,source_refs=len(before['source_sha256']),
    expected_changes=len(changed),summary_sha256=digest(out/'summary.json'),
    verification_sha256=digest(out/'verification.json'))))
