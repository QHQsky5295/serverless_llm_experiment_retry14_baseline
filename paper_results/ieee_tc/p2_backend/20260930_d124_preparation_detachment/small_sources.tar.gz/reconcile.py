"""D123 immutable evidence: absolute timing and line-level preparation samples.

No re-projection, replay, full raw load, or claim of user/client receipt.
"""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = Path(__file__).resolve().parent
old = ROOT/'results/ieee_tc/p2_backend_qualification/d123_20260930'
out = raw/'reconciliation.json'
assert not out.exists()
refs = []
def load(path, limit):
    assert path.stat().st_size <= limit
    data = path.read_bytes()
    refs.append(dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    return json.loads(data)

projection = load(old/'prefix1_request_projection.json', 9_000_000)
deployment = load(old/'7b_full_w0_prefix1/launch.launch/physical_deployment/deployment.json', 100_000)
summary = load(ROOT/'paper_results/ieee_tc/p2_backend/20260930_d123_7b_full_w0_prefix1.json', 100_000)
rows = []
for r in projection['requests']:
    if not r['success']:
        continue
    t = r['native_token_timing']
    a = deployment['arrival_start_s'] + r['scheduled_arrival_offset_s']
    true_dispatch = (t['controller_admitted_monotonic_s']-a)*1000
    gap = true_dispatch-r['dispatch_admission_wait_ms']
    ttft = (t['native_first_token_monotonic_s']-a)*1000
    e2e = (t['controller_completed_monotonic_s']-a)*1000
    assert abs(ttft-r['overall_ttft_ms']-gap) < 1e-6
    assert abs(e2e-r['overall_e2e_ms']-gap) < 1e-6
    rows.append(dict(request_id=r['request_id'], omitted_interval_ms=gap,
        reported_dispatch_ms=r['dispatch_admission_wait_ms'], absolute_dispatch_ms=true_dispatch,
        reported_ttft_ms=r['overall_ttft_ms'], absolute_ttft_ms=ttft,
        reported_controller_e2e_ms=r['overall_e2e_ms'], absolute_controller_e2e_ms=e2e))
assert len(rows) == 916
assert {r['request_id'] for r in rows if r['omitted_interval_ms'] > 1.} == {
    'req_00063','req_00330','req_00539'}

profile = load(old/'controller_prefix1.speedscope.json', 32_000_000)
frames = profile['shared']['frames']
targets = {'owned_preparation_inputs','_run_ieee_file_preparation_plan'}
counts = collections.Counter()
for thread in profile['profiles']:
    for stack in thread['samples']:
        chain = [frames[i] for i in stack]
        local = [f for f in chain if f.get('file','').startswith(str(ROOT)+'/')]
        if not local or any(f['name'] == 'save_results' for f in local):
            continue
        parent = local[-1]
        if parent['name'] in targets:
            leaf = chain[-1]
            counts[(parent['name'],parent.get('line'),leaf['name'],leaf.get('file',''))] += 1
del profile

main = load(old/'7b_full_w0_prefix1/launch.launch/physical_deployment/main_outcome.json', 16_000_000)
views = []
def inspect(value, path=()):
    if isinstance(value, dict):
        if value.get('kind') == 'ieee_owned_preparation_view_v1':
            views.append(dict(path=list(path), kind=value['kind'],
                adapters=len(value['sources']), native=value['native'] is not None))
        for k,v in value.items():
            if isinstance(v,(dict,list)): inspect(v,path+(k,))
    elif isinstance(value,list):
        for i,v in enumerate(value):
            if isinstance(v,(dict,list)): inspect(v,path+(i,))
inspect(main)
result = dict(kind='d124_timing_and_preparation_reconciliation_v1',
    historical_data_modified=False, performance_qualification=False,
    source_refs=refs, successful_request_count=len(rows), all_signed_gaps_nonnegative=all(
        r['omitted_interval_ms'] >= -1e-6 for r in rows),
    mean_omitted_ms=sum(r['omitted_interval_ms'] for r in rows)/len(rows),
    max_omitted_ms=max(r['omitted_interval_ms'] for r in rows),
    violations=[r for r in rows if r['omitted_interval_ms']>1.],
    affected_records=rows,
    profile_lines=[dict(function=k[0],line=k[1],leaf=k[2],leaf_file=k[3],samples=n)
                   for k,n in counts.most_common()],
    complete_preparation_views_in_normal_outcome=views,
    caveats=['Absolute controller completion is not client response receipt.',
        'The source code proves a partition gap; its sub-operations were not independently timed.',
        'Online control consumes TTFT; future correction changes runtime identity.',
        'Profile samples are not wall time, and neither issue yet explains aggregate backlog.'])
with out.open('x') as h: json.dump(result,h,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in result.items() if k not in ('affected_records','source_refs')},indent=2))
