"""One bounded paired causal probe; fixed received values, no GPU/remote IO.

Exercise actual preparation input/selector validation with the existing owner
fixture, then the actual saved 7B native JSON component (not a full online plan).
"""
import ast
import asyncio
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from unittest.mock import patch

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from faaslora.preloading import preloading_planner as p
from tests.test_ieee_tc_transfer_pressure import OwnedPreparationPlanning

raw=Path(__file__).resolve().parent
assert not (raw/'preparation_probe.json').exists()
reference_commit='5e3407b16b62e5c8a85e81027b4c24f55e367a65'
source=subprocess.check_output(['git','show',reference_commit+':faaslora/preloading/preloading_planner.py'],text=True)
tree=ast.parse(source)
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='owned_preparation_inputs')
namespace=dict(vars(p))
exec(compile(ast.Module(body=[node],type_ignores=[]),'<D123 frozen preparation input function>','exec'),namespace)
reference_inputs=namespace['owned_preparation_inputs']

def wire(x):return json.dumps(x,sort_keys=True,separators=(',', ':'),allow_nan=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()

async def paired(name, before, after, verify):
    rows=[]
    for trial in range(3):
        methods=[('reference',before),('candidate',after)]
        if trial%2:methods.reverse()
        for position,(method,call) in enumerate(methods):
            future=asyncio.get_running_loop().create_future()
            start=time.perf_counter_ns()
            asyncio.get_running_loop().call_soon(lambda:future.set_result(time.perf_counter_ns()))
            value=call()
            end=time.perf_counter_ns()
            callback=await future
            verify(value)
            rows.append(dict(trial=trial,position=position,method=method,
                elapsed_ms=(end-start)/1e6,ready_callback_delay_ms=(callback-start)/1e6))
    return dict(case=name,samples=rows)

factory=OwnedPreparationPlanning()
fixture,runner,queue,slot,_=factory.make()
try:
    with patch.object(p,'owned_preparation_inputs',wraps=p.owned_preparation_inputs) as observed:
        plan=factory.plan(runner,slot)
    kwargs=observed.call_args.kwargs
    expected=reference_inputs(**kwargs)
    assert p.owned_preparation_inputs(**kwargs)==expected
    before=wire(kwargs['file_snapshot'])
    def verify_inputs(value):
        assert value==expected
        assert wire(kwargs['file_snapshot'])==before
        value['source_view']['files']['artifacts']['a']['targets']['nvme']['path']='copy-only'
        assert wire(kwargs['file_snapshot'])==before
    selector=runner._stack.preloading_planner
    def validate_copied(copier):
        copied=copier(plan)
        selected=selector.validate_ieee_execution_plan(copied)
        return copied,selected
    def verify_plan(value):
        copied,selected=value
        assert copied==plan and selected==plan['selected']
        copied['source_view']['sources']['a']['selected_source']['tier']='remote'
        try:selector.validate_ieee_execution_plan(copied)
        except ValueError:pass
        else:raise AssertionError('changed physical owner view was accepted')
        selector.validate_ieee_execution_plan(plan)
    cases=[asyncio.run(paired('actual_owned_inputs_four_adapter_owner_fixture',
        lambda:reference_inputs(**kwargs),lambda:p.owned_preparation_inputs(**kwargs),verify_inputs)),
        asyncio.run(paired('actual_plan_copy_and_selector_validation_four_adapter_owner_fixture',
        lambda:validate_copied(copy.deepcopy),lambda:validate_copied(p.copy_ieee_preparation_plan),verify_plan))]
    fixture_identity=dict(source_snapshot_id=plan['source_snapshot_id'],plan_sha256=plan['plan_sha256'],
        adapter_count=len(plan['source_view']['sources']),view_bytes=len(wire(plan['source_view'])),
        selected={k:[r.artifact_id for r in v] for k,v in plan['selected'].items()})
finally:
    asyncio.run(queue.close())
    factory.doCleanups()

# Reuse D121's saved discovery path, rather than traverse/reprofile the old run.
prior=json.loads((ROOT/'paper_results/ieee_tc/p2_backend/20260930_d121_preparation_copy/summary.json').read_text())
record=next(r for r in prior['models'] if r['model']=='7b')
source_path=Path(record['source_path'])
assert source_path.stat().st_size==20341207
encoded=source_path.read_bytes()
assert sha(encoded)==record['source_sha256']
view=json.loads(encoded)
for key in record['selected_path']:view=view[key]
expected_bytes=wire(view)
assert sha(expected_bytes)==record['view_sha256']
def old_freeze():
    detached=copy.deepcopy(view)
    return detached,sha(wire(detached))
def verify_component(value):
    detached,digest=value
    assert detached==view and digest==record['view_sha256']
    detached['sources'][0]['adapter_id']='copy-only'
    assert wire(view)==expected_bytes
cases.append(asyncio.run(paired('retained_7b_native_JSON_component_only',old_freeze,
    lambda:p.freeze_preparation_source_view(view),verify_component)))
result=dict(kind='d124_preparation_detachment_causal_probe_v1',reference_commit=reference_commit,
    old_function_source_sha256=sha(source.encode()),cases=cases,fixture=fixture_identity,
    retained_component=record,formal_performance_result=False,production_full_accepted=False,
    limitations=['Four-adapter controlled owner fixture is not a 500-adapter performance workload.',
        'D88 retained 7B native component has only two registered adapters; not D123 maximum state.',
        'Paired CPU repeats establish component effects only, not seed-level CI or Full speedup.',
        'No owner/epoch/content/budget validation or live reservation was removed.'],
    source_refs=[dict(path=str(source_path),sha256=record['source_sha256']),
        dict(path=str(Path(p.__file__)),sha256=sha(Path(p.__file__).read_bytes()))])
with (raw/'preparation_probe.json').open('x') as h:json.dump(result,h,indent=2,allow_nan=False)
print(json.dumps(dict(cases=cases,fixture=fixture_identity),indent=2))

