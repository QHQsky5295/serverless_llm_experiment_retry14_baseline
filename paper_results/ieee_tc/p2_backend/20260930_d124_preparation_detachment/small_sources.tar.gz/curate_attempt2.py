"""Reuse D123 small-evidence packaging and protected-result checks for D124."""
import csv
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path
from statistics import mean

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts.ieee_tc_preflight import verify_seal
raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/20260930_d124_preparation_detachment'
out.mkdir(exist_ok=True)
assert not any(out.iterdir()), 'failed first curator created only an empty directory'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
for unit in ('timing','preparation','probe2','verify'):
    assert subprocess.check_output(['systemctl','--user','show',
        f'primelora-d124-{unit}-20260930.scope','-p','ActiveState','--value'],text=True).strip()=='inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
counts={}
for name,expected in (('timing_tests',209),('preparation_tests',189),('verification_tests',425)):
    log=(raw/f'{name}.log').read_text()
    matches=re.findall(r'^Ran ([0-9]+) tests in ([0-9.]+)s\n\nOK\s*
    assert len(matches)==1 and int(matches[0][0])==expected
    assert 'Exit status: 0' in (raw/f'{name}_time.txt').read_text()
    counts[name]=dict(count=expected,reported_seconds=float(matches[0][1]))
for name in ('timing','probe2','verification'):
    values=dict(line.split() for line in (raw/f'{name}_memory.events').read_text().splitlines())
    assert all(int(v)==0 for v in values.values())
reconciliation=load(raw/'reconciliation.json')
assert reconciliation['successful_request_count']==916 and len(reconciliation['violations'])==3
assert len(reconciliation['affected_records'])==916
assert 'FileNotFoundError' in (raw/'preparation_probe.log').read_text()
assert 'Exit status: 1' in (raw/'preparation_probe_time.txt').read_text()
assert 'Exit status: 0' in (raw/'preparation_probe2_time.txt').read_text()
probe=load(raw/'preparation_probe.json')
assert not probe['production_full_accepted'] and len(probe['cases'])==3
table=[]
for case in probe['cases']:
    before=[r['elapsed_ms'] for r in case['samples'] if r['method']=='reference']
    after=[r['elapsed_ms'] for r in case['samples'] if r['method']=='candidate']
    assert len(before)==len(after)==3
    table.append(dict(case=case['case'],repeats=3,reference_mean_ms=mean(before),
        candidate_mean_ms=mean(after),relative_decrease=(mean(before)-mean(after))/mean(before)))
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
sources=[raw/name for name in ('reconciliation.json','preparation_probe.json','reconcile.py',
    'probe_preparation.py','probe_preparation_attempt2.py')]
sources += [ROOT/name for name in ('faaslora/preloading/preloading_planner.py',
    'scripts/run_all_experiments.py','tests/test_ieee_tc_native_timing.py',
    'tests/test_ieee_tc_preparation_snapshot_copy.py','docs/ieee_tc/D124_TIMING_AND_PREPARATION_DETACHMENT.md',
    'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md','paper_results/ieee_tc/p2_backend/20260930_d123_7b_full_w0_prefix1.json')]
sources.append(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))
summary=dict(kind='d124_timing_and_preparation_candidate_v1',correctness_tests=counts,
    correctness_tests_total=sum(v['count'] for v in counts.values()),
    tests_execution_note='209 timing/lifecycle tests preceded the preparation candidate; 189 and 425 include it.',
    timing={k:v for k,v in reconciliation.items() if k!='affected_records'},
    component_probe=probe,table=table,protected=protected,
    failed_attempt=dict(stage='CPU probe',reason='wrong D121 summary path',exit=1,
        original_source_preserved=True,original_log_preserved=True,tests_rerun=False,
        partial_fixture_measurements_not_emitted=True,correction='source path only'),
    gpu_or_remote_run=False,candidate_ready_for_full=True,production_full_accepted=False,
    source_refs=[dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p)) for p in sources])
with (out/'summary.json').open('x') as f:json.dump(summary,f,indent=2,allow_nan=False)
with (out/'component_table.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
with (out/'component_samples.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['case','trial','position','method','elapsed_ms','ready_callback_delay_ms'])
    writer.writeheader()
    for case in probe['cases']:
        for row in case['samples']:writer.writerow(dict(case=case['case'],**row))
# Same small-source bundle workflow as D123; include failed attempt and receipts.
members=sorted(p for p in raw.iterdir() if p.is_file() and p.stat().st_size<128*1024
               and p.suffix in {'.py','.sh','.json','.log','.txt','.events'}
               and p.name not in {'curation2.log','curation2_time.txt'})
bundle=out/'small_sources.tar.gz'
hashes={}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        data=p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        hashes[p.name]=hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames())==set(hashes)
    for name,expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected
with (out/'small_sources_members.json').open('x') as f:
    json.dump(dict(member_sha256=hashes,member_checks_pass=True),f,indent=2)
with (out/'small_sources.sha256').open('x') as f:f.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(output=str(out),tests=823,protected=147,
    bundle_bytes=bundle.stat().st_size,bundle_sha256=digest(bundle),members=len(hashes),
    table=table,summary_sha256=digest(out/'summary.json')),indent=2))
,log,re.MULTILINE)
    assert not re.search(r'^FAILED',log,re.MULTILINE)
    assert len(matches)==1 and int(matches[0][0])==expected
    assert 'Exit status: 0' in (raw/f'{name}_time.txt').read_text()
    counts[name]=dict(count=expected,reported_seconds=float(matches[0][1]))
for name in ('timing','probe2','verification'):
    values=dict(line.split() for line in (raw/f'{name}_memory.events').read_text().splitlines())
    assert all(int(v)==0 for v in values.values())
reconciliation=load(raw/'reconciliation.json')
assert reconciliation['successful_request_count']==916 and len(reconciliation['violations'])==3
assert len(reconciliation['affected_records'])==916
assert 'FileNotFoundError' in (raw/'preparation_probe.log').read_text()
assert 'Exit status: 1' in (raw/'preparation_probe_time.txt').read_text()
assert 'Exit status: 0' in (raw/'preparation_probe2_time.txt').read_text()
probe=load(raw/'preparation_probe.json')
assert not probe['production_full_accepted'] and len(probe['cases'])==3
table=[]
for case in probe['cases']:
    before=[r['elapsed_ms'] for r in case['samples'] if r['method']=='reference']
    after=[r['elapsed_ms'] for r in case['samples'] if r['method']=='candidate']
    assert len(before)==len(after)==3
    table.append(dict(case=case['case'],repeats=3,reference_mean_ms=mean(before),
        candidate_mean_ms=mean(after),relative_decrease=(mean(before)-mean(after))/mean(before)))
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
sources=[raw/name for name in ('reconciliation.json','preparation_probe.json','reconcile.py',
    'probe_preparation.py','probe_preparation_attempt2.py')]
sources += [ROOT/name for name in ('faaslora/preloading/preloading_planner.py',
    'scripts/run_all_experiments.py','tests/test_ieee_tc_native_timing.py',
    'tests/test_ieee_tc_preparation_snapshot_copy.py','docs/ieee_tc/D124_TIMING_AND_PREPARATION_DETACHMENT.md',
    'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md','paper_results/ieee_tc/p2_backend/20260930_d123_7b_full_w0_prefix1.json')]
sources.append(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))
summary=dict(kind='d124_timing_and_preparation_candidate_v1',correctness_tests=counts,
    correctness_tests_total=sum(v['count'] for v in counts.values()),
    tests_execution_note='209 timing/lifecycle tests preceded the preparation candidate; 189 and 425 include it.',
    timing={k:v for k,v in reconciliation.items() if k!='affected_records'},
    component_probe=probe,table=table,protected=protected,
    failed_attempt=dict(stage='CPU probe',reason='wrong D121 summary path',exit=1,
        original_source_preserved=True,original_log_preserved=True,tests_rerun=False,
        partial_fixture_measurements_not_emitted=True,correction='source path only'),
    gpu_or_remote_run=False,candidate_ready_for_full=True,production_full_accepted=False,
    source_refs=[dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p)) for p in sources])
with (out/'summary.json').open('x') as f:json.dump(summary,f,indent=2,allow_nan=False)
with (out/'component_table.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
with (out/'component_samples.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['case','trial','position','method','elapsed_ms','ready_callback_delay_ms'])
    writer.writeheader()
    for case in probe['cases']:
        for row in case['samples']:writer.writerow(dict(case=case['case'],**row))
# Same small-source bundle workflow as D123; include failed attempt and receipts.
members=sorted(p for p in raw.iterdir() if p.is_file() and p.stat().st_size<128*1024
               and p.suffix in {'.py','.sh','.json','.log','.txt','.events'})
bundle=out/'small_sources.tar.gz'
hashes={}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        data=p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        hashes[p.name]=hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames())==set(hashes)
    for name,expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected
with (out/'small_sources_members.json').open('x') as f:
    json.dump(dict(member_sha256=hashes,member_checks_pass=True),f,indent=2)
with (out/'small_sources.sha256').open('x') as f:f.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(output=str(out),tests=823,protected=147,
    bundle_bytes=bundle.stat().st_size,bundle_sha256=digest(bundle),members=len(hashes),
    table=table,summary_sha256=digest(out/'summary.json')),indent=2))

