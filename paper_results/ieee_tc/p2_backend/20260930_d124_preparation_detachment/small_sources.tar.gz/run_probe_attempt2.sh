#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d124_20260930
unit=primelora-d124-probe2-20260930.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/probe2_scope.txt"
/usr/bin/time -v -o "$raw/preparation_probe2_time.txt" \
  /home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python "$raw/probe_preparation_attempt2.py" \
  > "$raw/preparation_probe2.log" 2>&1
group=$(systemctl --user show "$unit" -p ControlGroup --value)
cp "/sys/fs/cgroup${group}/memory.events" "$raw/probe2_memory.events"
