#!/usr/bin/env bash
set -euo pipefail
# Reuse D135 exact-identity cleanup; execute only AFTER projection terminal.
date -Is
test "$(systemctl --user show primelora-tc-svc-fb0fb6dc2ebb411ca7e272c20372cf85.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d137-full1-project-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 8268d3e498934c0b967e327631b4d26e
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d137-full1-project-20261001.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
