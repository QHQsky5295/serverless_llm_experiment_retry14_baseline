"""D137 ordinary Full: reuse D135 config and immutable input evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight
from faaslora.runtime_configuration import resolve_facade_lora_capacity

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d137_20261001'
previous = root/'results/ieee_tc/p2_backend_qualification/d135_20261001'
expected_commit = '233ccc29bfe016950efe73331739e0399cd9e81f'
prior_runtime = 'c164f874bee8fcfaa6735a5acdd04484df3c531d'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected_commit
dirty = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty) <= {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'}, dirty
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old_path = root/'results/ieee_tc/p2_backend_qualification/d135_20261001/7b_main_config_full1.yaml'
new_path = raw/'7b_main_config_full1.yaml'
old, new = [yaml.safe_load(path.read_text()) for path in (old_path,new_path)]
for config in (old,new):
    assert config['workload']['total_requests'] == 4000
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
assert old == new, 'configuration differs beyond three fresh owned paths'
assert not (raw/'7b_full_w0_full1/launch.json').exists()
assert not (raw/'7b_nvme_full1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d137-7b-full1/tc_ieee_full').exists()
before = json.loads((previous/'prelaunch_verification.json').read_text())
refs = dict(before['source_sha256'])
allowed_changes = {'scripts/run_all_experiments.py','tests/test_ieee_tc_request_lifecycle.py'}
changes = []
for name, expected in list(refs.items()):
    path = Path(name) if name.startswith('/') else root/name
    actual = digest(path)
    if actual != expected:
        relative = str(path.relative_to(root))
        assert relative in allowed_changes, (name, expected, actual)
        old_source = subprocess.check_output(['git','show',prior_runtime+':'+relative],cwd=root)
        new_source = subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)
        assert hashlib.sha256(old_source).hexdigest() == expected, relative
        assert hashlib.sha256(new_source).hexdigest() == actual, relative
        changes.append(dict(path=relative,before=expected,after=actual))
        refs[name] = actual
for relative in allowed_changes:
    path = root/relative
    assert digest(path) == hashlib.sha256(subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)).hexdigest()
    refs[str(path)] = digest(path)
candidate = root/'paper_results/ieee_tc/p2_backend/20261001_d136_dispatch_permits.json'
assert digest(candidate) == '40d7d7b7e4826cc8628433a894c6ec6ad98732aca1b3ff74a37102d45d4ba247'
model = resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras'] == 24 and model['runtime_concurrency_cap'] == 2
assert model['max_num_seqs'] == 2 and model['max_loras'] == 4
for key in ('ieee_service_profile','ieee_preparation_profile'):
    binding = new['resource_coordination'][key]
    assert digest(Path(binding['path'])) == binding['sha256']
full_before = json.loads((root/'results/ieee_tc/p2_backend_qualification/d119_20260930/prelaunch_verification.json').read_text())
trace = full_before['trace']
subset = full_before['subset']
assert digest(Path(trace['source_path'])) == trace['source_sha256'] == 'efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
assert digest(Path(subset['path'])) == subset['sha256'] == 'aa94b21e1295aefde664e5b29c030a9e42e02af946369bfe9ae15336b89b3016'
for path in [raw/name for name in ('7b_main_config_full1.yaml','run_7b_full_w0_full1.sh',
    'activate_services_full1.sh','check_health.sh','verify_full1_prelaunch.py','prepare_full1.sh')]+[candidate,old_path]:
    refs[str(path)] = digest(path)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
resources = preflight([root,raw],32*1024**3)
assert resources['preflight_pass'], resources['issues']
receipt = dict(kind='d137_7b_full_prelaunch_v1',time_unix=time.time(),
    run='d137_7b_full_w0_full1',evidence_commit=expected_commit,
    runtime_source_commit=expected_commit,source_change='D136 FIFO outer dispatch permit ownership before waiter wake',
    expected_source_changes=changes,same_configuration_except_owned_paths=True,
    diagnostic_instrumentation=False,formal_performance_result=False,
    source_sha256=refs,protected=protected,resource_preflight=resources,trace=trace,subset=subset,
    replay_scope='ordinary_full_4000',diagnostic_prefix_count=None,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    comparison='Full development validation of D136 dispatch permit candidate; no formal SLO or winner claim',
    detailed_cpu_profiler=False,
    pending_metric_reconciliation='Preserve controller completion and outer terminal separately',
    reused_initialization='D88/D89; same D135 7B parent config, no new profiles/data/cache',
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),
    sha256=digest(raw/'prelaunch_verification.json'),protected=147,source_refs=len(refs),
    population=4000,same_config=True,resource_pass=True,formal=False,changes=changes)))
