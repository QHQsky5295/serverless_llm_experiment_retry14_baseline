#!/usr/bin/env bash
# Reuse the existing bounded evidence-check pattern; no performance experiment.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d137_20261001
unit=primelora-d137-legacy-audit-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/legacy_audit_scope.txt"
/usr/bin/time -v -o "$raw/legacy_audit_time.txt" /usr/bin/python3 - <<'PY'
import json
from datetime import datetime
from pathlib import Path
from scripts.ieee_tc_preflight import digest

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d137_20261001'
audit_path = root/'paper_results/ieee_tc/p2_backend/20261001_legacy_3b_contract_audit.json'

def bounded_json(path):
    assert path.stat().st_size < 128 * 1024**2, path
    with path.open() as f:
        return json.load(f)

audit_sha = digest(audit_path)
audit = bounded_json(audit_path)
requests = {}
stats = {}
for name, ref in audit['sources'].items():
    path = Path(ref['path'])
    assert path.stat().st_size == ref['bytes']
    assert digest(path) == ref['sha256'], path
    data = bounded_json(path)
    for key in ref['request_path'].split('.'):
        data = data[key]
    rows = sorted(data, key=lambda r: r['request_id'])
    requests[name] = rows
    stats[name] = {
        'count': len(rows),
        'unique_ids': len({r['request_id'] for r in rows}),
        'success': sum(r['success'] is True for r in rows),
        'input_tokens': sum(r['input_tokens'] for r in rows),
        'output_tokens': sum(r['output_tokens'] for r in rows),
        'max_input': max(r['input_tokens'] for r in rows),
        'max_output': max(r['output_tokens'] for r in rows),
        'prompt_hash_records': sum(bool(r.get('canonical_prompt_sha256')) for r in rows),
        'generation_contracts': sorted({r.get('generation_contract') for r in rows}, key=str),
    }
    assert stats[name] == audit[name], (name, stats[name], audit[name])
    assert digest(path) == ref['sha256'], path

def compare(a, b):
    assert len(a) == len(b)
    return {
        'ids_identical': all(x['request_id'] == y['request_id'] for x, y in zip(a, b)),
        'adapter_map_identical': all(x['adapter_id'] == y['adapter_id'] for x, y in zip(a, b)),
        'arrival_map_identical': all(x['scheduled_arrival_offset_s'] == y['scheduled_arrival_offset_s'] for x, y in zip(a, b)),
        'input_tokens_equal': sum(x['input_tokens'] == y['input_tokens'] for x, y in zip(a, b)),
        'output_tokens_equal': sum(x['output_tokens'] == y['output_tokens'] for x, y in zip(a, b)),
    }

pairs = {
    'local_vs_remote': compare(requests['legacy_local'], requests['legacy_remote']),
    'remote_vs_d118': compare(requests['legacy_remote'], requests['d118']),
}
for name, actual in pairs.items():
    assert actual == audit[name], (name, actual, audit[name])
rows = requests['d118']
input_audit = {
    'native_prompt_count_matches': sum(r['input_tokens'] == r['native_token_timing']['actual_prompt_tokens'] for r in rows),
    'content_max': max(r['canonical_prompt_tokens'] for r in rows),
    'content_total': sum(r['canonical_prompt_tokens'] for r in rows),
    'native_minus_content_unique': sorted({r['input_tokens'] - r['canonical_prompt_tokens'] for r in rows}),
}
assert input_audit == {k: v for k, v in audit['d118_input_count_audit'].items() if k != 'method'}
sealed_path = root/'paper_results/ieee_tc/p2_backend/20260930_d118_3b_full_w0_full11.json'
assert digest(sealed_path) == 'ff39d2b0fbb952f6bf1d0601115eff9888895b13d0a9b6c2d062c2fbef376eaf'
sealed = bounded_json(sealed_path)
assert any(ref['path'] == audit['sources']['d118']['path'] and ref['sha256'] == audit['sources']['d118']['sha256'] for ref in sealed['source_refs'])
assert digest(audit_path) == audit_sha
receipt = {
    'pass': True, 'kind': 'independent_legacy_3b_contract_recomputation_v1',
    'created_at': datetime.now().astimezone().isoformat(),
    'audit_path': str(audit_path), 'audit_sha256': audit_sha,
    'sources': audit['sources'], 'recomputed': stats,
    'pairs': pairs, 'd118_input_count_audit': input_audit,
    'sealed_d118_reference_matched': True,
    'script_sha256': digest(raw/'verify_legacy_contract_audit.sh'),
    'formal_performance_result': False,
}
with (raw/'legacy_audit_verification.json').open('x') as f:
    json.dump(receipt, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(json.dumps({'pass': True, 'source_files': len(requests), 'request_rows': sum(len(x) for x in requests.values()), 'audit_sha256': audit_sha}))
PY
