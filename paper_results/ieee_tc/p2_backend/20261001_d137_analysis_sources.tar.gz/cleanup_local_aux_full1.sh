#!/usr/bin/env bash
set -euo pipefail
# Reuse D137 exact-identity / empty-domain cleanup; only D137 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-fb0fb6dc2ebb411ca7e272c20372cf85.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-86e998ed65294520a86ae97eff027144.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 784f4920989d40e7b6433d5eb397b654
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-86e998ed65294520a86ae97eff027144.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
