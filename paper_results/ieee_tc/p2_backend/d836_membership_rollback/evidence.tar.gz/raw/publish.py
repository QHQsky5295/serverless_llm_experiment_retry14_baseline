"""Reuse D828 packaging for the exact, CPU-checked D834 rollback."""
import hashlib
from pathlib import Path

template = Path(__file__).resolve().parent.parent / 'd828_20261025/publish.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == '4690fe8a595eb36dd993059f162477ba21b7cb8ca6e5bfebb664d53a32683624'
source = template.read_text()
start = source.index("summary = read(OUT/'summary.json')")
end = source.index('\nclosed = []', start)
source = source[:start] + source[end:]
for old, new in (
    ('d828_post_file_owner_turn', 'd836_membership_rollback'),
    ("for phase in ('analysis', 'focused', 'regression'):", "for phase in ('focused',):"),
    ('d827_workspace_retirement/closure.json', 'd834_completed_membership_reuse/closure.json'),
    ("('d827_20261025', 'publish.py'), ('d824_20261025', 'backup.py')",
     "('d828_20261025', 'publish.py'), ('d824_20261025', 'backup.py')"),
    ('production_candidate=True', 'production_candidate=False, exact_rollback=True'),
    ('distinct_regression_tests=370, focused_tests_included=57', 'distinct_tests=207'),
    ("decision='One admitted owner anchor candidate CPU-qualified; complete unchanged 3B W2 next.'",
     "decision='D834 removed exactly after unchanged D835 joint SLO. D831 development base retained; all performance evidence preserved. No same-key retry and no new candidate.'"),
    ('D828_POST_FILE_OWNER_TURN_20261025.md', 'D836_MEMBERSHIP_ROLLBACK_20261025.md'),
    ("RAW/'regression_receipt.json'", "RAW/'focused_receipt.json'"),
    ('distinct_tests=370', 'distinct_tests=207'),
):
    assert old in source, old
    source = source.replace(old, new)
marker = "save(OUT/'closure.json', closure)"
extra = '''
base='0c93a6d92e2e7708c313f0c543e837cbe7118c9b'
for name, sha in closure['production_sources'].items():
    data=subprocess.check_output(['git','show',base+':'+str(Path(name).relative_to(ROOT))],cwd=ROOT)
    assert hashlib.sha256(data).hexdigest()==sha
receipt=read(RAW.parent/'d835_20261025/backup_completion.json')
assert receipt['passed'] and receipt['head']=='b7de1c04ca75d53971658118150407e0a7ca036b'
storage=ROOT/'paper_results/ieee_tc/storage/20261025_d835_closed_results.json'
storage_check=storage.with_name(storage.stem+'_verification.json')
assert read(storage_check)['passed'] and read(storage_check)['receipt_sha256']==p.digest(storage)
storage_scope=read(storage_check)['identity']
assert not Path(storage_scope['path']).exists() and not p.scope_still_owned(storage_scope)
log=(RAW/'focused.log').read_text()
assert 'Ran 194 tests' in log and 'Ran 13 tests' in log and log.count('\\nOK\\n')==2
closure.update(restored_reference_commit=base, production_rollback_pending=False,
    complete_result_backup=receipt, storage_receipt=ref(storage), storage_verification=ref(storage_check))
'''
assert source.count(marker) == 1
source = source.replace(marker, extra + '\n' + marker)
out = Path('/home/qhq/serverless_llm_experiment_retry14_baseline/paper_results/ieee_tc/p2_backend/d836_membership_rollback')
out.mkdir(parents=True, exist_ok=False)
exec(compile(source, str(template), 'exec'), globals())
