"""Reuse the explicit-path D824 checkpoint for rollback plus storage receipts."""
import hashlib
from pathlib import Path

template = Path(__file__).resolve().parent.parent / 'd824_20261025/backup.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == 'ee84b28423f93cea5a6764c529174b4531ad1bcf7c38ee4e1d37c95bc0b951c8'
source = template.read_text()
for old, new in (
    ('d824_current_ingress_pending', 'd836_membership_rollback'),
    ('107185c45f49a891c0b391b1140b7d765e83daea', 'b7de1c04ca75d53971658118150407e0a7ca036b'),
    ("OUT/'final_manifest.json'", "OUT/'manifest.json'"),
    ('D824_CURRENT_INGRESS_AND_CONTROL_20261025.md', 'D836_MEMBERSHIP_ROLLBACK_20261025.md'),
    ("         ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',",
     "         ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',\n         *[Path(path) for path in closure['production_sources']],\n         ROOT/'paper_results/ieee_tc/storage/20261025_d835_closed_results.json',\n         ROOT/'paper_results/ieee_tc/storage/20261025_d835_closed_results_verification.json',\n         ROOT/'paper_results/ieee_tc/storage/20261025_d835_closed_results.py.snapshot',"),
    ('len(set(paths)) == 20', 'len(set(paths)) == 11'),
    ('backup/d824-current-ingress-control-20261025', 'backup/d836-membership-rollback-20261025'),
    ('tc: preserve current 3B ingress and actual scaling-trigger diagnosis (D824)',
     'tc: restore D831 after unchanged D835 joint SLO; preserve closed evidence (D836)'),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'), globals())
