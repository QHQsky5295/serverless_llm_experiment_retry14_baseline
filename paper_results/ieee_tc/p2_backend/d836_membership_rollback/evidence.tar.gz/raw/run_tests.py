"""Check the exact D834 rollback with the existing bounded CPU test runner."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d610_20261017/run_tests.py')
assert hashlib.sha256(source.read_bytes()).hexdigest() == '5b24776d3c359cc2f138ddef663ce04afcbb0edfa3ac166bcf06bc5c3e573efc'
code = source.read_text()
old = "'faaslora/memory/residency_manager.py',\n    'tests/test_ieee_tc_file_observation.py',\n    'tests/test_ieee_tc_request_lifecycle.py'"
new = "'faaslora/scheduling/resource_coordinator.py',\n    'tests/test_ieee_tc_transfer_pressure.py',\n    'tests/test_ieee_tc_shared_pressure_integration.py'"
assert code.count(old) == 1
code = code.replace(old, new)
old = "tests=(['tests.test_ieee_tc_file_observation']\n    if phase=='focused' else ['tests.test_ieee_tc_request_lifecycle',\n    'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_static_preparation'])"
new = "tests=['tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_shared_pressure_integration']"
assert code.count(old) == 1
code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
