"""Reuse D610 bounded per-module qualification, changing only the affected suite."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d610_20261017/run_tests.py')
code=source.read_text()
old="tests=(['tests.test_ieee_tc_file_observation']"
new="tests=(['tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication']"
assert code.count(old)==1
code=code.replace(old,new)
exec(compile(code,str(source),'exec'))
