"""Reuse D595 qualification for affected inventory and delivery API tests."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/run_tests.py')
code=source.read_text().replace("('focused','regression')", "('observation',)")
start=code.index('paths=[ROOT/name');end=code.index('\nrefs=',start)
code=code[:start]+"""paths=[ROOT/name for name in ('faaslora/memory/residency_manager.py',
    'tests/test_ieee_tc_file_observation.py','tests/test_http_artifact_store.py',
    'tests/test_ieee_tc_request_lifecycle.py')]
"""+code[end:]
start=code.index('tests=(');end=code.index('\ncommand=',start)
code=code[:start]+"tests=['tests.test_ieee_tc_file_observation','tests.test_http_artifact_store']"+code[end:]
exec(compile(code,str(source),'exec'))
