"""Reuse D627 real-file measurement with the qualified private-verification candidate."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d627_20261017/component.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("d626_20261017/publication_closure.json", "d627_20261017/component_closure.json")
replace('fd783131934664f1dee49f78b21366c2aff7264d60a15c2a9bcb975e207bec4f',
        '3bf7490deff8c917bbad46b79526772a3803f9b030f559b8e63e976052d99407')
replace("prefix='tc-d627-publication-'", "prefix='tc-d628-publication-'")
replace("('_file_inventory','_source_observation','_publish_verified_source')",
        "('_file_inventory','_source_observation','_verify_publication_payload','_commit_verified_source')")
replace('assert len(owner.lock.rows)==1','assert len(owner.lock.rows)==4')
replace("all(h['under_owner_lock'] for h in hashes)","all(not h['under_owner_lock'] for h in hashes)")
replace('lock=owner.lock.rows[0],',
        "lock=dict(held_ms=sum(r['held_ms'] for r in owner.lock.rows),wait_ms=sum(r['wait_ms'] for r in owner.lock.rows)),lock_intervals=owner.lock.rows.copy(),")
replace('hash_under_lock=True','hash_under_lock=False')
replace('production_changed=False','production_changed=True')
exec(compile(code,str(source),'exec'))
