"""Reuse D612 checked explicit-path publisher for D627 evidence + D628 candidate."""
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/publish.py')
assert hashlib.sha256(source.read_bytes()).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace('d612_w2_quality_resource_diagnosis','d628_private_verification_locked_commit')
replace('f72091155cd3bb258651fc461db11b9113c72faf','6625a7eb05e95391d3a52d7da22046a4a5733bcc')
replace("assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')",
    "assert set(git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc').splitlines()) == {'faaslora/memory/residency_manager.py','tests/test_ieee_tc_request_lifecycle.py'}")
start=code.index("diagnosis=read(");end=code.index('\nprotected=',start)
code=code[:start]+"""parent_raw=RAW.parent/'d627_20261017'
component=read(RAW/'component_result.json');parent_component=read(parent_raw/'component_result.json')
assert component['passed'] and parent_component['passed']
assert component['production_changed'] and not component['formal_performance']
assert component['production_sha256']==p.digest(ROOT/'faaslora/memory/residency_manager.py')
assert len(component['rows'])==len(parent_component['rows'])==6
assert all(not row['hash_under_lock'] and row['hash_bytes']==33589802 for row in component['rows'])
assert all(row['hash_under_lock'] and row['hash_bytes']==33589802 for row in parent_component['rows'])
assert component['source_files']==parent_component['source_files']
for path,record in component['source_files'].items():assert p.digest(Path(path))==record['sha256']
for phase in ('regression','observation'):
    receipt=read(RAW/(phase+'_receipt.json'));assert receipt['passed']
    for name,sha in receipt['sources'].items():assert p.digest(Path(name))==sha
    assert receipt['log_sha256']==p.digest(RAW/(phase+'.log'))
assert not read(RAW/'focused_receipt.json')['passed']
assert read(RAW/'focused2_receipt.json')['passed']
for root,names in [(RAW,('focused','focused2','regression','component','observation')),
        (parent_raw,('component',)),(RAW.parent/'d626_20261017',('publication',))]:
    for name in names:
        closure=read(root/(name+'_closure.json'))
        assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
        assert not Path(closure['identity']['path']).exists()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
for name,sha in [('METRIC_PROTOCOL_FROZEN_V1.md','5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'),
        ('METRIC_PROTOCOL_SINGLE_RUN_V2.md','193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d')]:
    assert p.digest(ROOT/'docs/ieee_tc'/name)==sha
"""+code[end:]
replace('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md','D628_PRIVATE_VERIFICATION_LOCKED_COMMIT.md')
start=code.index('files=sorted(');end=code.index('\nassert sum(path.stat()',start)
code=code[:start]+"""files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log'),*RAW.glob('*_source.tar.gz')])
files+=sorted([*parent_raw.glob('*.py'),*parent_raw.glob('*.json')])
files += [doc,ROOT/'docs/ieee_tc/D627_PUBLICATION_CRITICAL_SECTION.md',
    ROOT/'faaslora/memory/residency_manager.py',ROOT/'tests/test_ieee_tc_request_lifecycle.py',
    RAW.parent/'d595_20261017/run_tests.py',RAW.parent/'d610_20261017/run_tests.py',
    RAW.parent/'d605_20261017/compare_inventory.py',
    RAW.parent.parent/'main_comparison/d594_20261017/close.py',
    RAW.parent/'d626_20261017/publication_closure.json',
    RAW.parent/'d612_20261017/publish.py']
"""+code[end:]
replace("kind='d612_reused_parent_closed_log_diagnosis_v1'", "kind='d628_private_verification_locked_commit_cpu_qualification_v1'")
replace('diagnosis=diagnosis,protected=protected,',
    "component=component,parent_component=parent_component,regression=read(RAW/'regression_receipt.json'),observation=read(RAW/'observation_receipt.json'),protected=protected,")
replace('production_changed=False,inference_runs_added=0,ranking_eligible=False',
    'production_changed=True,inference_runs_added=0,ranking_eligible=False,performance_accepted=False')
replace("names=[str(doc.relative_to(ROOT)),'docs/ieee_tc/EXECUTION_STATUS.md']",
    "names=[str(doc.relative_to(ROOT)),'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D627_PUBLICATION_CRITICAL_SECTION.md','faaslora/memory/residency_manager.py','tests/test_ieee_tc_request_lifecycle.py']")
replace('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
    'tc: qualify private payload verification with locked capacity and publication (D627-D628)')
exec(compile(code,str(source),'exec'))
