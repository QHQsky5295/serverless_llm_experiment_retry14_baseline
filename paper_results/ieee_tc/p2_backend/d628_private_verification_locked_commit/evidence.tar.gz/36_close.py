"""Reuse D594 exact-identity recursive-empty closure for this bounded component."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/close.py')
code=source.read_text()
old="('analysis', 'publication', 'remote_diagnosis', 'pressure_diagnosis')"
assert code.count(old)==1
code=code.replace(old,"('component', 'publication')")
exec(compile(code,str(source),'exec'))
