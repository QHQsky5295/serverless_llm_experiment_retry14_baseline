"""Installed native dispatch/step methods with synthetic work, no CUDA init."""
import json
import os
from pathlib import Path
import queue
import sys
from types import SimpleNamespace as NS
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],p.GIB);assert gate['preflight_pass'],gate['issues']
passed=False
try:
    import torch
    import vllm
    from vllm.v1.engine.core import EngineCoreProc, EngineShutdownState
    from vllm.v1.engine import EngineCoreRequestType
    from vllm.v1.executor.uniproc_executor import UniProcExecutor
    from faaslora.scheduling.core_interleave import POLICY, install_core_control_interleave
    assert not torch.cuda.is_initialized()
    scheduler=NS(vllm_config=NS(additional_config={'ieee_tc_control_interleave':POLICY},
        model_config=NS(is_moe=False)),parallel_config=NS(tensor_parallel_size=1,
        pipeline_parallel_size=1,data_parallel_size=1),has_requests=lambda:True)
    state=install_core_control_interleave(EngineCoreProc,scheduler,executor_type=UniProcExecutor,
        request_types=EngineCoreRequestType,native_version=vllm.__version__)
    core=EngineCoreProc.__new__(EngineCoreProc)
    core.scheduler=scheduler
    core.model_executor=UniProcExecutor.__new__(UniProcExecutor)
    core.model_executor.shutdown=lambda:None
    core.engines_running=False;core.batch_queue=None
    core.shutdown_state=EngineShutdownState.RUNNING
    core.input_queue=queue.Queue();core.output_queue=queue.Queue();core.aborts_queue=queue.Queue()
    core.check_for_draft_tokens=False;core.async_scheduling=True
    calls=[]
    def transaction():
        calls.extend(['pending','reference'])
        return dict(complete=True)
    def step():
        calls.append('model_step_stub')
        return {},True
    core.ieee_pending_gpu_reference=transaction
    core.step_fn=step
    for i in (1,2):
        core.input_queue.put((EngineCoreRequestType.UTILITY,[0,i,'ieee_pending_gpu_reference',[]]))
    core._process_input_queue()
    assert core.input_queue.qsize()==1 and calls==['pending','reference']
    assert core._process_engine_step() is True
    core._process_input_queue()
    assert calls==['pending','reference','model_step_stub','pending','reference']
    replies=[core.output_queue.get_nowait(),core.output_queue.get_nowait()]
    assert [r[1].utility_output.call_id for r in replies]==[1,2]
    assert all(r[1].utility_output.failure_message is None for r in replies)
    assert state.snapshot()['yields_to_native_loop']==2
    assert not torch.cuda.is_initialized()
    passed=True
finally:
    value=dict(passed=passed,identity=identity,gate=gate,
        resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')},
        actual_vllm_api=True,synthetic_executor_and_work=True,gpu_experiment=False,
        source_sha256=p.digest(ROOT/'faaslora/scheduling/core_interleave.py'))
    with (RAW/'native_api_receipt.json').open('x') as f:json.dump(value,f,indent=2)
print(json.dumps(value))
