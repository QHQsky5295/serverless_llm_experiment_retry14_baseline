"""Seal tested opt-in candidate and prepare reused first100 launch assets."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d355_control_interleave'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],32*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
receipts={name:json.loads((RAW/(name+'_receipt.json')).read_text())
          for name in ('cpu1','cpu2','native1','native_api')}
assert receipts['cpu1']['returncode']==1
assert all(receipts[n]['passed'] for n in ('cpu2','native1','native_api'))
for name in ('cpu2','native1'):
    assert 'Ran 110 tests' in (RAW/(name+'.log')).read_text()
    for path,sha in receipts[name]['sources'].items():assert p.digest(ROOT/path)==sha
with tarfile.open(RAW/'cpu1_sources.tar.gz') as bundle:
    for path,sha in receipts['cpu1']['sources'].items():
        assert hashlib.sha256(bundle.extractfile(path).read()).hexdigest()==sha
closures=[]
for name,record in receipts.items():
    old=record['identity'];oldpath=Path(old['path'])
    assert old!=identity and p.scope_still_owned(old) and not p.owned_pids(oldpath)
    stop=p.stop_scope_identity(old)
    assert stop['released'] and not stop['hard_kill'] and not oldpath.exists()
    closures.append(dict(test=name,identity=old,cleanup=stop))
with (RAW/'test_cleanup.json').open('x') as f:json.dump(closures,f,indent=2)
config=ROOT/'configs/ieee_tc/20261008_d355_7b_interleave_validation_100.yaml'
reference=ROOT/'configs/ieee_tc/20261008_d353_7b_full_w0.yaml'
candidate=yaml.safe_load(config.read_text());prior=yaml.safe_load(reference.read_text())
assert candidate['model'].pop('ieee_control_interleave')=='atomic_control_yield_v1'
for value in (candidate,prior):
    value['experiment'].pop('output_dir')
    value['storage'].pop('nvme_cache_dir');value['storage'].pop('host_cache_dir')
assert candidate==prior,'unintended configuration difference'
subprocess.run(['bash','-n',str(ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh')],check=True)
for name in ('start_remote.sh','stop_remote.sh'):subprocess.run(['bash','-n',str(RAW/name)],check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
allowed='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert protected['changed']==[allowed]
assert p.digest(Path(allowed))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
OUT.mkdir(parents=True,exist_ok=False)
members={x.name:x for x in sorted(RAW.iterdir()) if x.is_file()}
archive=OUT/'preparation_sources.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for name,path in members.items():bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as bundle:
    assert len(bundle.getmembers())==len(members)
    for member in bundle.getmembers():
        assert member.isfile() and member.name in members
        assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest()==p.digest(members[member.name])
paths=[ROOT/x for x in ('faaslora/scheduling/core_interleave.py',
    'faaslora/scheduling/vllm_ieee_scheduler.py','scripts/run_all_experiments.py',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh','tests/test_ieee_tc_core_interleave.py',
    'docs/ieee_tc/D355_ATOMIC_CONTROL_INTERLEAVE.md','docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')]
paths.extend([config,reference,Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')])
record=dict(kind='d355_control_interleave_preparation_v1',cpu_tests=110,native_environment_tests=110,
    native_api_no_cuda_passed=True,gpu_validation_complete=False,formal_qualification=False,
    sole_policy_delta='atomic_control_yield_v1',config_comparison_pass=True,
    protected=protected,gate=gate,closed_test_scopes=closures,
    archive=dict(path=str(archive.relative_to(ROOT)),sha256=p.digest(archive),
                 bytes=archive.stat().st_size,members={n:p.digest(x) for n,x in members.items()}),
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths],
    raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in members.values()])
with (OUT/'preparation.json').open('x') as f:json.dump(record,f,indent=2)
with (RAW/'preparation_scope.json').open('x') as f:
    json.dump(dict(identity=identity,resources={k:(group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current')},passed=True),f,indent=2)
print(json.dumps(dict(passed=True,archive_bytes=archive.stat().st_size,closed_scopes=len(closures))))
