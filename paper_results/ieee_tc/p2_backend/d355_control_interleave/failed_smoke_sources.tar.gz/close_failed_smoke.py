"""Retain pre-arrival profile-binding failure; do not manufacture performance."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d355_control_interleave'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
run=RAW/'7b_interleave_validation_100'
launch=json.loads((run/'launch.json').read_text())
summary=json.loads((run/'launch.launch/physical_deployment/summary.json').read_text())
assert not launch['pass'] and launch['service_returncode']==1
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert summary['n_terminal']==0 and summary['owner_event_count']==0
assert summary['gpu_seconds_observed']==0 and not summary['measurement_complete']
assert 'service profile model/configuration/context mismatch' in (run/'launch.launch/service.log').read_text()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
stop=(RAW/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive')==stop.count('MainPID=0')==3
health=json.loads((RAW/'remote_health.json').read_text())
clock=health['7b']['clock_id']
import re
assert re.fullmatch('remote-process-monotonic:[0-9a-f]{32}',clock)
check=subprocess.run(['ssh','-o','BatchMode=yes','primelora-artifact-174',
    'grep','-l',clock,'/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-*.jsonl'],
    text=True,capture_output=True)
assert check.returncode==1 and not check.stdout and not check.stderr,check
remote='/home/lab14/primelora_remote/tc/d355_20261008_control100/remote_monitor.log'
sha=subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','sha256sum',remote],text=True).split()[0]
destination=RAW/'remote_monitor.log'
assert not destination.exists()
subprocess.run(['scp','-q','-o','BatchMode=yes','primelora-artifact-174:'+remote,str(destination)],check=True)
assert p.digest(destination)==sha
closures=[]
old=p.scope_identity(Path(launch['auxiliary']['path']).name)
assert old['path']==launch['auxiliary']['path']
for old in (old,json.loads((RAW/'launch_gate.json').read_text())['identity']):
    assert old!=identity and p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
    resources={key:(Path(old['path'])/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')}
    cleanup=p.stop_scope_identity(old)
    assert cleanup['released'] and not cleanup['hard_kill'] and not Path(old['path']).exists()
    closures.append(dict(identity=old,resources=resources,cleanup=cleanup))
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['changed']==['/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py']
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
members={str(x.relative_to(RAW)):x for x in RAW.rglob('*') if x.is_file() and not x.is_symlink() and x.name!='cpu1_sources.tar.gz'}
archive=OUT/'failed_smoke_sources.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for name,path in sorted(members.items()):bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as bundle:
    assert len(bundle.getmembers())==len(members)
    for item in bundle.getmembers():assert hashlib.sha256(bundle.extractfile(item).read()).hexdigest()==p.digest(members[item.name])
record=dict(kind='d355_failed_full_entry_v1',classification='protocol_or_launcher_error',
    cause='new_control_policy_requires_its_own_measured_service_and_preparation_profiles',
    execution_commit=json.loads((RAW/'start_receipt.json').read_text())['head'],
    native_completed=0,gpu_seconds_observed=0,performance_qualified=False,n_correct=None,
    full_source_count=4000,diagnostic_prefix_count=100,occurred_before_arrivals=True,
    remote_closed=True,remote_transfer_count=0,remote_stop_returncode=1,
    remote_stop_nonzero_reason='no matching transfer file: no request reached transfer',
    remote_monitor_sha256=sha,closed_scopes=closures,protected=protected,
    archive=dict(path=str(archive.relative_to(ROOT)),sha256=p.digest(archive),bytes=archive.stat().st_size,
                 members={name:p.digest(path) for name,path in sorted(members.items())}),
    next_action='remeasure affected profiles with unchanged collector, then new exclusive Full100 attempt')
with (OUT/'failed_smoke.json').open('x') as f:json.dump(record,f,indent=2)
with (RAW/'failure_closure_scope.json').open('x') as f:json.dump(dict(identity=identity,passed=True),f,indent=2)
print(json.dumps(dict(failure_retained=True,remote_closed=True,native_completed=0,archive_bytes=archive.stat().st_size)))
