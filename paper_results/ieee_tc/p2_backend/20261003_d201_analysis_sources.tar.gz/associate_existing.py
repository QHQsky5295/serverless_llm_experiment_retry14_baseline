"""D201: reuse sealed D200 readers; associate sampled frames, not time attribution.

No new replay and no serving change. Only complete successful calls from D200.
Full snapshot capture must fit inside the native-send -> native-begin interval.
Each process/sample contributes once even if multiple calls await native entry.
"""
from collections import Counter, defaultdict
import json
import math
from pathlib import Path
import runpy
import subprocess

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
SEALED = ROOT/'paper_results/ieee_tc/p2_backend/20261003_d200_prefix_diagnostic.json'


def containment(start, stop, at, duration):
    """Half-open call interval; capture uncertainty is not silently ignored."""
    if any(type(x) not in (int, float) or not math.isfinite(x)
           for x in (start, stop, at, duration)) or stop < start or duration < 0:
        raise ValueError('invalid interval')
    return (start <= at < stop and at + duration < stop,
            at < stop and at + duration >= start)


def fixtures():
    assert containment(1, 2, 1, .1) == (True, True)
    assert containment(1, 2, 2, 0) == (False, False)
    assert containment(1, 2, 1.9, .2) == (False, True)
    assert containment(1, 2, .9, .2) == (False, True)
    assert containment(1, 2, .5, .1) == (False, False)
    for args in ((2, 1, 1, 0), (1, 2, 1, -1), (1, 2, float('nan'), 0)):
        try:
            containment(*args)
        except ValueError:
            continue
        raise AssertionError(args)


def main():
    fixtures()
    assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
        '--format=csv,noheader'], text=True).strip()
    # Verify the collector itself before importing its existing bounded reader.
    import hashlib
    assert hashlib.sha256(SEALED.read_bytes()).hexdigest() == '23ffb565ccfb93f74bc4283bca82b56eab417989e4eeb4b4a4626176819e683d'
    sealed = json.loads(SEALED.read_text())
    refs = {str(Path(r['path']).resolve()): r for r in sealed['source_refs']}
    collector = ROOT/'results/ieee_tc/p2_backend_qualification/d200_20261003/collect_prefix1_cpu.py'
    assert hashlib.sha256(collector.read_bytes()).hexdigest() == refs[str(collector.resolve())]['sha256']
    old = runpy.run_path(str(collector))
    rows, digest = old['rows'], old['digest']
    consumed = []
    def verify(ref):
        p = Path(ref['path'])
        assert p.is_file() and not p.is_symlink()
        assert p.stat().st_size == ref['bytes'] and digest(p) == ref['sha256'], p
        consumed.append(ref)
        return p
    boundary = sealed['boundaries']
    assert boundary['complete_success_coverage'] and boundary['statuses'] == {'success_complete':4204}
    attempts = defaultdict(dict)
    for ref in boundary['source_refs']:
        if not ref['path'].endswith('.control.jsonl'):
            continue
        path = verify(ref)
        for row, partial in rows(path):
            assert not partial and row['clock_id'] == boundary['clock_id']
            row = dict(row, process_identity=path.name.removesuffix('.control.jsonl'))
            assert row['boundary'] not in attempts[row['attempt_id']]
            attempts[row['attempt_id']][row['boundary']] = row
    assert len(attempts) == boundary['attempts']
    pending = defaultdict(list)
    for aid, events in attempts.items():
        assert len(events) == 11 and events['parent_terminal']['outcome'] == 'success'
        begin, send = events['native_begin'], events['frontend_native_send']
        assert send['monotonic_s'] <= begin['monotonic_s']
        pending[begin['process_identity']].append((send['monotonic_s'],begin['monotonic_s'],aid,begin['thread_ident']))
    processes = []
    matches = []
    for process in sealed['cpu']['processes']:
        if process['role_evidence'] != ['gpu_core']:
            continue
        meta_path, stack_path = [verify(r) for r in process['source_refs']]
        meta = json.loads(meta_path.read_text())
        identity = meta_path.stem
        intervals = pending[identity]
        assert intervals and {i[3] for i in intervals} == {meta['main_thread_ident']}
        census = Counter()
        nearest, callers = Counter(), Counter()
        covered = set()
        for row, partial in rows(stack_path):
            assert not partial
            census['all_samples'] += 1
            at, duration = row['observed_monotonic_s'], row['snapshot_wall_seconds']
            inside, ambiguous = [], []
            for begin, end, aid, _ in intervals:
                definite, intersects = containment(begin,end,at,duration)
                if definite: inside.append(aid)
                elif intersects: ambiguous.append(aid)
            if ambiguous: census['capture_boundary_ambiguous_samples'] += 1
            if not inside: continue
            census['inside_samples'] += 1
            covered.update(inside)
            main = [t for t in row['threads'] if t['ident'] == meta['main_thread_ident']]
            assert len(main) <= 1
            if not main:
                census['inside_missing_main'] += 1
                continue
            frame = main[0]
            census['inside_truncated_main'] += int(frame['truncated'])
            chain = frame['frames']
            project = [(i,f,n,line) for i,(f,n,line) in enumerate(chain) if f.startswith(str(ROOT)+'/')]
            closest = project[0][1:] if project else ('','no_project_frame',0)
            nearest[closest] += 1
            for i,f,n,line in project:
                caller = tuple(chain[i+1]) if i+1 < len(chain) else ('','truncated',0)
                callers[(f,n,line,*caller)] += 1
            matches.append(dict(process_identity=identity,index=row['index'],at=at,
                snapshot_wall_s=duration,attempt_ids=inside,ambiguous_attempt_ids=ambiguous,
                truncated=frame['truncated'],frames=chain))
        assert census['all_samples'] == process['samples']
        processes.append(dict(process_identity=identity,pid=meta['pid'],
            attempts=len(intervals),attempts_with_sample=len(covered),counts=dict(census),
            nearest=[dict(file=k[0],function=k[1],line=k[2],samples=v) for k,v in nearest.most_common()],
            callers=[dict(file=k[0],function=k[1],line=k[2],caller_file=k[3],
                caller_function=k[4],caller_line=k[5],occurrences=v) for k,v in callers.most_common()]))
    assert len(processes) == 4
    from scripts.ieee_tc_preflight import verify_seal
    protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
    assert protected['pass']
    result = dict(kind='d201_native_wait_stack_association_v1',new_gpu_replay=False,
        serving_change=False,formal_performance_result=False,clock_id=boundary['clock_id'],
        interval='frontend_native_send <= entire capture < native_begin',
        processes=processes,matches=matches,protected=protected,
        source_refs=[dict(path=str(SEALED),sha256=digest(SEALED)),*consumed],
        caveats=['Same-process capture-window association, not causal CPU/wall-time attribution.',
            '2-second GIL-scheduled Python sampling; native C/CUDA internals unavailable.',
            'Queries without in-interval samples remain unsampled, not zero-cost.',
            'Concurrent waiting calls do not duplicate a process/sample in counts.',
            'Inclusive caller occurrences overlap and must not be summed as time.',
            'No latency, SLO, numerical-correctness or G1/G2 improvement claim.'])
    with (RAW/'association1.json').open('x') as f:
        json.dump(result,f,indent=2,allow_nan=False)
    print(json.dumps([{k:p[k] for k in ('pid','attempts','attempts_with_sample','counts','nearest')}
                      for p in processes],indent=2))


if __name__ == '__main__':
    main()
