#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d201_20261003
unit=primelora-d201-curate1-20261003.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/curate1_scope.txt"
export PYTHONPATH="$PWD" PYTHONDONTWRITEBYTECODE=1
set +e
/usr/bin/time -v -o "$raw/curate1_time.txt" /usr/bin/python3 "$raw/curate1.py" > "$raw/curate1.log" 2>&1
status=$?
set -e
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cp "/sys/fs/cgroup$cg/memory.events" "$raw/curate1_memory.events"
cp "/sys/fs/cgroup$cg/memory.swap.current" "$raw/curate1_swap.txt"
exit "$status"
