"""Reuse D200 small-file sealing; no serving changes or large-data replication."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root=Path.cwd()
raw=Path(__file__).resolve().parent
out=root/'paper_results/ieee_tc/p2_backend'
prefix='20261003_d201_'
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert not subprocess.check_output(['git','diff','--name-only','1852c43','--','faaslora','scripts','tests','configs/ieee_tc'],text=True).strip()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
unit='primelora-d201-association1-20261003.scope'
receipt=dict(line.split('=',1) for line in (raw/'association1_scope.txt').read_text().splitlines())
assert receipt['InvocationID']=='85a69431dba240a883b2ebc9ff29518d'
for prop,wanted in (('ActiveState','inactive'),('ControlGroup',''),('InvocationID','')):
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip()==wanted
assert not Path('/sys/fs/cgroup'+receipt['ControlGroup']).exists()
events={k:int(v) for k,v in (line.split() for line in (raw/'association1_memory.events').read_text().splitlines())}
assert not any(events.values()) and (raw/'association1_swap.txt').read_text().strip()=='0'
assert 'Exit status: 0' in (raw/'association1_time.txt').read_text()
value=json.loads((raw/'association1.json').read_text())
for ref in value['source_refs']:
    assert digest(Path(ref['path']))==ref['sha256'],ref['path']
assert sum(p['counts']['inside_samples'] for p in value['processes'])==len(value['matches'])==159
assert len({(r['process_identity'],r['index']) for r in value['matches']})==159
assert sum(p['attempts_with_sample'] for p in value['processes'])==226
assert sum(p['counts'].get('capture_boundary_ambiguous_samples',0) for p in value['processes'])==1
assert not any(p['counts'].get('inside_missing_main',0) or p['counts'].get('inside_truncated_main',0) for p in value['processes'])
counts=Counter()
for p in value['processes']:
    for row in p['nearest']: counts[(row['file'],row['function'],row['line'])]+=row['samples']
assert sum(v for (f,n,l),v in counts.items() if n=='ieee_gpu_reference' and l==940)==48
assert sum(v for (f,n,l),v in counts.items() if n=='add' and l==103)==59
doc=root/'docs/ieee_tc/D201_NATIVE_WAIT_ASSOCIATION.md'
curated=out/(prefix+'native_wait_association.json')
table=out/(prefix+'native_wait_table.md')
verification=out/(prefix+'verification.json')
bundle=out/(prefix+'analysis_sources.tar.gz')
assert not any(p.exists() for p in (curated,table,verification,bundle))
text=['# D201 原生查询等待内的采样关联（非时间占比）','',
    '| PID | 完整查询 | 有样本查询 | 区间内独立样本 | HOST 深拷贝样本 |',
    '|---|---:|---:|---:|---:|']
for p in value['processes']:
    n=sum(r['samples'] for r in p['nearest'] if r['function']=='ieee_gpu_reference' and r['line']==940)
    line=f"| {p['pid']} | {p['attempts']} | {p['attempts_with_sample']} | {p['counts']['inside_samples']} | {n} |"
    assert line in doc.read_text()
    text.append(line)
text+=['','同一进程样本不按并发查询重复计数。159 个独立样本覆盖 226/4204 个调用；',
       '另有 1 个跨边界窗口。GIL/2 秒采样偏差存在，不能推算延迟贡献、CPU 占比或加速比。','']
with table.open('x') as f: f.write('\n'.join(text))
summary={k:v for k,v in value.items() if k!='matches'}
summary.update(raw_association=dict(path=str(raw/'association1.json'),sha256=digest(raw/'association1.json')),
    nearest_totals=[dict(file=k[0],function=k[1],line=k[2],samples=v) for k,v in counts.most_common()],
    analysis_memory_peak_bytes=int((raw/'association1_memory.peak').read_text()),
    analysis_memory_events=events,source_runtime_commit='1852c43aa55b89923e23c591ecf68137e3d0c965')
with curated.open('x') as f: json.dump(summary,f,indent=2,allow_nan=False)
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
local_sources=[root/p for p in ('faaslora/memory/gpu_monitor.py','faaslora/experiment/instance_pool.py',
    'faaslora/preloading/preloading_planner.py','faaslora/scheduling/vllm_ieee_scheduler.py',
    'scripts/dedicated_engine_worker.py','scripts/run_all_experiments.py')]
env=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')
local_sources += [env/p for p in ('v1/engine/core.py','v1/engine/core_client.py','v1/executor/uniproc_executor.py')]
for p in raw.glob('*.py'): ast.parse(p.read_text())
for p in raw.glob('*.sh'): subprocess.run(['bash','-n',str(p)],check=True)
members=[p for p in sorted(raw.iterdir()) if p.is_file() and p.name not in ('curate1.log','curate1_scope.txt','curate1_time.txt')]
assert all(p.stat().st_size < 2*1024**2 for p in members)
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret)>16
for p in members+[curated,table,doc]:
    data=p.read_bytes()
    assert secret not in data
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    assert not any(x.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in x for x in data.splitlines())
hashes={p.name:digest(p) for p in members}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members: archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames())==set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha
with (out/(prefix+'analysis_sources.sha256')).open('x') as f: f.write(digest(bundle)+'  '+bundle.name+'\n')
with (out/(prefix+'analysis_sources_members.json')).open('x') as f: json.dump(hashes,f,indent=2)
verify=dict(kind='d201_association_verification_v1',checks_pass=True,protected=protected,
    serving_changed=False,new_gpu_replay=False,formal_performance_result=False,
    association_scope=dict(unit=unit,invocation_id=receipt['InvocationID'],path_absent=True,memory_events=events),
    curated_refs=[dict(path=str(p),sha256=digest(p)) for p in (doc,curated,table,bundle)],
    source_code_refs=[dict(path=str(p),sha256=digest(p)) for p in local_sources],
    next='One consumer-specific physical HOST observation candidate, not implemented or accepted')
with verification.open('x') as f: json.dump(verify,f,indent=2)
print(json.dumps(dict(curated_sha256=digest(curated),verification_sha256=digest(verification),
    bundle_sha256=digest(bundle),bundle_bytes=bundle.stat().st_size,members=len(members),protected=147)))
