"""Reuse D192's retained native inputs and bounded alternating component method.

Analysis-only planning projection: no serving edit, GPU or new workload.
This projects to the EXISTING routing_source_snapshot native graph, not its
compact routing wire and not request-scoped capacities.
"""
import asyncio
import copy
import csv
import hashlib
import json
from pathlib import Path
import pickle
import statistics
import subprocess
import time
from unittest.mock import patch

import torch
from scripts.ieee_tc_preflight import verify_seal
from faaslora.experiment.instance_pool import NativeSourceSnapshot
from faaslora.preloading.preloading_planner import freeze_preparation_source_view
from faaslora.preloading.planning_cpu import execute_planning_message
from tests.test_ieee_tc_planning_cpu import PlanningCPU

ROOT = Path.cwd()
RAW = Path(__file__).resolve().parent
PARENT = 'dad2fb427dfc51029b5cd19a49265f533464c861'
PLAN_SHA = '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
METRIC_SHA = '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == PARENT
assert not torch.cuda.is_initialized()
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147 and protected['plan_sha256'] == PLAN_SHA
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == METRIC_SHA
source_names = ['faaslora/preloading/preloading_planner.py', 'faaslora/preloading/planning_cpu.py',
    'faaslora/memory/gpu_monitor.py', 'faaslora/experiment/instance_pool.py',
    'scripts/run_all_experiments.py', 'tests/test_ieee_tc_planning_cpu.py',
    'tests/test_ieee_tc_transfer_pressure.py', 'tests/test_ieee_tc_worker_observation.py']
source_shas = {}
for name in source_names:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git','show','HEAD:'+name])
    source_shas[name] = sha(ROOT/name)


def project(native):
    # Shallow selection; all dynamic graph objects still go through the exact
    # current detachment/parser. No TTL, cached verdict or field reconstruction.
    result = {key: value for key, value in native.items()
              if key not in ('native_staging_footprints', 'native_host_allocator')}
    result['native_footprints'] = {key: value for key, value in native['native_footprints'].items()
                                   if key != 'host_tensor_views'}
    return result


def parse(native):
    return NativeSourceSnapshot.from_native(native, expected_clock_id=native['clock_id'],
        received_monotonic_s=native['captured_monotonic_s']+1)


def component(native, projected):
    start = time.perf_counter()
    value = project(native) if projected else native
    parsed = parse(value)
    detached, digest = freeze_preparation_source_view(value)
    elapsed = time.perf_counter()-start
    return elapsed, parsed, detached, digest


source = RAW.parent/'d169_20261002/7b_probe1.json'
assert 0 < source.stat().st_size < 64*1024**2
assert sha(source) == 'ead0c5c81acc52c502874e9d45cfba111665f875220e23467c2e716a0d770602'
snapshots = [row['sources_before'] for row in json.loads(source.read_bytes())['warm_batches']]
assert len(snapshots) == 4
rows, cases, negatives = [], [], []
for index, native in enumerate(snapshots):
    selected = project(native)
    expected = parse(native)
    assert parse(selected) == expected
    assert {k:v for k,v in native.items() if k not in ('native_footprints', 'native_staging_footprints', 'native_host_allocator')} == {
        k:v for k,v in selected.items() if k != 'native_footprints'}
    assert selected['native_footprints'] == {k:v for k,v in native['native_footprints'].items() if k != 'host_tensor_views'}
    cases.append(dict(snapshot=index, registered=len(native['registered_cpu_adapter_ids']),
        full_json_bytes=len(json.dumps(native,sort_keys=True,separators=(',',':')).encode()),
        projected_json_bytes=len(json.dumps(selected,sort_keys=True,separators=(',',':')).encode()),
        removed_host_views=len(native['native_footprints'].get('host_tensor_views', [])),
        full_registered_union_equal=True, identities_equal=True,
        retained_top_level_keys=sorted(selected), retained_footprint_keys=sorted(selected['native_footprints'])))
    for repeat in range(3):
        for variant in (('full', 'planning_projection') if repeat % 2 == 0 else ('planning_projection','full')):
            durations = []
            for _ in range(5):
                elapsed, state, detached, digest = component(native, variant == 'planning_projection')
                assert state == expected
                assert detached == (selected if variant == 'planning_projection' else native)
                durations.append(elapsed)
            rows.append(dict(snapshot=index, variant=variant, repeat=repeat, iterations=5,
                mean_ms=statistics.mean(durations)*1000, includes_projection=True,
                parser_and_canonical_detach_included=True))
    # Current full parser and projected parser must both reject corrupted
    # capacity/alias/identity/clock evidence. Never replace global union with
    # requested-target footprints or inferred reclaimable bytes.
    mutations = {
        'host_union': lambda x: x['native_footprints'].__setitem__('host_tensor_storage_bytes',-1),
        'alias_owners': lambda x: x['native_footprints']['host_allocations'][0].__setitem__('adapter_ids',[]),
        'exclusive_credit': lambda x: x['native_footprints']['host_adapter_footprints'][0].__setitem__('exclusive_storage_bytes',-1),
        'gpu_capacity': lambda x: x['native_footprints'].__setitem__('pool_allocated_bytes',-1),
        'slot_mapping': lambda x: x['native_footprints'].__setitem__('slot_adapter_ids',[]),
        'owner_identity': lambda x: x.__setitem__('owner_id',''),
        'unconfirmed': lambda x: x.__setitem__('complete_for_native_caches',False),
    }
    for name, mutate in mutations.items():
        broken = copy.deepcopy(native)
        mutate(broken)
        outcomes = []
        for value in (broken, project(broken)):
            try:
                parse(value)
            except (ValueError, TypeError) as error:
                outcomes.append((type(error).__name__, str(error)))
            else:
                raise AssertionError(('invalid native graph accepted',index,name))
        assert outcomes[0] == outcomes[1]
        negatives.append(dict(snapshot=index,case=name,identical_rejection=outcomes[0]))


# Reuse actual existing pure-planner composition fixture. These are metadata
# tests, not real model inference or a substitute for the historical graphs.
# Extra diagnostic fields use explicit fixture sentinels; no physical claim.
fixture_checks = []
def semantic(value):
    if isinstance(value, dict):
        return {key: semantic(item) for key,item in value.items()
                if key not in ('plan_sha256','planning_sha256','source_snapshot_id',
                               'native_staging_footprints','native_host_allocator','host_tensor_views')}
    if isinstance(value, (tuple,list)):
        return type(value)(semantic(item) for item in value)
    return value

for mode in ('handoff','residency'):
    fixture = PlanningCPU()
    try:
        args, runner, slot = fixture.inputs(mode)
        n = args['native_snapshot']
        n['native_staging_footprints'] = {'diagnostic_fixture_not_a_physical_measurement': [1,2]}
        n['native_host_allocator'] = {'diagnostic_fixture_not_a_physical_measurement': 123}
        n['native_footprints']['host_tensor_views'] = [{'diagnostic_fixture': 'not-consumed'}]
        limit = runner._stack.preloading_planner.max_dp_buffer_bytes
        for protected_ids in ([], [n['slot_adapter_ids'][0]]):
            n['replacement_protected_adapter_ids'] = protected_ids
            bundles = []
            for variant in ('full','planning_projection'):
                current = dict(args, native_snapshot=n if variant == 'full' else project(n))
                # Stable identifier ONLY for comparing this pure component.
                with patch('faaslora.preloading.planning_cpu.uuid.uuid4') as uuid4:
                    uuid4.return_value.hex = 'd193-fixed-fixture-ownership-id'
                    payload, receipt = execute_planning_message(pickle.dumps(
                        ('owned_execution_epoch',limit,current),protocol=5))
                bundles.append(pickle.loads(payload))
                assert receipt['frozen_execution_validated'] and receipt['execution_objectives_prepared']
            assert semantic(bundles[0]) == semantic(bundles[1])
            assert bundles[0][0]['plan_sha256'] != bundles[1][0]['plan_sha256']
            assert bundles[0][1] == bundles[1][1]
            assert bundles[0][0]['remaining_bytes'] == bundles[1][0]['remaining_bytes']
            fixture_checks.append(dict(mode=mode,protected_adapter_ids=protected_ids,
                selections_equal=True,budgets_equal=True,objectives_equal_except_provenance=True,
                provenance_hash_changed=True))
    finally:
        fixture.doCleanups()

assert not torch.cuda.is_initialized()
assert verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json') == protected
result = dict(kind='d193_planning_native_projection_dependency_study_v1',parent_commit=PARENT,
    plan_sha256=PLAN_SHA,metric_protocol_sha256=METRIC_SHA,protected_artifacts=protected,
    unchanged_sources=source_shas,source=str(source),source_sha256=sha(source),
    snapshots=cases,measurements=rows,negative_checks=negatives,fixture_checks=fixture_checks,
    production_changed=False,gpu_execution=False,remote_operation=False,
    caveat='Retained D169 graphs and metadata fixtures; not D190 live size distribution or serving speedup. No inventory construction/RPC latency measured.')
with (RAW/'probe1.json').open('x') as handle:
    json.dump(result,handle,indent=2,allow_nan=False)
with (RAW/'probe1.csv').open('x',newline='') as handle:
    writer=csv.DictWriter(handle,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
print(json.dumps(dict(status='PASS',snapshots=len(cases),rows=len(rows),
    negative_checks=len(negatives),fixture_checks=len(fixture_checks))))
