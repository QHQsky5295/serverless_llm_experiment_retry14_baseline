"""Reuse D192's small-file curation, exact table and evidence packaging."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT=Path.cwd(); RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX='20261003_d193_planning_snapshot'
DOC=ROOT/'docs/ieee_tc/D193_PLANNING_SNAPSHOT_STUDY.md'
def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()
unit='primelora-d193-probe1-20261003.scope'
for prop,value in (('LoadState','not-found'),('InvocationID',''),('ControlGroup','')):
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip()==value
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','dad2fb427dfc51029b5cd19a49265f533464c861','--','faaslora','scripts','tests','configs/ieee_tc'],text=True).strip()
assert 'InvocationID=a0efe2a5f8b64cd185733befea55753b' in (RAW/'probe1_scope.txt').read_text()
assert 'Exit status: 0' in (RAW/'probe1_time.txt').read_text()
events=dict(line.split() for line in (RAW/'probe1_memory_events.txt').read_text().splitlines())
assert all(int(value)==0 for value in events.values())
assert (RAW/'probe1_swap.txt').read_text().strip()=='0'
assert sha(RAW/'probe1.json')=='71e1b074762109b95c4d23382f41859883ae3198488a7dc68e520c175be3e667'
probe=json.loads((RAW/'probe1.json').read_text())
assert not any(probe[k] for k in ('production_changed','gpu_execution','remote_operation'))
assert sha(Path(probe['source']))==probe['source_sha256']
for name,digest in probe['unchanged_sources'].items():
    assert sha(ROOT/name)==digest
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected==probe['protected_artifacts'] and protected['pass'] and protected['entry_count']==147
assert protected['plan_sha256']==probe['plan_sha256']
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')==probe['metric_protocol_sha256']
assert len(probe['snapshots'])==4 and len(probe['measurements'])==24
assert len(probe['negative_checks'])==28 and len(probe['fixture_checks'])==4
groups=[]
table=['# D193 planning snapshot dependency component table','',
    'Retained snapshots; three alternating component rounds, five calls per round. No serving gain or seed CI.',
    'All outliers retained. Production unchanged; decision: qualify one initialized-planner candidate.','',
    '| 快照 | 已注册 adapter | 完整 bytes | 精简 bytes | 完整 ms | 精简 ms | 字节减少 | 时间减少 |',
    '|---:|---:|---:|---:|---:|---:|---:|---:|']
document=DOC.read_text()
for case in probe['snapshots']:
    chosen=[r for r in probe['measurements'] if r['snapshot']==case['snapshot']]
    timings={}
    for variant in ('full','planning_projection'):
        values=[r for r in chosen if r['variant']==variant]
        assert len(values)==3 and sorted(r['repeat'] for r in values)==[0,1,2]
        assert all(r['iterations']==5 and r['parser_and_canonical_detach_included'] for r in values)
        timings[variant]=statistics.mean(r['mean_ms'] for r in values)
    a,b=case['full_json_bytes'],case['projected_json_bytes']
    old,new=timings['full'],timings['planning_projection']
    row=dict(snapshot=case['snapshot'],registered=case['registered'],full_bytes=a,projected_bytes=b,
        full_ms=old,projected_ms=new,byte_reduction=(a-b)/a,time_reduction=(old-new)/old)
    groups.append(row)
    line=f"| {row['snapshot']} | {row['registered']} | {a} | {b} | {old:.6f} | {new:.6f} | {(a-b)/a*100:.3f}% | {(old-new)/old*100:.3f}% |"
    assert line in document,line
    table.append(line)
with (OUT/(PREFIX+'.csv')).open('x',newline='') as handle:
    writer=csv.DictWriter(handle,fieldnames=list(groups[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(groups)
with (OUT/(PREFIX+'_table.md')).open('x') as handle:
    handle.write('\n'.join(table)+'\n')
members=[RAW/name for name in ('probe.py','run_cpu.sh','probe1.json','probe1.csv','probe1.log',
    'probe1_scope.txt','probe1_time.txt','probe1_memory_events.txt','probe1_swap.txt',
    'probe1_protected_before.json','probe1_protected_after.json','curate.py','run_curate.sh','check_staged.py')]+[DOC]
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret)>16
for path in members:
    data=path.read_bytes()
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    if path.suffix=='.py': ast.parse(data,filename=str(path))
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
source_shas={str(p):sha(p) for p in members}
bundle=OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output,tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members: archive.add(path,arcname=path.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers())==len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(path.name).read()).hexdigest()==source_shas[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as handle:
    handle.write(sha(bundle)+'  '+bundle.name+'\n')
result=dict(kind='d193_planning_snapshot_study_curated_v1',
    status='supports_one_candidate_qualification_not_serving_acceptance',probe=probe,groups=groups,
    source_sha256=source_shas,protected_after=protected,probe_scope_absent=True,
    probe_memory_events=events,probe_swap_bytes=0,
    plot_decision='Exact component table, all outliers retained; no serving-performance figure or seed CI.',
    production_changed=False,gpu_execution=False,remote_operation=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    output_csv_sha256=sha(OUT/(PREFIX+'.csv')),table_sha256=sha(OUT/(PREFIX+'_table.md')))
with (OUT/(PREFIX+'.json')).open('x') as handle: json.dump(result,handle,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS',groups=len(groups),protected=147,
    curated_sha256=sha(OUT/(PREFIX+'.json')),evidence_bundle=result['evidence_bundle']),indent=2))
