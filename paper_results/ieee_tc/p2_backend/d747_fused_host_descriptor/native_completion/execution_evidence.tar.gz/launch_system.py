"""Same D747 command under qualified system Python; no workload retry occurred."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=json.loads((RAW/'start_identity.json').read_text())
path=Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(path)
resources=p.cgroup_snapshot(path)
closed=p.stop_scope_identity(identity,grace_seconds=0)
assert closed['released'] and not closed['targets'] and not path.exists()
assert not (RAW/'native_launch.json').exists() and not (RAW/'native_descriptor.json').exists()
with (RAW/'initial_launcher_failure.json').open('x') as f:
    json.dump(dict(kind='protocol_or_launcher_error',
        reason='Conda supervisor lacks signal.pidfd_send_signal; require_watchdog_primitives rejected before service creation.',
        failed_identity=identity,resources=resources,closure=closed,
        gpu_service_started=False,performance_samples=0,
        correction='Use existing /usr/bin/python3 supervisor; native candidate interpreter and command unchanged.'),f,indent=2)
source=RAW/'launch.py'
text=source.read_text()
assert text.count("'start_identity.json'")==1
text=text.replace("'start_identity.json'","'start_system_identity.json'")
p.require_watchdog_primitives()
exec(compile(text,str(source),'exec'))
