"""Retain the old-environment import failures; check native-only cases natively."""
import ast
import hashlib
from pathlib import Path
source = Path(__file__).resolve().parent/'qualify.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '17ae0ff9f9e290a4d7a10881dabac45e5b859c9e92a724b417b80b22fa445da7'
tree = ast.parse(data)
assert tree.body[-1].value.func.id == 'exec'
namespace = {'__file__': str(__file__), '__name__': '__main__'}
exec(compile(ast.Module(body=tree.body[:-1], type_ignores=[]), str(source), 'exec'), namespace)
code = namespace['code']
old = "'tests.test_ieee_tc_host_observation_freshness']"
assert code.count(old) == 1
code = code.replace(old, "'tests.test_ieee_tc_host_observation_freshness',\n        'tests.test_ieee_tc_hit_host_transaction.NativeHostActivationWitness']")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
