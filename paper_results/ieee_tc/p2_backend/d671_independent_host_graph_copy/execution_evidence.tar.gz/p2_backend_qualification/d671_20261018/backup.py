"""Reuse the checked explicit-path D595 checkpoint; retain all qualification outcomes."""
import ast
import hashlib
from pathlib import Path
import sys

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='c16bfc285f6b9ed3f14bd46b730b5c37f0a9c52245f0f90e093fa2c23f34c1c4'
code=data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace('d595_parallel_pressure_barrier','d671_independent_host_graph_copy')
code=code.replace('023ae0079e0b2ffa537a81bda7855e8a4b8ede95','a3cdce75b60d1b55c2c88b9d0d828257349f6b43')
start=code.index("reg=read(RAW/'regression2_receipt.json')")
end=code.index('preserved={',start)
code=code[:start]+'''old=read(RAW/'qualification_receipt.json');reg=read(RAW/'qualification2_receipt.json')
assert old['passed'] is False and old['returncode']==1
assert reg['passed'] and reg['returncode']==0
for phase in ('qualification','qualification2'):
    receipt=read(RAW/(phase+'_receipt.json'))
    assert p.digest(RAW/(phase+'.log'))==receipt['log_sha256']
    for path,sha in receipt['source_sha256'].items():assert p.digest(Path(path))==sha
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
log=(RAW/'qualification.log').read_text()
failures=re.findall(r'^ERROR: (.*)$',log,re.M)
assert len(failures)==3 and all('NativeHostActivationWitness.' in item for item in failures)
assert log.count("ModuleNotFoundError: No module named 'vllm.lora.model_manager'")==3
assert 'FAILED (errors=3)' in log and 'Ran 685 tests' in log
native=(RAW/'qualification2.log').read_text()
assert 'Ran 45 tests' in native and '\\nOK\\n' in native
for item in failures:assert item+' ... ok' in native
prior=RAW.parent/'d670_20261018'
prior_closed=read(prior/'qualification_closure.json')
assert prior_closed['passed'] and prior_closed['path_gone']
assert not Path(prior_closed['identity']['path']).exists()
assert p.digest(prior/'probe.json')=='efae49c951b4ee430fe3ed7267a9126d1661ff6e32cc839b1c786109975cfae7'
late=RAW.parent.parent/'storage_maintenance/d669_20261018/publication_closure.json'
late_closed=read(late)
assert late_closed['passed'] and late_closed['path_gone']
assert not Path(late_closed['identity']['path']).exists()
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
''' + code[end:]
start=code.index('members=[RAW/name')
end=code.index('\nfor path in members:',start)
code=code[:start]+"members=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log'),*prior.glob('*.py'),*prior.glob('*.json'),*prior.glob('*.csv')])+[late]\nassert sum(path.stat().st_size for path in members)<8*1024*1024"+code[end:]
replace('bundle.add(path,arcname=path.name,recursive=False)',
        'bundle.add(path,arcname=str(path.relative_to(RAW.parent.parent)),recursive=False)')
replace('bundle.extractfile(path.name).read()',
        'bundle.extractfile(str(path.relative_to(RAW.parent.parent))).read()')
replace("for name in ('focused','regression2')}","for name in ('qualification','qualification2')}")
replace("policy='parallel_owner_barrier_v1'","mechanism='independent_registered_host_graph_copy_v1'")
replace('focused_before_metadata=focused,aborted_cpu_regression=stopped,protected=protected,',
        'old_environment=old,old_import_failures=failures,protected=protected,\n    actual_native_environment_cpu_only=True,prior_probe_sha256=p.digest(prior/\'probe.json\'),\n    late_storage_publication_closure=late_closed,')
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['faaslora/memory/gpu_monitor.py','tests/test_ieee_tc_worker_observation.py',\n    'tests/test_ieee_tc_gpu_references.py','docs/ieee_tc/EXECUTION_STATUS.md',\n    'docs/ieee_tc/D670_INDEPENDENT_HOST_GRAPH_COPY_PROBE.md',\n    'docs/ieee_tc/D671_INDEPENDENT_HOST_GRAPH_COPY.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: qualify independent HOST graph copying with fresh physical checks (D671)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D671 exact-path checkpoint adaptation parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
