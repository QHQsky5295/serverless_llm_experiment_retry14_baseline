"""D202 component replay; typed independent copying only, production unchanged."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'qualification_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],8*1024*1024);assert gate['preflight_pass'],gate['issues']
save(RAW/'qualification_gate.json',gate)
assert p.digest(ROOT/'faaslora/memory/gpu_monitor.py')=='9fd4f98c9b5241b3b722f7ac5835429c6714c6de5bf1c1f6a2ac77899ff2b270'

def clone_inventory(graph):
    """Only a newly produced, no-view registered inventory, not arbitrary data."""
    def flat(row):
        out={}
        for key,value in row.items():
            if type(value) is list:
                if any(type(v) not in (str,int,bool) for v in value):
                    raise ValueError('inventory scalar-list schema changed')
                out[key]=value.copy()
            elif type(value) in (str,int,bool):out[key]=value
            else:raise ValueError('inventory scalar-record schema changed')
        return out
    if set(graph)!={'host_allocations','host_adapter_footprints','host_tensor_storage_bytes',
                    'host_footprint_scope','host_staged_adapter_ids',
                    'host_allocator_overhead_included','host_budget_reserved'}:
        raise ValueError('inventory projection schema changed')
    if graph['host_footprint_scope']!='native_registered_tensor_storage_capacity' or graph['host_staged_adapter_ids']:
        raise ValueError('copy requires current registered inventory without staging')
    result=flat({k:v for k,v in graph.items() if k not in ('host_allocations','host_adapter_footprints')})
    for key in ('host_allocations','host_adapter_footprints'):
        result[key]=[flat(row) for row in graph[key]]
    return result

def mutable_ids(value):
    if type(value) is dict:
        return {id(value)}.union(*(mutable_ids(v) for v in value.values()))
    if type(value) is list:
        return {id(value)}.union(*(mutable_ids(v) for v in value))
    return set()

source=RAW.parent/'d202_20261003/probe2.py';data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='0addd2031348527f540fe3467faebb5ecf4908e656e7fd4dbfac77adeda878c1'
code=data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("PARENT = '5fadd45fb6a8be47c7a6e39ed65d8b1f4f2ecc4d'", "PARENT = 'a3cdce75b60d1b55c2c88b9d0d828257349f6b43'")
replace("new = monitor.IEEEWorkerObservationExtension.ieee_gpu_reference", """candidate_source=previous.decode()
needle='if staged else copy.deepcopy(host))'
assert candidate_source.count(needle)==1
candidate_source=candidate_source.replace(needle,'if staged else clone_inventory(host))')
candidate_cls=next(n for n in ast.parse(candidate_source).body if isinstance(n,ast.ClassDef) and n.name=='IEEEWorkerObservationExtension')
namespace['clone_inventory']=clone_inventory
exec(compile(ast.Module(body=[candidate_cls],type_ignores=[]),'d670_probe_only', 'exec'),namespace)
new=namespace['IEEEWorkerObservationExtension'].ieee_gpu_reference""")
replace("    if 'result' in expected:\n        for key in ('native_footprints', 'native_staging_footprints'):\n            del expected['result'][key]['host_tensor_views']", """    if 'result' in expected:
        candidate=outputs['candidate']['result']
        assert not mutable_ids(candidate['native_footprints']) & mutable_ids(candidate['native_staging_footprints']),case""")
replace("    values = {'parent': full['native_staging_footprints'],\n              'candidate': projected['native_staging_footprints']}","""    values = {'parent': projected['native_staging_footprints'], 'candidate': projected['native_staging_footprints']}
    cloned=clone_inventory(values['candidate'])
    assert cloned==values['parent']
    assert not mutable_ids(cloned)&mutable_ids(values['candidate'])""")
replace('            for _ in range(10): copied = copy.deepcopy(values[label])',
        "            copier=copy.deepcopy if label=='parent' else clone_inventory\n            for _ in range(10): copied = copier(values[label])")
replace("host_views=len(values['parent']['host_tensor_views'])", "host_views=0")
replace('json_bytes_before=encoded(full)', 'json_bytes_before=encoded(projected)')
replace("kind='d202_physical_host_projection_component_v1'", "kind='d670_independent_inventory_copy_component_v1'")
replace("with (RAW/'probe2.json').open('x')", "with (RAW/'probe.json').open('x')")
replace("with (RAW/'probe2.csv').open('x'", "with (RAW/'probe.csv').open('x'")
replace("print(json.dumps(result, indent=2))", "print(json.dumps(dict(passed=True,cases=len(cases),retained_snapshots=rows,production_changed=False,end_to_end_performance_measured=False)))")
ast.parse(code)
exec(compile(code,str(source),'exec'))
assert p.digest(ROOT/'faaslora/memory/gpu_monitor.py')=='9fd4f98c9b5241b3b722f7ac5835429c6714c6de5bf1c1f6a2ac77899ff2b270'
seal=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert seal['pass'] and seal['entry_count']==147
save(RAW/'qualification_receipt.json',dict(passed=True,protected=seal,
    production_changed=False,no_gpu_run=True,probe_sha256=p.digest(RAW/'probe.json'),
    resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
