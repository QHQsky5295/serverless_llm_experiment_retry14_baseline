#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d141_20261001
unit=$1
phase=$2
test "$unit" = "primelora-d141-$phase-20261001.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/$phase.scope.txt"
sha256sum tests/test_ieee_tc_transfer_pressure.py faaslora/preloading/preloading_planner.py scripts/run_all_experiments.py faaslora/memory/residency_manager.py > "$raw/$phase.source.sha256"
export PYTHONPATH=$PWD PYTHONUNBUFFERED=1
exec /usr/bin/time -v -o "$raw/$phase.time.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest \
  tests.test_ieee_tc_transfer_pressure.AutomaticGPUReplacement.test_other_selected_target_copy_expires_whole_plan_before_gpu_mutation -v > "$raw/$phase.log" 2>&1
