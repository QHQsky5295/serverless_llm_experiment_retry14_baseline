#!/usr/bin/env bash
# Reuse D134 regression/protection workflow, with native binding coverage.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d141_20261001
unit=primelora-d141-verify2-20261001.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/verify_scope.txt"
sha256sum faaslora/preloading/preloading_planner.py faaslora/memory/residency_manager.py tests/test_ieee_tc_transfer_pressure.py > "$raw/verify_sources.sha256"
export PYTHONUNBUFFERED=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
set +e
/usr/bin/time -v -o "$raw/verify_time.txt" "$python" -m unittest tests.test_ieee_tc_gpu_references tests.test_ieee_tc_service_routing tests.test_ieee_tc_service_events tests.test_ieee_tc_planning_cpu tests.test_ieee_tc_transfer_pressure tests.test_ieee_tc_planning tests.test_ieee_tc_preparation_snapshot_copy tests.test_ieee_tc_preparation_cost tests.test_ieee_tc_native_retirement tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_native_timing tests.test_ieee_tc_launch tests.test_ieee_tc_external_replay tests.test_basic_smoke -v > "$raw/verify.log" 2>&1
rc=$?
set -e
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
test "$rc" = 0
sha256sum -c "$raw/verify_sources.sha256"
"$python" - <<'PY'
import json, re
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root=Path.cwd()
raw=root/'results/ieee_tc/p2_backend_qualification/d141_20261001'
seal=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert seal['pass'] and seal['entry_count']==147
metric=root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
plan=Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')
assert digest(metric)=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert digest(plan)=='fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
changed={'faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py','tests/test_ieee_tc_transfer_pressure.py'}
before=json.loads((raw.parent/'d140_20261001/prelaunch_verification.json').read_text())
checked=0
for name, expected in before['source_sha256'].items():
    p=Path(name) if name.startswith('/') else root/name
    if str(p.relative_to(root)) in changed if p.is_relative_to(root) else False: continue
    assert digest(p)==expected,name
    checked+=1
log=(raw/'verify.log').read_text()
match=re.search(r'Ran (\d+) tests in ([\d.]+)s\n\nOK\n',log)
assert match and int(match[1])>=1071
result=dict(kind='d141_plan_source_binding_verification_v1',protected=seal,
    metric_protocol_sha256=digest(metric),plan_sha256=digest(plan),
    source_refs=[dict(path=str(root/p),sha256=digest(root/p)) for p in sorted(changed)],
    unchanged_d140_frozen_sources=checked,tests=int(match[1]),test_seconds=float(match[2]),
    red_log_sha256=digest(raw/'red1.log'),green_log_sha256=digest(raw/'green1.log'),
    full_replay_qualified=False,formal_performance_result=False)
with (raw/'verification.json').open('x') as stream:
    json.dump(result,stream,indent=2,allow_nan=False)
print(json.dumps(dict(protected=147,tests=result['tests'],unchanged_sources=checked)))
PY
date -Is


