"""D134 source-binding curation/bundle workflow, adapted to selected siblings."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d141_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for phase in ('red1', 'green1', 'verify', 'verify2'):
    unit = f'primelora-d141-{phase}-20261001.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
v = json.loads((raw/'verification.json').read_text())
assert v['protected']['pass'] and v['protected']['entry_count'] == 147
assert v['tests'] >= 1071 and v['unchanged_d140_frozen_sources'] >= 180
for ref in v['source_refs']:
    assert sha(Path(ref['path'])) == ref['sha256']
red, green = ((raw/f'{phase}.log').read_text() for phase in ('red1','green1'))
assert 'Ran 1 test in 0.134s' in red and 'FAILED (errors=1)' in red
assert 'ValueError: preparation source identity/coverage contradicts its frozen objective' in red
assert 'Ran 1 test in 0.097s\n\nOK\n' in green
assert 'Exit status: 1' in (raw/'red1.time.txt').read_text()
assert 'Exit status: 0' in (raw/'green1.time.txt').read_text()
assert 'Exit status: 0' in (raw/'verify_time.txt').read_text()
sources = {}
for phase in ('red1','green1'):
    sources[phase] = {line.split(maxsplit=1)[1]:line.split(maxsplit=1)[0]
                      for line in (raw/f'{phase}.source.sha256').read_text().splitlines()}
assert sources['red1']['tests/test_ieee_tc_transfer_pressure.py'] == sources['green1']['tests/test_ieee_tc_transfer_pressure.py']
changed = [name for name in sources['red1'] if sources['red1'][name] != sources['green1'][name]]
assert changed == ['faaslora/preloading/preloading_planner.py']
cleanup = {}
for phase in ('red1','green1','verify_attempt1','verify2'):
    p = raw/f'{phase}.cleanup.txt'
    events = {line.split()[0]:int(line.split()[1]) for line in p.read_text().splitlines()
              if line.startswith(('low ', 'high ', 'max ', 'oom ', 'oom_kill ', 'oom_group_kill '))}
    assert len(events) == 6 and not any(events.values()), p
    cleanup[phase] = dict(memory_events=events, receipt_sha256=sha(p))
doc = root/'docs/ieee_tc/D141_SELECTED_SIBLING_PLAN_EXPIRY.md'
files = [p for p in sorted(raw.iterdir()) if p.is_file()
         and p.suffix in {'.py','.sh','.json','.txt','.log','.sha256'}
         and not p.name.startswith('finalize')]
files.append(doc)
assert all(p.stat().st_size < 2*1024**2 for p in files)
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for p in files:
    data = p.read_bytes()
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and line.endswith(b'PRIVATE KEY-----') for line in data.splitlines()), p
    if p.suffix == '.py': compile(data, str(p), 'exec')
    if p.suffix == '.sh': subprocess.run(['bash','-n',str(p)],check=True)
result = dict(kind='d141_selected_sibling_plan_expiry_v1',
    parent_commit='acee2f5ffd8b914d16be7722f2b3160ca8881455',
    decision='correctness_candidate_passed_cpu_regression_runtime_requalification_pending',
    full_replay_qualified=False, formal_performance_result=False, cuda_executed=False,
    exact_d140_failure_snapshot_available=False,
    causal_scope='CPU counterexample proves a defect path, not unique attribution of D140',
    red_green=dict(test_sha256=sources['red1']['tests/test_ieee_tc_transfer_pressure.py'],
        original='source identity guard rejected legitimate selected-sibling copy change',
        candidate='whole old plan superseded before proactive GPU operation',
        only_changed_source=changed, independent_performance_repetitions=0),
    tests=v, cleanup=cleanup,
    regression_attempt1='actual affinity precheck stopped before unittest; taskset used in attempt2',
    unchanged=dict(formulas=True,profile=True,capacity=True,timeout=True,workload=True,remote=True),
    source_refs=[dict(path=str(p),sha256=sha(p)) for p in files])
curated = out/'20261001_d141_selected_sibling_plan_expiry.json'
with curated.open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
files.append(curated)
bundle = out/'20261001_d141_source_binding_sources.tar.gz'
with bundle.open('xb') as handle:
    with tarfile.open(fileobj=handle,mode='w:gz') as archive:
        for p in files: archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(files)
    for member,p in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == sha(p)
with (out/'20261001_d141_source_binding_sources.sha256').open('x') as f:
    f.write(f'{sha(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=sha(curated),tests=v['tests'],protected=147,
    bundle_sha256=sha(bundle),bundle_bytes=bundle.stat().st_size,members=len(files))))
