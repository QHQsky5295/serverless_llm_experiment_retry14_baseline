#!/usr/bin/env bash
# Reuse existing bounded CPU qualification; no GPU or remote work.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in tests1|analyze1|analyze2|verify1) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d182_20261003
unit="primelora-d182-${phase}-20261003.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
if test "$phase" = tests1; then
  args=(-m unittest tests.test_ieee_tc_timing_bound tests.test_ieee_tc_control_timeline -v)
elif test "$phase" = warmtests2; then
  python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
  args=(-m unittest tests.test_ieee_tc_warm_reference -v)
else
  python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
  args=("$raw/${phase%?}.py")
fi
set +e
/usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/${phase}_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/${phase}_swap.txt"
exit "$code"
