"""D153-derived bounded static/dynamic preparation dependency study.

The prototype is analysis-only: it replaces three pure expressions in the
current function, never production code, live ownership or capacity checks.
"""
import ast
from collections import Counter
import contextlib
import copy
import hashlib
import inspect
import io
import json
import os
from pathlib import Path
import statistics
import subprocess
import tempfile
import textwrap
import time
from types import MappingProxyType
from unittest.mock import patch

import torch
from faaslora.memory import residency_manager as module
from faaslora.storage.http_artifact_store import HttpArtifactStoreClient, _quote_artifact_id
from scripts.ieee_tc_preflight import digest, verify_seal
from tests.test_ieee_tc_file_observation import FreshFileObservation, without_capture_times

ROOT = Path.cwd()
RAW = Path(__file__).resolve().parent
PARENT = '475cd90cd8341fbe909a5c3884b5330ff0dd4794'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == PARENT
assert not torch.cuda.is_initialized()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'

source = textwrap.dedent(inspect.getsource(module.LocalSourceReferences.preparation_snapshot))
tree = ast.parse(source)
function = tree.body[0]
function.args.kwonlyargs.append(ast.arg(arg='compiled'))
function.args.kw_defaults.append(None)
replacements = Counter()


class StaticOnly(ast.NodeTransformer):
    def visit_Expr(self, node):
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == '_quote_artifact_id':
            replacements['canonical_id'] += 1
            return ast.parse('compiled[aid]').body[0]
        return self.generic_visit(node)

    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'content':
            assert ast.unparse(node.value) == 'self._expected_content(files)'
            replacements['content_hash'] += 1
            return ast.parse("content = compiled[aid]['content_sha256']").body[0]
        if (len(node.targets) == 1 and isinstance(node.targets[0], ast.Subscript)
                and isinstance(node.targets[0].value, ast.Name) and node.targets[0].value.id == 'artifacts'):
            replacements['static_targets'] += 1
            return ast.parse("artifacts[aid] = dict(content_sha256=compiled[aid]['content_sha256'], logical_payload_bytes=compiled[aid]['logical_payload_bytes'], sources=sources, targets={tier: dict(row) for tier, row in compiled[aid]['targets'].items()})").body[0]
        return self.generic_visit(node)


tree = ast.fix_missing_locations(StaticOnly().visit(tree))
assert replacements == {'canonical_id': 1, 'content_hash': 1, 'static_targets': 1}
namespace = dict(module.__dict__)
exec(compile(tree, '<D188-analysis-only-static-expressions>', 'exec'), namespace)
prototype = namespace['preparation_snapshot']


def freeze_and_compile(owner, manifests):
    """Only immutable file metadata and explicit destination geometry.

    Does not contain residency, source signatures, epochs, budgets or leases.
    A serving implementation must bind these inputs and recompile on geometry
    changes. This prototype checks that boundary outside its measured call.
    """
    start = time.perf_counter()
    frozen = MappingProxyType({a: MappingProxyType(dict(f)) for a, f in manifests.items()})
    roots = dict(owner.roots)
    units = {t: os.statvfs(p).f_frsize for t, p in roots.items()}
    rows = {}
    for aid, files in sorted(frozen.items()):
        _quote_artifact_id(aid)
        content = owner._expected_content(files)
        rows[aid] = MappingProxyType(dict(content_sha256=content,
            logical_payload_bytes=sum(size for size, _ in files.values()),
            targets=MappingProxyType({tier: MappingProxyType(dict(tier=tier,
                representation='verified_regular_file_tree_v1', content_sha256=content,
                footprint_bytes=sum(((size+unit-1)//unit)*unit for size, _ in files.values()),
                path=str(roots[tier]/aid))) for tier, unit in units.items()})))
    return frozen, MappingProxyType(rows), roots, units, time.perf_counter()-start


def compare(case_name, owner, manifests, limits):
    frozen, compiled, roots, units, setup_s = freeze_and_compile(owner, manifests)
    assert dict(owner.roots) == roots
    assert {t: os.statvfs(p).f_frsize for t, p in roots.items()} == units
    expected = without_capture_times(owner.preparation_snapshot(manifests=frozen, limits=limits))
    rows = []
    for repeat in range(3):
        order = ('current', 'static_prototype') if repeat % 2 == 0 else ('static_prototype', 'current')
        for variant in order:
            counts = Counter()
            base_content = owner._expected_content
            base_inventory = module._local_file_inventory
            def observed_content(files):
                counts['content_digest'] += 1
                return base_content(files)
            def observed_inventory(*args, **kwargs):
                counts['physical_inventory'] += 1
                return base_inventory(*args, **kwargs)
            with patch.object(owner, '_expected_content', observed_content), patch.object(module, '_local_file_inventory', observed_inventory):
                begin = time.perf_counter()
                value = (owner.preparation_snapshot(manifests=frozen, limits=limits) if variant == 'current'
                         else prototype(owner, manifests=frozen, limits=limits, compiled=compiled))
                elapsed = time.perf_counter()-begin
            assert without_capture_times(value) == expected
            # Public export mutation must not poison the precompiled description.
            first = next(iter(value['artifacts']))
            value['artifacts'][first]['targets']['nvme']['footprint_bytes'] = -1
            assert compiled[first]['targets']['nvme']['footprint_bytes'] >= 0
            rows.append(dict(case=case_name, candidates=len(frozen), confirmed_trees=len(owner._confirmed_sources),
                repeat=repeat, variant=variant, elapsed_s=elapsed,
                content_digest_calls=counts['content_digest'], inventory_calls=counts['physical_inventory'],
                exact_except_capture_times=True))
    # All physical reads and validations are the same AST. Independently exercise
    # a live foreign filesystem change against the prototype, not a stale view.
    checks = {'export_isolation': True}
    if owner._confirmed_sources:
        published = next(iter(owner._confirmed_sources))
        file = next(p for p in published.rglob('*') if p.is_file())
        stat = file.stat()
        os.utime(file, ns=(stat.st_atime_ns, stat.st_mtime_ns+1000000000))
        try:
            prototype(owner, manifests=frozen, limits=limits, compiled=compiled)
        except RuntimeError as error:
            assert 'changed outside' in str(error)
            checks['changed_live_source_rejected'] = True
        else:
            raise AssertionError('prototype accepted changed published source')
    else:
        rogue = owner.roots['nvme']/'unconfirmed'
        rogue.mkdir()
        # Add a known adapter name as an unconfirmed tree, no payload generated.
        rogue.rmdir()
        rogue = owner.roots['nvme']/next(iter(frozen))
        rogue.mkdir()
        try:
            prototype(owner, manifests=frozen, limits=limits, compiled=compiled)
        except RuntimeError as error:
            assert 'without verified source publication' in str(error)
            checks['unknown_live_tree_rejected'] = True
        else:
            raise AssertionError('prototype accepted unconfirmed source')
        rogue.rmdir()
    groups = []
    for variant in ('current', 'static_prototype'):
        chosen = [r for r in rows if r['variant'] == variant]
        groups.append(dict(case=case_name, candidates=len(frozen), variant=variant, repeats=3,
            mean_ms=statistics.mean(r['elapsed_s'] for r in chosen)*1000,
            inventory_calls=chosen[0]['inventory_calls'], digest_calls=chosen[0]['content_digest_calls'],
            setup_ms=setup_s*1000))
    return dict(case=case_name, groups=groups, rows=rows, checks=checks)


results = []
for count in (4, 500):
    fixture_case = FreshFileObservation()
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            fixture, owner, manifests, limits = fixture_case.make()
        manifests.update({f'absent-{i}': dict(manifests['a']) for i in range(count-4)})
        results.append(compare(f'existing_fixture_{count}', owner, manifests, limits))
    finally:
        fixture_case.doCleanups()

index = ROOT/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
assert digest(index) == 'e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c'
client = HttpArtifactStoreClient(endpoint='http://unused.invalid', token='')
client.configure_content_manifest(json.loads(index.read_text()))
manifests = client.preparation_manifests(client._content_manifest)
assert len(manifests) == 500
with tempfile.TemporaryDirectory(prefix='d188-metadata-only-', dir=RAW) as name:
    base = Path(name)
    roots = {tier: base/tier for tier in ('host', 'nvme')}
    for root in roots.values():
        root.mkdir()
    owner = module.LocalSourceReferences(roots)
    owner.configure_host_budget(limit_bytes=16*1024**3)
    results.append(compare('existing_7b_index_empty_owner', owner, manifests,
                           {'host': 16*1024**3, 'nvme': 16*1024**3}))

assert not torch.cuda.is_initialized()
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
files = [Path(__file__), ROOT/'faaslora/memory/residency_manager.py',
    ROOT/'faaslora/storage/http_artifact_store.py', ROOT/'scripts/run_all_experiments.py',
    ROOT/'tests/test_ieee_tc_file_observation.py', ROOT/'tests/test_ieee_tc_transfer_pressure.py', index]
output = dict(kind='d188_static_preparation_dependency_v1', parent_commit=PARENT,
    production_code_changed=False, inference=False, formal_performance_result=False,
    prototype_ast_replacements=dict(replacements), results=results, protected=protected,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in files],
    caveats=['Tiny existing fixture plus real 500-adapter metadata with empty owner; not production occupancy.',
        'Local instrumented timings, three alternating component calls; not seed repeats or a CI.',
        'Static compilation setup separately measured, must count in deployment lifecycle.',
        'Prototype precondition bindings checked outside call; production lifetime/invalidation still unqualified.',
        'No static description certifies a tier, available capacity, lease or execution readiness.',
        'No end-to-end latency improvement or model acceptance established.'])
with (RAW/'probe1.json').open('x') as f:
    json.dump(output, f, indent=2, allow_nan=False)
print(json.dumps([g for r in results for g in r['groups']], indent=2))
