"""Reuse D180's small-file evidence/table delivery for D188's component study."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT = Path.cwd()
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX = '20261003_d188_static_preparation'

def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()

unit = 'primelora-d188-probe1-20261003.scope'
for prop, value in (('LoadState', 'not-found'), ('InvocationID', ''), ('ControlGroup', '')):
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == value
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice', unit).exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','475cd90cd8341fbe909a5c3884b5330ff0dd4794','--','faaslora','scripts','tests','configs/ieee_tc'],text=True).strip()
assert 'InvocationID=6ea683e64ebc4bb2be9b1981844f98b5' in (RAW/'probe1_scope.txt').read_text()
assert 'Exit status: 0' in (RAW/'probe1_time.txt').read_text()
events = dict(line.split() for line in (RAW/'probe1_memory_events.txt').read_text().splitlines())
assert all(int(v) == 0 for v in events.values())
assert (RAW/'probe1_swap.txt').read_text().strip() == '0'
probe = json.loads((RAW/'probe1.json').read_text())
assert probe['production_code_changed'] is False and probe['inference'] is False
for ref in probe['source_refs']:
    assert sha(Path(ref['path'])) == ref['sha256']
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert protected['plan_sha256'] == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert len(probe['results']) == 3
groups = [g for result in probe['results'] for g in result['groups']]
doc = ROOT/'docs/ieee_tc/D188_STATIC_PREPARATION_STUDY.md'
labels = ('既有4-name fixture', '既有500-name fixture', '真实7B索引、空owner')
table = ['# D188 component table', '',
    'Three alternating component calls, not independent serving runs. No CI or TTFT extrapolation.', '',
    '| Case | Current ms | Static prototype ms | Reduction | Compile once ms | Inventory calls | Digest calls |',
    '|---|---:|---:|---:|---:|---:|---:|']
for label, result in zip(labels, probe['results']):
    assert len(result['rows']) == 6 and all(r['exact_except_capture_times'] for r in result['rows'])
    assert all(result['checks'].values()) and len(result['checks']) == 2
    for group in result['groups']:
        rows = [r for r in result['rows'] if r['variant'] == group['variant']]
        assert len(rows) == 3
        assert statistics.mean(r['elapsed_s'] for r in rows)*1000 == group['mean_ms']
        assert all(r['inventory_calls'] == 1 for r in rows)
        assert all(r['content_digest_calls'] == group['digest_calls'] for r in rows)
    before, after = result['groups']
    assert before['variant'] == 'current' and after['variant'] == 'static_prototype'
    assert before['setup_ms'] == after['setup_ms']
    line = f"| {label} | {before['mean_ms']:.3f} | {after['mean_ms']:.3f} | {before['setup_ms']:.3f} | 1 → 1 | {before['candidates']} → 0 |"
    assert line in doc.read_text()
    reduction = (before['mean_ms']-after['mean_ms'])/before['mean_ms']
    table.append(f"| {before['case']} | {before['mean_ms']:.3f} | {after['mean_ms']:.3f} | {reduction:.3%} | {before['setup_ms']:.3f} | 1 -> 1 | {before['candidates']} -> 0 |")
with (OUT/(PREFIX+'.csv')).open('x', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(groups[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(groups)
with (OUT/(PREFIX+'_table.md')).open('x') as f:
    f.write('\n'.join(table)+'\n')

members = [RAW/name for name in ('probe.py','run_cpu.sh','probe1.json','probe1.log',
    'probe1_scope.txt','probe1_time.txt','probe1_memory_events.txt','probe1_swap.txt',
    'probe1_protected_before.json','probe1_protected_after.json','curate.py','run_curate.sh','check_staged.py')]
members.append(doc)
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret) > 16
for path in members:
    data = path.read_bytes()
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}', data)
    if path.suffix == '.py':
        ast.parse(data, filename=str(path))
    if path.suffix == '.sh':
        subprocess.run(['bash','-n',str(path)], check=True)
sources = {str(p):sha(p) for p in members}
bundle = OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output, tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members:
        archive.add(path, arcname=path.name, recursive=False)
with tarfile.open(bundle, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(path.name).read()).hexdigest() == sources[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as f:
    f.write(sha(bundle)+'  '+bundle.name+'\n')
result = dict(kind='d188_static_preparation_study_curated_v1',
    status='supports_one_static_catalog_candidate_not_production_qualified', probe=probe,
    source_sha256=sources, protected_after=protected, probe_scope_absent=True,
    probe_memory_events=events, probe_swap_bytes=0,
    plot_decision='Exact component/status table; no performance-claim figure or seed CI.',
    production_changed=False, gpu_execution=False, remote_operation=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    output_csv_sha256=sha(OUT/(PREFIX+'.csv')),table_sha256=sha(OUT/(PREFIX+'_table.md')))
with (OUT/(PREFIX+'.json')).open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS', groups=6, exact_outputs=18, protected=147,
    curated_sha256=sha(OUT/(PREFIX+'.json')), evidence_bundle=result['evidence_bundle']),indent=2))
