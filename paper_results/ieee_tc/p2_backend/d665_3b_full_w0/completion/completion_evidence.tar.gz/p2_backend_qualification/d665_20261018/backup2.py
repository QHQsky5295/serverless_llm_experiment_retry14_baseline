"""Resume D665 publication after a missing document name; retain original bundle."""
import ast
import hashlib
from pathlib import Path
import sys

source=Path(__file__).with_name('backup.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='937a74f3ade7d231db71f7fc99e328998d09e915b216498b7dfb5d3183a63221'
code=data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("save(RAW/'backup_identity.json',identity)","save(RAW/'backup2_identity.json',identity)")
replace("save(RAW/'backup_receipt.json',dict(","save(RAW/'backup2_receipt.json',dict(")
replace('docs/ieee_tc/D665_3B_FULL_W0.md','docs/ieee_tc/D665_3B_HOST_TRANSACTION_FULL_W0.md')
start=code.index("with tarfile.open(OUT/'execution_evidence.tar.gz','x:gz')")
end=code.index("names=['docs/ieee_tc/EXECUTION_STATUS.md'",start)
code=code[:start]+'''failed=read(RAW/'backup_closure.json')
assert failed['passed'] and failed['actual_recursive_procs_empty'] and failed['path_gone']
assert not Path(failed['identity']['path']).exists()
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
with tarfile.open(OUT/'execution_evidence.tar.gz') as old_bundle:
    for member in old_bundle.getmembers():
        assert member.isfile()
        path=RAW.parent.parent/member.name
        assert path.is_relative_to(RAW.parent.parent)
        assert hashlib.sha256(old_bundle.extractfile(member).read()).hexdigest()==p.digest(path)
files+=['execution_evidence.tar.gz','result.sha256']
extra=[RAW/name for name in ('backup2.py','start2.py','close_extra.py','backup_identity.json','backup_closure.json')]
save(OUT/'backup_resume.json',dict(kind='d665_prelaunch_publication_resume_v1',
    original_failure='FileNotFoundError: publication document name mismatch; no stage, commit or GPU launch',
    original_helper_sha256=p.digest(RAW/'backup.py'),original_bundle_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    original_result_manifest_sha256=p.digest(OUT/'result.sha256'),failed_scope_closed=failed,
    unchanged_runtime_configuration=True,unchanged_qualification=True,
    helpers={str(path):p.digest(path) for path in extra}))
with tarfile.open(OUT/'backup_resume_evidence.tar.gz','x:gz') as bundle:
    for path in extra:
        check(path.read_bytes());bundle.add(path,arcname=str(path.relative_to(RAW.parent.parent)),recursive=False)
with tarfile.open(OUT/'backup_resume_evidence.tar.gz') as bundle:
    for path in extra:assert hashlib.sha256(bundle.extractfile(str(path.relative_to(RAW.parent.parent))).read()).hexdigest()==p.digest(path)
files+=['backup_resume.json','backup_resume_evidence.tar.gz']
with (OUT/'backup_resume.sha256').open('x') as stream:
    for name in files:stream.write(p.digest(OUT/name)+'  '+name+'\\n')
subprocess.run(['sha256sum','-c','backup_resume.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
files+=['backup_resume.sha256']
''' +code[end:]
replace("for name in files+['result.sha256']]","for name in files]")
replace("protected=protected,preserved={str(k):v for k,v in preserved.items()}))",
        "protected=protected,preserved={str(k):v for k,v in preserved.items()},\n    resume_helper_sha256={str(path):p.digest(path) for path in extra}))")
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D665 publication resume parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no args or --check-only')
