"""Reuse frozen D665 launcher, referring to the successful publication resume."""
import ast
import hashlib
import json
from pathlib import Path
import sys

source=Path(__file__).with_name('start.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='8209cbf39f6234fab111676a66de5f4fc29693e68c6c77c30cb2b795b91b96f6'
code=data.decode()
assert code.count('backup_receipt.json')==code.count('backup_closure.json')==1
code=code.replace('backup_receipt.json','backup2_receipt.json').replace('backup_closure.json','backup2_closure.json')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D665 launcher publication references parsed; no writes.')
elif not sys.argv[1:]:
    backup=json.loads(source.with_name('backup2_receipt.json').read_text())
    assert backup['passed']
    for path,sha in backup['resume_helper_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no args or --check-only')
