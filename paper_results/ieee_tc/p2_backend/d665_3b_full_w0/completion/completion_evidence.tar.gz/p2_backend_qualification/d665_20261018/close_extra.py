"""Reuse exact-identity closure for the publication-resume scope only."""
import hashlib
from pathlib import Path
import sys
source=Path(__file__).with_name('close.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='2275f5fb7959fb2df7bf13a67cce7f4ebcd226a232ca9d6ecb5ec00d013ca68a'
assert sys.argv[1:]==['backup2']
code=data.decode().replace("assert name in ('qualification',","assert name in ('backup2','qualification',")
exec(compile(code,str(source),'exec'))
