"""Reuse D660 complete-run publication; retain D665 prelaunch and failed backup."""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d660_20261018/publish.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'b2b65c513b52e42c15486f8b50422d5df9307ebb38505c3516a312d51a53ed27'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d660_3b_full_w0'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d665_3b_full_w0/completion'")
replace("expected_head='24208f8d9bdbbbb2e667060b57d7d6b1f18184c8'",
        "expected_head='793b69729233f14ed9db8d07c9efe716177ca05e'")
replace("assert audit['passed'] and audit['protocol_bound_count']==4000",
        "assert audit['passed'] and audit['protocol_bound_count']==4000\nassert audit['host_transaction']['passed'] and len(audit['host_transaction']['request_ids'])==1392")
replace("for phase in ('qualification','backup','start','analysis'):",
        "for phase in ('qualification','backup','backup2','start','analysis'):")
replace("assert OUT.is_dir() and not (OUT/'audit.json').exists()\nsubprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)",
        """assert OUT.parent.is_dir() and not OUT.exists()
prelaunch=OUT.parent
assert p.digest(prelaunch/'result.sha256')=='ef3e2addf8c7bb5fb01ce3d3bcbfa06216ef649400bb162242092f41435e1e65'
assert p.digest(prelaunch/'backup_resume.sha256')=='2786c22d9306ca9057794c4db06e3861abbd2b56d76e934008b15e47923dcd61'
for checksum in ('result.sha256','backup_resume.sha256'):
    subprocess.run(['sha256sum','-c',checksum],cwd=prelaunch,check=True,stdout=subprocess.DEVNULL)
assert read(RAW/'backup2_receipt.json')['passed']
OUT.mkdir()""")
replace("'backup_identity.json','backup_receipt.json','backup_closure.json')]",
        """'backup_identity.json','backup2_receipt.json','backup_closure.json')]
members += [RAW/name for name in ('backup2.py','backup2_identity.json','backup2_closure.json',
    'start2.py','close_extra.py')]
members += [RAW.parent/'d664_20261018'/'publication_closure.json']""")
replace("assert joint==3575 and audit['protocol_bound_count']==4000",
        """assert joint==3550 and audit['protocol_bound_count']==4000
previous_path=ROOT/'paper_results/ieee_tc/p2_backend/d660_3b_full_w0/audit.json'
assert p.digest(previous_path)=='31e3a5c042961983fcbfd1bd926141e66b153aab892e1432c8914b1b086e89d9'
previous=read(previous_path)
assert previous['workload_identity']==audit['workload_identity']
assert previous['native_tokens']==audit['native_tokens']
metrics=('mean_ttft_ms','p95_ttft_ms','mean_tpot_ms','p95_tpot_ms','mean_e2e_ms','physical_gpu_seconds')
comparison=dict(kind='d665_vs_d660_complete_w0_single_observation_v1',
    previous_audit=dict(path=str(previous_path),sha256=p.digest(previous_path)),
    current_audit_sha256=p.digest(RAW/'analysis1.log'),
    workload_identity=audit['workload_identity'],native_tokens=audit['native_tokens'],
    previous_joint_count=previous['common_threshold_joint_count'],current_joint_count=joint,
    joint_delta_percentage_points=(joint-previous['common_threshold_joint_count'])/40,
    metrics=[dict(metric=k,previous=previous['stats'][k],current=audit['stats'][k],
        lower_better_improvement_percent=100*(previous['stats'][k]-audit['stats'][k])/previous['stats'][k]) for k in metrics],
    previous_stage_means_ms=previous['stage_means_ms'],current_stage_means_ms=audit['stage_means_ms'],
    performance_goal_met=False,accepted_as_goal_improvement=False,
    confidence_interval=None,independent_holdout=False,
    caveat='Known fixed workload, one observation per version; native HOST proof passed, but joint SLO fell and resource saving was negligible. No causal attribution of run variation, numerical proof or final ranking.')
save(OUT/'comparison_d660.json',comparison)
files+=['comparison_d660.json']""")
replace("kind='d660_3b_complete_w0_seal_v1'", "kind='d665_3b_complete_w0_host_transaction_seal_v1'")
replace("joint_slo_fraction=joint/4000,joint_slo_pass=False,",
        """joint_slo_fraction=joint/4000,joint_slo_pass=joint>=3800,
    host_transaction=audit['host_transaction'],
    immutable_prelaunch_sha256=p.digest(prelaunch/'result.sha256'),
    immutable_resume_sha256=p.digest(prelaunch/'backup_resume.sha256'),
    reused_publication_helper=dict(path=str(source),sha256=hashlib.sha256(data).hexdigest()),
    comparison_sha256=p.digest(OUT/'comparison_d660.json'),accepted_as_goal_improvement=False,""")
replace("no_figures=True,no_runtime_source_change=True,",
        "no_figures=True,publication_runtime_source_changed=False,")
replace("next_action='Retained-data diagnosis of persistent 3B wait/preparation/control and scaling occupancy, then one falsifiable candidate if supported; no W1/W2 launch before resolving this W0 shortfall.'",
        "next_action='Bounded D660/D665 retained-data comparison of HOST transaction stages and joint violations; no same-key rerun, threshold change, unproven candidate stacking or W1/W2 launch before resolving this W0 shortfall.'")
replace('docs/ieee_tc/D660_3B_FULL_W0.md', 'docs/ieee_tc/D665_3B_HOST_TRANSACTION_FULL_W0.md')
replace('tc: seal complete 3B Full W0 and retained SLO shortfall (D660)',
        'tc: seal full HOST candidate with retained 3B SLO regression (D665)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D665 completion publication adaptation parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no args or --check-only')
