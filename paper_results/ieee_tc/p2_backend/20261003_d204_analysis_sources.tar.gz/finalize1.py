"""Reuse small evidence packaging and protected-artifact checks for D204."""
import csv
import hashlib
import json
import math
import subprocess
import tarfile
from pathlib import Path
from statistics import mean
from scripts.ieee_tc_preflight import ROOT, digest, verify_seal, check_plan

RAW=Path(__file__).parent.resolve()
BASE=ROOT/'paper_results/ieee_tc/p2_backend'
OUT=BASE/'20261003_d204_control_path_attempt2'
DOC=ROOT/'docs/ieee_tc/D204_REMAINING_MISSES_AND_IDENTITY.md'
unit='primelora-d204-analyze2-20261003.scope'
def prop(name):
    return subprocess.check_output(['systemctl','--user','show',unit,'-p',name,'--value'],text=True).strip()
assert prop('ActiveState') == 'inactive' and not prop('InvocationID') and not prop('ControlGroup')
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
assert 'InvocationID=d976272d79854f8dad5d84c78269486a' in (RAW/'analyze2_scope.txt').read_text()
assert 'Exit status: 0' in (RAW/'analyze2_time.txt').read_text()
assert all(line.split()[1] == '0' for line in (RAW/'analyze2_memory_events.txt').read_text().splitlines())
assert (RAW/'analyze2_swap.txt').read_text().strip() == '0'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()

load=lambda p:json.loads(p.read_text())
d=load(OUT/'diagnosis.json')
s=load(OUT/'summary.json')
assert digest(OUT/'diagnosis.json') == '39c0a6d608dc0f2d652a75620ef066fb7ccb35092e5421f85c65cc5eded0e1ab'
assert digest(OUT/'summary.json') == 'a5ee037f874cfeea68d958c7be444b264dc7c915024fb702108e1d95df8371c0'
for path,sha in d['sources'].items():
    assert digest(Path(path)) == sha
for ref in s['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256']
assert check_plan() == d['plan_sha256']
protection=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protection == d['protection_after'] and protection['pass']
with (OUT/'request_control_spans.csv').open(newline='') as f:
    rows=list(csv.DictReader(f))
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
with (OUT/'control_spans.csv').open(newline='') as f:
    groups=list(csv.DictReader(f))
assert len(groups) == len(d['groups']) == 65
for row,expected in zip(groups,d['groups']):
    assert row['group'] == expected['group'] and row['field'] == expected['field']
    selected=[r for r in rows if row['group'] == 'all' or r['tier'] == row['group']]
    values=sorted(float(r[row['field']]) for r in selected)
    assert int(row['n']) == len(values) == expected['n']
    for name,actual in dict(mean=mean(values),p50=values[math.ceil(.5*len(values))-1],
                            p95=values[math.ceil(.95*len(values))-1],max=values[-1]).items():
        assert float(row[name]) == expected[name] == actual

# Independently recompute overlays and document tables from emitted request CSVs.
for path,sha in d['overlay_source_sha256'].items():
    assert digest(Path(path)) == sha
prior_path=BASE/'20261003_d196_control_path/control_spans.csv'
prior={(r['group'],r['field']):r for r in csv.DictReader(prior_path.open())}
comparison=list(csv.DictReader((OUT/'previous_current_stage_comparison.csv').open()))
assert len(comparison)==65
for r in comparison:
    old=prior[r['group'],r['field']]
    new=next(g for g in groups if g['group']==r['group'] and g['field']==r['field'])
    assert float(r['prior_mean'])==float(old['mean'])
    assert float(r['current_mean'])==float(new['mean'])
    assert float(r['delta_current_minus_prior'])==float(new['mean'])-float(old['mean'])
text=DOC.read_text()
labels={'arrival_release_lateness_ms':'计划到达→服务端接收',
        'dispatch_window_wait_ms':'接收→全局 gate',
        'recorded_routing_ms':'gate→源准入：已记录 routing',
        'runtime_wait_outside_recorded_routing_ms':'gate→源准入：其余残余',
        'source_to_generation_handoff_ms':'源准入→generation handoff',
        'generation_handoff_to_native_ms':'generation handoff→native dispatch'}
for field,label in labels.items():
    new=next(r for r in groups if r['group']=='all' and r['field']==field)
    old=prior['all',field]
    x,y=float(old['mean']),float(new['mean'])
    line=f"| {label} | {x:.3f} | {y:.3f} | {y-x:+.3f} | {float(new['p95']):.3f} |"
    assert line in text,line
overlay=list(csv.DictReader((OUT/'request_control_spans_with_outcomes.csv').open()))
assert len(overlay)==4000 and {r['request_id'] for r in overlay}=={r['request_id'] for r in rows}
for expected in d['outcome_groups']:
    cohort=[r for r in overlay if r['outcome']==expected['group']]
    values=sorted(float(r[expected['field']]) for r in cohort)
    assert len(values)==expected['n']
    assert mean(values)==expected['mean']
    assert values[math.ceil(.95*len(values))-1]==expected['p95']
for outcome in ('timing_pass','ttft_only_miss','tpot_only_miss','both_miss'):
    cohort=[r for r in overlay if r['outcome']==outcome]
    metrics=[mean(float(r[k]) for r in cohort) for k in ('dispatch_window_wait_ms','recorded_routing_ms','source_to_generation_handoff_ms')]
    line=f"| {outcome} | {len(cohort)} | "+" | ".join(f"{v:.3f}" for v in metrics)+" |"
    assert line in text,line
for expected in d['phase_outcomes']:
    cohort=[r for r in overlay if int(r['phase_index'])==expected['phase_index']]
    n=len(cohort)
    counts=[sum(r['outcome']==o for r in cohort) for o in ('timing_pass','ttft_only_miss','tpot_only_miss','both_miss')]
    assert n==500 and counts==[expected[k] for k in ('timing_pass','ttft_only_miss','tpot_only_miss','both_miss')]
    line=f"| {expected['phase_index']} | {n} | "+" | ".join(str(v) for v in counts)+" |"
    assert line in text,line
ids=list(csv.DictReader((OUT/'request_output_identity.csv').open()))
assert len(ids)==len({r['request_id'] for r in ids})==4000
assert sum(r['output_changed']=='True' for r in ids)==126
for r in ids:
    assert (r['prior_output_sha256']!=r['current_output_sha256'])==(r['output_changed']=='True')
    assert r['retained_native_id_match']=='True'
for name,predicate in [('all',lambda r:True),('finance_lora',lambda r:r['adapter_id']=='finance_lora'),
    ('medical_lora',lambda r:r['adapter_id']=='medical_lora'),
    ('other_logical_adapters',lambda r:r['adapter_id'] not in ('finance_lora','medical_lora'))]:
    cohort=[r for r in ids if predicate(r)]
    same=sum(r['output_changed']=='False' for r in cohort)
    assert f"| {name} | {len(cohort)} | {same} | {len(cohort)-same} |" in text
assert sum(r['source_content_sha_status']=='equal' for r in ids)==672
assert sum(r['source_content_sha_status']=='unavailable_native_source' for r in ids)==3328
# Failed analysis remains a failed analysis, not erased or relabeled.
failed='primelora-d204-analyze1-20261003.scope'
assert not subprocess.check_output(['systemctl','--user','show',failed,'-p','InvocationID','--value'],text=True).strip()
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',failed).exists()
assert 'InvocationID=7dd3cfe6b37546b68983f1a4b129eab3' in (RAW/'analyze1_scope.txt').read_text()
assert 'Exit status: 1' in (RAW/'analyze1_time.txt').read_text()
assert "KeyError: 'content_sha256'" in (RAW/'analyze1.log').read_text()
assert all(line.split()[1]=='0' for line in (RAW/'analyze1_memory_events.txt').read_text().splitlines())
assert (RAW/'analyze1_swap.txt').read_text().strip()=='0'

source_paths=['scripts/run_all_experiments.py','scripts/analyze_control_path_overhead.py',
    'faaslora/preloading/planning_cpu.py','faaslora/memory/gpu_monitor.py',
    'faaslora/experiment/instance_pool.py','faaslora/scheduling/vllm_ieee_frontend.py',
    'faaslora/memory/residency_manager.py','faaslora/datasets/workload_generator.py',
    'scripts/dedicated_engine_worker.py','docs/ieee_tc/D203_7B_ORDINARY_FULL.md']
for name in source_paths:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git','show','HEAD:'+name])
# Syntax smoke for the new local analysis wrappers; no code execution or pyc writes.
for name in ('analyze.py','analyze2.py','finalize1.py','check_staged.py'):
    compile((RAW/name).read_bytes(),str(RAW/name),'exec')
for name in ('run_cpu.sh','run_cpu2.sh'):
    subprocess.run(['bash','-n',str(RAW/name)],check=True)

members=[RAW/name for name in ('analyze.py','analyze2.py','run_cpu.sh','run_cpu2.sh',
    'finalize1.py','check_staged.py','analyze1_scope.txt','analyze1_time.txt',
    'analyze1_memory_events.txt','analyze1_swap.txt','analyze1.log',
    'analyze2_scope.txt','analyze2_time.txt','analyze2_memory_events.txt','analyze2_swap.txt','analyze2.log')]
members += [ROOT/'scripts/analyze_control_path_overhead.py']
bundle=BASE/'20261003_d204_analysis_sources.tar.gz'
assert not bundle.exists()
hashes={}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        assert p.is_file() and p.stat().st_size < 128*1024
        name=p.name
        assert name not in hashes
        hashes[name]=digest(p)
        archive.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name,sha in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == sha
with (BASE/'20261003_d204_analysis_sources_members.json').open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
with (BASE/'20261003_d204_analysis_sources.sha256').open('x') as f:
    f.write(digest(bundle)+'  '+bundle.name+'\n')
artifacts=sorted(OUT.iterdir())+[DOC,bundle]
result=dict(kind='d204_offline_evidence_verification_v1',passed=True,
    protection=protection,request_count=4000,summary_rows=65,
    sources_unchanged=source_paths,syntax_smoke=True,analysis_scope_released=True,
    analysis_invocation_id='d976272d79854f8dad5d84c78269486a',
    artifacts={str(p.relative_to(ROOT)):digest(p) for p in artifacts},
    bundle_members=len(hashes),bundle_bytes=bundle.stat().st_size,
    prior_table_sources={str(prior_path.relative_to(ROOT)):digest(prior_path)},
    failed_attempt_retained=True, output_identity_rows=4000, output_differences=126,
    native_source_hash_unavailable=3328, numerical_correctness_qualified=False,
    comparison_rows=len(comparison),document_stage_table_checked=True,
    document_outcome_phase_identity_tables_checked=True)
with (BASE/'20261003_d204_evidence_verification.json').open('x') as f:
    json.dump(result,f,indent=2)
print(json.dumps(result))
