"""Reuse the sealed D203 projection and existing RPC analyzer; no inference."""
import csv
import json
import math
import hashlib
from collections import Counter
from pathlib import Path
from statistics import mean

from scripts.analyze_control_path_overhead import analyze_rpc_breakdown, write_csv
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal

RAW = Path(__file__).parent.resolve()
SOURCE = ROOT / 'results/ieee_tc/p2_backend_qualification/d203_20261003'
OUT = ROOT / 'paper_results/ieee_tc/p2_backend/20261003_d204_control_path'
SEALED = ROOT / 'paper_results/ieee_tc/p2_backend/20261003_d203_7b_full_w0_full1.json'
SHA = '8b92e298f7093295a5b062f45e8502d4c68b9d71e93aa606049116be044763e3'
PROJECTION = SOURCE / 'full_full1_request_projection.json'
DEPLOYMENT = SOURCE / '7b_full_w0_full1/launch.launch/physical_deployment'
PROTOCOL = ROOT / 'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
SEAL = ROOT / 'paper_results/ieee_tc/safety/20260925_execution_start_protected.json'

assert not OUT.exists()
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(PROTOCOL) == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
before = verify_seal(SEAL)
assert before['pass'] and before['entry_count'] == 147
audit = analyze_rpc_breakdown(PROJECTION, DEPLOYMENT/'deployment.json',
    DEPLOYMENT/'request_terminals.jsonl', SEALED, SHA, OUT)
assert audit['complete_field_coverage']
assert PROJECTION.stat().st_size < 64 * 1024**2
rows = json.loads(PROJECTION.read_text())['requests']
assert len(rows) == len({r['request_id'] for r in rows}) == 4000

records = []
for row in rows:
    rt = row['runtime_slot_wait_ms']
    routing = row['routing_decision_us'] / 1000
    lateness = row['arrival_release_lateness_ms']
    window = row['dispatch_window_wait_ms']
    admission = row['dispatch_admission_wait_ms']
    t = row['native_token_timing']
    handoff = row['retained_reference_evidence']['generation_submission']
    assert handoff['boundary'] == 'parent_rpc_handoff_v1'
    assert handoff['state'] == 'may_execute'
    assert all(type(v) in (int, float) and math.isfinite(v) and v >= 0
               for v in (rt, routing, lateness, window, admission))
    residual = rt - routing
    # No clipping or treating missing/invalid quantities as zero.
    assert residual >= 0, (row['request_id'], rt, routing)
    assert abs(lateness + window + rt - admission) <= 1.0
    source_to_handoff = 1000 * (handoff['handoff_monotonic_s'] - t['controller_admitted_monotonic_s'])
    handoff_to_native = 1000 * (t['native_dispatch_monotonic_s'] - handoff['handoff_monotonic_s'])
    assert min(source_to_handoff, handoff_to_native) >= 0
    assert abs(source_to_handoff + handoff_to_native - t['admission_to_engine_dispatch_ms']) <= 1.0
    e = row['external_arrival_timing']
    ext = dict(offered_to_task_ms=1000*(e['task_created_s']-e['planned_arrival_s']),
        task_to_client_submit_ms=1000*(e['client_submit_s']-e['task_created_s']),
        client_submit_to_server_receive_ms=1000*(e['server_received_s']-e['client_submit_s']),
        server_receive_to_service_dequeue_ms=1000*(e['service_dequeued_s']-e['server_received_s']))
    assert min(ext.values()) >= 0
    records.append(dict(request_id=row['request_id'],tier=row['readiness_tier_before_dispatch'],
        arrival_release_lateness_ms=lateness,dispatch_window_wait_ms=window,
        runtime_slot_wait_ms=rt,recorded_routing_ms=routing,
        runtime_wait_outside_recorded_routing_ms=residual,
        dispatch_admission_wait_ms=admission,source_to_generation_handoff_ms=source_to_handoff,
        generation_handoff_to_native_ms=handoff_to_native,
        overall_ttft_ms=row['overall_ttft_ms'],**ext))
groups=[]
fields=list(records[0])[2:]
for tier in ('all','gpu','host','nvme','remote'):
    selected=[r for r in records if tier == 'all' or r['tier'] == tier]
    assert selected
    for name in fields:
        values=sorted(r[name] for r in selected)
        groups.append(dict(group=tier,field=name,n=len(values),unit='ms',mean=mean(values),
            p50=values[math.ceil(.5*len(values))-1],p95=values[math.ceil(.95*len(values))-1],max=values[-1]))
write_csv(records,OUT/'request_control_spans.csv')
write_csv(groups,OUT/'control_spans.csv')
# D204 overlay: reuse D203 timing classification and D195 bounded projection.
timing_csv = ROOT/'paper_results/ieee_tc/p2_backend/20261003_d203_timing_requests.csv'
timing_json = ROOT/'paper_results/ieee_tc/p2_backend/20261003_d203_timing_gap.json'
old_projection = ROOT/'results/ieee_tc/p2_backend_qualification/d195_20261003/full_full1_request_projection.json'
prior_groups = ROOT/'paper_results/ieee_tc/p2_backend/20261003_d196_control_path/control_spans.csv'
pins = {
    timing_csv: '766699d8d1fb1a5a5742990fd5ddcaf81d17e36056e1659fce0d2202f3345968',
    timing_json: '2ef171286a7fb67ccf3212824a90cece2edc493e4e30a6a5d9d25dc072f4a10a',
    old_projection: '805a6b8c5aa8f89b7394a4eba8b593f5ada95c6f3048f5a9f2d6c1c06e759697',
    prior_groups: '478dc7f9680e0ab106413442884d57218026e768c4ee19d05bd80976b3a7b5c7',
}
for path, sha in pins.items():
    assert path.stat().st_size < 64*1024**2 and digest(path) == sha
times = {r['request_id']:r for r in csv.DictReader(timing_csv.open())}
thresholds = {r['group_id']:r for r in json.loads(timing_json.read_text())['thresholds']}
old = {r['request_id']:r for r in json.loads(old_projection.read_text())['requests']}
current = {r['request_id']:r for r in rows}
assert len(times) == len(old) == len(current) == 4000 and set(times) == set(old) == set(current)
sealed = json.loads(SEALED.read_text())
changed_expected = set(sealed['d195_request_contract_comparison']['fields']['completion_token_ids_sha256']['changed_request_ids'])
identity_rows=[]
for row in records:
    rid=row['request_id']; cur=current[rid]; prev=old[rid]; tm=times[rid]
    assert abs(float(tm['ttft_s'])*1000-row['overall_ttft_ms']) <= 1.0
    assert tm['tier'] == row['tier']
    threshold=thresholds[int(tm['group_id'])]
    tp_pass=float(tm['tpot_s'])<=threshold['tpot_s']
    tt_pass=float(tm['ttft_s'])<=threshold['ttft_s']
    assert (tm['ttft_pass']=='True') == tt_pass and (tm['tpot_pass']=='True') == tp_pass
    assert tm['outcome'] == ('timing_pass' if tt_pass and tp_pass else 'ttft_only_miss' if tp_pass else 'tpot_only_miss' if tt_pass else 'both_miss')
    row['outcome']=tm['outcome']
    row['pre_engine_ms']=sum(row[k] for k in (
        'arrival_release_lateness_ms','dispatch_window_wait_ms','runtime_slot_wait_ms',
        'source_to_generation_handoff_ms','generation_handoff_to_native_ms'))
    row['pre_engine_exceeds_ttft_threshold']=row['pre_engine_ms']>1000*threshold['ttft_s']
    row['ttft_excess_ms']=max(0.,row['overall_ttft_ms']-1000*threshold['ttft_s'])
    row['tpot_ms']=1000*float(tm['tpot_s'])
    row['phase_index']=int(rid.removeprefix('req_'))//500
    # Recheck retained identity without importing the serving backend.
    int_id=(int(hashlib.md5(cur['adapter_id'].encode()).hexdigest(),16)%999999)+1
    assert prev['adapter_id'] == cur['adapter_id']
    assert cur['native_token_timing']['gpu_reference_adapter_int_id'] == int_id
    assert prev['native_token_timing']['gpu_reference_adapter_int_id'] == int_id
    cs=cur['retained_reference_evidence']['source_admission']['source']['content_sha256']
    ps=prev['retained_reference_evidence']['source_admission']['source']['content_sha256']
    assert len(cs)==64 and cs==ps
    output_changed=cur['completion_token_ids_sha256']!=prev['completion_token_ids_sha256']
    assert output_changed == (rid in changed_expected)
    assert cur['native_token_timing']['completion_token_ids_sha256']==cur['completion_token_ids_sha256']
    assert prev['native_token_timing']['completion_token_ids_sha256']==prev['completion_token_ids_sha256']
    identity_rows.append(dict(request_id=rid,adapter_id=cur['adapter_id'],
        expected_native_adapter_int_id=int_id,retained_native_id_match=True,
        source_content_sha_match=True,source_content_sha256=cs,
        prior_tier=prev['readiness_tier_before_dispatch'],current_tier=row['tier'],
        output_changed=output_changed,prior_output_sha256=prev['completion_token_ids_sha256'],
        current_output_sha256=cur['completion_token_ids_sha256'],
        numerical_cause='unresolved'))
assert len(changed_expected)==126 and sum(r['output_changed'] for r in identity_rows)==126
overlay_groups=[]
for outcome in ('timing_pass','ttft_only_miss','tpot_only_miss','both_miss'):
    cohort=[r for r in records if r['outcome']==outcome]
    assert cohort
    for name in (*fields,'pre_engine_ms','ttft_excess_ms','tpot_ms'):
        values=sorted(r[name] for r in cohort)
        overlay_groups.append(dict(group=outcome,field=name,n=len(values),unit='ms',
            mean=mean(values),p50=values[math.ceil(.5*len(values))-1],
            p95=values[math.ceil(.95*len(values))-1],max=values[-1]))
counts=[]
for phase in range(8):
    cohort=[r for r in records if r['phase_index']==phase]
    assert len(cohort)==500
    counts.append(dict(phase_index=phase,count=len(cohort),
        **{v:sum(r['outcome']==v for r in cohort) for v in ('timing_pass','ttft_only_miss','tpot_only_miss','both_miss')},
        pre_engine_exceeds_ttft_threshold=sum(r['pre_engine_exceeds_ttft_threshold'] for r in cohort)))
ident_groups=[]
for name,predicate in [('all',lambda r:True),('finance_lora',lambda r:r['adapter_id']=='finance_lora'),
        ('medical_lora',lambda r:r['adapter_id']=='medical_lora'),
        ('other_logical_adapters',lambda r:r['adapter_id'] not in ('finance_lora','medical_lora'))]:
    cohort=[r for r in identity_rows if predicate(r)]
    ident_groups.append(dict(group=name,count=len(cohort),
        changed=sum(r['output_changed'] for r in cohort),
        same=sum(not r['output_changed'] for r in cohort)))
prior=list(csv.DictReader(prior_groups.open()))
prior={(r['group'],r['field']):r for r in prior}
comparison=[]
for r in groups:
    p=prior[(r['group'],r['field'])]
    a,b=float(p['mean']),r['mean']
    comparison.append(dict(group=r['group'],field=r['field'],prior_n=int(p['n']),
        current_n=r['n'],prior_mean=a,current_mean=b,unit='ms',
        delta_current_minus_prior=b-a,lower_better_relative=(a-b)/a if a else None))
for name,data in [('request_control_spans_with_outcomes.csv',records),
        ('outcome_control_spans.csv',overlay_groups),('phase_outcomes.csv',counts),
        ('request_output_identity.csv',identity_rows),('output_identity_groups.csv',ident_groups),
        ('previous_current_stage_comparison.csv',comparison)]:
    write_csv(data,OUT/name)
assert sum(r['pre_engine_exceeds_ttft_threshold'] for r in records)==161
after=verify_seal(SEAL)
assert after == before
result=dict(kind='d204_retained_control_path_diagnosis_v1',new_inference_run=False,
    source_run='D203',run_count=1,formal_qualification=False,n_correct=None,
    plan_sha256=check_plan(),metric_protocol_sha256=digest(PROTOCOL),
    protection_before=before,protection_after=after,
    sources={str(p):digest(p) for p in (Path(__file__),PROJECTION,SEALED,PROTOCOL,
        ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'scripts/run_all_experiments.py')},
    groups=groups, outcome_groups=overlay_groups, phase_outcomes=counts,
    output_identity_groups=ident_groups, output_changed_count=126,
    retained_expected_native_adapter_ids_match=4000,
    selected_source_content_sha_same=4000,
    output_tokens_available=False, first_divergent_position=None,
    per_token_execution_mapping_available=False,
    overlay_source_sha256={str(p):s for p,s in pins.items()},
    caveats=[
        'recorded_routing_ms includes awaits; it is not exclusive CPU execution.',
        'Recorded routing excludes collection rejection returning None before the timer update.',
        'Residual includes unrecorded retries, pending registration, selected-source protection, event-loop resumption and capacity waits; it is not a named RPC duration.',
        'Actual selected-tier groups are conditional, not matched causal populations.',
        'External arrival subspans overlap legacy dispatch fields and must not be summed twice.',
        'No new performance result, CI, numerical correctness, common SLO or G1/G2 acceptance.'])
with (OUT/'diagnosis.json').open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps({'passed':True,'requests':len(records),'groups':[r for r in groups if r['group']=='all'],'outcomes':counts,'identity':ident_groups},allow_nan=False))
