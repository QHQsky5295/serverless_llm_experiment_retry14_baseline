"""Reuse D332 exact-archive audit/apply; never remove installed packages."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('d332',
    OUT.parents[1]/'d332_20261008/cache1/download_archives.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
d = previous.d
TARGETS = [
    ('libcublas-static', '12.1.0.26'),
    ('libcufft-static', '11.0.2.4'),
    ('libcusparse-static', '12.0.2.55'),
    ('libcusparse', '12.0.2.55'),
    ('libcusparse-dev', '12.0.2.55'),
    ('libnpp', '12.0.2.50'),
    ('libnpp-static', '12.0.2.50'),
    ('libcufft', '11.0.2.4'),
    ('libcusolver', '11.4.4.55'),
]

def save(name, value):
    with (OUT/name).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

def configure(package, version):
    name = f'{package}-{version}-0'
    d.OUT = OUT/package
    d.ARCHIVE = d.ROOT/(name+'.tar.bz2')
    d.RECORD = d.ROOT/name/'info/repodata_record.json'

def sample(group):
    return {k: (group/k).read_text().strip() for k in (
        'memory.high','memory.max','memory.swap.max','memory.peak',
        'memory.events','memory.swap.current','cgroup.events')}

parser = argparse.ArgumentParser()
parser.add_argument('action', choices=('audit','apply'))
parser.add_argument('--reviewed-manifest-sha256')
args = parser.parse_args()
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
before = sample(group)
assert before['memory.high'] == str(3*p.GIB)
assert before['memory.max'] == str(4*p.GIB)
assert before['memory.swap.max'] == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
success = False
try:
    if args.action == 'audit':
        rows = []
        for package, version in TARGETS:
            configure(package, version)
            d.OUT.mkdir(exist_ok=False)
            previous.audit('nvidia', package, version)
            rows.append(dict(package=package, version=version,
                audit_sha256=d.sha(d.OUT/'audit.json')))
        save('review_manifest.json', dict(created=time.time(), targets=rows,
            action='nine_verified_public_download_archives_only'))
        print(json.dumps(dict(review_manifest_sha256=p.digest(OUT/'review_manifest.json'))), flush=True)
    else:
        assert p.digest(OUT/'review_manifest.json') == args.reviewed_manifest_sha256
        manifest = json.loads((OUT/'review_manifest.json').read_text())
        assert [(r['package'],r['version']) for r in manifest['targets']] == TARGETS
        for row in manifest['targets']:
            configure(row['package'],row['version'])
            d.apply(row['audit_sha256'])
        save('complete.json', dict(removed_files=len(TARGETS),
            removed_allocated_bytes=sum(json.loads((OUT/pkg/'complete.json').read_text())['removed_allocated_bytes']
                                        for pkg, _ in TARGETS),
            after=d.prior.usage(), reviewed_manifest_sha256=args.reviewed_manifest_sha256))
    success = True
finally:
    save(args.action+'_resources.json', dict(identity=identity,before=before,
        after=sample(group),success=success))
