"""Reuse exact-owned closure and small SHA-verified archive for D336 setup."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
out = p.ROOT/'paper_results/ieee_tc/p2_backend/d336_capacity_control'
out.mkdir(exist_ok=False)
cleanup = []
rejected = json.loads((raw/'cache1/audit_resources.json').read_text())
assert rejected['success'] is False
assert subprocess.check_output(['systemctl','--user','show',rejected['identity']['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
assert not list((raw/'cache1').glob('*/complete.json'))
cleanup.append(dict(identity=rejected['identity'],after='inactive',
    resources=rejected['after'],reason='Missing local SHA metadata; zero removals; exact empty scope closed.'))
reports = [raw/'cache2/audit_resources.json',raw/'cache2/apply_resources.json',raw/'regression1.json']
for path in reports:
    report = json.loads(path.read_text())
    if path.name == 'regression1.json':
        assert report['returncode'] == 0
    else:
        assert report['success'] is True
    identity = report['identity']
    group = Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources = {k:(group/k).read_text().strip() for k in
        ['memory.peak','memory.events','memory.swap.current','memory.high','memory.max','memory.swap.max']}
    assert resources['memory.swap.current'] == '0'
    assert all(int(row.split()[1]) == 0 for row in resources['memory.events'].splitlines())
    subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
    assert subprocess.check_output(['systemctl','--user','show',identity['unit'],
        '-p','ActiveState','--value'],text=True).strip() == 'inactive'
    cleanup.append(dict(report=str(path),identity=identity,resources=resources,
        empty_before_stop=True,after='inactive'))
prelaunch = json.loads((raw/'prelaunch1.log').read_text().splitlines()[-1])
identity = prelaunch['scope']
group = Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
resources = {k:(group/k).read_text().strip() for k in ['memory.peak','memory.events','memory.swap.current']}
assert resources['memory.swap.current'] == '0'
assert all(int(row.split()[1]) == 0 for row in resources['memory.events'].splitlines())
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',identity['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
cleanup.append(dict(identity=identity,resources=resources,empty_before_stop=True,after='inactive'))
with (out/'cleanup.json').open('x') as f:
    json.dump(cleanup,f,indent=2)
binding = json.loads((raw/'prelaunch_binding.json').read_text())
assert binding['passed']
for ref in binding['source_references']:
    assert p.digest(Path(ref['path'])) == ref['sha256']
with (out/'prelaunch_binding.json').open('x') as f:
    json.dump(binding,f,indent=2)
tests = int(re.search(r'^Ran (\d+) tests in ',(raw/'regression1.log').read_text(),re.M)[1])
assert (raw/'regression1.log').read_text().rstrip().endswith('OK')
refs = [raw/name for name in ['regression1.log','regression1.json','test_candidate.py',
    'prelaunch_binding.json','prelaunch1.log','verify_prelaunch.py','launch_gate.py',
    'start_remote.sh','stop_remote.sh','check_remote_health.py','checkpoint.py']]
refs += sorted(x for name in ['cache1','cache2'] for x in (raw/name).rglob('*') if x.is_file())
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in refs:
    assert token and token not in path.read_bytes(),path
archive = out/'setup_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in refs:
        tar.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(refs)
    for path in refs:
        assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw))).read()).hexdigest() == p.digest(path)
record = dict(kind='d336_capacity_control_setup_v1',tests=tests,
    source_plan_sha256=p.check_plan(),metric_protocol_sha256=p.digest(p.ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    capacity_targets=binding['capacity_targets'],native_gpu_validation=False,
    numerical_n_correct=None,formal_qualification=False,no_figures=True,
    cache_cleanup=json.loads((raw/'cache2/complete.json').read_text()),
    artifact_delivery_cache='Reuse existing D78/D80 approved published cache; not regenerated.',
    raw_references=[dict(path=str(path),sha256=p.digest(path)) for path in refs],
    archive_sha256=p.digest(archive),next='Checkpoint and fresh gates, then one full4000 W0; no more short tests.')
with (out/'evidence.json').open('x') as f:
    json.dump(record,f,indent=2,allow_nan=False)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+path.name+'\n')
print(json.dumps(dict(tests=tests,archive_bytes=archive.stat().st_size,archive_members=len(refs),
    released_cpu_scopes=len(cleanup))))
group=p.cg_path()
print(json.dumps(dict(identity=p.scope_identity(group.name),
    resources={k:(group/k).read_text().strip() for k in ['memory.peak','memory.events','memory.swap.current']})))
