"""D594 explicit-path backup guards reused for D659 current 3B Full prefix qualification."""
import hashlib,json,os,re,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d659_3b_full_smoke100'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
expected_head='8a30f65fbeeeb8b79e83ad40c4d388a6a080b525'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==expected_head
preserved={ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(path)==sha
audit=read(RAW/'analysis1.log')
assert audit['passed'] and audit['protocol_bound_count']==100
assert not audit['fixed_workload_complete4000'] and not audit['ranking_eligible']
assert audit['stats']['n_correct'] is None
for ref in audit['refs']:assert p.digest(Path(ref['path']))==ref['sha256']
assert read(RAW/'analysis_receipt.json')['passed']
for phase in ('start','analysis'):
    closure=read(RAW/(phase+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
local=read(RAW/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
remote=read(RAW/'remote_stop.json')
assert remote['all_owned_units_inactive'] and remote['download_hashes_match_remote']
OUT.mkdir(parents=True,exist_ok=False)
with (OUT/'audit.json').open('xb') as stream:stream.write((RAW/'analysis1.log').read_bytes())
assert p.digest(OUT/'audit.json')==p.digest(RAW/'analysis1.log')
files=['audit.json']
members=[RAW/x for x in ('start.py','close.py','close_launch.py','start_remote.sh',
    'stop_remote.sh','check_remote_health_stdlib.py','collect_closure.py','analyze.py',
    'run_analysis.py','publish.py','launch_gate.json','model_cache_metadata_before.json',
    'start_identity.json','start_receipt.json','start_closure.json','service_aux_identity.json',
    'local_cleanup.json','remote_health.json','remote_start.log','remote_stop.log','remote_stop.json',
    'collection_receipt.json','collection1.log','completion_receipt.json',
    'analysis_identity.json','analysis_receipt.json','analysis_closure.json')]
previous=RAW.parent/'d658_20261018'
closed=read(previous/'publication_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
members += [previous/name for name in ('publication_identity.json','publication_receipt.json','publication_closure.json')]
save(OUT/'manifest.json',dict(passed=True,kind='d659_3b_prefix100_seal_v1',
    source_audit_sha256=p.digest(RAW/'analysis1.log'),source_commit=expected_head,
    performance_runs=1,complete4000=False,formal_qualification=False,n_correct=None,
    numerical_proof_unknown=True,ranking_eligible=False,
    n_native_bound=100,joint_slo_count=audit['common_threshold_joint_count'],
    no_figures=True,no_runtime_source_change=True,
    outputs={'audit.json':p.digest(OUT/'audit.json')},
    next_action='Same measured 3B Full configuration complete W0; prefix is not G1/G2 qualification.'))
files+=['manifest.json']
baseline=Path('/home/qhq/serverless_llm_baselines')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=baseline,text=True).strip()=='e16af33aaf41f02a62ecdce59f6f3227813244c3'
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
with tarfile.open(OUT/'execution_evidence.tar.gz','x:gz') as bundle:
    for path in members:
        check(path.read_bytes());bundle.add(path,arcname=str(path.relative_to(RAW.parent.parent)),recursive=False)
with tarfile.open(OUT/'execution_evidence.tar.gz') as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(str(path.relative_to(RAW.parent.parent))).read()).hexdigest()==p.digest(path)
files+=['execution_evidence.tar.gz']
with (OUT/'result.sha256').open('x') as f:
    for name in files:f.write(p.digest(OUT/name)+'  '+name+'\n')
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D659_3B_FULL_PREFIX_QUALIFICATION.md']
names += [str((OUT/name).relative_to(ROOT)) for name in files+['result.sha256']]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: seal current 3B Full native prefix qualification and SLO limits (D659)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,identity=identity,files=names,
    protected=protected,preserved={str(k):v for k,v in preserved.items()}))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
