"""Reuse explicit D595 backup after bounded D639 analysis."""
import ast
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code = source.read_text()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d639_cross_workload_observation'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'",
        "=='fa75de67c7b64ed8264992105bb12abc7de2e7f7'")
begin = code.index('reg=read(RAW/')
end = code.index('preserved={', begin)
code = code[:begin] + """audit=read(RAW/'qualification.json')
assert audit['passed'] and audit['no_gpu_run'] and audit['no_production_change']
assert [r['changed_outputs'] for r in audit['audits']]==[177,122]
for path,sha in audit['refs'].items():assert p.digest(Path(path))==sha
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
previous=RAW.parent/'d638_20261017'
receipt=read(previous/'backup_receipt.json')
assert receipt['passed'] and receipt['head']=='fa75de67c7b64ed8264992105bb12abc7de2e7f7'
closed=read(previous/'backup_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',
    'faaslora','scripts','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
""" + code[end:]
begin = code.index('members=[RAW/name')
end = code.index('\nfor path in members:', begin)
code = code[:begin] + """members=[RAW/name for name in ('analyze.py','close.py','backup.py',
    'analysis_identity.json','analysis_closure.json','preflight.json','qualification.json','backup_gate.json',
    'w1_changed_requests.json','w2_changed_requests.json','w1_reference_matches.json','w2_reference_matches.json')]
members += [previous/'backup_receipt.json',previous/'backup_closure.json',
    ROOT/'docs/ieee_tc/D639_7B_CROSS_WORKLOAD_OBSERVATION_DECISION.md']
assert len({path.name for path in members})==len(members)
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
""" + code[end:]
begin = code.index('test_counts={')
end = code.index("save(OUT/'qualification.json'", begin)
code = code[:begin] + """test_counts={'complete_request_records':16000,'existing_reference_pairs':200}
record=dict(passed=True,production_candidate=False,native_gpu_validation=False,
    full_performance_run=False,parent_commit='fa75de67c7b64ed8264992105bb12abc7de2e7f7',
    audit=audit,protected=protected,preserved={str(k):v for k,v in preserved.items()},
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    archive_members={path.name:dict(path=str(path),sha256=p.digest(path)) for path in members},
    caveat='Version-labelled known-workload observations and bounded saved-output audit; no same-version formal splice, numerical proof or global optimum.')
""" + code[end:]
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D639_7B_CROSS_WORKLOAD_OBSERVATION_DECISION.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: preserve versioned 7B cross-workload observations and advance 3B main line (D639)')
ast.parse(code)
exec(compile(code, str(source), 'exec'))
