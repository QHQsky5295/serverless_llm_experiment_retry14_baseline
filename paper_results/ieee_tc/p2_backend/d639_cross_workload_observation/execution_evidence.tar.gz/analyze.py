"""Complete W1/W2 saved-output audits and a version-labelled 7B overview.

Reuse D638 projections; read old gzip evidence without restoring datasets.
"""
import ast
import collections
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import ijson

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.plot_d290_diagnostic import binding_checks, request_vectors

source = RAW.parent/'d638_20261017/analyze.py'
assert p.digest(source) == '32b9343204cc275a6c15b08caea8d19d42f75da894135e4393c673b7dfb15c40'
code = source.read_text()
refs = {str(source):p.digest(source)}
for node in ast.parse(code).body:
    wanted = isinstance(node, ast.FunctionDef) and node.name in {'read', 'save', 'bound', 'projection'}
    wanted = wanted or (isinstance(node, ast.Assign) and any(isinstance(t, ast.Name)
        and t.id == 'metadata_fields' for t in node.targets))
    if wanted:
        snippet = ast.get_source_segment(code, node)
        if isinstance(node, ast.FunctionDef) and node.name == 'projection':
            assert snippet.count("path.open('rb')") == 2
            snippet = snippet.replace("path.open('rb')", 'open_input(path)')
        exec(compile(snippet, str(source), 'exec'))

def open_input(path):
    return gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')

def source_path(audit):
    original = Path(audit['evidence']['source'])
    expected_sha = audit['evidence']['source_sha256']
    if original.exists():
        return bound(original, expected_sha)
    receipt_path = bound(Path(str(original)+'.compression_receipt.json'))
    receipt = read(receipt_path)
    assert receipt['source'] == str(original)
    assert receipt['source_sha256'] == receipt['first_roundtrip_sha256'] == receipt['second_roundtrip_sha256'] == expected_sha
    archive = bound(Path(receipt['archive']), receipt['archive_sha256'])
    digest = hashlib.sha256()
    with gzip.open(archive, 'rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024), b''):
            digest.update(chunk)
    assert digest.hexdigest() == expected_sha
    return archive

identity = p.scope_identity(p.cg_path().name)
save('analysis_identity.json', identity)
cg = Path(identity['path'])
assert (cg/'memory.high').read_text().strip() == str(3*p.GIB)
assert (cg/'memory.max').read_text().strip() == str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
gate = p.preflight([ROOT], 32*1024*1024)
save('preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
# Reuse the identical, hash-bound independent content canonicalization.
begin, end = code.index('index_path = bound('), code.index('metadata_fields = ')
exec(compile(code[begin:end], str(source), 'exec'))
previous_audit = read(bound(RAW.parent/'d638_20261017/qualification.json'))
for path,sha in previous_audit['refs'].items():
    bound(Path(path), sha)
hf = read(bound(RAW.parent/'d385_20261010/7b_peft_sequence_reference_100_retry1.json'))
native_path = bound(Path(hf['source_native_path']), hf['source_native_sha256'])
native, _, _ = projection(native_path, 'tc_ieee_native_token_witness_100', 100)
hf_rows = {r['request_id']:r for r in hf['requests']}
same_fields = ('request_id','adapter_id','prompt_sha256','native_prompt_sha256',
               'prompt_tokens','target','generation_contract','token_source','weight_sha256')
results = []
for workload, old_id, new_id, folder, expected_changes in (
    ('W1','d619','d633','d633_min2_full_w1',177),
    ('W2','d621','d632','d632_min2_full_w2',122)):
    projections, audits, checks, metas = {}, {}, {}, {}
    for label in (old_id, new_id):
        audit = read(bound(RAW.parent/(label+'_20261017')/'actual_qualification.json'))
        assert audit['passed'] and audit['protocol_bound_count'] == 4000
        assert audit['workload_identity']['profile'] == workload
        audits[label] = audit
        projections[label], checks[label], metas[label] = projection(source_path(audit), 'tc_ieee_full', 4000)
    assert audits[old_id]['workload_identity'] == audits[new_id]['workload_identity']
    summary = read(bound(ROOT/'paper_results/ieee_tc/p2_backend'/folder/'result1/summary.json'))
    assert summary['audit'] == audits[new_id]
    expected_changed_ids = set(summary['comparison']['same_backend_changed_output_request_ids'])
    groups = collections.defaultdict(lambda:dict(total=0, changed=0))
    changes = []
    assert projections[old_id].keys() == projections[new_id].keys()
    for rid, row in projections[new_id].items():
        old = projections[old_id][rid]
        assert all(old[k] == row[k] for k in same_fields), rid
        changed = old['output_sha256'] != row['output_sha256']
        for family,key in (('weight_sha256',row['weight_sha256']),
                           ('zero_update',str(row['all_tensors_zero'])),
                           ('candidate_tier',row['tier']),
                           ('tier_pair',old['tier']+'->'+row['tier'])):
            groups[family+'|'+key]['total'] += 1
            groups[family+'|'+key]['changed'] += int(changed)
        if changed:
            changes.append(dict(**row, reference_tier=old['tier'], reference_output_sha256=old['output_sha256']))
    assert len(changes) == expected_changes
    assert {r['request_id'] for r in changes} == expected_changed_ids
    save(workload.lower()+'_changed_requests.json', changes)
    matches, unmatched = [], []
    for rid, old_native in native.items():
        current = projections[new_id][rid]
        mismatch = [key for key in same_fields if current[key] != old_native[key]]
        if mismatch:
            unmatched.append(dict(request_id=rid, unequal_input_fields=mismatch))
            continue
        ref = hf_rows[rid]
        assert ref['native_ids_sha256'] == old_native['output_sha256']
        matches.append(dict(request_id=rid, adapter_id=current['adapter_id'],
            all_tensors_zero=current['all_tensors_zero'],
            reference_ids_sha256=ref['reference_ids_sha256'], current_ids_sha256=current['output_sha256'],
            exact=current['output_sha256'] == ref['reference_ids_sha256']))
    save(workload.lower()+'_reference_matches.json', dict(matched=matches, unmatched=unmatched))
    result = dict(workload=workload, reference=old_id.upper(), candidate=new_id.upper(),
        source_execution_commit=summary['execution_commit'], binding_check_pass_counts=checks,
        same_input_request_count=4000, changed_outputs=len(changes), groups=dict(sorted(groups.items())),
        independent_reference_matched_inputs=len(matches), independent_reference_exact=sum(r['exact'] for r in matches),
        unmatched_reference_inputs=unmatched, source_stats=audits[new_id]['stats'],
        joint_good=audits[new_id]['common_threshold_joint_count'], runtime_metadata=metas,
        numerical_difference_cause='not established', kernel_arithmetic_correctness_proven=False,
        raw_n_correct_preserved=None, raw_ranking_eligible_preserved=False)
    results.append(result)

references_path = bound(ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft/resident_references.json',
    'a9b6b25fe4ec8a17921dd5968c4fb494b7a6d795c0d4a11c7b7d306ac06bc60c')
references = read(references_path)
baseline_path = bound(ROOT/'paper_results/ieee_tc/main_comparison/d593_complete_7b/metrics.csv',
    '0e591949eaeb99e9255fbe2d6480a3070bb75b658ae3f5584daf2174cb66212f')
baselines = [r for r in csv.DictReader(baseline_path.read_text().splitlines()) if r['system'] != 'PrimeLoRA']
assert len(baselines) == 15
model_points, pairwise = [], []
for workload,label,folder in (('W0','d636','d636_min2_full_w0'),
                            ('W1','d633','d633_min2_full_w1'),('W2','d632','d632_min2_full_w2')):
    path = bound(ROOT/'paper_results/ieee_tc/p2_backend'/folder/'result1/summary.json')
    summary = read(path)
    audit = summary['audit']
    stats = audit['stats']
    assert audit['passed'] and audit['protocol_bound_count'] == 4000 and stats['n_correct'] is None
    budget = references[workload]['B_gpu_seconds'] if workload != 'W0' else None
    point = dict(workload=workload, system='PrimeLoRA', run=label.upper(),
        source_execution_commit=summary['execution_commit'], protocol_bound=4000,
        joint_good=audit['common_threshold_joint_count'], joint_slo=audit['common_threshold_joint_count']/4000,
        gpu_seconds=stats['physical_gpu_seconds'], gpu_seconds_per_protocol_bound=stats['physical_gpu_seconds']/4000,
        p95_ttft_ms=stats['p95_ttft_ms'], p95_tpot_ms=stats['p95_tpot_ms'],
        mean_ttft_ms=stats['mean_ttft_ms'], mean_e2e_ms=stats['mean_e2e_ms'],
        budget_gpu_seconds=budget, ratio_to_budget=stats['physical_gpu_seconds']/budget if budget else None,
        joint95_observed=audit['common_threshold_joint_count'] >= 3800,
        budget_observed=stats['physical_gpu_seconds'] <= budget if budget else None,
        source_summary=dict(path=str(path), sha256=p.digest(path)),
        identity='known_workload_development_observation', independent_holdout=False,
        same_repaired_version_executed=(label == 'd636'), raw_n_correct=None,
        independent_numerical_proof=False, final_formal_ranking_eligible=False)
    model_points.append(point)
    for base in (r for r in baselines if r['workload'] == workload):
        bU,bQ,bA = float(base['gpu_seconds']),float(base['p95_ttft_ms']),float(base['joint_slo'])
        pairwise.append(dict(workload=workload, baseline=base['system'], baseline_run=base['run'],
            baseline_joint_slo=bA, baseline_gpu_seconds=bU, baseline_p95_ttft_ms=bQ,
            baseline_joint95=bA >= .95, baseline_budget_feasible=bU <= budget if budget else None,
            gpu_time_reduction_fraction=(bU-point['gpu_seconds'])/bU,
            p95_ttft_reduction_fraction=(bQ-point['p95_ttft_ms'])/bQ,
            joint_slo_difference_percentage_points=(point['joint_slo']-bA)*100))
repair = read(bound(RAW.parent/'d637_20261017/reuse_impact.json'))
assert repair['passed'] and all(r['repaired_payload_identical_for_every_recorded_attempt'] for r in repair['records'])
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
record = dict(passed=True, kind='d639_bounded_w1_w2_audit_and_versioned_7b_observations',
    audits=results, model_points=model_points, all_baselines=baselines, pairwise=pairwise,
    all_three_joint95_observed=all(r['joint95_observed'] for r in model_points),
    both_budget_constraints_observed=all(r['budget_observed'] for r in model_points if r['workload'] != 'W0'),
    same_version_three_workload_execution=False, historical_repair_reuse_class='R2_with_bounded_affected_path_equivalence',
    no_new_cross_backend_exactness_gate=True, no_gpu_run=True, no_production_change=True,
    refs=refs, protected=protected, scope=identity,
    conclusion='Retain version-labelled native-contract development evidence. No same-version formal splice, kernel arithmetic proof, independent holdout, statistical or universal optimum claim. Bounded saved-output audits now cover W0/W1/W2; do not repeat these runs absent a specific affected defect.')
save('qualification.json', record)
print(json.dumps(dict(passed=True, audits=[{k:r[k] for k in ('workload','changed_outputs',
    'independent_reference_matched_inputs','independent_reference_exact','groups')} for r in results],
    points=[{k:r[k] for k in ('workload','joint_slo','gpu_seconds','ratio_to_budget')} for r in model_points])))
