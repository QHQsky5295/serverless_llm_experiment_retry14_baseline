"""Exact-parent operation-count comparison using the existing real-owner fixture.

CPU correctness/component evidence, not a performance measurement or GPU run.
"""
import ast
import asyncio
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import subprocess
from types import MethodType

import scripts.run_all_experiments as implementation
from tests.test_ieee_tc_request_lifecycle import SelectedSourceAdmissionIntegration

ROOT = Path.cwd()
RAW = ROOT / 'results/ieee_tc/p2_backend_qualification/d176_20261003'
PARENT = '95de3c348a59529cfe57ea5aa2501cdb9e534372'
source = subprocess.check_output(['git', 'show', PARENT + ':scripts/run_all_experiments.py'], text=True)
tree = ast.parse(source)
names = {'_acquire_runtime_gpu_reference', '_ieee_prepare_selected_adapter'}
functions = [n for n in ast.walk(tree) if isinstance(n, ast.AsyncFunctionDef) and n.name in names]
assert len(functions) == 2
namespace = dict(vars(implementation))
exec(compile(ast.Module(body=functions, type_ignores=[]), '<exact-parent-functions>', 'exec'), namespace)
rows = []
for tier in ('gpu', 'host', 'nvme', 'remote'):
    for version in ('parent', 'candidate'):
        case = SelectedSourceAdmissionIntegration()
        try:
            runner, slot, trace, plan, owner, _ = case.build(tier if tier in ('gpu', 'host') else 'remote')
            if tier in ('nvme', 'remote'):
                case.file_source(runner, trace, publish=tier == 'nvme')
            if version == 'parent':
                for name in sorted(names):
                    setattr(runner, name, MethodType(namespace[name], runner))
            result = asyncio.run(runner._exec_request(trace, 4, 0., request_plan=plan))
            assert result.success, result.error
            assert result.readiness_tier_before_dispatch == tier
            counts = Counter(call.kwargs['operation'] for call in slot.engine.ieee_gpu_reference.await_args_list)
            assert counts['source_snapshot'] == 0
            assert counts['demand_load_and_acquire'] == 1
            state = owner.snapshot()
            assert state['live_leases'] == state['live_host_source_leases'] == slot.active_requests == 0
            rows.append(dict(tier=tier, version=version,
                routing_graph_queries=counts['routing_source_snapshot'],
                demand_transactions=counts['demand_load_and_acquire'],
                host_holds=counts['hold_host_source'], host_releases=counts['release_host_source'],
                success=True, dispatch_tier=tier, live_gpu_leases=state['live_leases'],
                live_host_leases=state['live_host_source_leases']))
        finally:
            case.doCleanups()
for old, new in zip(rows[::2], rows[1::2]):
    expected = 1 if old['tier'] == 'host' else 0
    assert old['routing_graph_queries'] - new['routing_graph_queries'] == expected
    assert {k: v for k, v in old.items() if k not in ('version', 'routing_graph_queries')} == {
        k: v for k, v in new.items() if k not in ('version', 'routing_graph_queries')}
payload = dict(kind='held_host_transaction_cpu_qualification_v1', parent_commit=PARENT,
    parent_runner_sha256=hashlib.sha256(source.encode()).hexdigest(),
    candidate_runner_sha256=hashlib.sha256((ROOT/'scripts/run_all_experiments.py').read_bytes()).hexdigest(),
    gpu_performance_qualified=False, numerical_full_pool_qualified=False, rows=rows)
with (RAW/'probe1.json').open('x') as out:
    json.dump(payload, out, indent=2, allow_nan=False)
    out.write('\n')
with (RAW/'probe1.csv').open('x', newline='') as out:
    writer = csv.DictWriter(out, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps(payload, indent=2))
