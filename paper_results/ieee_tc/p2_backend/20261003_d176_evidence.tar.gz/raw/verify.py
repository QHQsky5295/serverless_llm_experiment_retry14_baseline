"""Reuse D174's bounded curation/seal/bundle; never rerun completed tests."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal

RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
BASE = '95de3c348a59529cfe57ea5aa2501cdb9e534372'
PLAN = '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
V1 = '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert check_plan() == PLAN
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == V1
changed = subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
allowed = {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md',
           'scripts/run_all_experiments.py','tests/test_ieee_tc_request_lifecycle.py'}
assert set(changed) <= allowed
runner = ROOT/'scripts/run_all_experiments.py'
before = ast.parse(subprocess.check_output(['git','show',BASE+':scripts/run_all_experiments.py'],cwd=ROOT,text=True))
after = ast.parse(runner.read_text())
names = {'_acquire_runtime_gpu_reference','_ieee_prepare_selected_adapter'}
original = {n.name:n for n in ast.walk(before) if isinstance(n,ast.AsyncFunctionDef) and n.name in names}
class Restore(ast.NodeTransformer):
    count = 0
    def visit_AsyncFunctionDef(self, node):
        if node.name in names:
            assert ast.dump(node) != ast.dump(original[node.name])
            self.count += 1
            return original[node.name]
        return self.generic_visit(node)
restore = Restore()
after = restore.visit(after)
assert restore.count == 2 and ast.dump(before) == ast.dump(after), 'non-target serving structure changed'
unchanged = ('faaslora/memory/gpu_monitor.py','faaslora/experiment/instance_pool.py',
             'faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py')
for rel in unchanged:
    assert (ROOT/rel).read_bytes() == subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT)
probe = json.loads((RAW/'probe1.json').read_text())
assert probe['parent_commit'] == BASE and probe['candidate_runner_sha256'] == digest(runner)
assert probe['gpu_performance_qualified'] is False and probe['numerical_full_pool_qualified'] is False
rows = probe['rows']
assert len(rows) == 8
for old,new in zip(rows[::2],rows[1::2]):
    expected = 1 if old['tier'] == 'host' else 0
    assert old['routing_graph_queries'] - new['routing_graph_queries'] == expected
    assert old['success'] and new['success'] and old['dispatch_tier'] == new['dispatch_tier']
    assert {k:v for k,v in old.items() if k not in ('version','routing_graph_queries')} == {
        k:v for k,v in new.items() if k not in ('version','routing_graph_queries')}
for phase,count in (('tests1',45),('regression1',947)):
    log = (RAW/f'{phase}.log').read_text()
    assert f'Ran {count} tests' in log and log.rstrip().endswith('OK')
cleanup = []
for phase in ('tests1','regression1','probe1'):
    for line in (RAW/f'{phase}_sources.sha256').read_text().splitlines():
        sha,path = line.split(maxsplit=1)
        assert digest(ROOT/path) == sha
    actual = re.search(r'^InvocationID=([a-f0-9]{32})$',(RAW/f'{phase}_scope.txt').read_text(),re.M)[1]
    state = subprocess.check_output(['systemctl','--user','show',f'primelora-d176-{phase}-20261003.scope',
        '-p','ActiveState','-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines() == ['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert all(int(line.split()[1]) == 0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text()) == 0
    assert 'Exit status: 0' in (RAW/f'{phase}_time.txt').read_text()
    cleanup.append(dict(phase=phase,actual_invocation_id=actual,returncode=0,
        cleanup='automatic_removal_verified',final_memory_events_zero=True,final_swap_zero=True))
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
doc = ROOT/'docs/ieee_tc/D176_HELD_HOST_COPY_TRANSACTION.md'
for old,new in zip(rows[::2],rows[1::2]):
    assert f"| {old['tier']} | {old['routing_graph_queries']} | {new['routing_graph_queries']} | 1 / 1 | 0 / 0 |" in doc.read_text()
with (RAW/'cleanup_verified.json').open('x') as out: json.dump(cleanup,out,indent=2)
table = OUT/'20261003_d176_held_host_transaction.csv'
with (RAW/'probe1.csv').open() as stream: assert len(list(csv.DictReader(stream))) == 8
with table.open('xb') as out: out.write((RAW/'probe1.csv').read_bytes())
curated = OUT/'20261003_d176_held_host_transaction.json'
refs = [runner, ROOT/'tests/test_ieee_tc_request_lifecycle.py', RAW/'probe1.json', RAW/'probe.py']
with curated.open('x') as out:
    json.dump(dict(kind='held_host_transaction_qualification_v1',base_commit=BASE,
        metric_protocol_sha256=V1,plan_sha256=PLAN,probe=probe,cleanup=cleanup,
        source_sha256={str(p):digest(p) for p in refs},tests_targeted=45,tests_regression=947,
        test_counts_overlap=True,failed_test_attempts_preserved=0,no_new_gpu_run=True,
        end_to_end_improvement_qualified=False,n_correct=None,formal_g1_g2_qualified=False,
        common_reference_frozen=False,table_sha256=digest(table),document_sha256=digest(doc)),out,indent=2)
for path in RAW.glob('*.py'): ast.parse(path.read_text())
verification = OUT/'20261003_d176_verification.json'
with verification.open('x') as out:
    json.dump(dict(passed=True,base_commit=BASE,non_target_serving_ast_unchanged=True,
        byte_identical_files=unchanged,tests_passed=dict(targeted=45,regression=947),protected=protected,
        cleanup=cleanup,curated_sha256=digest(curated),table_sha256=digest(table),document_sha256=digest(doc)),out,indent=2)
members = sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size < 2*1024**2
                 and not p.name.startswith('verify1') and p.suffix != '.lock')
extras = [doc,curated,verification,table,runner,ROOT/'tests/test_ieee_tc_request_lifecycle.py']
hashes = {}
bundle = OUT/'20261003_d176_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for path in members+extras:
        name = 'raw/'+str(path.relative_to(RAW)) if path in members else str(path.relative_to(ROOT))
        hashes[name] = digest(path)
        tar.add(path,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames()) == set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == sha
with (OUT/'20261003_d176_evidence_members.json').open('x') as out:
    json.dump(dict(passed=True,member_sha256=hashes,source_raw_retained_and_bound=True),out,indent=2)
with (OUT/'20261003_d176_evidence.sha256').open('x') as out: out.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    members=len(hashes),bundle_bytes=bundle.stat().st_size,cleanup=cleanup),indent=2))
