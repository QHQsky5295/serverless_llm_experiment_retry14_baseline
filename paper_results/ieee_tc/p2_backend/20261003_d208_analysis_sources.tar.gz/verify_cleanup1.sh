#!/usr/bin/env bash
# Read-only exact recorded service absence; does not stop any process.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
attempt=1
aux=primelora-tc-aux-e03a7ae7d7234f4aa3edacbb8a73a234.scope
raw=results/ieee_tc/p2_backend_qualification/d208_20261003
launch="$raw/arithmetic1_launch.json"
{
date -Is
test "$(jq -r '.service_path_removed' "$launch")" = true
test "$(jq -r '.native_gpu_context_release_confirmed' "$launch")" = true
unit=$(jq -r '.service_identity.unit' "$launch")
invocation=$(jq -r '.service_identity.invocation_id' "$launch")
[[ "$unit" =~ ^primelora-tc-svc-[a-f0-9]{32}\.scope$ ]]
[[ "$invocation" =~ ^[a-f0-9]{32}$ ]]
for u in "$unit" "$aux"; do
  test "$(systemctl --user show "$u" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$u" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$u"
  systemctl --user show "$u" -p Id -p ActiveState -p InvocationID -p ControlGroup
done
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
printf 'recorded_service_invocation=%s\ncleanup=automatic_removal_verified\n' "$invocation"
} | tee "$raw/arithmetic1_cleanup.txt"

