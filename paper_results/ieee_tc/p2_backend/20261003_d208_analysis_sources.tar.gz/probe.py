"""Independent coordinate oracle for the installed native LoRA operators.

No model/serving imports except native operators; no generated adapter files.
Diagnostic-only coordinate inputs are not an inference trace or performance run.
"""
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.ieee_tc_preflight import verify_current_service


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    output = RAW / 'arithmetic1.json'
    rows_path = RAW / 'arithmetic1_rows.jsonl'
    assert not output.exists() and not rows_path.exists()
    result = dict(kind='d208_coordinate_arithmetic_v1', passed=False,
                  performance_sample=False, n_correct=None,
                  arbitrary_input_numeric_qualified=False,
                  full_pool_qualified=False, formal_g1_g2_qualified=False,
                  service=verify_current_service(), source_sha256=sha(__file__))
    started = time.monotonic()
    try:
        import torch
        import vllm
        from safetensors import safe_open
        from vllm.lora.ops.triton_ops import LoRAKernelMeta, lora_shrink, lora_expand
        from vllm.lora.ops.triton_ops.utils import _LORA_A_PTR_DICT, _LORA_B_PTR_DICT

        assert vllm.__version__ == '0.30.0'
        assert torch.cuda.get_device_capability(0) == (8, 6)
        torch.cuda.set_device(0)
        result['environment'] = dict(torch=torch.__version__, vllm=vllm.__version__,
            cuda=torch.version.cuda, gpu=torch.cuda.get_device_name(0), pid=os.getpid())
        prior = json.loads((ROOT/'paper_results/ieee_tc/p2_backend/20261002_d167_checkpoint_slot_content.json').read_text())
        pool = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
        names = ('finance_lora', 'medical_lora', 'writing_lora_0011', 'code_lora_0015')
        weights, configs = [], []
        result['inputs'] = {}
        for name in names:
            for filename in ('adapter_config.json', 'adapter_model.safetensors'):
                path = pool/name/filename
                value = sha(path)
                assert value == prior['sources'][str(path)]
                result['inputs'][str(path)] = value
            cfg = json.loads((pool/name/'adapter_config.json').read_text())
            assert cfg['r'] in (8, 16) and not cfg.get('use_rslora') and not cfg.get('use_dora')
            configs.append(cfg)
            with safe_open(pool/name/'adapter_model.safetensors', framework='pt', device='cpu') as handle:
                weights.append({key: handle.get_tensor(key).to(torch.float16) for key in handle.keys()})
        base = json.loads(Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf/config.json').read_text())
        assert base['hidden_size'] == 4096 and base['num_hidden_layers'] == 32
        result['native_sources'] = {}
        vroot = Path(vllm.__file__).parent
        for rel in ('lora/ops/triton_ops/lora_shrink_op.py', 'lora/ops/triton_ops/lora_expand_op.py',
                    'lora/ops/triton_ops/kernel_utils.py', 'lora/ops/triton_ops/lora_kernel_metadata.py',
                    'lora/punica_wrapper/punica_gpu.py'):
            result['native_sources'][str(vroot/rel)] = sha(vroot/rel)
        count = compared = negative_differences = 0
        controls = []
        with rows_path.open('x') as journal, torch.inference_mode():
            for layer in range(32):
                for modules in (('q_proj', 'k_proj', 'v_proj'), ('o_proj',)):
                    aa, bb = [], []
                    for module in modules:
                        a = torch.zeros((4, 64, 4096), dtype=torch.float16)
                        b = torch.zeros((4, 4096, 64), dtype=torch.float16)
                        for slot, (state, cfg) in enumerate(zip(weights, configs)):
                            key = f'base_model.model.model.layers.{layer}.self_attn.{module}'
                            av = state[key+'.lora_A.weight']
                            bv = state[key+'.lora_B.weight']
                            assert tuple(av.shape) == (cfg['r'], 4096)
                            assert tuple(bv.shape) == (4096, cfg['r'])
                            a[slot, :cfg['r']] = av
                            b[slot, :, :cfg['r']] = bv * (cfg['lora_alpha']/cfg['r'])
                        assert torch.isfinite(a).all() and torch.isfinite(b).all()
                        aa.append(a)
                        bb.append(b)
                    _LORA_A_PTR_DICT.clear()
                    _LORA_B_PTR_DICT.clear()
                    ag, bg = [x.cuda() for x in aa], [x.cuda() for x in bb]
                    for op in ('shrink', 'expand'):
                        coords = torch.tensor([i * 4095 // 15 for i in range(16)]) if op == 'shrink' else torch.arange(64)
                        dim = 4096 if op == 'shrink' else 64
                        n = len(coords) * 5
                        x0 = torch.zeros((n, dim), dtype=torch.float16 if op == 'shrink' else torch.float32)
                        x0[torch.arange(n), coords.repeat(5)] = 1
                        x = x0.cuda() if op == 'shrink' else x0.repeat(len(modules), 1, 1).cuda()
                        out = torch.zeros((len(modules), n, 64), dtype=torch.float32, device='cuda') if op == 'shrink' else torch.zeros((n, len(modules)*4096), dtype=torch.float16, device='cuda')
                        meta = LoRAKernelMeta.make(4, n, 'cuda')
                        patterns = ((0, 1, 2, 3, -1), (1, 0, 3, 2, -1))

                        def expected(pattern):
                            ref = torch.zeros_like(out, device='cpu')
                            for group, slot in enumerate(pattern):
                                if slot < 0:
                                    continue
                                span = slice(group*len(coords), (group+1)*len(coords))
                                for s in range(len(modules)):
                                    if op == 'shrink':
                                        ref[s, span] = aa[s][slot, :, coords].T.float()
                                    else:
                                        ref[span, s*4096:(s+1)*4096] = bb[s][slot, :, coords].T
                            return ref

                        def invoke():
                            out.zero_()
                            args = meta.meta_args(n, specialize_active_lora=False)
                            if op == 'shrink':
                                lora_shrink(x, ag, out, *args, 1.0)
                            else:
                                lora_expand(x, bg, out, *args, offset_start=0, add_inputs=True)

                        mapping = torch.tensor(patterns[0], dtype=torch.int32).repeat_interleave(len(coords)).cuda()
                        meta.prepare_tensors(mapping)
                        invoke()  # Compile before graph capture; not a timing sample.
                        torch.cuda.synchronize()
                        graph = torch.cuda.CUDAGraph()
                        with torch.cuda.graph(graph):
                            invoke()
                        for pi, pattern in enumerate(patterns):
                            mapping.copy_(torch.tensor(pattern, dtype=torch.int32).repeat_interleave(len(coords)).cuda())
                            meta.prepare_tensors(mapping)
                            ref = expected(pattern)
                            for mode in ('eager', 'cuda_graph_replay'):
                                invoke() if mode == 'eager' else graph.replay()
                                torch.cuda.synchronize()
                                actual = out.cpu()
                                mismatch = int(torch.count_nonzero(actual != ref))
                                record = dict(layer=layer, modules=list(modules), op=op,
                                    pattern=pi, mode=mode, elements=actual.numel(), mismatches=mismatch,
                                    max_abs_error=float((actual.float()-ref.float()).abs().max()),
                                    finite=bool(torch.isfinite(actual).all()),
                                    expected_sha256=hashlib.sha256(ref.numpy().tobytes()).hexdigest(),
                                    actual_sha256=hashlib.sha256(actual.numpy().tobytes()).hexdigest())
                                journal.write(json.dumps(record)+'\n')
                                journal.flush()
                                count += 1
                                compared += actual.numel()
                                assert record['finite'] and mismatch == 0, record
                            if pi == 0:
                                changed = int(torch.count_nonzero(ref != expected(patterns[1])))
                                nonzero = int(torch.count_nonzero(ref))
                                controls.append(dict(layer=layer, modules=list(modules), op=op,
                                    swapped_nonzero_adapter_differences=changed,
                                    base_substitution_differences=nonzero))
                                assert changed > 0 and nonzero > 0, controls[-1]
                                negative_differences += changed + nonzero
                        del graph, meta, x, out, mapping
                    del ag, bg
                print(f'completed layer {layer + 1}/32', flush=True)
        for path, value in result['inputs'].items():
            assert sha(path) == value
        result.update(passed=True, cases=count, elements_compared=compared,
                      negative_controls=controls, negative_difference_elements=negative_differences,
                      coordinate_arithmetic_qualified=True, rows_sha256=sha(rows_path))
    except BaseException as exc:
        result.update(error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
        if rows_path.exists():
            result['rows_sha256'] = sha(rows_path)
        raise
    finally:
        result['wall_seconds_diagnostic_not_latency'] = time.monotonic()-started
        with output.open('x') as handle:
            json.dump(result, handle, indent=2)
            handle.write('\n')


if __name__ == '__main__':
    main()
