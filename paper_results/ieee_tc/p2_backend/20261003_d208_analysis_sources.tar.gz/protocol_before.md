# D208 — 既有权重的 LoRA 算术坐标检查

执行前合同，2026-10-03。状态：待执行。只补底层数值证据，不修改生产
实现、九个公式、配置、共同 SLO 或 V1，也不重做 D166/D167/D207。

## 问题与独立期望值

D63 的完整模型 log-probability 容差同时接受了错误 adapter/base，不能识别
身份；D167 已证明 checkpoint→slot 内容，D207 已证明 22 请求真实执行映射。
剩余的独立问题是：安装的 LoRA shrink/expand 算子是否按所选槽内容计算。

参考 [vLLM v0.30.0 官方算子测试](https://github.com/vllm-project/vllm/blob/v0.30.0/tests/lora/test_punica_ops.py)
对 shrink/expand 分开验证的方法，不直接沿用其面向随机矩阵的宽容差。
令 e_j 为坐标向量，e_j A^T=A[:,j]^T，e_k B^T=B[:,k]^T。
0/1 与有限 FP16 权重的单项乘加在这些坐标输入上应精确恢复对应列，
因此比较直接读取的列，不采用事后可调概率容差。这是专门的代数测试，
不是将完整模型的 FP16 误差容差改为零，更不是宣称一般 matmul 精确。

## 预登记范围

- 四个已有内容类别：finance_lora、medical_lora、writing_lora_0011、
  code_lora_0015；来源 SHA 与 D167 相同，无新工件、权重或业务负载。
- 原 7B 32 层 q/k/v 合并布局及 o 投影，FP16，4 槽、rank padding 64。
- A 的每个输入维度中等距固定 16 个坐标，B 的全部 64 个 rank 坐标；
  涵盖原 rank 8/16 及零填充，不按输出挑选坐标。
- 每组包含四个不同槽和显式 no-LoRA 行；正常与交换 finance/medical
  映射两种。普通执行及同一 CUDA Graph 在元数据改变后的 replay 均检查。
- shrink 原生 FP32 中间量与 A 列比较；expand 的 FP16 输出与已经按原
  alpha/r 缩放的 B 列比较。输出从零开始，只隔离 LoRA 项，不伪作基座输出。
- 正确列逐元素精确比较；同时列出 finance 与 medical、finance 与 base
  的独立参考差异数。零权重类别数值不可区分，不能据此识别其逻辑名字。
- 使用已有 gated-launch、共同 72/80 GiB/swap2 和独立 watchdog；单卡，
  无基座加载、远端操作、模型服务或全量回放。只在资格通过后再决定主线动作。

该检查不证明任意输入误差界、完整模型语义、所有 500 个逻辑 ID 或 4,000
请求的 n_correct，也不解释 D203 的 126 个输出 hash 差异。不得追改旧标记。
与 D167/D207 结合是分层资格证据，而非各自冒充完整性能验收。

按计划 §11/academic-plotting 使用正确性表。任何失败保留实际坐标、层、
模式和最大误差，不放松判据后重标通过；最多两轮有新依据的最小检查。
