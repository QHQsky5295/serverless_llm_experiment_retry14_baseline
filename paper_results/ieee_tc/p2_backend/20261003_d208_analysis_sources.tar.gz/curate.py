"""D207 sealing procedure reused for the bounded D208 operator result."""
import ast
import csv
import itertools
import json
import subprocess
import tarfile
from collections import defaultdict
from pathlib import Path
from scripts.ieee_tc_preflight import ROOT, check_plan, digest, verify_seal

raw = Path(__file__).resolve().parent
base = ROOT/'paper_results/ieee_tc/p2_backend'
prefix = '20261003_d208'
def load(path):
    assert path.stat().st_size < 4*1024**2
    return json.loads(path.read_text())
data = load(raw/'arithmetic1.json')
launch = load(raw/'arithmetic1_launch.json')
assert data['passed'] and launch['pass']
assert launch['service_returncode'] == launch['watchdog_returncode'] == 0
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
identity = launch['service_identity']
assert not Path(identity['path']).exists()
for unit in (identity['unit'], 'primelora-tc-aux-e03a7ae7d7234f4aa3edacbb8a73a234.scope'):
    assert not subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','--value'], text=True).strip()
assert not Path('/proc'/Path(str(data['service']['pid']))).exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
assert 'cleanup=automatic_removal_verified' in (raw/'arithmetic1_cleanup.txt').read_text()
assert digest(raw/'arithmetic1_rows.jsonl') == data['rows_sha256']
assert digest(raw/'probe.py') == data['source_sha256']
refs = {}
for line in (raw/'arithmetic1_sources.sha256').read_text().splitlines():
    expected, name = line.split(maxsplit=1)
    path = Path(name)
    if name == 'docs/ieee_tc/D208_LORA_COORDINATE_ARITHMETIC.md':
        path = raw/'protocol_before.md'
    elif not path.is_absolute():
        path = ROOT/path
    assert digest(path) == expected, str(path)
    refs[str(path)] = expected
for name, expected in {**data['inputs'], **data['native_sources']}.items():
    assert digest(Path(name)) == expected
    refs[name] = expected
rows = [json.loads(line) for line in (raw/'arithmetic1_rows.jsonl').read_text().splitlines()]
keys = [(r['layer'], tuple(r['modules']), r['op'], r['pattern'], r['mode']) for r in rows]
expected_keys = set(itertools.product(range(32), (('q_proj','k_proj','v_proj'),('o_proj',)),
                   ('shrink','expand'), (0,1), ('eager','cuda_graph_replay')))
assert len(keys) == len(set(keys)) == 512 and set(keys) == expected_keys
assert all(r['finite'] and r['mismatches'] == r['max_abs_error'] == 0 for r in rows)
assert sum(r['elements'] for r in rows) == data['elements_compared'] == 673710080
assert len(data['negative_controls']) == 128
assert all(r['swapped_nonzero_adapter_differences'] > 0 and r['base_substitution_differences'] > 0
           for r in data['negative_controls'])
grouped = defaultdict(lambda: dict(cases=0, elements=0, mismatches=0, max_abs_error=0.0))
for row in rows:
    g = grouped[(row['op'], row['mode'])]
    g['cases'] += 1
    g['elements'] += row['elements']
table = [dict(op=k[0], mode=k[1], **v) for k,v in sorted(grouped.items())]
samples = []
with (raw/'arithmetic1_launch.launch/watchdog.jsonl').open() as handle:
    for line in handle:
        row = json.loads(line)
        if row['event'] == 'resource_sample':
            samples.append(row)
assert samples and all(not s['decision']['abort_reasons'] for s in samples)
compute = [p for s in samples for d in s['gpu']['devices'] for p in d['processes'] if p['kind']=='compute']
assert compute and all(p['pid']==data['service']['pid'] and p['service_member'] for p in compute)
assert all(p['identity']['affinity']==list(range(4,24))+list(range(28,48)) for p in compute)
assert all(not s['service']['memory.swap.current'] and not any(s['service']['memory.events'].values()) for s in samples)
resource = dict(samples=len(samples), peak_memory_bytes=max(s['service']['memory.peak'] for s in samples),
    min_host_available_bytes=min(s['host']['available_bytes'] for s in samples),
    guard_events=0, swap_bytes=0, released=True, worker_pid=data['service']['pid'])
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
v1 = ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
assert digest(v1) == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protection = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protection['pass'] and protection['entry_count'] == 147
runtime_changes = subprocess.check_output(['git','diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc'], text=True).strip()
assert not runtime_changes
for path in raw.glob('*.py'):
    ast.parse(path.read_text())
for name in ('run_gpu1.sh','verify_cleanup1.sh','run_cpu.sh'):
    subprocess.run(['bash','-n',str(raw/name)],check=True)
doc=ROOT/'docs/ieee_tc/D208_LORA_COORDINATE_ARITHMETIC.md'
for path in (raw/'arithmetic1.json',raw/'arithmetic1_launch.json',raw/'arithmetic1_rows.jsonl',doc):
    refs[str(path)] = digest(path)
summary=dict(kind='d208_coordinate_arithmetic_curated_v1',passed=True,table=table,
    cases=512, layers=32, content_classes=4, coordinate_arithmetic_qualified=True,
    numerical_scope='isolated coordinate shrink/expand only; no arbitrary-input/full-model guarantee',
    negative_controls=data['negative_controls'],resource=resource,
    n_correct=None, full_pool_qualified=False, formal_g1_g2_qualified=False, performance_sample=False,
    sources=refs, parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    plan_sha256=check_plan(),metric_protocol_sha256=digest(v1),protected=protection)
with (base/f'{prefix}_coordinate_arithmetic.json').open('x') as handle:
    json.dump(summary,handle,indent=2,allow_nan=False);handle.write('\n')
with (base/f'{prefix}_coordinate_arithmetic.csv').open('x',newline='') as handle:
    writer=csv.DictWriter(handle,fieldnames=list(table[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(table)
members=[(p,p.relative_to(raw).as_posix()) for p in raw.rglob('*') if p.is_file()
         and not p.name.startswith('curate1')]
members.append((doc,'D208_LORA_COORDINATE_ARITHMETIC.md'))
native_root=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages')
members.extend((Path(p),'installed_source/'+Path(p).relative_to(native_root).as_posix()) for p in data['native_sources'])
bundle=base/f'{prefix}_analysis_sources.tar.gz'
manifest=[]
with tarfile.open(bundle,'x:gz') as archive:
    for path,name in sorted(members,key=lambda item:item[1]):
        assert path.stat().st_size < 4*1024**2
        archive.add(path,arcname=name,recursive=False)
        manifest.append(dict(name=name,size=path.stat().st_size,sha256=digest(path)))
with tarfile.open(bundle,'r:gz') as archive:
    for row in manifest:
        import hashlib
        assert hashlib.sha256(archive.extractfile(row['name']).read()).hexdigest()==row['sha256']
with (base/f'{prefix}_analysis_sources.sha256').open('x') as handle:
    handle.write(f'{digest(bundle)}  {bundle.name}\n')
with (base/f'{prefix}_analysis_sources_members.json').open('x') as handle:
    json.dump(manifest,handle,indent=2);handle.write('\n')
print(json.dumps(dict(passed=True,table=table,resource=resource,bundle_sha256=digest(bundle),members=len(manifest)),indent=2))
