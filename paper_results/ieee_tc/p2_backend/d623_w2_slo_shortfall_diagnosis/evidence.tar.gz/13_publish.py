"""Reuse D612's explicit-path, checked diagnostic publication procedure."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/publish.py')
code=source.read_text()
changes={
    'd612_w2_quality_resource_diagnosis':'d623_w2_slo_shortfall_diagnosis',
    'f72091155cd3bb258651fc461db11b9113c72faf':'9de424ee19864741e82d8a66a1d3ef26f8169360',
    "diagnosis['runs']['D607']['all']['joint']==3762":"diagnosis['runs']['D615']['all']['joint']==3817",
    "diagnosis['runs']['D611']['all']['joint']==3819":"diagnosis['runs']['D621']['all']['joint']==3798",
    'D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md':'D623_W2_SLO_SHORTFALL_DIAGNOSIS.md',
    "RAW.parent/'d607_20261017/publish_result.py'":
        "RAW.parent/'d612_20261017/diagnose.py',RAW.parent/'d612_20261017/publish.py'",
    'd612_reused_parent_closed_log_diagnosis_v1':'d623_reused_closed_w2_slo_diagnosis_v1',
    'tc: preserve post-SLO resource gap diagnosis without another replay (D612)':
        'tc: explain retained W2 SLO shortfall using matched request evidence (D623)',
}
for before,after in changes.items():
    assert code.count(before)==1,before
    code=code.replace(before,after)
exec(compile(code,str(source),'exec'))
