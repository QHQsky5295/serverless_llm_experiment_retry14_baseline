"""Reuse D612's sealed-source streaming diagnosis on D615 and D621 W2.

No performance run, input generation, threshold change or causal-effect claim.
Adds exact rotation100 bins separately from 500-request reporting windows.
"""
from pathlib import Path

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/diagnose.py')
code=source.read_text()
start=code.index('# Reuse the sealed D608 parent projection;')
end=code.index('    folder=RAW.parent/dirname',start)
code=code[:start]+"""runs={}
projections={}
for name,dirname,tag in [('D615','d615_20261017','7b_three_replica_full_w2'),
                         ('D621','d621_20261017','7b_device_domain_full_w2')]:
"""+code[end:]
changes={
    '20261017_d611_7b_inventory_extent_full_w2.yaml':'20261017_d621_7b_device_domain_full_w2.yaml',
    "'D607'":"'D615'",
    "'D611'":"'D621'",
    'd612_w2_residual_and_holding_v1':'d623_w2_slo_shortfall_and_holding_v1',
    "stages_ms=st['stages_ms'],dominant_ttft_stage=max(ttft_stages,key=ttft_stages.get))":
        """stages_ms=st['stages_ms'],dominant_ttft_stage=max(ttft_stages,key=ttft_stages.get),
                prompt_sha256=r['canonical_prompt_sha256'],generation_contract=r['generation_contract'],
                token_source=r['completion_token_source'],output_sha256=r['completion_token_ids_sha256'])""",
    "for key in ('request_id','source_index','adapter_id','arrival_s','target','prompt_tokens'):":
        "for key in ('request_id','source_index','adapter_id','arrival_s','target','prompt_tokens','prompt_sha256','generation_contract','token_source'):",
    "    projections[name]=projected":
        """    runs[name]['rotation100_phases']=[dict(index=i//100,
        **summarize(rows[i:i+100])) for i in range(0,4000,100)]
    runs[name]['reporting_windows_500']=[dict(index=i//500,
        **summarize(rows[i:i+500])) for i in range(0,4000,500)]
    classes={'TTFT_only':[r for r in rows if not r['ttft_good'] and r['tpot_good']],
             'TPOT_only':[r for r in rows if r['ttft_good'] and not r['tpot_good']],
             'both':[r for r in rows if not r['ttft_good'] and not r['tpot_good']]}
    runs[name]['violation_classes']={k:summarize(v) for k,v in classes.items()}
    assert sum(len(v) for v in classes.values())==len(bad)
    intervals=sorted((a['trigger_at']-t0,a['engine_ready_at']-t0) for a in acts
                     if a['category']=='natural_scaleout')
    union=[]
    for a,b in intervals:
        if not union or a>union[-1][1]: union.append([a,b])
        else: union[-1][1]=max(union[-1][1],b)
    for r in rows:
        r['scaleout_overlap_before_first_ms']=1000*sum(overlap(r['arrival_s'],
            r['arrival_s']+r['ttft_ms']/1000,a,b) for a,b in union)
    runs[name]['scaleout_overlap_conditional']={
        'overlap':summarize([r for r in rows if r['scaleout_overlap_before_first_ms']>0]),
        'no_overlap':summarize([r for r in rows if r['scaleout_overlap_before_first_ms']==0]),
        'bad_overlap':summarize([r for r in bad if r['scaleout_overlap_before_first_ms']>0]),
        'bad_no_overlap':summarize([r for r in bad if r['scaleout_overlap_before_first_ms']==0]),
        'caveat':'Observed temporal overlap, not counterfactual startup causation.'}
    runs[name]['ttft_margin_violation_counts_ms']={str(cut):sum(
        0<r['ttft_ms']-r['ttft_limit_ms']<=cut for r in rows) for cut in (1,10,100,500,1000)}
    projections[name]=projected""",
    "matched_transitions=changes,control_limits=limits,source_refs=refs,":
        """matched_transitions=changes,control_limits=limits,source_refs=refs,
    same_backend_output_hash_changes=sum(projections['D615'][rid]['output_sha256']!=
        projections['D621'][rid]['output_sha256'] for rid in projections['D615']),
    phase_definition='rotation100 is 40 fixed input-order bins; reporting_windows_500 is descriptive only',""",
}
for before,after in changes.items():
    assert before in code,before
    code=code.replace(before,after)
exec(compile(code,str(source),'exec'))
