#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d143_20261001
unit=primelora-d143-cpu-collection-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test "$(systemctl --user show primelora-tc-svc-35d671eb99a34407aaa05d676b41a08d.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show primelora-tc-aux-11f02aa273744fa3822b7dea9733e03a.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/cpu_collection_scope.txt"
/usr/bin/python3 "$raw/test_cpu_collection.py" > "$raw/cpu_collection_test.log" 2>&1
exec /usr/bin/time -v -o "$raw/cpu_collection_time.txt" /usr/bin/python3 "$raw/collect_prefix1_cpu.py" > "$raw/cpu_collection.log" 2>&1
