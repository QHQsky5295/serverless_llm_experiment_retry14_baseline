"""Existing curator's bounded terminal/resource/remote checks, before full projection."""
import collections
import json
import subprocess
from pathlib import Path

raw = Path(__file__).resolve().parent
# Adapted from D118 Full11; NORMAL outcome only, after terminal/cleanup.
# Prepared during D143 replay, not executed. Failed requests are retained.
assert subprocess.check_output([
    'systemctl', '--user', 'show',
    'primelora-tc-svc-35d671eb99a34407aaa05d676b41a08d.scope',
    '-p', 'ActiveState', '--value'], text=True).strip() == 'inactive'
assert not subprocess.check_output([
    'nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'],
    text=True).strip()
e = raw / '7b_full_w0_prefix1/launch.launch'
outcome_path = e / 'physical_deployment/main_outcome.json'
# Same complete metadata, with ASCII line indentation removed by the guarded
# launcher. Every field remains; original bytes and numeric lexemes preserved.
compact_outcome_path = raw / 'prefix1_main_outcome_compact.json'
assert 0 < compact_outcome_path.stat().st_size < 128 * 1024**2, 'not bounded normal metadata'
subprocess.run(['sha256sum', '-c', str(raw / 'prefix1_metadata_compaction.sha256')], check=True)
x = json.loads(compact_outcome_path.read_text())
launch = json.loads((e.parent / 'launch.json').read_text())
assert launch['pass'] and launch['service_returncode'] == launch['replay_returncode'] == launch['watchdog_returncode'] == 0
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
p = json.loads((e / 'physical_deployment/summary.json').read_text())
rows = [json.loads(line) for line in (e / 'physical_deployment/request_terminals.jsonl').open()]
remote = [json.loads(line) for line in (raw / 'remote_7b_prefix1_transfers.jsonl').open()]
health = json.loads((raw / 'health_7b.json').read_text())
assert health['clock_id'] == 'remote-process-monotonic:7ea05c3d766348c187c75532b68ad9c4'
t = x['remote_transfers']
by = {r['transfer_id']: r for r in remote}
assert len(rows) == len({r['request_id'] for r in rows}) == 1000
assert len(by) == len(remote) == len(t) > 0
assert set(by) == {r['http_transfer_id'] for r in t}
for r in t:
    peer = by[r['http_transfer_id']]
    assert peer['artifact_id'] == r['artifact_id']
    assert peer['clock_id'] == health['clock_id']
    assert not peer['pack_performed'] and not peer['temporary_created']
    if r['state'] == 'published':
        assert peer['bytes_written'] == r['transferred_bytes']
        assert r['content_verified'] and r['published_archive_verified']
        assert r['payload_bytes_verified'] == r['payload_bytes_expected']
    else:
        assert r['state'] == 'not_published' and r['content_verified'] is False
        assert 0 <= r['transferred_bytes'] <= peer['bytes_written']
        assert 'payload_bytes_verified' not in r or r['payload_bytes_verified'] is None
assert x['run_completed'] and x['error'] is None and x['cleanup']['complete']
assert not x['formal_comparison_qualified']
assert not x['cleanup_errors'] and not x['measurement_errors'] and not x['interrupted_replays']
assert all(not Path(r['path']).exists() for r in x['cleanup']['roots'])
assert all(r['released'] for r in p['allocation_journals']) and not p['open_lease_ids']
assert p['measurement_complete'] and not p['eligible_correctness']
resources = dict(samples=0, peak_bytes=0, min_host_available_bytes=2**63,
                 events={}, max_swap_bytes=0, warnings=0)
for line in (e / 'watchdog.jsonl').open():
    r = json.loads(line)
    if r['event'] != 'resource_sample':
        continue
    resources['samples'] += 1
    assert not r['decision']['abort_reasons']
    resources['warnings'] += r['decision']['warning']
    resources['peak_bytes'] = max(resources['peak_bytes'], r['service']['memory.peak'])
    resources['min_host_available_bytes'] = min(resources['min_host_available_bytes'], r['host']['available_bytes'])
    resources['max_swap_bytes'] = max(resources['max_swap_bytes'], r['service']['memory.swap.current'])
    for k in ('high', 'max', 'oom', 'oom_kill'):
        resources['events'][k] = max(resources['events'].get(k, 0), r['service']['memory.events'].get(k, 0))
q = x['mechanism_events']['_ieee_runtime_quarantine_events']
first_four = sorted(x['mechanism_events']['_ieee_activations'], key=lambda r: r['trigger_at'])[:4]
initial = {r['target_replica'] for r in first_four}
assert len(initial) == 4
success = [r for r in rows if r['success']]
assert all(r['native_contract_matched'] for r in success)
assert len(success) <= len(rows)  # Never require or invent successful completion.
replacements = [r for r in success if r['instance_id'] not in initial]
result = dict(kind='d143_prefix1_preliminary_postcleanup_v1', formal_performance_result=False,
    full_qualified=False, source_workload_count=4000, diagnostic_prefix_count=1000,
    population=dict(planned=1000, terminal=len(rows), success=len(success),
        native_contract_matched=sum(r['native_contract_matched'] for r in rows),
        failure_terminal_types=dict(collections.Counter(str(r.get('error_type')) for r in rows if not r['success']))),
    physical_gpu_seconds=p['gpu_seconds'], window_gpu_seconds=p['window_gpu_seconds'],
    allocations=len(p['allocation_journals']), released=len(p['allocation_journals']), resources=resources,
    remote=dict(uuid_pairs=len(t), client_received_bytes=sum(r['transferred_bytes'] for r in t),
        server_socket_written_bytes=sum(r['bytes_written'] for r in remote),
        byte_mismatches=[dict(http_transfer_id=r['http_transfer_id'],artifact_id=r['artifact_id'],
            state=r['state'],client_received_bytes=r['transferred_bytes'],
            server_socket_written_bytes=by[r['http_transfer_id']]['bytes_written']) for r in t
            if r['transferred_bytes'] != by[r['http_transfer_id']]['bytes_written']],
        verified_published_logical_bytes=sum(r['payload_bytes_verified'] for r in t if r['state'] == 'published'),
        states=dict(collections.Counter(r['state'] for r in t)), request_packing=0,
        not_published=[dict(fields={k:r[k] for k in ('artifact_id','http_transfer_id','state','transferred_bytes',
            'content_verified','published_archive_verified','payload_bytes_expected','payload_bytes_verified') if k in r},
            payload_bytes_verified_field_present='payload_bytes_verified' in r) for r in t if r['state'] != 'published'],
        clock_ids=sorted({r['clock_id'] for r in remote})),
    first_four_runtime_successes=len(success)-len(replacements), replacement_successes=len(replacements),
    replacement_successful_runtimes=len({r['instance_id'] for r in replacements}),
    source_stats=x['mechanism_events']['_ieee_source_observation_stats'], first_four_activation_categories=dict(collections.Counter(r['category'] for r in first_four)),
    quarantine_events=len(q),
    quarantine_first=q[0] if q else None, quarantine_last=q[-1] if q else None,
    quarantine_keys=sorted({k for r in q for k in r}),
    quarantine_states=dict(collections.Counter(r.get('state') for r in q)))
result['execution_completed'] = x['run_completed']
result['launch_pass'] = launch['pass']
result['native_contract_all_requests_complete'] = len(success) == len(rows) == 1000
result['qualification_caveat'] = ('Native token checks do not establish numerical adapter correctness or formal SLO; '
    'request failures remain in the planned denominator. No formal ranking.')
result['cleanup'] = {k:x['cleanup'][k] for k in ('complete','reason','roots') if k in x['cleanup']}
result['mechanism_counts'] = {k:dict(collections.Counter(r.get('state','not_a_state_event') for r in v))
                            for k,v in x['mechanism_events'].items() if isinstance(v,list)}
for key in ('_ieee_residency_epochs','_ieee_file_preparation_plans','_ieee_gpu_preparation_plans'):
    assert result['mechanism_counts'][key].get('failed',0) == 0, key
sources = list((raw/'7b_outputs_prefix1').glob('experiment_results_full_vllm_dedicated_a500_r1000_c*_tc_ieee_full_d143_7b_full_w0_prefix1.json'))
assert len(sources) == 1
source_stat = sources[0].stat()
assert source_stat.st_size > 0
result['normal_source_stat'] = dict(path=str(sources[0]), bytes=source_stat.st_size,
    mtime_ns=source_stat.st_mtime_ns, inode=source_stat.st_ino)
result['normal_outcome_bytes'] = outcome_path.stat().st_size
result['compact_outcome_bytes'] = compact_outcome_path.stat().st_size
result['metadata_transform'] = 'ASCII line indentation only; all values and line boundaries retained'
compaction_hashes = (raw / 'prefix1_metadata_compaction.sha256').read_text().splitlines()
assert len(compaction_hashes) == 2
result['metadata_source_sha256'] = compaction_hashes[0].split(maxsplit=1)[0]
result['metadata_compact_sha256'] = compaction_hashes[1].split(maxsplit=1)[0]
out = raw / 'prefix1_preliminary.json'
with out.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps(result, indent=2, allow_nan=False))
