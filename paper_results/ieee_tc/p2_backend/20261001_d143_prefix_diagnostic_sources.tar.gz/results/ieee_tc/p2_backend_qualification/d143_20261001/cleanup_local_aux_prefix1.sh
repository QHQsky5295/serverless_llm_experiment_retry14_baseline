#!/usr/bin/env bash
set -euo pipefail
# D140 exact-identity/empty-domain cleanup, bound to D143's observed identities.
date -Is
test "$(systemctl --user show primelora-tc-svc-35d671eb99a34407aaa05d676b41a08d.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-11f02aa273744fa3822b7dea9733e03a.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 7f6f44d06bb345b8bfb8cd5989f46b86
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-11f02aa273744fa3822b7dea9733e03a.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
