"""Small fixtures for D143's adaptation of the existing diagnostic collector."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('collector', Path(__file__).with_name('collect_prefix1_cpu.py'))
collector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(collector)


class CollectionTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.meta = Path(self.temp.name) / '10-20.json'
        self.meta.write_text(json.dumps(dict(kind='diagnostic_python_frames_v1', pid=10,
            start_ticks=20, parent_pid=1, cgroup='/fixture', main_thread_ident=1,
            capture_start_monotonic_s=0.0, gil_scheduling_bias=True, cpu_time_profile=False)))
        self.path = self.meta.with_suffix('.stacks.jsonl')

    def sample(self, index, at):
        return dict(event='python_frames', index=index, pid=10, observed_monotonic_s=at,
            scheduled_monotonic_s=at-0.25, interval_seconds=2.5, scheduler_delay_seconds=0.25,
            process_cpu_seconds=float(index), process_cpu_delta_seconds=1.0,
            observer_cpu_seconds_before_sample=0.001*(index-1), snapshot_wall_seconds=0.0001,
            observer_thread_ident=2, threads=[
                dict(ident=1, truncated=False, frames=[['/usr/lib/selectors.py','select',1],
                    [str(collector.ROOT/'scripts/run_all_experiments.py'),'main',2]]),
                dict(ident=2, truncated=False, frames=[['observer.py','observe',3]])])

    def save(self, rows, suffix=b''):
        self.path.write_bytes(b''.join((json.dumps(r)+'\n').encode() for r in rows)+suffix)

    def test_idle_occurrence_and_phase_denominators(self):
        self.save([self.sample(i, i*2.5) for i in range(1,4)])
        value=collector.collect_one(self.meta,3.,6.)
        self.assertEqual(value['samples'],3)
        self.assertEqual(value['role_evidence'],['controller'])
        self.assertEqual(value['main_phase_counts'],dict(pre_arrival=1,request_window=1,post_requests=1))
        self.assertEqual(value['leaf_frames'][0]['function'],'select')
        self.assertEqual(value['leaf_frames'][0]['samples'],3)
        self.assertEqual(value['request_window_nearest_project'][0]['samples'],1)
        self.assertAlmostEqual(value['observer_cpu_before_last_sample_s'],0.002)

    def test_final_partial_line_retained_as_missing(self):
        self.save([self.sample(1,2.5)],b'{"incomplete":')
        value=collector.collect_one(self.meta,1.,None)
        self.assertEqual(value['samples'],1)
        self.assertEqual(value['final_partial_line_bytes'],14)

    def test_missing_main_and_empty_file_not_zero_overhead(self):
        row=self.sample(1,2.5)
        row['threads']=row['threads'][1:]
        self.save([row])
        value=collector.collect_one(self.meta,1.,None)
        self.assertEqual(value['missing_main_samples'],1)
        self.assertEqual(value['leaf_frames'],[])
        self.assertEqual(value['role_evidence'],[])
        self.save([])
        value=collector.collect_one(self.meta,1.,None)
        self.assertIsNone(value['process_cpu_at_last_sample_s'])

    def test_invalid_record_fails(self):
        for field,bad in [('index',2),('pid',11),('process_cpu_seconds',float('nan')),
                          ('interval_seconds',1.0),('scheduler_delay_seconds',-1.)]:
            with self.subTest(field=field):
                row=self.sample(1,2.5)
                row[field]=bad
                self.save([row])
                with self.assertRaises(AssertionError):
                    collector.collect_one(self.meta,1.,None)

    def test_duplicate_sample_and_thread_fail(self):
        row=self.sample(1,2.5)
        self.save([row,row])
        with self.assertRaises(AssertionError):
            collector.collect_one(self.meta,1.,None)
        row['threads'].append(row['threads'][0])
        self.save([row])
        with self.assertRaises(AssertionError):
            collector.collect_one(self.meta,1.,None)

    def test_oversize_line_fails(self):
        self.path.write_bytes(b'x'*(1024*1024+1))
        with self.assertRaises(ValueError):
            list(collector.rows(self.path))


if __name__=='__main__':
    unittest.main(verbosity=2)
