"""D143 diagnostic closure using the existing qualification/seal workflow."""
import collections
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d143_20261001'
e = raw/'7b_full_w0_prefix1/launch.launch'
out = root/'paper_results/ieee_tc/p2_backend'
load = lambda p: json.loads(p.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == 'a494c90c017e5307ff59f1d9ff7c4dde214d6bbf'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for unit in ('primelora-tc-svc-35d671eb99a34407aaa05d676b41a08d.scope',
             'primelora-tc-aux-11f02aa273744fa3822b7dea9733e03a.scope',
             'primelora-d143-cpu-collection-20261001.scope',
             'primelora-d143-prefix1-metadata-20261001.scope'):
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
preflight = load(raw/'prelaunch_verification.json')
for name, sha in preflight['source_sha256'].items():
    assert digest(root/name) == sha, name
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert 'Ran 6 tests in 0.061s\n\nOK\n' in (raw/'cpu_collection_test.log').read_text()
for name in ('cpu_collection_time.txt','prefix1_metadata_time.txt'):
    assert 'Exit status: 0' in (raw/name).read_text()
for name in ('cpu_collection_cleanup.txt','prefix1_metadata_cleanup.txt','prefix1_aux_cleanup.txt'):
    events = {r.split()[0]:int(r.split()[1]) for r in (raw/name).read_text().splitlines()
              if r.startswith(('low ','high ','max ','oom ','oom_kill ','oom_group_kill '))}
    assert len(events)==6 and not any(events.values()), name
cpu = load(raw/'prefix1_cpu_samples.json')
preliminary = load(raw/'prefix1_preliminary.json')
assert digest(raw/'prefix1_cpu_samples.json') == '1f48bcc5b5ea6832bd913098656f18f27c057bffa3257c79b20459a2477509be'
assert digest(raw/'prefix1_preliminary.json') == '2094489d1c0464168351559502b96d02b4882380b6ead9c1ac1b813cb2123c91'
assert cpu['terminal_count']==cpu['terminal_successes']==1000 and cpu['terminal_failures']==0
assert len(cpu['processes'])==10
assert preliminary['native_contract_all_requests_complete'] and preliminary['cleanup']['complete']
assert not preliminary['full_qualified'] and not preliminary['formal_performance_result']
source = preliminary['normal_source_stat']
stat = Path(source['path']).stat()
assert (stat.st_size,stat.st_ino,stat.st_mtime_ns)==(source['bytes'],source['inode'],source['mtime_ns'])
assert abs(sum(preliminary['window_gpu_seconds'].values())-preliminary['physical_gpu_seconds']) < 1e-6
receipt=load(e/'exec_receipt.json')
t0=receipt['external_replay']['replay_t0_s']
terminals=[json.loads(line) for line in (e/'physical_deployment/request_terminals.jsonl').open()]
end=max(r['at'] for r in terminals)
callers=[]
for process in cpu['processes']:
    assert not any(process[k] for k in ('missing_main_samples','final_partial_line_bytes'))
    assert type(process['truncated_main_samples']) is int and 0 <= process['truncated_main_samples'] <= process['samples']
    for ref in process['source_refs']:
        assert digest(Path(ref['path'])) == ref['sha256']
    if process['role_evidence'] != ['gpu_core']:
        continue
    meta_path=Path(process['source_refs'][0]['path'])
    meta=load(meta_path)
    names=collections.Counter()
    sites=collections.Counter()
    host_inclusive=window=0
    for line in meta_path.with_suffix('.stacks.jsonl').open():
        row=json.loads(line)
        if not t0 <= row['observed_monotonic_s'] <= end:
            continue
        main=next(t for t in row['threads'] if t['ident']==meta['main_thread_ident'])
        frames=main['frames']
        window+=1
        host_inclusive+=any(f.endswith('/faaslora/memory/gpu_monitor.py') and n=='_ieee_lora_host_inventory'
                            for f,n,_ in frames)
        for i,(file,function,lineno) in enumerate(frames):
            if file.endswith('/faaslora/memory/gpu_monitor.py') and function=='add':
                assert i+1 < len(frames)
                names[frames[i+1][1]]+=1
                sites[lineno]+=1
    assert window==process['main_phase_counts']['request_window']
    # Same name also exists for GPU-pool inventory; retain any observed callers.
    callers.append(dict(pid=process['pid'],request_window_samples=window,
        host_inventory_inclusive_samples=host_inclusive,
        add_caller_counts=dict(names),add_source_line_counts=dict(sites)))
files=[root/'docs/ieee_tc/D143_PREFIX_DIAGNOSTIC_RESULTS.md']
files += [raw/name for name in (
    'collect_prefix1_cpu.py','test_cpu_collection.py','collect_prefix1_cpu.sh',
    'cpu_collection_test.log','cpu_collection.log','cpu_collection_time.txt','cpu_collection_scope.txt','cpu_collection_cleanup.txt',
    'collect_prefix1_preliminary.py','inspect_prefix1_metadata.sh','prefix1_metadata.log','prefix1_metadata_time.txt',
    'prefix1_metadata_scope.txt','prefix1_metadata_cleanup.txt','prefix1_metadata_compaction.sha256',
    'prefix1_cpu_samples.json','prefix1_preliminary.json','prelaunch_verification.json',
    '7b_main_config_prefix1.yaml','7b_main_config_prefix1_preflight_rejected.yaml',
    'prelaunch.log','prelaunch2.log','prelaunch_cleanup.txt','prelaunch2_cleanup.txt',
    'run_7b_full_w0_prefix1.sh','profile_controller_python.sh','controller_prefix1_time.txt',
    'stop_services_prefix1.sh','stop_remote_after_prefix1.sh','stop_services_prefix1.log',
    'cleanup_local_aux_prefix1.sh','prefix1_aux_cleanup.txt','copy_remote_prefix1.sh','remote_copy_receipt.txt',
    'remote_7b_prefix1_transfers.jsonl','health_7b.json','health_3b.json','remote_prelaunch.txt','local_nic.txt',
    'curate_prefix1.py','curate_prefix1.sh','curate_prefix1_attempt2.py','curate_prefix1_attempt2.sh',
    'prefix1_curation.log','prefix1_curation_scope.txt','prefix1_curation_time.txt','prefix1_curation_cleanup.txt')]
files += [e.parent/'launch.json',e/'exec_receipt.json',e/'physical_deployment/summary.json',
          e/'physical_deployment/deployment.json',e/'physical_deployment/request_terminals.jsonl']
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for path in files:
    assert path.stat().st_size < 2*1024**2, path
    payload=path.read_bytes()
    assert secret not in payload, path
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in payload.splitlines()),path
    if path.suffix=='.py': compile(payload,str(path),'exec')
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
large_refs=[dict(path=str(path),bytes=path.stat().st_size,sha256=digest(path)) for path in
    (e/'watchdog.jsonl',raw/'remote_monitor_prefix1_final.log',e/'physical_deployment/main_outcome.json')]
table=out/'20261001_d143_prefix_roles.csv'
with table.open('x',newline='') as stream:
    writer=csv.writer(stream)
    writer.writerow(['pid','role','all_samples','request_window_samples','max_sampling_delay_s','host_inventory_inclusive_samples','add_host_caller_samples'])
    by={row['pid']:row for row in callers}
    for row in cpu['processes']:
        role='frontend' if 'frontend' in row['role_evidence'] else row['role_evidence'][0]
        extra=by.get(row['pid'],{})
        writer.writerow([row['pid'],role,row['samples'],row['main_phase_counts']['request_window'],row['max_schedule_lag_s'],
            extra.get('host_inventory_inclusive_samples'),extra.get('add_caller_counts',{}).get('_ieee_lora_host_inventory')])
files.append(table)
result=dict(kind='d143_prefix_diagnostic_closure_v1',runtime_commit=preflight['runtime_source_commit'],
    formal_performance_result=False,full_qualification=False,latency_identity_audit_complete=False,
    full_raw_request_json_reparsed=False,first_curation_rejected_zero_truncation_assumption=True,source_count=4000,prefix_count=1000,
    protected=protected,prelaunch_refs_verified=len(preflight['source_sha256']),
    preliminary=preliminary,cpu=cpu,host_inventory_callers=callers,
    large_source_refs=large_refs,source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
curated=out/'20261001_d143_prefix_diagnostic.json'
with curated.open('x') as stream: json.dump(result,stream,indent=2,allow_nan=False)
files.append(curated)
bundle=out/'20261001_d143_prefix_diagnostic_sources.tar.gz'
with bundle.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for path in files: archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers())==len(files)
    for member,path in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==digest(path)
with (out/'20261001_d143_prefix_diagnostic_sources.sha256').open('x') as stream:
    stream.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,caller_counts=callers)))
