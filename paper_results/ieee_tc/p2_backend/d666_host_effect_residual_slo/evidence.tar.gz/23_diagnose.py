"""Adapt sealed D612 streaming diagnosis to the completed 3B D660 W0 only.

No new workload, inference, counterfactual latency or online parameter changes.
"""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/diagnose.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '5b9026f7fb88fdb1ccf52423ec18d3767fcfc4c0d4a1f4dd823e1cd6926c6306'
code = data.decode()

def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace('20261010_7b_slo_d394_frozen.json', '20261017_3b_slo_d648_frozen.json')
replace('2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3',
        'd15123570c4a8d830515ca942d1db553c6717ffc1a40ade5c1546d35e2bed9d8')
replace('20261017_d611_7b_inventory_extent_full_w2.yaml', '20261018_d660_3b_full_w0.yaml')
begin = code.index('# Reuse the sealed D608 parent projection;')
end = code.index('    folder=RAW.parent/dirname', begin)
code = code[:begin] + "runs={}\nprojections={}\nfor name,dirname,tag in [('D660','d660_20261018','3b_full_w0')]:\n" + code[end:]
replace("audit_path=folder/'actual_qualification.json'", "audit_path=ROOT/'paper_results/ieee_tc/p2_backend/d660_3b_full_w0/audit.json'\n    assert p.digest(audit_path)=='31e3a5c042961983fcbfd1bd926141e66b153aab892e1432c8914b1b086e89d9'")
replace("plan=FrozenReplayPlan.load(wi['source_path'],count=4000,profile='W2',\n        adapter_map=wi['adapter_map'],adapter_map_sha256=wi['adapter_map_sha256'])",
        "plan=FrozenReplayPlan.load(wi['source_path'],count=4000,profile='W0')")
replace("stages_ms=st['stages_ms'],dominant_ttft_stage=max(ttft_stages,key=ttft_stages.get))", """stages_ms=st['stages_ms'],dominant_ttft_stage=max(ttft_stages,key=ttft_stages.get),
                nested_routing_ms=st['nested_routing_ms'],
                native_timing={k:v for k,v in r['native_token_timing'].items()
                    if type(v) in (int,float,bool,str) or v is None},
                diagnostic_scalars={k:v for k,v in r.items()
                    if (type(v) in (int,float,bool) or v is None) and
                    any(label in k for label in ('load','prepar','admission','rpc','routing','control_path','runtime'))})""")
replace('    projections[name]=projected', """    runs[name]['reporting_windows_500']=[dict(index=i//500,**summarize(rows[i:i+500])) for i in range(0,4000,500)]
    classes={'TTFT_only':[r for r in rows if not r['ttft_good'] and r['tpot_good']],
             'TPOT_only':[r for r in rows if r['ttft_good'] and not r['tpot_good']],
             'both':[r for r in rows if not r['ttft_good'] and not r['tpot_good']],
             'good':[r for r in rows if r['joint']]}
    runs[name]['violation_classes']={k:summarize(v) for k,v in classes.items()}
    assert sum(len(v) for v in classes.values())==4000
    runs[name]['scalar_diagnostics']={k:{field:dict(n=sum(type(r['diagnostic_scalars'].get(field)) in (int,float) for r in members),
        mean=fmean(r['diagnostic_scalars'][field] for r in members if type(r['diagnostic_scalars'].get(field)) in (int,float)))
        for field in sorted(set().union(*(r['diagnostic_scalars'].keys() for r in members)))
        if any(type(r['diagnostic_scalars'].get(field)) in (int,float) for r in members)}
        for k,members in classes.items()}
    intervals=sorted((a['trigger_at']-t0,a['engine_ready_at']-t0) for a in acts if a['category']=='natural_scaleout')
    union=[]
    for a,b in intervals:
        if not union or a>union[-1][1]:union.append([a,b])
        else:union[-1][1]=max(union[-1][1],b)
    for r in rows:
        r['scaleout_overlap_before_first_ms']=1000*sum(overlap(r['arrival_s'],r['arrival_s']+r['ttft_ms']/1000,a,b) for a,b in union)
    runs[name]['scaleout_overlap_conditional']={key:summarize(members) for key,members in (
        ('overlap',[r for r in rows if r['scaleout_overlap_before_first_ms']>0]),
        ('no_overlap',[r for r in rows if r['scaleout_overlap_before_first_ms']==0]),
        ('bad_overlap',[r for r in bad if r['scaleout_overlap_before_first_ms']>0]),
        ('bad_no_overlap',[r for r in bad if r['scaleout_overlap_before_first_ms']==0]))}
    runs[name]['actual_scaleout_intervals_s']=intervals
    runs[name]['control_ttft_p95_summary_ms']={key:percentile([e['p95_ttft_ms'] for e in inwindow if e['p95_ttft_ms'] is not None],q)
        for key,q in [('min',0.0000001),('median',.5),('p95',.95)]}
    runs[name]['native_timing_fields']=sorted(rows[0]['native_timing'])
    projections[name]=projected""")
begin = code.index("assert runs['D607']['workload_identity']==runs['D611']['workload_identity']")
end = code.index('protected=p.verify_seal', begin)
code = code[:begin] + "assert runs['D660']['all']['joint']==3575\nchanges={}\nref(source)\n" + code[end:]
replace('d612_w2_residual_and_holding_v1', 'd661_3b_w0_residual_and_holding_v1')
replace('matched_transitions=changes,control_limits=limits,source_refs=refs,',
        'paired_request_comparison_performed=False,control_limits=limits,source_refs=refs,')
replace('Matched requests have fixed input but different realized system trajectories; no independent repeat or causal treatment estimate.',
        'Single completed 3B W0 reused for conditional diagnosis; no independent repeat, cross-system comparison or causal treatment estimate.')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('Sealed D612 source and explicit D660 adaptation AST passed; no data analyzed.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
