"""D662: partition retained D660 receipts; no inference or policy changes.

Reuse the existing preparation validator and D661 SLO projection. Boundaries
are observations, not RPC starts/ACK arrivals or counterfactual savings.
"""
import collections
import json
import math
import os
from pathlib import Path
from statistics import fmean
import subprocess
import sys
import ijson

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OLD = RAW.parent/'d661_20261018'
RUN = RAW.parent/'d660_20261018/3b_full_w0'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.analyze_d297_full import retained_preparation_row

def read(path): return json.loads(path.read_text())
def save(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2, allow_nan=False)
def describe(values):
    values = sorted(values)
    assert all(type(x) in (int, float) and math.isfinite(x) for x in values)
    return dict(n=len(values), mean=fmean(values) if values else None,
        p95_type1=values[math.ceil(.95*len(values))-1] if values else None,
        max=values[-1] if values else None)

identity = p.scope_identity(p.cg_path().name)
cg = Path(identity['path'])
save(RAW/'analysis_identity.json', identity)
assert (cg/'memory.high').read_text().strip() == str(3*p.GIB)
assert (cg/'memory.max').read_text().strip() == str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 24*1024*1024)
save(RAW/'resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
parent = read(OLD/'diagnosis.json')
assert p.digest(OLD/'diagnosis.json') == '518a1f265755445933db2277fd36b5b472a6a2c0767e99c3f47d59bb7db87d88'
oldpaths = read(OLD/'source_paths.json')
assert p.digest(OLD/'source_paths.json') == 'a8f24ee225ec610bf55e15b3a177569d760f9951ae1233a00d9a210dc85525a4'
projection = OLD/'d660_projection.json'
assert p.digest(projection) == oldpaths['projection_sha256']
rows_by_id = {r['request_id']:r for r in read(projection)}
assert len(rows_by_id) == 4000 and sum(r['joint'] for r in rows_by_id.values()) == 3575
refs = {r['path']:r['sha256'] for r in parent['source_refs']}
source = Path(oldpaths['source_path'])
assert p.digest(source) == oldpaths['source_sha256'] == refs[str(source)]
launch_path = RUN/'launch.json'
assert p.digest(launch_path) == refs[str(launch_path)]
launch = read(launch_path)
t0, clock = launch['external_replay']['replay_t0_s'], launch['external_replay']['clock_id']
assert launch['pass'] and launch['native_gpu_context_release_confirmed']
for name in ('analysis','analysis2','publication'):
    closure = read(OLD/(name+'_closure.json'))
    assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()

rows, examples, seen = [], {}, set()
with source.open('rb') as stream:
    for request in ijson.items(stream, 'detailed_results.tc_ieee_full.requests.item', use_float=True):
        rid = request['request_id']
        assert rid not in seen
        seen.add(rid)
        projected = rows_by_id[rid]
        prep = retained_preparation_row(request)
        e, timing = request['gpu_reference_evidence'], request['native_token_timing']
        admission, receipt = e['source_admission'], e['receipt']
        source_state = admission['source']
        assert prep['tier'] == projected['tier'] and type(source_state['native']) is bool
        key = prep['tier'] + ('::native' if source_state['native'] else '::file_or_remote')
        row = dict(request_id=rid, adapter_id=request['adapter_id'], path=key,
            joint=projected['joint'], ttft_good=projected['ttft_good'], tpot_good=projected['tpot_good'],
            ttft_ms=projected['ttft_ms'], tpot_ms=projected['tpot_ms'], preparation=prep,
            nested_routing_ms=projected['nested_routing_ms'], boundaries={}, spans_ms={}, errors=[])
        examples.setdefault(key, dict(pending=e.get('pending_kv_admission'), host=e.get('native_host_source'),
            acquisition=receipt, source_admission=admission,
            prior_routing_attempts=e.get('prior_routing_attempts')))
        if key in ('host::native','gpu::native'):
            try:
                pending = e['pending_kv_admission']['receipt']
                assert pending['clock_id'] == clock == timing['native_clock_id']
                assert pending['scheduler_owner_id'] == receipt['owner_id']
                b = dict(resume=t0+request['arrival_released_offset_s']+request['dispatch_window_wait_ms']/1000,
                    pending_observed=pending['observed_at'], admitted=admission['admitted_monotonic_s'],
                    acquired=receipt['acquired_monotonic_s'], dispatch=timing['native_dispatch_monotonic_s'])
                assert abs((b['admitted']-b['resume'])*1000 -
                    projected['stages_ms']['runtime_slot_wait_ms'] -
                    projected['stages_ms']['runtime_to_controller_admission_ms']) < .001
                if key == 'host::native':
                    host = e['native_host_source']['receipt']
                    assert host['held'] and host['owner_id'] == receipt['owner_id']
                    assert host['epoch'] == receipt['epoch'] and host['adapter_int_id'] == receipt['adapter_int_id']
                    assert host.get('clock_id', clock) == clock
                    b['host_held'] = host['held_monotonic_s']
                    chain = ['resume','pending_observed','host_held','admitted']
                    if prep['native_load_invoked']:
                        b['load_started'] = receipt['native_load_started_monotonic_s']
                        chain.append('load_started')
                    chain += ['acquired','dispatch']
                else:
                    assert not prep['native_load_invoked']
                    chain = ['resume','pending_observed','acquired','admitted','dispatch']
                row['boundaries'] = b
                for name in chain:
                    assert type(b[name]) in (int,float) and math.isfinite(b[name]) and b[name]>0, name
                for a,z in zip(chain,chain[1:]):
                    assert b[a] <= b[z], (a,z,b[a],b[z])
                    row['spans_ms'][a+'_to_'+z] = 1000*(b[z]-b[a])
                total = 1000*(b['dispatch']-b['resume'])
                assert abs(sum(row['spans_ms'].values())-total) < .001
                row['resume_to_dispatch_ms'] = total
            except (AssertionError, KeyError, TypeError, ValueError) as exc:
                row['errors'].append(type(exc).__name__+': '+str(exc))
                row['spans_ms'] = {}
        rows.append(row)
assert seen == set(rows_by_id)
save(RAW/'request_receipts.json', rows)
save(RAW/'receipt_examples.json', examples)

def flatten_numbers(value, prefix=''):
    result = {}
    if not isinstance(value,dict): return result
    for k,v in value.items():
        name = prefix+k
        if type(v) in (int,float): result[name] = v
        elif isinstance(v,dict): result.update(flatten_numbers(v,name+'.'))
    return result

def summarize(members):
    span_keys = sorted(set().union(*(r['spans_ms'].keys() for r in members)))
    rpc = [flatten_numbers(r['preparation']['final_rpc_timing']) for r in members]
    rpc_keys = sorted(set().union(*(x.keys() for x in rpc)))
    return dict(n=len(members), joint=sum(r['joint'] for r in members),
        ttft_bad=sum(not r['ttft_good'] for r in members), tpot_bad=sum(not r['tpot_good'] for r in members),
        chains_valid=sum(bool(r['spans_ms']) for r in members),
        errors=dict(collections.Counter(x for r in members for x in r['errors'])),
        stale_rechecks=dict(collections.Counter(str(r['preparation']['stale_rechecks']) for r in members)),
        spans_ms={k:describe(r['spans_ms'][k] for r in members if k in r['spans_ms']) for k in span_keys},
        preparation_ms={k:describe(r['preparation'][k] for r in members if r['preparation'][k] is not None)
            for k in ('admission_to_acquired_ms','acquired_before_admission_ms','executable_to_engine_ms',
                'admission_to_engine_ms','before_final_load_ms','final_native_load_ms')},
        rpc_fields_nonadditive={k:describe(r[k] for r in rpc if k in r) for k in rpc_keys},
        ttft_ms=describe(r['ttft_ms'] for r in members),tpot_ms=describe(r['tpot_ms'] for r in members))

groups = {}
for key in sorted({r['path'] for r in rows}):
    members = [r for r in rows if r['path'] == key]
    groups[key] = dict(all=summarize(members),
        loaded=summarize([r for r in members if r['preparation']['native_load_invoked']]),
        reused=summarize([r for r in members if not r['preparation']['native_load_invoked']]),
        ttft_bad=summarize([r for r in members if not r['ttft_good']]),
        tpot_bad=summarize([r for r in members if not r['tpot_good']]))
assert sum(g['all']['n'] for g in groups.values()) == 4000
assert sum(g['all']['joint'] for g in groups.values()) == 3575
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
paths = [Path(__file__), ROOT/'scripts/ieee_tc/analyze_d297_full.py', source, launch_path,
    OLD/'diagnosis.json', OLD/'source_paths.json', projection]
diagnosis = dict(passed=True,kind='d662_retained_native_source_path_partition_v1',
    inference_runs_added=0,n_correct=None,ranking_eligible=False,groups=groups,protected=protected,
    source_refs=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
    output_sha256={name:p.digest(RAW/name) for name in ('request_receipts.json','receipt_examples.json')},
    caveats=['Endogenous source groups are descriptive, not causal tier effects.',
        'Pending observed_at is scheduler observation, not controller ACK arrival or RPC start.',
        'HOST held time is worker reference acquisition; reply/controller work lies after it.',
        'RPC fields overlap the additive event chain; do not add them a second time.',
        'Missing chains remain unknown with explicit errors; no zero-filled timing.',
        'No counterfactual saved TTFT, no new performance result, no policy or threshold changes.'])
save(RAW/'diagnosis.json', diagnosis)
save(RAW/'analysis_receipt.json', dict(passed=True, identity=identity,
    diagnosis_sha256=p.digest(RAW/'diagnosis.json'),
    resources={k:(cg/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,groups={k:{field:v['all'][field] for field in
    ('n','joint','chains_valid','errors','spans_ms','preparation_ms')} for k,v in groups.items()})), flush=True)
