"""Reuse sealed D612 explicit-path publication; preserve all D666 evidence."""
import ast
import hashlib
from pathlib import Path
import sys
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/publish.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace('d612_w2_quality_resource_diagnosis', 'd666_host_effect_residual_slo')
replace('f72091155cd3bb258651fc461db11b9113c72faf', 'f6e07db4c1b4591782a2c621c7ecfe987b8a04c3')
replace("assert diagnosis['runs']['D607']['all']['joint']==3762", "assert diagnosis['runs']['D660']['all']['joint']==3575")
replace("assert diagnosis['runs']['D611']['all']['joint']==3819", "assert diagnosis['runs']['D665']['all']['joint']==3550")
replace('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md', 'D666_3B_HOST_EFFECT_AND_RESIDUAL_SLO.md')
replace("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']", """files += [doc, RAW/'analysis1.log', RAW.parent/'d665_20261018/publication_closure.json',
    RAW.parent/'d612_20261017/diagnose.py', RAW.parent/'d612_20261017/publish.py',
    RAW.parent/'d661_20261018/diagnose.py', RAW.parent/'d662_20261018/diagnose.py',
    RAW.parent/'d662_20261018/diagnose2.py', RAW.parent/'d660_20261018/close.py']""")
replace('assert sum(path.stat().st_size for path in files)<32*1024*1024',
        'assert sum(path.stat().st_size for path in files)<64*1024*1024')
replace('assert len(data)<8*1024*1024', 'assert len(data)<32*1024*1024')
replace('d612_reused_parent_closed_log_diagnosis_v1','d666_host_transaction_and_residual_slo_diagnosis_v1')
replace('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
        'tc: distinguish HOST transaction gains from remaining 3B SLO gap (D666)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('Explicit-path publication adaptation AST passed; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
