"""Bounded D660/D665 comparison; reuse sealed streaming and receipt analyzers.

No inference, policy changes, counterfactual latency, repeats or threshold search.
"""
import ast
import hashlib
import json
import sys
from pathlib import Path
from statistics import fmean

RAW = Path(__file__).resolve().parent
BASE = RAW.parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
SOURCES = {
    BASE/'d661_20261018/diagnose.py': 'd776ad4e728f628697ee7502ef378e55ece53bd528fcc8ac9906a0f104f49f40',
    BASE/'d612_20261017/diagnose.py': '5b9026f7fb88fdb1ccf52423ec18d3767fcfc4c0d4a1f4dd823e1cd6926c6306',
    BASE/'d662_20261018/diagnose2.py': '8063d573c908693aafa0be1645c846445b1693d39316dc9b8f9b5384fb5cd1b2',
    BASE/'d662_20261018/diagnose.py': 'f53da33350ae35ade2a0566a2bb3caad405ff773adcba6d02f8d891d52f3207c',
}
for path, expected in SOURCES.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, path

def expanded_wrapper(path, final_node):
    tree = ast.parse(path.read_text())
    assert isinstance(tree.body[-1], final_node)
    tree.body.pop()  # Only suppress the terminal execute/check-only statement.
    env = {'__file__': str(path), '__name__': '__sealed_analyzer_expansion__'}
    exec(compile(tree, str(path), 'exec'), env)
    return env['code']

def replace(code, old, new):
    assert code.count(old) == 1, old
    return code.replace(old, new)

projection_code = expanded_wrapper(BASE/'d661_20261018/diagnose.py', ast.If)
for old,new in (
    ('20261018_d660_3b_full_w0.yaml','20261018_d665_3b_full_w0.yaml'),
    ("('D660','d660_20261018','3b_full_w0')", "('D665','d665_20261018','3b_full_w0')"),
    ('p2_backend/d660_3b_full_w0/audit.json','p2_backend/d665_3b_full_w0/completion/audit.json'),
    ('31e3a5c042961983fcbfd1bd926141e66b153aab892e1432c8914b1b086e89d9',
     '2495a30a67e16936c79c24601ecee62d6c77f580fed15932ab668e40cfb6225d'),
    ("assert runs['D660']['all']['joint']==3575\nchanges={}\nref(source)",
     "assert runs['D665']['all']['joint']==3550\nchanges={}"),
    ('32*1024*1024','64*1024*1024'),
    ("assert not any('host_memory_below_stop' in x or 'filesystem_below_stop' in x for x in gate['issues'])",
     "assert gate['preflight_pass'], gate['issues']"),
    ('d661_3b_w0_residual_and_holding_v1','d666_d665_reused_projection_v1'),
    ("save(RAW/'analysis_receipt.json'", "save(RAW/'projection_receipt.json'"),
):
    projection_code = replace(projection_code, old, new)
projection_code = projection_code.replace("RAW/'diagnosis.json'", "RAW/'projection_diagnosis.json'")

receipt_code = expanded_wrapper(BASE/'d662_20261018/diagnose2.py', ast.Expr)
receipt_code = replace(receipt_code, "OLD = RAW.parent/'d661_20261018'", 'OLD = RAW')
receipt_code = replace(receipt_code, "RUN = RAW.parent/'d660_20261018/3b_full_w0'", "RUN = RAW.parent/'d665_20261018/3b_full_w0'")
begin = receipt_code.index('identity = p.scope_identity')
end = receipt_code.index('rows, examples, seen =', begin)
receipt_code = receipt_code[:begin] + '''identity = read(RAW/'analysis_identity.json')
cg = Path(identity['path'])
assert p.scope_still_owned(identity)
parent = read(RAW/'projection_diagnosis.json')
assert parent['passed'] and parent['runs']['D665']['all']['joint'] == 3550
projection = RAW/'d665_projection.json'
rows_by_id = {r['request_id']:r for r in read(projection)}
assert len(rows_by_id) == 4000
refs = {r['path']:r['sha256'] for r in parent['source_refs']}
source = RUN/'experiment_results_full_vllm_dedicated_a500_r4000_c8_tc_ieee_full_d665_3b_full_w0.json'
assert p.digest(source) == refs[str(source)] == 'fe3a27ae3bd4fb6181fbbd18e00675a9c20985b6653025e35bebd0684ea3905b'
launch_path = RUN/'launch.json'
assert p.digest(launch_path) == refs[str(launch_path)]
launch = read(launch_path)
t0, clock = launch['external_replay']['replay_t0_s'], launch['external_replay']['clock_id']
assert launch['pass'] and launch['native_gpu_context_release_confirmed']

''' + receipt_code[end:]
receipt_code = replace(receipt_code, "== 3575", "== 3550")
receipt_code = replace(receipt_code, "OLD/'diagnosis.json', OLD/'source_paths.json', projection", "RAW/'projection_diagnosis.json', projection")
begin = receipt_code.index("diagnosis['analyzer_revision']")
end = receipt_code.index("save(RAW/'analysis2_receipt.json'", begin)
receipt_code = receipt_code[:begin] + "save(RAW/'receipt_diagnosis.json', diagnosis)\n" + receipt_code[end:]
receipt_code = replace(receipt_code, "save(RAW/'analysis2_receipt.json'", "save(RAW/'receipt_analysis_receipt.json'")
receipt_code = replace(receipt_code, "p.digest(RAW/'diagnosis2.json')", "p.digest(RAW/'receipt_diagnosis.json')")
receipt_code = replace(receipt_code, "assert seen == set(rows_by_id)",
    "assert seen == set(rows_by_id)\nassert all(not r['errors'] for r in rows), 'receipt chain validation failed'")
receipt_code = replace(receipt_code, 'd662_retained_native_source_path_partition_v1', 'd666_d665_retained_native_source_path_partition_v1')
for code in (projection_code, receipt_code):
    ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('Sealed analyzers and bounded D665 adaptations AST passed; no data analyzed.')
    raise SystemExit(0)
assert not sys.argv[1:]

ns1 = {'__file__': __file__, '__name__': '__d666_projection__'}
exec(compile(projection_code, str(BASE/'d612_20261017/diagnose.py'), 'exec'), ns1)
ns2 = {'__file__': __file__, '__name__': '__d666_receipts__'}
exec(compile(receipt_code, str(BASE/'d662_20261018/diagnose.py'), 'exec'), ns2)
p, read, save = ns1['p'], ns1['read'], ns1['save']
summarize, receipts, describe = ns1['summarize'], ns2['summarize'], ns2['describe']
old_projection = BASE/'d661_20261018/d660_projection.json'
old_receipts = BASE/'d662_20261018/request_receipts2.json'
old_diagnosis = BASE/'d661_20261018/diagnosis.json'
for path, expected in (
    (old_projection, '71e02205b245c9bb0e3996e18a702cf2790e42a215e6e72b72ac87ed96092c87'),
    (old_receipts, 'c82a424bb86d6eb6d4a47d62eca7b986ecc7b66ed321ca38065da1d10cce5c91'),
    (old_diagnosis, '518a1f265755445933db2277fd36b5b472a6a2c0767e99c3f47d59bb7db87d88'),
):
    assert p.digest(path) == expected
    SOURCES[path] = expected
old = {r['request_id']:r for r in read(old_projection)}
new = ns1['projections']['D665']
before = {r['request_id']:r for r in read(old_receipts)}
after = {r['request_id']:r for r in ns2['rows']}
assert set(old) == set(new) == set(before) == set(after) and len(old) == 4000
assert all(not r['errors'] for r in before.values())
for rid in old:
    for key in ('request_id','source_index','adapter_id','arrival_s','target','prompt_tokens','ttft_limit_ms','tpot_limit_ms'):
        assert old[rid][key] == new[rid][key], (rid,key)

def compare(ids):
    ids = list(ids)
    return dict(n=len(ids), old=summarize([old[r] for r in ids]), new=summarize([new[r] for r in ids]),
        mean_difference_new_minus_old_ms={key:fmean(new[r]['stages_ms'][key]-old[r]['stages_ms'][key] for r in ids)
            for key in old[ids[0]]['stages_ms']} if ids else {})

transitions = {}
for left in (True,False):
    for right in (True,False):
        key=('good' if left else 'bad')+'_to_'+('good' if right else 'bad')
        transitions[key]=compare(r for r in old if old[r]['joint']==left and new[r]['joint']==right)
assert sum(v['n'] for v in transitions.values()) == 4000
assert transitions['bad_to_good']['n']-transitions['good_to_bad']['n'] == -25
matched_paths = {}
for path in sorted({r['path'] for r in before.values()}|{r['path'] for r in after.values()}):
    ids=[r for r in old if before[r]['path']==after[r]['path']==path]
    matched_paths[path]=dict(comparison=compare(ids),before=receipts([before[r] for r in ids]),after=receipts([after[r] for r in ids]))
new_bad=[r for r in new.values() if not r['joint']]
bad_groups={k:summarize(rows) for k,rows in (
    ('ttft_only',[r for r in new_bad if not r['ttft_good'] and r['tpot_good']]),
    ('tpot_only',[r for r in new_bad if r['ttft_good'] and not r['tpot_good']]),
    ('both',[r for r in new_bad if not r['ttft_good'] and not r['tpot_good']]),
    ('tpot_bad_target_le31',[r for r in new_bad if not r['tpot_good'] and r['target']<=31]),
    ('tpot_bad_target_gt31',[r for r in new_bad if not r['tpot_good'] and r['target']>31]),
)}
host_ids = read(ROOT/'paper_results/ieee_tc/p2_backend/d665_3b_full_w0/completion/audit.json')['host_transaction']['request_ids']
assert len(host_ids)==1392 and set(host_ids)<=set(after)
optimized_host = receipts([after[r] for r in host_ids])
assert optimized_host['chains_valid']==1392
old_run = read(old_diagnosis)['runs']['D660']
new_run = ns1['runs']['D665']
assert old_run['workload_identity']==new_run['workload_identity']
refs={str(path):sha for path,sha in SOURCES.items()}
for run in (ns1['refs'], ns2['diagnosis']['source_refs']):
    for item in run: refs[item['path']]=item['sha256']
for path in (Path(__file__), RAW/'d665_projection.json',RAW/'request_receipts2.json',
             RAW/'projection_diagnosis.json',RAW/'receipt_diagnosis.json'):
    refs[str(path)]=p.digest(path)
for key,sha in refs.items(): assert p.digest(Path(key))==sha, key
diagnosis=dict(passed=True,kind='d666_host_transaction_and_joint_slo_comparison_v1',
    inference_runs_added=0,production_changed=False,n_correct=None,ranking_eligible=False,
    confidence_interval=None,replicates_per_version=1,
    runs={'D660':{k:v for k,v in old_run.items() if k!='violations'},
          'D665':{k:v for k,v in new_run.items() if k!='violations'}},
    all_matched=compare(old),matched_transitions=transitions,matched_same_source_paths=matched_paths,
    new_violation_groups=bad_groups,new_receipt_groups=ns2['groups'],optimized_host=optimized_host,
    source_refs=[dict(path=path,sha256=sha) for path,sha in sorted(refs.items())],
    caveats=['Matched inputs do not hold endogenous routing, admission, occupancy or native batching fixed.',
        'Single observations; no CI, significance, causal latency saving, or threshold tuning.',
        'Receipt event spans contain scheduling/IPC as well as code execution; RPC fields overlap.',
        'No independent numerical correctness is inferred; failed SLO remains failed.'])
save(RAW/'diagnosis.json', diagnosis)
group=Path(ns1['identity']['path'])
save(RAW/'analysis_receipt.json',dict(passed=True,identity=ns1['identity'],
    diagnosis_sha256=p.digest(RAW/'diagnosis.json'),
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,transitions={k:v['n'] for k,v in transitions.items()},
    optimized_host=optimized_host['spans_ms'],bad_groups={k:{f:v[f] for f in ('n','joint','ttft_bad','tpot_bad')} for k,v in bad_groups.items()})),flush=True)
