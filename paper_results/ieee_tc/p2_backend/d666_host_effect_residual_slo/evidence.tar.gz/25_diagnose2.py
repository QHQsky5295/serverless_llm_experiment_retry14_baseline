"""Correct analyzer identity domains; preserve first extraction unchanged.

Scheduler and residency manager have independently generated owner IDs.
Epochs may advance during protected HOST loading. Match PID/clock, each
owner domain, exact HOST lease and adapter, rather than equating these IDs.
"""
import ast
import hashlib
from pathlib import Path
source = Path(__file__).resolve().parent/'diagnose.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'f53da33350ae35ade2a0566a2bb3caad405ff773adcba6d02f8d891d52f3207c'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace("save(RAW/'analysis_identity.json', identity)", "save(RAW/'analysis2_identity.json', identity)")
replace("save(RAW/'resource_gate.json', gate)", "save(RAW/'resource_gate2.json', gate)")
replace("assert pending['scheduler_owner_id'] == receipt['owner_id']", """assert pending['scheduler_pid'] == receipt['worker_pid'], 'scheduler/worker PID'
                assert pending['intent_id'] == e['pending_kv_admission']['intent_id'], 'pending intent'
                closed = e['pending_kv_admission']['close_receipt']['receipt']
                assert closed['scheduler_owner_id'] == pending['scheduler_owner_id'], 'scheduler owner'
                assert closed['external_request_id'] == pending['intent_id'], 'retirement intent'""")
replace("assert host['epoch'] == receipt['epoch'] and host['adapter_int_id'] == receipt['adapter_int_id']", """assert host['epoch'] <= receipt['epoch'], 'HOST epoch monotonic'
                    assert host['adapter_int_id'] == receipt['adapter_int_id'], 'adapter identity'
                    intent = e['native_host_source']['intent']
                    assert host['lease_id'] == intent['lease_id'], 'HOST lease'
                    assert host['owner_id'] == intent['expected_owner_id'], 'HOST owner'
                    assert host['worker_pid'] == receipt['worker_pid'], 'HOST worker'""")
replace("assert host.get('clock_id', clock) == clock", "assert host['clock_id'] == clock, 'HOST clock'")
replace("chain += ['acquired','dispatch']", """b['post_snapshot'] = receipt['post_load_source_snapshot']['captured_monotonic_s']
                    chain += ['acquired','post_snapshot','dispatch']""")
replace("chain = ['resume','pending_observed','acquired','admitted','dispatch']", """b['post_snapshot'] = receipt['post_load_source_snapshot']['captured_monotonic_s']
                    chain = ['resume','pending_observed','acquired','post_snapshot','admitted','dispatch']""")
replace("rows.append(row)", """row['rpc_by_operation'] = dict(
            pending=e['pending_kv_admission']['receipt'].get('timing'),
            host_hold=e.get('native_host_source',{}).get('receipt',{}).get('timing'),
            host_release=e.get('native_host_source',{}).get('release_receipt',{}).get('timing'),
            acquire=prep['final_rpc_timing'])
        rows.append(row)""")
replace("rpc = [flatten_numbers(r['preparation']['final_rpc_timing']) for r in members]",
        "rpc = [flatten_numbers(r['rpc_by_operation']) for r in members]")
code = code.replace("'request_receipts.json'", "'request_receipts2.json'")
code = code.replace("'receipt_examples.json'", "'receipt_examples2.json'")
replace("save(RAW/'diagnosis.json', diagnosis)", """diagnosis['analyzer_revision'] = 'identity_domains_corrected_v2'
diagnosis['previous_extraction'] = dict(path=str(RAW/'diagnosis.json'),sha256=p.digest(RAW/'diagnosis.json'),
    reason='Wrong analyzer equality of independent scheduler/residency owners and invariant epoch; no production defect inferred.')
diagnosis['source_refs'].append(dict(path=str(source),sha256=hashlib.sha256(data).hexdigest()))
save(RAW/'diagnosis2.json', diagnosis)""")
replace("save(RAW/'analysis_receipt.json', dict(passed=True, identity=identity,", "save(RAW/'analysis2_receipt.json', dict(passed=True, identity=identity,")
replace("diagnosis_sha256=p.digest(RAW/'diagnosis.json'),", "diagnosis_sha256=p.digest(RAW/'diagnosis2.json'),")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
