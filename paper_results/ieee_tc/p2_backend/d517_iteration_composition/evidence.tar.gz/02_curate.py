"""D517 compact source-bound publication, reusing D512 provenance workflow."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d517_iteration_composition'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'curation_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],p.GIB);assert gate['preflight_pass'],gate['issues']
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and not Path(closed['identity']['path']).exists()
receipt=read(RAW/'analysis_receipt.json');assert receipt['passed'] and receipt['identity']==closed['identity']
match=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK',(RAW/'tests1.log').read_text())
assert match and int(match[1])==133
manifest=read(RAW/'analysis1/manifest.json')
for name,sha in manifest['outputs'].items():assert p.digest(RAW/'analysis1'/name)==sha,name
for ref in manifest['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
frozen={ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in frozen.items():assert p.digest(path)==sha,path
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
subprocess.run(['git','diff','--exit-code','65eb834fa2d5e1a726bf5f1849365b7274d753bf','--',
    'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=ROOT,check=True)
OUT.mkdir(parents=True,exist_ok=False)
for name in ('summary.json','groups.csv','allocation_shapes.csv','processes.csv'):
    data=(RAW/'analysis1'/name).read_bytes();assert len(data)<2*1024*1024
    with (OUT/name).open('xb') as f:f.write(data)
    assert p.digest(OUT/name)==manifest['outputs'][name]
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
files=[RAW/name for name in ('audit_iterations.py','close.py','curate.py','analysis_identity.json',
    'analysis_receipt.json','analysis_closure.json','tests1.log','analysis1/manifest.json')]
members={}
with tarfile.open(OUT/'evidence.tar.gz','w:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<2*1024*1024
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
        name=f'{i:02d}_{path.name}'
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
outputs={x.name:p.digest(x) for x in sorted(OUT.iterdir()) if x.is_file()}
save(OUT/'manifest.json',dict(passed=True,outputs=outputs,archive_members=members,
    source_refs=manifest['source_refs'],raw_analysis_manifest=dict(path=str(RAW/'analysis1/manifest.json'),
        sha256=p.digest(RAW/'analysis1/manifest.json')),protected=protected,
    preserved={str(path):sha for path,sha in frozen.items()},tests=dict(count=133,seconds=float(match[2]),
        log_sha256=p.digest(RAW/'tests1.log')),new_gpu_runs=0,production_changed=False,
    detailed_steps_and_request_windows_local_only=True))
save(RAW/'curation_receipt.json',dict(passed=True,identity=identity,manifest_sha256=p.digest(OUT/'manifest.json'),
    sources=len(manifest['source_refs']),archive_bytes=(OUT/'evidence.tar.gz').stat().st_size,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(read(RAW/'curation_receipt.json')))
