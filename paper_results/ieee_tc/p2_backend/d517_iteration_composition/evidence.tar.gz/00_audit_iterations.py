"""D517: reuse D354's bounded offline audit on the sealed D512 observations.

No inference, production changes, output overwrites or inferred GPU kernel time.
"""
import collections
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import summarize_core_host_spans, core_interval_overlap, write_csv
RAW=Path(__file__).resolve().parent
BASE=ROOT/'paper_results/ieee_tc/p2_backend/d512_native_core/analysis1'
OUT=RAW/'analysis1'
PYTHON='/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python'
PROTECTED=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')

def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
def describe(values):
    values=sorted(values)
    return dict(count=len(values),total=math.fsum(values),
        mean=math.fsum(values)/len(values) if values else None,
        p50=values[math.ceil(.5*len(values))-1] if values else None,
        p95=values[math.ceil(.95*len(values))-1] if values else None,
        maximum=values[-1] if values else None)

def main():
    identity=p.scope_identity(p.cg_path().name)
    save(RAW/'analysis_identity.json',identity)
    group=Path(identity['path'])
    def sample():
        return {k:(group/k).read_text().strip() for k in
            ('memory.high','memory.max','memory.peak','memory.events','memory.swap.max','memory.swap.current')}
    before=sample()
    assert before['memory.high']==str(3*p.GIB) and before['memory.max']==str(4*p.GIB)
    assert before['memory.swap.max']=='0' and os.sched_getaffinity(0)=={2,3,26,27}
    assert os.environ['CUDA_VISIBLE_DEVICES']==''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    gate=p.preflight([ROOT],p.GIB)
    assert gate['preflight_pass'],gate['issues']
    assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    assert not OUT.exists()
    protected=p.verify_seal(PROTECTED);assert protected['pass'] and protected['entry_count']==147
    assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
    subprocess.run(['git','diff','--exit-code','65eb834fa2d5e1a726bf5f1849365b7274d753bf','--',
        'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=ROOT,check=True)
    passed=False
    command=[PYTHON,'-B','-m','unittest','tests.test_ieee_tc_core_timing_analysis',
        'tests.test_ieee_tc_core_timing','tests.test_ieee_tc_control_timeline',
        'tests.test_ieee_tc_decode_overlap','-q']
    try:
        with (RAW/'tests1.log').open('x') as stream:
            result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
        result.check_returncode()
        manifest=read(BASE/'manifest.json')
        for name,expected in manifest['outputs'].items():assert p.digest(BASE/name)==expected,name
        summary=read(BASE/'core_timing/summary.json')
        assert summary['complete_processes']==summary['processes']==10
        assert summary['complete_request_observations']==summary['diagnostic_count']==1000
        with (BASE/'core_timing/decode_windows.csv').open() as f:windows=list(csv.DictReader(f))
        with (BASE/'core_timing/processes.csv').open() as f:processes=list(csv.DictReader(f))
        assert len(windows)==len({r['request_id'] for r in windows})==1000
        assert all(w['observation_complete']=='True' for w in windows)
        sources=[];steps=[];requests=[];process_rows=[];turns=[]
        streams=[s for s in summary['sources'] if Path(s['path']).suffix=='.jsonl']
        assert len(streams)==10
        for source in streams:
            path=Path(source['path']);before_stat=path.stat()
            assert not path.is_symlink() and before_stat.st_size==source['bytes']<=64*1024**2
            events=[];digest=hashlib.sha256()
            with path.open('rb') as f:
                for i,line in enumerate(f):
                    assert len(line)<=8192 and line.endswith(b'\n') and i<=200002
                    digest.update(line);row=json.loads(line)
                    if i==0:header=row
                    else:events.append(row)
            after_stat=path.stat()
            assert (before_stat.st_ino,before_stat.st_size,before_stat.st_mtime_ns)==(
                after_stat.st_ino,after_stat.st_size,after_stat.st_mtime_ns)
            assert digest.hexdigest()==source['sha256']
            assert header['clock_id']==summary['clock_id']
            assert header['event']=='native_core_host_timing_v1' and header['diagnostic_prefix_count']==1000
            assert header['formal_performance_result'] is False and header['gpu_kernel_timing'] is False
            assert header['observer_overhead_included'] is True
            pid=header['pid'];assert path.stem==f"{pid}-{header['start_ticks']}"
            old=[r for r in processes if r['pid']==str(pid)]
            assert len(old)==1 and old[0]['process']==path.stem and old[0]['complete']=='True'
            audit=summarize_core_host_spans(events,include_input_turns=True,include_iterations=True)
            assert audit['complete'] and audit['spans']==int(old[0]['spans'])
            iteration=audit['iterations'];turn=audit['input_turns']
            index=iteration['index'];categories=iteration['categories']
            assert sum(index[key]['total_ns'] for key in categories)==audit['index']['step']['total_ns']
            assert index['schedule']['total_ns']+index['step_non_schedule']['total_ns']==audit['index']['step']['total_ns']
            steps.extend(dict(process=path.stem,pid=pid,**r) for r in iteration['records'])
            turns.extend(dict(process=path.stem,pid=pid,**r) for r in turn['records'])
            process_rows.append(dict(process=path.stem,pid=pid,spans=audit['spans'],
                steps=iteration['step_count'],**{k+'_ms':v['total_ns']/1e6 for k,v in index.items()}))
            for w in (r for r in windows if r['worker_pid']==str(pid)):
                a,b=int(w['first_ns']),int(w['last_ns'])
                assert audit['first_ns']<=a<=b<=audit['last_ns']
                assert w['timing_tpot_miss'] in ('True','False')
                for category in ('client','input_nonclient','step'):
                    measured=core_interval_overlap(audit['index'][category],a,b)/1e6
                    assert math.isclose(measured,float(w[category+'_ms']),abs_tol=1e-9,rel_tol=1e-12)
                record=dict(request_id=w['request_id'],worker_pid=pid,tokens=int(w['tokens']),
                    timing_tpot_miss=w['timing_tpot_miss']=='True',first_ns=a,last_ns=b,
                    **{k:float(w[k]) for k in ('tpot_ms','decode_ms','client_ms','input_nonclient_ms','step_ms','other_or_unobserved_ms')})
                overlaps={key:core_interval_overlap(value,a,b) for key,value in index.items()}
                assert sum(overlaps[k] for k in categories)==core_interval_overlap(audit['index']['step'],a,b)
                assert overlaps['schedule']+overlaps['step_non_schedule']==sum(overlaps[k] for k in categories)
                record.update({key+'_ms':value/1e6 for key,value in overlaps.items()})
                record.update({key+'_ms':core_interval_overlap(value,a,b)/1e6 for key,value in turn['index'].items()})
                requests.append(record)
            sources.append(source)
            del events,audit,iteration,turn,index
        assert len(requests)==len({r['request_id'] for r in requests})==1000
        groups=[];keys=[k for k in requests[0] if k.endswith('_ms')]
        for name,select in [('all',lambda r:True),('short_2_32',lambda r:r['tokens']<=32),
                            ('long_33_256',lambda r:r['tokens']>32)]:
            for miss in (False,True):
                rows=[r for r in requests if select(r) and r['timing_tpot_miss']==miss]
                groups.append(dict(group=name,timing_tpot_miss=miss,count=len(rows),
                    **{'mean_'+k:math.fsum(r[k] for r in rows)/len(rows) if rows else None for k in keys}))
        step_summary=[];shape_rows=[]
        def summarize_steps(rows):
            return dict(steps=len(rows),model_executed_true=sum(r['model_executed'] is True for r in rows),
                preceded_by_utility=sum(r['preceding_utility_count']>0 for r in rows),
                **{key[:-3]+'_ms':describe([r[key]/1e6 for r in rows]) for key in
                    ('step_ns','step_thread_cpu_ns','schedule_ns','schedule_thread_cpu_ns','step_non_schedule_ns','preceding_client_ns')})
        for category in categories:
            rows=[r for r in steps if r['category']==category]
            step_summary.append(dict(category=category,**summarize_steps(rows)))
            for n in sorted({r['scheduled_requests'] for r in rows},key=lambda v:-1 if v is None else v):
                selected=[r for r in rows if r['scheduled_requests']==n]
                values=summarize_steps(selected)
                shape_rows.append(dict(category=category,scheduled_requests=n,steps=len(selected),
                    model_executed_true=values['model_executed_true'],
                    **{key+'_'+stat:value for key,stats in values.items() if isinstance(stats,dict)
                       for stat,value in stats.items()}))
        turn_summary=[]
        for state,select in [('work',lambda r:r['unfinished_before']>0),('idle_at_entry',lambda r:r['unfinished_before']==0)]:
            rows=[r for r in turns if select(r)]
            turn_summary.append(dict(state=state,nonempty_turns=len(rows),
                multi_client_turns=sum(r['client_count']>1 for r in rows),
                multi_utility_turns=sum(r['utility_count']>1 for r in rows),
                **{key[:-3]+'_ms':describe([r[key]/1e6 for r in rows]) for key in
                    ('client_ns','clients_after_first_ns','clients_after_first_utility_ns')}))
        for path in (BASE/'manifest.json',BASE/'core_timing/summary.json',BASE/'core_timing/decode_windows.csv',
                     BASE/'core_timing/processes.csv',ROOT/'scripts/analyze_control_path_overhead.py',Path(__file__),
                     ROOT/'tests/test_ieee_tc_core_timing_analysis.py',
                     ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
                     Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
                     ROOT/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json',
                     Path(PYTHON).parent.parent/'lib/python3.12/site-packages/vllm/v1/engine/core.py',
                     Path(PYTHON).parent.parent/'lib/python3.12/site-packages/vllm/v1/core/sched/scheduler.py'):
            sources.append(dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=p.digest(path)))
        OUT.mkdir(exist_ok=False)
        for name,rows in [('processes',process_rows),('steps',steps),('allocation_shapes',shape_rows),
                          ('decode_windows',sorted(requests,key=lambda r:r['request_id'])),('groups',groups)]:
            write_csv(rows,OUT/(name+'.csv'))
        output=dict(kind='d517_retained_iteration_composition_v1',new_gpu_runs=0,production_changed=False,
            formal_performance_result=False,gpu_kernel_timing=False,n_correct=None,
            diagnostic_contract='D512 intrusive original1000 prefix; not D516 ordinary Full',
            processes=len(process_rows),spans=sum(r['spans'] for r in process_rows),steps=len(steps),requests=len(requests),
            clock_id=summary['clock_id'],step_summary=step_summary,turn_summary=turn_summary,groups=groups,
            sources=sources,caveats=[
                'Allocation shape is not GPU prefill/decode phase; one-token can be final prefill, multi-token can include recomputation.',
                'Step host span includes executor/output/post-step and asynchronous batch waits; not isolated GPU kernel time.',
                'Schedule is nested within step; do not add their totals. Step categories are disjoint and exhaustive.',
                'Adjacent input activity is context, not causally attributed delay. Idle/work is measured at input entry only.',
                'Process sums are across lifetimes; overlapping request intersections cannot be summed as service time.',
                'Observer overhead is included, never subtracted; no counterfactual speedup or production4000 extrapolation.',
                'TPOT groups use the unchanged D394 frozen ruler, not provisional thresholds; numerical proof remains unknown.'])
        save(OUT/'summary.json',output)
        outputs={x.name:p.digest(x) for x in sorted(OUT.iterdir()) if x.is_file()}
        save(OUT/'manifest.json',dict(outputs=outputs,source_refs=sources))
        assert p.verify_seal(PROTECTED)['pass']
        passed=True
        print(json.dumps(dict(steps=len(steps),step_summary=step_summary,turn_summary=turn_summary,groups=groups)))
    finally:
        save(RAW/'analysis_receipt.json',dict(passed=passed,identity=identity,before=before,after=sample(),
            gate=gate,test_command=command,protected=protected,new_gpu_runs=0))

if __name__=='__main__':main()
