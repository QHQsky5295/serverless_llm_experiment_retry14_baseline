#!/usr/bin/env bash
# Reuse D115 evidence closure for the normal D135 result schema.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d135_20261001
unit=primelora-d135-full1-evidence-20261001.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_evidence_scope.txt"
export PYTHONUNBUFFERED=1
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest tests.test_ieee_tc_gpu_lifecycle tests.test_ieee_tc_external_replay tests.test_ieee_tc_native_timing tests.test_ieee_tc_control_timeline -v
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python - <<'PY'
import json, subprocess
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d135_20261001'
before = json.loads((raw/'prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    p = Path(name) if name.startswith('/') else root/name
    assert digest(p) == expected, name
full = root/'paper_results/ieee_tc/p2_backend/20261001_d135_7b_full_w0_full1.json'
assert digest(full) == '8ec44dfe0fc2aa3a56837a4b0fc34d02d0a59d32dad6c60017cf5ca0fe76b061'
x = json.loads(full.read_text())
assert not x['native_contract_completion_pass'] and not x['full_qualified']
assert not x['formal_performance_result'] and x['launcher_cleanup_pass']
assert x['execution_completed'] and x['cleanup']['complete']
launch = json.loads((raw/'7b_full_w0_full1/launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert all(launch[k] == 0 for k in ('service_returncode','replay_returncode','watchdog_returncode'))
assert x['population']['success'] == x['population']['native_contract_matched'] == 3999
assert x['population']['failure_observations'] == {'TimeoutError':1}
assert x['timing_validation']['requests'] == 3999
assert max(x['timing_validation']['max_error_ms'].values()) <= 1.0
assert x['timing_validation']['pass_tolerance']
assert x['timing_validation']['violations'] == []
assert x['timing_validation']['requests_over_tolerance'] == 0
assert x['physical']['n_correct'] is None and not x['physical']['eligible_correctness']
assert x['physical']['measurement_complete'] and not x['physical']['open_lease_ids']
assert not x['observed_completion_boundaries']['client_response_observed']
assert x['quarantine']['events'] == x['quarantine']['released'] == 0
assert x['remote']['uuid_pairs'] == 132
assert not x['remote']['byte_mismatches'] and x['remote']['request_packing'] == 0
assert x['remote']['states'] == dict(published=132)
assert x['remote']['client_received_bytes'] == x['remote']['server_socket_written_bytes'] == 131480060
assert x['remote']['unpublished_cause'] == 'per_transfer_evidence_not_presumed_identical'
assert x['remote']['unpublished_evidence'] == []
planning = x['planning_cpu_diagnostics']
assert planning['events'] == 2077
assert set(planning['by_operation']) == {'owned_execution_epoch'}
op = planning['by_operation']['owned_execution_epoch']
assert op['events'] == op['receipt_rows'] == 2077
assert op['worker_pids'] == [403567]
assert op['state_counts'] == dict(completed=2077)
assert op['frozen_validation_ms']['n'] == 2077
assert op['frozen_validation_ms']['mean'] > 0
assert op['input_bytes'] == 5398380950 and op['output_bytes'] == 6867712204
assert all(counts.get('failed', 0) == 0 for counts in x['mechanism_counts'].values())
assert x['readiness_evidence']['confirmed_pre_generation_requests'] == 3999
assert x['readiness_evidence']['conflicts'] == 0
for removed in x['cleanup']['roots']:
    assert not Path(removed['path']).exists(), removed['path']
for stage in ('projection', 'curation'):
    lines = (raw/f'{stage}_cleanup_full1.log').read_text().splitlines()
    names = {'low','high','max','oom','oom_kill','oom_group_kill'}
    events = dict(line.split() for line in lines if len(line.split()) == 2 and line.split()[0] in names)
    assert set(events) == names and all(int(v) == 0 for v in events.values())
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == x['metric_protocol_sha256']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
reused = []
checked = 0
for ref in x['source_refs']:
    p = Path(ref['path'])
    if p.name == 'experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d135_7b_full_w0_full1.json':
        # Already streamed/hashed by the completed curator, not re-parsed/rehashed.
        st = p.stat()
        assert st.st_size == 15082690805 and st.st_mtime_ns <= full.stat().st_mtime_ns
        reused.append(dict(**ref, bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                           verification='reuse_completed_curator_stream_hash_plus_stat'))
    else:
        assert digest(p) == ref['sha256'], ref['path']
        checked += 1
# Normal D96 streaming schema fixture; preserve both success and failure.
fixture = dict(detailed_results=dict(tc_ieee_full=dict(scenario_name='fixture',total=2,
    requests=[dict(request_id='r0',tokens=[1,2],gpu_reference_evidence=dict(
        source_admission=dict(tier='host'),generation_submission=dict(state='submitted'),
        prior_routing_attempts=[dict(x=1),dict(x=2)],huge_inventory=[dict(x=9)])),
        dict(request_id='r1',error='request-failure')])))
jq_filter = root/'results/ieee_tc/p2_backend_qualification/d96_20260928/project_full_attempt3.jq'
res = subprocess.run(['jq','--stream','-n','-f',str(jq_filter)],
    input=json.dumps(fixture),text=True,capture_output=True,check=True)
y = json.loads(res.stdout)
assert y['scenario'] == dict(scenario_name='fixture',total=2)
assert len(y['requests']) == 2 and y['requests'][1]['error'] == 'request-failure'
r = y['requests'][0]
assert r['tokens'] == [1,2] and r['prior_routing_attempt_count'] == 2
assert r['retained_reference_evidence']['source_admission'] == dict(tier='host')
assert 'gpu_reference_evidence' not in r and 'huge_inventory' not in r
failure = root/'paper_results/ieee_tc/p2_backend/20261001_d135_7b_full_w0_failure_breakdown.json'
assert digest(failure) == 'ca988f57f19b46583a96dfeeb8378f936045e404b5dfb2cf09884fca86f9c5ae'
f = json.loads(failure.read_text())
assert f['population'] == dict(planned=4000,success=3999,timeout=1,returned_error=0)
assert f['returned_categories'] == {}
assert f['failure_observation_clock_id'] == x['physical']['clock_id']
assert f['projection_sha256'] == digest(raw/'full_full1_request_projection.json')
assert f['source_script_sha256'] == digest(raw/'collect_full1_failure_breakdown.py')
assert len(f['timeout_requests']) == 1 and len(f['returned_requests']) == 0
assert f['returned_generation_submission_states'] == {}
assert f['first_returned_error'] is None and f['first_timeout']['request_id'] == 'req_03061'
assert 'Exit status: 0' in (raw/'full_full1_failure_time.txt').read_text()
# Reuse D126's bounded occupancy verification, all offered IDs retained.
import csv, math
occupancy_dir = root/'paper_results/ieee_tc/p2_backend/20261001_d135_control_occupancy'
occupancy_path = occupancy_dir/'summary.json'
assert digest(occupancy_path) == 'd8ba932601b9e27f60a3fb1c305582939074bd8e627bc2eb87c694aed6b75f88'
occupancy = json.loads(occupancy_path.read_text())
assert occupancy['population'] == dict(planned=4000,terminal=4000,native_success=3999,failed=1)
assert occupancy['phase_population'] == 'native_success_only' and len(occupancy['failures']) == 1
for ref in occupancy['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256']
phases = occupancy['phase_summaries']
assert all(v['n'] == 3999 for v in phases.values())
phase_sum = math.fsum(phases[k]['total_request_seconds'] for k in (
    'gate_to_source_admission','source_to_native_dispatch','native_dispatch_to_last_token',
    'last_token_to_controller_completion','controller_completion_to_terminal'))
assert math.isclose(phase_sum,phases['gate_to_terminal']['total_request_seconds'],abs_tol=1e-6)
with (occupancy_dir/'request_occupancy.csv').open() as handle:
    occupancy_rows = list(csv.DictReader(handle))
assert len(occupancy_rows) == len({r['request_id'] for r in occupancy_rows}) == 4000
assert 'Exit status: 0' in (raw/'audit_time2.txt').read_text()
assert 'ActiveState=inactive' in (raw/'cleanup_occupancy2.log').read_text()
controls=occupancy['control_observations']
assert controls['source_event_count'] == 1945
assert controls['in_request_window_count'] == 1944
assert len(controls['outside_request_window']) == 1
outside=controls['outside_request_window'][0]
assert outside['boundary'] == 'after_request_window' and outside['source_index'] == 1944
assert outside['event']['observed_at'] == 314529.797258679
assert outside['event']['queue_depth'] == outside['event']['active_requests'] == 0
assert sum(v['samples'] for v in controls['by_phase'].values()) == 1944
assert 'Exit status: 1' in (raw/'audit_time1.txt').read_text()
assert 'Exit status: 0' in (raw/'timeline_test1_time.txt').read_text()
refs = [full,failure,raw/'collect_full1_failure_breakdown.py',raw/'full_full1_failure_time.txt',
        raw/'summarize_full_full1.py',raw/'verify_full1_evidence.sh',
        raw/'full_full1_curation_time.txt',raw/'curation_cleanup_full1.log',
        root/'tests/test_ieee_tc_gpu_lifecycle.py',root/'tests/test_ieee_tc_external_replay.py',
        root/'tests/test_ieee_tc_native_timing.py']
refs += [p for p in occupancy_dir.iterdir() if p.is_file()]
refs += [raw/'run_occupancy_audit2.sh',raw/'cleanup_occupancy2.sh',raw/'cleanup_occupancy2.log',
         raw/'scope_before2.txt',raw/'audit_time2.txt',root/'docs/ieee_tc/D135_FULL_W0_FULL1.md']
refs += [root/'scripts/analyze_control_path_overhead.py', root/'tests/test_ieee_tc_control_timeline.py',
         raw/'control_bounds2.json', raw/'audit_time1.txt', raw/'run_occupancy_audit1.sh',
         raw/'cleanup_occupancy1.sh',raw/'cleanup_occupancy1.log',
         raw/'timeline_test1.log',raw/'timeline_test1_time.txt',raw/'cleanup_timeline_test1.log',
         raw/'full_full1_metadata_compaction.sha256']
receipt = dict(kind='d135_full1_evidence_verification_v1',pass_checks=True,
    full_qualified=False,formal_performance_result=False,projection_fixture_pass=True,
    frozen_source_refs_checked=len(before['source_sha256']),curated_source_refs_rehashed=checked,
    reused_large_source_hash=reused,source_commit=before['runtime_source_commit'],
    protected=protected,refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
out = root/'paper_results/ieee_tc/p2_backend/20261001_d135_evidence_verification.json'
with out.open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(out),sha256=digest(out),frozen_sources=len(before['source_sha256']),
    curated_sources_rehashed=checked,reused_large_source_hash=len(reused),protected=147)))
PY
