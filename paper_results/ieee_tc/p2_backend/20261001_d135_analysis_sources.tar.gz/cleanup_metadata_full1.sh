#!/usr/bin/env bash
set -euo pipefail
# Reuse D115 exact-identity / empty-domain cleanup; only D135 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-fb9a22ab559b4a2e8d78c17e72e4eb03.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d135-full1-metadata-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 1f84c2b4e7034ae881a0d0671089fe0e
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d135-full1-metadata-20261001.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
