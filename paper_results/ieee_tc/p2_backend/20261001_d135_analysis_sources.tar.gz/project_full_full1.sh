#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d135_20261001
# Prepared, NOT run. Normal-result schema only; inspect final state first.
shopt -s nullglob
sources=("$raw"/7b_outputs_full1/experiment_results_full_vllm_dedicated_a500_r4000_c*_tc_ieee_full_d135_7b_full_w0_full1.json)
test "${#sources[@]}" = 1
source_file="${sources[0]}"
target="$raw/full_full1_request_projection.json"
test -s "$raw/7b_full_w0_full1/launch.json"
test -s "$source_file"
test "$(stat -c %s "$source_file")" = "$(jq -er '.normal_source_stat.bytes' "$raw/full_full1_preliminary.json")"
test "$source_file" = "$(jq -er '.normal_source_stat.path' "$raw/full_full1_preliminary.json" | sed 's@^/home/qhq/serverless_llm_experiment/results/@results/@')"
test "$(stat -c %i "$source_file")" = "$(jq -er '.normal_source_stat.inode' "$raw/full_full1_preliminary.json")"
jq -e '.execution_completed == true and .cleanup.complete == true and .population.terminal == 4000' "$raw/full_full1_preliminary.json"
test ! -e "$target"
test ! -e "$raw/full_full1_projection_time.txt"
test "$(systemctl --user show primelora-tc-svc-fb9a22ab559b4a2e8d78c17e72e4eb03.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d135-full1-project-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_projection_scope.txt"
# Unmodified D96 bounded projection retains failed requests. No whole JSON load.
exec /usr/bin/time -v -o "$raw/full_full1_projection_time.txt" \
  jq --stream -n -f results/ieee_tc/p2_backend_qualification/d96_20260928/project_full_attempt3.jq \
  "$source_file" > "$target"
