#!/usr/bin/env bash
set -euo pipefail
# Reuse D115 exact-identity / empty-domain cleanup; only D135 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-fb9a22ab559b4a2e8d78c17e72e4eb03.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d135-occupancy2-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 1c8b73ee1abf4344b338e36129cb3de9
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d135-occupancy2-20261001.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
