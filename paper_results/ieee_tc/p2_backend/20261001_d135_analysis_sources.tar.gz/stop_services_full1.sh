#!/usr/bin/env bash
set -euo pipefail
# Existing D110 exact-identity cleanup, adapted to D135. Execute remotely ONLY
# after local main exit and GPU cleanup; never while inference is running.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d135full1.service)
ids=(f741a67c707149ab8b5d1ba85d7fda89 234e940b60da41548cdd0cbd2d8c4753 c3bf9e95a97444d0bce92df2af85973f)
pids=(1114693 1114695 1114698)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result
