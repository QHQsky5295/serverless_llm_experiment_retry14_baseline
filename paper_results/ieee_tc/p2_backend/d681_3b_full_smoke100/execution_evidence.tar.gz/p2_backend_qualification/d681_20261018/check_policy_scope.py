"""Reuse D663 bounded tests only for changed controller/configuration scope."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d663_20261018/qualify.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='1cfd5d94227448d349d837b613283b03d85a28f3069e74fa118ef531b952eeea'
code=data.decode()
start=code.index("paths = ['faaslora/memory/gpu_monitor.py'")
end=code.index('log = RAW/',start)
code=code[:start]+"""paths=['scripts/run_all_experiments.py','tests/test_ieee_tc_request_lifecycle.py','tests/test_ieee_tc_launch.py']
for path in paths:ast.parse((MAIN/path).read_text())
tests=['tests.test_ieee_tc_request_lifecycle.SelectedSourceAdmissionIntegration',
       'tests.test_ieee_tc_launch.ScenarioRuntimeConfiguration',
       'tests.test_ieee_tc_launch.NativeAllocatorLaunchContract',
       'tests.test_ieee_tc_launch.MetadataFullProfileConfiguration']
"""+code[end:]
ast.parse(code)
exec(compile(code,str(source),'exec'))
