"""Reuse D676 assembly and completed D680 tests for one native prefix qualification."""
import ast
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import yaml

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d681_3b_full_smoke100'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'qualification2_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate=p.preflight([ROOT],32*p.GIB)
save(RAW/'resource_gate2.json',gate)
assert gate['preflight_pass'],gate['issues']
affected=read(RAW/'analysis_receipt.json')
assert affected['passed'] and affected['returncode']==0
assert p.digest(RAW/'analysis.log')==affected['log_sha256']
for path,sha in affected['source_sha256'].items():assert p.digest(Path(path))==sha
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
prior=RAW.parent/'d680_20261018'
refs={}
qualified=read(ROOT/'paper_results/ieee_tc/p2_backend/d680_host_lease_transfer/qualified/qualification.json')
assert qualified['passed'] and qualified['production_candidate'] and not qualified['native_gpu_validation']
assert qualified['test_counts']['analysis2']==527 and qualified['test_counts']['qualification2']==72
for phase in ('qualification2','analysis2'):
    receipt=read(prior/(phase+'_receipt.json'))
    assert receipt['passed'] and receipt['returncode']==0
    assert p.digest(prior/(phase+'.log'))==receipt['log_sha256']
    for path,sha in receipt['source_sha256'].items():
        current=affected['source_sha256'].get(path,sha)
        assert p.digest(Path(path))==current,path
        refs[path]=current
    for path,sha in receipt['preserved'].items():assert p.digest(Path(path))==sha
for phase in ('qualification','analysis','qualification2','analysis2','backup','publication'):
    closed=read(prior/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
assert read(prior/'publication_receipt.json')['head']=='da30cb2f2e002bdd53ec9b163cb4e71af8fb8c07'
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
text=shell.read_text()
start=text.index('  d681)\n');end=text.index('    ;;\n',start)+len('    ;;\n')
restored=text[:start]+text[end:]
assert restored.count(' || "${1:-d293}" == d681')==2
restored=restored.replace(' || "${1:-d293}" == d681','')
assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
for path in [shell,*RAW.glob('*.sh')]:subprocess.run(['bash','-n',str(path)],check=True)
for path in RAW.glob('*.py'):ast.parse(path.read_text())
old_config=ROOT/'configs/ieee_tc/20261018_d676_3b_full_smoke100.yaml'
config=ROOT/'configs/ieee_tc/20261018_d681_3b_full_smoke100.yaml'
expected_text=old_config.read_text().replace('d676','d681').replace(
    'resource_coordination:\n',
    'resource_coordination:\n  ieee_host_lease_transfer: same_owner_host_to_gpu_v1\n')
assert config.read_text()==expected_text
cfg=yaml.safe_load(config.read_text())
prepared_path=ROOT/'paper_results/ieee_tc/p2_backend/d658_3b_full_entry/preparation.json'
prepared=read(prepared_path)
assert prepared['passed']
for item in prepared['sources']:
    assert p.digest(Path(item['path']))==item['sha256']
src={item['role']:Path(item['path']) for item in prepared['sources']}
from scripts.ieee_tc.prepare_d298_capacity import assemble_3b_current_full
from scripts.run_all_experiments import ScenarioRunner,_prepare_scenario_runtime_model_config,_prepare_dedicated_subprocess_model_cfg
assembled,child,env=assemble_3b_current_full(yaml.safe_load(src['previous'].read_text()),
    read(src['contract']),read(src['profiles']),output_dir=cfg['experiment']['output_dir'],
    nvme_dir=cfg['storage']['nvme_cache_dir'],host_dir=cfg['storage']['host_cache_dir'],count=100)
assert child==prepared['planned_child_model_config'] and env==prepared['child_environment']
assembled['resource_coordination']['ieee_host_lease_transfer']='same_owner_host_to_gpu_v1'
assert assembled==cfg
runtime=_prepare_scenario_runtime_model_config(cfg['model'],cfg['workload'],cfg['resource_coordination'])
child,env=_prepare_dedicated_subprocess_model_cfg(runtime,device_id=0,runtime_gpu_ids=[0])
expected_child=prepared['planned_child_model_config']
assert child==expected_child and env==prepared['child_environment']
runner=ScenarioRunner.__new__(ScenarioRunner)
runner.coord_cfg=cfg['resource_coordination'];runner._initial_runtime_pending=True
runner.model_cfg=_prepare_scenario_runtime_model_config(cfg['model'],cfg['workload'],runner.coord_cfg)
runner._service_profiles=runner._load_ieee_service_profiles()
assert runner._load_ieee_preparation_profiles() is not None
from faaslora.datasets.workload_generator import FrozenReplayPlan
plan=FrozenReplayPlan.load(prepared['source_plan']['source_path'],count=100,profile='W0')
assert plan.identity()==prepared['source_plan']
assert not (RAW/'3b_full_smoke100').exists() and not Path(cfg['storage']['host_cache_dir']).exists()
assert not Path(cfg['storage']['nvme_cache_dir']).exists()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
OUT.mkdir(parents=True,exist_ok=False)
prepared=copy.deepcopy(prepared)
prepared.update(kind='d681_same_owner_host_lease_transfer_native_v1',
    configuration=dict(path=str(config),sha256=p.digest(config)),
    candidate_parent='da30cb2f2e002bdd53ec9b163cb4e71af8fb8c07',
    unchanged_non_target_configuration=True,planned_child_model_config=child,
    candidate_delta={'resource_coordination.ieee_host_lease_transfer':'same_owner_host_to_gpu_v1'})
save(OUT/'preparation.json',prepared)
paths=[shell,config,old_config,prepared_path,OUT/'preparation.json',*src.values(),
       ROOT/'scripts/run_all_experiments.py',ROOT/'scripts/ieee_tc/prepare_d298_capacity.py',
       ROOT/'faaslora/experiment/instance_pool.py',ROOT/'faaslora/datasets/workload_generator.py',
       ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json']
paths+=sorted(RAW.glob('*.py'))+sorted(RAW.glob('*.sh'))
refs.update(affected['source_sha256'])
refs.update({str(path):p.digest(path) for path in paths})
record=dict(passed=True,count=100,reused_cpu_tests=527,reused_native_method_tests=72,no_gpu_run=True,
    same_configuration_as_d676_except_host_transfer_and_paths=True,
    affected_scope_tests=dict(receipt_sha256=p.digest(RAW/'analysis_receipt.json'),tests=affected['tests']),unchanged_historical_shell_branches=True,
    source_plan=plan.identity(),planned_child_model_config=child,child_environment=env,
    configuration=prepared['configuration'],refs=refs,protected=protected,identity=identity,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')})
save(RAW/'qualification.json',record)
save(OUT/'prelaunch.json',dict(passed=True,count=100,full_performance_complete=False,
    qualification_sha256=p.digest(RAW/'qualification.json'),configuration=prepared['configuration'],
    candidate_parent=prepared['candidate_parent'],no_new_input_or_profile=True))
print(json.dumps(dict(passed=True,count=100,source_plan=plan.identity(),resources=record['resources'])))
