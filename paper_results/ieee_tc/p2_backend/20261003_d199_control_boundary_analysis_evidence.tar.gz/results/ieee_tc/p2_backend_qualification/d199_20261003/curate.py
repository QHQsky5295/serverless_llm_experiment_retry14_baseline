"""Reuse D198's bounded qualification/evidence delivery for the offline analyzer."""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT=Path.cwd()
RAW=ROOT/'results/ieee_tc/p2_backend_qualification/d199_20261003'
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX='20261003_d199_control_boundary_analysis'
PARENT='79dc8f12668c7d255846e97c7a461c95e8d580d4'

def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()

source='scripts/analyze_control_path_overhead.py'
old=ast.parse(subprocess.check_output(['git','show',PARENT+':'+source]))
new=ast.parse((ROOT/source).read_bytes())
def stripped(tree):
    tree.body=[n for n in tree.body if not (
        isinstance(n,ast.FunctionDef) and n.name in ('main','analyze_control_boundaries'))
        and not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONTROL_BOUNDARIES' for t in n.targets))]
    return ast.dump(tree)
assert stripped(old)==stripped(new), 'existing analyzer bodies changed'
changed=set(subprocess.check_output(['git','diff','--name-only',PARENT,'--','faaslora','scripts','configs/ieee_tc'],text=True).splitlines())
assert changed=={source},changed
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
rows,members=[],[]
for phase,identity,count in [('tests1','98860922cc054a6aa5835a1e6cd84d8e',31),
                             ('regression1','ad9f576254a844a4a8664ef676563cd5',71)]:
    unit='primelora-d199-'+phase+'-20261003.scope'
    for prop,value in [('LoadState','not-found'),('InvocationID',''),('ControlGroup','')]:
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip()==value
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    assert 'InvocationID='+identity in (RAW/(phase+'_scope.txt')).read_text()
    log=(RAW/(phase+'.log')).read_text()
    summary=re.findall(r'^Ran (\d+) tests in ([0-9.]+)s\n\nOK$',log,re.M)
    assert len(summary)==1 and int(summary[0][0])==count
    timing=(RAW/(phase+'_time.txt')).read_text()
    assert 'Exit status: 0' in timing
    events=dict(line.split() for line in (RAW/(phase+'_memory_events.txt')).read_text().splitlines())
    assert all(int(v)==0 for v in events.values())
    assert (RAW/(phase+'_swap.txt')).read_text().strip()=='0'
    for when in ('before','after'):
        encoded=(RAW/(phase+'_protected_'+when+'.json')).read_text()
        prefix,payload=encoded.split('\n',1)
        assert re.fullmatch(r'INFO \d{2}-\d{2} \d{2}:\d{2}:\d{2} \[__init__\.py:216\] Automatically detected platform cuda\.',prefix)
        checked=json.loads(payload)
        assert checked['pass'] and checked['entry_count']==147
    with tarfile.open(RAW/(phase+'_sources.tar.gz'),'r:gz') as archive:
        for line in (RAW/(phase+'_sources.sha256')).read_text().splitlines():
            digest,path=line.split('  ',1)
            assert hashlib.sha256(archive.extractfile(path).read()).hexdigest()==digest
            # The tests1 wrapper predates adding the regression selector; exact
            # historical wrapper is in its source archive, never overwritten.
            if not (phase=='tests1' and path.endswith('/run_cpu.sh')):
                assert sha(ROOT/path)==digest
    rows.append(dict(phase=phase,tests=count,status='PASS',test_body_seconds=float(summary[0][1]),
        command_elapsed=re.search(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\): (\S+)',timing).group(1),
        max_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',timing).group(1)),
        invocation_id=identity,scope_absent=True,memory_events=events,swap_bytes=0))
    members.extend(RAW/(phase+suffix) for suffix in ('.log','_scope.txt','_time.txt','_memory_events.txt',
        '_swap.txt','_protected_before.json','_protected_after.json','_sources.sha256','_sources.tar.gz'))
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
assert protected['plan_sha256']=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
doc=ROOT/'docs/ieee_tc/D199_CONTROL_BOUNDARY_ANALYSIS.md'
members.extend([doc,ROOT/source,ROOT/'tests/test_ieee_tc_rpc_breakdown.py',
                RAW/'run_cpu.sh',RAW/'curate.py',RAW/'run_curate.sh'])
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret)>16
def inspect(data,name):
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for member in archive.getmembers():
                assert member.isfile() and '..' not in Path(member.name).parts and not member.name.startswith('/')
                inspect(archive.extractfile(member).read(),member.name)
    if name.endswith('.py'): ast.parse(data,filename=name)
for path in members:
    inspect(path.read_bytes(),str(path))
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
table=['# D199 CPU qualification','',
       'Synthetic fixtures; overlapping test groups. No GPU performance, model qualification or CI.','',
       '| Check | Tests | Result | Body seconds | Command elapsed | Peak RSS KiB |',
       '|---|---:|---|---:|---|---:|']
for row in rows:
    table.append(f"| {row['phase']} | {row['tests']} | PASS | {row['test_body_seconds']:.3f} | {row['command_elapsed']} | {row['max_rss_kib']} |")
with (OUT/(PREFIX+'.csv')).open('x',newline='') as f:
    keys=('phase','tests','status','test_body_seconds','command_elapsed','max_rss_kib','invocation_id','scope_absent','swap_bytes')
    writer=csv.DictWriter(f,fieldnames=keys,lineterminator='\n')
    writer.writeheader()
    writer.writerows({k:row[k] for k in keys} for row in rows)
with (OUT/(PREFIX+'_table.md')).open('x') as f: f.write('\n'.join(table)+'\n')
sources={str(p):sha(p) for p in members}
bundle=OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output,tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members: archive.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers())==len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(str(path.relative_to(ROOT))).read()).hexdigest()==sources[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as f: f.write(sha(bundle)+'  '+bundle.name+'\n')
result=dict(kind='d199_control_boundary_analysis_qualification_v1',parent=PARENT,
    status='cpu_qualified_diagnostic_prefix_pending',tests=rows,protected_after=protected,
    source_sha256=sources,scope_ast_check='PASS: existing analyzer bodies unchanged',
    serving_changed=False,gpu_execution=False,remote_operation=False,numeric_qualification=False,performance_accepted=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    table_sha256=sha(OUT/(PREFIX+'_table.md')),csv_sha256=sha(OUT/(PREFIX+'.csv')))
with (OUT/(PREFIX+'.json')).open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS',tests=[r['tests'] for r in rows],protected=147,
    curated_sha256=sha(OUT/(PREFIX+'.json')),evidence_bundle=result['evidence_bundle']),indent=2))
