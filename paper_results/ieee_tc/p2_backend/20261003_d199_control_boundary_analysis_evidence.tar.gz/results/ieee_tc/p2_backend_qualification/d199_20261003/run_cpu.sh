#!/usr/bin/env bash
# Reuse D198 resource/test contract; only bounded offline analyzer changes.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in tests1|tests2|regression1) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d199_20261003
unit="primelora-d199-${phase}-20261003.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sources=(scripts/analyze_control_path_overhead.py tests/test_ieee_tc_rpc_breakdown.py
  tests/test_ieee_tc_capacity_audit.py tests/test_ieee_tc_timing_bound.py
  tests/test_ieee_tc_control_timeline.py "$raw/run_cpu.sh")
sha256sum "${sources[@]}" > "$raw/${phase}_sources.sha256"
tar -czf "$raw/${phase}_sources.tar.gz" "${sources[@]}"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
"$python" scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "$raw/${phase}_protected_before.json"
set +e
if test "$phase" = regression1; then
  args=(-m unittest tests.test_ieee_tc_rpc_breakdown tests.test_ieee_tc_capacity_audit tests.test_ieee_tc_timing_bound tests.test_ieee_tc_control_timeline -v)
else
  args=(-m unittest tests.test_ieee_tc_rpc_breakdown -v)
fi
/usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/${phase}_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/${phase}_swap.txt"
"$python" scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "$raw/${phase}_protected_after.json"
exit "$code"
