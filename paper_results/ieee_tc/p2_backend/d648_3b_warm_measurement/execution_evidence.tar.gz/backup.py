"""Reuse the explicit checkpoint for the complete 3B common warm calibration."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'","OUT=ROOT/'paper_results/ieee_tc/p2_backend/d648_3b_warm_measurement'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'","=='514098deb97107644ae08b1efa15ae0319ad19a0'")
begin=code.index('reg=read(RAW/');end=code.index('preserved={',begin)
code=code[:begin]+'''audit=read(RAW/'qualification.json')
assert audit['passed'] and audit['tests']==17 and audit['native_checked']==1552 and audit['batch_checked']==194
assert audit['current_warm_measured'] and audit['measured']==1536
assert p.digest(RAW/'source1.json')==audit['source_sha256']
for name,key in [('scripts/ieee_tc/audit_warm_measurement.py','auditor_sha256'),('tests/test_ieee_tc_warm_reference.py','tests_sha256')]:
    assert p.digest(ROOT/name)==audit[key]
for phase in ('start','analysis','publication'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert not Path(read(RAW/'local_cleanup.json')['identity']['path']).exists()
freeze=read(RAW/'freeze_receipt.json');assert freeze['passed']
for key in ('freeze','calibration','samples','auditor','source'):
    ref=freeze[key];assert p.digest(Path(ref['path']))==ref['sha256']
assert read(Path(freeze['freeze']['path']))['slo_reference_frozen']
gate=p.preflight([ROOT],32*1024*1024);assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
''' +code[end:]
begin=code.index('members=[RAW/name');end=code.index('\nfor path in members:',begin)
code=code[:begin]+'''members=[RAW/name for name in ('start.py','close.py','collect.py','freeze.py','backup.py',
    'start_identity.json','start_receipt.json','start_closure.json','launch_gate.json','preflight.json',
    'launcher_identity.json','local_cleanup.json','analysis_identity.json','analysis_closure.json','analysis_gate.json',
    'qualification.json','native_audit.json','audit.log','source1_launch.json','source_commit.txt',
    'source1_launcher.log','publication_identity.json','publication_gate.json','publication_closure.json',
    'freeze_receipt.json','backup_gate.json')]
members += [RAW/'source1_launch.launch'/name for name in ('service.log','exec_receipt.json','watchdog.jsonl','watchdog.stderr')]
assert len({path.name for path in members})==len(members)
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
''' +code[end:]
replace('OUT.mkdir(parents=True,exist_ok=False)',"assert OUT.is_dir() and (OUT/'warm_reference.json').exists()")
begin=code.index('test_counts={');end=code.index("save(OUT/'qualification.json'",begin)
code=code[:begin]+'''test_counts={'native_cases':1552,'measured':1536,'retained_warmups':16,'reused_unchanged_cpu_tests':17}
record=dict(passed=True,experiment_pass=True,native_warm_measurement=True,full_performance_run=False,
    parent_commit='514098deb97107644ae08b1efa15ae0319ad19a0',audit=audit,protected=protected,freeze=freeze,
    preserved={str(k):v for k,v in preserved.items()},archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    source_run=dict(path=str(RAW/'source1.json'),sha256=p.digest(RAW/'source1.json')),
    archive_members={path.name:dict(path=str(path),sha256=p.digest(path)) for path in members},
    caveat='Shared 3B SLO calibration; not Full workload, GPU budget reference or system ranking.')
''' +code[end:]
outputs="('qualification.json','execution_evidence.tar.gz','warm_reference.json','native_audit.json','samples.csv')"
replace("for name in ('qualification.json','execution_evidence.tar.gz'):f.write",'for name in '+outputs+':f.write')
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D648_3B_COMMON_WARM_REFERENCE.md',str(Path(freeze['freeze']['path']).relative_to(ROOT))]")
replace("('qualification.json','execution_evidence.tar.gz','result.sha256')",outputs[:-1]+",'result.sha256')")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: freeze common 3B native warm SLO calibration without changing metric rules (D648)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
