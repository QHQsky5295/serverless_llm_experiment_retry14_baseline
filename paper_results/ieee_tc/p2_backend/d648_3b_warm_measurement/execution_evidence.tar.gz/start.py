"""Reuse the gated start with sealed current 3B inputs and a passed batch8 probe."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d641_20261017/start.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("=='02f438519d2cca90aa2b710466900dac1daca2a6'","=='514098deb97107644ae08b1efa15ae0319ad19a0'")
replace("previous=RAW.parent/'d640_20261017'","previous=RAW.parent/'d647_20261017'")
begin=code.index("prepared=ROOT/");end=code.index('assert p.check_plan()',begin)
code=code[:begin]+'''prepared=ROOT/'paper_results/ieee_tc/p2_backend/d646_3b_warm_inputs'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=prepared,check=True,stdout=subprocess.DEVNULL)
audit=read(prepared/'qualification.json');assert audit['passed'] and audit['audit']['inputs']['passed']
inputs=audit['audit']['inputs']
assert inputs['current_tokenizer_checked_requests']==4000 and inputs['measure_batches']==194
for ref in inputs['source_refs']+[inputs['index'],inputs['config']]:
    assert p.digest(Path(ref['path']))==ref['sha256']
assert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==audit['audit']['runner_sha256']
probe_dir=ROOT/'paper_results/ieee_tc/p2_backend/d647_3b_warm_probe'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=probe_dir,check=True,stdout=subprocess.DEVNULL)
probe=read(probe_dir/'qualification.json')
assert probe['passed'] and probe['audit']['native_checked']==32 and probe['audit']['batch_size']==8
assert probe['audit']['audit']['index_ref']==inputs['index']
assert p.digest(Path(probe['source_run']['path']))==probe['source_run']['sha256']
assert read(previous/'analysis_closure.json')['path_gone']
assert not Path(read(previous/'local_cleanup.json')['identity']['path']).exists()
''' +code[end:]
code=code.replace("'tc-d641-source'","'tc-d648-warm'")
code=code.replace("('start.py','remote_control.py','close.py')","('start.py','close.py')")
replace("input_qualification=audit['inputs']","input_qualification=inputs,capacity_probe_sha256=p.digest(probe_dir/'qualification.json')")
replace("subprocess.run([sys.executable,str(RAW/'remote_control.py'),'start'],check=True)\nsubprocess.run([sys.executable,str(RAW/'remote_control.py'),'health'],check=True,stdout=subprocess.DEVNULL)",
        "# GPU-ready warm reference has no remote service or network acquisition.")
replace('run_d298_capacity_source.sh d641','run_d298_capacity_source.sh d648')
ast.parse(code)
exec(compile(code,str(source),'exec'))
