"""Apply the existing D170/V1 round-mean recipe to fully audited 3B samples."""
import csv,json,math,os,statistics,subprocess,sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline');RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d648_3b_warm_measurement'
FROZEN=ROOT/'paper_results/ieee_tc/protocols/20261017_3b_slo_d648_frozen.json'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):
    assert path.stat().st_size<128*1024**2
    return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
def ref(path):return dict(path=str(path),sha256=p.digest(path))
identity=p.scope_identity(p.cg_path().name);save(RAW/'publication_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not OUT.exists() and not FROZEN.exists()
gate=p.preflight([ROOT,RAW],32*1024*1024);assert gate['preflight_pass'],gate['issues']
save(RAW/'publication_gate.json',gate)
closed=read(RAW/'analysis_closure.json');assert closed['passed'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
q=read(RAW/'qualification.json');audit=q['audit']
assert q['passed'] and q['current_warm_measured'] and q['native_checked']==1552
assert p.digest(RAW/'source1.json')==q['source_sha256']
data=read(RAW/'measurement_projection1.json');assert p.digest(RAW/'measurement_projection1.json')==audit['projection_sha256']
index_path=Path(audit['index_ref']['path']);index=read(index_path)
assert p.digest(index_path)==audit['index_ref']['sha256']==data['warm_reference_index_sha256']
assert data['profile']=='llama32_3b_main_modelscope' and data['trace']['source_sha256']==index['source']['source_sha256']
assert data['config_sha256']==p.digest(Path(index['source_refs'][-1]['path']))
assert data['check_source_sha256']==p.digest(ROOT/'scripts/ieee_tc_preflight.py')
assert data['model_config']['generation_contract']=='fixed_length_greedy_v1'
assert data['model_config']['enable_prefix_caching'] is False
assert data['model_config']['max_num_seqs']==data['model_config']['max_loras']==8
assert data['measurement_boundary']=='native_dispatch_to_native_tokens_no_prime_pending_admission'
assert data['artifact_mode']=='existing_local_frozen_qualification_only'
assert len(p.completed_warm_length_samples(data,index))==512
groups=[];thresholds=[]
for group in index['groups']:
    rows=sorted([r for r in audit['round_means'] if r['group_id']==group['group_id']],key=lambda r:r['round'])
    assert [r['round'] for r in rows]==[0,1,2] and all(r['count']==256 for r in rows)
    means={key:statistics.fmean(r[key+'_ms'] for r in rows) for key in ('ttft','tpot')}
    assert all(math.isfinite(v) and v>0 for v in means.values())
    threshold=dict(ttft=5*means['ttft'],tpot=2*means['tpot'])
    boundary=('<=%s'%group['upper_inclusive'] if group['lower_exclusive'] is None else '>%s'%group['lower_exclusive'])
    groups.append(dict(group_id=group['group_id'],native_input_boundary=boundary,
        round_means_ms=[dict(ttft=r['ttft_ms'],tpot=r['tpot_ms']) for r in rows],
        equal_weight_mean_ms=means,candidate_threshold_ms=threshold))
    thresholds.append(dict(lower_exclusive=group['lower_exclusive'],upper_inclusive=group['upper_inclusive'],
        ttft_ms=threshold['ttft'],tpot_ms=threshold['tpot']))
assert [g['upper_inclusive'] for g in thresholds]==[506,None]
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
v1=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')
v2=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')
assert v1==index['metric_protocol_sha256'] and v2==index['single_run_protocol_sha256']
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'native_audit.json',audit)
calibration=dict(campaign_id=RAW.name,kind='common_warm_reference_current_code_v1',model=data['profile'],
    status='calibration_candidate_complete',formal_g1_g2_qualified=False,plan_sha256=data['plan_sha256'],
    metric_protocol='primelora_tc_metrics_v1',metric_protocol_sha256=v1,single_run_amendment_sha256=v2,
    source_trace_sha256=data['trace']['source_sha256'],warm_reference_index_sha256=p.digest(index_path),
    source_execution_commit=q['source_execution_commit'],raw_result=str(RAW/'source1.json'),
    raw_result_sha256=q['source_sha256'],raw_result_bytes=(RAW/'source1.json').stat().st_size,
    independent_audit=str((OUT/'native_audit.json').relative_to(ROOT)),independent_audit_sha256=p.digest(OUT/'native_audit.json'),
    config_sha256=data['config_sha256'],preflight_source_sha256=data['check_source_sha256'],
    batch_size=8,warmup_requests=16,measurement_requests=1536,measurement_rounds=3,requests_per_group_round=256,
    groups=groups,contract=dict(native_pass=1536,target_match=1536,timing_contract='ieee_tc_native_v1',
        clock_domains=len({r['timing']['native_clock_id'] for r in data['requests']}),batch_records=194,release_records=1552,
        remote_delivery_enabled=False,prefix_caching=False),resource_audit=audit['resource'],
    physical_gpu_s=audit['physical_gpu_s'],interpretation='Common 3B GPU-ready metrology, not Full performance or a resource reference.')
assert calibration['contract']['clock_domains']==1
save(OUT/'warm_reference.json',calibration)
with (OUT/'samples.csv').open('x',newline='') as f:
    keys=('phase','round','group_id','batch_serial','source_index','source_request_id','adapter_id',
          'native_prompt_tokens','target_tokens','actual_tokens','ttft_ms','tpot_ms','pass_native')
    writer=csv.DictWriter(f,fieldnames=keys,lineterminator='\n');writer.writeheader()
    for r in data['requests']:writer.writerow({k:r[k] for k in keys})
freeze=dict(kind='common_slo_numeric_freeze_v1',reference_id='3b_vllm0300_d648_batch8_native_v1',date='2026-10-17',
    model=data['profile'],slo_reference_frozen=True,resource_reference_frozen=False,
    metric_protocol_sha256=v1,single_run_amendment_sha256=v2,
    calibration=dict(path=str((OUT/'warm_reference.json').relative_to(ROOT)),sha256=p.digest(OUT/'warm_reference.json'),
        audit_path=str((OUT/'native_audit.json').relative_to(ROOT)),audit_sha256=p.digest(OUT/'native_audit.json'),
        requests=1536,batch_size=8,prefix_caching=False,reuse_existing_completed_calibration=True),
    input_group_source='native actual prompt tokens; duplicate quartile boundaries merged',groups=thresholds,
    minimum_joint_count=3800,planned_count=4000,thresholds_common_to_all_systems=True,
    freeze_after_development_observations=True,historical_reuse_is_independent_holdout=False,
    reference_does_not_certify_test_run_correctness=True,
    scope='Common 3B evaluation thresholds only; not U_ref, G2 budget or system ranking.')
save(FROZEN,freeze)
save(RAW/'freeze_receipt.json',dict(passed=True,freeze=ref(FROZEN),calibration=ref(OUT/'warm_reference.json'),
    samples=ref(OUT/'samples.csv'),auditor=ref(OUT/'native_audit.json'),protected=protected,
    source=ref(RAW/'freeze.py'),metric_protocol_sha256=v1,single_run_amendment_sha256=v2))
print(json.dumps(dict(passed=True,groups=groups,freeze=ref(FROZEN))))
