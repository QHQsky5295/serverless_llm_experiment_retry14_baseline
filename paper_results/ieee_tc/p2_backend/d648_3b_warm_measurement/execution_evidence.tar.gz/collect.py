"""Reuse the native audit for all sealed 3B warm rounds, never a partial cohort."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d647_20261017/collect.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
begin=code.index("with (RAW/'tests.log').open('x')");end=code.index('from scripts.ieee_tc.audit_warm_measurement',begin)
code=code[:begin]+'''previous=read(RAW.parent/'d647_20261017/qualification.json')
assert previous['passed'] and previous['tests']==17
assert p.digest(ROOT/'scripts/ieee_tc/audit_warm_measurement.py')==previous['auditor_sha256']
assert p.digest(ROOT/'tests/test_ieee_tc_warm_reference.py')==previous['tests_sha256']
tests=17
''' +code[end:]
replace("index_path=index,phase='probe'","index_path=index,phase='measure'")
replace("checked['native_checked']==32 and checked['batch_checked']==4","checked['native_checked']==1552 and checked['batch_checked']==194")
replace("checked['measured']==0 and not checked['round_means']","checked['measured']==1536 and checked['warmup']==16 and len(checked['round_means'])==6")
replace("kind='d647_current_3b_warm_capacity_v1'","kind='d648_current_3b_warm_measurement_v1'")
replace("native_checked=32,batch_checked=4,batch_size=8,batches=batch_summary","native_checked=1552,measured=1536,warmup=16,batch_checked=194,batch_size=8,batches=batch_summary")
replace("current_warm_measured=False,thresholds=None","current_warm_measured=True,thresholds=None")
replace("print(json.dumps(dict(passed=True,tests=tests,native_checked=32,batches=batch_summary,\n    physical_gpu_s=checked['physical_gpu_s'],resource=checked['resource'])))",
        "print(json.dumps(dict(passed=True,tests_reused=tests,native_checked=1552,measured=1536,batch_checked=194,round_means=checked['round_means'],physical_gpu_s=checked['physical_gpu_s'],resource=checked['resource'])))")
ast.parse(code)
exec(compile(code,str(source),'exec'))
