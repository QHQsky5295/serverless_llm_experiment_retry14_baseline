#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d153_20261002
unit=primelora-d153-verify2-20261002.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/verify2_scope.txt"
export PYTHONPATH="$PWD" PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES=''
exec /usr/bin/time -v -o "$raw/verify2_time.txt" /usr/bin/python3 "$raw/verify_qualification.py" > "$raw/verify2.log" 2>&1
