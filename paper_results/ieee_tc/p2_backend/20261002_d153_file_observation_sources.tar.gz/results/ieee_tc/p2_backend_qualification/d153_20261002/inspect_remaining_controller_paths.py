"""Reuse D147/D143 bounded historical reader; resolve remaining caller ambiguity.

Not a new replay/profile or CPU-time estimate. No serving changes or GPU use.
"""
import ast
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
prior = root/'results/ieee_tc/p2_backend_qualification/d143_20261001'
raw = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('d143_reader', prior/'collect_prefix1_cpu.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
summary_path = prior/'prefix1_cpu_samples.json'
assert reader.digest(summary_path) == '1f48bcc5b5ea6832bd913098656f18f27c057bffa3257c79b20459a2477509be'
summary = json.loads(summary_path.read_text())
process = next(p for p in summary['processes'] if p['pid'] == 1586316)
for item in process['source_refs']:
    assert reader.digest(Path(item['path'])) == item['sha256']
evidence = prior/'7b_full_w0_prefix1/launch.launch'
receipt_path = evidence/'exec_receipt.json'
terminals_path = evidence/'physical_deployment/request_terminals.jsonl'
receipt = json.loads(receipt_path.read_text())
terminals = [r for r, partial in reader.rows(terminals_path) if not partial]
assert len(terminals) == len({r['request_id'] for r in terminals}) == 1000
assert all(r['clock_id'] == receipt['external_replay']['clock_id'] for r in terminals)
start = receipt['external_replay']['replay_t0_s']
end = max(r['at'] for r in terminals)
meta_path = evidence/'diagnostic_stacks/1586316-34561749.json'
meta = json.loads(meta_path.read_text())
targets = {
    'faaslora/memory/residency_manager.py': {'source_snapshot','_local_file_inventory'},
    'faaslora/experiment/instance_pool.py': {'_footprints'},
    'faaslora/preloading/preloading_planner.py': {
        'owned_file_execution_objective','owned_gpu_execution_objective'},
}
historical_commit = 'a494c90c017e5307ff59f1d9ff7c4dde214d6bbf'
definitions = {}
source_identity = {}
def functions(tree, parents=()):
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                yield '.'.join(parents+(node.name,)), node
            yield from functions(node, parents+(node.name,))
        else:
            yield from functions(node, parents)
for name, names in targets.items():
    old = subprocess.check_output(['git','show',f'{historical_commit}:{name}'])
    current = (root/name).read_bytes()
    old_defs = dict(functions(ast.parse(old)))
    new_defs = dict(functions(ast.parse(current)))
    definitions[name] = [(qualified,node) for qualified,node in old_defs.items()
                         if node.name in names]
    source_identity[name] = dict(historical_sha256=hashlib.sha256(old).hexdigest(),
        current_sha256=hashlib.sha256(current).hexdigest(), definitions={
            qualified: dict(historical_start=node.lineno,historical_end=node.end_lineno,
                current_ast_identical=qualified in new_defs and
                    ast.dump(node)==ast.dump(new_defs[qualified]))
            for qualified,node in definitions[name]})
counts = Counter()
details = Counter()
examples = {}
main_count = 0
for row, partial in reader.rows(meta_path.with_suffix('.stacks.jsonl')):
    assert not partial
    if not start <= row['observed_monotonic_s'] <= end:
        continue
    main, = [t for t in row['threads'] if t['ident'] == meta['main_thread_ident']]
    main_count += 1
    frames = main['frames']
    for i,(file,name,line) in enumerate(frames):
        relative = file.removeprefix(str(root)+'/')
        if relative not in targets or name not in targets[relative]:
            continue
        matched = [q for q,n in definitions[relative]
                   if n.name == name and n.lineno <= line <= n.end_lineno]
        assert len(matched)==1, (relative,name,line)
        qualified, = matched
        caller = frames[i+1] if i+1<len(frames) else ['','truncated',0]
        label = relative+':'+qualified
        counts[label] += 1
        details[(label, caller[0], caller[1], caller[2])] += 1
        if label not in examples:
            examples[label] = dict(index=row['index'],at=row['observed_monotonic_s'],
                truncated=main['truncated'], frames=frames[:min(len(frames),i+5)])
assert main_count==570
new_full = root/'paper_results/ieee_tc/p2_backend/20261002_d152_7b_full_w0_full1.json'
assert reader.digest(new_full)=='6a1cd918beb5df1331b7a41725af7531335e25321fe1fce65e7ada7bdc21b5e7'
result = dict(kind='d153_remaining_controller_caller_audit_v1',
    historical_commit=historical_commit,
    current_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    request_window_main_samples=main_count, historical_window=dict(start_s=start,end_s=end),
    inclusive_counts=dict(counts), caller_counts=[dict(frame=k[0],caller_file=k[1],
        caller_function=k[2],caller_line=k[3],samples=n) for k,n in details.most_common()],
    examples=examples, source_identity=source_identity,
    caveats=['Historical GIL-scheduled stack occurrence is not CPU/wall time or current frequency.',
             'Unchanged AST does not prove unchanged timing or whole-system causality.',
             'Overlapping inclusive frames must not be summed as disjoint work.',
             'No new GPU replay, profiler, weights, traces, cache publication or serving edit.'],
    source_refs=[dict(path=str(p),sha256=reader.digest(p)) for p in (
        summary_path,meta_path,meta_path.with_suffix('.stacks.jsonl'),receipt_path,
        terminals_path,prior/'collect_prefix1_cpu.py',Path(__file__),new_full,
        root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
        Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))],
    formal_performance_result=False)
out = raw/'remaining_controller_callers.json'
with out.open('x') as handle:
    json.dump(result,handle,indent=2,allow_nan=False)
print(json.dumps({k:result[k] for k in ('request_window_main_samples','inclusive_counts','caller_counts','source_identity')},indent=2))
