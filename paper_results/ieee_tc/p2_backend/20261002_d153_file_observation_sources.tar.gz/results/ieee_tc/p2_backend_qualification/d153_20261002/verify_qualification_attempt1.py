"""Reuse D151 qualification/seal procedure; only bounded small evidence."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root=Path.cwd()
raw=root/'results/ieee_tc/p2_backend_qualification/d153_20261002'
out=root/'paper_results/ieee_tc/p2_backend'
parent='53efe130e6871d387af128c3101aed4cef635b30'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
changed={'faaslora/memory/residency_manager.py','tests/test_ieee_tc_transfer_pressure.py'}
prior=root/'results/ieee_tc/p2_backend_qualification/d152_20261002/prelaunch_verification.json'
sources=json.loads(prior.read_text())['source_sha256']
for name,sha in sources.items():
    path=Path(name) if name.startswith('/') else root/name
    relative=str(path.relative_to(root)) if path.is_relative_to(root) else None
    actual=hashlib.sha256(subprocess.check_output(['git','show',f'{parent}:{relative}'])).hexdigest() if relative in changed else digest(path)
    assert actual==sha,name
attempts={}
for phase,count in (('targeted1',18),('regression1',813),('micro1',None)):
    unit=f'primelora-d153-{phase}-20261002.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
    assert not subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','--value'],text=True).strip()
    scope=(raw/f'{phase}_scope.txt').read_text()
    identity=re.search(r'^InvocationID=([a-f0-9]{32})$',scope,re.M).group(1)
    cg=re.search(r'^ControlGroup=(.+)$',scope,re.M).group(1)
    assert not Path('/sys/fs/cgroup'+cg).exists()
    assert all(line in scope for line in ('MemoryHigh=3221225472','MemoryMax=4294967296','MemorySwapMax=0'))
    cleanup=(raw/f'{phase}_cleanup.txt').read_text()
    assert f'actual_invocation={identity}' in cleanup
    assert 'cleanup=automatic_removal_verified' in cleanup
    assert 'final_memory_events=unavailable_after_removal' in cleanup
    timing=(raw/f'{phase}_time.txt').read_text()
    assert 'Exit status: 0' in timing
    match=re.search(rf'Ran {count} tests in ([\d.]+)s\n\nOK\n',(raw/f'{phase}.log').read_text()) if count else None
    assert count is None or match,phase
    for line in (raw/f'{phase}_sources.sha256').read_text().splitlines():
        sha,name=line.split(maxsplit=1)
        assert digest(root/name)==sha,(phase,name)
    attempts[phase]=dict(tests=count,exit_code=0,test_seconds=float(match.group(1)) if match else None,
        command_wall=re.search(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\): (.+)',timing).group(1),
        peak_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',timing).group(1)),
        invocation_id=identity,cleanup='automatic_removal_verified',final_memory_events=None)
component=json.loads((raw/'file_observation_component.json').read_text())
assert len(component['rows'])==12 and all(r['exact_except_capture_times'] for r in component['rows'])
for row in component['source_refs']:
    assert digest(Path(row['path']))==row['sha256']
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
files=[root/p for p in sorted(changed|{'tests/test_ieee_tc_file_observation.py'})]
files+=[root/'docs/ieee_tc/D153_FILE_OBSERVATION_DIAGNOSIS.md']
files+=[raw/name for name in ('inspect_remaining_controller_paths.py','remaining_controller_callers.json',
    'run_tests.sh','cleanup_test.sh','compare_observation.py','file_observation_component.json',
    'verify_qualification.py','run_verification.sh')]
for phase in attempts:
    files+=[raw/f'{phase}{suffix}' for suffix in ('.log','_time.txt','_scope.txt','_cleanup.txt','_sources.sha256')]
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for path in files:
    assert path.stat().st_size<4*1024**2,path
    payload=path.read_bytes()
    assert secret not in payload,path
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in payload.splitlines()),path
    if path.suffix=='.py': compile(payload,str(path),'exec')
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
result=dict(kind='d153_fresh_file_observation_qualification_v1',parent_commit=parent,
    decision='qualified_for_ordinary_full_not_performance_acceptance',attempts=attempts,
    component=component,caller_audit=json.loads((raw/'remaining_controller_callers.json').read_text()),
    cuda_executed=False,formal_performance_result=False,performance_gain_established=False,
    retry_or_timeout_changed=False,equations_changed=False,budgets_changed=False,
    cross_call_cache_added=False,execution_physical_checks_preserved=True,
    full_replay_status='pending',protected=protected,prelaunch_sources_verified=len(sources),
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
curated=out/'20261002_d153_file_observation.json'
with curated.open('x') as stream: json.dump(result,stream,indent=2,allow_nan=False)
files.append(curated)
bundle=out/'20261002_d153_file_observation_sources.tar.gz'
with bundle.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for path in files: archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers())==len(files)
    for member,path in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==digest(path)
with (out/'20261002_d153_file_observation_sources.sha256').open('x') as stream:
    stream.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,regression_tests=813)))
