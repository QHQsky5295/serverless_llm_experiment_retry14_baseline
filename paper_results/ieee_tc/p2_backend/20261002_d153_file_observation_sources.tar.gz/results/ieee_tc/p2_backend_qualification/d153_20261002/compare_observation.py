"""Bounded component equivalence/metadata counts, NOT a serving experiment."""
import ast
from collections import Counter
import contextlib
import hashlib
import io
import json
from pathlib import Path
import statistics
import subprocess
import time
import types
from unittest.mock import patch

from faaslora.memory import residency_manager as module
from tests.test_ieee_tc_file_observation import FreshFileObservation, without_capture_times

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = Path(__file__).resolve().parent
old_commit = '53efe130e6871d387af128c3101aed4cef635b30'
old_source = subprocess.check_output(['git','show',old_commit+':faaslora/memory/residency_manager.py'])
tree = ast.parse(old_source)
cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name=='LocalSourceReferences')
namespace = dict(module.__dict__)
for name in ('preparation_snapshot','_settle_file_allocations'):
    node = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name==name)
    exec(compile(ast.Module(body=[node],type_ignores=[]), '<D152-parent:'+name+'>','exec'), namespace)

rows = []
for count in (4,500):
    case = FreshFileObservation()
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            fixture, owner, manifests, limits = case.make()
        manifests.update({f'absent-{i}': dict(manifests['a']) for i in range(count-4)})
        # Warm filesystem observations, not model/adapter inference.
        owner.preparation_snapshot(manifests=manifests, limits=limits)
        old = types.MethodType(namespace['preparation_snapshot'], owner)
        settle = types.MethodType(namespace['_settle_file_allocations'], owner)
        observed = {}
        for repeat in range(3):
            order = ('legacy','candidate') if repeat%2==0 else ('candidate','legacy')
            for variant in order:
                calls = Counter()
                original_stat = Path.stat
                original_inventory = module._local_file_inventory
                def counted_stat(path, *args, **kwargs):
                    calls['path_stat'] += 1
                    return original_stat(path, *args, **kwargs)
                def counted_inventory(*args, **kwargs):
                    calls['inventory'] += 1
                    return original_inventory(*args, **kwargs)
                with contextlib.ExitStack() as stack:
                    stack.enter_context(patch.object(Path,'stat',counted_stat))
                    stack.enter_context(patch.object(module,'_local_file_inventory',counted_inventory))
                    if variant=='legacy':
                        stack.enter_context(patch.object(owner,'_settle_file_allocations',settle))
                    started = time.perf_counter()
                    value = (old if variant=='legacy' else owner.preparation_snapshot)(
                        manifests=manifests, limits=limits)
                    elapsed = time.perf_counter()-started
                normalized = without_capture_times(value)
                if observed:
                    assert normalized==observed, (count,repeat,variant)
                observed=normalized
                rows.append(dict(logical_candidates=count,actual_confirmed_trees=len(owner._confirmed_sources),
                    repeat=repeat,variant=variant,elapsed_seconds=elapsed,counts=dict(calls),
                    exact_except_capture_times=True))
    finally:
        case.doCleanups()

groups=[]
for count in (4,500):
    for variant in ('legacy','candidate'):
        matches=[r for r in rows if r['logical_candidates']==count and r['variant']==variant]
        assert len({json.dumps(r['counts'],sort_keys=True) for r in matches})==1
        groups.append(dict(logical_candidates=count,variant=variant,repeats=len(matches),
            mean_seconds=statistics.mean(r['elapsed_seconds'] for r in matches),
            counts=matches[0]['counts']))
sources=[Path(__file__),root/'faaslora/memory/residency_manager.py',
         root/'tests/test_ieee_tc_file_observation.py',root/'tests/test_ieee_tc_transfer_pressure.py',
         raw/'remaining_controller_callers.json',root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
         Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')]
result=dict(kind='d153_file_observation_component_v1',old_commit=old_commit,
    old_source_sha256=hashlib.sha256(old_source).hexdigest(),groups=groups,rows=rows,
    inference=False,formal_result=False,
    caveats=['Tiny existing publication fixture; 500 names are metadata test candidates, not new LoRA weights or trace.',
             'Instrumented local component timings; not GPU, remote, serving latency or independent runs.',
             'Operation counts include Python wrappers; no extrapolation to total TTFT.',
             'Both functions use current unchanged inventory/source checks; original settlement restored for legacy.'],
    source_refs=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources])
with (raw/'file_observation_component.json').open('x') as handle:
    json.dump(result,handle,indent=2,allow_nan=False)
print(json.dumps(groups,indent=2))
