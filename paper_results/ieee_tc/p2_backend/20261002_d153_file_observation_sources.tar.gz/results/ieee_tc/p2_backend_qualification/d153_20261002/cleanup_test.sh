#!/usr/bin/env bash
# Verify actual post-exit removal; never stops a live job.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
expected_id=$2
code=$3
case "$phase" in targeted1|targeted2|regression1|micro1|preflight1|preflight2|verify1|verify2) ;; *) exit 2;; esac
[[ "$expected_id" =~ ^[a-f0-9]{32}$ ]]
[[ "$code" =~ ^[01]$ ]]
raw=results/ieee_tc/p2_backend_qualification/d153_20261002
unit="primelora-d153-${phase}-20261002.scope"
{
date -Is
rg -qx "InvocationID=$expected_id" "$raw/${phase}_scope.txt"
rg -q "Exit status: $code" "$raw/${phase}_time.txt"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
printf 'actual_invocation=%s\nexit_code=%s\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n' "$expected_id" "$code"
} | tee "$raw/${phase}_cleanup.txt"
