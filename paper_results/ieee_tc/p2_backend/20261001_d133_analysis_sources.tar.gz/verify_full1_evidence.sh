#!/usr/bin/env bash
# Reuse D115 evidence closure for the interrupted D133 result schema.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d133_20261001
unit=primelora-d133-full1-evidence-20261001.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_evidence_scope.txt"
export PYTHONUNBUFFERED=1
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest tests.test_ieee_tc_gpu_lifecycle tests.test_ieee_tc_external_replay tests.test_ieee_tc_native_timing -v
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python - <<'PY'
import json, subprocess
from pathlib import Path
import json, subprocess, hashlib
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d133_20261001'
before = json.loads((raw/'prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    p = Path(name) if name.startswith('/') else root/name
    assert digest(p) == expected, name
full = root/'paper_results/ieee_tc/p2_backend/20261001_d133_7b_full_w0_interrupted.json'
assert digest(full) == '9a86da955c7dc9b8d83bc2020fe8d1a138170247a485aa6b0e16265c2575f95a'
x = json.loads(full.read_text())
assert not x['full_replay_qualified'] and not x['formal_performance_result']
assert x['population']['planned'] == 4000 and x['population']['terminal_records'] == 518
assert x['population']['success_native_contract'] == 452 and x['population']['cancelled'] == 66
assert x['population']['arrived'] == 581 and x['population']['submitted'] == 570
assert sum(x['population'][k] for k in ('success_native_contract','cancelled',
    'publisher_submitted_without_service_terminal','publisher_created_not_submitted','never_arrived')) == 4000
assert x['physical_gpu_seconds'] is None and not x['all_allocations_released']
assert len(x['open_lease_ids']) == 4 and not x['cleanup_complete']
assert x['actual_native_process_cleanup_confirmed']
assert x['resources']['samples'] == 789 and x['resources']['peak_bytes'] == 22096293888
assert all(v == 0 for v in x['resources']['events'].values())
assert x['resources']['max_swap_bytes'] == x['resources']['warnings'] == 0
assert x['resources']['abort_events'] == []
assert x['remote']['uuid_pairs'] == 47 and x['remote']['states'] == dict(published=47)
assert x['remote']['client_received_bytes'] == x['remote']['server_socket_written_bytes'] == 64753815
assert x['remote']['request_packing'] == 0
assert x['primary_service_error']['type'] == 'UnresolvedTransferOperation'
assert 'native integer ID reused for a different adapter source' in x['primary_service_error']['traceback']
assert len(x['unresolved_native_host_preparations']) == 1
failed = x['unresolved_native_host_preparations'][0]
assert failed['adapter_id'] == 'medical_lora_0014'
assert failed['plan_id'] == '91755aed1ab846b3b3e40a3f8af43bf9'
assert failed['attempts'][0]['command']['adapter_int_id'] == 683755
assert failed['attempts'][0]['command']['expected_epoch'] == 1411
for row in x['cleanup']['roots']:
    p = Path(row['path']); st = p.stat()
    assert p.is_dir() and not p.is_symlink() and st.st_dev == row['device'] and st.st_ino == row['inode']
launch = json.loads((raw/'7b_full_w0_full1/launch.json').read_text())
assert not launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert (launch['service_returncode'],launch['replay_returncode'],launch['watchdog_returncode']) == (-15,1,0)
checked = 0
for name, expected in x['source_sha256'].items():
    p = root/name
    assert digest(p) == expected, name
    checked += 1
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == x['metric_protocol_sha256']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
projection = raw/'full_full1_outcome_projection.json'
assert digest(projection) == 'a9c0ce5096d9861559e6bfc3420ac75c14ad5734e64c2a9a9ee11ac8bad336b4'
assert 'Exit status: 0' in (raw/'full_full1_outcome_projection_time.txt').read_text()
assert 'Exit status: 0' in (raw/'interrupted_curation_time.txt').read_text()
# D131 fixture check adapted to the actual interrupted-request schema.
fixture = dict(kind='fixture',error=dict(type='failed'),interrupted_replays=[
    dict(submitted_count=2,requests=[
        dict(request_id='r0',success=True,tokens=[1,2],gpu_reference_evidence=dict(
            source_admission=dict(tier='host'),generation_submission=dict(state='submitted'),
            prior_routing_attempts=[dict(x=1),dict(x=2)],huge_inventory=[dict(x=9)])),
        dict(request_id='r1',success=False,error='CancelledError')],unsubmitted_request_ids=['r2'])],
    completed_scenario_windows=dict(requests=[]))
jq_filter = raw/'project_full1_outcome.jq'
res = subprocess.run(['jq','--stream','-n','-f',str(jq_filter)],
    input=json.dumps(fixture),text=True,capture_output=True,check=True)
y = json.loads(res.stdout)
assert y['error'] == fixture['error'] and y['requests'] == []
ir = y['interrupted_replays'][0]
assert ir['unsubmitted_request_ids'] == ['r2'] and ir['submitted_count'] == 2
assert len(ir['requests']) == 2 and ir['requests'][1]['error'] == 'CancelledError'
r = ir['requests'][0]
assert r['tokens'] == [1,2] and r['prior_routing_attempt_count'] == 2
assert r['retained_reference_evidence']['source_admission'] == dict(tier='host')
assert 'gpu_reference_evidence' not in r and 'huge_inventory' not in r
refs = [full,raw/'collect_interrupted_full1.py',raw/'verify_full1_evidence.sh',
    raw/'project_full1_outcome.jq',raw/'project_full1_outcome.sh',
    raw/'full_full1_outcome_projection_time.txt',raw/'interrupted_curation_time.txt',
    raw/'cleanup_failed_projection.sh',raw/'cleanup_interrupted_curation.sh',
    root/'tests/test_ieee_tc_gpu_lifecycle.py',root/'tests/test_ieee_tc_external_replay.py',
    root/'tests/test_ieee_tc_native_timing.py',root/'docs/ieee_tc/D133_INTERRUPTED_FULL_W0_FULL1.md']
receipt = dict(kind='d133_interrupted_evidence_verification_v1',pass_checks=True,
    full_qualified=False,formal_performance_result=False,projection_fixture_pass=True,
    frozen_source_refs_checked=len(before['source_sha256']),curated_source_refs_rehashed=checked,
    source_commit=before['runtime_source_commit'],protected=protected,
    refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
out = root/'paper_results/ieee_tc/p2_backend/20261001_d133_evidence_verification.json'
with out.open('x') as handle: json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(out),sha256=digest(out),frozen_sources=len(before['source_sha256']),
    curated_sources_rehashed=checked,protected=147)))
PY
