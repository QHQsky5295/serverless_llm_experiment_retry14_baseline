#!/usr/bin/env bash
set -euo pipefail
unit=primelora-d133-failed-project-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 07e45f926161471b89941df51baa9b97
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d133-failed-project-20261001.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
