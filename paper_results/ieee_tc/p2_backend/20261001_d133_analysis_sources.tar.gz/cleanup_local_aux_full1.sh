#!/usr/bin/env bash
set -euo pipefail
# Reuse D133 exact-identity / empty-domain cleanup; only D133 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-e2d45b22d09549a899b629ad1138844d.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-d2c9011443d5471486d6fabd23608bfb.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 99fec8e48d894e349d535f667752d9cd
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-d2c9011443d5471486d6fabd23608bfb.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
