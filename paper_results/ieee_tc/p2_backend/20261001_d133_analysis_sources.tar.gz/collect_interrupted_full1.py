"""Reuse D105 interrupted-run curator and D115 bounded projection for D133."""
import collections
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts.ieee_tc_preflight import verify_seal, digest
raw = Path(__file__).parent
e = raw/'7b_full_w0_full1/launch.launch'
assert subprocess.check_output(['systemctl','--user','show',
    'primelora-tc-svc-e2d45b22d09549a899b629ad1138844d.scope','-p','ActiveState','--value'],text=True).strip() == 'inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
projection = raw/'full_full1_outcome_projection.json'
assert 'Exit status: 0' in (raw/'full_full1_outcome_projection_time.txt').read_text()
assert 0 < projection.stat().st_size < 256 * 1024**2
x = json.loads(projection.read_text())
p = json.loads((e/'physical_deployment/summary.json').read_text())
launch = json.loads((raw/'7b_full_w0_full1/launch.json').read_text())
rows = [json.loads(l) for l in (e/'physical_deployment/request_terminals.jsonl').open()]
replay = [json.loads(l) for l in (e/'replay.jsonl').open()]
incomplete = [r for r in replay if r['event']=='replay_incomplete']
assert len(incomplete) == 1
assert incomplete[0]['N_plan'] == x['planned_request_count'] == p['n_plan'] == 4000
assert len(rows) == len({r['request_id'] for r in rows}) == 518
assert sum(r['success'] for r in rows) == sum(r['native_contract_matched'] for r in rows) == 452
assert sum(r['error_type']=='CancelledError' for r in rows) == 66
assert p['n_terminal']==452 and p['n_interrupted']==66
assert x['error']['type'] == 'UnresolvedTransferOperation'
assert x['error']['message'] == 'native HOST loading/release outcome unresolved'
assert 'native integer ID reused for a different adapter source' in x['error']['traceback']
assert not x['run_completed'] and not x['formal_comparison_qualified']
assert not x['cleanup']['complete'] and x['cleanup_errors'] and not x['measurement_errors']
assert all(Path(r['path']).is_dir() for r in x['cleanup']['roots'])
assert len(p['open_lease_ids']) == 4 and all(not r['released'] for r in p['allocation_journals'])
assert p['gpu_seconds'] is None and not p['measurement_complete']
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
remote = [json.loads(l) for l in (raw/'remote_7b_full1_transfers.jsonl').open()]
by = {r['transfer_id']:r for r in remote}
t = x['remote_transfers']
assert len(by)==len(remote)==len(t)>0 and set(by)=={r['http_transfer_id'] for r in t}
for r in t:
    peer = by[r['http_transfer_id']]
    assert peer['artifact_id']==r['artifact_id']
    assert peer['clock_id']=='remote-process-monotonic:2f188cc5ae31494abc34cc7425acde71'
    assert not peer['pack_performed'] and not peer['temporary_created']
    if r['state']=='published':
        assert peer['bytes_written']==r['transferred_bytes']
        assert r['content_verified'] and r['published_archive_verified']
        assert r['payload_bytes_verified']==r['payload_bytes_expected']
    else:
        assert r['state']=='not_published' and r['content_verified'] is False
        assert 0<=r['transferred_bytes']<=peer['bytes_written']
resources = dict(samples=0,peak_bytes=0,min_host_available_bytes=2**63,
    events={},max_swap_bytes=0,warnings=0,abort_events=[])
for line in (e/'watchdog.jsonl').open():
    r=json.loads(line)
    if r['event']=='watchdog_abort':resources['abort_events'].append(r)
    if r['event']!='resource_sample':continue
    resources['samples']+=1
    assert not r['decision']['abort_reasons']
    resources['warnings']+=int(r['decision']['warning'])
    resources['peak_bytes']=max(resources['peak_bytes'],r['service']['memory.peak'])
    resources['min_host_available_bytes']=min(resources['min_host_available_bytes'],r['host']['available_bytes'])
    resources['max_swap_bytes']=max(resources['max_swap_bytes'],r['service']['memory.swap.current'])
    for k in ('high','max','oom','oom_kill'):
        resources['events'][k]=max(resources['events'].get(k,0),r['service']['memory.events'].get(k,0))
plans=[]
for plan in x['mechanism_events']['_ieee_gpu_preparation_plans']:
    plans.append({**{k:plan.get(k) for k in ('plan_id','state','error_type','objective_sha256',
        'owner_id','target_replica','started_at','finished_at')},
        'attempt_states':dict(collections.Counter(a['state'] for a in plan['attempts'])),
        'unresolved_attempts':[{k:a.get(k) for k in ('adapter_int_id','attempt_id','lease_id','state')}
            for a in plan['attempts'] if a['state']=='native_outcome_unresolved'],
        'registration_keys':sorted(plan['registration']),
        'close_receipt':plan.get('close_receipt'), 'close_receipt_present':'close_receipt' in plan})
before=json.loads((raw/'prelaunch_verification.json').read_text())
for name,expected in before['source_sha256'].items():
    assert digest(Path(name) if name.startswith('/') else ROOT/name)==expected,name
seal=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert seal['pass'] and seal['entry_count']==147
refs=[Path(__file__),raw/'prelaunch_verification.json',raw/'7b_full_w0_full1/launch.json',
    raw/'remote_activation.txt',raw/'stop_services_full1.log',
    raw/'remote_7b_full1_transfers.jsonl',raw/'remote_monitor_full1_final.log',
    raw/'remote_copy_receipt.txt',raw/'stop_remote_after_full1.sh',raw/'stop_services_full1.sh',
    raw/'cleanup_local_aux_full1.sh',projection,raw/'project_full1_outcome.sh',
    raw/'project_full1_outcome.jq',raw/'full_full1_outcome_projection_time.txt']
refs += [e/name for name in ('service.log','watchdog.jsonl','watchdog.stderr','replay.jsonl',
    'service_ingress.jsonl','physical_deployment/main_outcome.json','physical_deployment/summary.json',
    'physical_deployment/request_terminals.jsonl')]

result=dict(kind='d133_interrupted_7b_full_v1',
    evidence_commit='30b07158788d080e5c51b93eedfa59a0a02bb2ca',
    runtime_source_commit='30b07158788d080e5c51b93eedfa59a0a02bb2ca',
    production_changed=False,formal_performance_result=False,full_replay_qualified=False,
    population=dict(planned=4000,arrived=incomplete[0]['N_arrived'],submitted=incomplete[0]['N_submitted'],
        terminal_records=len(rows),success_native_contract=452,cancelled=66,failed_untyped=0,
        physical_terminal_noninterrupted=p['n_terminal']),
    failed_request_records=[r for r in rows if not r['success']],
    primary_service_error={**x['error'],'message':x['error']['message'].splitlines()[0]},
    outer_launcher=dict(classification=launch['classification'],error=launch['error'],
        service_returncode=launch['service_returncode'],replay_returncode=launch['replay_returncode']),
    profiler=dict(enabled=False, reason='Ordinary Full, no detailed profiler or diagnostic prefix'),
    physical_gpu_seconds=None,physical_gpu_seconds_observed=p['gpu_seconds_observed'],
    window_gpu_seconds=p['window_gpu_seconds'],allocations=len(p['allocation_journals']),
    all_allocations_released=False,cleanup_complete=False,
    actual_native_process_cleanup_confirmed=True,open_lease_ids=p['open_lease_ids'],
    cleanup=x['cleanup'],cleanup_errors=x['cleanup_errors'],resources=resources,
    remote=dict(uuid_pairs=len(t),request_packing=0,
        states=dict(collections.Counter(r['state'] for r in t)),
        client_received_bytes=sum(r['transferred_bytes'] for r in t),
        server_socket_written_bytes=sum(r['bytes_written'] for r in remote)),gpu_plans=plans,
    native_host_preparations=[{**{k:r.get(k) for k in ('adapter_id','target_replica','source_path','plan_id')},
        'attempt_count':len(r['attempts']), 'attempt_states':[a['state'] for a in r['attempts']]}
        for r in x['mechanism_events']['_ieee_native_host_preparations']],
    cause_boundary='Native source-binding guard also checks live preparation ownership. Error proves rejection, not wrong weights or the exact old/new binding. Failed command and actual prior observations must be joined before choosing a fix.',
    protected=seal,unchanged_sources=len(before['source_sha256']),
    metric_protocol_sha256=before['metric_protocol_sha256'],
    source_sha256={str(p.relative_to(ROOT)):digest(p) for p in refs},
    next='Finish failure table and verified backup, then reconstruct native binding and preparation-owner lifetimes; no guard removal, new optimizer or blind replay')
assert len(x['interrupted_replays']) == 1
ir = x['interrupted_replays'][0]
assert ir['complete'] is False and ir['planned_request_count'] == 4000
requests = ir['requests']
assert ir['submitted_count'] == len(requests) == len(rows) == 518
assert not ir['collection_errors']
assert {r['request_id'] for r in requests} == {r['request_id'] for r in rows}
by_request = {r['request_id']: r for r in requests}
for terminal in rows:
    request = by_request[terminal['request_id']]
    assert request['success'] == terminal['success']
    if terminal['success']:
        assert request['generation_contract'] == 'fixed_length_greedy_v1'
        assert request['completion_token_source'] == 'vllm_token_ids'
        assert request['output_contract_match'] is True
        assert request['completion_tokens'] == terminal['target_tokens'] == request['requested_completion_tokens']
        assert request['completion_token_ids_sha256'] == terminal['completion_token_ids_sha256']
        assert request['canonical_prompt_sha256'] == terminal['canonical_prompt_sha256']
assert len(ir['unsubmitted_request_ids']) == len(set(ir['unsubmitted_request_ids'])) == 3482
assert not set(ir['unsubmitted_request_ids']) & set(by_request)
result['population'].update(service_started=518,service_unstarted=3482,
    publisher_created_not_submitted=incomplete[0]['N_arrived']-incomplete[0]['N_submitted'],
    publisher_submitted_without_service_terminal=incomplete[0]['N_submitted']-len(rows),
    never_arrived=4000-incomplete[0]['N_arrived'],numerical_adapter_correctness_qualified=False)
result['failure_classification'] = 'system_service_invariant_rejection_then_interrupted_replay'
result['classification_caveat'] = 'No watchdog OOM/resource abort; source conflict root cause requires identity/ownership reconstruction.'
result['qualification_caveat'] = 'All 4000 remain offered denominator. Unarrived/unstarted are not invented timeouts. U_obs is censored, not full cost. No conditional-latency comparison.'
result['interrupted_replay_metadata'] = {k:v for k,v in ir.items() if k not in ('requests','unsubmitted_request_ids')}
result['mechanism_state_counts'] = {k:dict(collections.Counter(r.get('state','not_a_state_event') for r in v))
    for k,v in x['mechanism_events'].items() if isinstance(v,list)}
result['unresolved_native_host_preparations'] = []
for record in x['mechanism_events']['_ieee_native_host_preparations']:
    attempts = [a for a in record['attempts'] if a['state']=='native_outcome_unresolved']
    if attempts:
        result['unresolved_native_host_preparations'].append({
            **{k:v for k,v in record.items() if k != 'attempts'}, 'attempts':attempts})
result['source_observation_stats'] = x['mechanism_events']['_ieee_source_observation_stats']
result['outer_launcher']['service_returncode_caveat'] = 'Supervisor -15 followed controller error/replay connection loss; not a normal completion.'

out=ROOT/'paper_results/ieee_tc/p2_backend/20261001_d133_7b_full_w0_interrupted.json'
with out.open('x') as h:json.dump(result,h,indent=2,allow_nan=False)
assert json.loads(out.read_text())==result
print(json.dumps({k:result[k] for k in ('population','primary_service_error','physical_gpu_seconds_observed',
    'allocations','resources','remote')}))
print(json.dumps(dict(output=str(out),sha256=digest(out),protected=147,unchanged_sources=len(before['source_sha256']))))
