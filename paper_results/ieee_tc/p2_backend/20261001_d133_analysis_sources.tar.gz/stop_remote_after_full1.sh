#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
# Prepared during replay, NEVER execute before terminal/physical cleanup.
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d133_20261001
test -s "$raw/7b_full_w0_full1/launch.json"
test "$(systemctl --user show primelora-tc-svc-e2d45b22d09549a899b629ad1138844d.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
jq -e '.native_gpu_context_release_confirmed == true and .service_path_removed == true' "$raw/7b_full_w0_full1/launch.json"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 primelora-artifact-174 bash -s < "$raw/stop_services_full1.sh" > "$raw/stop_services_full1.log" 2>&1
