#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d133_20261001
source_file="$raw/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json"
target="$raw/full_full1_outcome_projection.json"
test -s "$raw/7b_full_w0_full1/launch.json"
test -s "$source_file"
test ! -e "$target"
test ! -e "$raw/full_full1_outcome_projection_time.txt"
test "$(systemctl --user show primelora-tc-svc-e2d45b22d09549a899b629ad1138844d.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d133-failed-project-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_projection_scope.txt"
test "$(stat -c %s "$source_file")" = 1543688884
jq -e '.pass == false and .native_gpu_context_release_confirmed == true and .service_path_removed == true' "$raw/7b_full_w0_full1/launch.json"
exec /usr/bin/time -v -o "$raw/full_full1_outcome_projection_time.txt" \
  jq --stream -n -f "$raw/project_full1_outcome.jq" "$source_file" > "$target"
