"""D362 bounded preparation reused for the D524 exact metadata identity."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
parent = Path(__file__).resolve().parent
raw = parent / 'd524_20261014'
pub = ROOT / 'paper_results/ieee_tc/p2_backend/d524_metadata_profiles'

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(parent/'d524_preparation_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
gate = p.preflight([ROOT], 8*p.GIB)
assert gate['preflight_pass'], gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
seal = parent.parent/'slora_qualification/d435_20261011/protected_before.json'
protected = p.verify_seal(seal)
assert protected['pass'] and protected['entry_count'] == 147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['bash','-n','scripts/ieee_tc/run_d298_capacity_source.sh'],cwd=ROOT,check=True)
tests = ['tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer',
    'tests.test_ieee_tc_preflight.CapacityProbeObservation',
    'tests.test_ieee_tc_control_profile_analysis', 'tests.test_ieee_tc_control_profile_gaps',
    'tests.test_basic_smoke']
with (parent/'d524_tests1.log').open('x') as stream:
    tested = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromNames(tests))
sources = ('scripts/ieee_tc_preflight.py', 'scripts/ieee_tc/prepare_d298_capacity.py',
    'scripts/ieee_tc/run_d298_capacity_source.sh', 'scripts/ieee_tc/export_d298_profiles.py',
    'tests/test_ieee_tc_preflight.py', 'tests/test_ieee_tc_control_profile_analysis.py',
    'configs/ieee_tc/20261014_d524_7b_metadata_source.yaml')
import torch
assert not torch.cuda.is_initialized()
record = dict(identity=identity, passed=tested.wasSuccessful() and not tested.skipped,
    tests=tested.testsRun, failures=len(tested.failures), errors=len(tested.errors),
    skipped=len(tested.skipped), cuda_initialized=False, gate=gate, protected=protected,
    sources={name:p.digest(ROOT/name) for name in sources})
save(parent/'d524_tests1.json', record)
assert record['passed']
from scripts.ieee_tc.prepare_d298_capacity import prepare_control_profiles
prepare_control_profiles(file_demand=True, metadata=True)

# Verify the actual next Full model identity, not only source-vs-source config.
import yaml
from faaslora.experiment.instance_pool import FrozenServiceProfiles
from scripts.run_all_experiments import _prepare_dedicated_subprocess_model_cfg
contract = json.loads((pub/'development_contract.json').read_text())
full = yaml.safe_load((ROOT/'configs/ieee_tc/20261014_d523_7b_cpu_frontend_validation_100.yaml').read_text())
model = dict(full['model'], ieee_admission_profile=contract['model_config']['ieee_admission_profile'])
child, _ = _prepare_dedicated_subprocess_model_cfg(model, device_id=0, runtime_gpu_ids=[0])
assert FrozenServiceProfiles.model_identity(child) == FrozenServiceProfiles.model_identity(contract['model_config'])
assert p.verify_seal(seal)['pass']
save(raw/'preparation_scope.json', dict(identity=identity, passed=True,
    protected=protected, full_model_identity_equal=True, tests=tested.testsRun,
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True, tests=tested.testsRun, full_model_identity_equal=True,
    source_cases=json.loads((pub/'prepare.json').read_text())['cases'])), flush=True)
