"""Reuse the tested explicit-path checkpoint protocol for D524 preparation."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
PUB = ROOT/'paper_results/ieee_tc/p2_backend/d524_metadata_profiles'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
read = lambda path:json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
own = p.scope_identity(p.cg_path().name)
save(RAW/'backup_identity.json',own)
group = Path(own['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert p.preflight([ROOT],p.GIB)['preflight_pass']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == 'cc80e58b1a495e90fda3eecc657012bc3ba36b83'
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
tested = read(RAW.parent/'d524_tests1.json')
assert tested['passed'] and tested['tests'] == 322 and not tested['cuda_initialized']
assert (tested['failures'],tested['errors'],tested['skipped']) == (0,0,0)
for name,sha in tested['sources'].items():assert p.digest(ROOT/name) == sha
closure = read(RAW/'preparation_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
prepared = read(PUB/'prepare.json')
assert prepared['passed'] and prepared['waves'] == 135 and prepared['cases'] == 1669
assert prepared['warmups'] == 34 and prepared['representative_cases'] == 1635
assert read(RAW/'preparation_scope.json')['full_model_identity_equal']
for item in prepared['source_refs']+[prepared['spec']]:
    path = Path(item['path'])
    assert p.digest(path if path.is_absolute() else ROOT/path) == item['sha256']
old = RAW.parent/'d523_20261014'
launch = read(old/'7b_cpu_frontend_validation_100/launch.json')
assert not launch['pass'] and launch['service_returncode'] == 1
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
closed = read(old/'local_cleanup.json')
assert closed['actual_recursive_procs_empty'] and closed['service_path_gone'] and closed['auxiliary_path_gone']
for key in ('service_identity','auxiliary_identity'):assert not Path(closed[key]['path']).exists()
assert not Path(read(old/'start_closure.json')['identity']['path']).exists()
log = old/'7b_cpu_frontend_validation_100/launch.launch/service.log'
assert 'service profile model/configuration/context mismatch' in log.read_text()
assert (old/'remote_stop.log').read_text().count('ActiveState=inactive') == 3
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
preserved = {ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    ROOT/'docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D519.md':'e0ed5415b779effec429b48ea716abde2e3e9b1a379d5abbc11073cdca2f3a99',
    BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(path) == sha
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def secrets(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
evidence = [RAW.parent/name for name in ('d524_prepare.py','d524_tests1.log','d524_tests1.json','d524_preparation_identity.json')]
evidence += [RAW/name for name in ('preparation_scope.json','preparation_closure.json','close.py','backup.py','start_remote.sh','check_remote_health.py','stop_remote.sh')]
evidence += [old/name for name in ('local_cleanup.json','start_closure.json','launch_gate.json','remote_start.log','remote_stop.log','remote_health.json','start.py','stop_remote.sh')]
evidence += [old/'7b_cpu_frontend_validation_100/launch.json',log]
members = {}
with tarfile.open(PUB/'preparation_evidence.tar.gz','x:gz') as archive:
    for i,path in enumerate(evidence):
        data = path.read_bytes();secrets(data)
        assert len(data) < 2*1024**2
        name = f'{i:02d}_'+path.name
        info = tarfile.TarInfo(name);info.size=len(data);info.mtime=0
        archive.addfile(info,io.BytesIO(data))
        members[name] = dict(source=str(path),sha256=hashlib.sha256(data).hexdigest())
with tarfile.open(PUB/'preparation_evidence.tar.gz') as archive:
    assert set(archive.getnames()) == set(members)
    for name,item in members.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == item['sha256']
save(PUB/'checkpoint.json',dict(passed=True,qualification=tested,protected=protected,
    preparation_closure=closure,previous_failed_attempt=dict(launch=launch,local_cleanup=closed,
        classification='protocol_or_launcher_error',performance_observation=False),
    archive_members=members,archive_sha256=p.digest(PUB/'preparation_evidence.tar.gz'),
    next='one D524 affected native source measurement; exact identity retained'))
paths = ['scripts/ieee_tc_preflight.py','scripts/ieee_tc/prepare_d298_capacity.py',
    'scripts/ieee_tc/run_d298_capacity_source.sh','scripts/ieee_tc/export_d298_profiles.py',
    'tests/test_ieee_tc_preflight.py','tests/test_ieee_tc_control_profile_analysis.py',
    'configs/ieee_tc/20261014_d524_7b_metadata_source.yaml',
    'docs/ieee_tc/D524_METADATA_PROFILE_REFRESH.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str(path.relative_to(ROOT)) for path in sorted(PUB.iterdir()) if path.is_file()]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
for name in paths:
    data = (ROOT/name).read_bytes();secrets(data)
    assert len(data) < 2*1024**2
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()) == set(paths)
for name in paths:
    data = subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    secrets(data)
    assert hashlib.sha256(data).hexdigest() == p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: retain D523 rejection and bind fresh metadata timing calibration (D524)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote = subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head == remote
save(RAW/'backup_receipt.json',dict(passed=True,head=head,remote=remote,paths=paths,
    identity=own,checkpoint_sha256=p.digest(PUB/'checkpoint.json')))
print(json.dumps(dict(passed=True,head=head,files=len(paths))),flush=True)
