"""D523 actual metadata installation native100; reuse protected Full deployment."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
BINDING = ROOT / 'paper_results/ieee_tc/p2_backend/d522_metadata_device/cpu_qualification.json'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p


def run(command, **kwargs):
    return subprocess.run(command, check=True, **kwargs)


def main():
    assert RAW.name == 'd523_20261014'
    assert not (RAW / '7b_cpu_frontend_validation_100').exists()
    identity = p.scope_identity(p.cg_path().name)
    with (RAW/'start_identity.json').open('x') as stream:
        json.dump(identity, stream, indent=2)
    group = Path(identity['path'])
    assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
    assert (group / 'memory.swap.max').read_text().strip() == '0'
    assert os.sched_getaffinity(0) == {2, 3, 26, 27}
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    remote = subprocess.check_output(
        ['git', 'ls-remote', 'faaslora_origin', 'refs/heads/retry14_continuous_queue_v2'],
        cwd=ROOT, text=True).split()[0]
    assert head == remote == 'cc80e58b1a495e90fda3eecc657012bc3ba36b83'
    changed = subprocess.check_output(
        ['git', 'diff', '--name-only', 'HEAD', '--', 'faaslora', 'scripts',
         'configs/ieee_tc', 'tests'], cwd=ROOT, text=True).strip()
    assert not changed, changed
    binding = json.loads(BINDING.read_text())
    assert binding['passed'] and binding['non_target_config_equal'] and binding['tests'] == 521
    for path, sha in binding['refs'].items():
        assert p.digest(Path(path)) == sha, path
    device_path = ROOT / 'results/ieee_tc/p2_backend_qualification/d522_20261014/device2.json'
    assert p.digest(device_path) == binding['prior_device_qualification_sha256']
    device = json.loads(device_path.read_text())
    assert device['pass'] and len(device['cases']) == 10
    assert all(item['metadata_equal'] and item['captured_graph_equal'] for item in device['cases'])
    prior_input_path=ROOT/'paper_results/ieee_tc/p2_backend/d464_host_queue/input_qualification.json'
    prior_input=json.loads(prior_input_path.read_text())
    assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    for view in (prior_input['view'],prior_input['full_view']):
        assert p.digest(Path(view['source_path']))==view['source_sha256']
    protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
    assert protected['pass'] and protected['entry_count']==147
    gate = p.preflight([ROOT], 32 * p.GIB)
    assert gate['preflight_pass'], gate['issues']
    assert not subprocess.check_output(
        ['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    assert subprocess.run(['tmux', 'has-session', '-t', 'tc-d523-cpuprep100'],
                          stderr=subprocess.DEVNULL).returncode != 0
    RAW.mkdir(parents=True, exist_ok=True)
    with (RAW / 'launch_gate.json').open('x') as stream:
        json.dump(dict(passed=True, campaign='d523_20261014', head=head,
                       remote=remote, gate=gate, identity=identity,
                       source_execution_sha=head,
                       qualification_manifest_sha256=p.digest(BINDING),
                       reused_input=dict(path=str(prior_input_path),sha256=p.digest(prior_input_path),view=prior_input['view']),
                       protected=protected,
                       helpers=[dict(path=str(x),sha256=p.digest(x),content=x.read_text())
                                for x in sorted([*RAW.glob('*.py'),*RAW.glob('*.sh')])],
                       config_sha=p.digest(ROOT / 'configs/ieee_tc/20261014_d523_7b_cpu_frontend_validation_100.yaml')),
                  stream, indent=2)
    run(['bash', str(RAW / 'start_remote.sh')])
    run(['/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python',
         str(RAW / 'check_remote_health.py')], cwd=ROOT)
    run(['tmux', 'new-session', '-d', '-s', 'tc-d523-cpuprep100', '-c', str(ROOT),
         'bash scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh d523'])
    receipt=RAW/'7b_cpu_frontend_validation_100/launch.launch/exec_receipt.json'
    deadline=time.monotonic()+30
    while not receipt.exists():
        if time.monotonic()>deadline:
            raise TimeoutError('guarded launch receipt not yet available; inspect retained launch')
        time.sleep(.1)
    launched=json.loads(receipt.read_text())
    captured=p.scope_identity(Path(launched['auxiliary_path']).name)
    with (RAW/'service_aux_identity.json').open('x') as stream:
        json.dump(captured,stream,indent=2)
    with (RAW / 'start_receipt.json').open('x') as stream:
        json.dump(dict(launched=True, campaign='d523_20261014', head=head,
                       remote=remote, tmux='tc-d523-cpuprep100', identity=identity),
                  stream, indent=2)
    print(json.dumps(dict(launched=True, campaign='d523_20261014', tmux='tc-d523-cpuprep100')))


if __name__ == '__main__':
    main()
