"""Post-D353 storage recovery; reuse D339's guarded lossless procedure.

Prepared during measurement, but never execute until the sole GPU run is closed.
Only TARGETS changes. Native-release/open-file/SHA/roundtrip/protected-result
checks and resource boundaries remain the established D339 procedure.
"""
import ast
import hashlib
from pathlib import Path

SOURCE = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d339_20261008/compress_historical.py')
tree = ast.parse(SOURCE.read_text(), filename=str(SOURCE))
targets = [
    ('d314_20261007/7b_full_w0',
     '081201cc6d413b8eabce6eba4158d59429aad0a72f0f80c2af0dd68f7005420f',
     'd314_full_w0/validated1/manifest.json'),
    ('d315_20261007/7b_full_w0',
     '8a159b58b3bacecda42f54e5309964610278695af677b01bf3a1c758185afaf9',
     'd315_full_w0/validated1/manifest.json'),
    ('d318_20261007/7b_full_w0',
     '611aae36e7bfbbe261dd9b310743f2931d257cd73b22de2a39de93c1a29d3dfb',
     'd318_full_w0/validated1/manifest.json'),
    ('d332_20261008/7b_full_w0',
     '3c201b1d6b3cf3e946c4da97ba6837d3aab81cc46401084da307bf0339b87a50',
     'd332_full_w0/validated1/manifest.json'),
    ('d335_20261008/7b_full_w0',
     '3191ae61fb91144c7c5eefb0a297d9dabdc9fbd3540fde97c967baa393476797',
     'd335_full_w0/validated1/manifest.json'),
    ('d346_20261008/7b_full_w0',
     'a283c7a8d0ad6f319ad9f941538b43731cb98f4a424d1558c66d79e71a92de38',
     'd346_full_w0/validated1/manifest.json'),
]
changed = 0
for node in tree.body:
    if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == 'TARGETS'
            for target in node.targets):
        node.value = ast.parse(repr(targets), mode='eval').body
        changed += 1
assert changed == 1
ast.fix_missing_locations(tree)
print('Reuse D339 compression procedure SHA256',
      hashlib.sha256(SOURCE.read_bytes()).hexdigest(), flush=True)
exec(compile(tree, str(SOURCE), 'exec'), {'__name__': '__main__', '__file__': __file__})
