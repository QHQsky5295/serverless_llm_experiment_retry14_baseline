"""Resume only the D353 reference-registration failure; preserve prior results."""
import json
import os
import subprocess
import sys
from pathlib import Path
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend/d353_full_w0'
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
def sample():
    return {k:(group/k).read_text().strip() for k in (
        'memory.peak','memory.events','memory.swap.current',
        'memory.high','memory.max','memory.swap.max','cgroup.events')}
before = sample()
assert before['memory.high'] == str(3*p.GIB) and before['memory.max'] == str(4*p.GIB)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}
gate = p.preflight([ROOT],4*p.GIB)
assert gate['preflight_pass'], gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
prior = json.loads((raw/'offline_execution_receipt.json').read_text())
assert prior['returncodes'] == [0,0,0,1] and not prior['pass_all']
closed = prior['identity']
assert closed != identity and p.scope_still_owned(closed)
assert not p.owned_pids(Path(closed['path']))
cleanup = p.stop_scope_identity(closed)
assert cleanup['released'] and not cleanup['hard_kill'] and not Path(closed['path']).exists()
with (raw/'analysis1_scope_cleanup.json').open('x') as f:
    json.dump(dict(identity=closed,cleanup=cleanup),f,indent=2)
assert not (out/'context_d336').exists()
original = raw/'check_d299_full_context.audit1.py'
script = ROOT/'scripts/ieee_tc/check_d299_full_context.py'
context_manifest = json.loads((out/'context1/manifest.json').read_text())
ref = [r for r in context_manifest['source_refs'] if r['path'] == str(script)]
assert len(ref) == 1 and p.digest(original) == ref[0]['sha256']
for subdir in ('validated1','context1'):
    manifest = json.loads((out/subdir/'manifest.json').read_text())
    for name,digest in manifest['outputs'].items():
        assert p.digest(out/subdir/name) == digest
with (raw/'analysis_source_retention.json').open('x') as f:
    json.dump(dict(original_path=str(script),retained_path=str(original),
        sha256=p.digest(original),revised_sha256=p.digest(script),
        reason='CLI accepted D336, but an older function-level guard still allowed only D315. Align registered-reference guards; no result or metric change.',
        first_three_commands_reused=True,prior_failure_retained=True),f,indent=2)
python = '/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python'
commands = [
    [python,'-m','unittest','tests.test_ieee_tc_timing_bound',
     'tests.test_ieee_tc_launch.MainOutcomeRetention','tests.test_ieee_tc_decode_overlap',
     'tests.test_ieee_tc_hit_host_analysis','-q'],
    [python,'-m','scripts.ieee_tc.check_d299_full_context','--campaign','d353','--reference','d336'],
]
codes = []
try:
    with (raw/'audit2.log').open('x') as f:
        for command in commands:
            print(json.dumps(dict(command=command)),file=f,flush=True)
            result = subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
            codes.append(result.returncode)
            result.check_returncode()
finally:
    with (raw/'offline_resume_receipt.json').open('x') as f:
        json.dump(dict(identity=identity,before=before,after=sample(),preflight=gate,
            commands=commands,returncodes=codes,pass_all=len(codes)==2 and not any(codes),
            retained_prior_sha256=p.digest(raw/'offline_execution_receipt.json'),
            no_gpu_rerun=True,no_measurement_change=True),f,indent=2)
print(json.dumps(dict(returncodes=codes,pass_all=True)))
