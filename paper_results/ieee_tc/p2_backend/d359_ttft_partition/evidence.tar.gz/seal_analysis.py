"""Seal D359 retained evidence; adapted from D358 closure_checkpoint.py."""
import csv
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path
from statistics import mean

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.analyze_d297_full import TTFT_STAGE_MS, percentile

raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend/d359_ttft_partition'
gate = p.preflight([ROOT], 4*p.GIB)
assert gate['preflight_pass'], gate['issues']
offline = json.loads((raw/'execution_receipt.json').read_text())
assert offline['pass_all']
identity = offline['identity']
assert p.scope_still_owned(identity) and not p.owned_pids(Path(identity['path']))
resources = {k:(Path(identity['path'])/k).read_text() for k in (
    'memory.peak','memory.events','memory.swap.current','cgroup.events')}
cleanup = p.stop_scope_identity(identity)
assert cleanup['released'] and not cleanup['hard_kill']
with (raw/'analysis_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,cleanup=cleanup),f,indent=2)

for folder in (out/'analysis1', out/'analysis1/sampled_capacity'):
    seal = json.loads((folder/'manifest.json').read_text())
    for name,digest in seal['outputs'].items():
        assert p.digest(folder/name)==digest
    for ref in seal['source_refs']:
        assert p.digest(Path(ref['path']))==ref['sha256'], ref['path']

data, groups, activation_rows = {}, [], []
for run in ('d353','d358'):
    with (out/f'analysis1/{run}_requests.csv').open() as f:
        rows = list(csv.DictReader(f))
    assert len(rows)==4000 and [r['request_id'] for r in rows]==[f'req_{i:05d}' for i in range(4000)]
    for r in rows:
        for k in TTFT_STAGE_MS + ('ttft_ms','tpot_ms','routing_nested_ms',
                'acquire_to_resume_startup_overlap_ms','pre_acquire_startup_overlap_ms'):
            r[k] = float(r[k])
        for k in ('phase','token_count'):
            r[k] = int(r[k])
    data[run] = rows
    cohorts = [('all', 'all', rows)]
    cohorts += [('phase',str(i+1),[r for r in rows if r['phase']==i]) for i in range(8)]
    cohorts += [('output_length',f'{lo}-{hi}',[r for r in rows if lo<=r['token_count']<=hi])
                for lo,hi in ((2,32),(33,128),(129,256))]
    for phase in ('all','2'):
        for tier in ('gpu','host','nvme','remote'):
            cohorts.append(('conditional_tier',phase+':'+tier,
                [r for r in rows if r['tier']==tier and (phase=='all' or r['phase']==1)]))
    for kind,label,rs in cohorts:
        assert rs
        groups.append(dict(run=run,group=kind,label=label,n=len(rs),
            **{k:mean(r[k] for r in rs) for k in TTFT_STAGE_MS},
            ttft_ms=mean(r['ttft_ms'] for r in rs),tpot_ms=mean(r['tpot_ms'] for r in rs),
            p95_ttft_ms=percentile([r['ttft_ms'] for r in rs],.95),
            routing_nested_ms=mean(r['routing_nested_ms'] for r in rs),
            timing_joint_pass=sum(r['timing_outcome']=='timing_pass' for r in rs)))
    deployment_path = ROOT/f'results/ieee_tc/p2_backend_qualification/{run}_20261008/7b_full_w0/launch.launch/physical_deployment/deployment.json'
    start = json.loads(deployment_path.read_text())['arrival_start_s']
    for a in json.loads((out/f'analysis1/{run}_activations.json').read_text()):
        activation_rows.append(dict(run=run,activation_id=a['activation_id'],category=a['category'],
            trigger_offset_s=a['trigger_at']-start,ready_offset_s=a['engine_ready_at']-start,
            startup_s=a['engine_ready_at']-a['trigger_at'],
            preparation_terminal_offset_s=a['preparation_terminal_at']-start))

summary = json.loads((out/'analysis1/summary.json').read_text())
stage_deltas = {k:summary['runs']['d358']['ttft_stage_means_ms'][k]-
                    summary['runs']['d353']['ttft_stage_means_ms'][k] for k in TTFT_STAGE_MS}
full_delta = mean(r['ttft_ms'] for r in data['d358'])-mean(r['ttft_ms'] for r in data['d353'])
assert abs(sum(stage_deltas.values())-full_delta)<1e-6
phase_contributions = []
for i in range(8):
    delta = mean(r['ttft_ms'] for r in data['d358'] if r['phase']==i)-mean(
        r['ttft_ms'] for r in data['d353'] if r['phase']==i)
    phase_contributions.append(dict(phase=i+1,mean_delta_ms=delta,
        contribution_to_global_mean_delta_ms=delta/8,
        share_of_global_delta=delta/8/full_delta))
for name,rows in (('groups.csv',groups),('activations.csv',activation_rows),
                   ('phase_contributions.csv',phase_contributions)):
    with (out/name).open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader(); writer.writerows(rows)
with (out/'comparison.json').open('x') as f:
    json.dump(dict(mean_ttft_delta_ms=full_delta,stage_deltas_ms=stage_deltas,
        second_phase_share=phase_contributions[1]['share_of_global_delta'],
        numerical_n_correct=None,formal_qualification=False,confidence_interval=None,
        caveat='One development run per configuration; additive means only. Tier groups are post-routing conditional descriptions, not matched causal effects. Startup overlap and sampled capacity cannot identify all wait causes.'),f,indent=2)

protected = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['changed']==['/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py']
assert p.digest(Path(protected['changed'][0]))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
with (raw/'protected.json').open('x') as f:
    json.dump(protected,f,indent=2)

paths=[raw/name for name in ('run_analysis.py','analysis1.log','execution_receipt.json',
    'analysis_cleanup.json','seal_analysis.py','protected.json')]
paths += [ROOT/name for name in ('scripts/ieee_tc/analyze_d297_full.py',
    'scripts/analyze_control_path_overhead.py','tests/test_ieee_tc_full_control_analysis.py')]
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in paths:
    assert token and token not in path.read_bytes()
archive=out/'evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths: tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest()==p.digest(path)
with (out/'evidence.json').open('x') as f:
    json.dump(dict(kind='d359_retained_ttft_diagnosis_v1',cpu_tests=56,new_gpu_runs=0,
        no_figures=True,source_commit='fb4e2b89244c440fe2ba77b4e3ae6e0049e6031d',
        archive_sha256=p.digest(archive),refs=[dict(path=str(path),sha256=p.digest(path)) for path in paths]),f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
own=p.scope_identity(p.cg_path().name)
with (raw/'seal_scope.json').open('x') as f:
    json.dump(dict(identity=own,resources={k:(Path(own['path'])/k).read_text() for k in (
        'memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(comparison=stage_deltas,analysis_cleanup=cleanup,archive_bytes=archive.stat().st_size)))
