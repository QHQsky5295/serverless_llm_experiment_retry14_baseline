"""Post-release D359 diagnosis using existing D353/D358 complete measurements."""
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])


def sample():
    return {k: (group/k).read_text().strip() for k in (
        'memory.peak', 'memory.events', 'memory.swap.current',
        'memory.high', 'memory.max', 'memory.swap.max', 'cgroup.events')}


before = sample()
assert before['memory.high'] == str(3*p.GIB) and before['memory.max'] == str(4*p.GIB)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2, 3, 26, 27}
assert not subprocess.check_output(
    ['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 4*p.GIB)
assert gate['preflight_pass'], gate['issues']
closure = json.loads((ROOT/'results/ieee_tc/p2_backend_qualification/d358_20261008/'
                           'closure_backup_receipt.json').read_text())
python = '/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python'
output = ROOT/'paper_results/ieee_tc/p2_backend/d359_ttft_partition/analysis1'
commands = [
    [python, '-m', 'unittest', 'tests.test_ieee_tc_control_timeline',
     'tests.test_ieee_tc_full_control_analysis', '-q'],
    [python, '-m', 'scripts.ieee_tc.analyze_d297_full', '--interleave-wait-output', str(output)],
]
returncodes = []
try:
    with (raw/'analysis1.log').open('x') as log:
        for command in commands:
            print(json.dumps(dict(command=command)), file=log, flush=True)
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            returncodes.append(result.returncode)
            result.check_returncode()
finally:
    receipt = dict(identity=identity, before=before, after=sample(), preflight=gate,
        commands=commands, returncodes=returncodes,
        pass_all=len(returncodes) == len(commands) and not any(returncodes),
        new_gpu_runs=0, no_figures=True, previous_backup=closure)
    with (raw/'execution_receipt.json').open('x') as handle:
        json.dump(receipt, handle, indent=2, allow_nan=False)
print(json.dumps(dict(returncodes=returncodes, resources=sample())))
