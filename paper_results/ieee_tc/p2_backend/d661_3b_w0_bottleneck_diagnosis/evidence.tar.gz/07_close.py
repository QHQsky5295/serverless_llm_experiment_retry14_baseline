"""Close only the exact empty auxiliary scope using the existing checked helper."""
import hashlib
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d660_20261018/close.py')
code = source.read_bytes()
# __file__ remains this new campaign, so existing sealed receipts are never edited.
exec(compile(code, str(source), 'exec'))
