"""Project only actual source-admission paths from the already sealed D660 run."""
import collections
import json
import os
from pathlib import Path
from statistics import fmean
import subprocess
import sys
import ijson

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.plot_d290_diagnostic import percentile

def read(path): return json.loads(path.read_text())
def save(path,data):
    with path.open('x') as stream: json.dump(data,stream,indent=2,allow_nan=False)

identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'analysis2_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()
diagnosis=read(RAW/'diagnosis.json')
projection_path=RAW/'d660_projection.json'
rows={r['request_id']:r for r in read(projection_path)}
assert len(rows)==4000 and sum(r['joint'] for r in rows.values())==3575
refs={r['path']:r['sha256'] for r in diagnosis['source_refs']}
sources=[Path(path) for path in refs if '/d660_' in path and '/experiment_results_' in path]
assert len(sources)==1 and p.digest(sources[0])==refs[str(sources[0])]
groups=collections.defaultdict(list);shapes={};seen=set()
with sources[0].open('rb') as stream:
    for r in ijson.items(stream,'detailed_results.tc_ieee_full.requests.item',use_float=True):
        rid=r['request_id'];assert rid not in seen;seen.add(rid)
        e=r['gpu_reference_evidence'];route=e['routing_snapshot']
        assert route['selected_replica_id']==r['instance_id']
        s=route['sources'][r['instance_id']]['source']
        assert s['tier']==r['readiness_tier_before_dispatch']==rows[rid]['tier']
        assert type(s['native']) is bool
        key=s['tier']+('::native' if s['native'] else '::file_or_remote')
        groups[key].append(rows[rid])
        shapes.setdefault(key,dict(evidence_keys=sorted(e),nested_keys={k:sorted(v) for k,v in e.items() if isinstance(v,dict)},source_keys=sorted(s)))
assert seen==set(rows)
def summarize(members):
    return dict(n=len(members),joint=sum(r['joint'] for r in members),
        ttft_bad=sum(not r['ttft_good'] for r in members),tpot_bad=sum(not r['tpot_good'] for r in members),
        mean_ttft_ms=fmean(r['ttft_ms'] for r in members),
        p95_ttft_ms=percentile([r['ttft_ms'] for r in members],.95),
        mean_tpot_ms=fmean(r['tpot_ms'] for r in members),
        stages_ms={k:fmean(r['stages_ms'][k] for r in members) for k in members[0]['stages_ms']})
payload=dict(passed=True,kind='d661_selected_source_path_projection_v1',source_path=str(sources[0]),
    source_sha256=refs[str(sources[0])],parent_diagnosis_sha256=p.digest(RAW/'diagnosis.json'),
    projection_sha256=p.digest(projection_path),groups={k:summarize(v) for k,v in groups.items()},
    receipt_shapes=shapes,length_groups={k:summarize(v) for k,v in (
        ('tpot_bad_2_32',[r for r in rows.values() if not r['tpot_good'] and r['target']<=32]),
        ('tpot_bad_33_64',[r for r in rows.values() if not r['tpot_good'] and 32<r['target']<=64]),
        ('tpot_bad_65_128',[r for r in rows.values() if not r['tpot_good'] and 64<r['target']<=128]))},
    caveat='Endogenous source/path and length groups, not causal effects, RPC totals or counterfactual improvements.',
    inference_runs_added=0,n_correct=None,ranking_eligible=False)
save(RAW/'source_paths.json',payload)
save(RAW/'analysis2_receipt.json',dict(passed=True,identity=identity,source_paths_sha256=p.digest(RAW/'source_paths.json'),
    resources={k:(cg/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,groups=payload['groups'])),flush=True)
