"""Reuse sealed D612 explicit publication guards for D661 closed-data analysis."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/publish.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace('d612_w2_quality_resource_diagnosis','d661_3b_w0_bottleneck_diagnosis')
replace('f72091155cd3bb258651fc461db11b9113c72faf','4ed5ead8c685ec6db6f92652aa1fb75452caec16')
replace("for name in ('analysis',):", "for name in ('analysis','analysis2'):")
replace("assert sum(x['n'] for x in diagnosis['matched_transitions'].values())==8000//2", """assert diagnosis['paired_request_comparison_performed'] is False
paths=read(RAW/'source_paths.json')
assert paths['passed'] and sum(g['n'] for g in paths['groups'].values())==4000
assert paths['parent_diagnosis_sha256']==p.digest(RAW/'diagnosis.json')
assert paths['projection_sha256']==p.digest(RAW/'d660_projection.json')
assert read(RAW/'analysis2_receipt.json')['source_paths_sha256']==p.digest(RAW/'source_paths.json')""")
replace("assert diagnosis['runs']['D607']['all']['joint']==3762", "assert diagnosis['runs']['D660']['all']['joint']==3575")
replace("assert diagnosis['runs']['D611']['all']['joint']==3819", "assert sum(g['joint'] for g in paths['groups'].values())==3575")
replace('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md','D661_3B_W0_BOTTLENECK_DIAGNOSIS.md')
replace("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']", """files += [doc,RAW.parent/'d660_20261018/close.py',
    RAW.parent/'d612_20261017/diagnose.py',RAW.parent/'d612_20261017/publish.py',
    RAW.parent/'d660_20261018/publication_closure.json',RAW/'analysis1.log',RAW/'analysis2.log']""")
replace('assert len(data)<8*1024*1024','assert len(data)<24*1024*1024')
replace('d612_reused_parent_closed_log_diagnosis_v1','d661_3b_w0_residual_and_holding_v1')
replace('diagnosis=diagnosis,protected=protected,','diagnosis=diagnosis,source_paths=paths,protected=protected,')
replace('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
        'tc: explain 3B W0 steady-state SLO and GPU holding shortfalls (D661)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('Sealed D612 publication adaptation AST passed; no write or commit.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else: raise SystemExit('expected no arguments or --check-only')
