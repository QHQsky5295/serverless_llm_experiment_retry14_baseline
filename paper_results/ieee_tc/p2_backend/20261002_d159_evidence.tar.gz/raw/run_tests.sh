#!/usr/bin/env bash
# D153 bounded CPU protocol, extended for fused execution objectives.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in targeted1|targeted2|regression1|regression2|micro1|verify1) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d159_20261002
unit="primelora-d159-${phase}-20261002.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sha256sum faaslora/preloading/planning_cpu.py scripts/run_all_experiments.py tests/test_ieee_tc_planning_cpu.py > "$raw/${phase}_sources.sha256"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
if [[ "$phase" == regression* ]]; then
  args=(-m unittest tests.test_ieee_tc_file_observation tests.test_ieee_tc_transfer_pressure tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_planning_cpu tests.test_ieee_tc_planning tests.test_ieee_tc_launch tests.test_ieee_tc_native_retirement tests.test_basic_smoke -v)
elif test "$phase" = micro1; then
  args=("$raw/compare_objectives.py")
elif test "$phase" = verify1; then
  args=("$raw/verify.py")
else
  args=(-m unittest tests.test_ieee_tc_planning_cpu -v)
fi
exec /usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
