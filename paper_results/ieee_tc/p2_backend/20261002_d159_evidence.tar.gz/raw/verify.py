"""Bounded D159 qualification/evidence seal; no serving result is invented."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
BASE = 'bd3fc57f4f93dfcafd8add8582514c58f281b2be'
def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
tests = []
for phase, count, code, expected in (
        ('targeted1', 9, 1, 'f1b1fdec2e7247a0922bef443e259c60'),
        ('targeted2', 9, 0, 'f765b6ff3c4e411190510880ffc6c323'),
        ('regression1', 816, 1, '1aba46f627c641b2b05ed59e2e39cdcd'),
        ('regression2', 816, 0, '940d747b12dc4f309fa208d6ca29e03f')):
    log = (RAW/f'{phase}.log').read_text()
    m = re.search(r'Ran (\d+) tests in ([\d.]+)s', log)
    assert m and int(m[1]) == count
    assert ('\nOK\n' in log) if code == 0 else ('\nFAILED (' in log)
    elapsed = (RAW/f'{phase}_time.txt').read_text()
    assert f'Exit status: {code}' in elapsed
    assert f'InvocationID={expected}' in (RAW/f'{phase}_scope.txt').read_text()
    assert f'actual_invocation={expected}' in (RAW/f'{phase}_cleanup.txt').read_text()
    assert 'cleanup=automatic_removal_verified' in (RAW/f'{phase}_cleanup.txt').read_text()
    unit = f'primelora-d159-{phase}-20261002.scope'
    assert subprocess.check_output(['systemctl', '--user', 'show', unit, '-p', 'ActiveState', '--value'], text=True).strip() == 'inactive'
    assert not subprocess.check_output(['systemctl', '--user', 'show', unit, '-p', 'InvocationID', '--value'], text=True).strip()
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice', unit).exists()
    tests.append(dict(phase=phase, count=count, exit_code=code, body_seconds=float(m[2]),
        maximum_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)', elapsed)[1]),
        actual_invocation_id=expected, cleanup_verified=True,
        final_memory_events='unavailable_after_automatic_removal'))

from scripts.ieee_tc_preflight import verify_seal
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
refs = {
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'): '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md': '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'paper_results/ieee_tc/p2_backend/20261002_d158_7b_full_w0_full1.json': 'bfaed07c833b33dc64f2a4768eda53990068c0ed17baf93c318eecb76d420c23',
}
for path, expected in refs.items():
    assert sha(path) == expected, path
sources = ['faaslora/preloading/planning_cpu.py', 'scripts/run_all_experiments.py',
           'tests/test_ieee_tc_planning_cpu.py']
for name in sources:
    ast.parse((ROOT/name).read_text())
    assert f'{sha(ROOT/name)}  {name}' in (RAW/'regression2_sources.sha256').read_text()
unchanged = 'faaslora/preloading/preloading_planner.py'
assert (ROOT/unchanged).read_bytes() == subprocess.check_output(['git', 'show', f'{BASE}:{unchanged}'], cwd=ROOT)
subprocess.run(['git', 'diff', '--check', '--', *sources, 'docs/ieee_tc/D159_EXECUTION_OBJECTIVES.md'], cwd=ROOT, check=True)
cache = json.loads((RAW/'public_download_cache_complete1.json').read_text())
assert cache['installed_environments_untouched'] and cache['tracked_projects_unchanged']
for phase in ('audit', 'apply'):
    assert 'cleanup=automatic_removal_verified' in (RAW/f'cache_{phase}1_cleanup.txt').read_text()
curated = OUT/'20261002_d159_execution_objectives.json'
save(curated, dict(kind='d159_fused_execution_objective_qualification_v1', base_commit=BASE,
    source_sha256={p:sha(ROOT/p) for p in sources+[unchanged]}, tests=tests,
    protected=protected, frozen_references={str(p):s for p,s in refs.items()},
    pure_original_objective_functions_unchanged=True,
    performance_run_completed=False, formal_g1_g2_qualified=False,
    qualification='correctness_and_containment_only', public_download_cleanup=cache,
    next='Ordinary 7B W0 Full4000, same D158 cap4/profiles; recheck prelaunch gates.',
    caveats=['No serving speedup inferred from unit tests.',
             'New GPU/file output materialization may add IPC size; full replay must measure net effect.',
             'Common numerical identity, warm SLO, Resident budgets and model acceptance remain open.']))
doc = ROOT/'docs/ieee_tc/D159_EXECUTION_OBJECTIVES.md'
save(OUT/'20261002_d159_verification.json', dict(pass_=True,
    document_sha256=sha(doc), curated_sha256=sha(curated), protected=protected))
members = sorted(p for p in RAW.iterdir() if p.is_file() and not p.name.startswith('verify1')
                 and p.stat().st_size < 2*1024**2
                 and p.suffix in {'.py','.sh','.log','.txt','.json','.jsonl','.sha256'})
extras = [ROOT/p for p in sources] + [doc, curated]
bundle = OUT/'20261002_d159_evidence.tar.gz'
hashes = {}
with tarfile.open(bundle, 'x:gz') as tar:
    for p in members+extras:
        name = ('raw/'+p.name) if p in members else str(p.relative_to(ROOT))
        data = p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        hashes[name] = hashlib.sha256(data).hexdigest()
        tar.add(p, arcname=name, recursive=False)
with tarfile.open(bundle, 'r:gz') as tar:
    assert set(tar.getnames()) == set(hashes)
    for name, digest in hashes.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
save(OUT/'20261002_d159_evidence_members.json', dict(member_sha256=hashes, pass_=True))
with (OUT/'20261002_d159_evidence.sha256').open('x') as f:
    f.write(sha(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(pass_=True, tests=tests, curated_sha256=sha(curated),
    bundle_sha256=sha(bundle), bundle_bytes=bundle.stat().st_size, members=len(hashes))))
