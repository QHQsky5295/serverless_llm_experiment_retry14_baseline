"""Close D344 auxiliary scopes and seal complete observations with two gaps."""
import ast,csv,hashlib,json,pathlib,re,subprocess,sys,tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles'
receipt=json.loads((raw/'analysis_receipt.json').read_text())
assert receipt['passed'] and not receipt['profile_exported'] and receipt['missing_classes']==2
units=[f'primelora-tc-aux-3440000000000000000000000000000{i}.scope' for i in range(4,9)]
closed=[]
for unit in units:
    identity=p.scope_identity(unit);group=pathlib.Path(identity['path'])
    if unit==receipt['identity']['unit']:assert identity==receipt['identity']
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    assert int(resources['memory.swap.current'])==0
    assert all(int(v)==0 for _,v in (line.split() for line in resources['memory.events'].splitlines()))
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    closed.append(dict(identity=identity,resources=resources,inactive=True))
with (raw/'auxiliary_cleanup.json').open('x') as f:json.dump(closed,f,indent=2)
run=json.loads((raw/'source1.json').read_text())
assert run['pass'] and run['stage']=='complete' and run['physical_allocation']['released']
assert p.digest(raw/'source1.json')=='09d2f2b688c7cbce1591bb8b5ab4af8f28d3df1f26377b109b231ec2440c924e'
assert len(run['requests'])==1529 and all(q['pass'] for q in run['requests'])
roles={i:w for i,w in enumerate(run['source_profile_spec']['waves'])}
rows=[]
for q in run['requests']:
    w=int(q['request_id'].split('/')[1][1:]);spec=roles[w]
    f=q['class_features'];t=q['timing']
    rows.append(dict(request_id=q['request_id'],source_request_id=q['source_request_id'],adapter_id=q['adapter_id'],
        wave=w,round=spec['round'],role=spec['role'],source=q['requested_source'],
        native_prompt_tokens=t['actual_prompt_tokens'],declared_output_tokens=q['target_tokens'],
        actual_output_tokens=q['actual_tokens'],adapter_rank=f['adapter_rank'],
        admitted_after_accept=f['admitted_after_accept'],admitted_bin=q['service_class']['admitted_bin'],
        output_bin=q['service_class']['output_limit_bin'],
        admitted_monotonic_s=q['admitted_monotonic_s'],last_token_monotonic_s=q['last_token_monotonic_s'],
        native_ttft_ms=(q['first_token_monotonic_s']-t['native_dispatch_monotonic_s'])*1000,
        native_tpot_ms=t['native_tpot_ms'],output_sha256=t['completion_token_ids_sha256']))
with (out/'native_requests1.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
short=[]
for i,spec in roles.items():
    selected=[r for r in rows if r['wave']==i]
    if spec['role']=='representative_measurement' and spec['source']=='gpu' and all(r['output_bin']==0 for r in selected):
        short.append(dict(wave=i,round=spec['round'],rank=selected[0]['adapter_rank'],planned_lanes=len(selected),
            actual_admission_counts=[r['admitted_after_accept'] for r in selected],
            completed_before_last_admission=sum(r['last_token_monotonic_s']<max(x['admitted_monotonic_s'] for x in selected) for r in selected)))
with (out/'short_gpu_coverage_diagnosis1.json').open('x') as f:
    json.dump(dict(waves=short,missing_classes=json.loads((out/'coverage1.json').read_text())['missing_service_classes'],
        explanation='Actual post-accept class below9 for short GPU-ready waves; native completions before later admission are recorded, no forced barrier.',
        next_measurement='Existing long-output background requests then original short-output targets in one GPU-ready wave; only two genuinely missing classes, no new capacity or workload.'),f,indent=2)
assert all(max(w['actual_admission_counts'])<=8 and w['completed_before_last_admission']>0 for w in short)
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
paths=[raw/n for n in ('source1_launch.json','source_commit.txt','source1_launcher.log','launcher_identity.json',
    'remote_start.log','remote_stop.log','remote_stop.json','remote_health.json','remote_transfers.jsonl','remote_monitor.log',
    'local_cleanup.json','analysis1.log','analysis_receipt.json','auxiliary_cleanup.json','analyze.py',
    'collect_closure.py','start_remote.sh','stop_remote.sh','check_remote_health.py','capture_launcher.py',
    'launch_gate.py','launch_gate.json','seal_measurement.py')]
paths += [raw/'source1_launch.launch'/n for n in ('service.log','watchdog.jsonl')]
archive=out/'measurement_audit_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        check(path.read_bytes())
        if path.suffix=='.py':ast.parse(path.read_bytes())
        tar.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in paths:assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw))).read()).hexdigest()==p.digest(path)
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count']==147 and seal['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='833ddd6dcc84e31700ad8bf13c5b449c56fe0f72'
for line in (out/'preparation.sha256').read_text().splitlines():
    sha,name=line.split('  ',1)
    assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)).hexdigest()==sha
with (out/'measurement_checkpoint.json').open('x') as f:
    json.dump(dict(passed=True,measurement_complete=True,profile_complete=False,full_qualified=False,
        source_execution_commit=head,source_run=dict(path=str(raw/'source1.json'),sha256=p.digest(raw/'source1.json'),bytes=(raw/'source1.json').stat().st_size),
        raw_source_retained=True,archive_bytes=archive.stat().st_size,protection=seal,
        source_refs=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
        plan_sha256=p.check_plan(),metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')),f,indent=2)
with (out/'measurement_outputs.sha256').open('x') as f:
    for name in ('coverage1.json','measurement_summary1.json','native_requests1.csv',
                 'short_gpu_coverage_diagnosis1.json','measurement_audit_evidence.tar.gz','measurement_checkpoint.json'):
        f.write(p.digest(out/name)+'  '+name+'\n')
with (raw/'measurement_seal_receipt.json').open('x') as f:json.dump(dict(passed=True,identity=p.scope_identity(p.cg_path().name)),f,indent=2)
print(json.dumps(dict(passed=True,archive_bytes=archive.stat().st_size,short_gpu_waves=short)),flush=True)
