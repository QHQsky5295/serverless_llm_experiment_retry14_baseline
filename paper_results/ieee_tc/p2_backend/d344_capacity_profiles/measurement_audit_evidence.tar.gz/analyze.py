"""Reuse source validators; coverage gates export, never default-filled profiles."""
import json,pathlib,sys,csv
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc import export_d298_profiles as exporter
from scripts.ieee_tc.export_d298_profiles import completed_gap_samples
from faaslora.storage.http_artifact_store import HttpArtifactStoreClient

def main():
    raw=pathlib.Path(__file__).resolve().parent
    out=ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles'
    run=json.loads((raw/'source1.json').read_text())
    launch=json.loads((raw/'source1_launch.json').read_text())
    assert run['pass'] and run['stage']=='complete'
    assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
    assert json.loads((raw/'remote_stop.json').read_text())['all_owned_units_inactive']
    specpath=out/'source_spec.json'
    assert p.digest(specpath)==run['source_profile_spec_sha256']
    spec=json.loads(specpath.read_text())
    assert spec==run['source_profile_spec']
    contentpath=ROOT/spec['content_index']['path']
    assert p.digest(contentpath)==spec['content_index']['sha256']
    content=json.loads(contentpath.read_text())
    client=HttpArtifactStoreClient(endpoint='http://127.0.0.1:1');client.configure_content_manifest(content)
    pool=(ROOT/'artifacts/frozen/llama2_7b_a500_v2_publicmix').resolve(strict=True)
    identities={r['id']:client.routing_identity(r['id'],(pool/r['id']/'adapter_config.json').read_bytes())
                for r in content['artifacts']}
    coverage=p.source_profile_class_coverage(run,identities)
    source_sha=p.digest(raw/'source1.json')
    samples,checked_coverage=completed_gap_samples(run,source_sha=source_sha,identities=identities)
    assert checked_coverage==coverage
    assert len(samples)==1515 and len(run['requests'])==1529
    transfers=[json.loads(line) for line in (raw/'remote_transfers.jsonl').read_text().splitlines()]
    remote={r['transfer_id']:r for r in transfers}
    assert len(remote)==len(transfers)==len(run['remote_transfers'])
    assert set(remote)=={r['http_transfer_id'] for r in run['remote_transfers']}
    remote_clock=json.loads((raw/'remote_health.json').read_text())['7b']['clock_id']
    for r in run['remote_transfers']:
        s=remote[r['http_transfer_id']]
        assert s['clock_id']==remote_clock and s['outcome']=='sent'
        assert r['state']=='published' and r['content_verified'] and r['published_archive_verified']
        assert r['artifact_id']==s['artifact_id'] and r['remote_archive_sha256']==s['archive_sha256']
        assert r['transferred_bytes']==s['archive_bytes']==s['bytes_read']==s['bytes_written']
        assert not r['remote_pack_performed'] and not s['pack_performed'] and not s['temporary_created']
    monitors=[]
    for line in (raw/'source1_launch.launch/watchdog.jsonl').open():
        r=json.loads(line)
        if r.get('event')=='resource_sample':monitors.append(r)
    assert monitors and not any(r['decision']['abort_reasons'] for r in monitors)
    life={e['event']:e['at'] for e in run['physical_allocation']['events']}
    assert len(run['physical_allocation']['gpu_uuids'])==1 and life['release']>life['acquire']
    for w in run['profile_waves']:
        assert w['complete']
        for k in ('capacity_before','capacity_after'):
            p.validate_capacity_probe_observation(w[k],run['model_config'],spec['capacity_probe_contract'])
    with (out/'coverage1.json').open('x') as f:json.dump(coverage,f,indent=2)
    with (out/'measurement_summary1.json').open('x') as f:
        json.dump(dict(kind='d344_complete_native_measurement_summary_v1',native_calls=1529,
            warmup_calls=14,measured_calls=1515,source_run_sha256=source_sha,
            physical_gpu_seconds=life['release']-life['acquire'],startup_latency_ms=run['startup_latency_ms'],
            fetches=len(transfers),wire_bytes=sum(r['transferred_bytes'] for r in run['remote_transfers']),
            request_packing=0,service_peak_bytes=max(r['service']['memory.peak'] for r in monitors),
            min_host_available_bytes=min(r['host']['available_bytes'] for r in monitors),
            service_swap_bytes=max(r['service']['memory.swap.current'] for r in monitors),
            memory_events={k:max(r['service']['memory.events'][k] for r in monitors) for k in ('high','max','oom','oom_kill')},
            missing_service_classes=len(coverage['missing_service_classes']),
            measured_service_classes=coverage['measured_service_classes'],
            required_service_classes=coverage['required_service_classes'],
            measured_preparation_classes=coverage['measured_preparation_classes'],
            class_domain_covered=coverage['class_domain_covered'],n_correct=None,full_qualified=False,
            common_SLO_qualified=False,independent_runs=1,CI=None),f,indent=2)
    actual_calls=len(run['requests'])
    # The exporter reads the same large source itself. Do not retain a second
    # parsed copy while it validates and serializes measured profile samples.
    del run, samples
    if coverage['class_domain_covered']:
        exporter.main('d344')
        manifest=json.loads((out/'initialization/manifest.json').read_text())
        # Exact numerical table, no figure styling while optimization is open.
        with (out/'initialization/service_estimates.csv').open('x',newline='') as f:
            rows=[dict(**x['service_class'],**{k:v for k,v in x.items() if k!='service_class'})
                  for x in manifest['estimates']['service']]
            writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
            writer.writeheader();writer.writerows(rows)
    record=dict(passed=True,profile_exported=coverage['class_domain_covered'],
        actual_calls=actual_calls,missing_classes=len(coverage['missing_service_classes']),
        missing_content_sources=len(coverage['missing_content_sources']),
        n_correct=None,formal_qualified=False,identity=p.scope_identity(p.cg_path().name))
    with (raw/'analysis_receipt.json').open('x') as f:json.dump(record,f,indent=2)
    print(json.dumps(record),flush=True)

if __name__=='__main__':
    main()
