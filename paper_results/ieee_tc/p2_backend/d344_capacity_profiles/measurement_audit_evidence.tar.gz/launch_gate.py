"""Close the sealed checkpoint and verify actual resources before D344."""
import json, pathlib, subprocess, sys
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
receipt=json.loads((raw/'checkpoint_receipt.json').read_text())
assert receipt['passed']
identity=receipt['identity']; group=pathlib.Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
values={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','scripts','faaslora','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
gate=p.preflight([ROOT],8*p.GIB)
assert gate['preflight_pass'],gate['issues']
with (raw/'launch_gate.json').open('x') as f:
    json.dump(dict(passed=True,local_head=head,remote_head=remote,preflight=gate,
        checkpoint_closed=True,checkpoint_resources=values),f,indent=2)
print(json.dumps(dict(passed=True,head=head,disk=gate['filesystems'][0]['free_bytes'],
    memory=gate['memory']['MemAvailable'])),flush=True)

