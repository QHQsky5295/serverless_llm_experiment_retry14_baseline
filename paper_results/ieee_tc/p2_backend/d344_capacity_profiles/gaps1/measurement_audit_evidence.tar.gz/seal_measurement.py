"""Seal D344's complete40-call gap measurement; no profile export or Full claim."""
import ast,csv,hashlib,json,pathlib,re,subprocess,sys,tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/gaps1'
read=lambda path:json.loads(path.read_text())
receipt=read(raw/'analysis_receipt2.json')
assert receipt['passed'] and receipt['target_classes_covered'] and not receipt['profile_exported']
closed=[]
for n in range(14,20):
    unit=f'primelora-tc-aux-{34400000000000000000000000000000+n}.scope'
    identity=p.scope_identity(unit);group=pathlib.Path(identity['path'])
    if unit==receipt['identity']['unit']:assert identity==receipt['identity']
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    assert int(resources['memory.swap.current'])==0
    assert all(int(v)==0 for _,v in (line.split() for line in resources['memory.events'].splitlines()))
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    closed.append(dict(identity=identity,resources=resources,inactive=True))
with (raw/'auxiliary_cleanup.json').open('x') as f:json.dump(closed,f,indent=2)
source=raw/'source1.json'
assert p.digest(source)=='764509162dd0889b469e6150ae42aed8ca018f1899271d7b1789406e04508e4d'
run=read(source);assert run['pass'] and len(run['requests'])==40 and run['physical_allocation']['released']
assert read(out/'coverage1.json')==read(out/'coverage2.json')
assert read(out/'measurement_summary1.json')==read(out/'measurement_summary2.json')
rows=[]
for q in run['requests']:
    i=int(q['request_id'].split('/')[1][1:]);wave=run['source_profile_spec']['waves'][i]
    f,t=q['class_features'],q['timing']
    rows.append(dict(request_id=q['request_id'],source_request_id=q['source_request_id'],adapter_id=q['adapter_id'],
        wave=i,round=wave['round'],role=wave['role'],source=q['requested_source'],
        target_tokens=q['target_tokens'],actual_tokens=q['actual_tokens'],rank=f['adapter_rank'],
        admitted_after_accept=f['admitted_after_accept'],admitted_bin=q['service_class']['admitted_bin'],
        output_bin=q['service_class']['output_limit_bin'],
        admitted_monotonic_s=q['admitted_monotonic_s'],last_token_monotonic_s=q['last_token_monotonic_s'],
        native_ttft_ms=(q['first_token_monotonic_s']-t['native_dispatch_monotonic_s'])*1000,
        native_tpot_ms=t['native_tpot_ms'],output_sha256=t['completion_token_ids_sha256']))
with (out/'native_requests1.csv').open('x',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
targets=[r for r in rows if r['role']=='representative_measurement' and r['output_bin']==0]
assert len(targets)==6 and all(9<=r['admitted_after_accept']<=14 for r in targets)
for r in targets:
    backgrounds=[x for x in rows if x['wave']==r['wave'] and x['output_bin']>0]
    r['live_backgrounds_at_target_admission']=sum(x['admitted_monotonic_s']<=r['admitted_monotonic_s']<x['last_token_monotonic_s'] for x in backgrounds)
    assert r['live_backgrounds_at_target_admission']==8
with (out/'gap_admission_diagnosis.json').open('x') as f:
    json.dump(dict(targets=targets,artificial_wait=False,new_requests=False,capacity_changed=False,
        interpretation='Eight original long requests remain live at each short-target admission; native counts fill both missing classes.'),f,indent=2)
base=read(out.parent/'coverage1.json');extra=read(out/'coverage2.json')
encode=lambda key:json.dumps(key,sort_keys=True)
required={encode(r['service_class']) for r in base['observed_service_counts']}|{encode(k) for k in base['missing_service_classes']}
counts={encode(r['service_class']):r['count'] for r in base['observed_service_counts']}
for row in extra['observed_service_counts']:
    k=encode(row['service_class']);assert k in required;counts[k]=counts.get(k,0)+row['count']
assert set(counts)==required and len(required)==200 and not base['missing_content_sources']
with (out/'coverage_union.json').open('x') as f:
    json.dump(dict(kind='measured_class_count_union_not_profile_export_v1',required=200,observed=200,missing=[],
        counts=[dict(service_class=json.loads(k),count=v) for k,v in sorted(counts.items())],
        coverage_sources=[dict(path=str(x),sha256=p.digest(x)) for x in (out.parent/'coverage1.json',out/'coverage2.json')],
        profiles_exported=False,full_qualified=False,n_correct=None),f,indent=2)
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
names=('source1_launch.json','source_commit.txt','source1_launcher.log','launcher_identity.json',
    'remote_start.log','remote_stop.log','remote_stop.json','remote_health.json','remote_transfers.jsonl',
    'remote_monitor.log','local_cleanup.json','analysis_receipt2.json','analysis1_failure.json',
    'auxiliary_cleanup.json','analyze.py','analyze2.py','collect_closure.py','start_remote.sh',
    'stop_remote.sh','check_remote_health.py','capture_launcher.py','launch_gate.py','launch_gate.json','seal_measurement.py')
paths=[raw/n for n in names]+[raw/'source1_launch.launch'/n for n in ('service.log','watchdog.jsonl')]
archive=out/'measurement_audit_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        check(path.read_bytes())
        if path.suffix=='.py':ast.parse(path.read_bytes())
        tar.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in paths:assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw))).read()).hexdigest()==p.digest(path)
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count']==147 and seal['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='7431ad6bde014182289c5e48daff68b4008cd428'
for line in (out/'preparation.sha256').read_text().splitlines():
    sha,name=line.split('  ',1)
    assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)).hexdigest()==sha
with (out/'measurement_checkpoint.json').open('x') as f:
    json.dump(dict(passed=True,measurement_complete=True,profile_exported=False,full_qualified=False,
        source_execution_commit=head,source_run=dict(path=str(source),sha256=p.digest(source),bytes=source.stat().st_size),
        raw_source_retained=True,archive_bytes=archive.stat().st_size,protection=seal,
        source_refs=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
        plan_sha256=p.check_plan(),metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')),f,indent=2)
outputs=('coverage1.json','coverage2.json','measurement_summary1.json','measurement_summary2.json',
    'native_requests1.csv','gap_target_coverage.json','gap_admission_diagnosis.json','coverage_union.json',
    'measurement_audit_evidence.tar.gz','measurement_checkpoint.json')
with (out/'measurement_outputs.sha256').open('x') as f:
    for name in outputs:f.write(p.digest(out/name)+'  '+name+'\n')
with (raw/'measurement_seal_receipt.json').open('x') as f:
    json.dump(dict(passed=True,identity=p.scope_identity(p.cg_path().name)),f,indent=2)
print(json.dumps(dict(passed=True,calls=40,target_counts=[r['admitted_after_accept'] for r in targets],
    live_backgrounds=[r['live_backgrounds_at_target_admission'] for r in targets],
    class_union=200,archive_bytes=archive.stat().st_size)),flush=True)
