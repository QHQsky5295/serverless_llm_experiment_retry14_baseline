"""Close the completed preparation scope and run bounded CPU regression."""
import json,pathlib,subprocess,sys,unittest
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

def main():
    raw=pathlib.Path(__file__).resolve().parent
    identity=json.loads((raw.parent.parent/'d344_gap_cpu1.json').read_text())['identity']
    group=pathlib.Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    assert int(resources['memory.swap.current'])==0
    assert all(int(v)==0 for _,v in (line.split() for line in resources['memory.events'].splitlines()))
    subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
    with (raw/'prepare_cleanup.json').open('x') as f:json.dump(dict(identity=identity,resources=resources,inactive=True),f,indent=2)
    names=['tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer',
        'tests.test_ieee_tc_preflight.CapacityProbeObservation','tests.test_ieee_tc_warm_reference',
        'tests.test_ieee_tc_request_lifecycle','tests.test_ieee_tc_launch']
    with (raw/'cpu_tests.log').open('x') as f:
        result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
    record=dict(tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
        successful=result.wasSuccessful(),gpu_runs=0,identity=p.scope_identity(p.cg_path().name))
    with (raw/'cpu_tests.json').open('x') as f:json.dump(record,f,indent=2)
    print(json.dumps(record),flush=True)
    assert result.wasSuccessful()

if __name__=='__main__':
    main()
