"""D344 prelaunch seal and exact-path backup preparation; no inference."""
import ast,json,pathlib,re,subprocess,sys,tarfile,hashlib
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/gaps1'
tests=json.loads((raw/'cpu_tests.json').read_text());assert tests['successful']
identity=tests['identity'];group=pathlib.Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
values={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
assert int(values['memory.swap.current'])==0
assert all(int(v)==0 for _,v in (line.split() for line in values['memory.events'].splitlines()))
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
with (raw/'cpu_cleanup.json').open('x') as f:json.dump(dict(identity=identity,resources=values,inactive=True),f,indent=2)
prepared=json.loads((out/'prepare.json').read_text())
for r in prepared['source_refs']:
    assert p.digest(pathlib.Path(r['path']))==r['sha256']
assert p.digest(out/'source_spec.json') == prepared['spec_sha256']
assert p.check_plan()==prepared['plan_sha256']=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')==prepared['metric_protocol_sha256']=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=[raw/n for n in ('validate.py','cpu_tests.json','cpu_tests.log','cpu_cleanup.json',
    'prepare_cleanup.json','scope10_cleanup.json','start_remote.sh','stop_remote.sh','check_remote_health.py','collect_closure.py','checkpoint.py')]
files += [raw.parent.parent/n for n in ('d344_gap_prepare.py','d344_gap_cpu1.log','d344_gap_cpu1.json')]
archive=out/'preparation_evidence.tar.gz'
with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz') as tar:
    for path in files:
        check(path.read_bytes())
        if path.suffix=='.py':ast.parse(path.read_bytes())
        if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in files:assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest()==p.digest(path)
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count']==147 and seal['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
with (out/'checkpoint.json').open('x') as f:json.dump(dict(passed=True,tests=tests['tests'],
    test_resources=values,protection=seal,archive_sha256=p.digest(archive),gpu_runs=0,
    parent_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()),f,indent=2)
names=['scripts/ieee_tc/prepare_d298_capacity.py','scripts/ieee_tc/run_d298_capacity_source.sh','tests/test_ieee_tc_preflight.py',
    'docs/ieee_tc/D344_C14_PROFILE_REFRESH.md','docs/ieee_tc/EXECUTION_STATUS.md']
names += [str(x.relative_to(ROOT)) for x in sorted(out.iterdir()) if x.is_file()]
for name in names:check((ROOT/name).read_bytes())
with (out/'preparation.sha256').open('x') as f:
    for name in names:f.write(p.digest(ROOT/name)+'  '+name+'\n')
names.append(str((out/'preparation.sha256').relative_to(ROOT)))
subprocess.run(['sha256sum','-c',str(out/'preparation.sha256')],cwd=ROOT,check=True)
subprocess.run(['git','diff','--check','--',*names],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (raw/'checkpoint_receipt.json').open('x') as f:json.dump(dict(passed=True,identity=p.scope_identity(p.cg_path().name),paths=names),f,indent=2)
print(json.dumps(dict(passed=True,tests=tests['tests'],paths=len(names),archive_bytes=archive.stat().st_size)),flush=True)
