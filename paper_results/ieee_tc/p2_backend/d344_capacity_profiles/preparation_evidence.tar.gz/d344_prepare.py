"""Bounded CPU-only preparation; existing collector, no inference or new data."""
import json,pathlib,sys,unittest
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.prepare_d298_capacity import prepare_capacity_profiles

def main():
    parent=pathlib.Path(__file__).resolve().parent
    names=['tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer',
           'tests.test_ieee_tc_preflight.CapacityProbeObservation']
    with (parent/'d344_cpu1.log').open('x') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
    record=dict(successful=result.wasSuccessful(),tests=result.testsRun,
        failures=len(result.failures),errors=len(result.errors),gpu_runs=0,
        identity=p.scope_identity(p.cg_path().name))
    with (parent/'d344_cpu1.json').open('x') as stream:json.dump(record,stream,indent=2)
    print(json.dumps(record),flush=True)
    assert result.wasSuccessful()
    prepare_capacity_profiles()

if __name__=='__main__':
    main()
