"""Read D634 retained preparation receipts, without loading its full outcome."""
import json
import os
import sys
from collections import Counter
from pathlib import Path
import ijson

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
PREVIOUS = RAW.parent/'d634_20261017'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
def save(name, value):
    with (RAW/name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
save('analysis_identity.json', identity)
source = PREVIOUS/'7b_min2_full_w0/launch.launch/physical_deployment/main_outcome.json'
failure = json.loads((PREVIOUS/'failure_analysis.json').read_text())
expected = next(r for r in failure['refs'] if r['path'] == str(source))
assert p.digest(source) == expected['sha256']
counts = Counter()
differences = []
unresolved = []
with source.open('rb') as stream:
    for plan in ijson.items(stream, 'mechanism_events._ieee_gpu_preparation_plans.item', use_float=True):
        counts['plans'] += 1
        for attempt in plan['attempts']:
            counts['attempts'] += 1
            counts['state_'+attempt['state']] += 1
            if attempt['state'] == 'native_outcome_unresolved':
                unresolved.append(dict(plan={k:v for k,v in plan.items() if k!='attempts'}, attempt=attempt))
            for aid, item in attempt.get('host_file_fallbacks', {}).items():
                counts['fallbacks'] += 1
                observed = item['source']
                if observed['tier'] == 'remote':
                    counts['remote'] += 1
                    continue
                lease = item['file_reference']
                confirmed = lease.get('confirmed_source') or {}
                pairs = {
                    'held': ('held', lease.get('state')),
                    'verified': (True, lease.get('content_verified')),
                    'adapter': (observed.get('adapter_id'), lease.get('adapter_id')),
                    'owner': (observed.get('owner_id'), lease.get('owner_id')),
                    'path': (observed.get('path'), lease.get('path')),
                    'tier': (observed.get('tier'), lease.get('tier')),
                    'content': (observed.get('content_sha256'), confirmed.get('content_sha256')),
                    'footprint': (observed.get('footprint_bytes'), confirmed.get('allocated_file_bytes')),
                    'representation': (observed.get('representation'), confirmed.get('representation')),
                }
                mismatch = {k:dict(source=v[0], lease=v[1]) for k,v in pairs.items() if v[0]!=v[1]}
                if mismatch:
                    differences.append(dict(plan_id=plan['plan_id'], owner_id=plan['owner_id'],
                        plan_state=plan['state'], attempt_id=attempt['attempt_id'],
                        attempt_state=attempt['state'], target_adapter_int_id=attempt['adapter_int_id'],
                        fallback_adapter_int_id=aid, differences=mismatch, evidence=item))
result = dict(source=expected, source_failure_sha256=p.digest(PREVIOUS/'failure_analysis.json'),
    counts=dict(counts), differences=differences, unresolved=unresolved,
    scope=identity, no_production_change=True, no_gpu_run=True)
save('receipt_audit.json', result)
print(json.dumps(dict(counts=dict(counts), difference_count=len(differences),
    unresolved_count=len(unresolved), differences=differences), indent=2))
