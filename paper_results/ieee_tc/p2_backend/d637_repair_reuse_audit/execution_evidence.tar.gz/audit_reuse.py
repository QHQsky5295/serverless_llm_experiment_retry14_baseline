"""Audit whether D635 changes any retained W1/W2 fallback payload.

Reuse D635's field audit and additionally reconstruct the complete repaired
payload from each held confirmation. This is offline evidence, not a replay.
"""
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json', identity)
cg = Path(identity['path'])
assert (cg/'memory.max').read_text().strip() == str(4*p.GIB)
assert (cg/'memory.high').read_text().strip() == str(3*p.GIB)
assert (cg/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
gate = p.preflight([ROOT], 32*1024*1024)
assert gate['preflight_pass'], gate['issues']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
source = RAW.parent/'d635_20261017/analyze.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '825b2c594cc63072c1fd24d6592b8e6166b4a23d1af3de211e50645b1ee2ec1a'
results = []
for run_id, run_tag, curated in (
    ('d632', '7b_min2_full_w2', 'd632_min2_full_w2'),
    ('d633', '7b_min2_full_w1', 'd633_min2_full_w1')):
    code = data.decode()
    def replace(old, new):
        global code
        assert code.count(old) == 1, old
        code = code.replace(old, new)
    replace("PREVIOUS = RAW.parent/'d634_20261017'", "PREVIOUS = RAW.parent/'%s_20261017'" % run_id)
    replace("save('analysis_identity.json', identity)", 'assert identity == outer_identity')
    replace("'7b_min2_full_w0/launch.launch/physical_deployment/main_outcome.json'",
            "'%s/launch.launch/physical_deployment/main_outcome.json'" % run_tag)
    replace("failure = json.loads((PREVIOUS/'failure_analysis.json').read_text())",
            "failure = json.loads((PREVIOUS/'actual_qualification.json').read_text())")
    replace("source_failure_sha256=p.digest(PREVIOUS/'failure_analysis.json')",
            "source_audit_sha256=p.digest(PREVIOUS/'actual_qualification.json')")
    replace("save('receipt_audit.json', result)", "save('%s_receipt_audit.json', result)" % run_id)
    replace("'representation': (observed.get('representation'), confirmed.get('representation')),",
            """'representation': (observed.get('representation'), confirmed.get('representation')),
                    'complete_payload': (observed, dict(confirmed, native=False,
                        owner_id=lease['owner_id'], footprint_bytes=confirmed['allocated_file_bytes'])),""")
    ast.parse(code)
    namespace = dict(__file__=__file__, __name__='d637_'+run_id, outer_identity=identity)
    with contextlib.redirect_stdout(io.StringIO()):
        exec(compile(code, str(source), 'exec'), namespace)
    result = namespace['result']
    summary_path = ROOT/'paper_results/ieee_tc/p2_backend'/curated/'result1/summary.json'
    summary = read(summary_path)
    assert summary['passed'] and summary['audit'] == namespace['failure']
    qualification = read(RAW.parent/(run_id+'_20261017')/'qualification.json')
    revision = summary['execution_commit']
    refs = []
    for relative in ('scripts/run_all_experiments.py', 'faaslora/coordination/autoscaler.py',
                     'faaslora/cpu_frontend.py', 'faaslora/memory/residency_manager.py'):
        path = ROOT/relative
        old_sha = qualification['refs'][str(path)]
        old_bytes = subprocess.check_output(['git', 'show', revision+':'+relative], cwd=ROOT)
        assert hashlib.sha256(old_bytes).hexdigest() == old_sha
        refs.append(dict(path=str(path), reference_sha256=old_sha, current_sha256=p.digest(path)))
    assert [r['path'] for r in refs if r['reference_sha256'] != r['current_sha256']] == [str(ROOT/'scripts/run_all_experiments.py')]
    changes = subprocess.check_output(['git', 'diff', '--no-ext-diff', '--unified=0',
        revision, '15aa23e2283ba5f469937b5c4aaab447ddbe7b49', '--', 'scripts/run_all_experiments.py'], cwd=ROOT, text=True)
    assert changes.count('@@') == 2 and 'confirmed = held' in changes
    same = not result['differences'] and not result['unresolved']
    results.append(dict(run=run_id.upper(), source_summary=dict(path=str(summary_path), sha256=p.digest(summary_path)),
        original_execution_commit=revision, counts=result['counts'],
        full_fallback_payload_mismatch_count=len(result['differences']),
        unresolved_native_outcome_count=len(result['unresolved']),
        repaired_payload_identical_for_every_recorded_attempt=same,
        production_refs=refs, runner_patch=changes,
        raw_result_unchanged=True, original_version_preserved=True,
        reuse_class='R2_with_bounded_affected_path_equivalence' if same else 'R3_affected_path_not_equivalent',
        exact_same_execution_contract=False, new_version_performance_executed=False,
        timing_equivalence_proved=False, independent_numerical_correctness='unknown'))
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
save(RAW/'reuse_impact.json', dict(passed=True, records=results, protected=protected,
    reused_auditor=dict(path=str(source), sha256=p.digest(source)), scope=identity,
    no_production_change=True, no_gpu_run=True, no_historical_result_rewrite=True,
    interpretation='Payload equivalence is a bounded offline observation on recorded attempts, not an execution of the repaired version or proof of timing equivalence. Retain original versions; no R0 relabeling or final cross-version ranking.'))
print(json.dumps([dict(run=r['run'], counts=r['counts'],
    full_payload_mismatches=r['full_fallback_payload_mismatch_count'],
    unresolved=r['unresolved_native_outcome_count']) for r in results]))
