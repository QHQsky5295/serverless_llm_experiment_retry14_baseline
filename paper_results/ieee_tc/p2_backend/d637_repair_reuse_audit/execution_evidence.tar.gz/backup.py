"""Reuse the explicit D595 checkpoint for this offline audit and scope decision."""
import ast
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code = source.read_text()

def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d637_repair_reuse_audit'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'",
        "=='62836866416c85b8894e79f6d75165f090fe00d5'")
begin = code.index('reg=read(RAW/')
end = code.index('preserved={', begin)
code = code[:begin] + """audit=read(RAW/'reuse_impact.json')
assert audit['passed'] and audit['no_gpu_run'] and audit['no_production_change']
for row in audit['records']:
    assert row['full_fallback_payload_mismatch_count']==0
    assert row['unresolved_native_outcome_count']==0
    assert p.digest(Path(row['source_summary']['path']))==row['source_summary']['sha256']
    for ref in row['production_refs']:
        assert p.digest(Path(ref['path']))==ref['current_sha256']
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
previous=RAW.parent/'d636_20261017'
completion=read(previous/'publication2_receipt.json')
closed=read(previous/'publication2_closure.json')
assert completion['passed'] and completion['head']=='62836866416c85b8894e79f6d75165f090fe00d5'
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',
    'faaslora','scripts','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
""" + code[end:]
begin = code.index('members=[RAW/name')
end = code.index('\nfor path in members:', begin)
code = code[:begin] + """members=[RAW/name for name in ('audit_reuse.py','close.py','backup.py',
    'analysis_identity.json','analysis_closure.json','d632_receipt_audit.json',
    'd633_receipt_audit.json','reuse_impact.json','backup_gate.json')]
members += [previous/'publication2_receipt.json',previous/'publication2_closure.json',
    RAW.parent/'d635_20261017/analyze.py',
    ROOT/'docs/ieee_tc/D637_REPAIR_REUSE_AND_CORRECTNESS_SCOPE.md',
    ROOT/'docs/ieee_tc/D393_7B_CORRECTNESS_AND_REMOTE_METRIC_ALIGNMENT.md']
assert len({path.name for path in members})==len(members)
for path in members:
    if path.suffix=='.py':
        import ast
        ast.parse(path.read_text())
""" + code[end:]
begin = code.index('test_counts={')
end = code.index("save(OUT/'qualification.json'", begin)
code = code[:begin] + """test_counts={'offline_runs_audited':len(audit['records']),
    'complete_fallback_payloads':sum(row['counts']['fallbacks'] for row in audit['records'])}
record=dict(passed=True,production_candidate=False,native_gpu_validation=False,
    full_performance_run=False,parent_commit='62836866416c85b8894e79f6d75165f090fe00d5',
    audit=audit,protected=protected,preserved={str(k):v for k,v in preserved.items()},
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    archive_members={path.name:dict(path=str(path),sha256=p.digest(path)) for path in members},
    caveat='Bounded equality of recorded fallback payloads, not same-version execution or timing equivalence. Cross-backend exact token equality is not a new V1 correctness requirement; preserve independent numerical uncertainty and old raw identities.')
""" + code[end:]
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D637_REPAIR_REUSE_AND_CORRECTNESS_SCOPE.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: audit W1/W2 repair impact and retain correctness protocol boundary (D637)')
ast.parse(code)
exec(compile(code, str(source), 'exec'))
