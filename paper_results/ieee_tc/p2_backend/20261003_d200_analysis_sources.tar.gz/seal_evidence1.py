"""D161 small-file evidence sealing reused for the completed D200 diagnostic."""
import ast
import hashlib
import json
import re
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d200_20261003'
out = root/'paper_results/ieee_tc/p2_backend'
verification_path = out/'20261003_d200_evidence_verification.json'
assert not verification_path.exists()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert not subprocess.check_output(['git','diff','--name-only','c75ef3750b4fc739f9351f713578fb2bbe9f3ca1','--','faaslora','scripts','tests','configs/ieee_tc'],text=True).strip()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
curated = out/'20261003_d200_prefix_diagnostic.json'
assert digest(curated) == '23ffb565ccfb93f74bc4283bca82b56eab417989e4eeb4b4a4626176819e683d'
value = json.loads(curated.read_text())
assert not value['formal_performance_result'] and value['prefix_count']==1000
refs = {}
for ref in value['source_refs'] + value['boundaries']['source_refs'] + [r for p in value['cpu']['processes'] for r in p['source_refs']]:
    p = Path(ref['path']).resolve()
    if str(p) in refs:
        assert refs[str(p)] == ref['sha256']
    else:
        assert digest(p) == ref['sha256'], str(p)
        refs[str(p)] = ref['sha256']
preflight = json.loads((raw/'prelaunch_verification.json').read_text())
for path, sha in preflight['source_sha256'].items():
    assert digest(root/path) == sha, path
closures = []
for suffix, expected, receipt in (
    ('cpu-collection','b372a59811a14a1cb71db16c25bf77f9','cpu_collection_scope.txt'),
    ('prefix1-metadata','245057c1874643929bb63dd7676a3693','prefix1_metadata_scope.txt'),
    ('prefix1-curation','2750a8509b5443a8aba318f8a342e493','prefix1_curation_scope.txt'),
    ('boundaries1','4f58160d4d854163afd2a6d4f5f49f3c','boundaries1_scope.txt')):
    unit = f'primelora-d200-{suffix}-20261003.scope'
    assert f'InvocationID={expected}' in (raw/receipt).read_text()
    for prop, wanted in (('ActiveState','inactive'),('InvocationID',''),('ControlGroup','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip()==wanted
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    closures.append(dict(unit=unit,actual_invocation_id=expected,inactive=True,
        cgroup_absent=True,final_counters='zero in terminal tool output; not reread after removal'))
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
for p in raw.glob('*.py'):
    ast.parse(p.read_text(),filename=str(p))
for p in raw.glob('*.sh'):
    subprocess.run(['bash','-n',str(p)],check=True)
e = raw/'7b_full_w0_prefix1/launch.launch'
large = [e/'watchdog.jsonl',raw/'remote_monitor_prefix1_final.log',
         e/'physical_deployment/main_outcome.json',Path(value['preliminary']['normal_source_stat']['path'])]
large_refs = [dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=digest(p)) for p in large]
doc = root/'docs/ieee_tc/D200_CONTROL_BOUNDARY_PREFIX.md'
table = out/'20261003_d200_prefix_roles.csv'
assert digest(table)=='a763432404897a4d1990246ddcf1200466bed36c6c49578ed52c0c1f4d9510d3'
# Reconcile this diagnostic's exact summary and document, without reclassifying missing data.
document = doc.read_text()
boundary_table = out/'20261003_d200_control_boundary_table.md'
boundaries = value['boundaries']
assert boundaries['attempts'] == boundaries['statuses']['success_complete'] == 4204
assert boundaries['events'] == 46244 and boundaries['complete_success_coverage']
assert not boundaries['partial_lines']
for field, mean, p95 in (
    ('frontend_native_send__to__native_begin',96.328020,408.975018),
    ('native_begin__to__native_ready',12.315801,29.037574),
    ('native_ready__to__frontend_native_received',24.726790,92.819631),
    ('frontend_ready__to__parent_received',35.193664,162.835339),
    ('parent_total_ms',179.796957,648.557653),
    ('native_thread_cpu_ms',9.520286,15.380119)):
    metric, = [m for m in boundaries['metrics'] if m['phase']=='business' and m['field']==field]
    assert metric['count']==4204
    assert round(metric['mean'],6)==mean and round(metric['p95'],6)==p95
    assert f'{mean:.6f} | {p95:.6f}' in document
    assert f'| {field} | 4204 | {mean:.6f} |' in boundary_table.read_text()
controller, = [p for p in value['cpu']['processes'] if p['pid']==2361577]
assert controller['main_phase_counts']['request_window']==537
for name, count in (('_decode_native_rpc_frame',45),('_local_file_inventory',26),('_planning_source_observations',17)):
    entry, = [r for r in controller['request_window_nearest_project'] if r['function']==name]
    assert entry['samples']==count
assert sum(p['truncated_main_samples'] for p in value['cpu']['processes'])==6
assert sum(p['missing_main_samples'] for p in value['cpu']['processes'])==0
assert sum(p['final_partial_line_bytes'] for p in value['cpu']['processes'])==0
assert value['preliminary']['population']['success']==1000
assert value['preliminary']['remote']['uuid_pairs']==60
assert value['preliminary']['remote']['client_received_bytes']==74953014
assert value['preliminary']['physical_gpu_seconds']==4452.071693249978
assert value['preliminary']['source_stats']['rpc_invocations']==4204
# Preserve original logs and analysis helpers in one small portable bundle.
# Only bounded small files; the normal result, compact metadata and raw stacks
# stay in the existing result directory with their SHA references.
members = sorted(p for p in raw.iterdir() if p.is_file() and p.stat().st_size < 2*1024**2
    and p.suffix in {'.py','.sh','.log','.txt','.json','.yaml','.sha256'}
    and p.name not in {'seal1.log','seal_scope1.txt','launch_outer1.log'})
members += sorted(p for folder in ('cache1','cache2','control_boundaries1') for p in (raw/folder).iterdir()
    if p.is_file() and p.stat().st_size<2*1024**2
    and p.suffix in {'.py','.sh','.log','.txt','.json','.jsonl','.csv'})
assert digest(raw/'cache2/public_download_cache_audit1.json') == '706b48b37ff17689f204bc15ccc16667cbce6cb2045f41665e09db264164e06d'
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret)>16
for p in members+[doc,table,boundary_table,curated]:
    data = p.read_bytes()
    assert secret not in data, 'credential found'
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
result = dict(kind='d200_diagnostic_evidence_verification_v1',
    verified_at=datetime.now(timezone.utc).isoformat(),checks_pass=True,
    formal_performance_result=False,serving_changed=False,
    source_refs=[dict(path=p,sha256=sha) for p,sha in sorted(refs.items())],
    curated_refs=[dict(path=str(p.resolve()),sha256=digest(p)) for p in (doc,table,boundary_table,curated)],
    frozen_refs_verified=len(preflight['source_sha256']),protected=protected,closures=closures,
    large_source_refs=large_refs,
    next='Inspect actual vLLM utility scheduling/response and Prime call path against official source; no new optimizer accepted')
with verification_path.open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
hashes = {str(p.relative_to(raw)):digest(p) for p in members}
bundle = out/'20261003_d200_analysis_sources.tar.gz'
assert not bundle.exists()
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        archive.add(p,arcname=str(p.relative_to(raw)),recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name,expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected
with (out/'20261003_d200_analysis_sources.sha256').open('x') as f:
    f.write(digest(bundle)+'  '+bundle.name+'\n')
with (out/'20261003_d200_analysis_sources_members.json').open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(verification_sha256=digest(verification_path),
    bundle_sha256=digest(bundle),bundle_bytes=bundle.stat().st_size,members=len(members),
    protected=147,source_refs=len(refs),frozen_refs=len(preflight['source_sha256']))))
