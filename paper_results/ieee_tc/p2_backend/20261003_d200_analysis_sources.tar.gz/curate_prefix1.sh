#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d200_20261003
unit=primelora-d200-prefix1-curation-20261003.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/prefix1_curation_scope.txt"
export PYTHONPATH="$PWD" PYTHONDONTWRITEBYTECODE=1
/usr/bin/time -v -o "$raw/prefix1_curation_time.txt" /usr/bin/python3 "$raw/curate_prefix1.py" > "$raw/prefix1_curation.log" 2>&1
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
