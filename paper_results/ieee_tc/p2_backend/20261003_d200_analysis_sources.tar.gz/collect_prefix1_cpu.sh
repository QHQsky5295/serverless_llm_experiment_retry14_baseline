#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d200_20261003
unit=primelora-d200-cpu-collection-20261003.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test "$(systemctl --user show primelora-tc-svc-5c3eb2f2a2c14d249e224f5311a2b94e.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show primelora-tc-aux-dfbd3ac771f348919fc489b5daaba34f.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/cpu_collection_scope.txt"
# D143 collector already qualified; byte-equivalence except campaign labels checked before launch.
/usr/bin/time -v -o "$raw/cpu_collection_time.txt" /usr/bin/python3 "$raw/collect_prefix1_cpu.py" > "$raw/cpu_collection.log" 2>&1
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
