#!/usr/bin/env bash
set -euo pipefail
# Existing D150 exact-identity cleanup, bound to this actual activation.
# Execute remotely ONLY after local terminal and physical GPU cleanup.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d200prefix1.service)
ids=(2bfcb78c0818438daa6d1a03cc42d170 14ae44c2bd5f461db9227a961fe3cc57 e5020271cb6c4780905090375efacf15)
pids=(1451251 1451253 1451256)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result
