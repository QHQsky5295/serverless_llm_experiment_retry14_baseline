#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d200_20261003
unit=primelora-d200-boundaries1-20261003.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test "$(systemctl --user show primelora-tc-svc-5c3eb2f2a2c14d249e224f5311a2b94e.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show primelora-tc-aux-dfbd3ac771f348919fc489b5daaba34f.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/boundaries1_scope.txt"
# D199 strict boundary analyzer, qualified before this replay; fresh diagnostic output only.
export PYTHONPATH="$PWD" PYTHONDONTWRITEBYTECODE=1
e="$raw/7b_full_w0_prefix1/launch.launch"
test -s "$raw/prefix1_local_cleanup.txt"
/usr/bin/time -v -o "$raw/boundaries1_time.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python scripts/analyze_control_path_overhead.py \
  --control-boundaries --input "$e/diagnostic_stacks" \
  --launch-receipt "$e/exec_receipt.json" \
  --deployment "$e/physical_deployment/deployment.json" \
  --output "$raw/control_boundaries1" > "$raw/boundaries1.log" 2>&1
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
