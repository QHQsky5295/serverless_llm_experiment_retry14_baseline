"""Reclaim only proven public wheel HTTP downloads, never installed environments.

D200: inspect remaining 10-30 MiB public HTTP downloads, including freshly observed
public scientific-library and build-tool wheel downloads. Never remove installed packages or custom builds.
Reuse the exact public package allowlist; custom versions remain protected.
All public registry SHA/size/HEAD, reference and ownership checks unchanged.
Reuse the previous cleanup's ownership, file identity, open-file and git guards.
The allowlist is generated read-only; apply requires its reviewed SHA argument.
"""
import argparse
from email.parser import BytesParser
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import time
import urllib.request
import zipfile
from pip._vendor import msgpack

ROOT = Path('/home/qhq/.cache/pip/http-v2')
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('prior_cleanup', '/home/qhq/experimental_cleanup_20260916/cleanup.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
digest = prior.helpers.digest_file

def save(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())

def guard():
    assert ROOT.resolve() == ROOT and not ROOT.is_symlink()
    assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    prior.no_active(ROOT)
    # Only the pip-managed HTTP cache is eligible, not local builds/wheels.
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        mount = Path(line.split()[4])
        assert mount != ROOT and not mount.is_relative_to(ROOT), mount

def reference_audit():
    hits = []
    checked = []
    for repo in prior.helpers.REPOS:
        for name in ('scripts', 'configs', 'docs'):
            path = repo / name
            if not path.is_dir():
                continue
            cmd = ['rg', '-l', '--hidden', '--no-ignore', '-F', '.cache/pip/http-v2',
                   '-g', '*.py', '-g', '*.sh', '-g', '*.yaml', '-g', '*.yml',
                   '-g', '*.toml', '-g', '*.ini', '-g', '*.cfg', '-g', '*.md',
                   '-g', '*.txt', '-g', '*.json', str(path)]
            result = subprocess.run(cmd, capture_output=True, text=True)
            assert result.returncode in (0, 1), result.stderr
            checked.append(str(path))
            hits.extend(result.stdout.splitlines())
    assert not hits, hits
    # Link count guards hardlinks; also reject environment symlinks to cache.
    for envroot in ('/home/qhq/.venvs', '/home/qhq/anaconda3/envs'):
        result = subprocess.run(['find', envroot, '-type', 'l', '-lname', '*cache/pip*', '-print'],
                                capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        assert not result.stdout, result.stdout
    return dict(checked=checked, direct_cache_path_hits=hits,
                installed_environment_cache_symlinks=0,
                scope='Project scripts/configs/docs plus installed-environment symlinks; not a whole-home text audit.')

def audit():
    guard()
    refs = reference_audit()
    selected = []
    retained = []
    registry = {}
    candidates = sorted((p for p in ROOT.rglob('*.body')
        if p.is_file() and 10*1024**2 <= p.stat().st_size < 30*1024**2),
        key=lambda p: (-p.stat().st_size, str(p)))
    candidate_paths = [str(p) for p in candidates]
    for body in candidates:
        if sum(row['allocated_bytes'] for row in selected) >= 2 * 1024**3:
            break
        assert body.is_relative_to(ROOT) and body.resolve() == body
        if not body.exists():
            retained.append(dict(path=str(body), reason='already absent; no action')); continue
        if not 10*1024**2 <= body.stat().st_size < 30*1024**2:
            continue
        header = body.with_suffix('')
        stamps = {str(p): prior.stamp(p) for p in (body, header)}
        if any(not stat.S_ISREG(s['mode']) or s['uid'] != os.getuid() or s['nlink'] != 1 for s in stamps.values()):
            retained.append(dict(path=str(body), reason='not an exclusively owned regular download')); continue
        raw = header.read_bytes()
        assert raw.startswith(b'cc=4,')
        metadata = msgpack.loads(raw.split(b',', 1)[1], raw=False)
        headers = {k.lower():v for k,v in metadata['response']['headers'].items()}
        project, version = headers.get('x-pypi-file-project'), headers.get('x-pypi-file-version')
        identity_source = 'pip_response_headers'
        if not project or not version:
            # Missing mirror headers do not prove identity. Read only wheel
            # metadata, then require exact public registry size/SHA/HEAD below.
            with zipfile.ZipFile(body) as archive:
                metadata = [n for n in archive.namelist() if n.endswith('.dist-info/METADATA')]
                if len(metadata) != 1:
                    retained.append(dict(path=str(body), reason='ambiguous wheel metadata; retained'))
                    continue
                info = archive.getinfo(metadata[0])
                assert info.file_size < 1024**2
                fields = BytesParser().parsebytes(archive.read(info))
            project, version = fields['Name'], fields['Version']
            identity_source = 'wheel_metadata_verified_against_public_registry'
        if project:
            project = project.lower().replace('_', '-')
        if not project or not version or not (project in ('torch', 'vllm', 'triton', 'xformers', 'flashinfer-cubin', 'cupy-cuda12x', 'sglang-kernel', 'pyarrow', 'llvmlite', 'scipy', 'xgrammar', 'opencv-python-headless', 'bitsandbytes', 'nixl-cu12', 'nixl-cu13', 'vllm-flash-attn', 'cmake', 'uv', 'numpy', 'pulp', 'cuda-bindings', 'plotly', 'botocore', 'llguidance', 'pandas', 'transformers', 'matplotlib', 'scikit-learn') or project.startswith('nvidia-')):
            retained.append(dict(path=str(body), reason='outside explicit public PyPI package allowlist')); continue
        if '+' in version:
            retained.append(dict(path=str(body), reason='custom local-version build; retained')); continue
        key = (project, version)
        if key not in registry:
            with urllib.request.urlopen(f'https://pypi.org/pypi/{project}/{version}/json', timeout=20) as response:
                registry[key] = json.load(response)
        sha = digest(body)
        matches = [r for r in registry[key]['urls'] if r['digests']['sha256'] == sha and r['size'] == stamps[str(body)]['size']]
        if not matches:
            retained.append(dict(path=str(body), reason='no exact public registry size/SHA match; retained', project=project, version=version, sha256=sha))
            continue
        assert len(matches) == 1, (body, project, version)
        match = matches[0]
        assert match['packagetype'] == 'bdist_wheel' and match['url'].startswith('https://files.pythonhosted.org/')
        with urllib.request.urlopen(urllib.request.Request(match['url'], method='HEAD'), timeout=20) as response:
            assert response.status == 200 and int(response.headers['Content-Length']) == match['size']
        with zipfile.ZipFile(body) as wheel:
            wheel_entries = [n for n in wheel.namelist() if n.endswith('.dist-info/WHEEL')]
            assert len(wheel_entries) == 1
        for p in (body, header):
            assert prior.stamp(p) == stamps[str(p)]
        selected.append(dict(body=str(body), header=str(header), stats=stamps,
            sha256=sha, header_sha256=digest(header), project=project, version=version,
            identity_source=identity_source,
            filename=match['filename'], url=match['url'], public_head_ok=True,
            wheel_entry=wheel_entries[0], allocated_bytes=sum(s['blocks']*512 for s in stamps.values())))
        print('Verified public wheel:', project, version, match['size'], flush=True)
    result = dict(created_at=time.time(), candidate_source='fresh read-only 10-30 MiB HTTP-cache census',
        candidate_paths=candidate_paths,
        target_reclaim_bytes=2*1024**3, action='remove_retrievable_public_pip_http_downloads',
        reason='Public downloaded archives only; installed environments, local builds, models and results unchanged.',
        selected=selected, retained=retained, reference_audit=refs,
        allocated_bytes=sum(r['allocated_bytes'] for r in selected), before=prior.usage(),
        source='https://pip.pypa.io/en/stable/topics/caching/',
        caveat='Future installs may download archives again; no installed package is removed.')
    assert selected
    save('public_download_cache_audit1.json', result)
    print(json.dumps(dict(selected=len(selected), allocated_bytes=result['allocated_bytes'],
                         audit_sha256=digest(OUT/'public_download_cache_audit1.json'))), flush=True)

def apply(expected):
    guard()
    path = OUT/'public_download_cache_audit1.json'
    assert digest(path) == expected
    data = json.loads(path.read_text())
    assert data['action'] == 'remove_retrievable_public_pip_http_downloads'
    assert time.time() - data['created_at'] < 3600
    refs = reference_audit()
    before = prior.helpers.git_guard()
    assert not (OUT/'public_download_cache_operations1.jsonl').exists()
    for row in data['selected']:
        for key in ('body', 'header'):
            p = Path(row[key])
            assert p.is_relative_to(ROOT) and p.resolve() == p
            assert prior.stamp(p) == row['stats'][str(p)]
    save('public_download_cache_apply_before1.json', dict(audit_sha256=expected, git=before, usage=prior.usage(), references=refs))
    with (OUT/'public_download_cache_operations1.jsonl').open('x') as log:
        for row in data['selected']:
            for key in ('header', 'body'):
                p = Path(row[key])
                prior.no_active(p)
                assert prior.stamp(p) == row['stats'][str(p)]
                event = dict(path=str(p), sha256=row['sha256'] if key == 'body' else row['header_sha256'],
                             public_url=row['url'], time=time.time(), action='unlink_verified_download')
                log.write(json.dumps(event)+'\n'); log.flush(); os.fsync(log.fileno())
                p.unlink()
    after = prior.helpers.git_guard()
    assert before == after
    assert all(not Path(row[key]).exists() for row in data['selected'] for key in ('body','header'))
    result = dict(audit_sha256=expected, selected_archives=len(data['selected']),
        removed_files=2*len(data['selected']), freed_file_allocated_bytes=data['allocated_bytes'],
        tracked_projects_unchanged=True, installed_environments_untouched=True, after=prior.usage())
    save('public_download_cache_complete1.json', result)
    print(json.dumps(result), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('audit','apply'))
    parser.add_argument('--reviewed-audit-sha256')
    args = parser.parse_args()
    if args.action == 'audit': audit()
    else: apply(args.reviewed_audit_sha256)
