"""One CPU-only import-path diagnostic; no engine, data, or performance replay."""
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
NATIVE = '/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python'
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2)

def census():
    return subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
        '--format=csv,noheader'], text=True, timeout=10).strip()

unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])

def resources():
    return {k: (group/k).read_text().strip() for k in ('memory.peak', 'memory.events',
        'memory.swap.current', 'memory.high', 'memory.max', 'memory.swap.max',
        'cgroup.events')}

before = resources()
assert before['memory.high'] == str(3*1024**3)
assert before['memory.max'] == str(4*1024**3) and before['memory.swap.max'] == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert not census()
plan_sha = p.check_plan()
tracked = [ROOT/'sitecustomize.py', ROOT/'scripts/run_all_experiments.py',
    ROOT/'scripts/dedicated_engine_worker.py', ROOT/'configs/generated/lora_manifest_1000.json',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md']
hashes = {str(x):p.digest(x) for x in tracked}

code = '''import time, sys, json, os
entry = time.monotonic()
stages = [{'phase':'entry', 'monotonic_s':entry,
           'loaded': [n for n in ('sitecustomize', 'torch', 'vllm.v1.worker.gpu_worker') if n in sys.modules]}]
sys.path.insert(0, ROOT)
from scripts import run_all_experiments as runner
stages.append({'phase':'runner_import', 'monotonic_s':time.monotonic()})
assert runner._lazy_import_vllm()
stages.append({'phase':'native_frontend_import', 'monotonic_s':time.monotonic()})
import torch
assert not torch.cuda.is_initialized()
print('D338_JSON=' + json.dumps({'stages':stages, 'cuda_initialized':torch.cuda.is_initialized(),
    'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),
    'torch':torch.__version__, 'python':sys.version, 'affinity':sorted(os.sched_getaffinity(0)),
    'loaded_count':len(sys.modules)}), flush=True)
'''.replace('ROOT', repr(str(ROOT)))

rows = []
try:
    for case in ('repository_startup_hook', 'neutral_startup_then_same_frontend'):
        env = dict(os.environ)
        for name in ('PYTHONPATH', 'FAASLORA_VISIBLE_DEVICES', 'PYTHONSTARTUP',
                     'PYTORCH_CUDA_ALLOC_CONF', 'PYTORCH_HIP_ALLOC_CONF'):
            env.pop(name, None)
        env.update(CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1',
            PYTHONUNBUFFERED='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
            VLLM_NO_USAGE_STATS='1', VLLM_WORKER_MULTIPROC_METHOD='spawn',
            FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY='uncached_background_v1',
            PYTORCH_ALLOC_CONF='pinned_max_cached_size_mb:0,pinned_use_background_threads:True')
        cwd = '/tmp'
        if case == 'repository_startup_hook':
            env['PYTHONPATH'] = str(ROOT)
            cwd = str(ROOT)
        output, errors = RAW/(case+'.stdout'), RAW/(case+'.importtime')
        start = time.monotonic()
        with output.open('x') as out, errors.open('x') as err:
            proc = subprocess.run([NATIVE, '-X', 'importtime', '-c', code],
                cwd=cwd, env=env, stdout=out, stderr=err, timeout=120)
        end = time.monotonic()
        assert not census()
        proc.check_returncode()
        records = [json.loads(x[len('D338_JSON='):]) for x in output.read_text().splitlines()
                   if x.startswith('D338_JSON=')]
        assert len(records) == 1 and not records[0]['cuda_initialized']
        record = records[0]
        parsed = []
        for line in errors.read_text().splitlines():
            match = re.match(r'import time:\s+(\d+)\s+\|\s+(\d+)\s+\| (.*)', line)
            if match:
                parsed.append(dict(self_us=int(match[1]), cumulative_us=int(match[2]),
                    module=match[3].strip()))
        phases = record['stages']
        rows.append(dict(case=case, returncode=proc.returncode, wall_s=end-start,
            interpreter_to_entry_s=phases[0]['monotonic_s']-start,
            runner_import_s=phases[1]['monotonic_s']-phases[0]['monotonic_s'],
            frontend_import_s=phases[2]['monotonic_s']-phases[1]['monotonic_s'],
            record=record, top_self_imports=sorted(parsed, key=lambda x:x['self_us'], reverse=True)[:30],
            top_cumulative_imports=sorted(parsed, key=lambda x:x['cumulative_us'], reverse=True)[:20],
            stdout_sha256=p.digest(output), importtime_sha256=p.digest(errors)))
    assert hashes == {str(x):p.digest(x) for x in tracked}
    save(RAW/'summary.json', dict(kind='d338_import_path_diagnostic_v1', rows=rows,
        source_sha256=hashes, plan_sha256=plan_sha,
        caveats=['CPU-only hidden-CUDA import diagnostic, not an activation or request benchmark.',
                 'Fixed sequential order, one observation each, importtime overhead included.',
                 'Warm filesystem/module-cache state differs from concurrent live activation.',
                 'Nested cumulative import times must not be summed.',
                 'Neutral case omits startup patches for diagnosis only; it is not a qualified serving change.']))
finally:
    save(RAW/'execution_receipt.json', dict(identity=identity, before=before, after=resources(),
        rows_completed=len(rows), gpu_census_after=census(), source_sha256=hashes))
print(json.dumps([{k:r[k] for k in ('case','wall_s','interpreter_to_entry_s','runner_import_s',
    'frontend_import_s')} for r in rows]))
