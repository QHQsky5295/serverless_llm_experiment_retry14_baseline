"""D338 evidence-only closure/backup, reusing existing scope/protection checks."""
import ast
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d338_startup_import'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(path, obj):
    with path.open('x') as f:
        json.dump(obj, f, indent=2)

def resources(group):
    return {k:(group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current','cgroup.events')}

receipt = json.loads((RAW/'execution_receipt.json').read_text())
old = receipt['identity']
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
old_resources = resources(Path(old['path']))
assert old_resources['cgroup.events'].splitlines()[0] == 'populated 0'
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',old['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
save(RAW/'import_cleanup.json',dict(identity=old,resources=old_resources,inactive=True))

unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
own = p.scope_identity(unit)
group = Path(own['path'])
assert (group/'memory.max').read_text().strip() == str(4*1024**3)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
summary = json.loads((RAW/'summary.json').read_text())
for name, expected in summary['source_sha256'].items():
    assert p.digest(Path(name)) == expected
assert receipt['rows_completed'] == 2 and receipt['gpu_census_after'] == ''
assert receipt['after']['memory.events'] == receipt['before']['memory.events']
assert receipt['after']['memory.swap.current'] == '0'
for row in summary['rows']:
    assert row['returncode'] == 0 and not row['record']['cuda_initialized']
    assert row['record']['affinity'] == [2,3,26,27]
    assert p.digest(RAW/(row['case']+'.stdout')) == row['stdout_sha256']
    assert p.digest(RAW/(row['case']+'.importtime')) == row['importtime_sha256']
seal = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = '/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert seal['changed'] == [known] and seal['entry_count'] == 147
assert p.digest(Path(known)) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)

OUT.mkdir(exist_ok=False)
for name in ('summary.json','execution_receipt.json','import_cleanup.json','attempt0_startup_error.json'):
    shutil.copyfile(RAW/name,OUT/name)
members = ['import_diagnostic.py','seal_and_backup.py',
    'repository_startup_hook.stdout','repository_startup_hook.importtime',
    'neutral_startup_then_same_frontend.stdout','neutral_startup_then_same_frontend.importtime']
archive = OUT/'execution_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for name in members:
        check((RAW/name).read_bytes())
        tar.add(RAW/name,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers()) == len(members)
    for name in members:
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == p.digest(RAW/name)
save(OUT/'manifest.json',dict(kind='d338_startup_import_evidence_v1',
    source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    sources=summary['source_sha256'],
    plan_sha256=summary['plan_sha256'],protected_seal=seal,
    archived_sources={name:p.digest(RAW/name) for name in members},
    outputs={x.name:p.digest(x) for x in OUT.iterdir() if x.is_file()},
    no_serving_change=True,no_gpu_run=True,no_figures=True))
with (OUT/'evidence.sha256').open('x') as f:
    for path in sorted(OUT.iterdir()):
        if path.name != 'evidence.sha256':
            f.write(p.digest(path)+'  '+path.name+'\n')
subprocess.run(['sha256sum','-c','evidence.sha256'],cwd=OUT,check=True)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip() == 'retry14_continuous_queue_v2'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
names = ['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D338_STARTUP_IMPORT_DIAGNOSTIC.md']
names += [str(x.relative_to(ROOT)) for x in sorted(OUT.iterdir()) if x.is_file()]
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()) == set(names)
for name in names:
    data = subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert data == (ROOT/name).read_bytes()
    check(data)
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
            for member in tar.getmembers():
                assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                body = tar.extractfile(member).read()
                check(body)
                if member.name.endswith('.py'): ast.parse(body)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (RAW/'backup.log').open('x') as log:
    subprocess.run(['git','commit','-m','Retain bounded startup import diagnosis without unsupported latency claim'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote = subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head == remote
save(RAW/'backup_receipt.json',dict(head=head,remote=remote,paths=names,
    identity=own,resources=resources(group),sources_checked=True,secrets_checked=True,
    user_manifest_not_staged=True))
print(json.dumps(dict(head=head,remote=remote,paths=len(names),pass_all=True)))
