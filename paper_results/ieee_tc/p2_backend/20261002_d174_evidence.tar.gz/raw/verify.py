"""Reuse D172 bounded seal/curation/bundle, no repeated qualification tests."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal

RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
BASE = 'bd7cb1c527216b009548bf78779ba4fadf2c6936'
PLAN = '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
V1 = '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert check_plan() == PLAN
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == V1
changed = subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
allowed = {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md',
    'faaslora/memory/gpu_monitor.py','tests/test_ieee_tc_worker_observation.py','tests/test_ieee_tc_gpu_references.py'}
assert set(changed) <= allowed
monitor = ROOT/'faaslora/memory/gpu_monitor.py'
before = ast.parse(subprocess.check_output(['git','show',BASE+':faaslora/memory/gpu_monitor.py'],cwd=ROOT,text=True))
after = ast.parse(monitor.read_text())
old_helper = next(n for n in before.body if isinstance(n,ast.FunctionDef) and n.name == '_ieee_lora_host_inventory')
new_helper = next(n for n in after.body if isinstance(n,ast.FunctionDef) and n.name == old_helper.name)
assert ast.dump(old_helper) != ast.dump(new_helper)
after.body[after.body.index(new_helper)] = old_helper
# Restore exactly the ONE routing producer call, not the entire method.
expected = ast.parse("host = (_ieee_lora_host_inventory(manager, include_tensor_views=False) if operation == 'routing_source_snapshot' else _ieee_lora_host_inventory(manager))").body[0]
original = ast.parse('host = _ieee_lora_host_inventory(manager)').body[0]
class RestoreRoutingCall(ast.NodeTransformer):
    count = 0
    def visit_Assign(self, node):
        if ast.dump(node) == ast.dump(expected):
            self.count += 1
            return original
        return self.generic_visit(node)
restore = RestoreRoutingCall()
after = restore.visit(after)
assert restore.count == 1 and ast.dump(before) == ast.dump(after), 'non-projection serving structure changed'
for rel in ('scripts/run_all_experiments.py','faaslora/experiment/instance_pool.py',
            'faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py'):
    assert (ROOT/rel).read_bytes() == subprocess.check_output(['git','show',BASE+':'+rel],cwd=ROOT)
probe = json.loads((RAW/'probe1.json').read_text())
assert probe['parent_commit'] == BASE and probe['torch_version'] == '2.13.0+cu130'
assert probe['cuda_executed'] is False and probe['end_to_end_performance_measured'] is False
assert len(probe['cases']) == 7 and all(c['complete_default_equal'] and c['projected_graph_equal'] for c in probe['cases'])
assert digest(Path(probe['source'])) == probe['source_sha256']
rows = probe['retained_snapshots']
assert len(rows) == 4 and [r['registered_adapters'] for r in rows] == [8,12,20,24]
assert all(r['exact_source_and_routing_equal'] for r in rows)
for phase, count in (('tests2',26), ('regression1',942)):
    log = (RAW/f'{phase}.log').read_text()
    assert f'Ran {count} tests' in log and log.rstrip().endswith('OK')
failed = (RAW/'tests1.log').read_text()
assert 'Ran 26 tests' in failed and 'FAILED (failures=1)' in failed and "(case='owners')" in failed
failed_sha = next(line.split()[0] for line in (RAW/'tests1_sources.sha256').read_text().splitlines()
                  if line.endswith('tests/test_ieee_tc_worker_observation.py'))
assert digest(RAW/'test_worker_observation_failed1.py') == failed_sha
for phase in ('tests1','tests2','probe1','regression1'):
    tested = next(line.split()[0] for line in (RAW/f'{phase}_sources.sha256').read_text().splitlines()
                  if line.endswith('faaslora/memory/gpu_monitor.py'))
    assert digest(monitor) == tested
cleanup = []
for phase in ('tests1','probe1','tests2','regression1'):
    receipt = (RAW/f'{phase}_scope.txt').read_text()
    actual = re.search(r'^InvocationID=([a-f0-9]{32})$', receipt, re.M)[1]
    state = subprocess.check_output(['systemctl','--user','show',f'primelora-d174-{phase}-20261002.scope',
        '-p','ActiveState','-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines() == ['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert all(int(line.split()[1]) == 0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text()) == 0
    code = 1 if phase == 'tests1' else 0
    assert f'Exit status: {code}' in (RAW/f'{phase}_time.txt').read_text()
    cleanup.append(dict(phase=phase, actual_invocation_id=actual, returncode=code,
        cleanup='automatic_removal_verified', final_memory_events_zero=True, final_swap_zero=True))
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
doc = ROOT/'docs/ieee_tc/D174_ROUTING_STORAGE_GRAPH.md'
for row in rows:
    assert f"| {row['snapshot']} | {row['registered_adapters']} | {row['host_views']} | {row['json_representation_bytes_before']} | {row['json_representation_bytes_after']} | {100*row['reduction_fraction']:.4f}% |" in doc.read_text()
with (RAW/'cleanup_verified.json').open('x') as stream: json.dump(cleanup,stream,indent=2)
table = OUT/'20261002_d174_routing_storage_graph.csv'
with (RAW/'probe1.csv').open() as stream: assert len(list(csv.DictReader(stream))) == 4
with table.open('xb') as stream: stream.write((RAW/'probe1.csv').read_bytes())
curated = OUT/'20261002_d174_routing_storage_graph.json'
refs = [monitor, ROOT/'tests/test_ieee_tc_worker_observation.py', ROOT/'tests/test_ieee_tc_gpu_references.py',
        RAW/'probe1.json', RAW/'probe.py', Path(probe['source'])]
with curated.open('x') as stream:
    json.dump(dict(kind='routing_storage_graph_qualification_v1',base_commit=BASE,
        metric_protocol_sha256=V1, plan_sha256=PLAN, probe=probe, cleanup=cleanup,
        source_sha256={str(p):digest(p) for p in refs}, tests_targeted=26,tests_regression=942,
        test_counts_overlap=True, failed_test_attempts_preserved=1,
        no_new_gpu_run=True,end_to_end_improvement_qualified=False,n_correct=None,
        formal_g1_g2_qualified=False,common_reference_frozen=False,
        table_sha256=digest(table),document_sha256=digest(doc)),stream,indent=2)
for path in RAW.glob('*.py'): ast.parse(path.read_text())
verification = OUT/'20261002_d174_verification.json'
with verification.open('x') as stream:
    json.dump(dict(passed=True,base_commit=BASE,non_projection_serving_ast_unchanged=True,
        tests_passed=dict(targeted=26,regression=942),protected=protected,cleanup=cleanup,
        curated_sha256=digest(curated),table_sha256=digest(table),document_sha256=digest(doc)),stream,indent=2)
members = sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size < 2*1024**2
                 and not p.name.startswith('verify1') and p.suffix != '.lock')
extras = [doc,curated,verification,table,monitor,ROOT/'tests/test_ieee_tc_worker_observation.py',ROOT/'tests/test_ieee_tc_gpu_references.py']
hashes = {}
bundle = OUT/'20261002_d174_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for path in members+extras:
        name = 'raw/'+str(path.relative_to(RAW)) if path in members else str(path.relative_to(ROOT))
        hashes[name] = digest(path)
        tar.add(path,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames()) == set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == sha
with (OUT/'20261002_d174_evidence_members.json').open('x') as stream:
    json.dump(dict(passed=True,member_sha256=hashes,source_raw_retained_and_bound=True),stream,indent=2)
with (OUT/'20261002_d174_evidence.sha256').open('x') as stream: stream.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    members=len(hashes),bundle_bytes=bundle.stat().st_size,cleanup=cleanup),indent=2))
