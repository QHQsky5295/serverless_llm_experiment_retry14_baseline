"""Reuse D144 exact-helper equivalence and D172 retained native snapshots.

CPU-only work/representation qualification; no serving performance claim.
"""
import ast
import copy
import csv
import hashlib
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace
from unittest.mock import patch
import torch
from faaslora.memory import gpu_monitor as monitor
from faaslora.experiment.instance_pool import NativeSourceSnapshot
from tests.test_ieee_tc_worker_observation import NativeHostFootprint

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
PARENT = 'bd7cb1c527216b009548bf78779ba4fadf2c6936'
previous = subprocess.check_output(['git', 'show', PARENT + ':faaslora/memory/gpu_monitor.py'], cwd=ROOT)
tree = ast.parse(previous)
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_ieee_lora_host_inventory')
namespace = dict(vars(monitor))
exec(compile(ast.Module(body=[function], type_ignores=[]), 'backed_bd7cb1c_host_inventory', 'exec'), namespace)
old = namespace['_ieee_lora_host_inventory']
new = monitor._ieee_lora_host_inventory
original = {name: getattr(torch.Tensor, name) for name in ('is_pinned', 'stride', 'element_size', 'storage_offset')}
cases = []
for case in ('shared', 'partial', 'packed', 'empty', 'staged_alias', 'unsupported_tensor', 'pinning_disagreement'):
    native, models = NativeHostFootprint().native_models()
    staged = None
    if case == 'partial':
        models[8].loras['shared'].lora_a = models[8].loras['shared'].lora_a[:1, :4]
        models[8].loras['shared'].lora_b = models[8].loras['shared'].lora_b[:4, :1]
    elif case == 'packed':
        layer = models[8].loras['shared']
        models[8].loras = {'qkv': SimpleNamespace(lora_a=[layer.lora_a, None], lora_b=[layer.lora_b, None])}
    elif case == 'empty': models.clear()
    elif case == 'staged_alias': staged = {8: models.pop(8)}
    elif case == 'unsupported_tensor': models[8].loras['shared'].bias = torch.empty((4,))
    incompatible = models[7].loras['shared'].lora_b if case == 'pinning_disagreement' else None
    outputs, counts = {}, {}
    for name in ('original', 'candidate_full', 'candidate_routing'):
        calls = dict.fromkeys(original, 0)
        def wrapper(key):
            def counted(tensor, *args, **kwargs):
                calls[key] += 1
                if key == 'is_pinned' and incompatible is not None: return tensor is incompatible
                return original[key](tensor, *args, **kwargs)
            return counted
        with patch.object(torch.Tensor, 'is_pinned', wrapper('is_pinned')), \
             patch.object(torch.Tensor, 'stride', wrapper('stride')), \
             patch.object(torch.Tensor, 'element_size', wrapper('element_size')), \
             patch.object(torch.Tensor, 'storage_offset', wrapper('storage_offset')):
            kwargs = dict(staged_models=staged)
            if name == 'candidate_routing': kwargs['include_tensor_views'] = False
            try: value = dict(result=(old if name == 'original' else new)(native, **kwargs))
            except ValueError as error: value = dict(error_type=type(error).__name__, error=str(error))
        outputs[name], counts[name] = value, calls
    assert outputs['original'] == outputs['candidate_full'], case
    expected = copy.deepcopy(outputs['original'])
    if 'result' in expected: del expected['result']['host_tensor_views']
    assert expected == outputs['candidate_routing'], case
    assert len({v['is_pinned'] for v in counts.values()}) == 1
    assert all(counts['candidate_routing'][k] == 0 for k in original if k != 'is_pinned')
    cases.append(dict(case=case, complete_default_equal=True, projected_graph_equal=True,
        work_counts=counts, expected_error=outputs['original'].get('error')))

source = RAW.parent / 'd169_20261002/7b_probe1.json'
assert 0 < source.stat().st_size < 64 * 1024**2
raw = source.read_bytes()
source_sha = hashlib.sha256(raw).hexdigest()
snapshots = [row['sources_before'] for row in json.loads(raw)['warm_batches']]
del raw
assert len(snapshots) == 4
rows = []
for index, source_view in enumerate(snapshots):
    # Emulate the already-qualified D151 routing endpoint of the retained
    # immutable full observations, not actual new worker RPC measurements.
    full = {k: v for k, v in source_view.items() if k not in ('native_staging_footprints', 'native_host_allocator')}
    projected = {**full, 'native_footprints': {k: v for k, v in full['native_footprints'].items()
                                            if k != 'host_tensor_views'}}
    clock = full['clock_id']
    received = full['captured_monotonic_s'] + 1.0
    a = NativeSourceSnapshot.from_native(full, expected_clock_id=clock, received_monotonic_s=received)
    b = NativeSourceSnapshot.from_native(projected, expected_clock_id=clock, received_monotonic_s=received)
    assert a == b
    assert a.routing_wire(device_uuid=full['device_uuid']) == b.routing_wire(device_uuid=full['device_uuid'])
    before = len(json.dumps(full, ensure_ascii=True, allow_nan=False, separators=(',', ':')).encode())
    after = len(json.dumps(projected, ensure_ascii=True, allow_nan=False, separators=(',', ':')).encode())
    rows.append(dict(snapshot=index, registered_adapters=len(a.registered_cpu_adapter_ids),
        host_views=len(full['native_footprints']['host_tensor_views']),
        json_representation_bytes_before=before, json_representation_bytes_after=after,
        reduction_fraction=(before-after)/before, exact_source_and_routing_equal=True))
result = dict(kind='d174_live_storage_graph_projection_component_v1', parent_commit=PARENT,
    original_monitor_sha256=hashlib.sha256(previous).hexdigest(), torch_version=torch.__version__,
    cases=cases, source=str(source), source_sha256=source_sha, retained_snapshots=rows,
    cuda_executed=False, end_to_end_performance_measured=False,
    caveat='Deterministic work counts and JSON representation sizes, not actual native RPC bytes/time or workload repetitions.')
with (RAW/'probe1.json').open('x') as stream: json.dump(result, stream, indent=2, allow_nan=False)
with (RAW/'probe1.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader(); writer.writerows(rows)
print(json.dumps(result, indent=2))
