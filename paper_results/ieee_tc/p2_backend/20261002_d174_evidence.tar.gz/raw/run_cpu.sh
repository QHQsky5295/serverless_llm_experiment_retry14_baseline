#!/usr/bin/env bash
# Reuse D172 bounded CPU runner and D151 affected test selection.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in tests1|tests2|regression1|probe1|verify1) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d174_20261002
unit="primelora-d174-${phase}-20261002.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sha256sum faaslora/memory/gpu_monitor.py scripts/run_all_experiments.py tests/test_ieee_tc_gpu_references.py tests/test_ieee_tc_worker_observation.py > "$raw/${phase}_sources.sha256"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
python=/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python
if test "$phase" = tests1 || test "$phase" = tests2; then
  args=(-m unittest tests.test_ieee_tc_worker_observation.NativeHostRoutingProjection
    tests.test_ieee_tc_gpu_references.NativeDemandTransactions.test_routing_snapshot_observes_fresh_sources_without_allocator_inventory
    tests.test_ieee_tc_gpu_references.NativeDemandTransactions.test_actual_extension_calls_native_loader_without_inplace_or_fake_inference
    tests.test_ieee_tc_service_routing.ProjectedNativeSources -v)
elif test "$phase" = regression1; then
  python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
  args=(-m unittest tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_service_routing
    tests.test_ieee_tc_service_events tests.test_ieee_tc_native_retirement
    tests.test_ieee_tc_gpu_references tests.test_ieee_tc_worker_observation
    tests.test_ieee_tc_transfer_pressure tests.test_ieee_tc_planning_cpu tests.test_basic_smoke -v)
else
  args=("$raw/${phase%?}.py")
fi
set +e
/usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/${phase}_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/${phase}_swap.txt"
exit "$code"
