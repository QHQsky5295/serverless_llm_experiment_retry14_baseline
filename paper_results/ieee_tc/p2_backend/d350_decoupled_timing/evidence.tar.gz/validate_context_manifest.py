"""Preserve and repair a self-referential export manifest without rerunning data."""
import hashlib
import json
from pathlib import Path

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
directory = root/'paper_results/ieee_tc/p2_backend/d350_decoupled_timing/control1'
def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''):
            digest.update(block)
    return digest.hexdigest()
original = directory/'manifest.json'
record = json.loads(original.read_text())
assert record['outputs'].pop('manifest.json') == hashlib.sha256(b'').hexdigest()
for name,digest in record['outputs'].items():
    assert sha(directory/name) == digest
for ref in record['source_refs']:
    assert sha(Path(ref['path'])) == ref['sha256']
record['source_refs'].extend([dict(path=str(original),sha256=sha(original)),
    dict(path=str(Path(__file__).resolve()),sha256=sha(Path(__file__)))])
record['export_correction'] = dict(original_preserved=True,recomputed_measurements=False,
    reason='Original exporter hashed its still-empty open manifest as an output. Exclude self-reference; all four data tables verified unchanged.',
    first_repair_invocation='Python 3.10 lacks hashlib.file_digest; exited before creating an output. Corrected to streamed SHA256, no data changes.')
with (directory/'validated_manifest.json').open('x') as f:
    json.dump(record,f,indent=2)
print(json.dumps(dict(validated_outputs=len(record['outputs']),new_inference_runs=0)))
