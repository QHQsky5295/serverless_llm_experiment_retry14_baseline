"""D350: join retained phase/control and decode evidence, no new inference."""
import bisect
import csv
import json
import math
from pathlib import Path
from statistics import mean
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.analyze_d297_full import percentile

raw = Path(__file__).resolve().parent
prior = json.loads((raw/'analysis1_receipt.json').read_text())
assert prior['pass_all'] and p.scope_still_owned(prior['identity'])
group = Path(prior['identity']['path'])
assert not p.owned_pids(group)
resources = {k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
subprocess.run(['systemctl','--user','stop',prior['identity']['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',prior['identity']['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'analysis1_cleanup.json').open('x') as f:
    json.dump(dict(identity=prior['identity'],resources=resources,inactive=True),f,indent=2)

out = ROOT/'paper_results/ieee_tc/p2_backend/d350_decoupled_timing/control1'
out.mkdir(parents=True,exist_ok=False)
paths = [Path(__file__)]
datasets = {
    'd336':'d337_capacity_lifecycle/analysis1',
    'd346':'d347_capacity_timing/analysis2',
    'd349':'d350_decoupled_timing/analysis1',
}
phases, events, overlap_cells, contexts = [], [], [], []
inputs = {}

def read_csv(directory, filename):
    seal = json.loads((directory/'manifest.json').read_text())
    source = directory/filename
    assert p.digest(source) == seal['outputs'][filename]
    paths.extend([source,directory/'manifest.json'])
    with source.open(newline='') as f:
        return list(csv.DictReader(f))

def truth(value):
    assert value in ('True','False')
    return value == 'True'

for name, relative in datasets.items():
    interval_dir = ROOT/'paper_results/ieee_tc/p2_backend'/relative
    rows = read_csv(interval_dir,name+'_intervals.csv')
    rows.sort(key=lambda r:(float(r['arrival_offset_s']),r['request_id']))
    assert len(rows)==4000 and len({r['request_id'] for r in rows})==4000
    for r in rows:
        for field in ('arrival_offset_s','admission_ms','ttft_ms','tpot_ms',
                      'mean_other_native_requests','prefill_decode_fraction','load_decode_fraction'):
            r[field]=float(r[field])
            assert math.isfinite(r[field]) and r[field]>=0
        r['tokens']=int(r['tokens'])
        for field in ('startup_overlap','load_overlap','prefill_overlap','timing_tpot_miss','ttft_pass'):
            r[field]=truth(r[field])
    inputs[name] = [(r['request_id'],r['adapter_id'],r['canonical_prompt_sha256'],
                     r['prompt_tokens'],r['tokens'],r['arrival_offset_s']) for r in rows]
    controls = read_csv(ROOT/f'paper_results/ieee_tc/p2_backend/{name}_full_w0/validated1',
                        'control_samples.csv')
    for c in controls:
        c['offset_s']=float(c['offset_s'])
        for k in ('queue','active','capacity','pending'):
            c[k]=int(c[k]); assert c[k]>=0
        assert c['active']<=c['capacity']
    timestamps=[c['offset_s'] for c in controls]
    assert timestamps==sorted(set(timestamps))
    bounds=[rows[i*500]['arrival_offset_s'] for i in range(8)] + [rows[-1]['arrival_offset_s']]
    for i in range(8):
        rs=rows[i*500:(i+1)*500]
        cs=[c for c in controls if bounds[i]<=c['offset_s']<bounds[i+1]]
        assert cs
        phases.append(dict(run=name,phase=i+1,n=500,control_samples=len(cs),
            mean_admission_ms=mean(r['admission_ms'] for r in rs),
            p95_admission_ms=percentile([r['admission_ms'] for r in rs],.95),
            max_admission_ms=max(r['admission_ms'] for r in rs),
            sampled_mean_queue=mean(c['queue'] for c in cs),
            sampled_max_queue=max(c['queue'] for c in cs),
            sampled_mean_active=mean(c['active'] for c in cs),
            sampled_mean_capacity=mean(c['capacity'] for c in cs),
            sampled_pending_count=sum(c['pending']>0 for c in cs),
            scale_up=sum(c['action']=='scale_up' for c in cs),
            scale_down=sum(c['action']=='scale_down' for c in cs)))
        for startup in (False,True):
            for loading in (False,True):
                for prefill in (False,True):
                    selected=[r for r in rs if r['tokens']<=32
                        and r['startup_overlap']==startup and r['load_overlap']==loading
                        and r['prefill_overlap']==prefill]
                    overlap_cells.append(dict(run=name,phase=i+1,startup=startup,
                        native_load=loading,prefill=prefill,n=len(selected),
                        timing_tpot_misses=sum(r['timing_tpot_miss'] for r in selected),
                        mean_tpot_ms=mean(r['tpot_ms'] for r in selected) if selected else None,
                        mean_other_native_requests=mean(r['mean_other_native_requests'] for r in selected) if selected else None))
        for r in rs:
            index=bisect.bisect_right(timestamps,r['arrival_offset_s'])-1
            c=controls[index] if index>=0 else None
            contexts.append(dict(run=name,phase=i+1,request_id=r['request_id'],tokens=r['tokens'],
                arrival_offset_s=r['arrival_offset_s'],admission_ms=r['admission_ms'],
                ttft_ms=r['ttft_ms'],tpot_ms=r['tpot_ms'],timing_tpot_miss=r['timing_tpot_miss'],
                last_sample_age_s=r['arrival_offset_s']-c['offset_s'] if c else None,
                last_sample_queue=c['queue'] if c else None,last_sample_active=c['active'] if c else None,
                last_sample_capacity=c['capacity'] if c else None,last_sample_pending=c['pending'] if c else None))
    events.extend(dict(run=name,**c) for c in controls if c['action']!='no_action')
assert inputs['d336']==inputs['d346']==inputs['d349']
for name,rows in (('phases.csv',phases),('scale_events.csv',events),
                  ('short_overlap_cells.csv',overlap_cells),('request_sample_context.csv',contexts)):
    with (out/name).open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader();writer.writerows(rows)
with (out/'manifest.json').open('x') as f:
    json.dump(dict(kind='d350_retained_sample_context_v1',new_inference_runs=0,
        n_correct=None,formal_qualification=False,confidence_interval=None,
        caveats=['Sample means/counts, not time-integrated occupancy or per-request atomic state.',
            'Last preceding sample keeps its age; missing prefix stays null, no future interpolation.',
            'Post-hoc overlapping exposure groups are not causal shares; all phases and empty cells retained.'],
        source_refs=[dict(path=str(x),sha256=p.digest(x)) for x in dict.fromkeys(paths)],
        outputs={x.name:p.digest(x) for x in sorted(out.iterdir())}),f,indent=2)
print(json.dumps(dict(complete=True,output=str(out),rows=len(contexts),new_inference_runs=0)))
