"""Seal D350 existing-data analysis and stage exact tested paths only."""
import ast
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d350_decoupled_timing'
assert p.preflight([ROOT],p.GIB)['preflight_pass']
identity=p.scope_identity('primelora-tc-aux-d3500000000000000000000000000002.scope')
group=Path(identity['path'])
assert p.scope_still_owned(identity) and not p.owned_pids(group)
resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip()=='inactive'
with (raw/'control1_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,inactive=True),f,indent=2)
refs=[]
for dirname,filename in [('analysis1','manifest.json'),('control1','validated_manifest.json')]:
    directory=out/dirname
    manifest=json.loads((directory/filename).read_text())
    for name,digest in manifest['outputs'].items():
        assert p.digest(directory/name)==digest,name
    for ref in manifest['source_refs']:
        assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
        refs.append(ref)
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def safe(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
paths=[raw/x for x in ['analyze.py','control_context.py','validate_context_manifest.py',
    'analysis1.log','analysis1_receipt.json','analysis1_cleanup.json','control1_cleanup.json','checkpoint.py']]
paths += [ROOT/'scripts/ieee_tc/analyze_d297_full.py',ROOT/'tests/test_ieee_tc_decode_overlap.py']
archive=out/'evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        data=path.read_bytes();safe(data)
        if path.suffix=='.py':ast.parse(data)
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest()==p.digest(path)
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert protected['changed']==[known] and protected['entry_count']==147
assert p.digest(Path(known))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
with (out/'evidence.json').open('x') as f:
    json.dump(dict(kind='d350_retained_diagnosis_checkpoint_v1',new_gpu_runs=0,no_figures=True,
        tests=66,n_correct=None,formal_qualification=False,archive_sha256=p.digest(archive),
        source_refs=refs,protected=protected,analysis_scope_closed=True,control_scope_closed=True,
        raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths]),f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
relative=['docs/ieee_tc/D350_DECOUPLED_CONTROL_DIAGNOSIS.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'scripts/ieee_tc/analyze_d297_full.py','tests/test_ieee_tc_decode_overlap.py']
relative += [str(x.relative_to(ROOT)) for x in sorted(out.rglob('*')) if x.is_file()]
subprocess.run(['git','add','--',*relative],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert sorted(staged)==sorted(relative)
assert 'configs/generated/lora_manifest_1000.json' not in staged
for filename in staged:
    data=subprocess.check_output(['git','show',':'+filename],cwd=ROOT)
    safe(data)
    assert hashlib.sha256(data).hexdigest()==p.digest(ROOT/filename)
    if filename.endswith('.py'):ast.parse(data)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['sha256sum','-c','evidence.sha256'],cwd=out,stdout=subprocess.DEVNULL,check=True)
own=p.scope_identity(Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name)
record=dict(pass_all=True,staged_paths=staged,archive_members=len(paths),identity=own,
    disk_free_bytes=p.preflight([ROOT],p.GIB)['disks'][0]['free_bytes'] if False else None)
with (raw/'checkpoint_verification.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(pass_all=True,staged_count=len(staged),archive_members=len(paths))))
