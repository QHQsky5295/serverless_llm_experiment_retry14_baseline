"""D352 bounded CPU contract test; no GPU or remote service is started."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
def resources():
    return {k: (group/k).read_text().strip() for k in (
        'memory.peak', 'memory.events', 'memory.swap.current', 'memory.high',
        'memory.max', 'memory.swap.max')}
before = resources()
assert before['memory.high'] == str(3*p.GIB) and before['memory.max'] == str(4*p.GIB)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2, 3, 26, 27}
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
command = [sys.executable, '-m', 'unittest',
    'tests.test_ieee_tc_hit_host_transaction', 'tests.test_ieee_tc_gpu_references',
    'tests.test_ieee_tc_worker_observation', 'tests.test_ieee_tc_host_observation_freshness',
    'tests.test_ieee_tc_identity_recheck', 'tests.test_ieee_tc_request_lifecycle',
    'tests.test_ieee_tc_transfer_pressure', '-q']
with (raw/'cpu_tests1.log').open('x') as f:
    completed = subprocess.run(command, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
with (raw/'cpu_tests1_receipt.json').open('x') as f:
    json.dump(dict(identity=identity, before=before, after=resources(),
        command=command, returncode=completed.returncode), f, indent=2)
print(json.dumps(dict(returncode=completed.returncode, resources=resources(), identity=identity)))
completed.check_returncode()
