"""Third CPU test artifact; explicit old-env worker import fixture corrected."""
from pathlib import Path
source = Path(__file__).with_name('prepare.py').read_text()
source = source.replace('cpu_tests1', 'cpu_tests3')
exec(compile(source, str(Path(__file__).with_name('prepare.py')), 'exec'))
