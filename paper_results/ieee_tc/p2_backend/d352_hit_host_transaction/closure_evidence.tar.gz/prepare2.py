"""Reuse D352 preparation without overwriting the first failed test evidence."""
from pathlib import Path
source = Path(__file__).with_name('prepare.py').read_text()
source = source.replace('cpu_tests1', 'cpu_tests2')
exec(compile(source, str(Path(__file__).with_name('prepare.py')), 'exec'))
