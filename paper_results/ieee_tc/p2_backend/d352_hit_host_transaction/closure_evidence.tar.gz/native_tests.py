"""Reuse bounded CPU test gate with the installed native backend; no CUDA work."""
from pathlib import Path
source = Path(__file__).with_name('prepare.py').read_text()
source = source.replace('cpu_tests1', 'native_tests1')
start = source.index('command = [')
end = source.index("with (raw/'", start)
source = source[:start] + "command = [sys.executable, '-m', 'unittest', 'tests.test_ieee_tc_hit_host_transaction', 'tests.test_ieee_tc_host_observation_freshness', '-q']\n" + source[end:]
exec(compile(source, str(Path(__file__).with_name('prepare.py')), 'exec'))
