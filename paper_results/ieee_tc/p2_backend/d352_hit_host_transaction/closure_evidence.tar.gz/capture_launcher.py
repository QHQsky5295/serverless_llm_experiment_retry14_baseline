"""Small identity receipt, no runtime data scan or performance analysis."""
import json
from pathlib import Path
import re
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
matches=re.findall(r'Running scope as unit: (primelora-tc-aux-[0-9a-f]{32}\.scope)',
    (raw/'7b_hit_validation_100/launcher.log').read_text())
assert len(matches)==1
identity=p.scope_identity(matches[0])
assert p.scope_still_owned(identity)
with (raw/'launcher_identity.json').open('x') as f:json.dump(identity,f,indent=2)
gate=json.loads((raw/'launch_gate.json').read_text())
old=gate['identity']; group=Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(group)
closed=p.stop_scope_identity(old)
assert closed['released'] and not closed['hard_kill'] and not group.exists()
with (raw/'start_cleanup.json').open('x') as f:json.dump(dict(identity=old,cleanup=closed),f,indent=2)
print(json.dumps(identity))
