"""Bind and back up this one tested candidate; no inference or remote mutation."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend/d352_hit_host_transaction'
out.mkdir(exist_ok=False, parents=True)
identity = p.scope_identity(p.cg_path().name)
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
assert git('rev-parse', 'HEAD') == '6e6f5be0262c7ae2ebe4dbc5fad442dfb08ebbd4'
assert git('branch', '--show-current') == 'retry14_continuous_queue_v2'
assert not git('diff', '--cached', '--name-only')
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
closed = []
for filename in ('cpu_tests1_receipt.json', 'cpu_tests2_receipt.json', 'cpu_tests3_receipt.json', 'native_tests1_receipt.json'):
    receipt = json.loads((raw/filename).read_text())
    if filename in ('cpu_tests3_receipt.json', 'native_tests1_receipt.json'):
        assert receipt['returncode'] == 0
    old = receipt['identity']
    group = Path(old['path'])
    assert p.scope_still_owned(old) and not p.owned_pids(group)
    stopped = p.stop_scope_identity(old)
    assert stopped['released'] and not stopped['hard_kill'] and not group.exists()
    closed.append(dict(identity=old, cleanup=stopped))
with (raw/'test_cleanup.json').open('x') as f: json.dump(closed, f, indent=2)
config = ROOT/'configs/ieee_tc/20261008_d352_7b_hit_validation_100.yaml'
prior = ROOT/'configs/ieee_tc/20261008_d349_7b_full_w0.yaml'
c, old = (yaml.safe_load(x.read_text()) for x in (config, prior))
expected = copy.deepcopy(old)
for section, field in (('experiment','output_dir'), ('storage','nvme_cache_dir'), ('storage','host_cache_dir')):
    assert not Path(c[section][field]).exists()
    expected[section][field] = c[section][field]
assert c == expected and c['workload']['total_requests'] == 4000
assert c['experiment']['output_dir'] == str(raw/'7b_hit_validation_100')
refs = [config, prior, ROOT/'faaslora/memory/gpu_monitor.py', ROOT/'faaslora/memory/residency_manager.py',
    ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    ROOT/'tests/test_ieee_tc_hit_host_transaction.py', ROOT/'tests/test_ieee_tc_transfer_pressure.py']
for section in ('ieee_service_profile', 'ieee_preparation_profile'):
    profile = c['resource_coordination'][section]
    assert p.digest(Path(profile['path'])) == profile['sha256']
    refs.append(Path(profile['path']))
native = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')
refs += [native/name for name in ('lora/worker_manager.py','utils/cache.py','v1/engine/core.py','v1/executor/uniproc_executor.py')]
protected = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count'] == 147 and protected['changed'] == [str(known)]
assert p.digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
gate = p.preflight([ROOT], 32*p.GIB)
assert gate['preflight_pass'], gate['issues']
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def safe(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----', data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}', data)
paths = sorted(x for x in raw.iterdir() if x.is_file())
archive = out/'preparation_evidence.tar.gz'
with archive.open('xb') as f, tarfile.open(fileobj=f, mode='w:gz') as tar:
    for path in paths:
        data = path.read_bytes(); safe(data)
        if path.suffix == '.py': ast.parse(data)
        if path.suffix == '.sh': subprocess.run(['bash','-n',str(path)], check=True)
        tar.add(path, arcname=path.name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest() == p.digest(path)
binding = dict(kind='d352_same_transaction_host_evidence_preparation_v1', passed=True,
    cpu_tests=618, native_environment_tests=25, base_requests=4000, diagnostic_prefix_count=100,
    n_correct=None, formal_qualification=False, config_changed_only_paths=True,
    protected=protected, preflight=gate, identity=identity,
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in refs],
    raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths],
    archive_sha256=p.digest(archive))
with (out/'preparation.json').open('x') as f: json.dump(binding, f, indent=2)
with (out/'preparation.sha256').open('x') as f:
    for path in sorted(out.iterdir()):
        if path.is_file() and path.name != 'preparation.sha256': f.write(p.digest(path)+'  '+path.name+'\n')
relative = [str(x.relative_to(ROOT)) for x in refs[:7] if x != prior]
relative += ['docs/ieee_tc/D352_TRANSACTION_LOCAL_HOST_EVIDENCE.md','docs/ieee_tc/EXECUTION_STATUS.md']
relative += [str(x.relative_to(ROOT)) for x in sorted(out.iterdir())]
subprocess.run(['git','add','--',*relative], cwd=ROOT, check=True)
assert sorted(git('diff','--cached','--name-only').splitlines()) == sorted(relative)
for name in relative:
    data = subprocess.check_output(['git','show',':'+name], cwd=ROOT)
    safe(data)
    assert hashlib.sha256(data).hexdigest() == p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'], cwd=ROOT, check=True)
subprocess.run(['sha256sum','-c','preparation.sha256'], cwd=out, check=True)
subprocess.run(['git','commit','-m','Reduce duplicate HOST inventory in confirmed GPU-hit transactions (D352)'], cwd=ROOT, check=True)
head = git('rev-parse','HEAD')
subprocess.run(['git','push','faaslora_origin','HEAD:retry14_continuous_queue_v2'], cwd=ROOT, check=True)
remote = git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head == remote
with (raw/'backup_receipt.json').open('x') as f:
    json.dump(dict(passed=True,head=head,remote=remote,paths=relative,identity=identity), f, indent=2)
print(json.dumps(dict(passed=True,head=head,remote=remote,paths=len(relative),
    disk_free_bytes=gate['filesystems'][0]['free_bytes'])))
