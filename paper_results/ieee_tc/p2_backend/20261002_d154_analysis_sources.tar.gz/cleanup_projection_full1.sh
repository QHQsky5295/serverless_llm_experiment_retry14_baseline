#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d154_20261002
unit=primelora-d154-full1-project-20261002.scope
{
  date -Is
  rg -qx 'InvocationID=346633f706484b9d937f5a15a8a71a19' "$raw/full_full1_projection_scope.txt"
  rg -q 'Exit status: 0' "$raw/full_full1_projection_time.txt"
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=346633f706484b9d937f5a15a8a71a19\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_projection_cleanup.txt"
