#!/usr/bin/env bash
# Verify auto-removal of exact completed prelaunch/health scope; no signals.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d154_20261002
phase=$1
identity=$2
case "$phase" in prelaunch|health) ;; *) exit 2;; esac
[[ "$identity" =~ ^[a-f0-9]{32}$ ]]
unit="primelora-d154-${phase}-20261002.scope"
{
date -Is
rg -qx "InvocationID=$identity" "$raw/${phase}_scope.txt"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
printf 'actual_invocation=%s\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n' "$identity"
} | tee "$raw/${phase}_cleanup.txt"
