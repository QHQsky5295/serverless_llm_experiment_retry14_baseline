#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d154_20261002
unit=primelora-d154-full1-curate-20261002.scope
{
  date -Is
  rg -qx 'InvocationID=5619225f222c49fdaf4588d1c7f43450' "$raw/full_full1_curation_scope.txt"
  rg -q 'Exit status: 0' "$raw/full_full1_curation_time.txt"
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=5619225f222c49fdaf4588d1c7f43450\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_curation_cleanup.txt"
