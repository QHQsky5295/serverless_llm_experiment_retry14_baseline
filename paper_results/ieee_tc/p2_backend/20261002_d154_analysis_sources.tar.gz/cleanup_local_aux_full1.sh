#!/usr/bin/env bash
set -euo pipefail
unit=primelora-tc-aux-318ecb4a5f8e4fd18f56487c98ee456e.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = a3ac14f901b44b7583cda07827d43f74
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-318ecb4a5f8e4fd18f56487c98ee456e.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
