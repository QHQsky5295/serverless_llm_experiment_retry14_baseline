#!/usr/bin/env bash
# Reuse post-exit absence receipt; no manual stop of removed scopes.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d154_20261002
{
  date -Is
  jq -e '.pass == true and .service_returncode == 0 and .replay_returncode == 0 and .watchdog_returncode == 0 and .native_gpu_context_release_confirmed == true and .service_path_removed == true and .service_identity.invocation_id == "fb3a7d977e9c43b0bae3b8e82cc790bd"' "$raw/7b_full_w0_full1/launch.json"
  for unit in primelora-tc-svc-3bfabb65d8a64a77a5d47380c926f69f.scope primelora-tc-aux-318ecb4a5f8e4fd18f56487c98ee456e.scope; do
    test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
    test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
    test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
    systemctl --user show "$unit" -p Id -p ActiveState -p InvocationID -p TasksCurrent
  done
  for pid in 614753 614760 618019 622796 622884 623230; do
    test ! -e "/proc/$pid"
    printf 'owned_pid=%s absent\n' "$pid"
  done
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  printf 'cleanup=automatic_removal_verified\nfinal_cgroup_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_local_cleanup.txt"
