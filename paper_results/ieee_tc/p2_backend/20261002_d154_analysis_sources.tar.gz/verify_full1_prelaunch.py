"""Reuse D152's full replay/configuration; qualify only D153 source observation."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight, check_plan
from faaslora.runtime_configuration import resolve_facade_lora_capacity

root=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw=root/'results/ieee_tc/p2_backend_qualification/d154_20261002'
previous=root/'results/ieee_tc/p2_backend_qualification/d152_20261002'
expected_commit='39cc3c1147f1699a4e7cddb54996be2564a895c3'
prior_runtime='26fa0a086bf91895e667a1996662971a526c860b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==expected_commit
dirty=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty)<={'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'},dirty
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old_path=previous/'7b_main_config_full1.yaml'
new_path=raw/'7b_main_config_full1.yaml'
old,new=[yaml.safe_load(path.read_text()) for path in (old_path,new_path)]
for config in (old,new):
    assert config['workload']['total_requests']==4000
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
assert old==new,'configuration differs beyond three fresh owned paths'
assert not (raw/'7b_full_w0_full1').exists()
assert not (raw/'7b_nvme_full1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d154-7b-full1/tc_ieee_full').exists()
prior=previous/'prelaunch_verification.json'
assert digest(prior)=='d8c811c440b525eac7d14183ed8527403db349ee05f0c8ea6e4f6d41b1fefcf3'
full_before=json.loads(prior.read_text())
refs=dict(full_before['source_sha256'])
allowed_changes={'faaslora/memory/residency_manager.py','tests/test_ieee_tc_transfer_pressure.py',
                 'scripts/ieee_tc_preflight.py','tests/test_ieee_tc_preflight.py'}
changes=[]
for name,expected in tuple(refs.items()):
    path=Path(name) if name.startswith('/') else root/name
    actual=digest(path)
    if actual!=expected:
        relative=str(path.relative_to(root))
        assert relative in allowed_changes,(name,expected,actual)
        old_source=subprocess.check_output(['git','show',prior_runtime+':'+relative],cwd=root)
        new_source=subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)
        assert hashlib.sha256(old_source).hexdigest()==expected,relative
        assert hashlib.sha256(new_source).hexdigest()==actual,relative
        changes.append(dict(path=relative,before=expected,after=actual))
        refs[name]=actual
for relative in allowed_changes|{'tests/test_ieee_tc_file_observation.py'}:
    path=root/relative
    assert digest(path)==hashlib.sha256(subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)).hexdigest()
    refs[str(path)]=digest(path)
candidate=root/'paper_results/ieee_tc/p2_backend/20261002_d153_file_observation.json'
assert digest(candidate)=='40358c5acae7d448cdeb4e0cefdd57c1e06f080452031b099e9286efe2302cbe'
qualification=json.loads(candidate.read_text())
assert qualification['attempts']['regression1']['tests']==813
assert qualification['attempts']['regression1']['exit_code']==0
assert qualification['attempts']['preflight2']['tests']==68
assert qualification['attempts']['preflight2']['exit_code']==0
assert qualification['execution_physical_checks_preserved']
assert not qualification['budgets_changed'] and not qualification['cross_call_cache_added']
assert not qualification['performance_gain_established']
model=resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras']==24 and model['runtime_concurrency_cap']==2
assert model['max_num_seqs']==2 and model['max_loras']==4
for key in ('ieee_service_profile','ieee_preparation_profile'):
    binding=new['resource_coordination'][key]
    assert digest(Path(binding['path']))==binding['sha256']
trace,subset=full_before['trace'],full_before['subset']
assert trace['count']==trace['source_count']==4000 and trace['profile']=='W0'
assert trace['view_sha256']=='a5331be2e2204483f18206825d9aaa18cbaa259fe0babfc303f989055819430d'
assert digest(Path(trace['source_path']))==trace['source_sha256']=='efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
assert digest(Path(subset['path']))==subset['sha256']=='aa94b21e1295aefde664e5b29c030a9e42e02af946369bfe9ae15336b89b3016'
for path in [raw/name for name in ('7b_main_config_full1.yaml','run_7b_full_w0_full1.sh',
    'activate_services_full1.sh','check_health.sh','run_health.sh','verify_full1_prelaunch.py','prepare_full1.sh')]+[
    candidate,old_path,prior,root/'docs/ieee_tc/PLAN_APPROVED_20261002_PRIME_FIRST.md']:
    refs[str(path)]=digest(path)
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
resources=preflight([root,raw],32*1024**3)
assert resources['preflight_pass'],resources['issues']
receipt=dict(kind='d154_7b_full_prelaunch_v1',time_unix=time.time(),
    run='d154_7b_full_w0_full1',evidence_commit=expected_commit,runtime_source_commit=expected_commit,
    source_change='D153 one fresh double-checked file owner inventory for preparation sources/budget; no stale cache or execution guard removal. Approved plan pointer synchronized only.',
    expected_source_changes=changes,same_configuration_except_owned_paths=True,
    diagnostic_instrumentation=False,formal_performance_result=False,
    source_sha256=refs,protected=protected,resource_preflight=resources,trace=trace,subset=subset,
    replay_scope='ordinary_full_4000',diagnostic_prefix_count=None,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    plan_sha256=check_plan(),
    comparison='Full development against D152: descriptive n=1, not causal CI or per-model G1/G2 acceptance',
    hypothesis='One fresh physical file observation instead of repeated scans reduces synchronous planning interference with request control',
    detailed_cpu_profiler=False,pending_metric_reconciliation='Keep controller completion and outer terminal distinct',
    reused_initialization='D88/D89; same D152 7B parent config, no new profiles/data/cache',
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),
    sha256=digest(raw/'prelaunch_verification.json'),protected=147,source_refs=len(refs),
    population=4000,same_config=True,resource_pass=True,formal=False,changes=changes)))
