"""Bounded reuse of D603 request quarters and existing stage/physical auditors."""
import collections
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
from statistics import fmean
import subprocess
import sys
import ijson
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import partition_retained_request_stages
from scripts.ieee_tc.check_d299_full_context import closed_physical_integral
from scripts.ieee_tc.plot_d290_diagnostic import percentile
from faaslora.datasets.workload_generator import FrozenReplayPlan

def read(path):
    return json.loads(path.read_text())

def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2, allow_nan=False)

def open_source(path):
    return gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')

def original_digest(path):
    h = hashlib.sha256()
    with open_source(path) as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
save(RAW/'analysis_identity.json', identity)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
gate = p.preflight([ROOT], 32*1024*1024)
assert not any('host_memory_below_stop' in x or 'filesystem_below_stop' in x for x in gate['issues'])
save(RAW/'analysis_resource_gate.json', gate)
slo_path = ROOT/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json'
assert p.digest(slo_path) == '2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3'
slo = read(slo_path)
config = yaml.safe_load((ROOT/'configs/ieee_tc/20261017_d607_7b_canonical_files_full_w2.yaml').read_text())

def find_scaling(node):
    if isinstance(node, dict):
        if 'ieee_scaling' in node:
            return node['ieee_scaling']
        for value in node.values():
            found = find_scaling(value)
            if found is not None:
                return found
    return None

limits = find_scaling(config)
assert limits is not None
refs = []
def ref(path, original_sha=None):
    item = dict(path=str(path),sha256=p.digest(path))
    if original_sha is not None:
        assert original_digest(path) == original_sha
        item['uncompressed_sha256'] = original_sha
    refs.append(item)

def summarize(rows):
    if not rows:
        return dict(n=0)
    return dict(n=len(rows),joint=sum(r['joint'] for r in rows),
        ttft_bad=sum(not r['ttft_good'] for r in rows),
        tpot_bad=sum(not r['tpot_good'] for r in rows),
        mean_ttft_ms=fmean(r['ttft_ms'] for r in rows),
        p95_ttft_ms=percentile([r['ttft_ms'] for r in rows],.95),
        mean_tpot_ms=fmean(r['tpot_ms'] for r in rows),
        stage_means_ms={k:fmean(r['stages_ms'][k] for r in rows) for k in rows[0]['stages_ms']},
        dominant_ttft_stage_counts=dict(collections.Counter(r['dominant_ttft_stage'] for r in rows)),
        tiers=dict(collections.Counter(r['tier'] for r in rows)),
        ttft_excess_ms=dict(median=percentile([r['ttft_ms']-r['ttft_limit_ms'] for r in rows],.5),
                           p95=percentile([r['ttft_ms']-r['ttft_limit_ms'] for r in rows],.95)))

def overlap(a,b,c,d):
    return max(0.,min(b,d)-max(a,c))

def holding_windows(physical,t0,bounds):
    intervals = [(a-t0,b-t0) for spans in physical['device_intervals'].values() for a,b in spans]
    windows = []
    for i,(left,right) in enumerate(zip(bounds,bounds[1:])):
        events = collections.defaultdict(int)
        events[left] += 0
        events[right] += 0
        for a,b in intervals:
            a,b=max(a,left),min(b,right)
            if b>a:
                events[a]+=1;events[b]-=1
        count=0;previous=left;hist=collections.defaultdict(float)
        for at,delta in sorted(events.items()):
            hist[count]+=at-previous
            count+=delta;previous=at
            assert 0<=count<=4
        assert count==0
        total=sum(overlap(a,b,left,right) for a,b in intervals)
        assert abs(sum(k*v for k,v in hist.items())-total)<1e-6
        assert abs(sum(hist.values())-(right-left))<1e-6
        windows.append(dict(quarter=i+1,start_s=left,end_s=right,physical_gpu_seconds=total,
            held_gpu_count_seconds=dict(sorted(hist.items())),mean_held_gpu_count=total/(right-left)))
    return windows

runs={}
projections={}
for name,dirname,tag in [('D554','d554_20261015','7b_initial_control_full_w2'),
                         ('D607','d607_20261017','7b_canonical_files_full_w2')]:
    folder=RAW.parent/dirname
    run=folder/tag
    audit_path=folder/'actual_qualification.json'
    audit=read(audit_path)
    assert audit['passed'] and audit['fixed_workload_complete4000']
    assert audit['ranking_eligible'] is False and audit['stats']['n_correct'] is None
    for filename in ('analysis_closure.json','publication_closure.json'):
        closure=read(folder/filename)
        assert closure['passed'] and closure['path_gone'] and closure['actual_recursive_procs_empty']
        assert not Path(closure['identity']['path']).exists()
    cleanup=read(folder/'local_cleanup.json')
    assert cleanup['passed'] and not Path(cleanup['service_identity']['path']).exists()
    assert not Path(cleanup['auxiliary_identity']['path']).exists()
    assert read(folder/'remote_stop.json')['all_owned_units_inactive']
    launch=read(run/'launch.json')
    assert launch['pass'] and launch['native_gpu_context_release_confirmed']
    t0=launch['external_replay']['replay_t0_s']
    clock=launch['external_replay']['clock_id']
    wi=audit['workload_identity']
    plan=FrozenReplayPlan.load(wi['source_path'],count=4000,profile='W2',
        adapter_map=wi['adapter_map'],adapter_map_sha256=wi['adapter_map_sha256'])
    assert plan.identity()==wi==launch['external_replay']['plan']
    index={e.request_id:i for i,e in enumerate(plan.entries)}
    assert len(index)==4000
    stored={r['path']:r['sha256'] for r in audit['refs']}
    candidates=list(run.glob('experiment_results*.json'))+list(run.glob('experiment_results*.json.gz'))
    assert len(candidates)==1
    source=candidates[0]
    original=source.with_suffix('') if source.suffix=='.gz' else source
    ref(source,stored[str(original)])
    ref(audit_path);ref(run/'launch.json')
    projected={}
    with open_source(source) as stream:
        for r in ijson.items(stream,'detailed_results.tc_ieee_full.requests.item',use_float=True):
            rid=r['request_id'];i=index[rid]
            assert rid not in projected and r['success']
            assert abs(r['scheduled_arrival_offset_s']-plan.entries[i].offset_s)<1e-9
            st=partition_retained_request_stages(r,arrival_start_s=t0,clock_id=clock)
            length=r['native_token_timing']['actual_prompt_tokens']
            gs=[g for g in slo['groups'] if (g['lower_exclusive'] is None or length>g['lower_exclusive'])
                and (g['upper_inclusive'] is None or length<=g['upper_inclusive'])]
            assert len(gs)==1
            g=gs[0];tg=r['overall_ttft_ms']<=g['ttft_ms'];pg=r['completion_tokens']==1 or r['tpot_ms']<=g['tpot_ms']
            ttft_stages={k:v for k,v in st['stages_ms'].items() if k not in (
                'native_decode_ms','worker_completion_notification_ms','worker_to_controller_completion_ms')}
            assert abs(sum(ttft_stages.values())-r['overall_ttft_ms'])<=1
            projected[rid]=dict(source_index=i,request_id=rid,adapter_id=r['adapter_id'],
                arrival_s=plan.entries[i].offset_s,tier=r['readiness_tier_before_dispatch'],
                instance_id=r['instance_id'],ttft_ms=r['overall_ttft_ms'],tpot_ms=r['tpot_ms'],
                joint=bool(tg and pg),ttft_good=tg,tpot_good=pg,ttft_limit_ms=g['ttft_ms'],
                tpot_limit_ms=g['tpot_ms'],prompt_tokens=length,target=r['completion_tokens'],
                stages_ms=st['stages_ms'],dominant_ttft_stage=max(ttft_stages,key=ttft_stages.get))
    rows=sorted(projected.values(),key=lambda r:r['source_index'])
    assert len(rows)==4000 and set(projected)==set(index)
    assert sum(r['joint'] for r in rows)==audit['common_threshold_joint_count']
    assert sum(r['ttft_good'] for r in rows)==audit['common_threshold_ttft_count']
    assert sum(r['tpot_good'] for r in rows)==audit['common_threshold_tpot_count']
    quarters=[summarize(rows[i:i+1000]) for i in range(0,4000,1000)]
    for k,v in audit['stage_means_ms'].items():
        assert abs(fmean(q['stage_means_ms'][k] for q in quarters)-v)<1e-6
    physical_path=run/'launch.launch/physical_deployment/summary.json'
    physical=read(physical_path)
    assert closed_physical_integral(physical)==audit['stats']['physical_gpu_seconds']
    assert physical['clock_id']==clock
    bounds=[plan.entries[i].offset_s for i in (0,1000,2000,3000)]+[plan.entries[-1].offset_s]
    windows=holding_windows(physical,t0,bounds)
    assert abs(sum(w['physical_gpu_seconds'] for w in windows)-physical['window_gpu_seconds']['arrival'])<1e-6
    ref(physical_path)
    outcome=run/'launch.launch/physical_deployment/main_outcome.json'
    actual=outcome if outcome.exists() else outcome.with_suffix('.json.gz')
    ref(actual,stored[str(outcome)])
    with open_source(actual) as stream:
        acts=list(ijson.items(stream,'mechanism_events._ieee_activations.item',use_float=True))
    with open_source(actual) as stream:
        control=list(ijson.items(stream,'mechanism_events._ieee_control_events.item',use_float=True))
    assert control and all(a['observed_at']<=b['observed_at'] for a,b in zip(control,control[1:]))
    controls=[]
    for e in control:
        at=e['observed_at']-t0
        # The closed same-config comparison shares these frozen control limits.
        low=dict(queue=e['queue_depth']<limits['queue_lower'],
                 active=e['active_saturation']<limits['active_lower'],
                 ttft=e['p95_ttft_ms'] is not None and e['p95_ttft_ms']<limits['ttft_lower_ms'])
        assert all(low.values())==e['all_low']
        controls.append(dict(offset_s=at,low_conditions=low,**e))
    inwindow=[e for e in controls if bounds[0]<=e['offset_s']<=bounds[-1]]
    control_groups={}
    for key,events in [('all_arrival',inwindow)]+[(f'quarter_{i+1}',[e for e in inwindow
            if a<=e['offset_s']<(b if i<3 else b+1e-9)]) for i,(a,b) in enumerate(zip(bounds,bounds[1:]))]:
        control_groups[key]=dict(samples=len(events),
            actions=dict(collections.Counter(e['action'] for e in events)),
            outcomes=dict(collections.Counter(e['outcome'] for e in events)),
            all_low=sum(e['all_low'] for e in events),
            low_conditions={k:sum(e['low_conditions'][k] for e in events) for k in ('queue','active','ttft')},
            low_failure_patterns=dict(collections.Counter('+'.join(k for k,v in e['low_conditions'].items() if not v)
                or 'none' for e in events)),
            ready_instances=dict(collections.Counter(e['ready_instances'] for e in events)),
            mean_queue=fmean(e['queue_depth'] for e in events) if events else None,
            mean_active_saturation=fmean(e['active_saturation'] for e in events) if events else None,
            max_observed_low_elapsed_s=max((e['observed_at']-e['low_since'] for e in events
                if e['low_since'] is not None),default=None),
            max_sample_gap_s=max((b['observed_at']-a['observed_at'] for a,b in zip(events,events[1:])),default=None))
    activation_by_id={a['activation_id']:a for a in acts}
    assert set(r['instance_id'] for r in rows)<=set(activation_by_id)
    instance_groups=[]
    for iid,a in activation_by_id.items():
        members=[r for r in rows if r['instance_id']==iid]
        instance_groups.append(dict(instance_id=iid,category=a['category'],state=a['state'],
            trigger_offset_s=a['trigger_at']-t0,ready_offset_s=a['engine_ready_at']-t0,
            requests=summarize(members)))
    bad=[r for r in rows if not r['joint']]
    runs[name]=dict(workload_identity=wi,stats=audit['stats'],all=summarize(rows),
        joint_violations=summarize(bad),quarters=quarters,
        bad_by_quarter=[summarize([r for r in rows[i:i+1000] if not r['joint']]) for i in range(0,4000,1000)],
        by_tier={tier:summarize([r for r in rows if r['tier']==tier]) for tier in sorted({r['tier'] for r in rows})},
        bad_by_tier={tier:summarize([r for r in bad if r['tier']==tier]) for tier in sorted({r['tier'] for r in rows})},
        bad_by_dominant_stage={stage:summarize([r for r in bad if r['dominant_ttft_stage']==stage])
            for stage in sorted({r['dominant_ttft_stage'] for r in bad})},
        instance_groups=instance_groups,window_gpu_seconds=physical['window_gpu_seconds'],holding_quarters=windows,
        device_intervals_relative={device:[[a-t0,b-t0] for a,b in spans]
            for device,spans in physical['device_intervals'].items()},
        control_summary=control_groups,
        control_changes=[e for e in controls if e['action']!='no_action'],
        no_action_name_observed=sorted({e['action'] for e in controls}),
        violations=[{k:v for k,v in r.items() if k!='stages_ms'} for r in bad])
    projections[name]=projected
    save(RAW/(name.lower()+'_projection.json'),rows)
    save(RAW/(name.lower()+'_controls.json'),controls)
    print(json.dumps(dict(run=name,joint=runs[name]['all']['joint'],quarter_joint=[q['joint'] for q in quarters],
        holding_quarters=windows,control_summary=control_groups)),flush=True)

assert runs['D554']['workload_identity']==runs['D607']['workload_identity']
matched=collections.defaultdict(list)
for rid,left in projections['D554'].items():
    right=projections['D607'][rid]
    for key in ('request_id','source_index','adapter_id','arrival_s','target','prompt_tokens'):
        assert left[key]==right[key],(rid,key)
    key=('good' if left['joint'] else 'bad')+'_to_'+('good' if right['joint'] else 'bad')
    matched[key].append((left,right))
changes={key:dict(n=len(pairs),old=summarize([a for a,b in pairs]),new=summarize([b for a,b in pairs]),
    mean_ttft_difference_new_minus_old_ms=fmean(b['ttft_ms']-a['ttft_ms'] for a,b in pairs))
    for key,pairs in matched.items()}
assert sum(x['n'] for x in changes.values())==4000
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
for path in [Path(__file__),ROOT/'scripts/analyze_control_path_overhead.py',
    ROOT/'scripts/ieee_tc/check_d299_full_context.py',ROOT/'scripts/ieee_tc/plot_d290_diagnostic.py',slo_path,
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')]:
    ref(path)
save(RAW/'diagnosis.json',dict(kind='d608_w2_residual_and_holding_v1',passed=True,runs=runs,
    matched_transitions=changes,control_limits=limits,source_refs=refs,
    n_correct=None,numerical_correctness_qualified=False,ranking_eligible=False,
    inference_runs_added=0,replicates=1,confidence_interval=None,
    caveats=['Matched requests have fixed input but different realized system trajectories; no independent repeat or causal treatment estimate.',
        'Tier, replica and largest-stage groups are endogenous conditional diagnostics, not common controlled populations.',
        'Stage spans include queue/IPC/scheduling and overlapping background work, not function CPU time or GPU kernel time.',
        'Control histograms count samples, not time; held-GPU durations integrate actual physical union intervals.',
        'No stage is subtracted from TTFT and no unknown numerical correctness is imputed.']))
save(RAW/'analysis_receipt.json',dict(passed=True,identity=identity,protected=protected,
    source_refs=refs,diagnosis_sha256=p.digest(RAW/'diagnosis.json'),
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,matched_transitions={k:v['n'] for k,v in changes.items()})),flush=True)
