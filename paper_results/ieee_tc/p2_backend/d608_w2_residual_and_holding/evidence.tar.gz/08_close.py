"""Reuse the already verified exact-identity recursive-empty scope closure."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')
code=source.read_text()
original="'analysis2','publication'"
assert code.count(original)==1
code=code.replace(original,"'analysis2','transport','publication'")
exec(compile(code,str(source),'exec'),dict(__file__=__file__,__name__='__main__'))
