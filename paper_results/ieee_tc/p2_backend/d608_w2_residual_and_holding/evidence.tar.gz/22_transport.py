"""Reuse retained client/remote spans; do not subtract remote time from TTFT."""
import gzip
import json
import math
import os
from pathlib import Path
from statistics import fmean
import subprocess
import sys
import ijson
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.plot_d290_diagnostic import percentile
def read(path):return json.loads(path.read_text())
def save(path,data):
    with path.open('x') as stream:json.dump(data,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'transport_identity.json',identity)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closure=read(RAW/'analysis2_closure.json')
assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()
gate=p.preflight([ROOT],32*1024*1024)
assert not any('host_memory_below_stop' in x or 'filesystem_below_stop' in x for x in gate['issues'])
save(RAW/'transport_resource_gate.json',gate)
diagnosis=read(RAW/'diagnosis.json');assert diagnosis['passed']
refs={r['path']:r['sha256'] for r in diagnosis['source_refs']}
results={}
for name,dirname,tag in [('D554','d554_20261015','7b_initial_control_full_w2'),
                        ('D607','d607_20261017','7b_canonical_files_full_w2')]:
    folder=RAW.parent/dirname;run=folder/tag
    source=run/'launch.launch/physical_deployment/main_outcome.json'
    source=source if source.exists() else source.with_suffix('.json.gz')
    assert p.digest(source)==refs[str(source)]
    with (gzip.open(source,'rb') if source.suffix=='.gz' else source.open('rb')) as stream:
        transfers=list(ijson.items(stream,'remote_transfers.item',use_float=True))
    remote_path=folder/'remote_transfers.jsonl'
    audit=read(folder/'actual_qualification.json')
    assert p.digest(remote_path)==next(r['sha256'] for r in audit['refs'] if r['path']==str(remote_path))
    server_rows=[json.loads(line) for line in remote_path.read_text().splitlines()]
    server={r['transfer_id']:r for r in server_rows}
    assert len(transfers)==len(server)==len(server_rows)==497
    assert {r['http_transfer_id'] for r in transfers}==set(server)
    rows=[]
    for t in transfers:
        s=server[t['http_transfer_id']]
        assert t['state']=='published' and t['content_verified'] and t['published_archive_verified']
        assert not t['remote_pack_performed'] and not s['pack_performed']
        assert t['artifact_id']==s['artifact_id'] and t['transferred_bytes']==s['bytes_written']==s['archive_bytes']
        fields=('loading_started_monotonic_s','headers_received_monotonic_s','body_received_monotonic_s',
                'extraction_started_monotonic_s','extraction_completed_monotonic_s',
                'published_monotonic_s','client_completed_monotonic_s')
        times=[t[k] for k in fields]
        assert all(math.isfinite(v) for v in times) and times==sorted(times)
        names=('request_to_headers_ms','reserve_receive_and_write_ms','body_to_extract_ms',
               'extract_and_verify_ms','verified_to_published_ms','published_to_completion_ms')
        stages={k:(b-a)*1000 for k,a,b in zip(names,times,times[1:])}
        for k,v in t['client_stage_ms'].items():assert abs(stages[k]-v)<1e-6
        stages['elapsed_ms']=t['elapsed_ms']
        stages['before_loading_unpartitioned_ms']=t['elapsed_ms']-(times[-1]-times[0])*1000
        assert stages['before_loading_unpartitioned_ms']>=-1
        stages.update(server_handler_ms=(s['handler_completed_ns']-s['handler_started_ns'])/1e6,
                      server_read_ms=s['object_read_wall_ns']/1e6,
                      server_write_ms=s['socket_write_wall_ns']/1e6)
        rows.append(dict(artifact_id=t['artifact_id'],http_transfer_id=t['http_transfer_id'],
            transferred_bytes=t['transferred_bytes'],stages_ms=stages))
    results[name]=dict(count=len(rows),wire_bytes=sum(r['transferred_bytes'] for r in rows),
        metrics_ms={k:dict(mean=fmean(r['stages_ms'][k] for r in rows),
            p50=percentile([r['stages_ms'][k] for r in rows],.5),
            p95=percentile([r['stages_ms'][k] for r in rows],.95),maximum=max(r['stages_ms'][k] for r in rows))
            for k in rows[0]['stages_ms']},source_refs=[dict(path=str(x),sha256=p.digest(x)) for x in (source,remote_path)])
    save(RAW/(name.lower()+'_transfer_projection.json'),rows)
    print(json.dumps(dict(run=name,**results[name])),flush=True)
save(RAW/'transport.json',dict(passed=True,kind='d608_retained_transfer_stages_v1',runs=results,
    inference_runs_added=0,ranking_eligible=False,n_correct=None,
    caveats=['Transfer population is not the residual request population: background prefetch and coalesced waiters may differ.',
        'Server and client clocks are never subtracted or added. Remote spans overlap client stages.',
        'Client receive interval includes local reservation/write; it is not pure wire time.',
        'Before-loading remainder includes workspace preparation and timing-call boundaries; not attributed to a function.',
        'Request TTFT is unchanged; these are diagnostic measured spans, not counterfactual saved latency.']))
save(RAW/'transport_receipt.json',dict(passed=True,identity=identity,
    output_sha256=p.digest(RAW/'transport.json'),source_sha256=p.digest(Path(__file__)),
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
