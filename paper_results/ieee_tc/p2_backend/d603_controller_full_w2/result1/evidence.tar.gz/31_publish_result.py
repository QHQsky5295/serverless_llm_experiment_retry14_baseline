"""Reuse D598 explicit-path publication; D603 is a diagnostic, not a candidate."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d598_20261017/publish_result.py')
code = source.read_text()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace("d598_parallel_pressure_full_w2/result1", "d603_controller_full_w2/result1")
replace("fa02740f1a5e16a8823da67ab6abe845e4932296", "cbd2820d33b145bd011894886beff4921a3cccbb")
replace("mechanism=read(RAW/'parallel_pressure_evidence.json')", "mechanism=read(RAW/'quarter_callers.json')")
replace("assert mechanism['passed'] and mechanism['multi_owner_triggered']\nassert sum(mechanism['participant_counts'].values())==mechanism['records']",
        "assert mechanism['passed'] and not mechanism['formal_performance_result']\nassert [q['count'] for q in mechanism['request_quarters']]==[1000]*4\nassert sum(q['joint'] for q in mechanism['request_quarters'])==audit['common_threshold_joint_count']")
replace("('qualification2','backup','start','analysis')", "('qualification2','backup','start','analysis','analysis2')")
start = code.index("old_path=RAW.parent/'d554_20261015/actual_qualification.json'")
end = code.index("protected=p.verify_seal", start)
code = code[:start] + """comparison=dict(kind='full_w2_python_frame_diagnostic',
    no_new_serving_candidate=True,ordinary_performance_comparison=False,
    no_repeated_run_inference=True,observer_perturbation_not_subtracted=True,
    independent_numerical_correctness='unknown',
    next_step='Audit current file-owner lifecycle and historical rejected candidates before any production optimization.')
for name in ('analysis','analysis2'):
    assert read(RAW/(name+'_receipt.json'))['passed']
for ref in read(RAW/'analysis2_receipt.json')['sources']:
    assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
assert p.digest(RAW/'quarter_callers.json')==read(RAW/'analysis2_receipt.json')['output_sha256']
""" + code[end:]
replace("run=RAW/'7b_parallel_pressure_full_w2'", "run=RAW/'7b_controller_full_w2'")
replace("files += [reference_path,old_path,run/'launch.json',run/'launch.launch/physical_deployment/summary.json',\n    ROOT/'docs/ieee_tc/D598_PARALLEL_PRESSURE_FULL_W2.md']",
        "files += [run/'launch.json',run/'launch.launch/physical_deployment/summary.json',\n    ROOT/'docs/ieee_tc/D603_FULL_W2_DIAGNOSTIC_RESULT.md',\n    Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d598_20261017/publish_result.py'),\n    Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d456_20261012/curate_callers.py'),\n    Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')]")
replace("full_performance_complete=True", "full_performance_complete=False,full_diagnostic_complete=True")
replace("comparison=comparison", "diagnostic_context=comparison")
replace("docs/ieee_tc/D598_PARALLEL_PRESSURE_FULL_W2.md", "docs/ieee_tc/D603_FULL_W2_DIAGNOSTIC_RESULT.md")
replace("tc: preserve full W2 outcome and nonfeasibility of parallel-pressure candidate (D598)",
        "tc: preserve complete W2 control-path diagnosis and quarter evidence (D603)")
exec(compile(code, str(source), 'exec'))
