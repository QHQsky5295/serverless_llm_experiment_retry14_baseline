"""Extend D456 caller accounting with preregistered full-W2 source quarters.

Reuse collect_cpu.rows and the common request-stage partitioner. No inference,
counterfactual latency, CPU-per-function attribution, or changed serving policy.
"""
import bisect
import collections
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys
from statistics import fmean
import ijson

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import partition_retained_request_stages
from scripts.ieee_tc.plot_d290_diagnostic import percentile
from faaslora.datasets.workload_generator import FrozenReplayPlan

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
save(RAW / 'analysis2_identity.json', identity)
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
assert (group / 'memory.high').read_text().strip() == str(3 * p.GIB)
assert (group / 'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
closure = read(RAW / 'analysis_closure.json')
assert closure['passed'] and closure['path_gone'] and closure['actual_recursive_procs_empty']
assert not Path(closure['identity']['path']).exists()
local = read(RAW / 'local_cleanup.json')
assert local['passed'] and local['service_path_gone'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists()
assert not Path(local['auxiliary_identity']['path']).exists()
assert read(RAW / 'remote_stop.json')['all_owned_units_inactive']
gate = p.preflight([ROOT], 32 * 1024 * 1024)
assert not any('host_memory_below_stop' in issue or 'filesystem_below_stop' in issue
               for issue in gate['issues'])
save(RAW / 'analysis2_resource_gate.json', gate)

audit = read(RAW / 'actual_qualification.json')
assert audit['passed'] and audit['fixed_workload_complete4000']
cpu = read(RAW / 'full_w2_cpu_samples.json')
assert cpu['terminal_count'] == cpu['terminal_successes'] == 4000
run = RAW / '7b_controller_full_w2'
evidence = run / 'launch.launch'
receipt = read(evidence / 'exec_receipt.json')
t0 = receipt['external_replay']['replay_t0_s']
clock = receipt['external_replay']['clock_id']
wi = audit['workload_identity']
plan = FrozenReplayPlan.load(wi['source_path'], count=4000, profile='W2',
    adapter_map=wi['adapter_map'], adapter_map_sha256=wi['adapter_map_sha256'])
assert plan.identity() == wi == receipt['external_replay']['plan']
index = {entry.request_id: i for i, entry in enumerate(plan.entries)}
assert len(index) == 4000
spec = importlib.util.spec_from_file_location('d603_reader', RAW / 'collect_cpu.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
terminals = []
for row, partial in reader.rows(evidence / 'physical_deployment/request_terminals.jsonl'):
    assert not partial and row['clock_id'] == clock
    terminals.append(row)
assert {r['request_id'] for r in terminals} == set(index) and len(terminals) == 4000
end = max(row['at'] for row in terminals)
boundaries = [t0 + plan.entries[i].offset_s for i in (0, 1000, 2000, 3000)] + [end]
assert boundaries == sorted(set(boundaries))
assert boundaries[0] >= t0
source = next(run.glob('experiment_results*.json'))
refs = {r['path']: r['sha256'] for r in audit['refs']}
assert p.digest(source) == refs[str(source)]
quarters = [[] for _ in range(4)]
seen = set()
with source.open('rb') as stream:
    for request in ijson.items(stream, 'detailed_results.tc_ieee_full.requests.item', use_float=True):
        rid = request['request_id']
        assert rid in index and rid not in seen
        seen.add(rid)
        assert math.isclose(request['scheduled_arrival_offset_s'], plan.entries[index[rid]].offset_s,
                            rel_tol=0, abs_tol=1e-9)
        stage = partition_retained_request_stages(request, arrival_start_s=t0, clock_id=clock)
        assert stage['max_identity_error_ms'] <= 1.0
        quarters[index[rid] // 1000].append(dict(stages_ms=stage['stages_ms'],
            ttft_ms=request['overall_ttft_ms'], tier=request['readiness_tier_before_dispatch']))
assert seen == set(index) and all(len(rows) == 1000 for rows in quarters)
request_quarters = [dict(quarter=q+1, count=len(rows),
    joint=sum(audit['source_order_phases'][i]['joint'] for i in range(q*10, (q+1)*10)),
    mean_ttft_ms=fmean(r['ttft_ms'] for r in rows),
    p95_ttft_ms=percentile([r['ttft_ms'] for r in rows], .95),
    stages_ms={k:fmean(r['stages_ms'][k] for r in rows) for k in rows[0]['stages_ms']},
    tiers=dict(collections.Counter(r['tier'] for r in rows))) for q, rows in enumerate(quarters)]
assert sum(r['joint'] for r in request_quarters) == audit['common_threshold_joint_count']
for key, value in audit['stage_means_ms'].items():
    assert abs(fmean(r['stages_ms'][key] for r in request_quarters) - value) < 1e-6

def counter_rows(counter, fields):
    return [dict(zip(fields, key), occurrences=value) for key, value in counter.most_common()]

processes = []
for process in cpu['processes']:
    for ref in process['source_refs']:
        assert p.digest(Path(ref['path'])) == ref['sha256']
    labels = process['role_evidence']
    role = 'frontend' if 'frontend' in labels else labels[0] if len(labels) == 1 else 'unclassified'
    meta_path = Path(process['source_refs'][0]['path'])
    meta = read(meta_path)
    assert meta['replay_scope'] == 'full_source_v1' and meta['replay_count'] == 4000
    stats = [dict(samples=0, missing_main=0, truncated_main=0, cpu_interval_s=0.0,
                  cpu_interval_wall_s=0.0, cpu_intervals=0, lags=[],
                  leaf=collections.Counter(), nearest=collections.Counter(),
                  inclusive=collections.Counter(), callers=collections.Counter(), examples={})
             for _ in range(4)]
    previous = meta['capture_start_monotonic_s']
    crossed = []
    window_count = 0
    for row, partial in reader.rows(meta_path.with_suffix('.stacks.jsonl')):
        if partial:
            assert partial == process['final_partial_line_bytes']
            break
        at = row['observed_monotonic_s']
        q = min(3, bisect.bisect_right(boundaries, at) - 1)
        if boundaries[0] <= at <= end:
            assert 0 <= q < 4
            s = stats[q]
            s['lags'].append(row['scheduler_delay_seconds'])
            if previous >= boundaries[q]:
                s['cpu_interval_s'] += row['process_cpu_delta_seconds']
                s['cpu_interval_wall_s'] += at - previous
                s['cpu_intervals'] += 1
            else:
                crossed.append(dict(quarter=q+1, from_s=previous, to_s=at,
                                    process_cpu_delta_s=row['process_cpu_delta_seconds']))
            main = [thread for thread in row['threads'] if thread['ident'] == meta['main_thread_ident']]
            if not main:
                s['missing_main'] += 1
            else:
                main, = main
                frames = main['frames']
                s['samples'] += 1
                window_count += 1
                s['truncated_main'] += int(main['truncated'])
                local_frames = [(i, f.removeprefix(str(ROOT)+'/'), n, line)
                    for i, (f,n,line) in enumerate(frames) if f.startswith(str(ROOT)+'/')]
                s['leaf'][tuple(frames[0][:2]) if frames else ('','empty_stack')] += 1
                s['nearest'][(local_frames[0][1], local_frames[0][2]) if local_frames
                             else ('','no_project_frame')] += 1
                s['inclusive'].update(set((f,n) for _,f,n,_ in local_frames))
                for i,f,n,line in local_frames:
                    caller = frames[i+1] if i+1 < len(frames) else ['','truncated',0]
                    s['callers'][(f,n,line,*caller)] += 1
                    if (f,n) not in s['examples']:
                        s['examples'][(f,n)] = dict(sample_index=row['index'], at_s=at,
                            frames=frames[:min(len(frames),i+5)])
        previous = at
    # First source arrival is zero; otherwise a separate gap must be reported.
    assert boundaries[0] == t0
    assert window_count == process['main_phase_counts'].get('request_window',0)
    for q,s in enumerate(stats):
        assert sum(s['nearest'].values()) == sum(s['leaf'].values()) == s['samples']
        assert all(v <= s['samples'] for v in s['inclusive'].values())
        s['quarter'] = q+1
        s['lag_p95_s'] = percentile(s['lags'],.95) if s['lags'] else None
        s['lag_max_s'] = max(s.pop('lags'),default=None)
        for key in ('leaf','nearest','inclusive'):
            s[key] = counter_rows(s[key],('file','function'))
        s['callers'] = counter_rows(s['callers'],('file','function','line','caller_file','caller_function','caller_line'))
        s['examples'] = [dict(file=k[0],function=k[1],**v) for k,v in s['examples'].items()]
    processes.append(dict(pid=process['pid'],role=role,window_samples=window_count,
        quarters=stats,boundary_crossing_cpu_intervals=crossed))
    for ref in process['source_refs']:
        assert p.digest(Path(ref['path'])) == ref['sha256']

assert p.digest(source) == refs[str(source)]
protected = p.verify_seal(RAW.parent.parent / 'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
save(RAW / 'quarter_callers.json', dict(kind='d603_full_w2_quarter_callers_v1',passed=True,
    source_quarter_size=1000,request_quarters=request_quarters,
    sample_time_boundaries_s=boundaries,processes=processes,formal_performance_result=False,
    caveats=cpu['caveats'] + [
        'Request groups follow original source order; sampling windows use their planned arrival boundaries.',
        'Requests may overlap adjacent sampling windows; no per-request causal assignment is inferred.',
        'CPU intervals crossing a window boundary are retained separately and not split or imputed.',
        'Process CPU is measured across native threads; frame occurrences are not CPU shares.']))
sources = [Path(__file__), RAW/'collect_cpu.py', RAW/'actual_qualification.json',
    RAW/'full_w2_cpu_samples.json', source, evidence/'exec_receipt.json',
    Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d456_20261012/curate_callers.py'),
    ROOT/'scripts/analyze_control_path_overhead.py']
save(RAW / 'analysis2_receipt.json',dict(passed=True,identity=identity,protected=protected,
    sources=[dict(path=str(path),sha256=p.digest(path)) for path in sources],
    output_sha256=p.digest(RAW/'quarter_callers.json'),
    resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,request_quarters=request_quarters,
    processes=[dict(pid=r['pid'],role=r['role'],window_samples=r['window_samples']) for r in processes])))
