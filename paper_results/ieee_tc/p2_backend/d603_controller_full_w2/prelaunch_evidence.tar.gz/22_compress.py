"""Reuse D596 guards and compressor for the closed D598 remote monitor only."""
import json
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d596_20261017/compress.py')
code = source.read_text()
old = "targets = ['d533_20261015/7b_full_w1', 'd512_20261014/7b_full_w0_prefix1',\n           'd519_20261014/7b_full_w0_prefix1']"
assert code.count(old) == 1
code = code.replace(old, "targets = ['d598_20261017/7b_parallel_pressure_full_w2']")
old = 'source, receipt = c.evidence_paths(run)'
assert code.count(old) == 1
code = code.replace(old, """source, receipt = c.evidence_paths(run, 'remote_monitor.log')
    stop = json.loads((run.parent/'remote_stop.json').read_text())
    assert stop['all_owned_units_inactive'] and stop['download_hashes_match_remote']
    assert p.digest(source) == stop['hashes']['remote_monitor.log']
    closed = json.loads((run.parent/'publication_closure.json').read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()""")
code = code.replace("source.with_suffix('.json.gz')", "source.with_suffix('.log.gz')")
old = "dict(run=row['run'],audit_sha=row['source_sha256'])"
assert code.count(old) == 1
code = code.replace(old, "dict(run=row['run'],audit_sha=row['source_sha256'],remote_monitor_log='remote_monitor.log')")
exec(compile(code, str(source), 'exec'))
