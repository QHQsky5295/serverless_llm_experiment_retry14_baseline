#!/usr/bin/env bash
set -euo pipefail
ROOT=/home/qhq/serverless_llm_experiment_retry14_baseline
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d293_20261006/7b_prefetch_validation_100
CONFIG=configs/ieee_tc/20261006_d293_7b_prefetch_validation_100.yaml
TAG=d293_7b_prefetch_validation_100
SCENARIO=tc_ieee_prefetch_validation_100
PREFIX_COUNT=100
case "${1:-d293}" in
  d293) ;;
  d296)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d296_20261007/7b_lifecycle_validation_100
    CONFIG=configs/ieee_tc/20261007_d296_7b_lifecycle_validation_100.yaml
    TAG=d296_7b_lifecycle_validation_100
    ;;
  d297)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d297_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d297_7b_full_w0.yaml
    TAG=d297_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d298)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d298_20261007/7b_capacity_validation_100
    CONFIG=configs/ieee_tc/20261007_d298_7b_capacity_validation_100.yaml
    TAG=d298_7b_capacity_validation_100
    ;;
  d299)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d299_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d299_7b_full_w0.yaml
    TAG=d299_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d300)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d300_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d300_7b_full_w0.yaml
    TAG=d300_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d302)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d302_20261007/7b_frontier_validation_100
    CONFIG=configs/ieee_tc/20261007_d302_7b_frontier_validation_100.yaml
    TAG=d302_7b_frontier_validation_100
    SCENARIO=tc_ieee_frontier_validation_100
    ;;
  d303)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d303_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d303_7b_full_w0.yaml
    TAG=d303_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d308)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d308_20261007/7b_prefill_validation_100
    CONFIG=configs/ieee_tc/20261007_d308_7b_prefill_validation_100.yaml
    TAG=d308_7b_prefill_validation_100
    SCENARIO=tc_ieee_prefill_validation_100
    ;;
  d309)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d309_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d309_7b_full_w0.yaml
    TAG=d309_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d310)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d310_20261007/7b_prefill_validation_100
    CONFIG=configs/ieee_tc/20261007_d310_7b_prefill_validation_100.yaml
    TAG=d310_7b_prefill_validation_100
    SCENARIO=tc_ieee_prefill_validation_100
    ;;
  d311)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d311_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d311_7b_full_w0.yaml
    TAG=d311_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d312)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d312_20261007/7b_prefill_validation_100
    CONFIG=configs/ieee_tc/20261007_d312_7b_prefill_validation_100.yaml
    TAG=d312_7b_prefill_validation_100
    SCENARIO=tc_ieee_prefill_validation_100
    ;;
  d313)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d313_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d313_7b_full_w0.yaml
    TAG=d313_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d314)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d314_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d314_7b_full_w0.yaml
    TAG=d314_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d315)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d315_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d315_7b_full_w0.yaml
    TAG=d315_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d317)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d317_20261007/7b_copy_validation_100
    CONFIG=configs/ieee_tc/20261007_d317_7b_copy_validation_100.yaml
    TAG=d317_7b_copy_validation_100
    SCENARIO=tc_ieee_copy_validation_100
    ;;
  d318)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d318_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d318_7b_full_w0.yaml
    TAG=d318_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d322)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d322_20261007/7b_length_validation_100
    CONFIG=configs/ieee_tc/20261007_d322_7b_length_validation_100.yaml
    TAG=d322_7b_length_validation_100
    SCENARIO=tc_ieee_length_validation_100
    ;;
  d322-attempt2)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d322_20261007/7b_length_validation_100_attempt2
    CONFIG=configs/ieee_tc/20261007_d322_7b_length_validation_100_attempt2.yaml
    TAG=d322_7b_length_validation_100_attempt2
    SCENARIO=tc_ieee_length_validation_100
    ;;
  d323)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d323_20261007/7b_full_w0
    CONFIG=configs/ieee_tc/20261007_d323_7b_full_w0.yaml
    TAG=d323_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d326)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d326_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d326_7b_full_w0.yaml
    TAG=d326_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d328)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d328_20261008/7b_full_w0_prefix1
    CONFIG=configs/ieee_tc/20261008_d328_7b_full_w0_prefix1.yaml
    TAG=d328_7b_full_w0_prefix1
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=1000
    ;;
  d331)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d331_20261008/7b_planning_validation_100
    CONFIG=configs/ieee_tc/20261008_d331_7b_planning_validation_100.yaml
    TAG=d331_7b_planning_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d331-attempt2)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d331_20261008/7b_planning_validation_100_attempt2
    CONFIG=configs/ieee_tc/20261008_d331_7b_planning_validation_100_attempt2.yaml
    TAG=d331_7b_planning_validation_100_attempt2
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d332)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d332_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d332_7b_full_w0.yaml
    TAG=d332_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d334)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d334_20261008/7b_native_pending_validation_100
    CONFIG=configs/ieee_tc/20261008_d334_7b_native_pending_validation_100.yaml
    TAG=d334_7b_native_pending_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d335)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d335_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d335_7b_full_w0.yaml
    TAG=d335_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d336)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d336_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d336_7b_full_w0.yaml
    TAG=d336_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d340)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d340_20261008/7b_prebuild_validation_100
    CONFIG=configs/ieee_tc/20261008_d340_7b_prebuild_validation_100.yaml
    TAG=d340_7b_prebuild_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    export FAASLORA_IEEE_QUANTIZATION_PREBUILD_POLICY=on_demand_v1
    export HUMMING_DISABLE_PARALLEL_BUILD=1
    export VLLM_WORKER_MULTIPROC_METHOD=spawn
    ;;
  d341)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d341_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d341_7b_full_w0.yaml
    TAG=d341_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    export FAASLORA_IEEE_QUANTIZATION_PREBUILD_POLICY=on_demand_v1
    export HUMMING_DISABLE_PARALLEL_BUILD=1
    export VLLM_WORKER_MULTIPROC_METHOD=spawn
    ;;
  d345)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d345_20261008/7b_capacity_validation_100
    CONFIG=configs/ieee_tc/20261008_d345_7b_capacity_validation_100.yaml
    TAG=d345_7b_capacity_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d346)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d346_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d346_7b_full_w0.yaml
    TAG=d346_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d349)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d349_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d349_7b_full_w0.yaml
    TAG=d349_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d351)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d351_20261008/7b_full_w0_prefix1
    CONFIG=configs/ieee_tc/20261008_d351_7b_full_w0_prefix1.yaml
    TAG=d351_7b_full_w0_prefix1
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=1000
    ;;
  d352)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d352_20261008/7b_hit_validation_100
    CONFIG=configs/ieee_tc/20261008_d352_7b_hit_validation_100.yaml
    TAG=d352_7b_hit_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d353)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d353_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d353_7b_full_w0.yaml
    TAG=d353_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d355)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d355_20261008/7b_interleave_validation_100
    CONFIG=configs/ieee_tc/20261008_d355_7b_interleave_validation_100.yaml
    TAG=d355_7b_interleave_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d357)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d357_20261008/7b_interleave_validation_100
    CONFIG=configs/ieee_tc/20261008_d357_7b_interleave_validation_100.yaml
    TAG=d357_7b_interleave_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d358)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d358_20261008/7b_full_w0
    CONFIG=configs/ieee_tc/20261008_d358_7b_full_w0.yaml
    TAG=d358_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d363)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d363_20261009/7b_file_demand_validation_100
    CONFIG=configs/ieee_tc/20261009_d363_7b_file_demand_validation_100.yaml
    TAG=d363_7b_file_demand_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d364)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d364_20261009/7b_full_w0
    CONFIG=configs/ieee_tc/20261009_d364_7b_full_w0.yaml
    TAG=d364_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d366)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d366_20261009/7b_file_identity_validation_100
    CONFIG=configs/ieee_tc/20261009_d366_7b_file_identity_validation_100.yaml
    TAG=d366_7b_file_identity_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d367)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d367_20261009/7b_full_w0
    CONFIG=configs/ieee_tc/20261009_d367_7b_full_w0.yaml
    TAG=d367_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d368)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d368_20261009/7b_full_w0
    CONFIG=configs/ieee_tc/20261009_d368_7b_full_w0.yaml
    TAG=d368_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d369)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d369_20261010/7b_stale_identity_validation_100
    CONFIG=configs/ieee_tc/20261010_d369_7b_stale_identity_validation_100.yaml
    TAG=d369_7b_stale_identity_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d370)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d370_20261010/7b_full_w0
    CONFIG=configs/ieee_tc/20261010_d370_7b_full_w0.yaml
    TAG=d370_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d371)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d371_20261010/7b_full_w0
    CONFIG=configs/ieee_tc/20261010_d371_7b_full_w0.yaml
    TAG=d371_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d374)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d374_20261010/7b_capacity_revalidation_100
    CONFIG=configs/ieee_tc/20261010_d374_7b_capacity_revalidation_100.yaml
    TAG=d374_7b_capacity_revalidation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d375)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d375_20261010/7b_capacity_revalidation_100
    CONFIG=configs/ieee_tc/20261010_d375_7b_capacity_revalidation_100.yaml
    TAG=d375_7b_capacity_revalidation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d376)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d376_20261010/7b_capacity_revalidation_100
    CONFIG=configs/ieee_tc/20261010_d376_7b_capacity_revalidation_100.yaml
    TAG=d376_7b_capacity_revalidation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d377)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d377_20261010/7b_capacity_revalidation_100
    CONFIG=configs/ieee_tc/20261010_d377_7b_capacity_revalidation_100.yaml
    TAG=d377_7b_capacity_revalidation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d378)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d378_20261010/7b_capacity_revalidation_100
    CONFIG=configs/ieee_tc/20261010_d378_7b_capacity_revalidation_100.yaml
    TAG=d378_7b_capacity_revalidation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d379)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d379_20261010/7b_capacity_revalidation_full_w0
    CONFIG=configs/ieee_tc/20261010_d379_7b_capacity_revalidation_full_w0.yaml
    TAG=d379_7b_capacity_revalidation_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d386)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d386_20261010/7b_capacity_queue4_full_w0
    CONFIG=configs/ieee_tc/20261010_d386_7b_capacity_queue4_full_w0.yaml
    TAG=d386_7b_capacity_queue4_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d450)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/elastic_locality_qualification/d450_20261012/7b_elastic_locality_100
    CONFIG=configs/ieee_tc/20261012_d450_7b_elastic_locality_100.yaml
    TAG=d450_7b_elastic_locality_100
    SCENARIO=tc_ieee_elastic_locality
    PREFIX_COUNT=100
    ;;
  d451)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/elastic_locality_qualification/d451_20261012/7b_elastic_locality_500
    CONFIG=configs/ieee_tc/20261012_d451_7b_elastic_locality_500.yaml
    TAG=d451_7b_elastic_locality_500
    SCENARIO=tc_ieee_elastic_locality
    PREFIX_COUNT=500
    ;;
  d452)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/elastic_locality_qualification/d452_20261012/7b_elastic_locality_1000
    CONFIG=configs/ieee_tc/20261012_d452_7b_elastic_locality_1000.yaml
    TAG=d452_7b_elastic_locality_1000
    SCENARIO=tc_ieee_elastic_locality
    PREFIX_COUNT=1000
    ;;
  d453)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/elastic_locality_qualification/d453_20261012/7b_elastic_locality_w0
    CONFIG=configs/ieee_tc/20261012_d453_7b_elastic_locality_w0.yaml
    TAG=d453_7b_elastic_locality_w0
    SCENARIO=tc_ieee_elastic_locality
    PREFIX_COUNT=
    ;;
  d456)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d456_20261012/7b_full_w0_prefix1
    CONFIG=configs/ieee_tc/20261012_d456_7b_full_w0_prefix1.yaml
    TAG=d456_7b_full_w0_prefix1
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=1000
    ;;
  d457)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d457_20261012/7b_full_w0_prefix1
    CONFIG=configs/ieee_tc/20261012_d457_7b_full_w0_prefix1.yaml
    TAG=d457_7b_full_w0_prefix1
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=1000
    ;;
  d458)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d458_20261012/7b_full_w0
    CONFIG=configs/ieee_tc/20261012_d458_7b_full_w0.yaml
    TAG=d458_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d464)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d464_20261012/7b_host_queue_validation_100
    CONFIG=configs/ieee_tc/20261012_d464_7b_host_queue_validation_100.yaml
    TAG=d464_7b_host_queue_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d465)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d465_20261012/7b_full_w0
    CONFIG=configs/ieee_tc/20261012_d465_7b_full_w0.yaml
    TAG=d465_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d470)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d470_20261012/7b_cpu_frontend_validation_100
    CONFIG=configs/ieee_tc/20261012_d470_7b_cpu_frontend_validation_100.yaml
    TAG=d470_7b_cpu_frontend_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d471)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d471_20261012/7b_cpu_frontend_validation_100
    CONFIG=configs/ieee_tc/20261012_d471_7b_cpu_frontend_validation_100.yaml
    TAG=d471_7b_cpu_frontend_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d472)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d472_20261012/7b_full_w0
    CONFIG=configs/ieee_tc/20261012_d472_7b_full_w0.yaml
    TAG=d472_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d475)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d475_20261012/7b_cpu_frontend_validation_100
    CONFIG=configs/ieee_tc/20261012_d475_7b_cpu_frontend_validation_100.yaml
    TAG=d475_7b_cpu_frontend_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d476)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d476_20261012/7b_full_w0
    CONFIG=configs/ieee_tc/20261012_d476_7b_full_w0.yaml
    TAG=d476_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d512)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d512_20261014/7b_full_w0_prefix1
    CONFIG=configs/ieee_tc/20261014_d512_7b_full_w0_prefix1.yaml
    TAG=d512_7b_full_w0_prefix1
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=1000
    ;;
  d515)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d515_20261014/7b_cpu_frontend_validation_100
    CONFIG=configs/ieee_tc/20261014_d515_7b_cpu_frontend_validation_100.yaml
    TAG=d515_7b_cpu_frontend_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d516)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d516_20261014/7b_full_w0
    CONFIG=configs/ieee_tc/20261014_d516_7b_full_w0.yaml
    TAG=d516_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d519)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d519_20261014/7b_full_w0_prefix1
    CONFIG=configs/ieee_tc/20261014_d519_7b_full_w0_prefix1.yaml
    TAG=d519_7b_full_w0_prefix1
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=1000
    ;;
  d523)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d523_20261014/7b_cpu_frontend_validation_100
    CONFIG=configs/ieee_tc/20261014_d523_7b_cpu_frontend_validation_100.yaml
    TAG=d523_7b_cpu_frontend_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d527)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d527_20261014/7b_cpu_frontend_validation_100
    CONFIG=configs/ieee_tc/20261014_d527_7b_cpu_frontend_validation_100.yaml
    TAG=d527_7b_cpu_frontend_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d528)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d528_20261014/7b_cpu_frontend_validation_100
    CONFIG=configs/ieee_tc/20261014_d528_7b_cpu_frontend_validation_100.yaml
    TAG=d528_7b_cpu_frontend_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d529)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d529_20261014/7b_full_w0
    CONFIG=configs/ieee_tc/20261014_d529_7b_full_w0.yaml
    TAG=d529_7b_full_w0
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d533)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d533_20261015/7b_full_w1
    CONFIG=configs/ieee_tc/20261015_d533_7b_full_w1.yaml
    TAG=d533_7b_full_w1
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d550)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/7b_initial_control_validation_100
    CONFIG=configs/ieee_tc/20261015_d550_7b_initial_control_validation_100.yaml
    TAG=d550_7b_initial_control_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d551)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d551_20261015/7b_initial_control_full_w1
    CONFIG=configs/ieee_tc/20261015_d551_7b_initial_control_full_w1.yaml
    TAG=d551_7b_initial_control_full_w1
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d554)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d554_20261015/7b_initial_control_full_w2
    CONFIG=configs/ieee_tc/20261015_d554_7b_initial_control_full_w2.yaml
    TAG=d554_7b_initial_control_full_w2
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d597)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d597_20261017/7b_parallel_pressure_validation_100
    CONFIG=configs/ieee_tc/20261017_d597_7b_parallel_pressure_validation_100.yaml
    TAG=d597_7b_parallel_pressure_validation_100
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=100
    ;;
  d598)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d598_20261017/7b_parallel_pressure_full_w2
    CONFIG=configs/ieee_tc/20261017_d598_7b_parallel_pressure_full_w2.yaml
    TAG=d598_7b_parallel_pressure_full_w2
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  d603)
    RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d603_20261017/7b_controller_full_w2
    CONFIG=configs/ieee_tc/20261017_d603_7b_controller_full_w2.yaml
    TAG=d603_7b_controller_full_w2
    SCENARIO=tc_ieee_full
    PREFIX_COUNT=
    ;;
  *) echo 'Unknown frozen campaign identity; no arbitrary output override' >&2; exit 2 ;;
esac
[[ $# -le 1 ]] || exit 2
cd "$ROOT"
[[ ! -e "$RAW" ]] || { echo "Refusing existing run: $RAW" >&2; exit 2; }
mkdir -p "$(dirname "$RAW")"
mkdir "$RAW"
set -o noclobber
exec >"$RAW/launcher.log" 2>&1
export PATH="/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin:$PATH"
export CUDA_HOME=/usr/local/cuda-13.0
export FLASHINFER_NVCC=/usr/local/cuda-13.0/bin/nvcc
export MAX_JOBS=2
IFS= read -r PRIME_REMOTE_TOKEN < /home/qhq/.config/primelora-tc-d75/artifact.token
export PRIME_REMOTE_TOKEN
export FAASLORA_REMOTE_ARTIFACT_ENABLED=1
export FAASLORA_REMOTE_ARTIFACT_ENDPOINT=http://192.168.4.174:18081
export FAASLORA_REMOTE_ARTIFACT_DELIVERY_MODE=prepublished_gzip_v1
export FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY=uncached_background_v1
export PYTORCH_ALLOC_CONF=pinned_max_cached_size_mb:0,pinned_use_background_threads:True
export VLLM_CACHE_ROOT=/home/qhq/.cache/vllm
export FAASLORA_PYTHON=/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python
if [[ "${1:-d293}" == d328 || "${1:-d293}" == d351 || "${1:-d293}" == d456 || "${1:-d293}" == d512 || "${1:-d293}" == d519 || "${1:-d293}" == d603 ]]; then
  # Observer is enabled by this wrapper only AFTER the normal resource gate.
  export FAASLORA_PYTHON="$ROOT/scripts/ieee_tc/profile_d328_controller_python.sh"
fi
export FAASLORA_TC_QUALIFICATION=1
export FAASLORA_TC_EXTERNAL_REPLAY=1
export FAASLORA_TC_REPLAY_PROFILE=W0
unset FAASLORA_TC_ADAPTER_MAP FAASLORA_TC_ADAPTER_MAP_SHA256
if [[ "${1:-d293}" == d554 || "${1:-d293}" == d598 || "${1:-d293}" == d603 ]]; then
  export FAASLORA_TC_REPLAY_PROFILE=W2
  export FAASLORA_TC_ADAPTER_MAP="$ROOT/paper_results/ieee_tc/inputs/20261015_7b_w2_adapter_map_v1.json"
  export FAASLORA_TC_ADAPTER_MAP_SHA256=48c72e39bfff13874de70a73a8a7ca26ff7be5246d5ee5a3a59dfb06bd502300
  export FAASLORA_TC_NATIVE_TOOLCHAIN_CONTRACT="$ROOT/configs/ieee_tc/native_toolchain_cuda130_v1.json"
  export FAASLORA_TC_NATIVE_TOOLCHAIN_SHA256=328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c
fi
if [[ "${1:-d293}" == d533 || "${1:-d293}" == d550 || "${1:-d293}" == d551 || "${1:-d293}" == d597 ]]; then
  export FAASLORA_TC_REPLAY_PROFILE=W1
  export FAASLORA_TC_NATIVE_TOOLCHAIN_CONTRACT="$ROOT/configs/ieee_tc/native_toolchain_cuda130_v1.json"
  export FAASLORA_TC_NATIVE_TOOLCHAIN_SHA256=328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c
fi
if [[ -n "$PREFIX_COUNT" ]]; then
  export FAASLORA_TC_DIAGNOSTIC_PREFIX_COUNT="$PREFIX_COUNT"
else
  unset FAASLORA_TC_DIAGNOSTIC_PREFIX_COUNT
fi
export FAASLORA_TC_LAUNCH_OUTPUT="$RAW/launch.json"
export FAASLORA_TC_PREDICTED_GROWTH_GIB=32
export FAASLORA_TC_NVML_BINDING=/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py
export FAASLORA_TC_NVML_SHA256=4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea
export FAASLORA_SHARED_TRACE_PATH=/home/qhq/serverless_llm_baselines/results/paper_experiments/11_remote_fair_main_local_sim_v4/20260512_123619_llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_remote_fair_local-sim_v1/shared_artifacts/llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_remote_fair_local-sim_v1_trace.json
export FAASLORA_SHARED_ADAPTER_SUBSET_PATH="${FAASLORA_SHARED_TRACE_PATH%_trace.json}_adapter_subset.json"
if [[ "${1:-d293}" == d451 ]]; then
  # Reuse D433/D443's original source and exact derived functional view.
  export FAASLORA_SHARED_TRACE_PATH=/home/qhq/serverless_llm_baselines/results/paper_experiments/03_main_comparison/20260424_104050_llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1/shared_artifacts/llama2_7b_r4000_a500_seed42_z1p0_hot48_rot500_s8_mainv1_trace.json
  export FAASLORA_SHARED_ADAPTER_SUBSET_PATH="${FAASLORA_SHARED_TRACE_PATH%_trace.json}_adapter_subset.json"
  export FAASLORA_TC_REPLAY_PROFILE=ADAPTER_COVERAGE_V1
  export FAASLORA_TC_COVERAGE_POOL_INDEX="$ROOT/paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json"
  export FAASLORA_TC_COVERAGE_POOL_INDEX_SHA256=e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c
fi
export FAASLORA_TRACE_ROLE=exploratory
export FAASLORA_FORMAL_RUN=0
export FAASLORA_RESULTS_TAG="$TAG"
export FAASLORA_WORKER_START_TIMEOUT_S=600
export FAASLORA_KEEP_DEDICATED_WORKER_LOGS=1
export PYTHONNOUSERSITE=1
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUNBUFFERED=1
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export VLLM_NO_USAGE_STATS=1
exec bash scripts/run_all_experiments_user_scope.sh \
  --config "$CONFIG" \
  --scenario "$SCENARIO" --full-stack
