"""Additive D357 offline-audit checkpoint; original preparation is immutable."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d357_control_interleave'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
test=json.loads((RAW/'analysis1_receipt.json').read_text())
assert test['passed'] and 'Ran 169 tests' in (RAW/'analysis1.log').read_text()
for path,sha in test['sources'].items():assert p.digest(ROOT/path)==sha
old=test['identity'];assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
cleanup=p.stop_scope_identity(old)
assert cleanup['released'] and not cleanup['hard_kill'] and not Path(old['path']).exists()
original=json.loads((OUT/'preparation.json').read_text())
for r in original['refs']+original['raw_refs']:assert p.digest(Path(r['path']))==r['sha256']
subprocess.run(['sha256sum','-c','preparation_validated.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
gate=p.preflight([ROOT],32*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
members={n:RAW/n for n in ('test_analysis.py','analysis1.log','analysis1_receipt.json',
                          'start_validated.py','seal_analysis.py')}
archive=OUT/'analysis_preparation_sources.tar.gz'
with tarfile.open(archive,'x:gz') as f:
    for n,path in members.items():f.add(path,arcname=n,recursive=False)
with tarfile.open(archive) as f:
    assert len(f.getmembers())==len(members)
    for m in f.getmembers():
        assert m.isfile() and m.name in members
        assert hashlib.sha256(f.extractfile(m).read()).hexdigest()==p.digest(members[m.name])
record=dict(kind='d357_full_control_audit_preparation_v1',passed=True,tests=169,
    original_preparation_sha256=p.digest(OUT/'preparation.json'),
    test=test,cleanup=cleanup,gate=gate,
    archive=dict(path=str(archive),sha256=p.digest(archive),bytes=archive.stat().st_size,
                 members={n:p.digest(path) for n,path in members.items()}),
    gpu_performance_run=False,formula_or_policy_change=False,
    sources=test['sources'],identity=identity)
with (OUT/'analysis_preparation.json').open('x') as f:json.dump(record,f,indent=2)
with (OUT/'analysis_preparation.sha256').open('x') as f:
    for path in (archive,OUT/'analysis_preparation.json'):
        f.write(p.digest(path)+'  '+path.name+'\n')
with (RAW/'analysis_seal_scope.json').open('x') as f:
    json.dump(dict(identity=identity,passed=True,resources={k:(group/k).read_text().strip()
        for k in ('memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(passed=True,archive_bytes=archive.stat().st_size,cleanup=cleanup)))
