#!/usr/bin/env bash
# Reuse post-exit absence receipt; no manual stop of removed scopes.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d164_20261002
{
  date -Is
  jq -e '.pass == true and .service_returncode == 0 and .replay_returncode == 0 and .watchdog_returncode == 0 and .native_gpu_context_release_confirmed == true and .service_path_removed == true and .service_identity.invocation_id == "44e8b9abc6b74796a4e19095f1e78d97"' "$raw/7b_full_w0_full1/launch.json"
  for unit in primelora-tc-svc-f75b863601e84d63be61ef2cc1a575cc.scope primelora-tc-aux-d985f0241abd4a50b5613132abf467fb.scope; do
    test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
    test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
    test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
    systemctl --user show "$unit" -p Id -p ActiveState -p InvocationID -p TasksCurrent
  done
  for pid in 3834703 3834731 3834809 3838044 3843356 3843473 3843637; do
    test ! -e "/proc/$pid"
    printf 'owned_pid=%s absent\n' "$pid"
  done
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  printf 'cleanup=automatic_removal_verified\nfinal_cgroup_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_local_cleanup.txt"
