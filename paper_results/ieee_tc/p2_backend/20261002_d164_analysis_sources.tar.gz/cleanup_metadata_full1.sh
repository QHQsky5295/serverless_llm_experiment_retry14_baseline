#!/usr/bin/env bash
# Reuse D160 automatic-removal verification, with this actual invocation only.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d164_20261002
unit=primelora-d164-full1-metadata2-20261002.scope
{
  date -Is
  rg -qx 'InvocationID=a5ba057fa5134d96a4d8af54b5ad344a' "$raw/full_full1_metadata2_scope.txt"
  rg -q 'Exit status: 0' "$raw/full_full1_metadata2_time.txt"
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=a5ba057fa5134d96a4d8af54b5ad344a\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=unavailable_after_removal\n'
} | tee "$raw/full_full1_metadata_cleanup.txt"
