"""Reuse D665 configuration/entry checks and D667 bounded observer qualification."""
import ast
import hashlib
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/qualify.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '95ec19233568e28d778f733efd9b3d66422cc5cf23825e23763a0da115eff75c'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d665_3b_full_w0'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d668_3b_host_inventory_prefix1'")
replace("text.index('  d665)\\n')", "text.index('  d668)\\n')")
replace("assert restored.count(' || \"${1:-d293}\" == d665')==2", "assert restored.count(' || \"${1:-d293}\" == d668')==3")
replace("restored=restored.replace(' || \"${1:-d293}\" == d665','')", "restored=restored.replace(' || \"${1:-d293}\" == d668','')")
replace("old_config=ROOT/'configs/ieee_tc/20261018_d660_3b_full_w0.yaml'", "old_config=ROOT/'configs/ieee_tc/20261018_d665_3b_full_w0.yaml'")
replace("\nconfig=ROOT/'configs/ieee_tc/20261018_d665_3b_full_w0.yaml'", "\nconfig=ROOT/'configs/ieee_tc/20261018_d668_3b_full_w0_prefix1.yaml'")
replace("assert config.read_text()==old_config.read_text().replace('d660','d665')", """expected=old_config.read_text().replace('d665','d668').replace('/3b_full_w0','/3b_full_w0_prefix1').replace('/3b_nvme_w0','/3b_nvme_w0_prefix1').replace('tc-d668-3b-w0','tc-d668-3b-w0-prefix1').replace('total_requests: 4000','total_requests: 1000')
assert config.read_text()==expected""")
code = code.replace('count=4000', 'count=1000')
replace("assert plan.identity()['view_sha256']=='0d998f48a006d638dda9b8d714f667fe3a87f4d2c88044ce19a816b308494a37'", "assert plan.identity()['count']==1000 and plan.identity()['source_count']==4000 and plan.identity()['rate_scale']==1.0")
replace("assert not (RAW/'3b_full_w0').exists()", "assert not (RAW/'3b_full_w0_prefix1').exists()")
replace('d665_same_configuration_native_host_candidate_full_w0_v1', 'd668_same_configuration_host_inventory_diagnostic_prefix_v1')
replace('same_configuration_as_d660_except_paths=True', 'same_configuration_as_d665_except_population_and_paths=True,diagnostic_cpu_tests=259')
replace("paths=[shell,config,old_config,prepared_path", "paths=[shell,wrapper,config,old_config,prepared_path")
anchor = "for path in [shell,*RAW.glob('*.sh')]:subprocess.run(['bash','-n',str(path)],check=True)"
replace(anchor, """wrapper=ROOT/'scripts/ieee_tc/profile_d328_controller_python.sh'
wrapped=wrapper.read_text()
begin=wrapped.index('  d668_3b_full_w0_prefix1)\\n')
end=wrapped.index('    ;;\\n',begin)+len('    ;;\\n')
restored_wrapper=wrapped[:begin]+wrapped[end:]
new_gate='''if [[ "$FAASLORA_RESULTS_TAG" == d668_3b_full_w0_prefix1 ]]; then
  export FAASLORA_TC_HOST_INVENTORY_TIMING=fresh_inventory_v1
else
  unset FAASLORA_TC_HOST_INVENTORY_TIMING
fi
'''
assert restored_wrapper.count(new_gate)==1
restored_wrapper=restored_wrapper.replace(new_gate,'')
assert restored_wrapper==subprocess.check_output(['git','show','HEAD:'+str(wrapper.relative_to(ROOT))],cwd=ROOT,text=True)
assert 'PREFIX_COUNT=1000' in text[text.index('  d668)'):text.index('    ;;',text.index('  d668)'))]
diagnostic=RAW.parent/'d667_20261018'
for phase in ('qualification','analysis2'):
    receipt=read(diagnostic/(phase+'_receipt.json'))
    assert receipt['passed'] and receipt['returncode']==0
    assert p.digest(diagnostic/(phase+'.log'))==receipt['log_sha256']
    for path,sha in receipt['source_sha256'].items():
        assert p.digest(Path(path))==sha,path
        refs[path]=sha
    closed=read(diagnostic/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
closed=read(diagnostic/'backup_closure.json')
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
assert read(diagnostic/'backup_receipt.json')['head']=='bcbce5ae1296815dab1f8b94b16aeb3cadb585d6'
with (RAW/'wrapper_tests.log').open('x') as stream:
    tested=subprocess.run([sys.executable,'-B','-m','unittest','tests.test_ieee_tc_d456_diagnostic_contract','-v'],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
assert tested.returncode==0
for path in [shell,wrapper,*RAW.glob('*.sh')]:subprocess.run(['bash','-n',str(path)],check=True)
""")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
