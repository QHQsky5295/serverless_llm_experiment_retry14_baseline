"""Preserve full-source YAML; select first1000 only in the existing replay contract."""
import ast
from pathlib import Path
raw = Path(__file__).resolve().parent
tree = ast.parse((raw/'qualify.py').read_text())
assert isinstance(tree.body[-1], ast.Expr) and tree.body[-1].value.func.id == 'exec'
ns = {'__file__': str(__file__), '__name__': '__main__'}
exec(compile(ast.Module(body=tree.body[:-1],type_ignores=[]),str(raw/'qualify.py'),'exec'),ns)
code = ns['code']
old = "host_dir=cfg['storage']['host_cache_dir'],count=1000)"
assert code.count(old) == 1
code = code.replace(old, "host_dir=cfg['storage']['host_cache_dir'],count=4000)")
old = ".replace('total_requests: 4000','total_requests: 1000')"
assert code.count(old) == 1
code = code.replace(old, '')
for old,new in [('qualification_identity.json','qualification2_identity.json'),
                ('resource_gate.json','resource_gate2.json'),
                ('wrapper_tests.log','wrapper_tests2.log'),
                ('qualification.json','qualification2.json')]:
    code = code.replace(old,new)
code = code.replace('same_configuration_as_d665_except_population_and_paths=True',
                    'same_configuration_as_d665_except_paths=True')
ast.parse(code)
exec(compile(code,str(raw/'qualify2_expanded.py'),'exec'))
