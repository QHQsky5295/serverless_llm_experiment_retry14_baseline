"""Reuse sealed D660 explicit prelaunch backup for one non-performance diagnostic."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d660_20261018/backup.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='6839c566c03aebe258a0580d2d021a701e424c9402447d871d34d2d1d8e5af04'
code=data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d660_3b_full_w0'", "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d668_3b_host_inventory_prefix1'")
replace('9fe8ffc78ce338b80c5836d1bd4d5a82511b5d48','bcbce5ae1296815dab1f8b94b16aeb3cadb585d6')
replace("preparation['count']==4000","preparation['count']==1000")
replace("qualification['count']==4000 and qualification['reused_cpu_tests']==6", "qualification['count']==1000 and qualification['reused_cpu_tests']==655 and qualification['diagnostic_cpu_tests']==259")
replace('same_configuration_as_d659_except_population_and_paths','same_configuration_as_d665_except_paths')
replace("files=['prelaunch.json']", "files=['prelaunch.json','preparation.json']")
replace("'qualification_identity.json','qualification_closure.json')", "'qualification_identity.json','qualification_closure.json','wrapper_tests.log','failed_initial_population.yaml','qualification_identity.json','qualification_closure.json','resource_gate.json','wrapper_tests.log')")
replace("previous=RAW.parent/'d659_20261018'", "previous=RAW.parent/'d667_20261018'")
replace("closed=read(previous/'publication_closure.json')", "closed=read(previous/'backup_closure.json')")
replace("('publication_identity.json','publication_receipt.json','publication_closure.json')", "('backup_identity.json','backup_receipt.json','backup_closure.json')")
replace('D660_3B_FULL_W0.md','D668_3B_HOST_INVENTORY_PREFIX_DIAGNOSTIC.md')
replace("'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',", "'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',\n    'scripts/ieee_tc/profile_d328_controller_python.sh',")
replace('20261018_d660_3b_full_w0.yaml','20261018_d668_3b_full_w0_prefix1.yaml')
replace('tc: freeze unchanged 3B Full configuration for complete W0 replay (D660)', 'tc: freeze one bounded 3B HOST inventory diagnostic with original workload (D668)')
code=code.replace('qualification.json','qualification2.json').replace('qualification_identity.json','qualification2_identity.json').replace('qualification_closure.json','qualification2_closure.json').replace('resource_gate.json','resource_gate2.json').replace('wrapper_tests.log','wrapper_tests2.log')
code=code.replace("members=sorted(RAW.glob('*.py'))+sorted(RAW.glob('*.sh'))", "members=sorted(RAW.glob('*.py'))+sorted(RAW.glob('*.sh'))+[RAW/name for name in ('qualification_identity.json','qualification_closure.json','resource_gate.json','wrapper_tests.log')]")
code=code.replace("for path in members:\n        check(path.read_bytes());", "for path in dict.fromkeys(members):\n        check(path.read_bytes());")
ast.parse(code)
if sys.argv[1:]==['--check-only']:print('D668 prelaunch backup adaptation parsed; no writes.')
elif not sys.argv[1:]:exec(compile(code,str(source),'exec'))
else:raise SystemExit('expected no arguments or --check-only')
