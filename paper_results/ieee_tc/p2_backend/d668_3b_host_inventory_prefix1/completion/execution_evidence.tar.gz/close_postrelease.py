"""Reuse exact-owned closure for the distinct postrelease analysis identity."""
import ast
from pathlib import Path
source=Path(__file__).resolve().parent/'close.py'
code=source.read_text()
old="('qualification','qualification2','backup','start','analysis','analysis2','publication','publication2')"
assert code.count(old)==1
code=code.replace(old,"('postrelease',)")
ast.parse(code)
exec(compile(code,str(source),'exec'))
