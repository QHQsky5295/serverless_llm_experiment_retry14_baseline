"""Reuse D595 explicit-path publication for a completed, non-ranking diagnostic."""
import ast
import hashlib
from pathlib import Path
import sys

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='c16bfc285f6b9ed3f14bd46b730b5c37f0a9c52245f0f90e093fa2c23f34c1c4'
code=data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace('d595_parallel_pressure_barrier','d668_3b_host_inventory_prefix1/completion')
code=code.replace('023ae0079e0b2ffa537a81bda7855e8a4b8ede95','e760eadb040c74f284fa345859db7bd482d0a138')
code=code.replace("RAW/'backup_identity.json'","RAW/'publication_identity.json'")
code=code.replace("RAW/'backup_receipt.json'","RAW/'publication_receipt.json'")
start=code.index("reg=read(RAW/'regression2_receipt.json')")
end=code.index('preserved={',start)
code=code[:start]+'''reg=read(RAW/'analysis_receipt.json');focused=read(RAW/'analysis2_receipt.json')
assert reg['passed'] is False and reg['returncode']==1 and focused['passed'] and focused['returncode']==0
assert 'Ran 183 tests' in (RAW/'analysis.log').read_text()
assert 'FAILED (errors=2)' in (RAW/'analysis.log').read_text()
assert "ModuleNotFoundError: No module named 'ijson'" in (RAW/'analysis.log').read_text()
assert 'Ran 2 tests' in (RAW/'analysis2.log').read_text() and '\\nOK\\n' in (RAW/'analysis2.log').read_text()
for report,name in ((reg,'analysis'),(focused,'analysis2')):
    assert p.digest(RAW/(name+'.log'))==report['log_sha256']
    for path,sha in report['source_sha256'].items():assert p.digest(Path(path))==sha
for phase in ('analysis','analysis2','postrelease','postrelease2','operations','qualification','qualification2','backup','start'):
    closure=read(RAW/(phase+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
local=read(RAW/'local_cleanup.json')
assert local['passed'] and local['service_returncode']==0 and local['actual_recursive_procs_empty']
for name in ('service_identity','auxiliary_identity'):assert not Path(local[name]['path']).exists()
completed=read(RAW/'completion_receipt.json')
assert completed['n_plan']==completed['n_terminal']==completed['n_native_contract_complete']==1000
assert completed['remote_stop']['all_owned_units_inactive'] and completed['native_gpu_context_release_confirmed']
assert completed['remote_stop']['ports_18080_18081_absent']
for name,sha in completed['remote_stop']['hashes'].items():assert p.digest(RAW/name)==sha
collected=read(RAW/'collection_receipt.json')
assert p.digest(Path(collected['source_path']))==collected['source_sha256']==completed['source_sha256']
assert read(RAW/'postrelease2_receipt.json')['passed'] and read(RAW/'operation_receipt.json')['passed']
manifest=read(OUT/'analysis_manifest.json')
for name,sha in manifest['outputs'].items():assert p.digest(OUT/name)==sha
for path,sha in manifest['source_refs'].items():assert p.digest(Path(path))==sha
for name in ('core_timing/summary.json','operation_detail1/summary.json','operation_detail1/inventory_summary.json'):
    for ref in read(OUT/name)['sources']:assert p.digest(Path(ref['path']))==ref['sha256']
summary=read(OUT/'completion.json')
assert summary['passed'] and summary['complete_processes']==summary['processes']==4
assert summary['complete_request_observations']==1000 and summary['inventory_observations']==16329
assert summary['n_correct'] is None and not summary['ranking_eligible'] and not summary['formal_performance_result']
inventory=read(OUT/'operation_detail1/inventory_summary.json')
assert inventory['total_completed_spans']==287670
assert {r['boundary']:r['count'] for r in inventory['inventory_summary']}=={'host_inventory':9233,'host_allocator_stats':7096}
for path,sha in {
    'faaslora/memory/gpu_monitor.py':'9fd4f98c9b5241b3b722f7ac5835429c6714c6de5bf1c1f6a2ac77899ff2b270',
    'faaslora/scheduling/vllm_ieee_scheduler.py':'8d862e8af56c3f4d70283c5d34d1800af9108a3be5d29dfc5b72ddc803b9f1c9',
}.items():assert p.digest(ROOT/path)==sha
gate=p.preflight([ROOT],16*1024*1024)
assert gate['preflight_pass'],gate['issues']
save(RAW/'publication_gate.json',gate)
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/qhq/serverless_llm_baselines',text=True).strip()=='e16af33aaf41f02a62ecdce59f6f3227813244c3'
''' + code[end:]
start=code.index('members=[RAW/name')
end=code.index('\nfor path in members:',start)
code=code[:start]+"members=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),*RAW.glob('*.json'),*RAW.glob('*.jsonl'),*RAW.glob('*.log'),RAW/'failed_initial_population.yaml'])\nassert len({v.name for v in members})==len(members)\nassert sum(v.stat().st_size for v in members)<8*1024*1024"+code[end:]
replace('OUT.mkdir(parents=True,exist_ok=False)','assert OUT.is_dir()')
start=code.index('test_counts={name:')
end=code.index("names=['faaslora/scheduling/resource_coordinator.py'",start)
code=code[:start]+'''test_counts={'distinct_final_pass':183,'first_attempt_pass':181,'environment_import_errors':2,'native_environment_rechecks_pass':2}
record=dict(passed=True,production_candidate=False,diagnostic_only=True,
    parent_commit='e760eadb040c74f284fa345859db7bd482d0a138',
    formal_performance_result=False,ranking_eligible=False,n_correct=None,
    diagnostic='fresh_inventory_v1',test_counts=test_counts,completion=summary,
    source_result_sha256=collected['source_sha256'],protected=protected,
    preserved={str(k):v for k,v in preserved.items()},
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    raw_member_sha256={v.name:p.digest(v) for v in members},
    archive_source_helper_sha256=p.digest(Path(__file__)),
    caveat='One observed 3B prefix, not a performance candidate or ranking. Nested inventory overlaps are not additive or a counterfactual speedup.')
save(OUT/'publication.json',record)
published=sorted(v for v in OUT.rglob('*') if v.is_file())
assert not (OUT/'result.sha256').exists()
with (OUT/'result.sha256').open('x') as f:
    for path in published:f.write(p.digest(path)+'  '+str(path.relative_to(OUT))+'\\n')
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
''' + code[end:]
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['scripts/analyze_control_path_overhead.py','tests/test_ieee_tc_core_timing_analysis.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D668_3B_HOST_INVENTORY_PREFIX_DIAGNOSTIC.md']")
replace("names += [str((OUT/name).relative_to(ROOT)) for name in ('qualification.json','execution_evidence.tar.gz','result.sha256')]",
        "names += [str(path.relative_to(ROOT)) for path in [*published,OUT/'result.sha256']]")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: preserve measured 3B HOST inventory bottleneck and strict nested-span analysis (D668)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D668 explicit-path completed diagnostic publication parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
