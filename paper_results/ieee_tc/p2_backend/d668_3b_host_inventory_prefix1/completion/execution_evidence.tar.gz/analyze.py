"""Reuse D665 native audit and D351 core-window analysis for this closed prefix."""
import ast
import contextlib
import hashlib
import io
import json
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/analyze.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='33609fce609f51520cfd4b5a9ba4b9c8e482f41d0d01b46a9e341c7ea18881a9'
code=data.decode()
code=code.replace("run=RAW/'3b_full_w0'","run=RAW/'3b_full_w0_prefix1'")
code=code.replace('d665_3b_full_w0/preparation.json','d668_3b_host_inventory_prefix1/preparation.json')
code=code.replace('==4000','==1000').replace('count=4000','count=1000')
code=code.replace('range(8)','range(2)')
code=code.replace('d665_3b_current_full_w0_qualification_v1','d668_3b_host_inventory_prefix_native_audit_v1')
code=code.replace('fixed_workload_complete4000=True','fixed_workload_complete4000=False,diagnostic_prefix_count=1000,formal_performance_result=False,observer_overhead_included=True')
ast.parse(code)
namespace={'__file__':str(__file__),'__name__':'__main__'}
capture=io.StringIO()
with contextlib.redirect_stdout(capture):
    exec(compile(code,str(source),'exec'),namespace)
audit=json.loads(capture.getvalue())
assert audit['passed'] and audit['protocol_bound_count']==1000 and not audit['ranking_eligible']
ROOT,RAW,run=namespace['ROOT'],namespace['RAW'],namespace['run']
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d668_3b_host_inventory_prefix1/completion'
OUT.mkdir(parents=True,exist_ok=False)
def save(name,value):
    with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
save('native_audit.json',audit)

# Same existing D351 window construction, using the frozen 3B ruler, not 7B.
from scripts.ieee_tc.analyze_d297_full import (
    partition_activation_readiness,decode_overlap_summary,native_load_overlap_summary)
from scripts.analyze_control_path_overhead import analyze_core_host_timing
requests,launch=namespace['requests'],namespace['launch']
E=run/'launch.launch'
deployment=json.loads((E/'physical_deployment/deployment.json').read_text())
thresholds=[dict(group_id=g['group_id'],lower_exclusive=g['lower_exclusive'],
    upper_inclusive=g['upper_inclusive'],ttft_s=g['ttft_ms']/1000,tpot_s=g['tpot_ms']/1000)
    for g in namespace['slo']['groups']]
ready,not_ready=partition_activation_readiness(namespace['activations'],requests,
    clock_id=deployment['clock_id'])
decode=decode_overlap_summary(requests,ready,clock_id=deployment['clock_id'],
    arrival_start=deployment['arrival_start_s'],thresholds=thresholds)
windows=native_load_overlap_summary(requests,decode['requests'],clock_id=deployment['clock_id'])['requests']
incarnations={}
for path in (E/'physical_allocations').glob('*.jsonl'):
    for line in path.open():
        event=json.loads(line)
        if event['event']!='native_workers':continue
        for worker in event['workers']:
            matches=[r for device in event['census']['devices'] for r in device['processes']
                if r['pid']==worker['pid'] and r['kind']=='compute' and r['service_member']
                and device['gpu_uuid']==worker['device_uuid']]
            assert len(matches)==1
            pid,ticks=worker['pid'],matches[0]['identity']['start_ticks']
            assert pid not in incarnations or incarnations[pid]==ticks
            incarnations[pid]=ticks
for window in windows:
    pid=window['worker_pid']
    assert pid in incarnations and (E/f'diagnostic_core/{pid}-{incarnations[pid]}.jsonl').is_file()
core=analyze_core_host_timing(E/'diagnostic_core',E/'exec_receipt.json',
    E/'physical_deployment/deployment.json',windows,OUT/'core_timing')
assert core['host_inventory_timing']=='fresh_inventory_v1'
save('completion.json',dict(passed=True,native_bound_count=1000,n_correct=None,
    formal_performance_result=False,ranking_eligible=False,includes_observer_overhead=True,
    complete_processes=core['complete_processes'],processes=core['processes'],
    complete_request_observations=core['complete_request_observations'],
    inventory_observations=core['host_inventory_observations'],thresholds=thresholds,
    not_ready_activations=not_ready,no_figures=True,
    analysis_tests='181 passed in existing CPU environment; two ijson-dependent tests passed separately in existing native environment; first errors retained'))
refs=[Path(__file__),RAW/'collect_closure.py',RAW/'postrelease.py',
    ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'tests/test_ieee_tc_core_timing_analysis.py',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')]
save('analysis_manifest.json',dict(source_refs={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in refs},
    outputs={str(path.relative_to(OUT)):hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(OUT.rglob('*')) if path.is_file()}))
print(json.dumps(dict(passed=True,completed_native=1000,core_processes=core['processes'],
    complete_processes=core['complete_processes'],complete_requests=core['complete_request_observations'],
    inventory_observations=core['host_inventory_observations'],groups=core['groups'])))
