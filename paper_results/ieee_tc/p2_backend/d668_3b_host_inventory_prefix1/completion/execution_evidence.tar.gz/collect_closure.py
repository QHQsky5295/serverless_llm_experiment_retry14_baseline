"""Reuse the closed D665 remote collector without re-materializing any artifact."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/collect_closure.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='c03b7de0b731dd531dc267d0aec95b2ad904830211953c02be92ed165624a881'
code=data.decode().replace('d665','d668').replace("run = raw/'3b_full_w0'","run = raw/'3b_full_w0_prefix1'")
code=code.replace('3b_full4000_closure_v1','3b_diagnostic_prefix1000_closure_v1')
code=code.replace('current 3B Full4000 W0 observation','current 3B W0 prefix1000 HOST diagnostic with observer overhead')
ast.parse(code)
exec(compile(code,str(source),'exec'))
