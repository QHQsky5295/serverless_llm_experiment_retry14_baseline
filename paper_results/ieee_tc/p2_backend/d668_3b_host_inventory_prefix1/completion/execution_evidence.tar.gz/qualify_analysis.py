"""Reuse bounded CPU regression gates for the post-release inventory analyzer."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d663_20261018/qualify.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='1cfd5d94227448d349d837b613283b03d85a28f3069e74fa118ef531b952eeea'
code=data.decode()
old="paths = ['faaslora/memory/gpu_monitor.py', 'faaslora/memory/residency_manager.py',\n         'tests/test_ieee_tc_hit_host_transaction.py']"
assert code.count(old)==1
code=code.replace(old,"paths = ['scripts/analyze_control_path_overhead.py', 'tests/test_ieee_tc_core_timing_analysis.py', 'faaslora/utils/core_timing.py']")
old="tests = ['tests.test_ieee_tc_host_observation_freshness']"
assert code.count(old)==1
code=code.replace(old,"""tests = ['tests.test_ieee_tc_core_timing_analysis', 'tests.test_ieee_tc_core_timing',
        'tests.test_ieee_tc_capacity_audit', 'tests.test_ieee_tc_route_identity_cache',
        'tests.test_ieee_tc_control_timeline', 'tests.test_ieee_tc_timing_bound',
        'tests.test_ieee_tc_rpc_breakdown']
    assert sys.executable == '/home/qhq/anaconda3/envs/sllm_vllm0102_newserverless_20260518/bin/python'
    local = json.loads((RAW/'local_cleanup.json').read_text())
    assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
    assert not Path(local['service_identity']['path']).exists()
    assert not Path(local['auxiliary_identity']['path']).exists()""")
ast.parse(code)
exec(compile(code,str(source),'exec'))
