"""Resume publication only; keep the large raw remote monitor outside Git."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path(__file__).resolve().parent/'publication.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='e35e22a1be2ca95d3bde5952e42533059723cde7f97d220c699ea24db4a58c1a'
tree=ast.parse(data)
assert isinstance(tree.body[-1],ast.If)
namespace={'__file__':str(__file__),'__name__':'__main__'}
exec(compile(ast.Module(body=tree.body[:-1],type_ignores=[]),str(source),'exec'),namespace)
code=namespace['code']
code=code.replace("RAW/'publication_identity.json'","RAW/'publication2_identity.json'")
code=code.replace("RAW/'publication_gate.json'","RAW/'publication2_gate.json'")
code=code.replace("RAW/'publication_receipt.json'","RAW/'publication2_receipt.json'")
old="assert len({v.name for v in members})==len(members)"
assert code.count(old)==1
code=code.replace(old,"""previous=read(RAW/'publication_closure.json')
assert previous['passed'] and previous['actual_recursive_procs_empty'] and previous['path_gone']
assert not Path(previous['identity']['path']).exists()
assert not (OUT/'publication.json').exists() and not (OUT/'execution_evidence.tar.gz').exists()
# Its SHA is verified above and saved in the completion receipt; never delete it.
members=[v for v in members if v.name!='remote_monitor.log']
assert len({v.name for v in members})==len(members)""")
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D668 publication resume parsed; raw monitor retained, no writes.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
