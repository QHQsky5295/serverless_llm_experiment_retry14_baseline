"""Reuse D665 bounded post-release collector/analyzer orchestration."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/run_analysis.py')
code=source.read_text()
# Preserve the actual closure gates and command sequence; only a new identity.
assert "raw/'analysis_identity.json'" in code and "raw/'analysis_receipt.json'" in code
code=code.replace("raw/'analysis_identity.json'","raw/'postrelease_identity.json'")
code=code.replace("raw/'analysis_receipt.json'","raw/'postrelease_receipt.json'")
guard="""
checks=json.loads((raw/'analysis_receipt.json').read_text())
supplement=json.loads((raw/'analysis2_receipt.json').read_text())
assert checks['returncode']==1 and supplement['passed']
assert 'Ran 183 tests' in (raw/'analysis.log').read_text()
assert 'FAILED (errors=2)' in (raw/'analysis.log').read_text()
assert "ModuleNotFoundError: No module named 'ijson'" in (raw/'analysis.log').read_text()
assert 'Ran 2 tests' in (raw/'analysis2.log').read_text() and '\\nOK\\n' in (raw/'analysis2.log').read_text()
for report in (checks,supplement):
    for path,sha in report['source_sha256'].items():assert p.digest(Path(path))==sha
for phase in ('analysis','analysis2'):
    closed=json.loads((raw/(phase+'_closure.json')).read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
"""
code=code.replace("commands=[('collection1.log'",guard+"\ncommands=[('collection1.log'")
ast.parse(code)
exec(compile(code,str(source),'exec'))
