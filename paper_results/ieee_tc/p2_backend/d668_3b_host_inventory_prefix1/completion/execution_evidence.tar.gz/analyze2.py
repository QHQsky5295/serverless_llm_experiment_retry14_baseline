"""Resume only core analysis; preserve the completed native audit and failed attempt."""
import hashlib
import ijson
import json
import sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
run=RAW/'3b_full_w0_prefix1'
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d668_3b_host_inventory_prefix1/completion'
sys.path.insert(0,str(ROOT))
from scripts.ieee_tc.plot_d290_diagnostic import audit_run
from scripts import ieee_tc_preflight as p
audit=json.loads((OUT/'native_audit.json').read_text())
assert audit['passed'] and audit['protocol_bound_count']==1000
for row in audit['refs']:assert p.digest(Path(row['path']))==row['sha256']
assert not (OUT/'core_timing').exists() and not (OUT/'completion.json').exists()
source,=run.glob('experiment_results*.json')
stats,evidence,requests=audit_run(source)
assert len(requests)==1000 and stats['completed']==1000
launch=json.loads((run/'launch.json').read_text())
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
slo_path=ROOT/'paper_results/ieee_tc/protocols/20261017_3b_slo_d648_frozen.json'
assert p.digest(slo_path)=='d15123570c4a8d830515ca942d1db553c6717ffc1a40ade5c1546d35e2bed9d8'
slo=json.loads(slo_path.read_text())
with (run/'launch.launch/physical_deployment/main_outcome.json').open('rb') as handle:
    activations=next(ijson.items(handle,'mechanism_events._ieee_activations',use_float=True))
namespace=dict(requests=requests,launch=launch,slo=slo,activations=activations)
def save(name,value):
    with (OUT/name).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
code=(RAW/'analyze.py').read_text()
code=code[code.index('from scripts.ieee_tc.analyze_d297_full import'):]
old="group_id=g['group_id'],"
assert code.count(old)==1
# The shared interval selector uses interval bounds, not a group name. Preserve
# exact frozen bounds/thresholds, without adding a default or fabricated field.
code=code.replace(old,'')
code=code.replace("refs=[Path(__file__),RAW/'collect_closure.py',RAW/'postrelease.py',",
    "refs=[Path(__file__),RAW/'analyze.py',RAW/'collect_closure.py',RAW/'postrelease.py',RAW/'postrelease2.py',")
exec(compile(code,str(RAW/'analyze.py'),'exec'))
