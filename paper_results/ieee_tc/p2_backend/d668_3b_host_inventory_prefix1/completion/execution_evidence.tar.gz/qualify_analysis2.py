"""Run only the two import-dependent checks in the existing ijson environment."""
import ast
from pathlib import Path
raw=Path(__file__).resolve().parent
source=raw/'qualify_analysis.py'
tree=ast.parse(source.read_text())
assert tree.body[-1].value.func.id=='exec'
namespace={'__file__':str(__file__),'__name__':'__main__'}
exec(compile(ast.Module(body=tree.body[:-1],type_ignores=[]),str(source),'exec'),namespace)
code=namespace['code']
code=code.replace("('qualification', 'qualification2', 'analysis')","('analysis2',)")
code=code.replace("if phase == 'analysis':","if phase == 'analysis2':")
start=code.index("    tests = ['tests.test_ieee_tc_core_timing_analysis'")
end=code.index('    assert sys.executable',start)
code=code[:start]+"    tests = ['tests.test_ieee_tc_control_timeline.RetainedStagePartitionTest.test_campaign_entry_imports_existing_statistics', 'tests.test_ieee_tc_control_timeline.RetainedStagePartitionTest.test_sealed_candidate_preserves_prior_rows_and_rejects_mismatch']\n"+code[end:]
code=code.replace('/home/qhq/anaconda3/envs/sllm_vllm0102_newserverless_20260518/bin/python',
                  '/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python')
ast.parse(code)
exec(compile(code,str(source),'exec'))
