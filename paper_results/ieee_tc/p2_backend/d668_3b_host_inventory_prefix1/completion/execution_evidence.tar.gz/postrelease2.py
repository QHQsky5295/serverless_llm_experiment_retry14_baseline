"""Resume just the uncompleted analysis after remote collection has closed."""
import ast
from pathlib import Path
source=Path(__file__).resolve().parent/'postrelease.py'
tree=ast.parse(source.read_text())
assert tree.body[-1].value.func.id=='exec'
namespace={'__file__':str(__file__),'__name__':'__main__'}
exec(compile(ast.Module(body=tree.body[:-1],type_ignores=[]),str(source),'exec'),namespace)
code=namespace['code']
code=code.replace('postrelease_identity.json','postrelease2_identity.json')
code=code.replace('postrelease_receipt.json','postrelease2_receipt.json')
old="commands=[('collection1.log',[sys.executable,str(raw/'collect_closure.py')]),\n          ('analysis1.log',[sys.executable,str(raw/'analyze.py')])]"
assert code.count(old)==1
new="""closed=json.loads((raw/'postrelease_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
collected=json.loads((raw/'collection_receipt.json').read_text())
assert p.digest(Path(collected['source_path']))==collected['source_sha256']
commands=[('core_analysis2.log',[sys.executable,str(raw/'analyze2.py')])]"""
code=code.replace(old,new)
ast.parse(code)
exec(compile(code,str(source),'exec'))
