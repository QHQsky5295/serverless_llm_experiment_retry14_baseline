"""Reuse sealed D666 retained-data diagnosis for D665 versus D672.

No inference, strategy change, repeated performance key, or new workload.
Only campaign identities, sealed hashes and observed-count assertions change.
"""
import ast
import hashlib
from pathlib import Path
import sys

RAW = Path(__file__).resolve().parent
BASE = RAW.parent
source = BASE/'d666_20261018/diagnose.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '42ebffc09e753da33f71ca256c8548e153ba724f069bb7465184ee5169f7b57f'
code = data.decode()
# Expand only D666's checked analyzer construction, not its data execution.
head = code[:code.index("if sys.argv[1:] == ['--check-only']:")]
env = {'__file__': __file__, '__name__': '__d673_analyzer_expansion__'}
exec(compile(head, str(source), 'exec'), env)
projection = env['projection_code']
receipts = env['receipt_code']
tail = code[code.index("ns1 = {'__file__'"):]

def once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)

for old, new in (
    ('d665', 'd672'), ('D665', 'D672'), ('d666', 'd673'),
    ('2495a30a67e16936c79c24601ecee62d6c77f580fed15932ab668e40cfb6225d',
     'df21f561a8122fce11fe76b44562ead36dd09eab3e8a503e5e1201a0130523b6'),
    ('3550', '3647'),
):
    assert old in projection, old
    projection = projection.replace(old, new)
for old, new in (
    ('d665', 'd672'), ('D665', 'D672'), ('d666', 'd673'), ('3550', '3647'),
    ('fe3a27ae3bd4fb6181fbbd18e00675a9c20985b6653025e35bebd0684ea3905b',
     '001f39cd1705de16ed345b33c748d0e3bc7d3e4a76a7ba373d650696b5857c5a'),
):
    assert old in receipts, old
    receipts = receipts.replace(old, new)

# The old D665 projections/receipt rows were already qualified by D666.
# Do not reparse its large (now losslessly compressed) main outcome.
for old, new in (
    ("BASE/'d661_20261018/d660_projection.json'", "BASE/'d666_20261018/d665_projection.json'"),
    ("BASE/'d662_20261018/request_receipts2.json'", "BASE/'d666_20261018/request_receipts2.json'"),
    ("BASE/'d661_20261018/diagnosis.json'", "BASE/'d666_20261018/projection_diagnosis.json'"),
    ('71e02205b245c9bb0e3996e18a702cf2790e42a215e6e72b72ac87ed96092c87',
     'b642a0da3830e376fd0439a336309ad42f14b46d8353dcea82864b84e38e7ede'),
    ('c82a424bb86d6eb6d4a47d62eca7b986ecc7b66ed321ca38065da1d10cce5c91',
     'ffa699fc4987640740045313d2cb06b794580748ccd6c098ffcef83ed96e6c62'),
    ('518a1f265755445933db2277fd36b5b472a6a2c0767e99c3f47d59bb7db87d88',
     '2d3c7c72cf570e5656e09ad378ac654fcc9a935c8adfbac1086f6dec11909842'),
    ("== -25", "== 97"),
    ('len(host_ids)==1392', 'len(host_ids)==1396'),
    ("optimized_host['chains_valid']==1392", "optimized_host['chains_valid']==1396"),
):
    tail = once(tail, old, new)
# Replace current-run references without changing the preceding old-data paths.
tail = tail.replace("ns1['projections']['D665']", "ns1['projections']['D672']")
tail = tail.replace('p2_backend/d665_3b_full_w0/', 'p2_backend/d672_3b_full_w0/')
tail = tail.replace("read(old_diagnosis)['runs']['D660']", "read(old_diagnosis)['runs']['D665']")
tail = tail.replace("ns1['runs']['D665']", "ns1['runs']['D672']")
tail = tail.replace("runs={'D660':", "runs={'D665':").replace("'D665':{k:v for k,v in new_run.items()", "'D672':{k:v for k,v in new_run.items()")
tail = tail.replace("RAW/'d665_projection.json'", "RAW/'d672_projection.json'")
tail = tail.replace('d666_host_transaction_and_joint_slo_comparison_v1', 'd673_independent_host_copy_and_residual_slo_v1')
for expanded in (projection, receipts, tail):
    ast.parse(expanded)
env['projection_code'], env['receipt_code'] = projection, receipts
env['SOURCES'][source] = hashlib.sha256(data).hexdigest()
if sys.argv[1:] == ['--check-only']:
    print('Sealed D666 expansions and D665/D672 identities checked; no data analyzed.')
elif not sys.argv[1:]:
    exec(compile(tail, str(source), 'exec'), env)
else:
    raise SystemExit('expected no arguments or --check-only')
