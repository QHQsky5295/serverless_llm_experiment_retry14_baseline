"""Reuse D678 explicit-path, checked publication for a new offline analysis."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path(__file__).resolve().parent.parent/'d678_20261018/publish.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='cc4235cdb6ff2dc030ac09e5469b7e0eb0a0b741331a8722d95c53ff38fda4f7'
tree=ast.parse(data)
assert isinstance(tree.body[-1],ast.If)
tree.body.pop()
env={'__file__':__file__,'__name__':'__d679_publication_expansion__'}
exec(compile(tree,str(source),'exec'),env)
code=env['code']
def replace(old,new):
    global code
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new)
replace('d678_proactive_host_outcome_diagnosis','d679_control_measurement_scope')
replace('d1922c176f53d2ebdee70462c236377229495256','5f18f6727accd93ec201c8f82066b10237135e95')
replace("assert sum(x['n'] for x in diagnosis['matched_transitions'].values())==8000//2",
        "assert all(run['requests']['all']['n']==4000 for run in diagnosis['runs'].values())")
replace("assert diagnosis['runs']['D677']['all']['joint']==3628",
        "assert diagnosis['runs']['D677']['requests']['all']['joint']==3628")
replace("assert diagnosis['runs']['D672']['all']['joint']==3647",
        "assert diagnosis['runs']['D672']['requests']['all']['joint']==3647")
replace('D678_3B_PROACTIVE_HOST_OUTCOME_DIAGNOSIS.md','D679_CONTROL_MEASUREMENT_SCOPE_AUDIT.md')
replace("RAW.parent/'d677_20261018/publication_receipt.json'","RAW.parent/'d678_20261018/publication_receipt.json'")
replace("RAW.parent/'d677_20261018/publication_closure.json'","RAW.parent/'d678_20261018/publication_closure.json'")
replace("RAW.parent/'d673_20261018/publish.py']", "RAW.parent/'d673_20261018/publish.py', RAW.parent/'d678_20261018/publish.py']")
replace('d678_reused_3b_proactive_host_outcome_v1','d679_control_measurement_scope_necessary_conditions_v1')
replace('tc: retain 3B proactive candidate regression and matched scaling evidence (D678)',
        'tc: audit control measurement scope and observed scale-in blockers (D679)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D679 explicit-path publication expansion checked; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no args or --check-only')
