"""Reuse D673 explicit-path publication; include D677 late closure evidence."""
import ast
import hashlib
from pathlib import Path
import sys
source = Path(__file__).resolve().parent.parent/'d673_20261018/publish.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '18d872becdaf7fe1ba82fbce006f84d8cf7d44e4d38b4cef7b255b6de0ee89d2'
tree=ast.parse(data)
assert isinstance(tree.body[-1],ast.If)
tree.body.pop()
env={'__file__':__file__,'__name__':'__d678_publication_expansion__'}
exec(compile(tree,str(source),'exec'),env)
code=env['code']
def replace(old,new):
    global code
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new)
replace('d673_residual_slo_scaling_path','d678_proactive_host_outcome_diagnosis')
replace('9f1a13c4c2e8585837e13ca06da70eea25b3407d','d1922c176f53d2ebdee70462c236377229495256')
replace("assert diagnosis['runs']['D672']['all']['joint']==3647", "assert diagnosis['runs']['D677']['all']['joint']==3628")
replace("assert diagnosis['runs']['D665']['all']['joint']==3550", "assert diagnosis['runs']['D672']['all']['joint']==3647")
replace('D673_3B_RESIDUAL_SLO_AND_SCALING_PATH.md','D678_3B_PROACTIVE_HOST_OUTCOME_DIAGNOSIS.md')
replace("RAW.parent/'d672_20261018/publication_receipt.json'", "RAW.parent/'d677_20261018/publication_receipt.json'")
replace("RAW.parent/'d672_20261018/publication_closure.json'", "RAW.parent/'d677_20261018/publication_closure.json'")
replace("RAW.parent/'d660_20261018/close.py']", "RAW.parent/'d660_20261018/close.py', RAW.parent/'d673_20261018/diagnose.py', RAW.parent/'d673_20261018/publish.py']")
replace('d673_reused_3b_residual_slo_scaling_path_v1','d678_reused_3b_proactive_host_outcome_v1')
replace('tc: distinguish 3B residual SLO gaps from early scale-out resource savings (D673)',
        'tc: retain 3B proactive candidate regression and matched scaling evidence (D678)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D678 explicit-path publication expansion checked; no data or writes.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
