"""Bounded isolated wheel qualification, leaving the frozen runtime unchanged."""
from pathlib import Path
import hashlib

driver = Path(__file__).resolve().parent.parent/'d605_20261017/compare_inventory.py'
assert hashlib.sha256(driver.read_bytes()).hexdigest() == 'eba30738e09478af3d885b1a686296431b0b03536f79ef361859665064829a9b'
header = driver.read_text().split('old_commit = ', 1)[0]
start, end = header.index('closed = '), header.index('assert os.statvfs')
header = header[:start] + header[end:]
header = header.replace('component_identity.json', 'install_identity.json')
exec(compile(header, str(driver), 'exec'))
import importlib.util
assert importlib.util.find_spec('isal') is None
gate = p.preflight([ROOT], 32*1024*1024)
save('install_resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
target = RAW/'dependency'
assert not target.exists()
command = [sys.executable, '-m', 'pip', 'install', '--no-input', '--no-deps',
    '--no-cache-dir', '--only-binary=:all:', '--index-url', 'https://pypi.org/simple',
    '--target', str(target), '--report', str(RAW/'pip_report.json'), 'isal==1.8.0']
with (RAW/'install.log').open('x') as log:
    completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
assert completed.returncode == 0
report = json.loads((RAW/'pip_report.json').read_text())
assert len(report['install']) == 1 and report['install'][0]['metadata']['version'] == '1.8.0'
assert importlib.util.find_spec('isal') is None
sys.path.insert(0, str(target))
from isal import igzip
assert Path(igzip.__file__).is_relative_to(target)
assert p.verify_seal(seal)['pass']
resources = {name:(group/name).read_text().strip() for name in
    ('memory.peak','memory.events','memory.swap.current')}
assert resources['memory.swap.current']=='0'
assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
save('installation.json', dict(passed=True, target=str(target), version='1.8.0',
    existing_environment_changed=False, scope=identity, resources=resources,
    files=[dict(path=str(path),bytes=path.stat().st_size,sha256=p.digest(path))
        for path in sorted(target.rglob('*')) if path.is_file()],
    source=report['install'][0]['download_info']))
print(json.dumps(dict(passed=True,version='1.8.0',resources=resources)))
