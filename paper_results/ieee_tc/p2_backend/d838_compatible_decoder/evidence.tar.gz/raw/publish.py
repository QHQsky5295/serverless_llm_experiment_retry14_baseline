"""Reuse the D837 closed-component evidence publication."""
from pathlib import Path
import hashlib

template = Path(__file__).resolve().parent.parent/'d837_20261025/publish.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == '773953a12d7bc0a70040131f3363fe7036af02e39bff9f3ae55cb0b7377b4846'
source = template.read_text()
for old, new in (
    ('d837_gzip_extraction', 'd838_compatible_decoder'),
    ('99d344e4b78eb61fada70d25b2f6537abec177a1', '6b0c771557be0675f1b60b4ee13b8d26a78e8f63'),
    ('D837_GZIP_EXTRACTION_PROFILE_20261025.md', 'D838_COMPATIBLE_GZIP_DECODER_20261025.md'),
    ("['r:gz','r|gz','r|gz','r:gz','r:gz','r|gz']", "['stdlib','isal_1.8.0','isal_1.8.0','stdlib','stdlib','isal_1.8.0']"),
    ("files = list(sorted(RAW.glob('*.py'))) + list(sorted(RAW.glob('*.json')))",
     "files = list(sorted(RAW.glob('*.py'))) + list(sorted(RAW.glob('*.json'))) + [RAW/'install.log']\n"
     "dependencies += [RAW.parent/'d837_20261025/component.py', RAW.parent/'d837_20261025/publish.py']\n"
     "installation = read(RAW/'installation.json')\n"
     "assert installation['passed'] and not installation['existing_environment_changed']\n"
     "for row in installation['files']: assert p.digest(Path(row['path'])) == row['sha256']\n"
     "install_scope = read(RAW/'install_identity.json')\n"
     "assert not Path(install_scope['path']).exists() and not p.scope_still_owned(install_scope)\n"
     "assert len(component['decoder_checks']) == 6 and all(row['rejected'] for row in component['decoder_checks'])"),
    ('Reject direct tar stream mode for this object; retain all six measurements; no online performance claim.',
     'Proceed to minimal decoder integration; no online performance or SLO claim from the component.'),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'), globals())
