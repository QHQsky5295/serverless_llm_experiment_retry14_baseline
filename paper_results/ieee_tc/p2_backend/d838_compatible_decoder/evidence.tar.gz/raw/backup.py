"""Reuse D837 explicit-path checkpoint for component-only D838 evidence."""
from pathlib import Path
import hashlib

template = Path(__file__).resolve().parent.parent/'d837_20261025/backup.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == '991f200121fe95d8bcc1ac01f86b1146752d7a5aa394e177fa91a787569e3478'
source = template.read_text()
for old, new in (
    ('d837_gzip_extraction', 'd838_compatible_decoder'),
    ('99d344e4b78eb61fada70d25b2f6537abec177a1', '6b0c771557be0675f1b60b4ee13b8d26a78e8f63'),
    ('D837_GZIP_EXTRACTION_PROFILE_20261025.md', 'D838_COMPATIBLE_GZIP_DECODER_20261025.md'),
    ('backup/d837-gzip-extraction-20261025', 'backup/d838-compatible-decoder-20261025'),
    ('tc: retain gzip extraction evidence and reject direct stream mode (D837)',
     'tc: qualify compatible single-thread gzip decoder component (D838)'),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'), globals())
