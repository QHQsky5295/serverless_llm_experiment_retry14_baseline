"""D837 component with one fixed single-threaded compatible gzip decoder."""
from pathlib import Path
import hashlib

template = Path(__file__).resolve().parent.parent/'d837_20261025/component.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == 'dd9f7beb5e446318eb204e281ec3a7d4d9b16ba6dfd9c6acb0c4f20eb9b04f83'
source = template.read_text()
marker = 'from faaslora.storage import http_artifact_store as http'
source = source.replace(marker, marker + '''
import gzip
from contextlib import contextmanager
installation = json.loads((RAW/'installation.json').read_text())
assert installation['passed'] and not installation['existing_environment_changed']
for row in installation['files']:
    assert p.digest(Path(row['path'])) == row['sha256']
sys.path.insert(0, installation['target'])
from isal import igzip
assert Path(igzip.__file__).is_relative_to(Path(installation['target']))

@contextmanager
def open_archive(path, mode):
    if mode == 'stdlib':
        with tarfile.open(path, 'r:gz') as tar:
            yield tar
    elif mode == 'isal_1.8.0':
        with igzip.open(path, 'rb') as decoded:
            with tarfile.open(fileobj=decoded, mode='r:') as tar:
                yield tar
    else:
        raise ValueError(mode)
''')
marker = 'rows=[]'
source = source.replace(marker, '''decoder_checks=[]
for name, decoder in [('stdlib', gzip), ('isal_1.8.0', igzip)]:
    for fault in ('crc', 'size', 'truncated'):
        corrupt = bytearray(payload)
        if fault == 'truncated':
            corrupt = corrupt[:-10]
        else:
            corrupt[-8 if fault == 'crc' else -4] ^= 1
        try:
            with decoder.open(io.BytesIO(corrupt), 'rb') as decoded:
                while decoded.read(1024*1024):
                    pass
        except (OSError, EOFError) as error:
            decoder_checks.append(dict(decoder=name, fault=fault, rejected=True,
                exception_type=type(error).__name__))
        else:
            raise AssertionError((name, fault, 'corrupt gzip accepted'))
save('decoder_checks.json', decoder_checks)
rows=[]''')
for old, new in (
    ("('r:gz','r|gz','r|gz','r:gz','r:gz','r|gz')", "('stdlib','isal_1.8.0','isal_1.8.0','stdlib','stdlib','isal_1.8.0')"),
    ('with tarfile.open(archive,mode) as tar:', 'with open_archive(archive,mode) as tar:'),
    ('tc-d837-extract-', 'tc-d838-extract-'),
    ('d837_existing_gzip_extraction_component_v1', 'd838_compatible_gzip_decoder_component_v1'),
    ("input_sha256=p.digest(RAW/'input.json'),", "input_sha256=p.digest(RAW/'input.json'),decoder_checks=decoder_checks,dependency=installation['source'],"),
    ('Streaming tar mode is not a concurrent receive/decompress pipeline. No projected SLO.',
     'Single-thread decoder component only; no online service, no projected SLO.'),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'), globals())
