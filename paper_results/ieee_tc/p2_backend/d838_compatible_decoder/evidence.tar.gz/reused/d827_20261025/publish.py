"""D825 packaging method, restricted to the closed D827 component evidence."""
import hashlib
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT / 'paper_results/ieee_tc/p2_backend/d827_workspace_retirement'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
def read(path):
    return json.loads(path.read_text())
def ref(path):
    return dict(path=str(path), sha256=p.digest(path), bytes=path.stat().st_size)

identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
save(RAW/'publication_identity.json', identity)
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert not OUT.exists()
component = read(RAW/'component_result.json')
assert component['passed'] and component['new_gpu_replays'] == 0
assert component['production_changed'] is False and len(component['rows']) == 6
assert [(row['with_metadata'], row['repeat']) for row in component['rows']] == [
    (mode, repeat) for mode in (False, True) for repeat in range(3)]
for path, sha in component['production_sources'].items():
    assert p.digest(Path(path)) == sha
for path, evidence in component['source_files'].items():
    assert p.digest(Path(path)) == evidence['sha256']
for row in component['rows']:
    assert row['workspace_removed'] and row['archive_inode_reservation_retired']
    assert row['published_destination_preserved']
    assert len(row['nested_phases']['inventory']) == len(row['nested_phases']['rmtree']) == 1
assert component['metadata_unique_files'] == 999 and component['metadata_paths'] == 1003
assert component['resources']['memory.swap.current'] == '0'
assert all(int(line.split()[1]) == 0 for line in component['resources']['memory.events'].splitlines())
old = read(RAW/'component_identity.json')
assert not Path(old['path']).exists() and not p.scope_still_owned(old)
properties = subprocess.check_output(['systemctl', '--user', 'show', old['unit'],
    '-p', 'ActiveState', '-p', 'ControlGroup', '-p', 'InvocationID'], text=True)
assert 'ActiveState=inactive' in properties and 'ControlGroup=\n' in properties
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
protected_path = RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json'
protected = p.verify_seal(protected_path)
assert protected['pass'] and protected['entry_count'] == 147
user = read(ROOT/'paper_results/ieee_tc/p2_backend/d824_current_ingress_pending/closure.json')['user_protected']
assert len(user) == 3
for path, sha in user.items():
    assert p.digest(Path(path)) == sha
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == \
    'de048c01f1c6310983b3ed896ad44b08e55c9688'
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
dependencies = [RAW.parent/name/file for name, file in (
    ('d605_20261017', 'compare_inventory.py'), ('d627_20261017', 'component.py'),
    ('d825_20261025', 'component.py'), ('d825_20261025', 'publish.py'),
    ('d824_20261025', 'backup.py'))]
files = list(sorted(RAW.glob('*.py'))) + [RAW/name for name in (
    'component.log', 'component_identity.json', 'component_resource_gate.json',
    'component_result.json', 'publication_identity.json')]
for path in files + dependencies:
    if path.suffix == '.py':
        compile(path.read_text(), str(path), 'exec')
OUT.mkdir(parents=True)
save(OUT/'component.json', component)
members = [(path, 'raw/'+path.name) for path in files] + [
    (path, 'reused/'+path.parent.name+'/'+path.name) for path in dependencies]
with tarfile.open(OUT/'evidence.tar.gz', 'x:gz') as archive:
    for path, name in members:
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(OUT/'evidence.tar.gz', 'r:gz') as archive:
    for path, name in members:
        digest = hashlib.sha256()
        with archive.extractfile(name) as handle:
            while chunk := handle.read(1024*1024):
                digest.update(chunk)
        assert digest.hexdigest() == p.digest(path)
closure = dict(passed=True, user_protected=user, protected_union_files=147,
    protected_manifest=ref(protected_path), component_scope=old, component_properties=properties,
    component_path_removed=True, gpu_idle=True, new_gpu_replays=0,
    production_candidate=False, production_changed=False, formal_performance=False,
    end_to_end_performance_accepted=False, n_correct=None, ranking_eligible=False,
    decision='No standalone deletion/asynchronous cleanup candidate; retain all six calls including the long inventory point.',
    plan=ref(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')),
    doc=ref(ROOT/'docs/ieee_tc/D827_WORKSPACE_RETIREMENT_PROFILE_20261025.md'),
    production_sources=component['production_sources'], source_files=component['source_files'],
    scope=identity, resources={name: (group/name).read_text().strip() for name in
        ('memory.peak', 'memory.events', 'memory.swap.current')},
    disk_free_bytes=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize,
    baseline_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'],
        cwd='/home/qhq/serverless_llm_baselines', text=True).strip())
save(OUT/'closure.json', closure)
save(OUT/'manifest.json', dict(archive_members=[dict(member=name, **ref(path)) for path, name in members],
    files=[ref(path) for path in sorted(OUT.iterdir()) if path.is_file()]))
print(json.dumps(dict(passed=True, files=len(members), protected=147, new_gpu_replays=0,
    disk_free_bytes=closure['disk_free_bytes'])))
