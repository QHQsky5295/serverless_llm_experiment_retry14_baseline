"""Reuse D827's closed-component packaging with D837's extraction assertions."""
from pathlib import Path
import hashlib

template = Path(__file__).resolve().parent.parent/'d827_20261025/publish.py'
source = template.read_text()
start = source.index("assert component['production_changed']")
end = source.index("assert component['resources']", start)
source = source[:start] + '''inputs = read(RAW/'input.json')
assert p.digest(RAW/'input.json') == component['input_sha256']
assert len(component['rows']) == 6 and component['production_candidate'] is False
assert [row['mode'] for row in component['rows']] == ['r:gz','r|gz','r|gz','r:gz','r:gz','r|gz']
for path, sha in component['production_sources'].items():
    assert p.digest(Path(path)) == sha
for path, row in inputs['source_files'].items():
    assert p.digest(Path(path)) == row['sha256']
for index, row in enumerate(component['rows']):
    assert read(RAW/f'call_{index}.json') == row
    assert row['content_sha256'] == '07f5e8575cf08fc5b0e78fde16b9c239b6c6406f3a1ca89c013d8aa5e481bba7'
assert component['archive_bytes'] == 2325514 and component['payload_bytes'] == 42695980
''' + source[end:]
start = source.index('dependencies = ')
end = source.index('for path in files + dependencies:', start)
source = source[:start] + '''dependencies = [RAW.parent/'d605_20261017/compare_inventory.py',
    RAW.parent/'d827_20261025/publish.py', RAW.parent/'d824_20261025/backup.py']
files = list(sorted(RAW.glob('*.py'))) + list(sorted(RAW.glob('*.json')))
''' + source[end:]
for old, new in (
    ('d827_workspace_retirement', 'd837_gzip_extraction'),
    ('de048c01f1c6310983b3ed896ad44b08e55c9688', '99d344e4b78eb61fada70d25b2f6537abec177a1'),
    ('D827_WORKSPACE_RETIREMENT_PROFILE_20261025.md', 'D837_GZIP_EXTRACTION_PROFILE_20261025.md'),
    ("source_files=component['source_files']", "source_files=inputs['source_files']"),
    ('No standalone deletion/asynchronous cleanup candidate; retain all six calls including the long inventory point.',
     'Reject direct tar stream mode for this object; retain all six measurements; no online performance claim.'),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'), globals())
