"""D605/D825 bounded component on one exact, already-published 3B gzip object."""
from pathlib import Path
import hashlib

driver = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d605_20261017/compare_inventory.py')
assert hashlib.sha256(driver.read_bytes()).hexdigest() == 'eba30738e09478af3d885b1a686296431b0b03536f79ef361859665064829a9b'
header = driver.read_text().split('old_commit = ', 1)[0]
start, end = header.index('closed = '), header.index('assert os.statvfs')
header = header[:start] + header[end:]
exec(compile(header, str(driver), 'exec'))
import tempfile
import tarfile
from faaslora.storage import http_artifact_store as http

gate = p.preflight([ROOT], 64*1024*1024)
save('component_resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
paths = [ROOT/name for name in ('faaslora/storage/http_artifact_store.py',
    'faaslora/memory/residency_manager.py', 'scripts/run_all_experiments.py')]
production = {str(path):p.digest(path) for path in paths}
index = ROOT/'paper_results/ieee_tc/inputs/20260927_3b_remote_content_index.json'
client = http.HttpArtifactStoreClient(endpoint='http://127.0.0.1:1')
client.configure_content_manifest(json.loads(index.read_text()))
aid = 'finance_lora'
expected = client.preparation_manifests([aid])[aid]
remote = '/home/lab14/primelora_remote/tc/d78_20260927/published/3b/'
ssh = ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','primelora-artifact-174']
manifest_bytes = subprocess.check_output(ssh+['cat '+remote+'delivery_manifest.json'],timeout=30)
assert hashlib.sha256(manifest_bytes).hexdigest() == '9fbd57b6216541d90f01e3efb7e63e849fec011c51a278259e9a54d8546d8173'
manifest = json.loads(manifest_bytes)
assert manifest['complete'] and manifest['content_manifest_sha256']==client.content_manifest_sha256
entry = next(row for row in manifest['artifacts'] if row['id']==aid)
assert entry['archive_bytes'] < 16*1024*1024
payload = subprocess.check_output(ssh+['cat '+remote+entry['archive']],timeout=30)
assert len(payload)==entry['archive_bytes'] and hashlib.sha256(payload).hexdigest()==entry['archive_sha256']
source = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama32_3b_a500_v1_modelscope')/aid
source_refs = {str(source/name):dict(bytes=size, sha256=digest) for name,(size,digest) in expected.items()}
for name,row in source_refs.items():
    assert Path(name).stat().st_size==row['bytes'] and p.digest(Path(name))==row['sha256']
payload_bytes=sum(size for size,_ in expected.values())
save('input.json',dict(artifact_id=aid,delivery=entry,delivery_manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
    content_index=dict(path=str(index),sha256=p.digest(index)),content_manifest_sha256=client.content_manifest_sha256,
    source_files=source_refs,production_sources=production,remote_service_started=False,
    archive_read='existing immutable object once over SSH, excluded from component timing'))

rows=[]
for ordinal,mode in enumerate(('r:gz','r|gz','r|gz','r:gz','r:gz','r|gz')):
    with tempfile.TemporaryDirectory(prefix='tc-d837-extract-') as directory:
        nvme=Path(directory)/'nvme';nvme.mkdir()
        owner=module.LocalSourceReferences({'nvme':nvme})
        target=nvme/aid
        phases={}
        with owner.materializing(target,budgeted=True) as transfer:
            with owner.transfer_workspace(transfer) as staging:
                owner.prepare_transfer(transfer,staging,len(payload),expected,limit_bytes=512*1024*1024)
                archive=staging.parent/'artifact.tar.gz'
                with archive.open('r+b') as stream:stream.write(payload)
                assert not owner.source_snapshot(aid)['sources'] and not target.exists()
                profiler=cProfile.Profile()
                begin,cpu_begin=time.perf_counter(),time.thread_time()
                profiler.enable()
                with tarfile.open(archive,mode) as tar:
                    verified=http._extract_verified(tar,staging,expected,lambda:None,
                        preallocated=True,verify_content=False)
                profiler.disable()
                phases['extract']=dict(wall_ms=1000*(time.perf_counter()-begin),cpu_ms=1000*(time.thread_time()-cpu_begin))
                assert not target.exists()
                begin,cpu_begin=time.perf_counter(),time.thread_time()
                receipt=owner.publish_transfer(transfer,staging,target,http.publish_directory,verified_files=verified)
                phases['publish']=dict(wall_ms=1000*(time.perf_counter()-begin),cpu_ms=1000*(time.thread_time()-cpu_begin))
                assert receipt['content_verified'] and receipt['adapter_id']==aid
                stats=pstats.Stats(profiler)
                functions=[dict(file=key[0],line=key[1],function=key[2],primitive_calls=value[0],
                    total_calls=value[1],self_ms=value[2]*1000,cumulative_ms=value[3]*1000)
                    for key,value in stats.stats.items()]
                row=dict(index=ordinal,mode=mode,phases=phases,content_sha256=receipt['content_sha256'],
                    total_wall_ms=sum(v['wall_ms'] for v in phases.values()),
                    functions=sorted(functions,key=lambda x:-x['self_ms']))
                rows.append(row)
                save(f'call_{ordinal}.json',row)
        assert not owner.materializations and not owner._transfer_workspaces
        assert owner.source_snapshot(aid)['sources'][0]['content_verified']
for name,row in source_refs.items():assert p.digest(Path(name))==row['sha256']
for path,sha in production.items():assert p.digest(Path(path))==sha
protected=p.verify_seal(seal);assert protected['pass'] and protected['entry_count']==147
import torch
assert not torch.cuda.is_initialized()
resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}
assert resources['memory.swap.current']=='0' and all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
result=dict(kind='d837_existing_gzip_extraction_component_v1',passed=True,rows=rows,
    input_sha256=p.digest(RAW/'input.json'),production_sources=production,resources=resources,
    protected=protected,scope=identity,payload_bytes=payload_bytes,archive_bytes=len(payload),
    new_gpu_replays=0,production_candidate=False,formal_performance=False,n_correct=None,ranking_eligible=False,
    limitations=['One existing object, sequential temporary copies; no HTTP or online competition.',
        'cProfile instruments both modes. Component times are not uninstrumented request latency.',
        'Streaming tar mode is not a concurrent receive/decompress pipeline. No projected SLO.'])
save('component_result.json',result)
print(json.dumps(dict(passed=True,archive_bytes=len(payload),payload_bytes=payload_bytes,
    rows=[{k:v for k,v in row.items() if k!='functions'} for row in rows],resources=resources),indent=2))
