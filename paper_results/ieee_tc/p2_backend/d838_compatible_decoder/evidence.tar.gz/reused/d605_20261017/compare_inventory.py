"""D457 AST comparison method: one fresh traversal prototype, no serving edit."""
import ast
from collections import Counter
import contextlib
import cProfile
import hashlib
import io
import json
import os
from pathlib import Path
import pstats
import statistics
import subprocess
import sys
import time
from unittest.mock import patch

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.memory import residency_manager as module
from faaslora.storage.http_artifact_store import FrozenPreparationDescriptions
from tests.test_ieee_tc_file_observation import FreshFileObservation, without_capture_times

def save(name, value):
    with (RAW/name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save('component_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
closed = json.loads((RAW.parent.parent/'storage_maintenance/d604_20261017/storage_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
assert os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize >= 150*p.GIB
seal = RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json'
assert p.verify_seal(seal)['pass']
old_commit = '161fa069e004ed54622dbc5922f72ee56f624f02'
relative = 'faaslora/memory/residency_manager.py'
old_source = subprocess.check_output(['git','show',old_commit+':'+relative],cwd=ROOT)
assert hashlib.sha256(old_source).hexdigest() == p.digest(ROOT/relative)
node = next(n for n in ast.parse(old_source).body if isinstance(n,ast.FunctionDef) and n.name=='_local_file_inventory')
parent_text = ast.get_source_segment(old_source.decode(),node)
candidate_text = parent_text
def replace(old, new, count=1):
    global candidate_text
    assert candidate_text.count(old) == count, old
    candidate_text = candidate_text.replace(old,new)
replace('root = Path(root)', 'root = str(Path(root))')
replace('info = path.lstat()', 'info = os.stat(path, follow_symlinks=False)', count=2)
replace('captured[path] = info', 'captured[Path(path)] = info')
replace('pending.extend(sorted(path.iterdir(), reverse=True))',
        "with os.scandir(path) as entries:\n"
        "                    names = sorted((entry.name for entry in entries), reverse=True)\n"
        "                pending.extend(os.path.join(path, name) if path != '.' else name for name in names)")
functions = {}
for variant, source in [('parent',parent_text),('prototype',candidate_text)]:
    namespace = dict(module.__dict__)
    exec(compile(source,'<d605-'+variant+'>','exec'),namespace)
    functions[variant] = namespace['_local_file_inventory']

rows, profiles, tests = [], [], []
case = FreshFileObservation()
try:
    with contextlib.redirect_stdout(io.StringIO()):
        fixture, owner, manifests, limits = case.make()
    manifests.update({f'absent-{i}':dict(manifests['a']) for i in range(496)})
    manifests = FrozenPreparationDescriptions(manifests)
    owner.preparation_snapshot(manifests=manifests,limits=limits)
    actual = {}
    for variant,function in functions.items():
        with patch.object(module,'_local_file_inventory',function):
            actual[variant] = without_capture_times(owner.preparation_snapshot(manifests=manifests,limits=limits))
    assert actual['parent'] == actual['prototype']
    tests.append('existing_fixture_preparation_snapshot_exact')
    file = next(pth for pth in (fixture.nvme/'a').rglob('*') if pth.is_file())
    original_stat = os.stat
    # Both Path.lstat and prototype os.stat reach this same fresh syscall boundary.
    for variant,function in functions.items():
        count = [0]
        def mutate_second(path,*args,**kwargs):
            if Path(path)==file:
                count[0] += 1
                if count[0]==2:
                    info = original_stat(path,*args,**kwargs)
                    os.utime(path,ns=(info.st_atime_ns,info.st_mtime_ns+1_000_000_000))
            return original_stat(path,*args,**kwargs)
        captured = {}
        with patch.object(os,'stat',mutate_second):
            try:
                function({'nvme':fixture.nvme},_observed_stats=captured)
            except RuntimeError as error:
                assert 'changed while collecting footprint' in str(error)
            else:
                raise AssertionError('second-stat mutation was accepted')
        assert captured=={} and count[0]==2
        tests.append(variant+'_second_stat_mutation_rejected_without_export')
    before = functions['prototype']({'nvme':fixture.nvme})
    info=file.stat();os.utime(file,ns=(info.st_atime_ns,info.st_mtime_ns+1_000_000_000))
    captured={};functions['prototype']({'nvme':fixture.nvme},_observed_stats=captured)
    assert captured[file].st_mtime_ns==file.stat().st_mtime_ns
    tests.append('prototype_new_call_observes_current_stat')
    for variant,function in functions.items():
        info=file.stat();key=(info.st_dev,info.st_ino)
        try:
            function({'nvme':fixture.nvme},allocation_bounds={key:dict(data_bytes=0,ceiling_bytes=0)})
        except RuntimeError as error:
            assert 'reserved envelope' in str(error)
        else:
            raise AssertionError('over-envelope allocation accepted')
        tests.append(variant+'_allocation_bound_rejected')
    for kind in ('symlink','fifo'):
        path=fixture.nvme/('d605-'+kind)
        if kind=='symlink':path.symlink_to(file)
        else:os.mkfifo(path)
        try:
            for variant,function in functions.items():
                try:function({'nvme':fixture.nvme})
                except ValueError as error:assert 'rejects links/special files' in str(error)
                else:raise AssertionError('special path accepted')
                tests.append(variant+'_'+kind+'_rejected')
        finally:path.unlink()
    # Alias accounting and order including Unicode/nested/prefix siblings.
    for name in ('index-a','index-ab','index-中文'):
        path=fixture.nvme/name/'nested';path.mkdir(parents=True)
        os.link(file,path/'alias')
    for capture in (False,True):
        observed={}
        for variant,function in functions.items():
            stats={}
            value=function(owner.roots,allocation_bounds=owner._file_allocations,
                _observed_stats=stats if capture else None)
            observed[variant]=(value,{str(k):(v.st_dev,v.st_ino,v.st_mode,v.st_size,v.st_blocks,
                v.st_nlink,v.st_mtime_ns,v.st_ctime_ns) for k,v in stats.items()})
        assert observed['parent']==observed['prototype']
    tests.append('tiny_alias_and_nested_order_exact')
finally:
    case.doCleanups()

pool = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
assert pool.resolve()==pool and pool.is_dir()
roots={'nvme':pool}
# Warm metadata using both variants; do not drop caches or read weight contents.
for function in functions.values():function(roots)
expected=None
for capture in (False,True):
    for repeat in range(3):
        order=('parent','prototype') if repeat%2==0 else ('prototype','parent')
        for variant in order:
            captured={}
            start=time.perf_counter()
            value=functions[variant](roots,_observed_stats=captured if capture else None)
            elapsed=time.perf_counter()-start
            if expected is None:expected=value
            assert value==expected
            rows.append(dict(variant=variant,capture=capture,repeat=repeat,elapsed_seconds=elapsed,
                file_count=value['unique_file_count'],path_count=sum(len(a['paths']) for a in value['allocations']),
                exact_output=True))
    counts={}
    for variant in functions:
        calls=Counter()
        def counted_stat(path,*args,**kwargs):
            calls[str(path)]+=1
            assert kwargs.get('follow_symlinks') is False
            return original_stat(path,*args,**kwargs)
        with patch.object(os,'stat',counted_stat):
            value=functions[variant](roots,_observed_stats={} if capture else None)
        assert value==expected and set(calls.values())=={2}
        counts[variant]=calls
    assert counts['parent']==counts['prototype']
    tests.append('real_pool_two_fresh_stats_exact_capture_'+str(capture))
    for variant in functions:
        profiler=cProfile.Profile()
        profiler.enable()
        value=functions[variant](roots,_observed_stats={} if capture else None)
        profiler.disable()
        assert value==expected
        stats=pstats.Stats(profiler)
        entries=[dict(file=k[0],line=k[1],function=k[2],primitive_calls=v[0],calls=v[1],
                      self_seconds=v[2],cumulative_seconds=v[3]) for k,v in stats.stats.items()]
        profiles.append(dict(variant=variant,capture=capture,
            entries=sorted(entries,key=lambda row:row['self_seconds'],reverse=True)))

import torch
assert not torch.cuda.is_initialized()
assert p.verify_seal(seal)['pass']
assert hashlib.sha256(old_source).hexdigest()==p.digest(ROOT/relative)
groups=[]
for capture in (False,True):
    for variant in functions:
        values=[r['elapsed_seconds'] for r in rows if r['variant']==variant and r['capture']==capture]
        groups.append(dict(variant=variant,capture=capture,mean_seconds=statistics.mean(values),
                           min_seconds=min(values),max_seconds=max(values),component_calls=len(values)))
result=dict(passed=True,kind='d605_fresh_inventory_component_prototype_v1',old_commit=old_commit,
    old_source_sha256=hashlib.sha256(old_source).hexdigest(),parent_function=parent_text,
    prototype_function=candidate_text,tests=tests,rows=rows,groups=groups,profiles=profiles,
    real_pool=str(pool),pool_inventory_output_sha256=hashlib.sha256(json.dumps(expected,sort_keys=True).encode()).hexdigest(),
    native_cuda_initialized=False,production_source_unchanged=True,formal_performance=False,
    independent_performance_repetitions=False,resources={k:(group/k).read_text().strip()
        for k in ('memory.peak','memory.events','memory.swap.current')})
save('component_result.json',result)
print(json.dumps(dict(passed=True,groups=groups,tests=len(tests)),indent=2))
