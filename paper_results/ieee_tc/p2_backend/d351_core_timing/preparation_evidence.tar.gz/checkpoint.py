"""Seal tested D351 observation preparation, exact paths only; no GPU launch."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d351_core_timing'
binding=json.loads((out/'prelaunch.json').read_text())
assert binding['passed'] and binding['tests']==202 and not binding['changed_policy']
for ref in binding['sources']+binding['refs']:
    assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
cleanup=[]
for suffix in ('3','4'):
    identity=p.scope_identity('primelora-tc-aux-d351000000000000000000000000000'+suffix+'.scope')
    group=Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
    subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
    assert subprocess.check_output(['systemctl','--user','show',identity['unit'],
        '-p','ActiveState','--value'],text=True).strip()=='inactive'
    cleanup.append(dict(identity=identity,resources=resources,inactive=True))
with (raw/'preparation_cleanup.json').open('x') as f:json.dump(cleanup,f,indent=2)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def safe(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
paths=[raw/x for x in ('prepare.py','complete_binding.py','checkpoint.py',
    'cpu_tests1.log','cpu_tests1_receipt.json','tests0_cleanup.json','tests1_cleanup.json',
    'preparation_cleanup.json','start_remote.sh','check_remote_health.py','stop_remote.sh')]
archive=out/'preparation_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        data=path.read_bytes();safe(data)
        if path.suffix=='.py':ast.parse(data)
        if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest()==p.digest(path)
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count']==147 and protected['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
with (out/'preparation_evidence.json').open('x') as f:
    json.dump(dict(kind='d351_observer_preparation_v1',tests=202,new_gpu_runs=0,
        archive_sha256=p.digest(archive),protected=protected,
        raw_refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths]),f,indent=2)
with (out/'preparation.sha256').open('x') as f:
    for path in sorted(out.glob('*')):
        if path.is_file() and path.name!='preparation.sha256':
            f.write(p.digest(path)+'  '+path.name+'\n')
relative=['docs/ieee_tc/D351_NATIVE_CORE_TIMING_DIAGNOSTIC.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'faaslora/utils/logger.py','faaslora/utils/core_timing.py','faaslora/scheduling/vllm_ieee_scheduler.py',
    'scripts/ieee_tc/profile_d328_controller_python.sh','scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    'configs/ieee_tc/20261008_d351_7b_full_w0_prefix1.yaml','tests/test_ieee_tc_core_timing.py']
relative += [str(x.relative_to(ROOT)) for x in sorted(out.glob('*')) if x.is_file()]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','add','--',*relative],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert sorted(staged)==sorted(relative)
assert 'configs/generated/lora_manifest_1000.json' not in staged
for filename in staged:
    data=subprocess.check_output(['git','show',':'+filename],cwd=ROOT)
    safe(data)
    assert hashlib.sha256(data).hexdigest()==p.digest(ROOT/filename)
    if filename.endswith('.py'):ast.parse(data)
    if filename.endswith('.sh'):subprocess.run(['bash','-n',str(ROOT/filename)],check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['sha256sum','-c','preparation.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
record=dict(passed=True,staged_paths=staged,archive_members=len(paths),
    identity=p.scope_identity(p.cg_path().name))
with (raw/'checkpoint_verification.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(passed=True,staged_count=len(staged),archive_members=len(paths))))
