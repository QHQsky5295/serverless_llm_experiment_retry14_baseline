"""Bounded D351 CPU qualification; no inference, source/data regeneration or remote work."""
import ast
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import yaml

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d351_core_timing'
out.mkdir(parents=True,exist_ok=True)
identity=p.scope_identity(p.cg_path().name)
group=Path(identity['path'])
def resources():
    return {k:(group/k).read_text().strip() for k in ('memory.peak','memory.events',
        'memory.swap.current','memory.high','memory.max','memory.swap.max')}
before=resources()
assert before['memory.high']==str(3*p.GIB) and before['memory.max']==str(4*p.GIB)
assert before['memory.swap.max']=='0' and os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
old=p.scope_identity('primelora-tc-aux-d3510000000000000000000000000001.scope')
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
old_resources={k:(Path(old['path'])/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
with (raw/'tests0_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,resources=old_resources,inactive=True,initial_tests=49),f,indent=2)
command=[sys.executable,'-m','unittest','tests.test_ieee_tc_core_timing',
    'tests.test_ieee_tc_stack_diagnostic','tests.test_ieee_tc_control_diagnostic',
    'tests.test_ieee_tc_scheduler_observation','tests.test_ieee_tc_launch','-q']
with (raw/'cpu_tests1.log').open('x') as f:
    completed=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
with (raw/'cpu_tests1_receipt.json').open('x') as f:
    json.dump(dict(identity=identity,before=before,after=resources(),command=command,
        returncode=completed.returncode),f,indent=2)
completed.check_returncode()
config=ROOT/'configs/ieee_tc/20261008_d351_7b_full_w0_prefix1.yaml'
previous=ROOT/'configs/ieee_tc/20261008_d349_7b_full_w0.yaml'
current,prior=(yaml.safe_load(x.read_text()) for x in (config,previous))
expected=copy.deepcopy(prior)
paths={('experiment','output_dir'):str(raw/'7b_full_w0_prefix1'),
       ('storage','nvme_cache_dir'):str(raw/'7b_nvme_w0'),
       ('storage','host_cache_dir'):'/dev/shm/tc-d351-7b-w0'}
for (section,field),value in paths.items():
    assert current[section][field]==value and not Path(value).exists()
    expected[section][field]=value
assert current==expected and current['workload']['total_requests']==4000
sources=[]
for relative in ('v1/engine/core.py','v1/executor/uniproc_executor.py',
                 'v1/core/sched/async_scheduler.py','v1/core/sched/scheduler.py'):
    path=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')/relative
    tree=ast.parse(path.read_text())
    if relative=='v1/engine/core.py':
        core=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='EngineCoreProc')
        methods={x.name:x for x in core.body if isinstance(x,ast.FunctionDef)}
        for name in ('_process_input_queue','_handle_client_request','_process_engine_step','shutdown'):
            assert name in methods,name
        assert [x.arg for x in methods['_handle_client_request'].args.args]==['self','request_type','request']
    sources.append(dict(path=str(path),sha256=p.digest(path)))
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['changed']==[str(known)] and seal['entry_count']==147
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
preflight=p.preflight([ROOT],32*p.GIB)
assert preflight['preflight_pass'],preflight['issues']
refs=[config,previous,Path(__file__),ROOT/'faaslora/utils/core_timing.py',
    ROOT/'faaslora/utils/logger.py',ROOT/'faaslora/scheduling/vllm_ieee_scheduler.py',
    ROOT/'scripts/ieee_tc/profile_d328_controller_python.sh',
    ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    ROOT/'tests/test_ieee_tc_core_timing.py',
    ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/initialization/service.json',
    ROOT/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/initialization/preparation.json']
assert p.digest(refs[-2])=='794d00bac794da9c076b34da38cc310c90d70330b9414ef02de09faab9c7cd32'
assert p.digest(refs[-1])=='bfe0a6f87a65a1835bf0d374f8045f28e0c09c41d5416960b1c4a218ad2893be'
record=dict(kind='d351_host_timing_prelaunch_v1',passed=True,identity=identity,
    sources=sources,refs=[dict(path=str(x),sha256=p.digest(x)) for x in refs],
    resources=resources(),preflight=preflight,protection=seal,
    base_requests=4000,diagnostic_prefix_count=1000,new_gpu_runs=0,
    n_correct=None,formal_performance_result=False,changed_policy=False,no_figures=True)
with (out/'prelaunch.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(passed=True,new_gpu_runs=0,preflight=True,
    disk_free_bytes=preflight['filesystems'][0]['free_bytes'],resources=resources())))
