"""Post-release bounded analysis/tests only; keep the instrumented identity."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
identity=p.scope_identity(p.cg_path().name)
group=Path(identity['path'])
def resources():
    return {k:(group/k).read_text().strip() for k in
        ('memory.high','memory.max','memory.swap.max','memory.peak','memory.events','memory.swap.current')}
before=resources()
assert before['memory.high']==str(3*p.GIB) and before['memory.max']==str(4*p.GIB)
assert before['memory.swap.max']=='0' and os.sched_getaffinity(0)=={2,3,26,27}
launch=json.loads((raw/'7b_full_w0_prefix1/launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert json.loads((raw/'remote_stop.json').read_text())['all_owned_units_inactive']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
collection=json.loads((raw/'collection_receipt.json').read_text())
assert p.digest(Path(collection['source_path']))==collection['source_sha256']
old=collection['identity'];oldgroup=Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(oldgroup)
old_resources={k:(oldgroup/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
assert not oldgroup.exists()
with (raw/'collection_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,resources=old_resources,inactive=True),f,indent=2)
command=[sys.executable,'-m','unittest','tests.test_ieee_tc_core_timing_analysis',
    'tests.test_ieee_tc_control_timeline','tests.test_ieee_tc_decode_overlap','-q']
with (raw/'analysis_tests1.log').open('x') as f:
    result=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
with (raw/'analysis_tests1_receipt.json').open('x') as f:
    json.dump(dict(command=command,returncode=result.returncode,identity=identity,
        before=before,after=resources()),f,indent=2)
result.check_returncode()
with (raw/'analysis1.log').open('x') as f:
    result=subprocess.run([sys.executable,str(raw/'analyze_prefix.py')],cwd=ROOT,
        stdout=f,stderr=subprocess.STDOUT)
with (raw/'analysis1_receipt.json').open('x') as f:
    json.dump(dict(returncode=result.returncode,identity=identity,resources=resources(),
        source_sha256=collection['source_sha256'],preflight=gate),f,indent=2)
result.check_returncode()
print(json.dumps(dict(passed=True,resources=resources(),new_gpu_runs=0)))
