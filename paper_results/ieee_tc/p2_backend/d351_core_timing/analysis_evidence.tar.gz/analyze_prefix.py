"""D351 offline only: reuse native audit and existing control analyzer; add host-span partition.

No serving changes, figures, CI, or comparison with uninstrumented Full.
"""
import collections
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.plot_d290_diagnostic import audit_run, binding_checks
from scripts.analyze_control_path_overhead import analyze_core_host_timing
from scripts.ieee_tc.analyze_d297_full import (decode_overlap_summary,
    native_load_overlap_summary, partition_activation_readiness)

RAW = Path(__file__).resolve().parent
RUN = RAW/'7b_full_w0_prefix1'
E = RUN/'launch.launch'
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d351_core_timing/analysis1'
read = lambda x: json.loads(x.read_text())

def write(name, value):
    with (OUT/name).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

launch = read(RUN/'launch.json')
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
receipt = read(E/'exec_receipt.json')
assert receipt['external_replay']['diagnostic_prefix_count'] == 1000
assert receipt['external_replay']['plan']['source_count'] == 4000
source, = RUN.glob('experiment_results_*.json')
assert source.stat().st_size < 128*1024**2
OUT.mkdir(parents=True, exist_ok=False)
stats, evidence, requests = audit_run(source)
assert len(requests) == 1000
index = read(ROOT/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json')
expected = {a['id']:hashlib.sha256(json.dumps(sorted(a['files'],key=lambda f:f['path']),
    sort_keys=True,separators=(',',':')).encode()).hexdigest() for a in index['artifacts']}
checks = collections.Counter()
for row in requests:
    c = binding_checks(row, expected[row['adapter_id']])
    assert all(c.values()), row['request_id']
    checks.update(k for k,v in c.items() if v)
terminals = [json.loads(l) for l in (E/'physical_deployment/request_terminals.jsonl').open()]
assert len(terminals) == len({r['request_id'] for r in terminals}) == 1000
assert all(r['success'] and r['native_contract_matched'] for r in terminals)
assert {r['request_id'] for r in terminals} == {r['request_id'] for r in requests}
physical = read(E/'physical_deployment/summary.json')
assert physical['measurement_complete'] and not physical['open_lease_ids']
assert all(r['released'] for r in physical['allocation_journals'])
assert abs(sum(physical['window_gpu_seconds'].values())-stats['physical_gpu_seconds']) < 1e-6
write('native_audit.json', dict(stats=stats,evidence=evidence,binding_pass_counts=dict(checks),
    source_count=4000,diagnostic_count=1000,terminal_success=1000,terminal_failure=0,
    window_gpu_seconds=physical['window_gpu_seconds'],allocations=len(physical['allocation_journals']),
    numerical_n_correct=None,formal_qualification=False,includes_observer_overhead=True))

# Existing D187 metadata audit, using the normal bounded outcome without a
# duplicate compact copy; current normal metadata is <256 MiB.
outcome_path = E/'physical_deployment/main_outcome.json'
assert outcome_path.stat().st_size < 256*1024**2
x = read(outcome_path)
assert x['run_completed'] and x['error'] is None and x['cleanup']['complete']
assert not x['cleanup_errors'] and not x['measurement_errors'] and not x['interrupted_replays']
remote = [json.loads(l) for l in (RAW/'remote_transfers.jsonl').open()]
health = read(RAW/'remote_health.json')['7b']
transfers = x['remote_transfers']
by = {r['transfer_id']:r for r in remote}
assert len(by) == len(remote) == len(transfers) > 0
assert set(by) == {r['http_transfer_id'] for r in transfers}
for r in transfers:
    peer = by[r['http_transfer_id']]
    assert peer['clock_id'] == health['clock_id'] and peer['artifact_id'] == r['artifact_id']
    assert not peer['pack_performed'] and not peer['temporary_created']
    assert r['state'] == 'published' and r['content_verified'] and r['published_archive_verified']
    assert peer['bytes_written'] == r['transferred_bytes']
    assert r['payload_bytes_verified'] == r['payload_bytes_expected']
resources = dict(samples=0,peak_bytes=0,min_host_available_bytes=2**63,events={},max_swap_bytes=0,warnings=0)
for line in (E/'watchdog.jsonl').open():
    r = json.loads(line)
    if r['event'] != 'resource_sample': continue
    resources['samples'] += 1
    assert not r['decision']['abort_reasons']
    resources['warnings'] += r['decision']['warning']
    resources['peak_bytes'] = max(resources['peak_bytes'],r['service']['memory.peak'])
    resources['min_host_available_bytes'] = min(resources['min_host_available_bytes'],r['host']['available_bytes'])
    resources['max_swap_bytes'] = max(resources['max_swap_bytes'],r['service']['memory.swap.current'])
    for k in ('high','max','oom','oom_kill'):
        resources['events'][k] = max(resources['events'].get(k,0),r['service']['memory.events'].get(k,0))
write('resource_remote.json',dict(resources=resources,remote=dict(transfers=len(transfers),
    wire_bytes=sum(r['transferred_bytes'] for r in transfers),packing=0,clock_id=health['clock_id']),
    source_stats=x['mechanism_events']['_ieee_source_observation_stats'],
    source_refs=[dict(path=str(f),sha256=p.digest(f)) for f in
        (outcome_path,RAW/'remote_transfers.jsonl',RAW/'remote_monitor.log',E/'watchdog.jsonl')]))
warm_path=ROOT/'paper_results/ieee_tc/p2_backend/20261002_d170_warm_measurement.json'
assert p.digest(warm_path)=='0ebc7587effe293dcb986d33fb932c100cbcb3384c56ab2c0b0bec73b2bdd88c'
thresholds=[dict(group_id=t['group_id'],lower_exclusive=t['lower_exclusive'],
    upper_inclusive=t['upper_inclusive'],ttft_s=t['candidate_ttft_threshold_ms']/1000,
    tpot_s=t['candidate_tpot_threshold_ms']/1000) for t in read(warm_path)['warm_threshold_candidates']]
deployment=read(E/'physical_deployment/deployment.json')
ready,not_ready=partition_activation_readiness(x['mechanism_events']['_ieee_activations'],requests,
    clock_id=deployment['clock_id'])
decode=decode_overlap_summary(requests,ready,clock_id=deployment['clock_id'],
    arrival_start=deployment['arrival_start_s'],thresholds=thresholds)
loads=native_load_overlap_summary(requests,decode['requests'],clock_id=deployment['clock_id'])
windows=loads['requests']
# Native worker PID is bound by the pre-existing audited source receipt.
# Confirm its actual process incarnation against allocation journals, not PID alone.
incarnations={}
for path in (E/'physical_allocations').glob('*.jsonl'):
    for line in path.open():
        event=json.loads(line)
        if event['event']!='native_workers': continue
        for worker in event['workers']:
            matches=[p for device in event['census']['devices'] for p in device['processes']
                if p['pid']==worker['pid'] and p['kind']=='compute' and p['service_member']
                and device['gpu_uuid']==worker['device_uuid']]
            assert len(matches)==1
            pid,ticks=worker['pid'],matches[0]['identity']['start_ticks']
            assert pid not in incarnations or incarnations[pid]==ticks
            incarnations[pid]=ticks
for window in windows:
    pid=window['worker_pid']
    assert pid in incarnations
    assert (E/f'diagnostic_core/{pid}-{incarnations[pid]}.jsonl').is_file()
del x,transfers,requests
gc.collect()
core=analyze_core_host_timing(E/'diagnostic_core',E/'exec_receipt.json',
    E/'physical_deployment/deployment.json',windows,OUT/'core_timing')
write('completion.json',dict(native_contract_count=1000,n_correct=None,
    formal_qualification=False,no_figures=True,processes=core['processes'],
    complete_processes=core['complete_processes'],
    complete_request_observations=core['complete_request_observations'],
    not_ready_activations=not_ready,thresholds=thresholds,
    source_refs=[dict(path=str(f),sha256=p.digest(f)) for f in
        (Path(__file__),source,RUN/'launch.json',warm_path)]))
# Hash outputs before opening the manifest: no self-reference to an empty file.
outputs={str(path.relative_to(OUT)):p.digest(path) for path in sorted(OUT.rglob('*')) if path.is_file()}
write('manifest.json',dict(outputs=outputs,source_refs=[dict(path=str(f),sha256=p.digest(f))
    for f in (Path(__file__),source,RUN/'launch.json',warm_path,
        ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'scripts/ieee_tc/plot_d290_diagnostic.py')]))
print(json.dumps(dict(completed_native=1000,stats=stats,processes=core['processes'],
    complete_request_observations=core['complete_request_observations'],groups=core['groups'],resources=resources)))
