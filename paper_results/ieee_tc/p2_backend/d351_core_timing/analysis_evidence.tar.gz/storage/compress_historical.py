"""Reuse the audited D339 procedure, with only target/output configuration changed.

This is storage maintenance, not a performance run. The historical source is
preserved byte-for-byte in gzip; no inputs or submitted results are touched.
"""
import ast
import hashlib
from pathlib import Path

SOURCE = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d339_20261008/compress_historical.py')
tree = ast.parse(SOURCE.read_text(), filename=str(SOURCE))
targets = [('d341_20261008/7b_full_w0',
    '37a057c1e9ca556d19b63650e9afa35b50fb5bea4b0fbbc577b1474037e3d435',
    'd341_full_w0/validated1/manifest.json')]
changed = 0
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'TARGETS' for t in node.targets):
        node.value = ast.parse(repr(targets), mode='eval').body
        changed += 1
assert changed == 1
ast.fix_missing_locations(tree)
print('Reuse D339 compression procedure SHA256', hashlib.sha256(SOURCE.read_bytes()).hexdigest(), flush=True)
exec(compile(tree, str(SOURCE), 'exec'), {'__name__': '__main__', '__file__': __file__})
