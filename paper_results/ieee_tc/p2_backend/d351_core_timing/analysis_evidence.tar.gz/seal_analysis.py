"""Seal D351 completed diagnostic with exact path staging, never raw large data."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d351_core_timing'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert json.loads((raw/'remote_stop.json').read_text())['all_owned_units_inactive']
gate=p.preflight([ROOT],p.GIB);assert gate['preflight_pass'],gate['issues']
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old=json.loads((raw/'operation_receipt.json').read_text())['identity'];og=Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(og)
resources={k:(og/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
assert not og.exists()
with (raw/'operation_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,resources=resources,inactive=True),f,indent=2)
tests=(raw/'analysis_tests1.log').read_text()
assert 'Ran 106 tests' in tests and 'OK' in tests.splitlines()
assert json.loads((raw/'analysis1_receipt.json').read_text())['returncode']==0
assert json.loads((out/'analysis1/completion.json').read_text())['complete_request_observations']==1000
for name,expected in json.loads((out/'analysis1/manifest.json').read_text())['outputs'].items():
    assert p.digest(out/'analysis1'/name)==expected
collection=json.loads((raw/'collection_receipt.json').read_text())
assert p.digest(Path(collection['source_path']))==collection['source_sha256']
subprocess.run(['sha256sum','-c','preparation.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def safe(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',data)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
paths=[raw/x for x in ('collect_closure.py','analyze_prefix.py','run_analysis.py',
    'summarize_operations.py','seal_analysis.py','local_cleanup.json','remote_stop.json',
    'remote_stop.log','collection_receipt.json','collection_cleanup.json',
    'analysis_tests1.log','analysis_tests1_receipt.json','analysis1.log','analysis1_receipt.json',
    'analysis_storage_cleanup.json','operation_receipt.json','operation_cleanup.json',
    '7b_full_w0_prefix1/launch.json','7b_full_w0_prefix1/launch.launch/exec_receipt.json')]
paths += sorted((raw/'storage').glob('*.json'))+[raw/'storage/compress_historical.py']
archive=out/'analysis_evidence.tar.gz'
with archive.open('xb') as handle,tarfile.open(fileobj=handle,mode='w:gz') as tar:
    for path in paths:
        data=path.read_bytes();safe(data)
        assert len(data)<10*1024**2
        if path.suffix=='.py':ast.parse(data)
        tar.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(paths)
    for path in paths:
        assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw))).read()).hexdigest()==p.digest(path)
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count']==147 and protected['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
relative=['docs/ieee_tc/D351_NATIVE_CORE_TIMING_DIAGNOSTIC.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'scripts/analyze_control_path_overhead.py','tests/test_ieee_tc_core_timing_analysis.py']
with (out/'analysis_evidence.json').open('x') as f:
    json.dump(dict(kind='d351_completed_diagnostic_v1',tests=106,archive_sha256=p.digest(archive),
        native_contract=1000,n_correct=None,formal_qualification=False,no_figures=True,
        protected=protected,execution_head='15e66c9b05b4c5ee8998f219206886c37a00f810',
        raw_references=[dict(path=str(x),sha256=p.digest(x)) for x in paths],
        code_references=[dict(path=str(ROOT/x),sha256=p.digest(ROOT/x)) for x in relative[2:]],
        source_path=collection['source_path'],source_sha256=collection['source_sha256'],
        service_released=True,remote_inactive=True,preflight=gate),f,indent=2)
with (out/'analysis.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='analysis.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
relative += [str(x.relative_to(ROOT)) for folder in ('analysis1','operation_detail1')
    for x in sorted((out/folder).rglob('*')) if x.is_file()]
relative += [str((out/x).relative_to(ROOT)) for x in
    ('analysis_evidence.tar.gz','analysis_evidence.json','analysis.sha256')]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','add','--',*relative],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert sorted(staged)==sorted(relative)
assert 'configs/generated/lora_manifest_1000.json' not in staged
for filename in staged:
    data=subprocess.check_output(['git','show',':'+filename],cwd=ROOT);safe(data)
    assert hashlib.sha256(data).hexdigest()==p.digest(ROOT/filename)
    if filename.endswith('.py'):ast.parse(data)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['sha256sum','-c','analysis.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
record=dict(passed=True,identity=identity,staged_paths=staged,resources=resources,archive_members=len(paths))
with (raw/'analysis_checkpoint.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(passed=True,staged_count=len(staged),archive_members=len(paths),resources=resources)))
