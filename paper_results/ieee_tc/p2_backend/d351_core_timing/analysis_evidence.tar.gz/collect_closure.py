"""D351 closure: reuse D335 exact-owned cleanup/download checks."""
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

own_identity = p.scope_identity(p.cg_path().name)
own_group = Path(own_identity['path'])
assert (own_group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (own_group/'memory.swap.max').read_text().strip() == '0'
gate = p.preflight([p.ROOT], 4*p.GIB)
assert gate['preflight_pass'], gate['issues']
raw = Path(__file__).resolve().parent
run = raw/'7b_full_w0_prefix1'
launch = json.loads((run/'launch.json').read_text())
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
aux = Path(launch['auxiliary']['path'])
identity = json.loads((raw/'launcher_identity.json').read_text())
assert p.scope_still_owned(identity)
assert identity['path'] == str(aux) and not p.owned_pids(aux)
files = {key: (aux/key).read_text() for key in ['memory.peak','memory.events','memory.swap.current',
    'memory.high','memory.max','memory.swap.max','cgroup.events']}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
after = subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip()
assert after == 'inactive'
with (raw/'local_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,files=files,after=after,launch_pass=True,native_gpu_release_confirmed=True), f, indent=2)
stop = (raw/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive') == 3 and stop.count('MainPID=0') == 3
transfer_paths = [line for line in stop.splitlines()
    if line.startswith('/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-') and line.endswith('.jsonl')]
assert len(transfer_paths) == 1
paths = {
    'remote_transfers.jsonl': transfer_paths[0],
    'remote_monitor.log': '/home/lab14/primelora_remote/tc/d351_20261008_prefix1/remote_monitor.log',
}
hashes = {}
for name, remote_path in paths.items():
    destination = raw/name
    assert not destination.exists()
    expected = subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','sha256sum',remote_path],text=True).split()[0]
    subprocess.run(['scp','-q','-o','BatchMode=yes',f'primelora-artifact-174:{remote_path}',str(destination)],check=True)
    assert p.digest(destination) == expected
    hashes[name] = expected
with (raw/'remote_stop.json').open('x') as f:
    json.dump(dict(all_owned_units_inactive=True,ports_18080_18081_absent=True,
        local_gpu_release_verified_before_remote_stop=True,download_hashes_match_remote=True,
        hashes=hashes,stop_log_sha256=p.digest(raw/'remote_stop.log')),f,indent=2)
print(json.dumps(dict(local_aux_inactive=True,remote_inactive=True,hashes=hashes)))

source = next(run.glob('experiment_results*.json'))
receipt = dict(identity=own_identity, source_path=str(source), source_sha256=p.digest(source),
    source_bytes=source.stat().st_size, preflight=gate,
    resources={k:(own_group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current','cgroup.events')})
with (raw/'collection_receipt.json').open('x') as f:
    json.dump(receipt,f,indent=2)
print(json.dumps({k:receipt[k] for k in ('identity','source_path','source_sha256','source_bytes','resources')}))
