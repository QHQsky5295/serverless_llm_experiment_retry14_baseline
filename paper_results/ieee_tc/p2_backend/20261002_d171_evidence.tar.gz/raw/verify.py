"""D170 bounded seal/bundle procedure reused; bind only new D171 dependencies."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT,digest,check_plan,verify_seal
RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
BASE='ef38f25735c0d781330b35f4cb254ca1b06d7f7c'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
changed=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(changed)<={'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md',
                     'scripts/analyze_control_path_overhead.py'}
analyzer=ROOT/'scripts/analyze_control_path_overhead.py'
before=ast.parse(subprocess.check_output(['git','show',BASE+':scripts/analyze_control_path_overhead.py'],cwd=ROOT,text=True))
after=ast.parse(analyzer.read_text())
new=[n for n in after.body if isinstance(n,ast.FunctionDef) and n.name=='provisional_timing_bound']
assert len(new)==1
after.body.remove(new[0])
assert ast.dump(before)==ast.dump(after), 'changed existing analyzer behavior'
curated=OUT/'20261002_d171_timing_gap.json'
data=json.loads(curated.read_text())
assert data['offered_count']==4000 and data['timing_joint_pass_count']==2110
assert sum(data['outcome_counts'].values())==4000
assert data['joint_upper_bound']==.5275 and data['minimum_additional_timing_passes']==1690
assert data['n_correct'] is None and data['formal_joint_slo'] is None
assert not data['formal_g1_g2_qualified'] and not data['common_reference_frozen']
for path,sha in data['sources'].items(): assert digest(Path(path))==sha,path
for path,sha in data['table_sha256'].items(): assert digest(Path(path))==sha,path
tests=(RAW/'tests1.log').read_text()
assert 'Ran 32 tests' in tests and tests.rstrip().endswith('OK')
assert len(re.findall(r'^test_.* \.\.\. ok$',tests,re.M))==32
cleanup=[]
for phase in ('tests1','analyze1'):
    receipt=(RAW/f'{phase}_scope.txt').read_text()
    actual=re.search(r'^InvocationID=([a-f0-9]{32})$',receipt,re.M)[1]
    state=subprocess.check_output(['systemctl','--user','show',f'primelora-d171-{phase}-20261002.scope',
                                  '-p','ActiveState','-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines()==['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert all(int(line.split()[1])==0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text())==0
    assert 'Exit status: 0' in (RAW/f'{phase}_time.txt').read_text()
    cleanup.append(dict(phase=phase,actual_invocation_id=actual,returncode=0,
                        cleanup='automatic_removal_verified'))
with (RAW/'cleanup_verified.json').open('x') as f: json.dump(cleanup,f,indent=2)
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
doc=ROOT/'docs/ieee_tc/D171_PROVISIONAL_TIMING_GAP.md'
tables=[OUT/f'20261002_d171_timing_{suffix}.csv' for suffix in ('groups','requests')]
for table,count in zip(tables,(11,4000)):
    with table.open() as f: assert len(list(csv.DictReader(f)))==count
for path in RAW.glob('*.py'): ast.parse(path.read_text())
verification=OUT/'20261002_d171_verification.json'
with verification.open('x') as f:
    json.dump(dict(passed=True,base_commit=BASE,serving_code_unchanged=True,
        existing_analyzer_ast_unchanged=True,tests_passed=32,protected=protected,cleanup=cleanup,
        curated_sha256=digest(curated),table_sha256=data['table_sha256'],document_sha256=digest(doc)),f,indent=2)
members=sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size<2*1024**2
               and not p.name.startswith('verify1') and p.suffix!='.lock')
extras=[doc,curated,verification,*tables,analyzer,ROOT/'tests/test_ieee_tc_timing_bound.py']
hashes={}
bundle=OUT/'20261002_d171_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for p in members+extras:
        name='raw/'+str(p.relative_to(RAW)) if p in members else str(p.relative_to(ROOT))
        hashes[name]=digest(p)
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha
with (OUT/'20261002_d171_evidence_members.json').open('x') as f:
    json.dump(dict(passed=True,member_sha256=hashes,source_raw_retained_and_bound=True),f,indent=2)
with (OUT/'20261002_d171_evidence.sha256').open('x') as f: f.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    members=len(hashes),bundle_bytes=bundle.stat().st_size,cleanup=cleanup),indent=2))
