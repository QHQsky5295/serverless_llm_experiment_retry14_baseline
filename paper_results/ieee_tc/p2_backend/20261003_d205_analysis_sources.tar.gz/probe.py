"""D205 bounded CPU probe of the installed metadata builder; no model or CUDA."""
import copy
import csv
import importlib.util
import json
from pathlib import Path
import sys

import torch

from scripts.ieee_tc_preflight import digest, validate_native_lora_execution_metadata
from tests.test_ieee_tc_artifact_audit import NativeExecutionMetadataAudit

root = Path(__file__).resolve().parents[0]
native = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')
rel = 'lora/ops/triton_ops/lora_kernel_metadata.py'
source = native / rel
assert not torch.cuda.is_initialized()
spec = importlib.util.spec_from_file_location('d205_installed_metadata', source)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
fixture = NativeExecutionMetadataAudit()
rows, records = [], []


def serialized(meta, count, specialized):
    tensors = meta.meta_args(count, specialized)
    return dict(zip(('token_lora_mapping', 'token_indices_sorted_by_lora_ids',
                     'num_tokens_per_lora', 'lora_token_start_loc', 'active_lora_ids'),
                    [t.tolist() for t in tensors[:5]]),
                no_lora=bool(tensors[5].item()), launch_lora_count=int(tensors[6].item()))


for specialized in (False, True):
    token_meta = module.LoRAKernelMeta.make(4, 16, 'cpu', [1, 2, 4, 5])
    sampler_meta = module.LoRAKernelMeta.make(4, 16, 'cpu', [1, 2, 4, 5])
    for name, ids, counts, layout in (
        ('mixed_prefill', (11, 22, 0), (2, 1, 2), (22, None, 11, 33)),
        ('decode_reorder', (22, 11), (1, 1), (22, None, 11, 33)),
        ('slot_reassignment', (22, 11), (1, 1), (11, 22, 33, None)),
        ('all_base_stale_unused', (0,), (2,), (11, 22, 33, None)),
    ):
        obs, bindings = fixture.observation(ids=ids, counts=counts, layout=layout)
        for key, vector, meta in (
            ('token_kernel_meta', obs['token_slot_indices'], token_meta),
            ('sampler_kernel_meta', obs['sampler_slot_indices'], sampler_meta),
        ):
            meta.prepare_tensors(torch.tensor(vector, dtype=torch.long, device='cpu'))
            obs[key] = serialized(meta, len(vector), specialized)
        result = validate_native_lora_execution_metadata(obs, bindings)
        assert result['metadata_matches'] and not result['gpu_observation_qualified']
        negatives = []
        wrong_binding = dict(bindings, r0=33)
        candidates = [('external_identity', copy.deepcopy(obs), wrong_binding)]
        wrong_flag = copy.deepcopy(obs)
        wrong_flag['token_kernel_meta']['no_lora'] = not wrong_flag['token_kernel_meta']['no_lora']
        candidates.append(('no_lora_flag', wrong_flag, bindings))
        if name != 'all_base_stale_unused':
            wrong_order = copy.deepcopy(obs)
            order = wrong_order['token_kernel_meta']['token_indices_sorted_by_lora_ids']
            order[0] = order[1]
            candidates.append(('duplicate_real_row', wrong_order, bindings))
            wrong_launch = copy.deepcopy(obs)
            wrong_launch['token_kernel_meta']['launch_lora_count'] = 0
            candidates.append(('zero_grid_width', wrong_launch, bindings))
            wrong_sampler = copy.deepcopy(obs)
            wrong_sampler['sampler_kernel_meta']['active_lora_ids'][0] = 3
            candidates.append(('wrong_sampler_slot', wrong_sampler, bindings))
        for label, broken, expected in candidates:
            try:
                validate_native_lora_execution_metadata(broken, expected)
            except ValueError as error:
                negatives.append(dict(name=label, rejected=True, error=str(error)))
            else:
                raise AssertionError('accepted wrong execution metadata: ' + label)
        rows.append(dict(case=name, specialized=specialized, requests=len(ids),
                         real_token_rows=sum(counts), metadata_matches=True,
                         negative_controls_rejected=len(negatives), gpu_measurement=False))
        records.append(dict(case=name, specialized=specialized, expected_bindings=bindings,
                            observation=obs, result=result, negative_controls=negatives))
assert not torch.cuda.is_initialized()
files = [
    'v1/worker/gpu_model_runner.py', 'v1/worker/gpu_input_batch.py',
    'v1/worker/lora_model_runner_mixin.py', 'lora/worker_manager.py', 'lora/model_manager.py',
    'lora/punica_wrapper/punica_base.py', 'lora/punica_wrapper/punica_gpu.py',
    'lora/punica_wrapper/utils.py', rel, 'lora/ops/triton_ops/lora_shrink_op.py',
    'lora/ops/triton_ops/lora_expand_op.py',
]
sources = [dict(path=str(native / p), sha256=digest(native / p),
                upstream_url='https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/' + 'vllm/' + p)
           for p in files]
result = dict(kind='d205_installed_metadata_cpu_probe_v1', passed=True,
              source_sha256=digest(source), sources=sources, torch_version=torch.__version__,
              device='cpu', cuda_initialized=False, gpu_measurement=False,
              model_numeric_qualified=False, n_correct=None, cases=records, summary=rows)
with (root / 'metadata_cpu_probe.json').open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
with (root / 'metadata_cpu_probe.csv').open('x', newline='') as output:
    writer = csv.DictWriter(output, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps(dict(passed=True, cpu_cases=len(rows),
                      rejected_controls=sum(r['negative_controls_rejected'] for r in rows),
                      gpu_measurement=False, n_correct=None)))
