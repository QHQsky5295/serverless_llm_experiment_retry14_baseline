#!/usr/bin/env bash
# D205 execution metadata qualification: reuse D202 bounded CPU runner.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in tests2|os1|curate3) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d205_20261003
unit="primelora-d205-${phase}-20261003.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sources=(scripts/ieee_tc_preflight.py tests/test_ieee_tc_artifact_audit.py
  tests/test_ieee_tc_preflight.py tests/test_basic_smoke.py "$raw/run_cpu4.sh")
if test "$phase" = probe1; then sources+=("$raw/probe.py"); fi
if test "$phase" = curate3; then sources+=("$raw/curate3.py"); fi
sha256sum "${sources[@]}" > "$raw/${phase}_sources.sha256"
tar -czf "$raw/${phase}_sources.tar.gz" "${sources[@]}"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
"$python" scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "$raw/${phase}_protected_before.json"
if test "$phase" = tests1 || test "$phase" = tests2; then
  args=(-m unittest tests.test_ieee_tc_artifact_audit
    tests.test_ieee_tc_preflight.ApprovedPlanIdentity
    tests.test_ieee_tc_preflight.ForwardedCommandCLI
    tests.test_ieee_tc_preflight.IndependentNumericReference
    tests.test_ieee_tc_preflight.ExistingContentIndex
    tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer
    tests.test_ieee_tc_preflight.SlotContentQualification tests.test_basic_smoke -v)
elif test "$phase" = os1; then
  python=/usr/bin/python3
  args=(-m unittest tests.test_ieee_tc_preflight.ProtocolGates -v)
elif test "$phase" = probe1 || test "$phase" = curate3; then
  args=("$raw/curate3.py")
else
  exit 2
fi
set +e
/usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/${phase}_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/${phase}_swap.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.peak" > "$raw/${phase}_memory_peak.txt"
"$python" scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "$raw/${phase}_protected_after.json"
exit "$code"
