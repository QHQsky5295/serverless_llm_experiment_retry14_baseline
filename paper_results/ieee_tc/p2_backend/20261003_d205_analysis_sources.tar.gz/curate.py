"""D205: reuse bounded evidence sealing/bundle checks, retaining failed attempt."""
import ast
import csv
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path
from scripts.ieee_tc_preflight import ROOT, check_plan, digest, verify_seal

raw = ROOT/'results/ieee_tc/p2_backend_qualification/d205_20261003'
base = ROOT/'paper_results/ieee_tc/p2_backend'
doc = ROOT/'docs/ieee_tc/D205_NATIVE_EXECUTION_METADATA.md'
probe = json.loads((raw/'metadata_cpu_probe.json').read_text())
assert probe['passed'] and probe['device'] == 'cpu' and not probe['cuda_initialized']
assert len(probe['cases']) == 8 and sum(len(c['negative_controls']) for c in probe['cases']) == 34
for source in probe['sources']:
    assert digest(Path(source['path'])) == source['sha256']
for case in probe['cases']:
    assert case['result']['metadata_matches'] and case['result']['n_correct'] is None
    assert all(n['rejected'] for n in case['negative_controls'])
with (raw/'metadata_cpu_probe.csv').open(newline='') as file:
    rows = list(csv.DictReader(file))
assert len(rows) == 8 and sum(int(r['negative_controls_rejected']) for r in rows) == 34

scopes = {}
for phase, exitcode, testcount in [('tests1', 1, 384), ('tests2', 0, 337),
                                   ('os1', 0, 47), ('probe1', 0, None)]:
    receipt = dict(line.split('=', 1) for line in (raw/f'{phase}_scope.txt').read_text().splitlines())
    assert receipt['InvocationID'] and receipt['MemoryHigh'] == '3221225472'
    assert receipt['MemoryMax'] == '4294967296' and receipt['MemorySwapMax'] == '0'
    assert not Path('/sys/fs/cgroup'+receipt['ControlGroup']).exists()
    unit = f'primelora-d205-{phase}-20261003.scope'
    assert not subprocess.check_output(['systemctl', '--user', 'show', unit,
                                        '-p', 'InvocationID', '--value'], text=True).strip()
    assert f'Exit status: {exitcode}' in (raw/f'{phase}_time.txt').read_text()
    assert all(line.split()[1] == '0' for line in (raw/f'{phase}_memory_events.txt').read_text().splitlines())
    assert (raw/f'{phase}_swap.txt').read_text().strip() == '0'
    assert int((raw/f'{phase}_memory_peak.txt').read_text()) <= 4 * 1024**3
    log = (raw/f'{phase}.log').read_text()
    if testcount:
        assert f'Ran {testcount} tests' in log
        assert ('FAILED (failures=2, errors=3)' if exitcode else '\nOK\n') in log
    for position in ('before', 'after'):
        assert json.loads((raw/f'{phase}_protected_{position}.json').read_text())['pass']
    scopes[phase] = dict(receipt, exitcode=exitcode, test_count=testcount, released=True)
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()

# Every pre-existing preflight AST node is unchanged; no runtime helper removed.
name = 'scripts/ieee_tc_preflight.py'
prior = ast.parse(subprocess.check_output(['git', 'show', 'HEAD:'+name], text=True))
current = ast.parse((ROOT/name).read_text())
new = [n for n in current.body if isinstance(n, ast.FunctionDef)
       and n.name == 'validate_native_lora_execution_metadata']
assert len(new) == 1
current.body.remove(new[0])
assert ast.dump(prior) == ast.dump(current)
unchanged = ['scripts/run_all_experiments.py', 'faaslora/memory/gpu_monitor.py',
             'faaslora/memory/residency_manager.py', 'faaslora/preloading/preloading_planner.py',
             'faaslora/experiment/instance_pool.py', 'scripts/dedicated_engine_worker.py']
for name in unchanged:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git', 'show', 'HEAD:'+name])
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
protection = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protection['pass']
for name in ('probe.py', 'curate.py', 'check_staged.py'):
    compile((raw/name).read_bytes(), str(raw/name), 'exec')
for name in ('run_cpu.sh', 'run_cpu2.sh'):
    subprocess.run(['bash', '-n', str(raw/name)], check=True)
text = doc.read_text()
for expected in ('337/337', '47/47', '10/10', '8/8', '34/34', '384 项，2 failure、3 error'):
    assert expected in text
for extension in ('json', 'csv'):
    with (base/f'20261003_d205_execution_metadata.{extension}').open('xb') as target:
        target.write((raw/f'metadata_cpu_probe.{extension}').read_bytes())

members = [(raw/name, name) for name in ('run_cpu.sh', 'run_cpu2.sh', 'probe.py', 'curate.py', 'check_staged.py')]
for phase in scopes:
    for suffix in ('scope.txt', 'time.txt', 'memory_events.txt', 'swap.txt', 'memory_peak.txt',
                   'protected_before.json', 'protected_after.json', 'sources.sha256', 'sources.tar.gz'):
        members.append((raw/f'{phase}_{suffix}', f'{phase}_{suffix}'))
    members.append((raw/f'{phase}.log', f'{phase}.log'))
for name in ('scripts/ieee_tc_preflight.py', 'tests/test_ieee_tc_artifact_audit.py',
             'tests/test_ieee_tc_preflight.py', 'docs/ieee_tc/D205_NATIVE_EXECUTION_METADATA.md'):
    members.append((ROOT/name, name))
for source in probe['sources']:
    path = Path(source['path'])
    rel = path.relative_to('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages')
    members.append((path, 'installed_source/'+str(rel)))
bundle = base/'20261003_d205_analysis_sources.tar.gz'
hashes = {}
with tarfile.open(bundle, 'x:gz') as archive:
    for path, name in members:
        assert name not in hashes and path.is_file() and path.stat().st_size < 1024**2
        hashes[name] = digest(path)
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(bundle, 'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, sha in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == sha
with (base/'20261003_d205_analysis_sources.sha256').open('x') as file:
    file.write(digest(bundle)+'  '+bundle.name+'\n')
with (base/'20261003_d205_analysis_sources_members.json').open('x') as file:
    json.dump(dict(bundle=bundle.name, member_sha256=hashes, member_checks_pass=True), file, indent=2)
artifacts = [base/f'20261003_d205_execution_metadata.{ext}' for ext in ('json', 'csv')] + [doc, bundle]
result = dict(kind='d205_execution_metadata_evidence_verification_v1', passed=True,
              plan_sha256=check_plan(), protection=protection, scope_receipts=scopes,
              existing_preflight_ast_unchanged=True, serving_sources_unchanged=unchanged,
              metadata_cpu_cases=8, rejected_controls=34, tests_after_correction=384,
              failed_attempt_retained=True, syntax_smoke=True, gpu_measurement=False,
              numeric_correctness_qualified=False, n_correct=None,
              bundle_members=len(hashes), bundle_bytes=bundle.stat().st_size,
              artifacts={str(path.relative_to(ROOT)): digest(path) for path in artifacts})
with (base/'20261003_d205_evidence_verification.json').open('x') as file:
    json.dump(result, file, indent=2)
print(json.dumps(result))
