"""D467 one bounded native frontend boundary, reusing the existing guard."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest
import urllib.request

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW/name).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

def gpu_empty():
    assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
        '--format=csv,noheader'], text=True, timeout=10).strip()

def cpu():
    save('cpu_identity.json', p.scope_identity(p.cg_path().name))
    assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
    assert os.sched_getaffinity(0) == {2,3,26,27}
    gpu_empty()
    protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
    assert protected['pass'] and protected['entry_count'] == 147
    paths = [ROOT/'scripts/ieee_tc_preflight.py', ROOT/'tests/test_ieee_tc_frontend_preparation.py',
        ROOT/'scripts/dedicated_engine_worker.py', ROOT/'scripts/run_all_experiments.py',
        ROOT/'sitecustomize.py', ROOT/'configs/ieee_tc/20261012_d465_7b_full_w0.yaml', Path(__file__)]
    for path in paths:
        if path.suffix == '.py': ast.parse(path.read_text())
    started = time.monotonic()
    with (RAW/'cpu_tests.txt').open('x') as f:
        result = unittest.TextTestRunner(stream=f, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromNames([
                'tests.test_ieee_tc_frontend_preparation',
                'tests.test_ieee_tc_preflight', 'tests.test_ieee_tc_launch']))
    save('cpu_result.json', dict(passed=result.wasSuccessful(), tests=result.testsRun,
        failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
        elapsed_s=time.monotonic()-started, protected=protected,
        sources=[dict(path=str(x), sha256=p.digest(x)) for x in paths]))
    print(json.dumps(dict(passed=result.wasSuccessful(), tests=result.testsRun)), flush=True)
    assert result.wasSuccessful()
    refs=[]
    for name in ('docs/design/multiprocessing.md', 'vllm/platforms/cuda.py',
                 'vllm/v1/engine/utils.py', 'vllm/v1/engine/core_client.py'):
        url='https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/'+name
        path=RAW/('official_'+name.replace('/','_'))
        with urllib.request.urlopen(url, timeout=25) as response:
            data=response.read(1024*1024+1)
        assert 0 < len(data) <= 1024*1024
        with path.open('xb') as f:f.write(data)
        refs.append(dict(url=url,path=str(path),sha256=p.digest(path),bytes=len(data)))
    save('primary_sources.json',dict(retrieved_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),refs=refs))

def native():
    save('native_identity.json', p.scope_identity(p.cg_path().name))
    gpu_empty()
    test=json.loads((RAW/'cpu_result.json').read_text())
    assert test['passed'] and test['errors']==test['failures']==test['skipped']==0
    for ref in test['sources']:assert p.digest(Path(ref['path']))==ref['sha256']
    for name in ('PYTORCH_CUDA_ALLOC_CONF','PYTORCH_HIP_ALLOC_CONF','PYTHONPATH','PYTHONHOME'):
        os.environ.pop(name,None)
    os.environ['FAASLORA_TC_NVML_BINDING']='/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py'
    os.environ['FAASLORA_TC_NVML_SHA256']='4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea'
    rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid','--format=csv,noheader'],text=True).splitlines()
    selected=[line.split(',',1)[1].strip() for line in rows if line.split(',',1)[0].strip()=='0']
    assert len(selected)==1
    mask=selected[0]
    receipt=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/runtime_20260926/cuda_import_attempt3.json')
    assert p.digest(receipt)=='cf38bbf8d3b80b30d88ac38e27722d389a24ae516565708cfc924937589079cf'
    command=['/usr/bin/env','CUDA_VISIBLE_DEVICES='+mask,'FAASLORA_VISIBLE_DEVICES='+mask,
        'PYTHONPATH='+str(ROOT),'PYTHONUNBUFFERED=1','VLLM_WORKER_MULTIPROC_METHOD=spawn',
        'OMP_NUM_THREADS=1','MKL_NUM_THREADS=1','VLLM_NO_USAGE_STATS=1',
        'FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY=uncached_background_v1',
        'PYTORCH_ALLOC_CONF=pinned_max_cached_size_mb:0,pinned_use_background_threads:True',
        '/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python','-B',
        str(ROOT/'scripts/ieee_tc_preflight.py'),'backend-frontend-check',
        '--runtime-receipt',str(receipt), '--config',
        str(ROOT/'configs/ieee_tc/20261012_d465_7b_full_w0.yaml'),
        '--output',str(RAW/'native_frontend.json')]
    result=p.gated_launch(command,RAW/'native_launch.json',predicted_growth=64*p.MIB)
    save('native_launch.json',result)
    print(json.dumps(dict(passed=result['pass'],service=result.get('service_unit'))),flush=True)
    assert result['pass']
    gpu_empty()

if __name__ == '__main__':
    {'cpu':cpu,'native':native}[sys.argv[1]]()
