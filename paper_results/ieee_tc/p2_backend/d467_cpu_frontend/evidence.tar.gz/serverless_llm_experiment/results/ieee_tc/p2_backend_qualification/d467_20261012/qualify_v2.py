"""Keep first-suite evidence; use the qualified system Python for PID-fd gates."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import unittest
import urllib.request
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
def native():
    save('native_identity.json',p.scope_identity(p.cg_path().name))
    assert sys.executable=='/usr/bin/python3'
    p.require_watchdog_primitives()
    old=json.loads((RAW/'cpu_result.json').read_text())
    assert (old['tests'],old['failures'],old['errors'],old['skipped'])==(272,2,2,0)
    for ref in old['sources']:assert p.digest(Path(ref['path']))==ref['sha256']
    log=(RAW/'cpu_tests.txt').read_text()
    failed={name for name in re.findall(r'^(?:FAIL|ERROR): (test_\w+)',log,re.M)}
    expected={'test_scope_identity_change_never_signals','test_tiny_gate_cannot_be_used_to_launch_an_unbounded_model',
        'test_launch_cannot_start_model_before_auxiliary_limits_exist','test_live_install_prevents_overlapping_model_launch'}
    assert failed==expected and 'interpreter lacks PID-handle signaling' in log
    assert json.loads((RAW/'cpu_closure.json').read_text())['actual_recursive_procs_empty']
    names=['tests.test_ieee_tc_preflight.ProtocolGates.'+name for name in sorted(expected)]
    with (RAW/'system_guard_tests.txt').open('x') as f:
        tests=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
    save('cpu_qualification.json',dict(passed=tests.wasSuccessful(),unique_tests=272,
        prior_passed=268,rechecked_system_guard_tests=tests.testsRun,failures=len(tests.failures),
        errors=len(tests.errors),skipped=len(tests.skipped),first_attempt_preserved=True,
        original_result_sha256=p.digest(RAW/'cpu_result.json'),original_log_sha256=p.digest(RAW/'cpu_tests.txt'),
        source_refs=old['sources'],system_python=sys.executable,
        diagnosis='The four guard tests require signal.pidfd_send_signal, absent from the LLM conda Python; no production/test changes.'))
    assert tests.wasSuccessful() and tests.testsRun==4
    refs=[]
    for name in ('docs/design/multiprocessing.md','vllm/platforms/cuda.py',
                 'vllm/v1/engine/utils.py','vllm/v1/engine/core_client.py'):
        url='https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/'+name
        path=RAW/('official_'+name.replace('/','_'))
        with urllib.request.urlopen(url,timeout=25) as response:data=response.read(1024*1024+1)
        assert 0<len(data)<=1024*1024
        with path.open('xb') as f:f.write(data)
        refs.append(dict(url=url,path=str(path),sha256=p.digest(path),bytes=len(data)))
    save('primary_sources.json',dict(retrieved_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),refs=refs))
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    for name in ('PYTORCH_CUDA_ALLOC_CONF','PYTORCH_HIP_ALLOC_CONF','PYTHONPATH','PYTHONHOME'):
        os.environ.pop(name,None)
    os.environ['FAASLORA_TC_NVML_BINDING']='/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py'
    os.environ['FAASLORA_TC_NVML_SHA256']='4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea'
    rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid','--format=csv,noheader'],text=True).splitlines()
    selected=[line.split(',',1)[1].strip() for line in rows if line.split(',',1)[0].strip()=='0']
    assert len(selected)==1
    mask=selected[0]
    receipt=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/runtime_20260926/cuda_import_attempt3.json')
    assert p.digest(receipt)=='cf38bbf8d3b80b30d88ac38e27722d389a24ae516565708cfc924937589079cf'
    command=['/usr/bin/env','CUDA_VISIBLE_DEVICES='+mask,'FAASLORA_VISIBLE_DEVICES='+mask,
        'PYTHONPATH='+str(ROOT),'PYTHONUNBUFFERED=1','VLLM_WORKER_MULTIPROC_METHOD=spawn',
        'OMP_NUM_THREADS=1','MKL_NUM_THREADS=1','VLLM_NO_USAGE_STATS=1',
        'FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY=uncached_background_v1',
        'PYTORCH_ALLOC_CONF=pinned_max_cached_size_mb:0,pinned_use_background_threads:True',
        '/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python','-B',
        str(ROOT/'scripts/ieee_tc_preflight.py'),'backend-frontend-check','--runtime-receipt',str(receipt),
        '--config',str(ROOT/'configs/ieee_tc/20261012_d465_7b_full_w0.yaml'),
        '--output',str(RAW/'native_frontend.json')]
    started=time.monotonic()
    result=p.gated_launch(command,RAW/'native_launch.json',predicted_growth=64*p.MIB)
    save('native_launch.json',result)
    save('supervisor_elapsed.json',dict(elapsed_s=time.monotonic()-started,
        caveat='Includes safety preflight, process launch, driver observations, imports and cleanup; not activation latency.'))
    print(json.dumps(dict(passed=result['pass'],service=result.get('service_unit'))),flush=True)
    assert result['pass']
if __name__=='__main__':native()
