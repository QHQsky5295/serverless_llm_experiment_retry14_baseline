"""Retain the actual fixed-UUID CPU boundary, failures, resources and sources."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d467_cpu_frontend'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def write(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);write(RAW/'curation_identity.json',identity)
assert os.environ['CUDA_VISIBLE_DEVICES']=='' and os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
cpu=read(RAW/'cpu_qualification.json');assert cpu['passed'] and cpu['unique_tests']==272
native=read(RAW/'native_frontend.json');launch=read(RAW/'native_launch.json')
assert native['pass'] and native['stage']=='complete' and not native['formal_performance_result']
assert launch['pass'] and launch['service_returncode']==launch['watchdog_returncode']==0
assert launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
assert not Path(launch['service_identity']['path']).exists()
for name in ('cpu','native'):
    closure=read(RAW/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty']
    assert not Path(closure['identity']['path']).exists()
for ref in cpu['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
assert p.digest(ROOT/'scripts/ieee_tc_preflight.py')==native['check_source_sha256']
for name,sha in launch['evidence_sha256'].items():assert p.digest(RAW/'native_launch.launch'/name)==sha
with (RAW/'native_launch.launch/watchdog.jsonl').open() as f:events=[json.loads(line) for line in f]
samples=[event for event in events if event['event']=='resource_sample']
assert len(samples)==22
censuses=[]
for event in events:
    for key,value in event.items():
        if isinstance(value,dict) and value.get('source')=='nvml_v3_compute_and_graphics':
            censuses.append(value)
assert len(censuses)>=len(samples)
for value in censuses:
    assert value['service_native_contexts_clear'] and not value['service_held_gpu_uuids']
    assert not value['foreign_compute_processes'] and not value['escaped_owned_processes']
for observation in native['observations']:
    assert not observation['torch_cuda_initialized']
    assert observation['primary_active']==observation['current_context']==0
    assert observation['cuda_visible_devices']==native['native_uuid']
assert len(native['observations'])==5 and native['descriptor']['engine_none']
resource=dict(samples=len(samples),gpu_censuses=len(censuses),
    max_observed_service_peak_bytes=max(s['service']['memory.peak'] for s in samples),
    min_host_available_bytes=min(s['host']['available_bytes'] for s in samples),
    max_swap_bytes=max(s['service']['memory.swap.current'] for s in samples),
    max_memory_events={k:max(s['service']['memory.events'][k] for s in samples)
        for k in ('high','max','oom','oom_kill')},
    native_gpu_contexts_observed=0,
    warning_samples=sum(s['decision']['warning'] for s in samples))
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
preserved={str(path):p.digest(path) for path in (Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
    ROOT/'configs/generated/lora_manifest_1000.json')}
assert preserved[str(ROOT/'configs/generated/lora_manifest_1000.json')]=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
primary=read(RAW/'primary_sources.json')
for ref in primary['refs']:assert p.digest(Path(ref['path']))==ref['sha256']
OUT.mkdir(parents=True,exist_ok=False)
for name in ('native_frontend.json','native_launch.json','cpu_result.json','cpu_qualification.json',
             'cpu_tests.txt','system_guard_tests.txt','primary_sources.json','cpu_closure.json','native_closure.json'):
    with (OUT/name).open('xb') as f:f.write((RAW/name).read_bytes())
summary=dict(kind='d467_cpu_frontend_qualification_summary_v1',passed=True,
    decision='Fixed-UUID CPU preparation boundary qualified; lifecycle integration and performance remain unqualified.',
    source_result_sha256=p.digest(RAW/'native_frontend.json'),resource=resource,
    checkpoints=5,unique_cpu_tests=272,new_cpu_tests=13,
    existing_background_python_threads=['humming-bg-build-reaper','humming-bg-build-reaper'],
    no_fork_no_engine_no_weights_no_remote_no_replay=True,
    production_request_path_changed=False,D463_performance_accepted=False,
    limitations=['No allocation, ready, cancellation or reuse handshake is implemented by this diagnostic.',
        'Five in-process checkpoints and sampled NVML census do not establish absence of every possible transient context.',
        'Unchanged sitecustomize ran before the first in-process checkpoint.',
        'CUDA driver initialization is present in this qualification only; it retains no context.',
        'No measured end-to-end improvement or amortized per-frontend memory claim.'])
write(OUT/'summary.json',summary)
paths=[RAW/name for name in ('qualify.py','qualify_v2.py','close.py','curate.py',
    'cpu_identity.json','native_identity.json','supervisor_elapsed.json')]
paths += list((RAW/'native_launch.launch').iterdir())
paths += [Path(ref['path']) for ref in primary['refs']]
paths += [ROOT/name for name in ('scripts/ieee_tc_preflight.py','tests/test_ieee_tc_frontend_preparation.py',
    'scripts/run_all_experiments.py','scripts/dedicated_engine_worker.py','sitecustomize.py',
    'faaslora/metrics/metrics_collector.py','configs/ieee_tc/20261012_d465_7b_full_w0.yaml')]
site=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages')
paths += [site/name for name in ('vllm/platforms/cuda.py','vllm/platforms/__init__.py',
    'vllm/v1/engine/utils.py','vllm/v1/engine/core_client.py')]
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for path in paths:
        assert path.is_file()
        data=path.read_bytes();name=str(path).removeprefix('/home/qhq/')
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644
        tar.addfile(entry,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest())
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
write(OUT/'manifest.json',dict(kind='d467_delivery_manifest_v1',passed=True,scope=identity,
    preserved=preserved,protected=protected,archive_members=members,
    outputs={path.name:p.digest(path) for path in OUT.iterdir()},
    source_refs=cpu['source_refs'],new_performance_run=False,production_path_changed=False))
print(json.dumps(dict(passed=True,summary=summary,archive_bytes=(OUT/'evidence.tar.gz').stat().st_size)))
