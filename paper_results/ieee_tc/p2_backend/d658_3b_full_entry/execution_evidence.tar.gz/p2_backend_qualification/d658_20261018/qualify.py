"""D658 bounded CPU assembly qualification; no GPU or source-matrix repeat."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path, obj):
    with path.open('x') as stream:
        json.dump(obj, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([MAIN], 16*1024*1024)
save(RAW/'resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
shell = MAIN/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
subprocess.run(['bash', '-n', str(shell)], check=True)
source = shell.read_text()
start = source.index('  d659)\n')
end = source.index('    ;;\n', start)+len('    ;;\n')
restored = source[:start]+source[end:]
# New model-specific overrides may not alter any historic campaign branch.
marker = 'if [[ "${1:-d293}" == d659 ]]; then\n'
assert restored.count(marker) == 2
for _ in range(2):
    start = restored.index(marker)
    end = restored.index('\nfi\n', start)+len('\nfi\n')
    restored = restored[:start]+restored[end:]
assert restored == subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(MAIN))],cwd=MAIN,text=True)
for path in (MAIN/'scripts/ieee_tc/prepare_d298_capacity.py', MAIN/'tests/test_ieee_tc_3b_full_candidate.py', Path(__file__)):
    ast.parse(path.read_text())
commands = [
    [sys.executable,'-B','-m','unittest','tests.test_ieee_tc_3b_full_candidate','-v'],
    [sys.executable,'-B','-m','scripts.ieee_tc.prepare_d298_capacity','--3b-full-candidate'],
]
steps=[]
for index, command in enumerate(commands):
    log=RAW/f'qualification_step{index}.log'
    with log.open('x') as stream:
        rc=subprocess.run(command,cwd=MAIN,stdout=stream,stderr=subprocess.STDOUT).returncode
    step=dict(command=command,returncode=rc,log=str(log),sha256=p.digest(log))
    steps.append(step)
    save(RAW/f'step{index}.json',step)
    if rc:
        raise RuntimeError(f'CPU qualification step {index} failed; retain log and do not launch')
prepared=MAIN/'paper_results/ieee_tc/p2_backend/d658_3b_full_entry/preparation.json'
record=json.loads(prepared.read_text())
assert record['passed'] and record['new_gpu_runs']==0 and not record['full_qualified']
assert record['source_plan']['count']==100
config=Path(record['configuration']['path'])
assert p.digest(config)==record['configuration']['sha256']
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
paths=[Path(__file__),shell,prepared,config,MAIN/'scripts/ieee_tc/prepare_d298_capacity.py',
    MAIN/'tests/test_ieee_tc_3b_full_candidate.py', MAIN/'scripts/run_all_experiments.py',
    MAIN/'faaslora/experiment/instance_pool.py', MAIN/'faaslora/preloading/preloading_planner.py',
    MAIN/'faaslora/datasets/workload_generator.py', MAIN/'configs/ieee_tc/native_toolchain_cuda130_v1.json']
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
save(RAW/'qualification.json',dict(passed=True,tests=6,steps=steps,identity=identity,
    resources=resources,protected=protected,refs={str(x):p.digest(x) for x in paths},
    no_gpu_run=True,unchanged_historical_shell_branches=True,unchanged_production_semantics=True))
print(json.dumps(dict(passed=True,tests=6,resources=resources)))
