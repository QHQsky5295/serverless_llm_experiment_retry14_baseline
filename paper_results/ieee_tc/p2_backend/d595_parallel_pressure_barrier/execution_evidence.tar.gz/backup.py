"""Explicit tested-candidate checkpoint; retain aborted CPU test evidence too."""
import hashlib,json,os,re,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'backup_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'
reg=read(RAW/'regression2_receipt.json');focused=read(RAW/'focused_receipt.json')
assert reg['passed'] and focused['passed']
for path,sha in reg['sources'].items():assert p.digest(Path(path))==sha
for name in ('focused','regression2'):
    closure=read(RAW/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
stopped=read(RAW/'regression_stopped.json')
assert stopped['passed'] is False and stopped['stop_completed'] and stopped['path_gone']
assert not Path(stopped['identity']['path']).exists()
preserved={ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(path)==sha
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def secret_check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members=[RAW/name for name in ('run_tests.py','run_regression_qualified.py','stop_regression.py','close.py','backup.py',
    'focused_identity.json','focused_gate.json','focused.log','focused_receipt.json','focused_closure.json',
    'regression_identity.json','regression_gate.json','regression.log','regression_stop_before.json','regression_stopped.json',
    'regression2_identity.json','regression2_gate.json','regression2.log','regression2_receipt.json','regression2_closure.json',
    'focused_source.tar.gz','regression_source.tar.gz','regression2_source.tar.gz')]
for path in members:
    if path.name.endswith('.tar.gz'):
        with tarfile.open(path) as bundle:
            for member in bundle.getmembers():
                if member.isfile():secret_check(bundle.extractfile(member).read())
    else:secret_check(path.read_bytes())
OUT.mkdir(parents=True,exist_ok=False)
with tarfile.open(OUT/'execution_evidence.tar.gz','x:gz') as bundle:
    for path in members:bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(OUT/'execution_evidence.tar.gz') as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
test_counts={name:int(re.search(r'Ran (\d+) tests', (RAW/(name+'.log')).read_text()).group(1))
    for name in ('focused','regression2')}
record=dict(passed=True,production_candidate=True,native_gpu_validation=False,full_performance_run=False,
    parent_commit='023ae0079e0b2ffa537a81bda7855e8a4b8ede95',
    policy='parallel_owner_barrier_v1',test_counts=test_counts,regression=reg,
    focused_before_metadata=focused,aborted_cpu_regression=stopped,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='CPU ownership/cancellation regression only; no native GPU or end-to-end performance improvement claim.')
save(OUT/'qualification.json',record)
with (OUT/'result.sha256').open('x') as f:
    for name in ('qualification.json','execution_evidence.tar.gz'):f.write(p.digest(OUT/name)+'  '+name+'\n')
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',
    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']
names += [str((OUT/name).relative_to(ROOT)) for name in ('qualification.json','execution_evidence.tar.gz','result.sha256')]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names:secret_check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','Overlap independent native pressure acknowledgements with all-settled barriers (D595)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'backup_receipt.json',dict(passed=True,identity=identity,head=head,remote=remote,files=names))
print(json.dumps(dict(passed=True,head=head,files=len(names),test_counts=test_counts,remote_equal=True)))
