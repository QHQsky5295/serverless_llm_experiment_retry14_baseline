"""D594 exact-identity empty-only closure; never kill an active worker."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
phase=sys.argv[1];assert phase in ('focused','regression','regression2','backup')
identity=json.loads((RAW/(phase+'_identity.json')).read_text())
assert p.scope_still_owned(identity)
cg=Path(identity['path']);members={str(f):f.read_text().split() for f in cg.rglob('cgroup.procs')}
assert members and all(not value for value in members.values())
resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert not cg.exists()
with (RAW/(phase+'_closure.json')).open('x') as f:
    json.dump(dict(passed=True,actual_recursive_procs_empty=True,path_gone=True,
        identity=identity,resources=resources),f,indent=2)
print(json.dumps(dict(passed=True,phase=phase,resources=resources)))
