"""D549's qualified interpreter/module order; preserve aborted first attempt."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'run_tests.py').read_text()
source=source.replace("phase in ('focused','regression')", "phase in ('regression2',)")
source=source.replace("['tests.test_ieee_tc_transfer_pressure',\n        'tests.test_ieee_tc_cpu_frontend_integration','tests.test_ieee_tc_launch']",
    "['tests.test_ieee_tc_launch','tests.test_ieee_tc_cpu_frontend_integration','tests.test_ieee_tc_transfer_pressure']")
exec(compile(source,str(RAW/'run_regression_qualified_reused.py'),'exec'),
    {'__name__':'__main__','__file__':str(Path(__file__))})
