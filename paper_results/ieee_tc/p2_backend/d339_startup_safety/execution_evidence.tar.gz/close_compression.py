"""Close only the completed D339 compression scope and retain its final counters."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

identity = json.loads((RAW/'resources.json').read_text())['identity']
assert p.scope_still_owned(identity)
group = Path(identity['path'])
assert not p.owned_pids(group)
resources = {name:(group/name).read_text().strip() for name in
    ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
assert resources['cgroup.events'].splitlines()[0] == 'populated 0'
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
inactive = subprocess.check_output(['systemctl','--user','show',identity['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
assert inactive
with (RAW/'compression_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,final_resources=resources,inactive=inactive),f,indent=2)
print(json.dumps(dict(inactive=inactive,final_resources=resources)))
