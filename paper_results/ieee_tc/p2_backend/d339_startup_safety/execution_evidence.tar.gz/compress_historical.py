"""Reuse D307/D323 lossless gzip procedure for three audited, closed raw logs."""
import hashlib
import importlib.util
import json
import os
import stat
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
spec = importlib.util.spec_from_file_location('prior', '/home/qhq/experimental_cleanup_20260916/cleanup.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
TARGETS = [
    ('d99_20260928/3b_full_w0_attempt6', '466863affe476867f34c9c628b12da14b8f187748925edfcfda390571640ad5e',
     '20260928_d99_3b_full_w0_attempt6.json'),
    ('d133_20261001/7b_full_w0_full1', '24d66641e05a19e429e53510a96c4dd10583d597dc2c108a8da5e10ff062f0a9',
     '20261001_d133_7b_full_w0_interrupted.json'),
    ('d98_20260928/3b_full_w0_attempt5', '9a782a2c84a3483fa4390fe97f66d7d467fda937a4377dbb7686b37eeb5bce09',
     '20260928_d98_3b_full_w0_attempt5.json'),
]

def save(name, obj):
    with (RAW/name).open('x') as f:
        json.dump(obj, f, indent=2)
        f.flush()
        os.fsync(f.fileno())

def decompressed_sha(archive):
    h = hashlib.sha256()
    with subprocess.Popen(['gzip','-dc','--',str(archive)],stdout=subprocess.PIPE) as process:
        while block := process.stdout.read(4*1024**2):
            h.update(block)
        assert process.wait() == 0
    return h.hexdigest()

unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])
def resources():
    return {k:(group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events')}
before = resources()
assert before['memory.high'] == str(3*1024**3) and before['memory.max'] == str(4*1024**3)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
plan_sha = p.check_plan()
git_before = prior.helpers.git_guard()
seal_path = ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json'
seal_before = p.verify_seal(seal_path)
assert seal_before['entry_count'] == 147 and seal_before['changed'] == ['/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py']
disk_before = prior.usage()
audited, done = [], []
try:
    for run, expected, curated_name in TARGETS:
        launch = ROOT/'results/ieee_tc/p2_backend_qualification'/run
        source = (launch/'launch.launch/physical_deployment/main_outcome.json').resolve(strict=True)
        archive = source.with_suffix('.json.gz')
        assert not archive.exists()
        stamp = prior.stamp(source)
        assert stat.S_ISREG(stamp['mode']) and stamp['uid'] == os.getuid() and stamp['nlink'] == 1
        prior.no_active(source)
        assert not any(Path(line.split()[4]) == source for line in Path('/proc/self/mountinfo').read_text().splitlines())
        launch_result = json.loads((launch/'launch.json').read_text())
        assert launch_result['service_path_removed'] is True
        assert launch_result['native_gpu_context_release_confirmed'] is True
        assert type(launch_result['service_returncode']) is int
        curated = ROOT/'paper_results/ieee_tc/p2_backend'/curated_name
        body = curated.read_text()
        assert expected in body and ('/'+run+'/') in body
        assert p.digest(source) == expected and prior.stamp(source) == stamp
        assert str(source) not in seal_path.read_text()
        audited.append(dict(run=run,source=str(source),archive=str(archive),stamp=stamp,
            source_sha256=expected,curated=str(curated),curated_sha256=p.digest(curated),
            launch_sha256=p.digest(launch/'launch.json'),
            original_pass=launch_result['pass'],service_returncode=launch_result['service_returncode'],
            physical_release_confirmed=True))
    save('audit.json',dict(plan_sha256=plan_sha,entries=audited,before=disk_before,identity=identity,
        references='Existing curated source SHA preserved; archive location recorded. gzip -dc reconstructs exact bytes; no inference rerun.',
        process_visibility='qhq-owned fd/maps/cwd/argv via existing helper; not privileged global visibility.',
        method='D307/D323 gzip -1 -k; gzip -t; two decompressed hashes, second original hash before unlink.'))
    for index, row in enumerate(audited):
        source, archive = Path(row['source']), Path(row['archive'])
        prior.no_active(source)
        assert prior.stamp(source) == row['stamp']
        subprocess.run(['gzip','-1','-k','--',str(source)],check=True)
        subprocess.run(['gzip','-t','--',str(archive)],check=True)
        first = decompressed_sha(archive)
        assert first == row['source_sha256'] == p.digest(source)
        second = decompressed_sha(archive)
        assert first == second and prior.stamp(source) == row['stamp']
        prior.no_active(source)
        astat = prior.stamp(archive)
        assert stat.S_ISREG(astat['mode']) and astat['nlink'] == 1
        result = dict(**row,archive_sha256=p.digest(archive),archive_bytes=astat['size'],
            archive_allocated_bytes=astat['blocks']*512,first_roundtrip=first,second_roundtrip=second)
        save(f'{index}_verified_before_unlink.json',result)
        assert prior.stamp(source) == row['stamp']
        source.unlink()
        assert not source.exists() and archive.is_file()
        done.append(dict(**result,uncompressed_duplicate_removed=True,
            allocated_bytes_reclaimed=row['stamp']['blocks']*512-astat['blocks']*512))
        save(f'{index}_complete.json',done[-1])
        print(json.dumps(dict(run=row['run'],freed_bytes=done[-1]['allocated_bytes_reclaimed'])),flush=True)
    assert git_before == prior.helpers.git_guard()
    assert p.verify_seal(seal_path) == seal_before
    save('summary.json',dict(kind='lossless_existing_result_compression_v1',entries=done,
        before=disk_before,after=prior.usage(),protected_seal=seal_before,
        unchanged='Weights, artifacts, traces, environments, source code, submitted results and curated outputs unchanged.',
        failed_runs_remain_failures=True,new_gpu_run=False,new_heavy_start_floor_bytes=150*1024**3,
        allocated_bytes_reclaimed=sum(x['allocated_bytes_reclaimed'] for x in done)))
finally:
    save('resources.json',dict(identity=identity,before=before,after=resources(),completed=len(done)))
