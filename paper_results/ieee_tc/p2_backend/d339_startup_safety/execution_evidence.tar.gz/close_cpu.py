"""Close the exact D339 CPU scope and the earlier rejected name-only launcher."""
import json
import subprocess
import sys
from pathlib import Path
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity = json.loads((RAW/'candidate_cpu1.json').read_text())['identity']
assert p.scope_still_owned(identity) and not p.owned_pids(Path(identity['path']))
group = Path(identity['path'])
resources = {k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
old_unit = 'primelora-tc-aux-d339-cpu1.scope'
old_group = group.parent/old_unit
assert old_group.stat().st_ino == 20451642 and not p.owned_pids(old_group)
assert subprocess.check_output(['systemctl','--user','show',old_unit,'-p','InvocationID','--value'],text=True).strip() == '6bb89982ca314826b0bc74e8ff68bc2d'
subprocess.run(['systemctl','--user','stop',old_unit],check=True)
for unit in (identity['unit'],old_unit):
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (RAW/'cpu_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,inactive=True,
        launcher_attempt0=dict(unit=old_unit,invocation_id='6bb89982ca314826b0bc74e8ff68bc2d',
            error='Scope name lacked required UUID; stopped before imports/tests.',inactive=True)),f,indent=2)
print(json.dumps(dict(cpu_scopes_inactive=True,resources=resources)))
