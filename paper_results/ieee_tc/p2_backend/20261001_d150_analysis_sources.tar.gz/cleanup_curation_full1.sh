#!/usr/bin/env bash
set -euo pipefail
# Post-exit absence receipt, not a manual stop: this actual scope was removed
# automatically. Final cgroup counters no longer exist and are not invented.
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d150_20261001
unit=primelora-d150-full1-curate-20261001.scope
date -Is
rg -qx 'InvocationID=ff8b1f86b3104b979f6bcc362626a19e' "$raw/full_full1_curation_scope.txt"
rg -q 'Exit status: 0' "$raw/full_full1_curation_time.txt"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
