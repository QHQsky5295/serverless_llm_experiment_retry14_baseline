#!/usr/bin/env bash
set -euo pipefail
# Post-exit absence receipt, not a manual stop: this actual scope was removed
# automatically. Final cgroup counters no longer exist and are not invented.
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d150_20261001
unit=primelora-d150-full1-evidence1-20261001.scope
date -Is
rg -qx 'InvocationID=f7d39e71a2354258ab749c5c5f47075c' "$raw/full_full1_evidence_scope.txt"
rg -q 'Exit status: 0' "$raw/full_full1_evidence_time.txt"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
