#!/usr/bin/env bash
set -euo pipefail
# Existing D148 exact-identity cleanup, bound to this actual activation.
# Execute remotely ONLY after local terminal and physical GPU cleanup.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d150full1.service)
ids=(04d60463d9a34e31ba533689e5cf91c7 c7f02aae303a4d24b0f39d09b2a34150 64859df2a13c4685be679d504e8a0015)
pids=(2429650 2429652 2429655)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result
