"""D150 ordinary Full: reuse D148 launch/config and frozen evidence map."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight
from faaslora.runtime_configuration import resolve_facade_lora_capacity

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d150_20261001'
previous = root/'results/ieee_tc/p2_backend_qualification/d148_20261001'
expected_commit = '9c73e33ad4c68d27d881f47ac81af8d579ec0f3b'
prior_runtime = '1eaf15a4eb82abd847b6b8cd08eff97b06b6ef24'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected_commit
dirty = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty) <= {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'}, dirty
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old_path = previous/'7b_main_config_full1.yaml'
new_path = raw/'7b_main_config_full1.yaml'
old, new = [yaml.safe_load(path.read_text()) for path in (old_path,new_path)]
for config in (old,new):
    assert config['workload']['total_requests'] == 4000
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
assert old == new, 'configuration differs beyond three fresh owned paths'
assert not (raw/'7b_full_w0_full1').exists()
assert not (raw/'7b_nvme_full1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d150-7b-full1/tc_ieee_full').exists()
prior = root/'results/ieee_tc/p2_backend_qualification/d148_20261001/prelaunch_verification.json'
assert digest(prior) == '454b8d102e011cd91baeae4eb5a27f019fa1cc0de042bc32270c355902031c59'
refs = dict(json.loads(prior.read_text())['source_sha256'])
allowed_changes = {'scripts/run_all_experiments.py', 'tests/test_ieee_tc_request_lifecycle.py'}
changes = []
for name, expected in tuple(refs.items()):
    path = Path(name) if name.startswith('/') else root/name
    actual = digest(path)
    if actual != expected:
        relative = str(path.relative_to(root))
        assert relative in allowed_changes, (name, expected, actual)
        old_source = subprocess.check_output(['git','show',prior_runtime+':'+relative],cwd=root)
        new_source = subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)
        assert hashlib.sha256(old_source).hexdigest() == expected, relative
        assert hashlib.sha256(new_source).hexdigest() == actual, relative
        changes.append(dict(path=relative,before=expected,after=actual))
        refs[name] = actual
for relative in allowed_changes:
    path = root/relative
    assert digest(path) == hashlib.sha256(subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)).hexdigest()
    refs[str(path)] = digest(path)
candidate = root/'paper_results/ieee_tc/p2_backend/20261001_d149_selected_source_projection.json'
assert digest(candidate) == '8a3025bbb0cc5ece1d576d9897f9d9b4171964f9a611f4ed77e65b91469c2700'
qualification = json.loads(candidate.read_text())
assert qualification['regression_tests'] == 700
assert qualification['complete_inventory_validation_preserved']
assert not qualification['budgets_changed']
assert not qualification['reading_cache_added']
assert qualification['performance_gain_established'] is False
model = resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras'] == 24 and model['runtime_concurrency_cap'] == 2
assert model['max_num_seqs'] == 2 and model['max_loras'] == 4
for key in ('ieee_service_profile','ieee_preparation_profile'):
    binding = new['resource_coordination'][key]
    assert digest(Path(binding['path'])) == binding['sha256']
full_before = json.loads((previous/'prelaunch_verification.json').read_text())
trace, subset = full_before['trace'], full_before['subset']
assert trace['count'] == trace['source_count'] == 4000 and trace['profile'] == 'W0'
assert trace['view_sha256'] == 'a5331be2e2204483f18206825d9aaa18cbaa259fe0babfc303f989055819430d'
assert digest(Path(trace['source_path'])) == trace['source_sha256'] == 'efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
assert digest(Path(subset['path'])) == subset['sha256'] == 'aa94b21e1295aefde664e5b29c030a9e42e02af946369bfe9ae15336b89b3016'
for path in [raw/name for name in ('7b_main_config_full1.yaml','run_7b_full_w0_full1.sh',
    'activate_services_full1.sh','check_health.sh','verify_full1_prelaunch.py','prepare_full1.sh')]+[candidate,old_path,prior]:
    refs[str(path)] = digest(path)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
resources = preflight([root,raw],32*1024**3)
assert resources['preflight_pass'], resources['issues']
receipt = dict(kind='d150_7b_full_prelaunch_v1',time_unix=time.time(),
    run='d150_7b_full_w0_full1',evidence_commit=expected_commit,
    runtime_source_commit=expected_commit,source_change='D149 selected-source queries use the existing fully validated fresh frontend projection; physical admission unchanged',
    expected_source_changes=changes,same_configuration_except_owned_paths=True,
    diagnostic_instrumentation=False,formal_performance_result=False,
    source_sha256=refs,protected=protected,resource_preflight=resources,trace=trace,subset=subset,
    replay_scope='ordinary_full_4000',diagnostic_prefix_count=None,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    comparison='Full development validation against D148; single-candidate one-run descriptive comparison, no causal CI or formal ranking',
    hypothesis='Projecting fresh validated selected-source observations before parent transfer reduces centralized validation/message overhead without stale state or changing ownership',
    detailed_cpu_profiler=False,
    pending_metric_reconciliation='Preserve controller completion and outer terminal separately',
    reused_initialization='D88/D89; same D148 7B parent config, no new profiles/data/cache',
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),
    sha256=digest(raw/'prelaunch_verification.json'),protected=147,source_refs=len(refs),
    population=4000,same_config=True,resource_pass=True,formal=False,changes=changes)))
