#!/usr/bin/env bash
set -euo pipefail
unit=primelora-tc-aux-5470a89aabd847c49a40b7b5c427b3b0.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 13efd326658647e38e9832a3ab55515e
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-5470a89aabd847c49a40b7b5c427b3b0.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
