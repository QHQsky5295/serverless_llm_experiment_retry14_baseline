"""Reuse D824 explicit-path backup checks for the closed D827 component."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d824_20261025/backup.py')
code = source.read_text()
changes = {
    'd824_current_ingress_pending': 'd827_workspace_retirement',
    '107185c45f49a891c0b391b1140b7d765e83daea': 'de048c01f1c6310983b3ed896ad44b08e55c9688',
    "OUT/'final_manifest.json'": "OUT/'manifest.json'",
    'D824_CURRENT_INGRESS_AND_CONTROL_20261025.md': 'D827_WORKSPACE_RETIREMENT_PROFILE_20261025.md',
    'len(set(paths)) == 20': 'len(set(paths)) == 6',
    'backup/d824-current-ingress-control-20261025': 'backup/d827-workspace-retirement-20261025',
    'tc: preserve current 3B ingress and actual scaling-trigger diagnosis (D824)':
        'tc: retain complete workspace retirement profile and close local cleanup direction (D827)',
}
for old, new in changes.items():
    assert code.count(old) == 1, old
    code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
