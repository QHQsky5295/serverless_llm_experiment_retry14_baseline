"""Reuse D605/D627/D825 component harness; profile retirement without serving edits."""
from pathlib import Path

driver = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d825_20261025/component.py')
header = driver.read_text().split('rows = []', 1)[0]
exec(compile(header, str(driver), 'exec'))

metadata = Path('/tmp/tc-d557-7bv/remote_artifacts')
launch = json.loads((RAW.parent.parent / 'vllm_qualification/d557_20261016/launch7b.json').read_text())
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not Path(launch['service_identity']['path']).exists()
prior = json.loads((RAW.parent / 'd826_20261025/finish_identity.json').read_text())
assert not Path(prior['path']).exists()
metadata_before = module._local_file_inventory({'retained_metadata': metadata})
archive_source = source_files[0]
archive_bytes = archive_source.stat().st_size
rows = []
for with_metadata in (False, True):
    for repeat in range(3):
        with tempfile.TemporaryDirectory(prefix='tc-d827-retirement-') as directory:
            nvme = Path(directory) / 'nvme'
            nvme.mkdir()
            roots = {'nvme': nvme}
            if with_metadata:
                roots['retained_metadata'] = metadata
            owner = module.LocalSourceReferences(roots)
            owner.lock = MeasuredLock()
            target = nvme / source.name
            phases = {}
            with owner.materializing(target, budgeted=True) as transfer:
                with contextlib.ExitStack() as wrappers:
                    def timed(name, function):
                        def call(*args, **kwargs):
                            begin, cpu_begin = time.perf_counter(), time.thread_time()
                            try:
                                return function(*args, **kwargs)
                            finally:
                                phases.setdefault(name, []).append(dict(
                                    wall_ms=1000 * (time.perf_counter() - begin),
                                    cpu_ms=1000 * (time.thread_time() - cpu_begin)))
                        return call
                    wrappers.enter_context(patch.object(owner, '_file_inventory',
                        timed('inventory', owner._file_inventory)))
                    wrappers.enter_context(patch.object(http.shutil, 'rmtree',
                        timed('rmtree', http.shutil.rmtree)))
                    with owner.transfer_workspace(transfer) as staging:
                        owner.prepare_transfer(transfer, staging, archive_bytes, expected,
                                               limit_bytes=512 * 1024 * 1024)
                        archive = staging.parent / 'artifact.tar.gz'
                        with archive_source.open('rb') as reader, archive.open('r+b') as writer:
                            while chunk := reader.read(1024 * 1024):
                                writer.write(chunk)
                        archive_info = archive.stat()
                        archive_key = archive_info.st_dev, archive_info.st_ino
                        files = http._extract_verified(ExistingFileMembers(), staging, expected,
                            lambda: None, preallocated=True, verify_content=False)
                        receipt = owner.publish_transfer(transfer, staging, target,
                            http.publish_directory, verified_files=files)
                        assert receipt['content_verified'] and receipt['adapter_id'] == source.name
                        assert archive_key in owner._file_allocations
                        assert transfer in owner._prepared_transfers
                        assert not staging.exists() and target.exists()
                        phases.clear()
                        owner.lock.rows.clear()
                        begin, cpu_begin = time.perf_counter(), time.thread_time()
                    elapsed = 1000 * (time.perf_counter() - begin)
                    cpu_elapsed = 1000 * (time.thread_time() - cpu_begin)
                    assert len(owner.lock.rows) == 1
                    assert not archive.exists() and not staging.parent.exists()
                    assert transfer not in owner._prepared_transfers
                    assert transfer not in owner._transfer_workspaces
                    assert archive_key not in owner._file_allocations
                    assert len(phases['inventory']) == 1 and len(phases['rmtree']) == 1
                    rows.append(dict(with_metadata=with_metadata, repeat=repeat,
                        cleanup_wall_ms=elapsed, cleanup_thread_cpu_ms=cpu_elapsed,
                        lock=owner.lock.rows[0], nested_phases=phases.copy(),
                        content_sha256=receipt['content_sha256'],
                        archive_placeholder_bytes=archive_bytes,
                        workspace_removed=True, archive_inode_reservation_retired=True,
                        published_destination_preserved=True))
            assert not owner.materializations and not owner._transfer_workspaces
            assert owner.source_snapshot(source.name)['sources'][0]['content_verified']

assert module._local_file_inventory({'retained_metadata': metadata}) == metadata_before
for path, evidence in sources.items():
    assert p.digest(Path(path)) == evidence['sha256']
for path, sha in production.items():
    assert p.digest(Path(path)) == sha
assert p.verify_seal(seal)['pass']
import torch
assert not torch.cuda.is_initialized()
result = dict(kind='d827_workspace_retirement_component_v1', passed=True,
    rows=rows, source_files=sources, production_sources=production,
    metadata_source=str(metadata), metadata_unique_files=metadata_before['unique_file_count'],
    metadata_paths=sum(len(row['paths']) for row in metadata_before['allocations']),
    archive_placeholder='Existing adapter_config.json bytes, not a valid gzip or transfer measurement.',
    production_changed=False, new_gpu_replays=0, formal_performance=False,
    online_lock_wait_measured=False, n_correct=None, ranking_eligible=False,
    resources={name: (group/name).read_text().strip() for name in
               ('memory.peak', 'memory.events', 'memory.swap.current')})
save('component_result.json', result)
print(json.dumps(result, indent=2))
