"""Reuse D605 bounded component harness; profile real publication, no serving edit."""
from pathlib import Path
driver=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d605_20261017/compare_inventory.py')
header=driver.read_text().split('old_commit = ',1)[0]
old="RAW.parent.parent/'storage_maintenance/d604_20261017/storage_closure.json'"
assert header.count(old)==1
header=header.replace(old,"RAW.parent/'d626_20261017/publication_closure.json'")
exec(compile(header,str(driver),'exec'))
import tempfile
import threading
from faaslora.storage.http_artifact_store import _verified_file_signature, publish_directory

gate=p.preflight([ROOT],64*1024*1024)
save('component_resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
production=ROOT/'faaslora/memory/residency_manager.py'
production_sha=p.digest(production)
assert production_sha=='fd783131934664f1dee49f78b21366c2aff7264d60a15c2a9bcb975e207bec4f'
source=Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix/medical_lora_0062')
source_files=[source/'adapter_config.json',source/'adapter_model.safetensors']
sources={str(path):dict(sha256=p.digest(path),bytes=path.stat().st_size) for path in source_files}
expected={path.name:(sources[str(path)]['bytes'],sources[str(path)]['sha256']) for path in source_files}
# Existing closed metadata tree, read only. This is a cardinality component case,
# not a reconstruction of current W2 tier residency or a physical HOST cache.
metadata=Path('/tmp/tc-d557-7bv/remote_artifacts')
launch=json.loads((RAW.parent.parent/'vllm_qualification/d557_20261016/launch7b.json').read_text())
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not Path(launch['service_identity']['path']).exists()
metadata_before=module._local_file_inventory({'retained_metadata':metadata})

class MeasuredLock:
    def __init__(self):
        self.native=threading.RLock();self.local=threading.local();self.rows=[]
    def acquire(self,*args,**kwargs):
        start=time.perf_counter();ok=self.native.acquire(*args,**kwargs);end=time.perf_counter()
        if ok:
            depth=getattr(self.local,'depth',0)
            if depth==0:self.local.begin=end;self.local.wait=end-start
            self.local.depth=depth+1
        return ok
    def release(self):
        depth=self.local.depth
        if depth==1:self.rows.append(dict(thread=threading.get_ident(),
            wait_ms=1000*self.local.wait,held_ms=1000*(time.perf_counter()-self.local.begin)))
        self.local.depth=depth-1;self.native.release()
    def __enter__(self):self.acquire();return self
    def __exit__(self,*args):self.release()
    def _is_owned(self):return self.native._is_owned()

rows=[];checks=[]
for with_metadata in (False,True):
    for repeat in range(3):
        with tempfile.TemporaryDirectory(prefix='tc-d627-publication-') as directory:
            root=Path(directory);nvme=root/'nvme';nvme.mkdir()
            roots={'nvme':nvme}
            if with_metadata:roots['retained_metadata']=metadata
            owner=module.LocalSourceReferences(roots);owner.lock=MeasuredLock()
            target=nvme/source.name
            with owner.materializing(target,budgeted=True) as transfer:
                with owner.transfer_workspace(transfer) as staging:
                    owner.prepare_copy(transfer,staging,expected,limit_bytes=512*1024*1024)
                    verified={}
                    for original in source_files:
                        destination=staging/original.name
                        with original.open('rb') as reader,destination.open('r+b') as writer:
                            while chunk:=reader.read(1024*1024):writer.write(chunk)
                        verified[original.name]=dict(size_bytes=expected[original.name][0],
                            sha256=expected[original.name][1],
                            signature=_verified_file_signature(destination.lstat()))
                    assert not target.exists()
                    assert owner.source_snapshot(source.name)['sources']==[]
                    for protected_path in (staging,staging.parent):
                        with owner.mutation(protected_path) as allowed:assert not allowed
                    try:
                        with owner.materializing(target,budgeted=True):pass
                    except RuntimeError as error:assert 'active transfer' in str(error)
                    else:raise AssertionError('duplicate target publication admitted')
                    held=owner.inventory()
                    assert held['transfer_held_file_bytes']>=sum(size for size,_ in expected.values())
                    checks.append(dict(with_metadata=with_metadata,repeat=repeat,
                        private_unpublished=True,managed_mutation_blocked=True,
                        unique_target=True,preallocated_capacity_charged=True))
                    phases={};hashes=[]
                    def timed(name,function):
                        def call(*args,**kwargs):
                            start=time.perf_counter()
                            try:return function(*args,**kwargs)
                            finally:phases.setdefault(name,[]).append(1000*(time.perf_counter()-start))
                        return call
                    original_hash=hashlib.sha256
                    class Hash:
                        def __init__(self,*args,**kwargs):
                            self.inner=original_hash(*args,**kwargs)
                        def update(self,data):
                            start=time.perf_counter();self.inner.update(data)
                            hashes.append(dict(bytes=len(data),ms=1000*(time.perf_counter()-start),
                                under_owner_lock=owner.lock._is_owned()))
                        def hexdigest(self):return self.inner.hexdigest()
                    with contextlib.ExitStack() as stack:
                        for name in ('_file_inventory','_source_observation','_publish_verified_source'):
                            stack.enter_context(patch.object(owner,name,timed(name,getattr(owner,name))))
                        stack.enter_context(patch.object(module.hashlib,'sha256',Hash))
                        owner.lock.rows.clear()
                        start=time.perf_counter()
                        receipt=owner.publish_transfer(transfer,staging,target,
                            timed('directory_publish',publish_directory),verified_files=verified)
                        elapsed=1000*(time.perf_counter()-start)
                    assert len(owner.lock.rows)==1
                    assert sum(h['bytes'] for h in hashes)==sum(s for s,_ in expected.values())
                    assert hashes and all(h['under_owner_lock'] for h in hashes)
                    assert receipt['content_verified'] and receipt['adapter_id']==source.name
                    rows.append(dict(with_metadata=with_metadata,repeat=repeat,
                        publication_ms=elapsed,lock=owner.lock.rows[0],
                        phase_ms=phases,hash_update_ms=sum(h['ms'] for h in hashes),
                        hash_bytes=sum(h['bytes'] for h in hashes),hash_under_lock=True))
            assert not owner.materializations and not owner._transfer_workspaces
            assert owner.source_snapshot(source.name)['sources'][0]['content_verified']

assert module._local_file_inventory({'retained_metadata':metadata})==metadata_before
for path,evidence in sources.items():assert p.digest(Path(path))==evidence['sha256']
assert p.digest(production)==production_sha
assert p.verify_seal(seal)['pass']
import torch
assert not torch.cuda.is_initialized()
result=dict(passed=True,rows=rows,checks=checks,source_files=sources,
    production_sha256=production_sha,production_changed=False,formal_performance=False,
    inference_runs_added=0,n_correct=None,ranking_eligible=False,
    metadata_source=str(metadata),metadata_unique_files=metadata_before['unique_file_count'],
    metadata_path_count=sum(len(x['paths']) for x in metadata_before['allocations']),
    metadata_content_not_read=True,live_w2_lock_wait_measured=False,
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')})
save('component_result.json',result)
print(json.dumps(dict(passed=True,rows=rows,resources=result['resources']),indent=2))
