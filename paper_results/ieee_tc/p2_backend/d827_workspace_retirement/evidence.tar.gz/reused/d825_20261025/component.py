"""D605/D627 bounded component, using existing files as tar member streams.

This measures extraction/write and owner publication, NOT gzip or HTTP.
Only one temporary adapter copy exists; source weights are never modified.
"""
from pathlib import Path
driver = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d605_20261017/compare_inventory.py')
header = driver.read_text().split('old_commit = ', 1)[0]
start, end = header.index('closed = '), header.index('assert os.statvfs')
header = header[:start] + header[end:]
exec(compile(header, str(driver), 'exec'))
import tempfile
import tarfile
import threading
from faaslora.storage import http_artifact_store as http

gate = p.preflight([ROOT], 64 * 1024 * 1024)
save('component_resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
paths = [ROOT / name for name in ('faaslora/storage/http_artifact_store.py',
    'faaslora/memory/residency_manager.py', 'scripts/run_all_experiments.py')]
production = {str(path): p.digest(path) for path in paths}
source = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix/medical_lora_0062')
source_files = [source / 'adapter_config.json', source / 'adapter_model.safetensors']
sources = {str(path): dict(sha256=p.digest(path), bytes=path.stat().st_size) for path in source_files}
expected = {path.name: (sources[str(path)]['bytes'], sources[str(path)]['sha256']) for path in source_files}
payload_bytes = sum(size for size, _ in expected.values())

# Reuse D627's measured RLock exactly, with no online instrumentation.
lock_source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d627_20261017/component.py')
node = next(n for n in ast.parse(lock_source.read_text()).body
            if isinstance(n, ast.ClassDef) and n.name == 'MeasuredLock')
exec(compile(ast.get_source_segment(lock_source.read_text(), node), str(lock_source), 'exec'))

class ExistingFileMembers:
    def __iter__(self):
        for name, (size, _) in expected.items():
            member = tarfile.TarInfo(name)
            member.size = size
            yield member
    def extractfile(self, member):
        return (source / member.name).open('rb')

rows = []
# Fixed ABBAAB order, three component calls each; no selection or CI.
for index, mode in enumerate(('stream', 'owner_publication', 'owner_publication',
                              'stream', 'stream', 'owner_publication')):
    with tempfile.TemporaryDirectory(prefix='tc-d825-publication-') as directory:
        nvme = Path(directory) / 'nvme'
        nvme.mkdir()
        owner = module.LocalSourceReferences({'nvme': nvme})
        owner.lock = MeasuredLock()
        target = nvme / source.name
        hashes, phases = [], {}
        phase = None
        real_hash = hashlib.sha256
        class Hash:
            def __init__(self, *args, **kwargs):
                self.inner = real_hash(*args, **kwargs)
            def update(self, data):
                begin = time.perf_counter()
                cpu_begin = time.thread_time()
                self.inner.update(data)
                hashes.append(dict(phase=phase, bytes=len(data),
                    cpu_ms=1000 * (time.thread_time() - cpu_begin),
                    wall_ms=1000 * (time.perf_counter() - begin),
                    under_owner_lock=owner.lock._is_owned()))
            def hexdigest(self):
                return self.inner.hexdigest()
        with owner.materializing(target, budgeted=True) as transfer:
            with owner.transfer_workspace(transfer) as staging:
                owner.prepare_copy(transfer, staging, expected, limit_bytes=512 * 1024 * 1024)
                assert not target.exists() and not owner.source_snapshot(source.name)['sources']
                with owner.mutation(staging) as allowed:
                    assert not allowed
                assert owner.inventory()['transfer_held_file_bytes'] >= payload_bytes
                with patch.object(http.hashlib, 'sha256', Hash):
                    phase = 'extract'
                    start, cpu_start = time.perf_counter(), time.thread_time()
                    files = http._extract_verified(ExistingFileMembers(), staging, expected,
                        lambda: None, preallocated=True, verify_content=(mode == 'stream'))
                    phases['extract'] = dict(wall_ms=1000 * (time.perf_counter() - start),
                        cpu_ms=1000 * (time.thread_time() - cpu_start))
                    assert not target.exists()
                    phase = 'publish'
                    owner.lock.rows.clear()
                    start, cpu_start = time.perf_counter(), time.thread_time()
                    receipt = owner.publish_transfer(transfer, staging, target,
                        http.publish_directory, verified_files=files)
                    phases['publish'] = dict(wall_ms=1000 * (time.perf_counter() - start),
                        cpu_ms=1000 * (time.thread_time() - cpu_start))
                for stage, factor, locked in [('extract', int(mode == 'stream'), False),
                                              ('publish', 1, True)]:
                    subset = [h for h in hashes if h['phase'] == stage]
                    assert sum(h['bytes'] for h in subset) == factor * payload_bytes
                    assert all(h['under_owner_lock'] is locked for h in subset)
                assert receipt['content_verified'] and receipt['adapter_id'] == source.name
                assert len(owner.lock.rows) == 1
                rows.append(dict(index=index, mode=mode, phases=phases,
                    total_wall_ms=sum(v['wall_ms'] for v in phases.values()),
                    total_cpu_ms=sum(v['cpu_ms'] for v in phases.values()),
                    hash_bytes=sum(h['bytes'] for h in hashes),
                    hash_wall_ms=sum(h['wall_ms'] for h in hashes),
                    hash_cpu_ms=sum(h['cpu_ms'] for h in hashes),
                    lock=owner.lock.rows[0], content_sha256=receipt['content_sha256']))
        assert not owner.materializations and not owner._transfer_workspaces
        assert owner.source_snapshot(source.name)['sources'][0]['content_verified']

for path, evidence in sources.items():
    assert p.digest(Path(path)) == evidence['sha256']
for path, sha in production.items():
    assert p.digest(Path(path)) == sha
assert p.verify_seal(seal)['pass']
import torch
assert not torch.cuda.is_initialized()
result = dict(kind='d825_single_destination_verification_component_v1', passed=True,
    rows=rows, payload_bytes=payload_bytes, source_files=sources, production_sources=production,
    method='existing_regular_files_as_tar_member_streams_no_gzip_no_network',
    retained_destination_hash=True, owner_lock_unchanged=True,
    formal_performance=False, new_gpu_replays=0, n_correct=None, ranking_eligible=False,
    resources={k: (group / k).read_text().strip() for k in
        ('memory.peak', 'memory.events', 'memory.swap.current')})
save('component_result.json', result)
print(json.dumps(result, indent=2))
