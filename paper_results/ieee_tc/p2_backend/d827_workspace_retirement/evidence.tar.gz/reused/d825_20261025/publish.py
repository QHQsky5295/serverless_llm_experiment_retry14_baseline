"""Package the closed D825 CPU evidence with the established hash/scope checks."""
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT / 'paper_results/ieee_tc/p2_backend/d825_single_destination_verification'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
identity = p.scope_identity(p.cg_path().name)
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
def read(path):
    return json.loads(path.read_text())
def ref(path):
    return dict(path=str(path), sha256=p.digest(path), bytes=path.stat().st_size)
save(RAW / 'publication_identity.json', identity)
assert not OUT.exists()
OUT.mkdir(parents=True)
component = read(RAW / 'component_result.json')
assert component['passed'] and component['new_gpu_replays'] == 0
for path, sha in component['production_sources'].items():
    assert p.digest(Path(path)) == sha
for path, facts in component['source_files'].items():
    assert p.digest(Path(path)) == facts['sha256']
receipts = {name: read(RAW / (name + '_receipt.json')) for name in ('focused', 'focused2', 'regression')}
assert not receipts['focused']['passed']
assert receipts['focused2']['passed'] and receipts['regression']['passed']
for name, receipt in receipts.items():
    assert p.digest(RAW / (name + '.log')) == receipt['log_sha256']
    assert receipt['protected']['pass'] and receipt['protected']['entry_count'] == 147
    resources = receipt['resources']
    assert resources['memory.swap.current'] == '0'
    assert all(int(line.split()[1]) == 0 for line in resources['memory.events'].splitlines())
for path, sha in receipts['regression']['sources'].items():
    assert p.digest(Path(path)) == sha
assert (RAW/'focused.log').read_text().count('Ran 37 tests') == 1
assert 'Ran 222 tests' in (RAW/'regression.log').read_text()
assert 'Ran 187 tests' in (RAW/'regression.log').read_text()
closed = []
for number in range(1, 6):
    unit = f'primelora-tc-aux-825{number:029d}.scope'
    properties = subprocess.check_output(['systemctl', '--user', 'show', unit,
        '-p', 'ActiveState', '-p', 'ControlGroup', '-p', 'InvocationID'], text=True)
    assert 'ActiveState=inactive' in properties and 'ControlGroup=\n' in properties and 'InvocationID=\n' in properties
    closed.append(dict(unit=unit, properties=properties, inactive=True))
for name in ('focused', 'focused2', 'regression', 'component'):
    old = read(RAW/(name+'_identity.json'))
    assert not p.scope_still_owned(old) and not Path(old['path']).exists()
protected_path = RAW.parent.parent / 'slora_qualification/d435_20261011/protected_before.json'
protected = p.verify_seal(protected_path)
assert protected['pass'] and protected['entry_count'] == 147
user = read(ROOT/'paper_results/ieee_tc/p2_backend/d824_current_ingress_pending/closure.json')['user_protected']
for path, sha in user.items():
    assert p.digest(Path(path)) == sha
assert len(user) == 3
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == '9ff11900cd10b4538a8c140b206ea239d8b34a87'
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
for path in RAW.glob('*.py'):
    compile(path.read_text(), str(path), 'exec')
failure = dict(kind='d825_cpu_attempts_retained_v1',
    first_test_failure='New assertion compared snapshot capture time; actual sources and epoch unchanged. Fixed only test.',
    wrapper_failure=dict(script=ref(RAW/'run_tests2.py'), exit_code=1,
        phase='before_test_invocation', expected_phase=('focused', 'regression'), supplied_phase='focused2',
        resource_peak=None, provenance='Observed terminal tool result; no fabricated log or memory sample.'),
    production_relaxed_to_pass=False, inference_attempts=0)
save(RAW/'attempt_notes.json', failure)
save(OUT/'component.json', component)
save(OUT/'qualification.json', dict(passed=True, unique_tests=446, http_tests=37,
    request_lifecycle_tests=222, transfer_tests=187, focused_32_subset_not_added=True,
    receipts=receipts, attempts=failure, closures=closed, new_gpu_replays=0))
files = [path for path in sorted(RAW.iterdir()) if path.is_file()]
with tarfile.open(OUT/'evidence.tar.gz', 'x:gz') as archive:
    for path in files:
        archive.add(path, arcname=path.name, recursive=False)
# Read back every member hash; archive creation must not substitute for evidence.
import hashlib
with tarfile.open(OUT/'evidence.tar.gz', 'r:gz') as archive:
    for path in files:
        with archive.extractfile(path.name) as contents:
            digest = hashlib.sha256()
            while chunk := contents.read(1024 * 1024):
                digest.update(chunk)
        assert digest.hexdigest() == p.digest(path)
cg = p.cg_path()
closure = dict(passed=True, user_protected=user, protected_union_files=147,
    protected_user_files=3, protected_manifest=ref(protected_path), cpu_scopes=closed,
    gpu_idle=True, new_gpu_replays=0, metric_changes=False, production_candidate=True,
    end_to_end_performance_accepted=False, n_correct=None, ranking_eligible=False,
    plan=ref(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')),
    doc=ref(ROOT/'docs/ieee_tc/D825_SINGLE_DESTINATION_VERIFICATION_20261025.md'),
    production_sources=component['production_sources'], source_files=component['source_files'],
    scope=identity, resources={k:(cg/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current')},
    disk_free_bytes=os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize,
    baseline_head=subprocess.check_output(['git','rev-parse','HEAD'],
        cwd='/home/qhq/serverless_llm_baselines',text=True).strip())
save(OUT/'closure.json', closure)
save(OUT/'manifest.json', dict(raw_files=[ref(path) for path in files],
    files=[ref(path) for path in sorted(OUT.iterdir()) if path.is_file()]))
print(json.dumps(dict(passed=True, unique_tests=446, protected=147, files=len(files),
    new_gpu_replays=0, disk_free_bytes=closure['disk_free_bytes'])))
