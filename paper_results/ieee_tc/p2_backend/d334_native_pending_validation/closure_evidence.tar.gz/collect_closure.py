import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
run = raw/'7b_native_pending_validation_100'
launch = json.loads((run/'launch.json').read_text())
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
aux = Path(launch['auxiliary']['path'])
identity = p.scope_identity(aux.name)
assert identity['path'] == str(aux) and not p.owned_pids(aux)
files = {key: (aux/key).read_text() for key in ['memory.peak','memory.events','memory.swap.current',
    'memory.high','memory.max','memory.swap.max','cgroup.events']}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
after = subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip()
assert after == 'inactive'
with (raw/'local_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,files=files,after=after,launch_pass=True,native_gpu_release_confirmed=True), f, indent=2)
stop = (raw/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive') == 3 and stop.count('MainPID=0') == 3
paths = {
    'smoke_remote_transfers.jsonl': '/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-019e867c961540cc88a56f61a56e58b3.jsonl',
    'smoke_remote_monitor.log': '/home/lab14/primelora_remote/tc/d334_20261008_smoke1/remote_monitor.log',
}
hashes = {}
for name, remote_path in paths.items():
    destination = raw/name
    assert not destination.exists()
    expected = subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','sha256sum',remote_path],text=True).split()[0]
    subprocess.run(['scp','-q','-o','BatchMode=yes',f'primelora-artifact-174:{remote_path}',str(destination)],check=True)
    assert p.digest(destination) == expected
    hashes[name] = expected
with (raw/'remote_stop.json').open('x') as f:
    json.dump(dict(all_owned_units_inactive=True,ports_18080_18081_absent=True,
        local_gpu_release_verified_before_remote_stop=True,download_hashes_match_remote=True,
        hashes=hashes,stop_log_sha256=p.digest(raw/'remote_stop.log')),f,indent=2)
print(json.dumps(dict(local_aux_inactive=True,remote_inactive=True,hashes=hashes)))
