"""D334 small closure evidence; reuses D332 exact-owned cleanup/seal protocol."""
import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
out=p.ROOT/'paper_results/ieee_tc/p2_backend/d334_native_pending_validation'
offline=json.loads((raw/'offline_execution_receipt.json').read_text())
assert offline['pass_all']
identity=offline['identity']
assert p.scope_still_owned(identity)
group=Path(identity['path'])
assert not p.owned_pids(group)
resources={k:(group/k).read_text().strip() for k in ['memory.peak','memory.events','memory.swap.current']}
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',identity['unit'],'-p','ActiveState','--value'],text=True).strip()=='inactive'
with (raw/'audit_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,empty=True,after='inactive'),f,indent=2)
audit=json.loads((out/'smoke1/audit.json').read_text())
assert audit['stats']['completed']==100 and audit['native_pending_turn_trigger']['combined_successful_requests']==45
for ref in audit['raw_evidence']:
    assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
binding=json.loads((out/'smoke1/binding_audit.json').read_text())
assert all(r['control_binding_pass_count']==100 for r in binding['runs'].values())
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
refs=[raw/name for name in ['launch_gate1.json','remote_start.log','remote_health.json',
    'remote_stop.log','remote_stop.json','local_cleanup.json','audit_cleanup.json','audit1.log',
    'offline_execution_receipt.json','collect_closure.py','run_audit.py','start_remote.sh',
    'stop_remote.sh','check_remote_health.py','checkpoint.py']]
run=raw/'7b_native_pending_validation_100'
refs += [run/'launch.json',run/'launch.launch/physical_deployment/summary.json']
assert len({path.name for path in refs})==len(refs)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for path in refs:
    assert token and token not in path.read_bytes()
archive=out/'closure_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in refs:
        tar.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in refs:
        assert hashlib.sha256(tar.extractfile(path.name).read()).hexdigest()==p.digest(path)
with (out/'evidence.json').open('x') as f:
    json.dump(dict(kind='d334_complete_prefix_candidate_checkpoint_v1',
        executed_source_commit='74587830983bd28fd4791ed8ffeec9192262c56d',
        native_complete=100,numerical_n_correct=None,formal_qualification=False,
        changed_output_token_sha_requests=len(binding['changed_requests']),
        combined_gpu_requests=45,archive_sha256=p.digest(archive),
        source_refs=[dict(path=str(path),sha256=p.digest(path)) for path in refs],
        next='D335 unchanged-candidate full4000 W0 versus D332; fresh resource gate mandatory; no new short/profile/numerical repeats.'),f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='evidence.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
print(json.dumps(dict(native_complete=100,changed_output_sha=len(binding['changed_requests']),
    archive_bytes=archive.stat().st_size,archived_files=len(refs),offline_inactive=True)))
