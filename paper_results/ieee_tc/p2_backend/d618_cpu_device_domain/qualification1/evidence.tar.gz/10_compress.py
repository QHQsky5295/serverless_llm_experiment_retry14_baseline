"""Reuse D604 streaming two-roundtrip compressor on two sealed D617 failure logs."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d604_20261017/compress.py')
code=source.read_text()
start=code.index('targets = [')
end=code.index('\nchecks = []',start)
code=code[:start]+"""targets = [
    dict(run='d617_20261017/7b_three_replica_full_w1'),
    dict(run='d617_20261017/7b_three_replica_full_w1',remote_monitor_log='remote_monitor.log'),
]
assert p.host_sample()['available_bytes']>=24*p.GIB
assert RAW.stat().st_dev==ROOT.stat().st_dev
import shutil
assert shutil.disk_usage(ROOT).free>=102*p.GIB
parent=c.RAW_ROOT/'d617_20261017'
audit=json.loads((parent/'failure_analysis.json').read_text())
curated=json.loads((ROOT/'paper_results/ieee_tc/p2_backend/d617_three_replica_full_w1/failure1/summary.json').read_text())
assert audit['passed'] and audit['failure_evidence_qualified']
assert not audit['full_performance_complete'] and audit==curated['audit']
refs={row['path']:row['sha256'] for row in audit['refs']}
for target in targets:
    path,_=c.evidence_paths(c.RAW_ROOT/target['run'],target.get('remote_monitor_log'))
    assert p.digest(path)==refs[str(path)]
    assert not path.is_mount()
"""+code[end:]
code=code.replace("c.require_closed_launch(launch)","c.require_closed_launch(launch, allow_closed_failure=True)")
code=code.replace("'completion_receipt.json'","'failure_analysis.json'")
code=code.replace("completion_sha256=","failure_analysis_sha256=")
code=code.replace("assert c.main() == 0","assert c.main(allow_closed_failure=True) == 0")
exec(compile(code,str(source),'exec'))

