"""Bound D611 native mechanism reuse; not D618 performance or numerical proof."""
import ast
import gzip
import hashlib
import ijson
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'native_reuse_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
source=ROOT/'scripts/run_all_experiments.py'
old=subprocess.check_output(['git','show','01c36f6:scripts/run_all_experiments.py'],cwd=ROOT)
new=source.read_bytes()
oldline=b'                    devices=self._available_device_ids()[:self.instance_pool.max_instances])'
newline=b'                    devices=self._available_device_ids())'
assert old.count(oldline)==new.count(newline)==1
# Ignore comments via AST, but reject any second semantic change anywhere.
assert ast.dump(ast.parse(old.replace(oldline,newline)))==ast.dump(ast.parse(new))
parent=RAW.parent/'d611_20261017'
run=parent/'7b_inventory_extent_full_w2'
audit=read(parent/'actual_qualification.json')
assert audit['passed'] and audit['protocol_bound_count']==4000
raw_source=run/'launch.launch/physical_deployment/main_outcome.json'
ref=next(row for row in audit['refs'] if row['path']==str(raw_source))
receipt=read(run/'compression_receipt.json')
assert receipt['source_sha256']==ref['sha256']==receipt['first_roundtrip_sha256']==receipt['second_roundtrip_sha256']
archive=Path(receipt['archive']);assert p.digest(archive)==receipt['archive_sha256']
with gzip.open(archive,'rb') as stream:
    preparation=next(ijson.items(stream,'cpu_frontend_preparation',use_float=True))
assert preparation['legal_devices']==[0,1,2,3] and preparation['closing']
assert preparation['records'] and all(row['process_returncode'] is not None for row in preparation['records'])
uuids=sorted({row['preparation']['gpu_uuid'] for row in preparation['records'] if 'preparation' in row})
assert len(uuids)==4
parent_qualification=read(parent/'qualification.json')
assert parent_qualification['passed']
assert parent_qualification['refs'][str(source)]==hashlib.sha256(old).hexdigest()
for phase in ('analysis','publication'):
    closed=read(parent/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
preserved=read(RAW.parent/'d617_20261017/failure_analysis.json')['preserved']
for path,sha in preserved.items():assert p.digest(Path(path))==sha
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
save(RAW/'native_reuse.json',dict(passed=True,scope=identity,
    parent_source_sha256=hashlib.sha256(old).hexdigest(),candidate_source_sha256=p.digest(source),
    single_semantic_change_verified=True,configuration_unchanged=True,
    parent_audit_path=str(parent/'actual_qualification.json'),parent_audit_sha256=p.digest(parent/'actual_qualification.json'),
    parent_qualification_sha256=p.digest(parent/'qualification.json'),
    archived_source=dict(path=str(archive),sha256=p.digest(archive),original_sha256=ref['sha256']),
    cpu_preparation=preparation,device_uuid_count=len(uuids),protected=protected,preserved=preserved,
    native_mechanism_reuse_only=True,new_native_performance_complete=False,
    overlapping_three_replica_runtime_not_yet_qualified=True,
    resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,legal_devices=preparation['legal_devices'],
    preparation_records=len(preparation['records']),device_uuid_count=len(uuids),performance_reused=False)))
