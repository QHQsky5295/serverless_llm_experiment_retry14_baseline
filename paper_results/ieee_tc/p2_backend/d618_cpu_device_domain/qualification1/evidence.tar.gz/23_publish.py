"""D618: reuse explicit-path publication, preserving failure/qualification/storage boundaries."""
import ast, hashlib, io, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d618_cpu_device_domain/qualification1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD')=='01c36f6d41437d679e67de52cf350c70d0fe081e'
assert not git('diff','--cached','--name-only')
assert set(git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc').splitlines())=={'scripts/run_all_experiments.py','tests/test_ieee_tc_cpu_frontend_integration.py'}
audit=read(RAW/'native_reuse.json')
assert audit['passed'] and audit['single_semantic_change_verified']
assert not audit['new_native_performance_complete'] and audit['device_uuid_count']==4
assert audit['candidate_source_sha256']==p.digest(ROOT/'scripts/run_all_experiments.py')
for row in audit['cpu_preparation']['records']:
    assert row['state']=='activation_sent' and row['process_returncode']==0
    observation=row['observation']; state=observation['context_state']
    assert not observation['engine_ready'] and observation['status']=='cpu_prepared'
    assert state['torch_cuda_initialized'] is False and state['current_context']==state['primary_active']==0
    assert state['cuda_visible_devices']==row['preparation']['gpu_uuid']
    assert row['activation']['permission']['gpu_uuid']==row['preparation']['gpu_uuid']
before=read(RAW/'before2_receipt.json')
assert not before['passed'] and before['returncode']==1
assert before['sources'][str(ROOT/'scripts/run_all_experiments.py')]==audit['parent_source_sha256']
assert 'FAILED (failures=4, errors=1)' in (RAW/'before2.log').read_text()
assert not read(RAW/'before_gate.json')['preflight_pass']
tests={}
for phase,counts in [('focused',[17,30,13]),('regression',[35,41,173,215])]:
    result=read(RAW/(phase+'_receipt.json'))
    assert result['passed'] and result['returncode']==0
    for path,sha in result['sources'].items():assert p.digest(Path(path))==sha,path
    log=(RAW/(phase+'.log')).read_text()
    assert p.digest(RAW/(phase+'.log'))==result['log_sha256']
    assert [int(x) for x in re.findall(r'^Ran (\d+) tests? in ',log,re.M)]==counts
    assert len(re.findall(r'^OK$',log,re.M))==len(counts)
    assert 'skipped=' not in log
    tests[phase]=dict(tests_run=sum(counts),receipt_sha256=p.digest(RAW/(phase+'_receipt.json')))
for phase in ('before','before2','focused','regression','storage','native_reuse'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
for path,sha in audit['preserved'].items():assert p.digest(Path(path))==sha
storage=read(RAW/'storage_result.json')
assert len(storage['entries'])==2 and read(RAW/'receipt.json')['passed']
for row in storage['entries']:
    assert row['launch_pass'] is False and row['closed_failure_explicitly_allowed']
    assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']==row['audit_sha256']
    assert p.digest(Path(row['archive']))==row['archive_sha256']
    assert not Path(row['source']).exists()
assert sum(row['allocated_bytes_reclaimed'] for row in storage['entries'])==224239616
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log'),*RAW.glob('*_source.tar.gz')])
files += [ROOT/'scripts/run_all_experiments.py',ROOT/'tests/test_ieee_tc_cpu_frontend_integration.py',
    ROOT/'docs/ieee_tc/D618_CPU_PREPARATION_DEVICE_DOMAIN.md',
    RAW.parent/'d595_20261017/run_tests.py',RAW.parent/'d550_20261015/close.py',
    RAW.parent.parent/'storage_maintenance/d604_20261017/compress.py',
    ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py',
    RAW.parent/'d617_20261017/failure_analysis.json',
    RAW.parent/'d617_20261017/publication_receipt.json',
    RAW.parent/'d617_20261017/publication_closure.json']
OUT.mkdir(parents=True,exist_ok=False);members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as bundle:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<8*1024*1024;clean(data)
        if path.suffix=='.py':ast.parse(data)
        name=f'{i:02d}_{path.name}';info=tarfile.TarInfo(name)
        info.size,info.mode,info.mtime=len(data),0o600,0
        bundle.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'summary.json',dict(passed=True,source_commit_before=git('rev-parse','HEAD'),
    qualification_only=True,full_performance_complete=False,ranking_eligible=False,
    new_independent_numerical_correctness=False,tests=tests,total_cpu_tests=524,
    expected_parent_failure=dict(tests=12,subtest_failures=4,errors=1),
    native_reuse=audit,storage=storage,protected=protected,
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz')))
with (OUT/'result.sha256').open('x') as stream:
    for name in ('summary.json','evidence.tar.gz'):stream.write(p.digest(OUT/name)+'  '+name+'\n')
names=['docs/ieee_tc/D618_CPU_PREPARATION_DEVICE_DOMAIN.md','docs/ieee_tc/EXECUTION_STATUS.md','scripts/run_all_experiments.py','tests/test_ieee_tc_cpu_frontend_integration.py']
names += [str((OUT/name).relative_to(ROOT)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
for name in names:
    if not name.endswith('.tar.gz'):clean((ROOT/name).read_bytes())
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: align CPU preparation with legal placement domain and retain W1 failure (D618)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD');remote=git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))

