"""Reuse D610/D595 bounded per-module CPU regression, with D618 affected paths.
'before' is the intentionally failing, retained production-parent witness.
"""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/run_tests.py')
code=source.read_text()
code=code.replace("phase in ('focused','regression')", "phase in ('before','before2','focused','regression')")
start=code.index('paths=[ROOT/name')
end=code.index('\nrefs=',start)
code=code[:start]+"""paths=[ROOT/name for name in (
    'scripts/run_all_experiments.py','faaslora/cpu_frontend.py',
    'faaslora/coordination/autoscaler.py',
    'tests/test_ieee_tc_cpu_frontend_integration.py',
    'tests/test_ieee_tc_cpu_frontend_lifecycle.py',
    'tests/test_ieee_tc_frontend_preparation.py',
    'tests/test_ieee_tc_gpu_lifecycle.py',
    'tests/test_ieee_tc_native_retirement.py',
    'tests/test_ieee_tc_launch.py',
    'tests/test_ieee_tc_request_lifecycle.py')]
"""+code[end:]
start=code.index('tests=(')
end=code.index('\ncommand=',start)
code=code[:start]+"""tests=(['tests.test_ieee_tc_cpu_frontend_integration.FactoryLifecycle']
    if phase in ('before','before2') else ['tests.test_ieee_tc_cpu_frontend_integration',
        'tests.test_ieee_tc_cpu_frontend_lifecycle','tests.test_ieee_tc_frontend_preparation']
    if phase=='focused' else ['tests.test_ieee_tc_native_retirement',
        'tests.test_ieee_tc_gpu_lifecycle','tests.test_ieee_tc_launch',
        'tests.test_ieee_tc_request_lifecycle'])"""+code[end:]
old='    result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)'
assert code.count(old)==1
code=code.replace(old,"""    completed=[]
    for module in tests:
        invocation=[sys.executable,'-B','-m','unittest',module,'-v']
        log.write('Module: '+module+'\\n');log.flush()
        outcome=subprocess.run(invocation,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)
        completed.append(dict(command=invocation,returncode=outcome.returncode))
        if outcome.returncode:break
    from types import SimpleNamespace
    result=SimpleNamespace(returncode=max(abs(row['returncode']) for row in completed))
    command=completed""")
exec(compile(code,str(source),'exec'))

