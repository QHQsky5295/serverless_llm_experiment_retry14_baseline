"""Reuse actual empty-domain closure, with explicit D618 phases."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')
code=source.read_text()
old="('qualification','qualification2','backup','start','analysis','analysis2','publication','publication2')"
assert code.count(old)==1
code=code.replace(old,"('before','before2','focused','regression','storage','native_reuse','publication')")
exec(compile(code,str(source),'exec'))
