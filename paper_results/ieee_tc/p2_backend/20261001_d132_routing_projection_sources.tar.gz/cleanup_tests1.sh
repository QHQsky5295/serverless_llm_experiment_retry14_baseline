#!/usr/bin/env bash
set -euo pipefail
# Existing exact-identity empty-domain cleanup; no process termination.
unit=primelora-d132-tests1-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = b3f047c49a6649ee96ce924a525fc9eb
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d132-tests1-20261001.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
