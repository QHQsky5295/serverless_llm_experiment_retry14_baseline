"""D127 saved-state + D130 paired callback method, across actual dedicated RPC.

Historical two-adapter state only. No GPU, weights, workload or remote service.
Unlike the archived codec probe, both methods keep stdlib JSON and this measures
producer validation/projection + TCP + parent decoding/validation. Native GPU
collection is intentionally not measured; Full is required for acceptance.
"""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def retained_view():
    prior = json.loads((ROOT/'paper_results/ieee_tc/p2_backend/20260930_d121_preparation_copy/summary.json').read_text())
    record = next(row for row in prior['models'] if row['model'] == '7b')
    path = Path(record['source_path'])
    assert path.stat().st_size < 24_000_000
    assert digest(path) == record['source_sha256']
    view = json.loads(path.read_bytes())
    for key in record['selected_path']:
        view = view[key]
    canonical = json.dumps(view, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    assert hashlib.sha256(canonical).hexdigest() == record['view_sha256']
    return view, record


def child():
    from scripts import run_all_experiments as runtime
    from scripts import dedicated_engine_worker
    original = runtime.InferenceEngine
    view, _ = retained_view()
    class SavedEngine:
        def __init__(self, config, cost):
            self.model_cfg = config
        async def initialize(self):
            pass
        async def shutdown(self):
            pass
        async def ieee_gpu_reference(self, *, operation):
            assert operation == 'source_snapshot'
            return view
        async def ieee_routing_sources(self):
            started = time.perf_counter_ns()
            result = await original.ieee_routing_sources(self)
            result['probe_worker_validation_projection_ms'] = (time.perf_counter_ns()-started)/1e6
            return result
    runtime.InferenceEngine = SavedEngine
    asyncio.run(dedicated_engine_worker._run_worker(RAW/'worker_payload.json', RAW/'worker_ready.json'))


async def main():
    from faaslora.clock import local_monotonic_clock_id
    from faaslora.experiment.instance_pool import NativeSourceSnapshot
    from scripts.run_all_experiments import SubprocessInferenceEngineProxy
    out = RAW/'routing_projection_probe.json'
    assert not out.exists()
    view, record = retained_view()
    clock = local_monotonic_clock_id()
    expected = NativeSourceSnapshot.from_native(view, expected_clock_id=clock,
        received_monotonic_s=time.monotonic())
    with (RAW/'worker_payload.json').open('x') as stream:
        json.dump(dict(repo_root=str(ROOT), model_cfg={}, cost_model={}), stream)
    assert not (RAW/'worker_ready.json').exists()
    samples = []
    proxy = None
    with (RAW/'worker.log').open('x') as log:
        proc = subprocess.Popen([sys.executable, str(Path(__file__)), '--worker'],
            cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            env=os.environ | {'CUDA_VISIBLE_DEVICES': ''})
        try:
            deadline = time.monotonic()+60
            while not (RAW/'worker_ready.json').exists():
                assert proc.poll() is None, 'saved-state worker exited; inspect worker.log'
                assert time.monotonic() < deadline, 'saved-state worker startup exceeded diagnostic bound'
                await asyncio.sleep(.05)
            address = json.loads((RAW/'worker_ready.json').read_text())
            parent_cgroup = Path('/proc/self/cgroup').read_text()
            worker_cgroup = Path(f'/proc/{proc.pid}/cgroup').read_text()
            assert parent_cgroup == worker_cgroup
            assert os.sched_getaffinity(proc.pid) == os.sched_getaffinity(0) == {2, 3, 26, 27}
            proxy = SubprocessInferenceEngineProxy(process=proc, host=address['host'], port=address['port'],
                model_cfg={'timing_contract': 'ieee_tc_native_v1'}, cost_model={},
                device_id=0, workdir=RAW, log_path=RAW/'worker.log')
            async def measure(method, trial, repetition):
                delays = []
                stop = asyncio.Event()
                async def heartbeat():
                    while not stop.is_set():
                        begin = time.perf_counter_ns()
                        await asyncio.sleep(.001)
                        delays.append(max(0., (time.perf_counter_ns()-begin)/1e6-1.))
                pulse = asyncio.create_task(heartbeat())
                await asyncio.sleep(0)
                start = time.perf_counter_ns()
                if method == 'full_parent_validation':
                    payload = await proxy.ieee_gpu_reference(operation='source_snapshot')
                    before_parse = time.perf_counter_ns()
                    state = NativeSourceSnapshot.from_native(payload, expected_clock_id=clock,
                        received_monotonic_s=time.monotonic())
                else:
                    payload = await proxy.ieee_routing_sources()
                    before_parse = time.perf_counter_ns()
                    state = NativeSourceSnapshot.from_routing_wire(payload, expected_clock_id=clock,
                        received_monotonic_s=time.monotonic())
                end = time.perf_counter_ns()
                # Include a ready callback after synchronous parsing, without
                # attributing this measurement timer to production latency.
                await asyncio.sleep(0)
                stop.set()
                await pulse
                assert state == expected
                assert not proxy._native_rpc_uncertain
                samples.append(dict(method=method, trial=trial, repetition=repetition,
                    elapsed_ms=(end-start)/1e6, parent_validation_ms=(end-before_parse)/1e6,
                    max_parent_heartbeat_lateness_ms=max(delays),
                    response_bytes=payload['timing']['parent_rpc_response_bytes'],
                    worker_validation_projection_ms=payload.get('probe_worker_validation_projection_ms'),
                    exact_value_equal=True))
            # Cold RPC/setup observations retained separately, not included in means.
            for method in ('full_parent_validation', 'compact_worker_validation'):
                await measure(method, -1, 0)
            for trial in range(3):
                order = ['full_parent_validation', 'compact_worker_validation']
                if trial % 2:
                    order.reverse()
                for method in order:
                    for repetition in range(10):
                        await measure(method, trial, repetition)
            await proxy._close_all_rpc_channels()
            await proxy._rpc('shutdown')
            await asyncio.to_thread(proc.wait, 30)
            assert proc.returncode == 0
            summary = []
            for metric in ('elapsed_ms', 'parent_validation_ms', 'max_parent_heartbeat_lateness_ms', 'response_bytes'):
                means = {method: statistics.mean(s[metric] for s in samples
                    if s['method'] == method and s['trial'] >= 0)
                    for method in ('full_parent_validation', 'compact_worker_validation')}
                summary.append(dict(metric=metric, **means,
                    relative_reduction=(means['full_parent_validation']-means['compact_worker_validation'])
                    /means['full_parent_validation']))
            sources = ['faaslora/experiment/instance_pool.py', 'scripts/run_all_experiments.py',
                'scripts/dedicated_engine_worker.py', 'tests/test_ieee_tc_service_routing.py',
                'tests/test_ieee_tc_request_lifecycle.py', 'tests/test_ieee_tc_service_events.py']
            result = dict(kind='d132_validated_routing_projection_component_v1',
                formal_performance_result=False, full_candidate_accepted=False,
                samples=samples, summary=summary, source_record=record,
                worker_pid=proc.pid, worker_cgroup=worker_cgroup, worker_exit=proc.returncode,
                native_sources=len(expected.sources), native_registered=len(expected.registered_cpu_adapter_ids),
                host_allocations=len(view['native_footprints']['host_allocations']),
                source_refs=[dict(path=str(ROOT/p), sha256=digest(ROOT/p)) for p in sources]
                    + [dict(path=str(Path(__file__)), sha256=digest(Path(__file__)))],
                plan_sha256=digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')),
                metric_protocol_sha256=digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
                limitations=['Historical two-adapter state, not current 24-adapter cache or 500-adapter Full.',
                    'Actual dedicated TCP and producer/receiver code; native GPU collection replaced by retained state.',
                    'Three local alternating trials are not independent trace seeds or a system-level CI.',
                    'Heartbeat samples add common diagnostic overhead; no heartbeat added to production.',
                    'No cache lifetime, admission/physical guard, backend capacity or formula changed.'])
            with out.open('x') as stream:
                json.dump(result, stream, indent=2, allow_nan=False)
            print(json.dumps(dict(summary=summary, worker_exit=proc.returncode), indent=2))
        finally:
            if proxy is not None:
                await proxy._close_all_rpc_channels()
            if proc.poll() is None:
                proc.terminate()
                await asyncio.to_thread(proc.wait, 30)


if __name__ == '__main__':
    if sys.argv[1:] == ['--worker']:
        child()
    else:
        asyncio.run(main())
