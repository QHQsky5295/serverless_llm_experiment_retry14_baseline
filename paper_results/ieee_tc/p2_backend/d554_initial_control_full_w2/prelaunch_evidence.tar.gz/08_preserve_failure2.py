"""Preserve the shell-test interception error before correcting the fixture."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name)
with (RAW/'result_identity.json').open('x') as f:json.dump(identity,f,indent=2)
group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
units=sorted(set(re.findall(r'primelora-tc-aux-[a-f0-9]{32}\.scope',(RAW/'wrapper_tests.log').read_text())))
assert len(units)==4
states={}
for unit in units:
    state=subprocess.check_output(['systemctl','--user','show',unit,'-p','Id','-p','LoadState','-p','ActiveState','-p','ControlGroup'],text=True)
    own=p.scope_identity(unit)
    cg=Path(own['path'])
    procs={str(path):path.read_text().split() for path in cg.rglob('cgroup.procs')}
    assert procs and all(not values for values in procs.values())
    assert p.scope_still_owned(own)
    resources={k:(cg/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert not cg.exists()
    states[unit]=dict(before=state,identity=own,recursive_empty=True,path_gone=True,resources=resources)
files=[RAW/'qualify.py',RAW/'wrapper_tests.log',RAW/'qualification_identity.json',RAW/'qualification_closure.json',
       ROOT/'tests/test_ieee_tc_preflight.py',ROOT/'scripts/run_all_experiments_user_scope.sh',
       RAW/'preserve_failure.py',RAW/'review_identity.json',RAW/'review_closure.json',Path(__file__)]
members={}
with tarfile.open(RAW/'failed_fixture_sources.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes(); name=f'{i}_{path.name}'
        info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest())
with tarfile.open(RAW/'failed_fixture_sources.tar.gz','r:gz') as tar:
    for name,row in members.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==row['sha256']
with (RAW/'fixture_failure.json').open('x') as f:
    json.dump(dict(passed=False,reason='Bash exec bypasses function named systemd-run; real guarded launcher rejected nonexistent fixture paths before serving.',
        units_terminal=states,members=members,archive_sha256=p.digest(RAW/'failed_fixture_sources.tar.gz'),
        no_model_started=True,production_fix_needed=False),f,indent=2)
