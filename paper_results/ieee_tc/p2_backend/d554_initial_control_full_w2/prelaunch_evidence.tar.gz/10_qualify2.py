"""D554: reuse D553 input/native qualification; check only new shell/config wiring."""
import ast
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
RESULTS = RAW.parent.parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

def read(path): return json.loads(path.read_text())
def save(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2, allow_nan=False)
def prior(relative):
    return subprocess.check_output(['git', 'show', '0901334:'+relative], cwd=ROOT, text=True)

def main():
    identity = p.scope_identity(p.cg_path().name)
    save(RAW/'qualification2_identity.json', identity)
    group = Path(identity['path'])
    assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
    assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip() == '0'
    assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    gate = p.preflight([ROOT], p.GIB)
    assert gate['preflight_pass'], gate['issues']
    assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    protected = p.verify_seal(RESULTS/'slora_qualification/d435_20261011/protected_before.json')
    assert protected['pass'] and protected['entry_count'] == 147
    binding_path = RESULTS/'main_comparison/d553_20261015/qualification_final.json'
    assert p.digest(binding_path) == '1e5f62dac7b1cb9e94f9b37a8b56e232a58069ac47513e36441751921a5fdeb1'
    binding = read(binding_path)
    assert binding['passed'] and binding['tests'] == 386
    changed_test = ROOT/'tests/test_ieee_tc_preflight.py'
    for path, sha in {**binding['refs'], **binding['preserved']}.items():
        if Path(path) != changed_test: assert p.digest(Path(path)) == sha, path
    old_tree, new_tree = ast.parse(prior(str(changed_test.relative_to(ROOT)))), ast.parse(changed_test.read_text())
    added = [n for n in new_tree.body if isinstance(n, ast.ClassDef) and n.name == 'UserScopeAdapterMapForwarding']
    assert len(added) == 1
    new_tree.body.remove(added[0])
    assert ast.dump(old_tree) == ast.dump(new_tree), 'existing tests changed'
    for phase in ('qualification3','contract','publication'):
        closed = read(binding_path.parent/(phase+'_closure.json'))
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists()
    # The serving change since native D551 is solely D553's qualified input loader.
    relative = 'scripts/run_all_experiments.py'
    before = ast.parse(subprocess.check_output(['git','show','723818e:'+relative],cwd=ROOT,text=True))
    after = ast.parse((ROOT/relative).read_text())
    for tree in (before, after):
        selected = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == '_load_shared_trace_requests']
        assert len(selected) == 1
        tree.body.remove(selected[0])
    assert ast.dump(before) == ast.dump(after), 'unqualified serving policy change'
    paths = [ROOT/'configs/ieee_tc/20261015_d551_7b_initial_control_full_w1.yaml',
             ROOT/'configs/ieee_tc/20261015_d554_7b_initial_control_full_w2.yaml']
    configs = [yaml.safe_load(path.read_text()) for path in paths]
    normalized = copy.deepcopy(configs)
    for row in normalized:
        row['experiment'].pop('output_dir')
        row['storage'].pop('nvme_cache_dir'); row['storage'].pop('host_cache_dir')
    assert normalized[0] == normalized[1], 'cross-workload model parameters changed'
    assert normalized[1]['resource_coordination']['ieee_initial_control_policy'] == 'observed_arrivals_v1'
    shell = ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
    body = shell.read_text()
    start = body.index('  d554)\n'); end = body.index('    ;;\n', start)+len('    ;;\n')
    branch = body[start:end]
    assert paths[1].name in branch and 'PREFIX_COUNT=\n' in branch and 'SCENARIO=tc_ieee_full\n' in branch
    restored = body[:start]+body[end:]
    start = restored.index('unset FAASLORA_TC_ADAPTER_MAP FAASLORA_TC_ADAPTER_MAP_SHA256\n')
    end = restored.index('\nfi\n', start)+len('\nfi\n')
    w2_block = restored[start:end]
    assert 'FAASLORA_TC_REPLAY_PROFILE=W2' in w2_block
    assert binding['prime_plan']['adapter_map_sha256'] in w2_block
    assert restored[:start]+restored[end:] == prior(str(shell.relative_to(ROOT)))
    plan = FrozenReplayPlan.load(binding['prime_plan']['source_path'], profile='W2',
        adapter_map=binding['prime_plan']['adapter_map'],
        adapter_map_sha256=binding['prime_plan']['adapter_map_sha256'])
    assert plan.identity() == binding['prime_plan'] and len(plan.entries) == 4000
    assert FrozenReplayPlan.from_launch_context(dict(plan=plan.identity(),tiny_witness=False,replay_scope='full_source_v1')) == plan
    compiler_path = ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain/qualification.json'
    build_path = ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
    compiler, build = read(compiler_path), read(build_path)
    assert compiler['passed'] and compiler['test_count'] == 16
    assert build['passed'] and build['actual_closure']['passed'] and build['actual_closure']['path_gone']
    for path,row in build['entrypoints']['build']['files'].items(): assert p.digest(Path(path)) == row['sha256'], path
    helpers = sorted([*RAW.glob('*.py'), *RAW.glob('*.sh'), shell, ROOT/'scripts/run_all_experiments_user_scope.sh'])
    for path in helpers:
        if path.suffix == '.py': ast.parse(path.read_text(), filename=str(path))
        else: subprocess.run(['bash','-n',str(path)],check=True)
    command = [sys.executable,'-B','-m','unittest','tests.test_ieee_tc_preflight.UserScopeAdapterMapForwarding','-v']
    with (RAW/'wrapper_tests2.log').open('x') as log:
        result = subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    assert result.returncode == 0, (RAW/'wrapper_tests2.log').read_text()
    assert 'Ran 4 tests' in (RAW/'wrapper_tests2.log').read_text()
    subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
    refs = [*helpers, *paths, binding_path, compiler_path, build_path, changed_test, RAW/'wrapper_tests2.log']
    refs += [Path(path) for path in binding['refs'] if Path(path) != changed_test]
    save(RAW/'qualification.json', dict(passed=True,scope=identity,gate=gate,protected=protected,
        preserved=binding['preserved'],prime_plan=plan.identity(),source_count=4000,count=4000,
        new_tests=4,reused_input_tests=386,reused_cpu_regression_tests=363,reused_compiler_tests=16,
        same_model_configuration_as_d551=True,no_new_performance=True,numerical_correctness_qualified=False,
        refs={str(path):p.digest(path) for path in refs}))
    print(json.dumps(dict(passed=True,new_tests=4,reused_input_tests=386,prime_plan=plan.identity())))

if __name__ == '__main__': main()
