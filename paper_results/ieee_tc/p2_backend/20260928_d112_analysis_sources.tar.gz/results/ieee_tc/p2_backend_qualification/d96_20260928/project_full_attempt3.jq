# Bounded streaming adaptation of D93's curator projection.
# Preserve request scalar/timing/failure fields without materializing repeated
# native inventories. Raw input remains immutable. No ranking or filtering of
# failed requests. Preserve exactly the selected small evidence fields below.
reduce inputs as $item
  ({requests: []};
   if ($item | length) != 2 then .
   else $item[0] as $p | $item[1] as $v |
     if $p[0] == "detailed_results" and $p[1] == "tc_ieee_full" then
       if $p[2] == "requests" and ($p | length) >= 5 then
         if $p[4] != "gpu_reference_evidence" then
           setpath(["requests"] + $p[3:]; $v)
         elif $p[5] == "prior_routing_attempts" and ($p[6] | type) == "number" then
           setpath(["requests", $p[3], "prior_routing_attempt_count"];
             ([getpath(["requests", $p[3], "prior_routing_attempt_count"]) // 0,
               $p[6] + 1] | max))
         elif (["generation_submission", "confirmed_dispatch_snapshot",
                "source_admission", "native_source_conflict", "file_source_conflict"]
                | index($p[5])) != null then
           setpath(["requests", $p[3], "retained_reference_evidence"] + $p[5:]; $v)
         else . end
       elif ($p | length) == 3 and
            (["scenario_name", "baseline_type", "total", "completed", "failed", "elapsed_sec"]
             | index($p[2])) != null then
         setpath(["scenario", $p[2]]; $v)
       else . end
     else . end
   end)
