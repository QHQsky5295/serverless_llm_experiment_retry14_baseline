#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d112_20260928
unit=primelora-d112-full9-curate-20260928.scope
test "$(systemctl --user show primelora-d112-full9-project-20260928.scope -p TasksCurrent --value)" = 0
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
rg -q 'Exit status: 0' "$raw/full_full9_projection_time.txt"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full9_curation_scope.txt"
export PYTHONUNBUFFERED=1
test -s "$raw/full_full9_preliminary.json"
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/summarize_full_full9.py" > "$raw/full_full9_curation.log"
