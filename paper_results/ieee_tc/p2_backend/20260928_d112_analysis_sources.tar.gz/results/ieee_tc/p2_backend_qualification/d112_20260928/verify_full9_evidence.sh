#!/usr/bin/env bash
# D110 evidence-check pattern, adapted to D112's full native completion.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d112_20260928
unit=primelora-d112-full9-evidence-20260928.scope
test "$(systemctl --user show primelora-d112-full9-curate2-20260928.scope -p TasksCurrent --value)" = 0
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full9_evidence_scope.txt"
export PYTHONUNBUFFERED=1
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest tests.test_ieee_tc_gpu_lifecycle tests.test_ieee_tc_external_replay tests.test_ieee_tc_native_timing -v
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python - <<'PY'
import json
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d112_20260928'
before = json.loads((raw/'prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    path = Path(name) if name.startswith('/') else root/name
    assert digest(path) == expected, name
full = root/'paper_results/ieee_tc/p2_backend/20260928_d112_3b_full_w0_full9.json'
x = json.loads(full.read_text())
assert x['native_contract_completion_pass']
assert not x['full_qualified'] and not x['formal_performance_result']
assert x['population']['success'] == x['population']['native_contract_matched'] == 4000
assert x['population']['failure_observations'] == {}
assert x['timing_validation']['requests'] == 4000
assert max(x['timing_validation']['max_error_ms'].values()) <= 1.0
assert x['physical']['n_correct'] is None
assert not x['physical']['eligible_correctness']
assert x['quarantine']['events'] == 0
assert x['source_observation_stats']['requests'] == x['source_observation_stats']['collections'] + x['source_observation_stats']['joined']
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == x['metric_protocol_sha256']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
for ref in x['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256'], ref['path']
refs = [full, raw/'summarize_full_full9.py', raw/'collect_full9_preliminary.py',
        raw/'curate_full_full9.sh', raw/'verify_full9_evidence.sh',
        root/'tests/test_ieee_tc_gpu_lifecycle.py', root/'tests/test_ieee_tc_external_replay.py',
        root/'tests/test_ieee_tc_native_timing.py']
receipt = dict(kind='d112_full9_postrun_evidence_verification_v1', pass_checks=True,
    frozen_source_refs_checked=len(before['source_sha256']), curated_source_refs_checked=len(x['source_refs']),
    source_commit=before['runtime_source_commit'], formal_performance_result=False,
    protected=protected, refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
out = root/'paper_results/ieee_tc/p2_backend/20260928_d112_evidence_verification.json'
with out.open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(out),sha256=digest(out),frozen_sources=receipt['frozen_source_refs_checked'],
    curated_sources=receipt['curated_source_refs_checked'],protected=147)))
PY
