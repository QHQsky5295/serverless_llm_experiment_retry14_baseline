#!/usr/bin/env bash
set -euo pipefail
date -Is
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
units=(primelora-d112-full9-project-20260928.scope primelora-d112-full9-curate-20260928.scope primelora-d112-full9-curate2-20260928.scope primelora-d112-full9-evidence-20260928.scope)
ids=(c5ed5d29bb81427e8e062cf99d87d799 3e8a852442874853a53651b37485bdc4 edb0789bbe504307859131a4f9571133 0b1ff5294f314059bc98e3c1497223da)
for i in 0 1 2 3; do
  unit=${units[$i]}
  test "$(systemctl --user show "$unit" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
  cg=$(systemctl --user show "$unit" -p ControlGroup --value)
  test "$cg" = "/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
  rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
  systemctl --user show "$unit" -p Id -p InvocationID -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax
  cat "/sys/fs/cgroup$cg/memory.events"
done
for unit in "${units[@]}"; do
  systemctl --user stop "$unit"
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
done
date -Is
