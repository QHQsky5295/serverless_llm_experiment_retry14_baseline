"""Extend the existing retained-data audit: control cooldown and short decode.

Read only sealed D673/D678 projections. No policy search, inference, hypothetical
resource saving, or request filtering. Reuse the D612 summary and resource gate.
"""
import ast
import collections
import hashlib
import json
import math
import os
from pathlib import Path
from statistics import fmean
import subprocess
import sys
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
BASE = RAW.parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.plot_d290_diagnostic import percentile

old = BASE/'d612_20261017/diagnose.py'
assert p.digest(old) == '5b9026f7fb88fdb1ccf52423ec18d3767fcfc4c0d4a1f4dd823e1cd6926c6306'
tree = ast.parse(old.read_text())
defs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('read', 'save', 'summarize')]
assert {n.name for n in defs} == {'read', 'save', 'summarize'}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(old), 'exec'))

def stretches(events, predicate):
    """Consecutive observed samples, not evidence of between-sample state."""
    result, current = [], []
    for event in events:
        if predicate(event):
            current.append(event)
        elif current:
            result.append(current)
            current = []
    if current:
        result.append(current)
    return result

def stretch_summary(groups, cooldown):
    spans = [g[-1]['observed_at']-g[0]['observed_at'] for g in groups]
    eligible = [g for g, span in zip(groups, spans) if span >= cooldown]
    return dict(stretches=len(groups), max_observed_duration_s=max(spans, default=0.),
        stretches_reaching_frozen_cooldown=len(eligible),
        samples_after_cooldown=sum(sum(e['observed_at']-g[0]['observed_at'] >= cooldown for e in g)
                                   for g in eligible),
        eligible_intervals=[dict(first_offset_s=g[0]['offset_s'], last_offset_s=g[-1]['offset_s'],
                                samples=len(g)) for g in eligible])

def control_audit(events, limits, last_arrival):
    events = [e for e in events if 0 <= e['offset_s'] <= last_arrival]
    assert all(a['observed_at'] < b['observed_at'] for a, b in zip(events, events[1:]))
    for e in events:
        low = dict(queue=e['queue_depth'] < limits['queue_lower'],
                   active=e['active_saturation'] < limits['active_lower'],
                   ttft=e['p95_ttft_ms'] is not None and e['p95_ttft_ms'] < limits['ttft_lower_ms'])
        assert low == e['low_conditions'] and all(low.values()) == e['all_low']
    # A necessary-condition diagnosis only: suppress the TTFT gate in this
    # question, not in production. Retain actual queue/active/pending samples.
    def other_low(e):
        return (e['low_conditions']['queue'] and e['low_conditions']['active']
                and e['pending_instances'] == 0 and e['ready_instances'] > 1)
    groups = stretches(events, other_low)
    actual = stretches(events, lambda e: other_low(e) and e['low_conditions']['ttft'])
    return dict(samples=len(events), necessary_without_ttft=stretch_summary(groups, limits['scale_down_cooldown_s']),
        actual_all_low=stretch_summary(actual, limits['scale_down_cooldown_s']),
        maximum_sample_gap_s=max(b['observed_at']-a['observed_at'] for a,b in zip(events, events[1:])),
        independent_blocker_counts={
            'queue_not_low':sum(not e['low_conditions']['queue'] for e in events),
            'active_not_low':sum(not e['low_conditions']['active'] for e in events),
            'ttft_not_low':sum(not e['low_conditions']['ttft'] for e in events),
            'pending':sum(e['pending_instances'] > 0 for e in events),
            'minimum_replicas':sum(e['ready_instances'] <= 1 for e in events)},
        actual_actions=dict(collections.Counter(e['action'] for e in events)),
        counterfactual_performance_computed=False)

def request_audit(rows):
    assert len(rows) == 4000 and len({r['request_id'] for r in rows}) == 4000
    groups = {}
    for name, selected in (
        ('all', rows), ('ttft_bad', [r for r in rows if not r['ttft_good']]),
        ('tpot_bad', [r for r in rows if not r['tpot_good']]),
        ('short_all', [r for r in rows if r['target'] <= 31]),
        ('short_tpot_bad', [r for r in rows if r['target'] <= 31 and not r['tpot_good']]),
        ('short_gpu_tpot_bad', [r for r in rows if r['target'] <= 31 and r['tier'] == 'gpu' and not r['tpot_good']]),
    ):
        record = summarize(selected)
        if selected:
            excess = []
            for r in selected:
                assert r['target'] >= 2
                decode = r['native_timing']['native_decode_ms']
                assert abs(decode/(r['target']-1)-r['tpot_ms']) < 1e-6
                excess.append(decode-r['tpot_limit_ms']*(r['target']-1))
            record['decode_excess_over_frozen_allowance_ms'] = dict(
                mean=fmean(excess), p50=percentile(excess,.5), p95=percentile(excess,.95))
            record['target_counts'] = dict(collections.Counter(r['target'] for r in selected))
            record['observed_natural_scaleout_overlap_count'] = sum(r['scaleout_overlap_before_first_ms'] > 0 for r in selected)
        groups[name] = record
    return groups

def unit_checks():
    def e(t, good): return dict(observed_at=t, offset_s=t, good=good)
    gs = stretches([e(0,True),e(47,True),e(48,False),e(49,True),e(97,True)], lambda x:x['good'])
    a = stretch_summary(gs,48)
    assert a['stretches']==2 and a['max_observed_duration_s']==48
    assert a['stretches_reaching_frozen_cooldown']==1 and a['samples_after_cooldown']==1
    assert stretch_summary([],48)['stretches']==0

if sys.argv[1:] == ['--check-only']:
    unit_checks()
    print('D679 reused helpers and deterministic cooldown boundary checks passed; no data or writes.')
elif not sys.argv[1:]:
    unit_checks()
    identity=p.scope_identity(p.cg_path().name); group=Path(identity['path'])
    save(RAW/'analysis_identity.json', identity)
    assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
    assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip()=='0'
    assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    gate=p.preflight([ROOT], 16*1024*1024)
    assert not any('host_memory_below_stop' in x or 'filesystem_below_stop' in x for x in gate['issues'])
    save(RAW/'analysis_resource_gate.json',gate)
    expected={
        BASE/'d678_20261018/diagnosis.json':'f8d7f07c1f83b35593fcf8bae9dead1d21ed689ae90945a8872ce2164936e960',
        BASE/'d673_20261018/d672_controls.json':'e5960a308adb2eb9a7c3a83602999467cc58f6a59e42e6fb62f29c2edc521eb2',
        BASE/'d673_20261018/d672_projection.json':'3f721c2fb0b3c91ba7b47ea36ac221d906dca807d6b357a4db5922108d9e634d',
        BASE/'d678_20261018/d677_controls.json':'ac3b8be8dfcccc5dab209ab317bdc2bf69f1126def690916dccf742a3d7e52c1',
        BASE/'d678_20261018/d677_projection.json':'edf942c057b15c91d2f8063a9313afad0f450eb2f6f0cd7a21fa2085cbcf75d7',
        ROOT/'faaslora/coordination/autoscaler.py':'57c54231ac790b5fb93a3410d7274db3820e126dc5ef54e1510241926b699463',
        ROOT/'scripts/run_all_experiments.py':'46ddbdd656fcabb3b83218a1ebeac82c30cd06249c001b5b4d79bb3415dd375e',
        Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'):'d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83',
        Path('/home/qhq/storage_audit_20260915/PrimeLoRA_IEEE.pdf'):'22d4272e78255f393d4d4f071670e7ca43f43771805784af75d9123a4e3912d1',
    }
    for path, sha in expected.items(): assert p.digest(path)==sha,path
    config_path=ROOT/'configs/ieee_tc/20261018_d677_3b_full_w0.yaml'
    limits=yaml.safe_load(config_path.read_text())['resource_coordination']['ieee_scaling']
    expected[config_path]=p.digest(config_path)
    expected[old]=p.digest(old)
    evidence=read(BASE/'d678_20261018/diagnosis.json')
    result={}
    for tag,parent in (('D672','d673_20261018'),('D677','d678_20261018')):
        rows=read(BASE/parent/(tag.lower()+'_projection.json'))
        controls=read(BASE/parent/(tag.lower()+'_controls.json'))
        assert sum(r['joint'] for r in rows)==evidence['runs'][tag]['all']['joint']
        result[tag]=dict(control=control_audit(controls,limits,max(r['arrival_s'] for r in rows)),
                         requests=request_audit(rows))
    report=dict(passed=True,kind='d679_control_scope_and_necessary_cooldown_audit_v1',
        inference_runs_added=0,production_changed=False,ranking_eligible=False,n_correct=None,
        configuration_changed=False,limits=limits,runs=result,
        source_refs=[dict(path=str(path),sha256=sha) for path,sha in expected.items()],
        caveats=['Other-low-only stretches do not predict feedback after scale-in.',
                 'No threshold sweep or counterfactual GPU-s/latency was computed.',
                 'Short decode excess is observed duration, not a measured removable CPU cost.',
                 'All fields remain single-run development observations; no CI or causal attribution.'])
    save(RAW/'diagnosis.json',report)
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
    save(RAW/'analysis_receipt.json',dict(passed=True,identity=identity,resources=resources,
        diagnosis_sha256=p.digest(RAW/'diagnosis.json'),source_sha256=p.digest(Path(__file__))))
    print(json.dumps(dict(passed=True,runs={k:v['control'] for k,v in result.items()})))
else:
    raise SystemExit('expected no args or --check-only')
