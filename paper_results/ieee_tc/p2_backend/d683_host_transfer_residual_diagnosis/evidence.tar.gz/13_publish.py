"""Reuse exact-path D612 evidence publication, with current closed identities."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path(__file__).resolve().parent.parent/'d612_20261017/publish.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=data.decode()
for old,new in (
    ('d612_w2_quality_resource_diagnosis','d683_host_transfer_residual_diagnosis'),
    ('f72091155cd3bb258651fc461db11b9113c72faf','019448c5be854d348c92a29180b779ad16f3a685'),
    ("assert diagnosis['runs']['D607']['all']['joint']==3762", "assert diagnosis['runs']['D677']['requests']['all']['joint']==3628"),
    ("assert diagnosis['runs']['D611']['all']['joint']==3819", "assert diagnosis['runs']['D682']['requests']['all']['joint']==3694"),
    ('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md','D683_3B_HOST_TRANSFER_RESIDUAL_DIAGNOSIS.md'),
    ("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']", """files += [doc,
    RAW.parent/'d682_20261018/publication_receipt.json',
    RAW.parent/'d682_20261018/publication_closure.json',
    RAW.parent/'d612_20261017/diagnose.py',RAW.parent/'d612_20261017/publish.py',
    RAW.parent/'d661_20261018/diagnose.py',RAW.parent/'d679_20261018/diagnose.py',
    RAW.parent/'d668_20261018/close.py']"""),
    ('assert sum(path.stat().st_size for path in files)<32*1024*1024','assert sum(path.stat().st_size for path in files)<64*1024*1024'),
    ('assert len(data)<8*1024*1024','assert len(data)<32*1024*1024'),
    ('d612_reused_parent_closed_log_diagnosis_v1','d683_reused_host_transfer_residual_diagnosis_v1'),
    ('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
     'tc: retain 3B post-transfer SLO residuals and unchanged holding evidence (D683)'),
):
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new)
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D683 checked explicit publication expansion; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no args or --check-only')
