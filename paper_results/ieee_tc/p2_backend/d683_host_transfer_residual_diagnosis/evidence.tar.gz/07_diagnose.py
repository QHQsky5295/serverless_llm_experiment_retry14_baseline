"""Reuse sealed streaming projection and cooldown audit for D682 residuals.

No new inference, threshold search, production edit or workload generation.
"""
import ast
import collections
import hashlib
import json
import math
from pathlib import Path
from statistics import fmean
import sys

RAW = Path(__file__).resolve().parent
BASE = RAW.parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
SOURCES = {
    BASE/'d661_20261018/diagnose.py': 'd776ad4e728f628697ee7502ef378e55ece53bd528fcc8ac9906a0f104f49f40',
    BASE/'d679_20261018/diagnose.py': '742be4843d75dcfc803eb07cfccb27496c7e73dbfd37c58dfb31f636b341b437',
    BASE/'d678_20261018/d677_projection.json': 'edf942c057b15c91d2f8063a9313afad0f450eb2f6f0cd7a21fa2085cbcf75d7',
    BASE/'d678_20261018/d677_controls.json': 'ac3b8be8dfcccc5dab209ab317bdc2bf69f1126def690916dccf742a3d7e52c1',
    BASE/'d678_20261018/projection_diagnosis.json': 'f91a4332f4c19ffe0cb8726506492101feeb7338751e5bc06d92ae1c846ebb6b',
}
source = BASE/'d661_20261018/diagnose.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCES[source]
tree = ast.parse(source.read_text())
assert isinstance(tree.body[-1], ast.If)
tree.body.pop()
outer = {'__file__': __file__, '__name__': '__checked_d683_expansion__'}
exec(compile(tree, str(source), 'exec'), outer)
code = outer['code']
for old, new in (('d660', 'd682'), ('D660', 'D682'),
    ('p2_backend/d682_3b_full_w0/audit.json', 'p2_backend/d682_3b_full_w0/completion/audit.json'),
    ('31e3a5c042961983fcbfd1bd926141e66b153aab892e1432c8914b1b086e89d9',
     'fbb9220309b3e66977775d0cd7644409598ac09f3ef5b72ece73bdad452fd1d7'),
    ('==3575', '==3694'), ('32*1024*1024', '64*1024*1024'),
    ("RAW/'diagnosis.json'", "RAW/'projection_diagnosis.json'"),
    ("RAW/'analysis_receipt.json'", "RAW/'projection_receipt.json'"),
    ('d661_3b_w0_residual_and_holding_v1', 'd683_d682_reused_projection_v1')):
    assert old in code, old
    code = code.replace(old, new)
ast.parse(code)
old = BASE/'d679_20261018/diagnose.py'
assert hashlib.sha256(old.read_bytes()).hexdigest() == SOURCES[old]
tree = ast.parse(old.read_text())
names = {'stretches', 'stretch_summary', 'control_audit', 'request_audit', 'unit_checks'}
defs = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert {n.name for n in defs} == names
exec(compile(ast.Module(body=defs, type_ignores=[]), str(old), 'exec'))
unit_checks()
if sys.argv[1:] == ['--check-only']:
    print('D683 sealed projection expansion and cooldown boundary checks passed; no writes.')
    raise SystemExit(0)
assert not sys.argv[1:]
ns = {'__file__': __file__, '__name__': '__d683_projection__'}
exec(compile(code, str(source), 'exec'), ns)
p, read, save = ns['p'], ns['read'], ns['save']
summarize, percentile = ns['summarize'], ns['percentile']
for path, sha in SOURCES.items():
    assert p.digest(path) == sha, path
old_rows = read(BASE/'d678_20261018/d677_projection.json')
old_controls = read(BASE/'d678_20261018/d677_controls.json')
old_run = read(BASE/'d678_20261018/projection_diagnosis.json')['runs']['D677']
new_rows = sorted(ns['projections']['D682'].values(), key=lambda r:r['source_index'])
new_run = ns['runs']['D682']
new_controls = read(RAW/'d682_controls.json')
assert old_run['workload_identity'] == new_run['workload_identity']
before, after = ({r['request_id']:r for r in rows} for rows in (old_rows, new_rows))
assert len(before) == len(after) == 4000 and set(before) == set(after)
for rid in before:
    for key in ('source_index','request_id','adapter_id','arrival_s','target','prompt_tokens','ttft_limit_ms','tpot_limit_ms'):
        assert before[rid][key] == after[rid][key], (rid,key)
transitions = {}
for a in (True, False):
    for b in (True, False):
        ids = [rid for rid in before if before[rid]['joint'] == a and after[rid]['joint'] == b]
        transitions[('good' if a else 'bad')+'_to_'+('good' if b else 'bad')] = dict(
            n=len(ids), old=summarize([before[r] for r in ids]), new=summarize([after[r] for r in ids]))
assert sum(v['n'] for v in transitions.values()) == 4000
assert transitions['bad_to_good']['n']-transitions['good_to_bad']['n'] == 66
runs = {}
for tag, rows, controls, run in (('D677',old_rows,old_controls,old_run), ('D682',new_rows,new_controls,new_run)):
    runs[tag] = dict(control=control_audit(controls,ns['limits'],max(r['arrival_s'] for r in rows)),
        requests=request_audit(rows), holding_quarters=run['holding_quarters'],
        control_changes=run['control_changes'],
        residual_classes=run['violation_classes'],
        resource_seconds=run['stats']['physical_gpu_seconds'],
        scalar_diagnostics=run['scalar_diagnostics'],
        by_tier=run['by_tier'], bad_by_tier=run['bad_by_tier'])
refs = {str(path):sha for path,sha in SOURCES.items()}
for row in ns['refs']: refs[row['path']] = row['sha256']
for path in (Path(__file__), RAW/'projection_diagnosis.json', RAW/'d682_projection.json', RAW/'d682_controls.json'):
    refs[str(path)] = p.digest(path)
report = dict(passed=True,kind='d683_host_transfer_residual_and_holding_v1',
    inference_runs_added=0,production_changed=False,configuration_changed=False,
    n_correct=None,ranking_eligible=False,confidence_interval=None,replicates_per_version=1,
    runs=runs,matched_transitions=transitions,
    source_refs=[dict(path=path,sha256=sha) for path,sha in sorted(refs.items())],
    caveats=['Matched inputs do not fix endogenous routing, loading, batching or control feedback.',
        'No hypothetical GPU saving or subtraction of event spans from user latency.',
        'Observed short decode excess is not a measured removable CPU cost.',
        'Same-owner transfer is separately qualified by the D682 audit; this analysis does not reclassify its receipts.',
        'Single-run development observations, not a causal effect estimate or final numerical qualification.'])
save(RAW/'diagnosis.json',report)
group = Path(ns['identity']['path'])
save(RAW/'analysis_receipt.json',dict(passed=True,identity=ns['identity'],
    diagnosis_sha256=p.digest(RAW/'diagnosis.json'),source_sha256=p.digest(Path(__file__)),
    resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,transitions={k:v['n'] for k,v in transitions.items()},
    runs={tag:dict(joint=data['requests']['all']['joint'],control=data['control']) for tag,data in runs.items()})),flush=True)
