"""D601 rollback: D595's bounded regression harness, D549-qualified module order."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/run_tests.py')
code=source.read_text()
old="['tests.test_ieee_tc_transfer_pressure',\n        'tests.test_ieee_tc_cpu_frontend_integration','tests.test_ieee_tc_launch']"
assert code.count(old)==1
code=code.replace(old,"['tests.test_ieee_tc_launch','tests.test_ieee_tc_cpu_frontend_integration','tests.test_ieee_tc_transfer_pressure']")
exec(compile(code,str(source),'exec'))
