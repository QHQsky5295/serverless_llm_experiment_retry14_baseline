"""Reuse D595 backup checks for a tested exact rollback, not a new performance point."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'", "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d601_parallel_pressure_rollback'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'", "=='bc43982913924eacebbf63243b43162a753bff82'")
start=code.index("reg=read(RAW/");end=code.index('preserved={',start)
code=code[:start]+"""reg=read(RAW/'regression_receipt.json')
assert reg['passed']
for path,sha in reg['sources'].items():assert p.digest(Path(path))==sha
closure=read(RAW/'regression_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
restored={}
for name in ('faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py'):
    before=subprocess.check_output(['git','show','8639ce5^:'+name],cwd=ROOT)
    assert (ROOT/name).read_bytes()==before
    restored[name]=hashlib.sha256(before).hexdigest()
"""+code[end:]
start=code.index('members=[RAW/name');end=code.index('\nfor path in members:',start)
code=code[:start]+"""members=[RAW/name for name in ('run_tests.py','close.py','backup.py',
    'regression_identity.json','regression_gate.json','regression.log','regression_receipt.json',
    'regression_closure.json','regression_source.tar.gz')]"""+code[end:]
replace("for name in ('focused','regression2')", "for name in ('regression',)")
start=code.index('record=dict(');end=code.index("save(OUT/'qualification.json'",start)
code=code[:start]+"""record=dict(passed=True,exact_candidate_rollback=True,native_gpu_validation=False,full_performance_run=False,
    parent_commit='bc43982913924eacebbf63243b43162a753bff82',restored_file_sha256=restored,
    test_counts=test_counts,regression=reg,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='Exact D595 rollback and CPU regression only. D598 retained; no new performance gain or final G1/G2 claim.')
"""+code[end:]
replace('docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md','docs/ieee_tc/D601_PARALLEL_PRESSURE_ROLLBACK.md')
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)', 'tc: restore preceding pressure semantics after full W2 regression (D601)')
exec(compile(code,str(source),'exec'))
