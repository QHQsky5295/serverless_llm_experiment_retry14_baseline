"""D601 exact-owned recursively-empty closure only."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/close.py')
exec(compile(source.read_text(),str(source),'exec'))
