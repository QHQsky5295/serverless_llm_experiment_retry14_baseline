"""Reuse D621 lifecycle/activation audit, without changing metric definitions."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d621_20261017/analyze.py')
code = source.read_text()
assert code.count('7b_device_domain_full_w2') == 2
assert code.count('d621_audit') == 1
code = code.replace('7b_device_domain_full_w2', '7b_private_verify_full_w2')
code = code.replace('d621_audit', 'd629_audit')
exec(compile(code, str(source), 'exec'))
