"""Reuse D550 exact-owned empty-scope closure for D629's collection receipt."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')
code = source.read_text()
old = "name=sys.argv[1];assert name in ('qualification','qualification2','backup','start','analysis','analysis2','publication','publication2')"
assert code.count(old) == 1
code = code.replace(old, "name='collection'")
old = "identity=json.loads((RAW/(name+'_identity.json')).read_text())"
assert code.count(old) == 1
code = code.replace(old, "identity=json.loads((RAW/'collection_receipt.json').read_text())['identity']")
exec(compile(code, str(source), 'exec'))
