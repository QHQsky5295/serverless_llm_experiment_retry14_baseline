"""Reuse the complete D621 W2 audit with only a new source/output identity."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d621_20261017/analyze_prefix.py')
code = source.read_text()
for old, new in (
    ('7b_device_domain_full_w2', '7b_private_verify_full_w2'),
    ('d621_actual_initial_control_full4000_qualification_v1', 'd629_private_verify_full4000_qualification_v1'),
):
    assert code.count(old) == 1, old
    code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
