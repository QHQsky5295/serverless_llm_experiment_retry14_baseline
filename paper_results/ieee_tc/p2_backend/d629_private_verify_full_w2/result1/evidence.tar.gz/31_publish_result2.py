"""Correct only the publication preflight schema; preserve failed source/identity."""
import ast
from pathlib import Path

source = Path(__file__).resolve().with_name('publish_result.py')
code = source.read_text()
assert code.count("gate['pass']") == 1
code = code.replace("gate['pass']", "gate['preflight_pass']")
marker = 'ast.parse(code)\nif sys.argv[1:]'
assert code.count(marker) == 1
code = code.replace(marker, """replace('publication_identity.json','publication2_identity.json')
replace('publication_resource_gate.json','publication2_resource_gate.json')
replace('publication_receipt.json','publication2_receipt.json')
ast.parse(code)
if sys.argv[1:]""")
ast.parse(code)
exec(compile(code,str(source),'exec'))
