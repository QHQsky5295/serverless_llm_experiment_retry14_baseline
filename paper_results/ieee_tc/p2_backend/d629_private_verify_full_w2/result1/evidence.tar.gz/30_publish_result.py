"""Reuse D621 publication with D629's rejected-performance outcome.

Retain every request and all original evidence; no production or metric edits.
The sealed D623 projection avoids reparsing the old 4000-request source.
"""
import ast
import hashlib
from pathlib import Path
import sys

SOURCE = Path(__file__).resolve().parent.parent / 'd621_20261017/publish_result.py'
data = SOURCE.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'e3541b4f4a813ac1167fb5bf7cea179c42750746f3124134a024f644859067f1'
code = data.decode()

def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d621_device_domain_full_w2/result1'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d629_private_verify_full_w2/result1'")
replace("assert git('rev-parse','HEAD')=='c2289327aeb3dc6cd086dfce2455ab2fb99924e7'",
        "assert git('rev-parse','HEAD')=='8127fbc3066530dfe1d79cb08cef41f9c69fb50b'")
replace("assert not git('diff','--cached','--name-only')",
        "gate=p.preflight([ROOT],p.GIB)\nassert gate['pass'],gate['issues']\nsave(RAW/'publication_resource_gate.json',gate)\nassert not git('diff','--cached','--name-only')")
replace("for name in ('qualification','backup','start','analysis'):",
        "for name in ('qualification','backup','start','collection','analysis'):")
replace("old_path=RAW.parent/'d615_20261017/actual_qualification.json'",
        "old_path=RAW.parent/'d621_20261017/actual_qualification.json'")
replace("old_run='D615'", "old_run='D621'")
replace('same_model_configuration_device_domain_revision_from_D615=True,',
        'same_model_configuration_private_verification_revision_from_D621=True,')
replace('candidate_selected_for_same_configuration_cross_workload_validation=True,',
        'candidate_selected_for_same_configuration_cross_workload_validation=False,')
old_conclusion = "conclusion='D621 full W2 has 3798/4000 observed joint-SLO passes (94.95%), below the frozen 95% requirement by two requests, despite meeting the physical GPU-time budget. Relative to D615, GPU time and P95 TTFT are slightly lower but joint SLO is 0.475 percentage points worse. Retain this failed feasibility point; no rounding, same-key rerun, causal attribution, independent numerical qualification or final G1/G2 claim.'"
replace(old_conclusion, "conclusion='D629 completed 4000 native-contract requests, but observed joint SLO is 3727/4000 (93.175%). Relative to D621 it is lower by 1.775 percentage points, P95 TTFT is 17.756% higher and physical GPU time 2.841% higher. Reject this candidate as a performance improvement; retain the complete run. The extra mean TTFT is concentrated in acquire-to-resume, which includes permit waiting and wakeup delay, not a proven causal effect of the lock change. No same-key rerun, cross-scene splicing, independent numerical qualification or final G1/G2 claim.'")
replace("cap=read(RAW/'realized_replica_cap.json')", '''# Bind identical model settings and actual request contracts before comparing.
import yaml
import ijson
configs=[ROOT/'configs/ieee_tc'/name for name in (
    '20261017_d621_7b_device_domain_full_w2.yaml',
    '20261017_d629_7b_private_verify_full_w2.yaml')]
normalized=[]
for path in configs:
    value=yaml.safe_load(path.read_text())
    del value['experiment']['output_dir']
    del value['storage']['nvme_cache_dir']
    del value['storage']['host_cache_dir']
    normalized.append(value)
assert normalized[0]==normalized[1]
old_binding=read(old_path.parent/'qualification.json')
for relative in ('scripts/run_all_experiments.py','faaslora/coordination/autoscaler.py',
                 'faaslora/cpu_frontend.py'):
    key=str(ROOT/relative)
    assert old_binding['refs'][key]==binding['refs'][key]==p.digest(ROOT/relative)
changed_key=str(ROOT/'faaslora/memory/residency_manager.py')
assert old_binding['refs'][changed_key]!=binding['refs'][changed_key]
assert binding['refs'][changed_key]=='3bf7490deff8c917bbad46b79526772a3803f9b030f559b8e63e976052d99407'
projection=RAW.parent/'d623_20261017/d621_projection.json'
projection_summary=ROOT/'paper_results/ieee_tc/p2_backend/d623_w2_slo_shortfall_diagnosis/summary.json'
sealed=read(projection_summary)
members=[v for v in sealed['archive_members'].values() if v['path']==str(projection)]
assert sealed['passed'] and len(members)==1
assert p.digest(projection)==members[0]['sha256']
parent={r['request_id']:r for r in read(projection)}
assert len(parent)==4000
seen=set();changes=[]
source_result=Path(audit['evidence']['source'])
assert p.digest(source_result)==audit['evidence']['source_sha256']
with source_result.open('rb') as stream:
    for request in ijson.items(stream,'detailed_results.tc_ieee_full.requests.item',use_float=True):
        rid=request['request_id'];assert rid not in seen;seen.add(rid)
        previous=parent[rid]
        checks={'adapter_id':'adapter_id','canonical_prompt_sha256':'prompt_sha256',
                'requested_completion_tokens':'target','generation_contract':'generation_contract',
                'completion_token_source':'token_source'}
        for key,old_key in checks.items():assert request[key]==previous[old_key],(rid,key)
        assert abs(request['scheduled_arrival_offset_s']-previous['arrival_s'])<1e-9
        assert request['native_token_timing']['actual_prompt_tokens']==previous['prompt_tokens']
        if request['completion_token_ids_sha256']!=previous['output_sha256']:
            changes.append(rid)
assert seen==set(parent)
comparison['matched_native_contract_count']=len(seen)
comparison['same_backend_output_hash_changes']=len(changes)
comparison['same_backend_changed_output_request_ids']=changes
comparison['same_backend_numerical_difference_cause']='unknown; no arithmetic equivalence or nondeterminism cause inferred'
comparison['normalized_configurations_equal']=True
comparison['configuration_refs']={str(path):p.digest(path) for path in configs}
comparison['residency_manager_sha256']={'reference':old_binding['refs'][changed_key],
                                      'candidate':binding['refs'][changed_key]}
comparison['stage_mean_delta_ms']={key:value-old['stage_means_ms'][key]
                                  for key,value in audit['stage_means_ms'].items()}
comparison['acquire_to_resume_share_of_mean_ttft_increase']=(
    comparison['stage_mean_delta_ms']['acquire_to_resume_ms']/
    (audit['stats']['mean_ttft_ms']-old['stats']['mean_ttft_ms']))
comparison['equal_remote_count_and_bytes']=(
    old['remote_transfers']==audit['remote_transfers'] and
    old['remote_wire_bytes']==audit['remote_wire_bytes'])
comparison['source_order_phases']={'reference':old['source_order_phases'],
                                  'candidate':audit['source_order_phases']}
comparison['metric_protocol_sha256']=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')
comparison['single_run_protocol_sha256']=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')
comparison['candidate_performance_accepted']=False
cap=read(RAW/'realized_replica_cap.json')''')
replace("run=RAW/'7b_device_domain_full_w2'", "run=RAW/'7b_private_verify_full_w2'")
replace("ROOT/'docs/ieee_tc/D621_DEVICE_DOMAIN_FULL_W2.md',",
        "ROOT/'docs/ieee_tc/D629_PRIVATE_VERIFY_FULL_W2.md',\n    RAW.parent/'d621_20261017/publish_result.py',projection,projection_summary,*configs,")
replace("names=['docs/ieee_tc/D621_DEVICE_DOMAIN_FULL_W2.md','docs/ieee_tc/EXECUTION_STATUS.md']",
        "names=['docs/ieee_tc/D629_PRIVATE_VERIFY_FULL_W2.md','docs/ieee_tc/EXECUTION_STATUS.md']")
replace('tc: retain W2 joint-SLO shortfall and complete lifecycle evidence (D621)',
        'tc: preserve complete W2 regression and reject private-verification performance gain (D629)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D621 source SHA and D629 adaptation/AST passed; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code,str(SOURCE),'exec'),dict(__file__=__file__,__name__='d629_publication'))
else:
    raise SystemExit('expected no arguments or --check-only')
