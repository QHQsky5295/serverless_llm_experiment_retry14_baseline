"""Reuse D621 bounded analysis; D629 collection is already closed, never rerun it."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d621_20261017/run_analysis.py')
code = source.read_text()
old = "commands=[('collection1.log',[sys.executable,str(raw/'collect_closure.py')]),\n          ('analysis1.log',[sys.executable,str(raw/'analyze.py')])]"
assert code.count(old) == 1
code = code.replace(old, """closed=json.loads((raw/'collection_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
binding=json.loads((raw/'qualification.json').read_text())
assert binding['passed'] and binding['count']==4000
for path,sha in {**binding['refs'],**binding['preserved']}.items():
    assert p.digest(Path(path))==sha,path
for path,sha in {
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'faaslora/memory/residency_manager.py':'3bf7490deff8c917bbad46b79526772a3803f9b030f559b8e63e976052d99407',
}.items():
    assert p.digest(path)==sha,path
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
commands=[('analysis1.log',[sys.executable,str(raw/'analyze.py')])]""")
exec(compile(code, str(source), 'exec'))
