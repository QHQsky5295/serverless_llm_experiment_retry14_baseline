"""Reuse D621 full-W2 binding; D628 qualification replaces affected source evidence."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d621_20261017/qualify.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace('4fa914baeb62b1a6644f0ab9bae10db475092ce8','e12e73f4ae1d2b91bad94c7bdcfb52f4f0783bcd')
start=code.index('# Production is unchanged');end=code.index('gate=p.preflight',start)
code=code[:start]+"""candidate=RAW.parent/'d628_20261017'
changed={ROOT/'faaslora/memory/residency_manager.py':'3bf7490deff8c917bbad46b79526772a3803f9b030f559b8e63e976052d99407',
    ROOT/'tests/test_ieee_tc_request_lifecycle.py':'4bd8e5141ea50765faca2edf0065a96245843cc6492521821f145a58ec057910'}
for path,sha in changed.items():assert p.digest(path)==sha
for path,sha in {**old['refs'],**old['preserved']}.items():
    if Path(path)!=shell:assert p.digest(Path(path))==changed.get(Path(path),sha),path
test_sources={}
import re
for phase,count in (('regression',410),('observation',52)):
    receipt=read(candidate/(phase+'_receipt.json'));assert receipt['passed']
    for path,sha in receipt['sources'].items():
        assert p.digest(Path(path))==sha,path
        test_sources[path]=sha
    log=candidate/(phase+'.log')
    assert p.digest(log)==receipt['log_sha256']
    assert sum(map(int,re.findall(r'Ran (\\d+) tests?',log.read_text())))==count
component=read(candidate/'component_result.json')
assert component['passed'] and component['production_sha256']==p.digest(ROOT/'faaslora/memory/residency_manager.py')
assert len(component['rows'])==6 and all(not row['hash_under_lock'] for row in component['rows'])
assert read(candidate/'publication_receipt.json')['head']=='e12e73f4ae1d2b91bad94c7bdcfb52f4f0783bcd'
for phase in ('focused','focused2','regression','observation','component','publication'):
    closed=read(candidate/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
latest=RAW.parent/'d624_20261017'
local=read(latest/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
stop=(latest/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive')==stop.count('MainPID=0')==3
for phase in ('qualification','backup','start','analysis','publication'):
    closed=read(latest/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
completed=read(latest/'actual_qualification.json');assert completed['passed'] and completed['protocol_bound_count']==4000
"""+code[end:]
replace("ROOT/'configs/ieee_tc/20261017_d619_7b_device_domain_full_w1.yaml'", "ROOT/'configs/ieee_tc/20261017_d621_7b_device_domain_full_w2.yaml'")
replace("ROOT/'configs/ieee_tc/20261017_d621_7b_device_domain_full_w2.yaml']", "ROOT/'configs/ieee_tc/20261017_d629_7b_private_verify_full_w2.yaml']")
code=code.replace("'  d621)\\n'", "'  d629)\\n'").replace('== d621', '== d629').replace("'d621' not", "'d629' not").replace("'d621' in", "'d629' in")
start=code.index('refs=[*helpers');end=code.index("subprocess.run(['git','diff','--check']",start)
code=code[:start]+"""refs=[*helpers,*paths,parent/'qualification.json',previous/'native_reuse.json',oldw2path,buildpath,
    candidate/'component_result.json',candidate/'publication_receipt.json',candidate/'publication_closure.json',
    latest/'local_cleanup.json',latest/'remote_stop.log',latest/'actual_qualification.json',
    Path(oldw2['adapter_map']),source]
refs += [candidate/(phase+suffix) for phase in ('regression','observation')
    for suffix in ('_receipt.json','.log','_closure.json')]
refs += [Path(path) for path in old['refs'] if Path(path)!=shell]
refs += list(map(Path,test_sources))
"""+code[end:]
replace('reused_cpu_regression_tests=464,reused_focused_tests=60', 'reused_cpu_regression_tests=462,reused_focused_tests=0')
replace('new_tests=0,reused_regression=464,reused_focused=60', 'new_tests=0,reused_regression=462,reused_focused=0')
replace('native_mechanism_reuse_only=True,device_domain_fix_sha256=',
        'private_verification_candidate=True,production_change_since_d621=True,native_mechanism_reuse_only=True,device_domain_fix_sha256=')
exec(compile(code,str(source),'exec'))
