"""Reuse D665 checked explicit-path prelaunch backup for D672."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/backup.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='937a74f3ade7d231db71f7fc99e328998d09e915b216498b7dfb5d3183a63221'
code=data.decode().replace('d665','d672').replace('D665','D672')
changes={
    'c77a161ae80cdefb5eb21f62c2a21ea2a295acae':'f8e95a1edc4d4602f92c091dfdecc0e9d5028018',
    "qualification['reused_cpu_tests']==655":"qualification['reused_cpu_test_invocations']==730",
    'same_configuration_as_d660_except_paths':'same_configuration_as_d665_except_paths',
    "previous=RAW.parent/'d664_20261018'":"previous=RAW.parent/'d671_20261018'",
    "closed=read(previous/'publication_closure.json')":"closed=read(previous/'backup_closure.json')",
    "('publication_identity.json','publication_receipt.json','publication_closure.json')":"('backup_identity.json','backup_receipt.json','backup_closure.json')",
    'tc: freeze unchanged 3B Full configuration for complete W0 replay (D672)':
    'tc: freeze one full 3B replay of independent HOST graph copying (D672)',
}
for old,new in changes.items():
    assert code.count(old)==1,old
    code=code.replace(old,new)
ast.parse(code)
exec(compile(code,str(source),'exec'))
