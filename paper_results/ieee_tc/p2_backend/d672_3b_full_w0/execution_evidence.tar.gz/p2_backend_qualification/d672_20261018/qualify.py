"""Reuse D665 preparation for one full W0 replay of the D671 copy candidate."""
import ast
import hashlib
from pathlib import Path

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/qualify.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='95ec19233568e28d778f733efd9b3d66422cc5cf23825e23763a0da115eff75c'
code=data.decode().replace('d665','d672').replace('D665','D672').replace('d660','d665')
start=code.index("prior=RAW.parent/'d663_20261018'")
end=code.index('shell=ROOT/',start)
code=code[:start]+'''prior=RAW.parent/'d671_20261018'
qualified_path=ROOT/'paper_results/ieee_tc/p2_backend/d671_independent_host_graph_copy/qualification.json'
qualified=read(qualified_path)
assert qualified['passed'] and qualified['production_candidate']
assert qualified['test_counts']=={'qualification':685,'qualification2':45}
assert qualified['regression']['passed'] and qualified['regression']['returncode']==0
assert qualified['old_environment']['passed'] is False and len(qualified['old_import_failures'])==3
refs={str(qualified_path):p.digest(qualified_path)}
for phase in ('qualification','qualification2'):
    receipt=read(prior/(phase+'_receipt.json'))
    assert p.digest(prior/(phase+'.log'))==receipt['log_sha256']
    for path,sha in receipt['source_sha256'].items():
        assert p.digest(Path(path))==sha,path
        refs[path]=sha
    for path,sha in receipt['preserved'].items():assert p.digest(Path(path))==sha
    closed=read(prior/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
closed=read(prior/'backup_closure.json')
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
assert read(prior/'backup_receipt.json')['head']=='f8e95a1edc4d4602f92c091dfdecc0e9d5028018'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='f8e95a1edc4d4602f92c091dfdecc0e9d5028018'
assert subprocess.check_output(['git','diff','--name-only','a3cdce75b60d1b55c2c88b9d0d828257349f6b43','HEAD','--','faaslora'],cwd=ROOT,text=True).splitlines()==['faaslora/memory/gpu_monitor.py']
previous_run=RAW.parent/'d665_20261018'
for phase in ('analysis','publication'):
    closed=read(previous_run/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
assert read(previous_run/'remote_stop.json')['all_owned_units_inactive']
assert read(previous_run/'local_cleanup.json')['passed']
native_audit_path=ROOT/'paper_results/ieee_tc/p2_backend/d665_3b_full_w0/completion/audit.json'
native_audit=read(native_audit_path)
assert native_audit['passed'] and native_audit['protocol_bound_count']==4000
assert native_audit['host_transaction']['passed']
refs[str(native_audit_path)]=p.digest(native_audit_path)
for path,sha in {
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'paper_results/ieee_tc/protocols/20261017_3b_slo_d648_frozen.json':'d15123570c4a8d830515ca942d1db553c6717ffc1a40ade5c1546d35e2bed9d8',
    ROOT/'paper_results/ieee_tc/main_comparison/d657_3b_references/resident_references.json':'f030f92f7bc426c427c6fa0ea65c8dd315a39cf52fd922973fc507117f30ea7a',
}.items():
    assert p.digest(path)==sha,path
    refs[str(path)]=sha
''' + code[end:]
code=code.replace("candidate_parent='7492ee71932491dec90f64e34213094a1769d21e'",
    "candidate_parent='f8e95a1edc4d4602f92c091dfdecc0e9d5028018'")
code=code.replace('reused_cpu_tests=655','reused_cpu_test_invocations=730')
code=code.replace('d672_same_configuration_native_host_candidate_full_w0_v1',
    'd672_independent_host_graph_copy_full_w0_v1')
code=code.replace("assert child==prepared['planned_child_model_config'] and env==prepared['child_environment']",
    """assert child==prepared['planned_child_model_config'] and env==prepared['child_environment']
assert not any('timing' in key and key!='timing_contract' for key in cfg['model'])
observer_guard=next(line for line in text.splitlines() if line.startswith('if [[') and '== d328' in line)
assert 'd672' not in observer_guard
""")
ast.parse(code)
exec(compile(code,str(source),'exec'))
