"""D672: reuse frozen D665 collector after actual local and remote closure."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/collect_closure.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'c03b7de0b731dd531dc267d0aec95b2ad904830211953c02be92ed165624a881'
code = data.decode()
assert code.count('d665') == 2
exec(compile(code.replace('d665', 'd672'), str(source), 'exec'))
