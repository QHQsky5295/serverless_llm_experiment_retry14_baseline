"""D672: run the existing post-release collection and audit in a bounded scope."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/run_analysis.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'b1e656c2390d956a63d456d88b89d86593671aea182efc0a23db65aacb0c1512'
exec(compile(data, str(source), 'exec'))
