"""D672: retain D665 complete-run checks, with the new immutable run identity."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/analyze.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '33609fce609f51520cfd4b5a9ba4b9c8e482f41d0d01b46a9e341c7ea18881a9'
code = data.decode()
assert code.count('d665') == 2
exec(compile(code.replace('d665', 'd672'), str(source), 'exec'))
