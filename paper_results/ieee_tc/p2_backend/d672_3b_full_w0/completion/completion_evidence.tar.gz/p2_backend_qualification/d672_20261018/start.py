"""Reuse D665 exact-owned launch gates; run D672 once with detailed observers off."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d665_20261018/start.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='8209cbf39f6234fab111676a66de5f4fc29693e68c6c77c30cb2b795b91b96f6'
code=data.decode().replace('d665','d672').replace('D665','D672')
old="binding['reused_cpu_tests']==655"
assert code.count(old)==1
code=code.replace(old,"binding['reused_cpu_test_invocations']==730")
old="'bash scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh d672'"
assert code.count(old)==1
code=code.replace(old,"'env -u FAASLORA_TC_CORE_TIMING -u FAASLORA_TC_CORE_STEP_TIMING -u FAASLORA_TC_HOST_INVENTORY_TIMING -u FAASLORA_TC_STACK_SAMPLING -u FAASLORA_TC_STACK_REPLAY_SCOPE bash scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh d672'")
ast.parse(code)
exec(compile(code,str(source),'exec'))
