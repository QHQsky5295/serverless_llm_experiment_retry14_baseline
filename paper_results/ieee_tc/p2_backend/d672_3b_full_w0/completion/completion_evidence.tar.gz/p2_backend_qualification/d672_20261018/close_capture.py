"""Exact-identity empty closure for the read-only launch-capture scope."""
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d668_20261018/close.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='2275f5fb7959fb2df7bf13a67cce7f4ebcd226a232ca9d6ecb5ec00d013ca68a'
code=data.decode()
old="('qualification','qualification2','backup','start','analysis','analysis2','publication','publication2')"
assert code.count(old)==1
code=code.replace(old,"('capture',)")
exec(compile(code,str(source),'exec'))
