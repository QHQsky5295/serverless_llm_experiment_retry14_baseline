"""Reuse D660 complete-run sealing and explicit-path backup for D672."""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d660_20261018/publish.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'b2b65c513b52e42c15486f8b50422d5df9307ebb38505c3516a312d51a53ed27'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d660_3b_full_w0'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d672_3b_full_w0/completion'")
replace("expected_head='24208f8d9bdbbbb2e667060b57d7d6b1f18184c8'",
        "expected_head='e5135ad0488ce256bc1ab33edeb3eab4d760f5af'")
replace("assert audit['passed'] and audit['protocol_bound_count']==4000",
        """assert audit['passed'] and audit['protocol_bound_count']==4000
assert audit['host_transaction']['passed'] and len(audit['host_transaction']['request_ids'])==1396
assert p.digest(ROOT/'faaslora/memory/gpu_monitor.py')=='0bec753ca9c5c04805f89940d83f75894a6c7f5b1a06d405d59389ce1cbea607'
assert p.digest(RAW/'analysis1.log')=='df21f561a8122fce11fe76b44562ead36dd09eab3e8a503e5e1201a0130523b6'""")
replace("for phase in ('qualification','backup','start','analysis'):",
        "for phase in ('qualification','backup','start','capture','analysis'):")
replace("assert OUT.is_dir() and not (OUT/'audit.json').exists()\nsubprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)",
        """assert OUT.parent.is_dir() and not OUT.exists()
prelaunch=OUT.parent
assert p.digest(prelaunch/'result.sha256')=='d45222dc8f2e02efa5872ceacc9952e5ce41c7fab10f72f77732b823a4c18756'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=prelaunch,check=True,stdout=subprocess.DEVNULL)
assert read(RAW/'backup_receipt.json')['passed']
capture=read(RAW/'capture_receipt.json')
assert capture['passed'] and capture['new_launches']==0 and capture['reobserved_same_launch']
assert not capture['serving_changed']
assert capture['service_identity']==read(RAW/'3b_full_w0/launch.json')['service_identity']
OUT.mkdir()""")
replace("'backup_identity.json','backup_receipt.json','backup_closure.json')]",
        """'backup_identity.json','backup_receipt.json','backup_closure.json')]
members += [RAW/name for name in ('capture_live_launch.py','close_capture.py',
    'capture_identity.json','capture_receipt.json','capture_closure.json')]
members += [RAW.parent/'d665_20261018'/name for name in
    ('collect_closure.py','run_analysis.py','analyze.py')]
members += [RAW.parent/'d660_20261018'/'publish.py']""")
replace("assert joint==3575 and audit['protocol_bound_count']==4000",
        """assert joint==3647 and audit['protocol_bound_count']==4000
previous_path=ROOT/'paper_results/ieee_tc/p2_backend/d665_3b_full_w0/completion/audit.json'
assert p.digest(previous_path)=='2495a30a67e16936c79c24601ecee62d6c77f580fed15932ab668e40cfb6225d'
previous=read(previous_path)
assert previous['workload_identity']==audit['workload_identity']
assert previous['native_tokens']==audit['native_tokens']
metrics=('mean_ttft_ms','p95_ttft_ms','mean_tpot_ms','p95_tpot_ms','mean_e2e_ms','physical_gpu_seconds')
comparison=dict(kind='d672_vs_d665_complete_w0_single_observation_v1',
    previous_audit=dict(path=str(previous_path),sha256=p.digest(previous_path)),
    current_audit_sha256=p.digest(RAW/'analysis1.log'),
    workload_identity=audit['workload_identity'],native_tokens=audit['native_tokens'],
    previous_joint_count=previous['common_threshold_joint_count'],current_joint_count=joint,
    joint_delta_percentage_points=(joint-previous['common_threshold_joint_count'])/40,
    metrics=[dict(metric=k,previous=previous['stats'][k],current=audit['stats'][k],
        lower_better_improvement_percent=100*(previous['stats'][k]-audit['stats'][k])/previous['stats'][k]) for k in metrics],
    previous_stage_means_ms=previous['stage_means_ms'],current_stage_means_ms=audit['stage_means_ms'],
    previous_phases=previous['source_order_phases'],current_phases=audit['source_order_phases'],
    previous_remote_transfers=previous['remote_transfers'],current_remote_transfers=audit['remote_transfers'],
    previous_remote_wire_bytes=previous['remote_wire_bytes'],current_remote_wire_bytes=audit['remote_wire_bytes'],
    observed_joint_and_resource_improvement=joint>previous['common_threshold_joint_count'] and u<previous['stats']['physical_gpu_seconds'],
    performance_goal_met=False,accepted_as_final=False,confidence_interval=None,independent_holdout=False,
    caveat='Known fixed workload, one observation per version; joint SLO and physical GPU time improved, but joint SLO remains below .95. No causal percentage attribution, numerical-proof upgrade or final ranking; retain every phase including regression.')
assert comparison['observed_joint_and_resource_improvement'] and joint<3800
save(OUT/'comparison_d665.json',comparison)
files+=['comparison_d665.json']""")
replace("kind='d660_3b_complete_w0_seal_v1'", "kind='d672_independent_host_graph_copy_complete_w0_seal_v1'")
replace("joint_slo_fraction=joint/4000,joint_slo_pass=False,",
        """joint_slo_fraction=joint/4000,joint_slo_pass=joint>=3800,
    host_transaction=audit['host_transaction'],
    immutable_prelaunch_sha256=p.digest(prelaunch/'result.sha256'),
    comparison_sha256=p.digest(OUT/'comparison_d665.json'),
    observed_joint_and_resource_improvement=True,accepted_as_final=False,
    launch_observation_race=read(RAW/'capture_receipt.json'),""")
replace("caveat='W0 complete native-binding/count/timing observation, not independent numerical qualification, canonical matched cross-system comparison, or G1/G2 success; all 8 phases below .95.'",
        "caveat='W0 complete native-binding/count/timing observation, not independent numerical qualification, canonical matched cross-system comparison, or G1/G2 success; 7 of 8 phases and the total remain below .95.'")
replace("no_figures=True,no_runtime_source_change=True,",
        "no_figures=True,publication_runtime_source_changed=False,")
replace("next_action='Retained-data diagnosis of persistent 3B wait/preparation/control and scaling occupancy, then one falsifiable candidate if supported; no W1/W2 launch before resolving this W0 shortfall.'",
        "next_action='Retain the single-copy candidate and compare existing D665/D672 per-request TTFT/TPOT violations and control waits before selecting one new hypothesis; no same-key replay, threshold change or W1/W2 closure. Recheck storage before another heavy task.'")
replace('docs/ieee_tc/D660_3B_FULL_W0.md', 'docs/ieee_tc/D672_3B_FULL_W0.md')
replace('tc: seal complete 3B Full W0 and retained SLO shortfall (D660)',
        'tc: seal 3B HOST-copy improvement with remaining SLO gap (D672)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D672 completion adaptation parsed; no outputs, staging or publication.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no args or --check-only')
