"""Capture the already live D672 launch after an empty-file observation race.

No tmux/service creation, retry, configuration change, model import or bulk scan.
The original starter exited after starting tmux but before saving its identity.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'capture_identity.json',identity)
cg=Path(identity['path'])
assert os.sched_getaffinity(0)=={2,3,26,27}
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
session='tc-d672-3b-w0'
pane=subprocess.check_output(['tmux','list-panes','-t',session,'-F','#{pane_pid} #{pane_dead}'],text=True).splitlines()
assert len(pane)==1
pid,dead=pane[0].split()
assert dead=='0' and Path('/proc',pid).exists()
receipt=RAW/'3b_full_w0/launch.launch/exec_receipt.json'
launched=json.loads(receipt.read_text())
service=launched['service_identity']
assert p.scope_still_owned(service)
auxiliary=p.scope_identity(Path(launched['auxiliary_path']).name)
assert auxiliary['path']==launched['auxiliary_path']
assert p.scope_still_owned(auxiliary)
assert any(path.read_text().split() for path in Path(service['path']).rglob('cgroup.procs'))
closed=json.loads((RAW/'start_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
backup=json.loads((RAW/'backup_receipt.json').read_text())
assert backup['passed']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==backup['head']
save(RAW/'service_aux_identity.json',auxiliary)
record=dict(launched=True,head=backup['head'],baseline_head='e16af33aaf41f02a62ecdce59f6f3227813244c3',
    tmux=session,starter_identity=closed['identity'],launcher_identity=auxiliary,
    service_identity=service,observed_pane_pid=int(pid),
    starter_error='JSONDecodeError at empty exec_receipt read after tmux was started; session 1842 exit1',
    reobserved_same_launch=True,new_launches=0,serving_changed=False,
    exec_receipt_sha256=p.digest(receipt),capture_identity=identity)
save(RAW/'start_receipt.json',record)
save(RAW/'capture_receipt.json',dict(passed=True,**record,
    resources={k:(cg/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,session=session,pane_pid=pid,service=service,auxiliary=auxiliary,new_launches=0)))
