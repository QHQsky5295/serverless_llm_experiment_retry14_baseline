"""Reuse D185 source/config checks and D143 diagnostic-prefix qualification."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight, check_plan
from faaslora.runtime_configuration import resolve_facade_lora_capacity
from faaslora.datasets.workload_generator import FrozenReplayPlan

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d187_20261003'
previous = root/'results/ieee_tc/p2_backend_qualification/d185_20261003'
expected_commit = 'e82a8ecc852d31db5e49f093a84ef9f49db205d6'
runtime_commit = '2615d240b567043e4ca92b0debc30a0480e0b347'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected_commit
dirty = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty) <= {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'}, dirty
assert not subprocess.check_output(['git','diff','--name-only',runtime_commit,expected_commit,'--','faaslora','scripts','tests'],cwd=root,text=True).strip()
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old_path,new_path = previous/'7b_main_config_full1.yaml',raw/'7b_main_config_prefix1.yaml'
old,new = [yaml.safe_load(p.read_text()) for p in (old_path,new_path)]
assert old['workload']['total_requests'] == 4000 and new['workload']['total_requests'] == 1000
for config in (old,new):
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
    del config['workload']['total_requests']
assert old == new, 'configuration differs beyond diagnostic prefix and three fresh paths'
assert not (raw/'7b_full_w0_prefix1/launch.json').exists()
assert not (raw/'7b_nvme_prefix1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d187-7b-prefix1/tc_ieee_full').exists()
prior = previous/'prelaunch_verification.json'
assert digest(prior) == 'ce8fd3e0239845d94a805fde9e63f1fbfab22c6fbfa2b5c1bb1b311bb1577647'
before = json.loads(prior.read_text())
refs = dict(before['source_sha256'])
for name,expected in refs.items():
    path = Path(name) if name.startswith('/') else root/name
    assert digest(path) == expected, name
# Observer and prefix interface already qualified; verify identities, no re-test.
for name in ('faaslora/utils/logger.py','faaslora/__init__.py','tests/test_ieee_tc_stack_diagnostic.py'):
    expected = hashlib.sha256(subprocess.check_output(['git','show','a494c90c017e5307ff59f1d9ff7c4dde214d6bbf:'+name],cwd=root)).hexdigest()
    assert digest(root/name) == expected, name
    refs[str(root/name)] = expected
interface = root/'paper_results/ieee_tc/p2_backend/20260930_d122_diagnostic_prefix'
assert digest(interface/'verification.json') == 'f266677bbdf57a667de6857a34f57c678e8c17ccfecff5ba5f28ee0303ab51d0'
assert digest(interface/'summary.json') == '57f55221ffc0b81da08de2eb50280e571a8d4ade0f9383597fcecf4b63c996c2'
context = json.loads((interface/'summary.json').read_text())['next_diagnostic_input']
plan = FrozenReplayPlan.from_launch_context(context)
assert len(plan.entries) == 1000 and plan.source_count == 4000 and plan.profile == 'W0'
assert plan.source_sha256 == before['trace']['source_sha256']
assert digest(Path(before['trace']['source_path'])) == plan.source_sha256
assert digest(Path(before['subset']['path'])) == before['subset']['sha256']
model = resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras'] == 24
assert model['max_num_seqs'] == model['runtime_concurrency_cap'] == model['requested_runtime_concurrency_cap'] == model['max_loras'] == 4
manifest_path = root/'paper_results/ieee_tc/p2_backend/d157_7b_initialization/manifest.json'
assert digest(manifest_path) == '51419cc52b607deb61c71554163ceeda4f6dfda91916bf39af8965cc4c7676ad'
manifest = json.loads(manifest_path.read_text())
assert manifest['pass'] and manifest['coverage']['class_domain_covered']
for key in ('ieee_service_profile','ieee_preparation_profile'):
    binding = new['resource_coordination'][key]
    assert binding == manifest['bindings'][key]
    assert digest(root/binding['path']) == binding['sha256']
contract = json.loads((root/manifest['contract']['path']).read_text())
assert new['resource_coordination'] == contract['coordination'] | manifest['bindings']
for path in [raw/name for name in ('7b_main_config_prefix1.yaml','run_7b_full_w0_prefix1.sh',
    'profile_controller_python.sh','activate_services_prefix1.sh','check_health.sh','run_health.sh',
    'verify_prefix1_prelaunch.py','prepare_prefix1.sh')] + [
    interface/'summary.json',interface/'verification.json',manifest_path,prior,old_path,
    root/'docs/ieee_tc/D186_CONTROL_PATH_DIAGNOSIS.md']:
    refs[str(path)] = digest(path)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
resources = preflight([root,raw],32*1024**3)
assert resources['preflight_pass'], resources['issues']
receipt = dict(kind='d187_current_cap4_stack_prefix_prelaunch_v1',time_unix=time.time(),
    run='d187_7b_full_w0_prefix1',evidence_commit=expected_commit,runtime_source_commit=runtime_commit,
    serving_policy_change=False,diagnostic_hook_opt_in=True,same_configuration_except_owned_paths_and_population=True,
    diagnostic_instrumentation=True,formal_performance_result=False,source_sha256=refs,
    protected=protected,resource_preflight=resources,trace=plan.identity(),subset=before['subset'],
    replay_scope='diagnostic_prefix_v1',diagnostic_prefix_count=1000,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),plan_sha256=check_plan(),
    hypothesis='D185 GPU-ready requests still wait before source admission and at completion; identify current synchronous source/control work before selecting one optimizer.',
    observer=dict(implementation='CPython3.12 sys._current_frames in Python thread',
        period_seconds=2.0,gil_scheduling_bias=True,actual_sample_times=True,all_threads=True,includes_idle=True,
        immediate_per_dump_write=True,cpu_time_profile=False,collect_locals=False,native_extension_frames=False,
        missing_role_samples='report missing; do not infer zero cost'),
    comparison='Current diagnostic only; D162 predates multiple serving changes, no paired performance comparison to D162 or ordinary Full.',
    reused_initialization='Current D157 cap4 profiles and D185 Full parent; no new profile/data/cache',
    warm_reference_sha=None,resource_reference_sha=None,
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),sha256=digest(raw/'prelaunch_verification.json'),
    protected=147,source_refs=len(refs),population=1000,source_count=4000,resource_pass=True,formal=False)))
