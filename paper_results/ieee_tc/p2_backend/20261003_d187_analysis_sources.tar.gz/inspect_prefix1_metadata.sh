#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d187_20261003
unit=primelora-d187-prefix1-metadata-20261003.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test "$(systemctl --user show primelora-tc-svc-d5185e419c9f46fdb2796763d0387c63.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show primelora-tc-aux-25638d8b7beb4988baa7d9c5223ccb47.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test -s "$raw/7b_full_w0_prefix1/launch.json"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/prefix1_metadata_scope.txt"
# Exact D138 tested lossless line-indentation transform; no JSON reserialization.
source_file="$raw/7b_full_w0_prefix1/launch.launch/physical_deployment/main_outcome.json"
compact_file="$raw/prefix1_main_outcome_compact.json"
LC_ALL=C sed -e 's/^ *//' -e 's/ *$//' "$source_file" > "$compact_file"
test "$(stat -c %s "$compact_file")" -lt 134217728
sha256sum "$source_file" "$compact_file" > "$raw/prefix1_metadata_compaction.sha256"
/usr/bin/time -v -o "$raw/prefix1_metadata_time.txt" /usr/bin/python3 "$raw/collect_prefix1_preliminary.py" > "$raw/prefix1_metadata.log" 2>&1
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
