"""D161 small-file evidence sealing reused for the completed D187 diagnostic."""
import ast
import hashlib
import json
import re
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d187_20261003'
out = root/'paper_results/ieee_tc/p2_backend'
verification_path = out/'20261003_d187_evidence_verification.json'
assert not verification_path.exists()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert not subprocess.check_output(['git','diff','--name-only','2615d240b567043e4ca92b0debc30a0480e0b347','--','faaslora','scripts','tests','configs/ieee_tc'],text=True).strip()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
curated = out/'20261003_d187_prefix_diagnostic.json'
assert digest(curated) == '896bf0ede6b0849268278174c35e94e44f3891bfca90942d2276ae915d12c7c6'
value = json.loads(curated.read_text())
assert not value['formal_performance_result'] and value['prefix_count']==1000
refs = {}
for ref in value['source_refs'] + [r for p in value['cpu']['processes'] for r in p['source_refs']]:
    p = Path(ref['path']).resolve()
    if str(p) in refs:
        assert refs[str(p)] == ref['sha256']
    else:
        assert digest(p) == ref['sha256'], str(p)
        refs[str(p)] = ref['sha256']
preflight = json.loads((raw/'prelaunch_verification.json').read_text())
for path, sha in preflight['source_sha256'].items():
    assert digest(root/path) == sha, path
closures = []
for suffix, expected, receipt in (
    ('cpu-collection','24caf363a4ef49d7ab35b9510c5e23b7','cpu_collection_scope.txt'),
    ('prefix1-metadata','c2914e4dcd0249fcbf86c06f45963583','prefix1_metadata_scope.txt'),
    ('prefix1-curation','0955f915993b47fe9ffe5b7efab7cc17','prefix1_curation_scope.txt')):
    unit = f'primelora-d187-{suffix}-20261003.scope'
    assert f'InvocationID={expected}' in (raw/receipt).read_text()
    for prop, wanted in (('ActiveState','inactive'),('InvocationID',''),('ControlGroup','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip()==wanted
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    closures.append(dict(unit=unit,actual_invocation_id=expected,inactive=True,
        cgroup_absent=True,final_counters='zero in terminal tool output; not reread after removal'))
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
for p in raw.glob('*.py'):
    ast.parse(p.read_text(),filename=str(p))
for p in raw.glob('*.sh'):
    subprocess.run(['bash','-n',str(p)],check=True)
e = raw/'7b_full_w0_prefix1/launch.launch'
large = [e/'watchdog.jsonl',raw/'remote_monitor_prefix1_final.log',
         e/'physical_deployment/main_outcome.json',Path(value['preliminary']['normal_source_stat']['path'])]
large_refs = [dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=digest(p)) for p in large]
doc = root/'docs/ieee_tc/D187_CURRENT_PREFIX_DIAGNOSTIC.md'
table = out/'20261003_d187_prefix_roles.csv'
assert digest(table)=='74e6252613e6d880c0c4c60ef7d3f34d7c87c06687a42ddcaef10b998f13ad75'
# Reconcile this diagnostic's exact document table with the saved role counters.
document = doc.read_text()
expected_rows = [
    (455713, 'preparation_snapshot', 95, 536),
    (455713, '_local_file_inventory', 30, 536),
    (455713, '_decode_native_rpc_frame', 46, 536),
    (456655, 'owned_preparation_inputs', 94, 539),
    (456655, 'freeze_preparation_source_view', 63, 539),
    (458394, '_ieee_lora_host_inventory', 96, 546),
    (462721, '_ieee_lora_host_inventory', 65, 524),
    (462924, '_ieee_lora_host_inventory', 68, 523),
    (463013, '_ieee_lora_host_inventory', 74, 521),
]
for pid, function, count, denominator in expected_rows:
    detail, = [r for r in value['request_window_details'] if r['pid'] == pid]
    assert detail['window_samples'] == denominator
    entries = [r for r in detail['inclusive'] if r['function'] == function]
    assert len(entries) == 1 and entries[0]['samples'] == count
    assert f'/ {pid} | {denominator} | {function} | {count} |' in document
controller, = [r for r in value['cpu']['processes'] if r['pid'] == 455713]
assert next(r['samples'] for r in controller['request_window_nearest_project']
            if r['function'] == 'execution_bundle_copy') == 22
assert '/ 455713 | 536 | execution_bundle_copy（最近项目帧） | 22 |' in document
assert sum(p['truncated_main_samples'] for p in value['cpu']['processes']) == 5
assert value['preliminary']['population']['success'] == 1000
assert value['preliminary']['remote']['uuid_pairs'] == 60
assert value['preliminary']['remote']['client_received_bytes'] == 74953014
assert value['preliminary']['physical_gpu_seconds'] == 4446.963003285113
# Preserve original logs and analysis helpers in one small portable bundle.
# Only bounded small files; the normal result, compact metadata and raw stacks
# stay in the existing result directory with their SHA references.
members = sorted(p for p in raw.iterdir() if p.is_file() and p.stat().st_size < 2*1024**2
    and p.suffix in {'.py','.sh','.log','.txt','.json','.yaml','.sha256'}
    and p.name not in {'seal1.log','seal_scope1.txt','launch_outer1.log'})
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret)>16
for p in members+[doc,table,curated]:
    data = p.read_bytes()
    assert secret not in data, 'credential found'
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
result = dict(kind='d187_diagnostic_evidence_verification_v1',
    verified_at=datetime.now(timezone.utc).isoformat(),checks_pass=True,
    formal_performance_result=False,serving_changed=False,
    source_refs=[dict(path=p,sha256=sha) for p,sha in sorted(refs.items())],
    curated_refs=[dict(path=str(p.resolve()),sha256=digest(p)) for p in (doc,table,curated)],
    frozen_refs_verified=len(preflight['source_sha256']),protected=protected,closures=closures,
    large_source_refs=large_refs,
    next='Study immutable preparation descriptions versus fresh dynamic owner state; no optimizer accepted')
with verification_path.open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
hashes = {p.name:digest(p) for p in members}
bundle = out/'20261003_d187_analysis_sources.tar.gz'
assert not bundle.exists()
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name,expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected
with (out/'20261003_d187_analysis_sources.sha256').open('x') as f:
    f.write(digest(bundle)+'  '+bundle.name+'\n')
with (out/'20261003_d187_analysis_sources_members.json').open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(verification_sha256=digest(verification_path),
    bundle_sha256=digest(bundle),bundle_bytes=bundle.stat().st_size,members=len(members),
    protected=147,source_refs=len(refs),frozen_refs=len(preflight['source_sha256']))))
