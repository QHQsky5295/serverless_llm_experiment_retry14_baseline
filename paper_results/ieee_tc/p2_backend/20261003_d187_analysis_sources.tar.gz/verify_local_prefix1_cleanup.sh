#!/usr/bin/env bash
# Reuse post-exit absence receipt; no manual stop of removed scopes.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d187_20261003
{
  date -Is
  jq -e '.pass == true and .service_returncode == 0 and .replay_returncode == 0 and .watchdog_returncode == 0 and .native_gpu_context_release_confirmed == true and .service_path_removed == true and .service_identity.invocation_id == "5df1ea275ce24ac4bc06d779e111a636"' "$raw/7b_full_w0_prefix1/launch.json"
  for unit in primelora-tc-svc-d5185e419c9f46fdb2796763d0387c63.scope primelora-tc-aux-25638d8b7beb4988baa7d9c5223ccb47.scope; do
    test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
    test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
    test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
    systemctl --user show "$unit" -p Id -p ActiveState -p InvocationID -p TasksCurrent
  done
  for pid in 455543 455713 456655 457582 458394 461669 461864 461924 462721 462924 463013; do
    test ! -e "/proc/$pid"
    printf 'owned_pid=%s absent\n' "$pid"
  done
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  printf 'cleanup=automatic_removal_verified\nfinal_cgroup_events=unavailable_after_removal\n'
} | tee "$raw/prefix1_local_cleanup.txt"
