"""D362 native-source starter reused with D524 tested checkpoint and gates."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
pub=ROOT/'paper_results/ieee_tc/p2_backend/d524_metadata_profiles'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
with (raw/'start_identity.json').open('x') as stream:json.dump(identity,stream,indent=2)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote=='d4cddb5d1429098942362dcc50ebf79e51981799'
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','scripts','faaslora','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
checkpoint=json.loads((pub/'checkpoint.json').read_text())
for name,sha in checkpoint['qualification']['sources'].items():assert p.digest(ROOT/name)==sha
for name in ('preparation','backup'):
    closed=json.loads((raw/(name+'_closure.json')).read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
receipt=json.loads((raw/'backup_receipt.json').read_text())
assert receipt['passed'] and receipt['head']==head
assert p.digest(pub/'checkpoint.json')==receipt['checkpoint_sha256']
gate=p.preflight([ROOT],8*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not (raw/'source1.json').exists() and not (raw/'source1_launch.json').exists()
assert subprocess.run(['tmux','has-session','-t','tc-d524-source'],stderr=subprocess.DEVNULL).returncode!=0
protected=p.verify_seal(raw.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
with (raw/'launch_gate.json').open('x') as stream:
    json.dump(dict(passed=True,head=head,remote=remote,gate=gate,identity=identity,protected=protected),stream,indent=2)
for name in ('start_remote.sh','stop_remote.sh'):
    subprocess.run(['bash','-n',str(raw/name)],check=True)
subprocess.run(['bash',str(raw/'start_remote.sh')],check=True)
subprocess.run([sys.executable,str(raw/'check_remote_health.py')],cwd=ROOT,check=True)
subprocess.run(['tmux','new-session','-d','-s','tc-d524-source','-c',str(ROOT),
    'bash scripts/ieee_tc/run_d298_capacity_source.sh d524'],check=True)
with (raw/'start_receipt.json').open('x') as stream:
    json.dump(dict(launched=True,head=head,remote=remote,tmux='tc-d524-source',identity=identity),stream,indent=2)
print(json.dumps(dict(launched=True,head=head,tmux='tc-d524-source')),flush=True)
