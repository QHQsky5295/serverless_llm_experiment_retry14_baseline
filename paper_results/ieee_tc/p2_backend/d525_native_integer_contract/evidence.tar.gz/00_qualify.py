"""Reuse D522 bounded CPU qualification for the affected native input boundary."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import types
import unittest
import urllib.request

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
PUB = ROOT / 'paper_results/ieee_tc/p2_backend/d525_native_integer_contract'
OLD = RAW.parent / 'd524_20261014'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

own = p.scope_identity(p.cg_path().name)
save(RAW/'cpu_identity.json', own)
group = Path(own['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate = p.preflight([ROOT], p.GIB)
assert gate['preflight_pass'], gate['issues']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
seal = RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json'
protected = p.verify_seal(seal)
assert protected['pass'] and protected['entry_count'] == 147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)

# Bound comparison to exact official installed producer/wrapper, not its hints.
source_refs = []
site = Path(sys.prefix)/'lib/python3.12/site-packages'
for name in ('vllm/v1/worker/gpu/lora_utils.py', 'vllm/lora/layers/utils.py',
             'vllm/v1/worker/lora_model_runner_mixin.py'):
    url = 'https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/' + name
    with urllib.request.urlopen(url, timeout=30) as response:
        body = response.read(512*1024)
    local = site/name
    assert body == local.read_bytes(), name
    source_refs.append(dict(path=str(local), url=url, sha256=p.digest(local), byte_equal=True))
save(RAW/'source_identity.json', source_refs)

# Replay the failure against the preserved previous helper, with real V2 inputs.
from tests.test_ieee_tc_lora_metadata_lowering import native_request_mapping
mapping, active = native_request_mapping()
previous = subprocess.check_output(['git','show','d4cddb5:faaslora/utils/lora_metadata.py'],cwd=ROOT)
old_module = types.ModuleType('_d525_previous_helper')
sys.modules[old_module.__name__] = old_module
exec(compile(previous, '<preserved-d524-helper>', 'exec'), old_module.__dict__)
reproduced = None
try:
    old_module.lower_dense_lora_metadata(index_mapping=mapping.index_mapping,
        prompt_mapping=mapping.prompt_mapping, slot_layout=(7,9), vocab_size=32000,
        max_num_tokens=8, captured_lora_counts=(1,2,3))
except ValueError as error:
    reproduced = str(error)
assert reproduced == 'index_mapping must be an immutable tuple of integers'
reproduction = dict(old_helper_sha256=hashlib.sha256(previous).hexdigest(),
    producer_scalar_types=sorted({type(value).__module__+'.'+type(value).__name__
                                 for value in mapping.index_mapping}),
    exact_failure_reproduced=True, error=reproduced, active_ids=sorted(x.lora_int_id for x in active))
save(RAW/'failure_reproduction.json', reproduction)

with (RAW/'cpu_tests.log').open('x') as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromNames([
            'tests.test_ieee_tc_lora_metadata_lowering',
            'tests.test_ieee_tc_lora_metadata_publication',
            'tests.test_ieee_tc_worker_observation', 'tests.test_basic_smoke']))
import torch
assert not torch.cuda.is_initialized()
sources = ('faaslora/utils/lora_metadata.py','faaslora/memory/lora_metadata_publication.py',
    'tests/test_ieee_tc_lora_metadata_lowering.py','tests/test_ieee_tc_lora_metadata_publication.py',
    'tests/test_ieee_tc_worker_observation.py','tests/test_basic_smoke.py')
record = dict(passed=result.wasSuccessful() and not result.skipped, tests=result.testsRun,
    failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
    identity=own,gate=gate,protected=protected,official_sources=source_refs,
    failure_reproduction=reproduction,cuda_initialized=False,gpu_qualified=False,
    performance_qualified=False,numerical_adapter_correctness_qualified=False,
    sources={name:p.digest(ROOT/name) for name in sources})
save(RAW/'cpu_result.json',record)
assert record['passed'], 'CPU qualification failed; preserve attempt'

# D524 is a failed qualification, not a performance sample or timing initializer.
source = json.loads((OLD/'source1.json').read_text())
assert p.digest(OLD/'source1.json') == 'ef1a60e0e68e168727a81bb90fbac1db61ac19bdfdef1121e7522ce9b24b98f6'
assert not source['pass'] and source['stage'] == 'source_profile_wave:0'
assert len(source['requests']) == 14 and not any(row.get('pass') for row in source['requests'])
cleanup = json.loads((OLD/'local_cleanup.json').read_text())
assert cleanup['actual_recursive_procs_empty'] and cleanup['auxiliary_path_gone'] and cleanup['service_path_gone']
assert not Path(cleanup['identity']['path']).exists()
remote = json.loads((OLD/'remote_stop.json').read_text())
assert all(remote[key] for key in ('all_owned_units_inactive','ports_18080_18081_absent',
                                  'local_gpu_release_verified_before_remote_stop','download_hashes_match_remote'))
for name,sha in remote['hashes'].items(): assert p.digest(OLD/name) == sha
worker = ROOT/'results/worker_failures/faaslora_worker_1bwmdm92_fatal_rpc_1791982120/worker.log'
assert reproduced in worker.read_text()
assert 'lora_metadata.py' in worker.read_text()
samples = [json.loads(line) for line in (OLD/'source1_launch.launch/watchdog.jsonl').read_text().splitlines()]
events = [row for row in samples if row.get('event') == 'sample']
failure = dict(status='failed_closed',classification='candidate_input_contract_error',
    performance_observation=False,timing_export_allowed=False,request_records=14,passed_records=0,
    stage=source['stage'],root_error=reproduced,wrapper_error=source['error'],
    source_sha256=p.digest(OLD/'source1.json'),worker_log_sha256=p.digest(worker),
    metadata_host_installation=source['metadata_host_installation'],
    metadata_global_host_budget=source['metadata_global_host_budget'],
    local_cleanup=cleanup,remote_stop=remote,failure_reproduction=reproduction,
    physical_released=source['physical_allocation']['released'],shutdown_called=source['shutdown_called'],
    watchdog_sha256=p.digest(OLD/'source1_launch.launch/watchdog.jsonl'),
    source_checkpoint='d4cddb5d1429098942362dcc50ebf79e51981799')
assert failure['physical_released'] and failure['shutdown_called']
PUB.mkdir(parents=True,exist_ok=False)
save(PUB/'cpu_qualification.json',record)
save(PUB/'d524_failure.json',failure)
assert p.verify_seal(seal)['pass']
print(json.dumps(dict(passed=True,tests=result.testsRun,exact_previous_failure_reproduced=True,
    cuda_initialized=False,new_performance_result=False)),flush=True)
