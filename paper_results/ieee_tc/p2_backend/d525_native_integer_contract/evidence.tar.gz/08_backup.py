"""D524 explicit-path, protected-evidence checkpoint protocol, reused for D525."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OLD = RAW.parent/'d524_20261014'
PUB = ROOT/'paper_results/ieee_tc/p2_backend/d525_native_integer_contract'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
read = lambda path:json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
own = p.scope_identity(p.cg_path().name)
save(RAW/'backup_identity.json',own)
group = Path(own['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert p.preflight([ROOT],p.GIB)['preflight_pass']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == 'd4cddb5d1429098942362dcc50ebf79e51981799'
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
tested = read(PUB/'cpu_qualification.json')
assert tested['passed'] and tested['tests'] == 393 and not tested['cuda_initialized']
assert (tested['failures'],tested['errors'],tested['skipped']) == (0,0,0)
for name,sha in tested['sources'].items():assert p.digest(ROOT/name) == sha
for item in tested['official_sources']:assert item['byte_equal'] and p.digest(Path(item['path'])) == item['sha256']
closure = read(RAW/'cpu_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
assert not Path(closure['identity']['path']).exists()
failure = read(PUB/'d524_failure.json')
assert failure['status'] == 'failed_closed' and not failure['timing_export_allowed']
assert failure['failure_reproduction']['exact_failure_reproduced']
assert failure['source_sha256'] == p.digest(OLD/'source1.json')
assert read(OLD/'local_cleanup.json')['native_gpu_release_confirmed']
assert all(read(OLD/'remote_stop.json')[key] for key in ('all_owned_units_inactive','ports_18080_18081_absent'))
samples = [json.loads(line) for line in (OLD/'source1_launch.launch/watchdog.jsonl').read_text().splitlines()]
samples = [row for row in samples if row.get('event') == 'resource_sample']
resources = dict(samples=len(samples),peak_bytes=max(r['service']['memory.peak'] for r in samples),
    max_swap_bytes=max(r['service']['memory.swap.current'] for r in samples),
    min_host_available_bytes=min(r['host']['available_bytes'] for r in samples),
    memory_events={key:max(r['service']['memory.events'][key] for r in samples)
        for key in ('high','max','oom','oom_kill')},
    abort_samples=sum(bool(r['decision']['abort_reasons']) for r in samples))
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
preserved = {ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    ROOT/'docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D519.md':'e0ed5415b779effec429b48ea716abde2e3e9b1a379d5abbc11073cdca2f3a99',
    BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(path) == sha
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def secrets(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
evidence = [RAW/name for name in ('qualify.py','cpu_identity.json','cpu_tests.log','cpu_result.json',
    'source_identity.json','failure_reproduction.json','cpu_closure.json','close.py','backup.py')]
evidence += [OLD/name for name in ('source1.json','source1_launch.json','source_commit.txt',
    'source1_launch.launch/watchdog.jsonl','source1_launch.launch/service.log','local_cleanup.json',
    'remote_stop.json','remote_stop.log','remote_transfers.jsonl','remote_monitor.log','analysis_closure.json',
    'start1_failure.json','start.py','resume_start.py','check_remote_health.py','check_remote_health_stdlib.py')]
evidence.append(ROOT/'results/worker_failures/faaslora_worker_1bwmdm92_fatal_rpc_1791982120/worker.log')
members = {}
with tarfile.open(PUB/'evidence.tar.gz','x:gz') as archive:
    for i,path in enumerate(evidence):
        data=path.read_bytes();secrets(data)
        assert len(data)<2*1024**2
        name=f'{i:02d}_'+path.name
        info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0
        archive.addfile(info,io.BytesIO(data))
        members[name]=dict(source=str(path),sha256=hashlib.sha256(data).hexdigest())
with tarfile.open(PUB/'evidence.tar.gz') as archive:
    assert set(archive.getnames()) == set(members)
    for name,item in members.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==item['sha256']
runner=ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh'
subprocess.run(['bash','-n',str(runner)],check=True)
save(PUB/'checkpoint.json',dict(passed=True,qualification_sha256=p.digest(PUB/'cpu_qualification.json'),
    protected=protected,cpu_closure=closure,d524_resources=resources,
    d524_failure_sha256=p.digest(PUB/'d524_failure.json'),archive_members=members,
    archive_sha256=p.digest(PUB/'evidence.tar.gz'),runner_sha256=p.digest(runner),
    next='D526 affected source calibration with unchanged D524 config/spec; not yet launched'))
paths=['faaslora/utils/lora_metadata.py','tests/test_ieee_tc_lora_metadata_lowering.py',
    'tests/test_ieee_tc_lora_metadata_publication.py','scripts/ieee_tc/run_d298_capacity_source.sh',
    'docs/ieee_tc/D525_NATIVE_INTEGER_CONTRACT.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str(path.relative_to(ROOT)) for path in sorted(PUB.iterdir()) if path.is_file()]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
for name in paths:
    data=(ROOT/name).read_bytes();secrets(data)
    assert len(data)<2*1024**2
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(paths)
for name in paths:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT);secrets(data)
    assert hashlib.sha256(data).hexdigest()==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: accept exact native CPU integer mappings and retain failed D524 (D525)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'backup_receipt.json',dict(passed=True,head=head,remote=remote,paths=paths,
    identity=own,checkpoint_sha256=p.digest(PUB/'checkpoint.json')))
print(json.dumps(dict(passed=True,head=head,files=len(paths))),flush=True)
