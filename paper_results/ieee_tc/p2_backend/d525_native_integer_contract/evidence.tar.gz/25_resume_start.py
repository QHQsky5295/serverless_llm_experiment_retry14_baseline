"""Continue after management-only import failure, without restarting remote."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
def save(name,value):
    with (raw/name).open('x') as stream:json.dump(value,stream,indent=2)
save('start2_identity.json',identity)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not (raw/'source1_launch.json').exists() and not (raw/'source1.json').exists()
assert not (raw/'start_receipt.json').exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.run(['tmux','has-session','-t','tc-d524-source'],stderr=subprocess.DEVNULL).returncode!=0
assert json.loads((raw/'start_closure.json').read_text())['path_gone']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='d4cddb5d1429098942362dcc50ebf79e51981799'
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','scripts','faaslora','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
gate=p.preflight([ROOT],8*p.GIB);assert gate['preflight_pass'],gate['issues']
save('start1_failure.json',dict(classification='protocol_or_launcher_error',
    failed_phase='remote_health_management_import',error='ModuleNotFoundError: numpy',
    interpreter='/usr/bin/python3',inference_launched=False,remote_started=True,
    retained_helper_sha256=p.digest(raw/'check_remote_health.py'),
    repair='reuse D362 stdlib-only HTTP module import; do not install dependencies or restart remote'))
# Existing exact InvocationIDs must still identify the remotely owned services.
blocks={}
for block in (raw/'remote_start.log').read_text().split('\n\n'):
    values=dict(line.split('=',1) for line in block.splitlines() if '=' in line and line.split('=',1)[0] in ('Id','InvocationID'))
    if 'Id' in values:blocks[values['Id']]=values['InvocationID']
assert len(blocks)==3
for unit,invocation in blocks.items():
    actual=subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174',
        'systemctl','--user','show',unit,'-p','InvocationID','--value'],text=True).strip()
    assert actual==invocation
subprocess.run([sys.executable,str(raw/'check_remote_health_stdlib.py')],cwd=ROOT,check=True)
save('start2_gate.json',dict(passed=True,gate=gate,identity=identity,remote_reused_without_restart=blocks))
subprocess.run(['tmux','new-session','-d','-s','tc-d524-source','-c',str(ROOT),
    'bash scripts/ieee_tc/run_d298_capacity_source.sh d524'],check=True)
save('start_receipt.json',dict(launched=True,head=head,tmux='tc-d524-source',identity=identity,
    management_attempts=2,remote_restarted=False))
print(json.dumps(dict(launched=True,head=head,tmux='tc-d524-source')),flush=True)
