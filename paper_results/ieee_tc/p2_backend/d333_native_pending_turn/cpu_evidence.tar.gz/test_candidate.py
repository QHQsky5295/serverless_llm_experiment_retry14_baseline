"""Bounded CPU validation; existing unittest entry points, no GPU qualification."""
import json
import os
from pathlib import Path
import subprocess
import sys
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
label = sys.argv[1]
assert label in ('cpu1', 'cpu2', 'regression1')
unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])
def sample():
    return {k:(group/k).read_text().strip() for k in ['memory.peak','memory.events',
        'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events']}
before = sample()
assert before['memory.high'] == str(3*1024**3) and before['memory.max'] == str(4*1024**3)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(p.ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
modules = ['tests.test_ieee_tc_pending_gpu_pipeline','tests.test_ieee_tc_pending_admission',
    'tests.test_ieee_tc_scheduler_observation','tests.test_ieee_tc_native_retirement']
if label == 'regression1':
    modules += ['tests.test_ieee_tc_request_lifecycle','tests.test_ieee_tc_service_events',
        'tests.test_ieee_tc_admission','tests.test_ieee_tc_gpu_references']
command = ['/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python','-m','unittest',*modules,'-v']
with (raw/(label+'.log')).open('x') as log:
    done = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
seal = p.verify_seal(p.ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
with (raw/(label+'.json')).open('x') as output:
    json.dump(dict(identity=identity,before=before,after=sample(),command=command,
        returncode=done.returncode,protected=seal),output,indent=2)
print(json.dumps(dict(returncode=done.returncode,receipt=str(raw/(label+'.json')))))
sys.exit(done.returncode)
