"""D364 post-release FAILURE audit, reusing D309/D313 evidence checks.

Not executable during measurement: requires native release, collection closure,
the unchanged startup resource gate and the complete 4000-request journal.
Uses the existing analyzers and tests; no new performance or metric framework.
The never-executed success-only draft was revised after req_03511 failed.
No all-success audit or performance comparison is run for this population.
"""
import gc
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
run = raw/'7b_full_w0'
physical = run/'launch.launch/physical_deployment'
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])


def read(path):
    return json.loads(path.read_text())


def sample():
    return {key: (group/key).read_text().strip() for key in (
        'memory.peak', 'memory.events', 'memory.swap.current',
        'memory.high', 'memory.max', 'memory.swap.max', 'cgroup.events')}


before = sample()
assert before['memory.high'] == str(3*p.GIB) and before['memory.max'] == str(4*p.GIB)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(
    ['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 4*p.GIB)
assert gate['preflight_pass'], gate['issues']
starter=read(raw/'launch_gate.json')['identity']
starter_group=Path(starter['path'])
assert p.scope_still_owned(starter) and not p.owned_pids(starter_group)
starter_resources={key:(starter_group/key).read_text() for key in
    ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
starter_cleanup=p.stop_scope_identity(starter)
assert starter_cleanup['released'] and not starter_cleanup['hard_kill'] and not starter_group.exists()
with (raw/'starter_scope_cleanup.json').open('x') as handle:
    json.dump(dict(identity=starter,resources=starter_resources,cleanup=starter_cleanup),handle,indent=2)
collected = read(raw/'collection_receipt.json')
closed = collected['identity']
assert closed['unit'].startswith('primelora-tc-aux-') and closed['unit'] != identity['unit']
cg = Path(closed['path'])
assert not p.owned_pids(cg) and p.scope_still_owned(closed)
resources = {key: (cg/key).read_text() for key in (
    'memory.peak', 'memory.events', 'memory.swap.current', 'cgroup.events')}
cleanup = p.stop_scope_identity(closed)
assert cleanup['released'] and not cleanup['hard_kill'] and not cg.exists()
with (raw/'collection_scope_cleanup.json').open('x') as handle:
    json.dump(dict(identity=closed, resources=resources, inactive=True,
                   cleanup=cleanup), handle, indent=2)

launch = read(run/'launch.json')
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert launch['service_returncode'] == launch['watchdog_returncode'] == launch['replay_returncode'] == 0
summary = read(physical/'summary.json')
terminals = [json.loads(line) for line in (physical/'request_terminals.jsonl').read_text().splitlines()]
assert summary['n_plan'] == summary['n_terminal'] == len(terminals) == 4000
assert summary['n_native_contract_complete'] == 3999
assert len({row['request_id'] for row in terminals}) == 4000
assert sum(row['success'] for row in terminals) == 3999
assert sum(row['native_contract_matched'] for row in terminals) == 3999
assert [row['request_id'] for row in terminals if not row['success']] == ['req_03511']
assert summary['measurement_complete'] and not summary['open_lease_ids'] and summary['n_correct'] is None
source = run/('experiment_results_full_vllm_dedicated_a500_r4000_c2'
              '_tc_ieee_full_d364_7b_full_w0.json')
assert source.resolve() == Path(collected['source_path']).resolve()
assert source.stat().st_size == collected['source_bytes']
assert p.digest(source) == collected['source_sha256']
assert collected['source_sha256'] == 'b90a4f6874d0f5f8a9c0a1ad8ddf749430e11c46b32c35c9eaa71c3edb6762aa'
remote = read(raw/'remote_stop.json')
assert remote['all_owned_units_inactive'] and remote['download_hashes_match_remote']
from scripts.ieee_tc.check_d299_full_context import failed_run_partition
data = read(source)
rows, successful, failures = failed_run_partition(data)
assert len(rows) == 4000 and len(successful) == 3999 and len(failures) == 1
failure = dict(failures[0])
assert failure['request_id'] == 'req_03511'
assert failure['error'] == 'ValueError: file demand source content is not confirmed'
del rows, successful, failures, data
gc.collect()
evidence = [source, run/'launch.json', physical/'summary.json', physical/'request_terminals.jsonl']
evidence += [raw/name for name in (
    'remote_transfers.jsonl', 'remote_monitor.log', 'remote_stop.json',
    'local_cleanup.json', 'collection_receipt.json')]
receipt = dict(kind='d364_full4000_failure_closure_v1',
    source_commit='ed98ac3aaf388983f8baa8ec17cc13461909a54e',
    n_plan=4000, n_terminal=4000, n_native_contract_complete=3999,
    n_failed_from_terminal_journal=1, planned=4000, terminal=4000,
    successful_returns=3999, failed=1, failure=failure, root_cause_confirmed=False,
    source_sha256=collected['source_sha256'], launch_sha256=p.digest(run/'launch.json'),
    remote_transfers_sha256=p.digest(raw/'remote_transfers.jsonl'),
    remote_monitor_sha256=p.digest(raw/'remote_monitor.log'), remote_stop=remote,
    n_correct=None, formal_qualification=False, ranking_eligible=False, no_figures=True,
    physical_gpu_seconds_total=summary['gpu_seconds'], launch_pass=True,
    native_gpu_context_release_confirmed=True, service_path_removed=True,
    remote_cleanup=remote,
    evidence={path.name: dict(path=str(path), sha256=p.digest(path)) for path in evidence},
    caveat='All offered requests reached terminal state, one failed. No all-correct, arithmetic, ranking or formal G1/G2 qualification.')
with (raw/'completion_receipt.json').open('x') as handle:
    json.dump(receipt, handle, indent=2, allow_nan=False)

python = '/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python'
commands = [
    [python, '-m', 'unittest', 'tests.test_ieee_tc_timing_bound',
     'tests.test_ieee_tc_launch.MainOutcomeRetention', 'tests.test_ieee_tc_decode_overlap',
     'tests.test_ieee_tc_hit_host_analysis', 'tests.test_ieee_tc_full_control_analysis', '-q'],
    [python, '-m', 'scripts.ieee_tc.check_d299_full_context', '--campaign', 'd364-failure'],
]
returncodes = []
try:
    with (raw/'audit1.log').open('x') as log:
        for command in commands:
            print(json.dumps(dict(command=command)), file=log, flush=True)
            completed = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            returncodes.append(completed.returncode)
            completed.check_returncode()
finally:
    with (raw/'offline_execution_receipt.json').open('x') as handle:
        json.dump(dict(identity=identity, before=before, after=sample(), commands=commands,
            preflight=gate, returncodes=returncodes,
            pass_all=len(returncodes) == len(commands) and not any(returncodes)), handle, indent=2)
print(json.dumps(dict(returncodes=returncodes, receipt=str(raw/'offline_execution_receipt.json'))))
