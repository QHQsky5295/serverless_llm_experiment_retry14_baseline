"""Post-D364 recovery: reuse the closed-log lossless D339 procedure.

Only three already-audited historical main-outcome logs are compressed.
D364 failure evidence, all weights/traces and submitted results stay untouched.
"""
import ast
import hashlib
import json
from pathlib import Path

raw = Path(__file__).resolve().parent.parent
release = json.loads((raw/'7b_full_w0/launch.json').read_text())
assert release['native_gpu_context_release_confirmed'] and release['service_path_removed']
SOURCE = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d339_20261008/compress_historical.py')
tree = ast.parse(SOURCE.read_text(), filename=str(SOURCE))
targets = [
    ('d349_20261008/7b_full_w0',
     '88ef3a6e5f809f15081233aa07e7649df95fcc8be0eefad04513e5bdde2ed859',
     'd349_full_w0/validated1/manifest.json'),
    ('d353_20261008/7b_full_w0',
     '55d90e00f076f69b9059868a85e6b9386c13e2240419821ddbd63a7b73cc851c',
     'd353_full_w0/validated1/manifest.json'),
    ('d358_20261008/7b_full_w0',
     '988bddcb5acfa52c8d7f5c17dab7f7afa9fe15aba98ad14b265f7a96105c2439',
     'd358_full_w0/validated1/manifest.json'),
]
changed = 0
for node in tree.body:
    if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == 'TARGETS'
            for target in node.targets):
        node.value = ast.parse(repr(targets), mode='eval').body
        changed += 1
assert changed == 1
ast.fix_missing_locations(tree)
print('Reuse D339 compression procedure SHA256',
      hashlib.sha256(SOURCE.read_bytes()).hexdigest(), flush=True)
exec(compile(tree, str(SOURCE), 'exec'), {'__name__': '__main__', '__file__': __file__})
