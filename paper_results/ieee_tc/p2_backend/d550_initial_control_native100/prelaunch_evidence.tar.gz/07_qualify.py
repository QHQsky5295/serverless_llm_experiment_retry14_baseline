"""D550: reuse D531 inputs and D549 regression; qualify only the new binding."""
import ast
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
RESULTS = RAW.parent.parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'qualification2_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate = p.preflight([ROOT], p.GIB)
assert gate['preflight_pass'], gate['issues']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
protected = p.verify_seal(RESULTS/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
binding_path = ROOT/'paper_results/ieee_tc/main_comparison/d531_w1_input/qualification.json'
binding = json.loads(binding_path.read_text())
assert binding['passed'] and binding['tests'] == 103
for path, sha in binding['preserved'].items():
    assert p.digest(Path(path)) == sha, path
# Only unchanged PrimeLoRA input/profile contracts are reused from D531; newer
# unrelated baseline adapters are not falsely claimed to have the old source SHA.
for relative in ('faaslora/datasets/workload_generator.py',
                 'tests/test_ieee_tc_external_replay.py',
                 'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
                 'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'):
    path = ROOT/relative
    assert p.digest(path) == binding['refs'][str(path)], relative
reg_path = RESULTS/'p2_backend_qualification/d549_20261015/regression_receipt.json'
reg = json.loads(reg_path.read_text())
assert reg['passed'] and reg['returncode'] == 0
for path, sha in reg['sources'].items(): assert p.digest(Path(path)) == sha, path
for phase in ('qualification2','regression','backup'):
    closed = json.loads((reg_path.parent/(phase+'_closure.json')).read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
paths = [ROOT/'configs/ieee_tc/20261015_d533_7b_full_w1.yaml',
         ROOT/'configs/ieee_tc/20261015_d550_7b_initial_control_validation_100.yaml']
configs = [yaml.safe_load(path.read_text()) for path in paths]
normalized = copy.deepcopy(configs)
for row in normalized:
    row['experiment'].pop('output_dir')
    row['storage'].pop('nvme_cache_dir'); row['storage'].pop('host_cache_dir')
assert normalized[1]['resource_coordination'].pop('ieee_initial_control_policy') == 'observed_arrivals_v1'
assert normalized[0] == normalized[1]
assert 'ieee_initial_control_policy' not in normalized[0]['resource_coordination']
from scripts.run_all_experiments import ScenarioRunner, _prepare_scenario_runtime_model_config, _normalize_runtime_concurrency_cap
full = configs[1]
scenario = next(row for row in full['scenarios'] if row['name']=='tc_ieee_full')
coord = dict(full['resource_coordination'], **scenario.get('resource_coordination',{}))
runner = ScenarioRunner.__new__(ScenarioRunner)
runner.model_cfg = _prepare_scenario_runtime_model_config(_normalize_runtime_concurrency_cap(full['model']), full['workload'], coord)
runner.coord_cfg = coord
runner._initial_runtime_pending = True
runner._service_profiles = runner._load_ieee_service_profiles()
runner._load_ieee_preparation_profiles()
shell = ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
body = shell.read_text()
old = subprocess.check_output(['git','show','5833564cd0bca0cebe60256122eeacd0a27740ba:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
start = body.index('  d550)\n')
end = body.index('    ;;\n', start)+len('    ;;\n')
branch = body[start:end]
assert paths[1].name in branch and 'PREFIX_COUNT=100\n' in branch
assert 'SCENARIO=tc_ieee_full\n' in branch
restored = (body[:start]+body[end:]).replace('== d533 || "${1:-d293}" == d550', '== d533')
assert restored == old, 'unexpected existing launcher change'
source_path = next(line.split('=',1)[1] for line in body.splitlines() if line.startswith('export FAASLORA_SHARED_TRACE_PATH='))
plan = FrozenReplayPlan.load(source_path, count=100, profile='W1')
complete = FrozenReplayPlan.load(source_path, profile='W1')
assert complete.identity() == binding['prime_plan']
assert plan.entries == complete.entries[:100] and plan.source_count == 4000
assert FrozenReplayPlan.from_launch_context(dict(plan=plan.identity(),tiny_witness=False,replay_scope='diagnostic_prefix_v1',diagnostic_prefix_count=100)) == plan
compiler_path = ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain/qualification.json'
compiler = json.loads(compiler_path.read_text())
assert compiler['passed'] and compiler['test_count'] == 16
build_path = ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build = json.loads(build_path.read_text())
assert build['passed'] and build['actual_closure']['passed'] and build['actual_closure']['path_gone']
for path,row in build['entrypoints']['build']['files'].items(): assert p.digest(Path(path)) == row['sha256'], path
toolchain = ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json'
assert p.digest(toolchain) == '328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c'
for path in sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),shell]):
    if path.suffix == '.py': ast.parse(path.read_text(), filename=str(path))
    else: subprocess.run(['bash','-n',str(path)],check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
import torch
assert not torch.cuda.is_initialized()
refs = [Path(__file__),shell,*paths,binding_path,reg_path,compiler_path,build_path,toolchain,
        ROOT/'scripts/run_all_experiments.py',ROOT/'faaslora/coordination/autoscaler.py',
        ROOT/'faaslora/datasets/workload_generator.py',
        ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
refs += [Path(row['path']) for row in (coord['ieee_service_profile'],coord['ieee_preparation_profile'])]
record = dict(passed=True,scope=identity,gate=gate,protected=protected,
    preserved=binding['preserved'],prime_plan=plan.identity(),source_count=4000,prefix_count=100,
    exact_profiles_loaded=True,only_policy_and_identity_paths_changed=True,
    unchanged_launcher_except_new_case_and_common_toolchain_selection=True,
    reused_cpu_regression_tests=363,reused_input_tests=103,reused_compiler_tests=16,
    no_new_performance_or_repeated_tests=True,ranking_eligible=False,
    early_native_mechanism_triggered=None,refs={str(path):p.digest(path) for path in refs})
save(RAW/'qualification.json',record)
print(json.dumps({k:record[k] for k in ('passed','source_count','prefix_count','prime_plan','exact_profiles_loaded')},indent=2))
