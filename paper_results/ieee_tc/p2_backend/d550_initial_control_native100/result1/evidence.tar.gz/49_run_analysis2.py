"""Population-only analyzer adaptation; never recollect or rerun the native run."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
with (RAW/'analysis2_identity.json').open('x') as f:json.dump(identity,f,indent=2)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert json.loads((RAW/'analysis_closure.json').read_text())['path_gone']
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
commands=[('analysis_population_tests.log',[sys.executable,'-B','-m','unittest','tests.test_tc_serverless_qualification_population','-v']),
          ('analysis2.log',[sys.executable,'-B',str(RAW/'analyze.py')])]
results=[]
try:
    for name,command in commands:
        with (RAW/name).open('x') as log:
            result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        results.append(dict(command=command,log=name,returncode=result.returncode))
        result.check_returncode()
finally:
    sources=[ROOT/'scripts/ieee_tc/check_d299_full_context.py',ROOT/'tests/test_tc_serverless_qualification_population.py',RAW/'analyze_prefix.py',RAW/'analyze.py',Path(__file__)]
    record=dict(passed=len(results)==len(commands) and all(r['returncode']==0 for r in results),
        identity=identity,commands=results,sources={str(path):p.digest(path) for path in sources},
        resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')})
    with (RAW/'analysis2_receipt.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record),flush=True)
