"""Reuse D147 source/test/cleanup/protected/bundle checks for D149."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d149_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
parent = '09989a0e7592491e66369c027d971fb5fed4ad45'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
changed = {'scripts/run_all_experiments.py','tests/test_ieee_tc_request_lifecycle.py'}
sources = json.loads((root/'results/ieee_tc/p2_backend_qualification/d148_20261001/prelaunch_verification.json').read_text())['source_sha256']
for name,sha in sources.items():
    path = (root/name).resolve()
    if path in {root/p for p in changed}:
        actual = hashlib.sha256(subprocess.check_output(['git','show',f'{parent}:{path.relative_to(root)}'])).hexdigest()
    else:
        actual = digest(path)
    assert actual == sha, name

# Preserve/reconstruct exact original RED test bytes; correcting its exception
# expectation did not change the production exception contract.
test_path = root/'tests/test_ieee_tc_request_lifecycle.py'
red_test = test_path.read_text().replace(
    "return {**getattr(owner, operation)(**kwargs), 'clock_id': local_monotonic_clock_id(),\n                'device_uuid': 'GPU-fixture'}",
    "return {**getattr(owner, operation)(**kwargs), 'clock_id': local_monotonic_clock_id()}")
red_test = red_test.replace(
    "        with self.assertRaisesRegex(ValueError, 'exclusive capacity'):\n            asyncio.run(runner._exec_request(trace, 4, 0., request_plan=plan))",
    "        result = asyncio.run(runner._exec_request(trace, 4, 0., request_plan=plan))\n        self.assertFalse(result.success)\n        self.assertIn('exclusive capacity', result.error)")
phases = ('red','green','regression')
cleanup = {}
for phase in phases:
    unit = f'primelora-d149-{phase}-20261001.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    events = {r.split()[0]:int(r.split()[1]) for r in (raw/f'{phase}_cleanup.txt').read_text().splitlines()
        if r.startswith(('low ','high ','max ','oom ','oom_kill ','oom_group_kill '))}
    assert len(events) == 6 and not any(events.values()), phase
    assert re.search(r'InvocationID=[a-f0-9]{32}',(raw/f'{phase}_scope.txt').read_text())
    assert f'Exit status: {1 if phase == "red" else 0}' in (raw/f'{phase}_time.txt').read_text()
    for line in (raw/f'{phase}_sources.sha256').read_text().splitlines():
        sha,name = line.split(maxsplit=1)
        if phase == 'red':
            payload = red_test.encode() if name.endswith('test_ieee_tc_request_lifecycle.py') else subprocess.check_output(['git','show',f'{parent}:{name}'])
            actual = hashlib.sha256(payload).hexdigest()
        else:
            actual = digest(root/name)
        assert actual == sha, (phase,name)
    cleanup[phase] = events
assert 'FAILED (failures=3, errors=1)' in (raw/'red.log').read_text()
for phase,n in (('green',2),('regression',700)):
    assert re.search(rf'Ran {n} tests in [\d.]+s\n\nOK\n',(raw/f'{phase}.log').read_text())
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
files = [root/name for name in sorted(changed)]
files += [root/'docs/ieee_tc/D149_SELECTED_SOURCE_PROJECTION.md']
files += [raw/name for name in ('run_tests.sh','cleanup_test.sh','verify_projection.py','red_test_changes.patch')]
for phase in phases:
    files += [raw/f'{phase}{suffix}' for suffix in ('.log','_time.txt','_scope.txt','_cleanup.txt','_sources.sha256')]
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for path in files:
    assert path.stat().st_size < 4*1024**2, path
    payload = path.read_bytes()
    assert secret not in payload, path
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in payload.splitlines()), path
    if path.suffix == '.py': compile(payload,str(path),'exec')
    if path.suffix == '.sh': subprocess.run(['bash','-n',str(path)],check=True)
result = dict(kind='d149_selected_source_projection_qualification_v1',parent_commit=parent,
    decision='qualified_for_ordinary_full_not_performance_acceptance',targeted_tests=2,regression_tests=700,
    regression_seconds=25.238,regression_command_seconds=36.70,regression_peak_rss_kib=1210360,
    cuda_executed=False,formal_performance_result=False,performance_gain_established=False,
    retry_or_timeout_changed=False,equations_changed=False,ownership_guards_changed=False,
    budgets_changed=False,reading_cache_added=False,complete_inventory_validation_preserved=True,
    red_test_expectation_correction='invalid graph already raises ValueError, not a returned result',
    previous_component_probe_reused_not_repeated='D132: exact full-source state equality across validated projection',
    protected=protected,prelaunch_sources_verified=len(sources),cleanup_events=cleanup,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
curated = out/'20261001_d149_selected_source_projection.json'
with curated.open('x') as stream: json.dump(result,stream,indent=2,allow_nan=False)
files.append(curated)
bundle = out/'20261001_d149_selected_source_projection_sources.tar.gz'
with bundle.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for path in files: archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(files)
    for member,path in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == digest(path)
with (out/'20261001_d149_selected_source_projection_sources.sha256').open('x') as stream:
    stream.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,regression_tests=700)))
