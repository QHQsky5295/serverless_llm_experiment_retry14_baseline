#!/usr/bin/env bash
# Reuses D147's bounded test runner; only candidate/test identities differ.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in red|green|regression|verify) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d149_20261001
unit="primelora-d149-${phase}-20261001.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sha256sum scripts/run_all_experiments.py tests/test_ieee_tc_request_lifecycle.py > "$raw/${phase}_sources.sha256"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
if test "$phase" = regression; then
  args=(-m unittest tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_service_routing tests.test_ieee_tc_service_events tests.test_ieee_tc_native_retirement tests.test_ieee_tc_gpu_references tests.test_basic_smoke -v)
elif test "$phase" = verify; then
  args=("$raw/verify_projection.py")
else
  args=(-m unittest
    tests.test_ieee_tc_request_lifecycle.SelectedSourceAdmissionIntegration.test_source_selection_and_acquisition_use_fresh_validated_projection
    tests.test_ieee_tc_request_lifecycle.SelectedSourceAdmissionIntegration.test_projected_acquisition_revalidates_graph_after_host_reference -v)
fi
exec /usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
