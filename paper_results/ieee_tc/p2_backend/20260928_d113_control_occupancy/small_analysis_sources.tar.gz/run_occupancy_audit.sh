#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d113_20260928
source=results/ieee_tc/p2_backend_qualification/d112_20260928
unit=primelora-d113-occupancy2-20260928.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/scope_before2.txt"
export PYTHONUNBUFFERED=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
"$python" -m unittest tests.test_ieee_tc_control_timeline -v
/usr/bin/time -v "$python" scripts/analyze_control_path_overhead.py \
  --native-timeline --input "$source/full_full9_request_projection.json" \
  --deployment "$source/3b_full_w0_full9/launch.launch/physical_deployment/deployment.json" \
  --terminals "$source/3b_full_w0_full9/launch.launch/physical_deployment/request_terminals.jsonl" \
  --watchdog "$source/3b_full_w0_full9/launch.launch/watchdog.jsonl" \
  --output paper_results/ieee_tc/p2_backend/20260928_d113_control_occupancy
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
