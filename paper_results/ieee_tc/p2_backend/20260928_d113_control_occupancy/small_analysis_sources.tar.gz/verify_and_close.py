"""D113 scoped evidence/protection verification and empty-scope retirement."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d113_20260928'
out = root/'paper_results/ieee_tc/p2_backend/20260928_d113_control_occupancy'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
states = []
for suffix, expected in (('', '5eaf5c35063c492aa3fde5f570d71ac2'),('2','5fcd666425dc4606ab7275ae6512c884')):
    unit = f'primelora-d113-occupancy{suffix}-20260928.scope'
    text = subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','-p','ControlGroup','-p','TasksCurrent'],text=True)
    fields = dict(line.split('=',1) for line in text.splitlines())
    assert fields['InvocationID'] == expected and fields['TasksCurrent'] == '0'
    assert fields['ControlGroup'] == '/user.slice/user-1001.slice/user@1001.service/app.slice/'+unit
    cg = Path('/sys/fs/cgroup'+fields['ControlGroup'])
    assert not (cg/'cgroup.procs').read_text().strip()
    assert 'populated 0' in (cg/'cgroup.events').read_text().splitlines()
    events = dict(line.split() for line in (cg/'memory.events').read_text().splitlines())
    assert all(events[k] == '0' for k in ('high','max','oom','oom_kill'))
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    states.append(dict(unit=unit,identity=fields,events=events,closed=True))

before = json.loads((root/'results/ieee_tc/p2_backend_qualification/d112_20260928/prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    path = Path(name) if name.startswith('/') else root/name
    assert digest(path) == expected, name
summary = json.loads((out/'summary.json').read_text())
for ref in summary['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256'], ref['path']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert summary['count'] == 4000 and summary['formal_performance_result'] is False
assert summary['phase_summaries']['gate_to_terminal']['max_concurrent_requests'] == 32
refs = [out/p for p in ('summary.json','request_occupancy.csv','sampled_occupancy.csv')]
refs += [root/'scripts/analyze_control_path_overhead.py',root/'tests/test_ieee_tc_control_timeline.py',
         root/'docs/ieee_tc/D113_CONTROL_OCCUPANCY.md']
bundle_files = [raw/p for p in ('audit.log','audit2.log','scope_before.txt','scope_before2.txt','run_occupancy_audit.sh','verify_and_close.py')]
bundle = out/'small_analysis_sources.tar.gz'
assert not bundle.exists()
with tarfile.open(bundle,'x:gz') as archive:
    for path in bundle_files:
        archive.add(path,arcname=path.name)
with tarfile.open(bundle,'r:gz') as archive:
    for path in bundle_files:
        assert hashlib.sha256(archive.extractfile(path.name).read()).hexdigest() == digest(path)
refs += [bundle]
receipt = dict(kind='d113_offline_evidence_verification_v1',formal_performance_result=False,
    production_source_commit=before['runtime_source_commit'],production_sources_checked=len(before['source_sha256']),
    protected=protected,closed_scopes=states,source_refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
with (out/'verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(pass_checks=True,production_sources=receipt['production_sources_checked'],protected=147,
                     summary_sha256=digest(out/'summary.json'),verification_sha256=digest(out/'verification.json'))))
