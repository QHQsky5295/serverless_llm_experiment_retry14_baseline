#!/usr/bin/env bash
set -euo pipefail
date -Is
unit=primelora-d126-verify-20260930.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 6750e92e139342688d71f98f9178a66e
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d126-verify-20260930.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
