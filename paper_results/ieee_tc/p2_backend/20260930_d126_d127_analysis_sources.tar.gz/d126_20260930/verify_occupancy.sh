#!/usr/bin/env bash
# Existing guarded CPU evidence closure; no GPU or dataset generation.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d126_20260930
unit=primelora-d126-verify-20260930.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/verify_scope.txt"
export PYTHONUNBUFFERED=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
"$python" -m unittest tests.test_basic_smoke -v
"$python" - <<'PY'
import csv, json, math
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root=Path.cwd()
raw=root/'results/ieee_tc/p2_backend_qualification/d126_20260930'
out=root/'paper_results/ieee_tc/p2_backend/20260930_d126_control_occupancy'
summary=out/'summary.json'
assert digest(summary)=='e366042d59a8f55be335792641aac636e568bbed9a4f2300467c441cf320f21f'
x=json.loads(summary.read_text())
assert not x['formal_performance_result']
assert x['population']==dict(planned=4000,terminal=4000,native_success=3456,failed=544)
assert x['phase_population']=='native_success_only' and len(x['failures'])==544
for ref in x['source_refs']:
    assert digest(Path(ref['path']))==ref['sha256'],ref['path']
phases=x['phase_summaries']
assert all(v['n']==3456 for v in phases.values())
summed=math.fsum(phases[k]['total_request_seconds'] for k in (
    'gate_to_source_admission','source_to_native_dispatch','native_dispatch_to_last_token',
    'last_token_to_controller_completion','controller_completion_to_terminal'))
assert math.isclose(summed,phases['gate_to_terminal']['total_request_seconds'],abs_tol=1e-6)
with (out/'request_occupancy.csv').open() as f:
    rows=list(csv.DictReader(f))
assert len(rows)==4000 and len({r['request_id'] for r in rows})==4000
receipt=(raw/'cleanup_occupancy1.log').read_text()
assert 'ActiveState=inactive' in receipt
events={line.split()[0]:int(line.split()[1]) for line in receipt.splitlines()
        if len(line.split())==2 and line.split()[0] in ('low','high','max','oom','oom_kill','oom_group_kill')}
assert len(events)==6 and not any(events.values())
assert 'Exit status: 0' in (raw/'audit_time1.txt').read_text()
seal=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert seal['pass'] and seal['entry_count']==147
metric=root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
plan=Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')
assert digest(metric)=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert digest(plan)=='fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
refs=[p for p in out.iterdir() if p.is_file()]+[raw/'run_occupancy_audit1.sh',
    raw/'verify_occupancy.sh',raw/'cleanup_occupancy1.sh',raw/'cleanup_occupancy1.log',
    raw/'scope_before1.txt',raw/'audit_time1.txt',root/'docs/ieee_tc/D126_CONTROL_OCCUPANCY.md']
result=dict(kind='d126_occupancy_verification_v1',pass_checks=True,
    formal_performance_result=False,source_refs_rehashed=len(x['source_refs']),protected=seal,
    metric_protocol_sha256=digest(metric),plan_sha256=digest(plan),
    phase_sums_pass=True,all_offered_ids_retained=True,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
with (out/'verification.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(pass_checks=True,sources=len(x['source_refs']),protected=147)))
PY
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
