"""Reuse D124 bounded saved-state probe, target ONLY RPC JSON decoding.

No production edits, new input pool, GPU, network service, or online policy.
The real saved components are not a current 500-adapter Full workload.
"""
import asyncio
import collections
import hashlib
import importlib.metadata
import json
import statistics
from pathlib import Path
import time
import msgspec

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw=Path(__file__).resolve().parent
out=raw/'rpc_decode_probe.json'
assert not out.exists()
refs=[]
def sha(data):return hashlib.sha256(data).hexdigest()
def load(path,limit,expected=None):
    assert path.stat().st_size < limit
    data=path.read_bytes()
    digest=sha(data)
    if expected:assert digest==expected,str(path)
    refs.append(dict(path=str(path),sha256=digest,bytes=len(data)))
    return json.loads(data)

previous=load(ROOT/'paper_results/ieee_tc/p2_backend/20260930_d123_7b_full_w0_prefix1.json',200_000)
profile_path=ROOT/'results/ieee_tc/p2_backend_qualification/d123_20260930/controller_prefix1.speedscope.json'
expected=next(ref['sha256'] for ref in previous['source_refs'] if ref['path']==str(profile_path))
profile=load(profile_path,32_000_000,expected)
frames=profile['shared']['frames']
counts=collections.Counter()
targeted_total=0
for thread in profile['profiles']:
    for stack in thread['samples']:
        local=[frames[i] for i in stack if frames[i].get('file','').startswith(str(ROOT)+'/')]
        if not local or any(f['name']=='save_results' for f in local):continue
        parent=local[-1]
        if parent['name']!='_send_rpc_on_channel':continue
        targeted_total+=1
        leaf=frames[stack[-1]]
        counts[(parent.get('line'),leaf['name'],leaf.get('file',''),leaf.get('line'))]+=1
assert targeted_total==37606
del profile,frames

prior=load(ROOT/'paper_results/ieee_tc/p2_backend/20260930_d121_preparation_copy/summary.json',100_000)
cases=[]
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',', ':'),allow_nan=False).encode()
async def paired(model,view):
    # Existing JSON wire bytes remain byte-for-byte unchanged.
    payload=json.dumps(dict(ok=True,result=view),ensure_ascii=True).encode('utf-8')
    assert len(payload)<=8*1024**2
    original=json.loads(payload.decode('utf-8'))
    expected=sha(canonical(original))
    assert sha(canonical(msgspec.json.decode(payload)))==expected
    samples=[]
    for trial in range(3):
        methods=[('stdlib',lambda:json.loads(payload.decode('utf-8'))),
                 ('msgspec',lambda:msgspec.json.decode(payload))]
        if trial%2:methods.reverse()
        for order,(name,decode) in enumerate(methods):
            for repetition in range(10):
                ready=asyncio.get_running_loop().create_future()
                start=time.perf_counter_ns()
                asyncio.get_running_loop().call_soon(lambda:ready.set_result(time.perf_counter_ns()))
                value=decode()
                end=time.perf_counter_ns()
                callback=await ready
                assert sha(canonical(value))==expected
                samples.append(dict(trial=trial,order=order,repetition=repetition,method=name,
                    elapsed_ms=(end-start)/1e6,ready_callback_delay_ms=(callback-start)/1e6))
    return dict(model=model,wire_bytes=len(payload),wire_sha256=sha(payload),
        decoded_canonical_sha256=expected,registered_adapters=len(view['registered_cpu_adapter_ids']),
        host_allocations=len(view['native_footprints']['host_allocations']),samples=samples,
        mean_decode_ms={name:statistics.mean(r['elapsed_ms'] for r in samples if r['method']==name)
                        for name in ('stdlib','msgspec')})

for record in prior['models']:
    path=Path(record['source_path'])
    view=load(path,24_000_000,record['source_sha256'])
    for key in record['selected_path']:view=view[key]
    assert sha(canonical(view))==record['view_sha256']
    cases.append(asyncio.run(paired(record['model'],view)))

# The candidate must preserve valid JSON integers/doubles/Unicode, not text
# retokenization or lossy number conversion. Invalid JSON differences are logged.
numeric={"min":-(2**63),"max":2**64-1,"big":2**100,
         "t":270744.173485817,"tiny":5e-324,"negzero":-0.0,"unicode":"层级\n请求"}
payload=json.dumps(numeric,ensure_ascii=True).encode()
old=json.loads(payload.decode())
new=msgspec.json.decode(payload)
assert canonical(new)==canonical(old)
invalid=[]
for payload in (b'{"x":NaN}',b'{"x":Infinity}',b'{"x":-Infinity}',b'{',b'{"x":"\\ud800"}'):
    row=dict(wire=payload.decode('ascii'))
    for name,decode in [('stdlib',lambda:json.loads(payload.decode())),('msgspec',lambda:msgspec.json.decode(payload))]:
        try:decode()
        except Exception as exc:row[name]=type(exc).__name__
        else:row[name]='accepted'
    invalid.append(row)
result=dict(kind='d127_saved_rpc_decode_probe_v1',formal_performance_result=False,
    production_changed=False,production_candidate_accepted=False,
    msgspec_version=importlib.metadata.version('msgspec'),
    historical_targeted_samples=targeted_total,total_historical_gil_samples=279902,
    exact_stack_lines=[dict(parent_line=k[0],leaf=k[1],leaf_file=k[2],leaf_line=k[3],samples=v)
                       for k,v in counts.most_common()],cases=cases,
    valid_number_and_unicode_equality=True,invalid_json_behavior=invalid,
    source_refs=refs+[dict(path=str(Path(__file__)),sha256=sha(Path(__file__).read_bytes()))],
    caveats=['D123 profiling predates D124; fractions are not D125 wall-time shares.',
        'Saved native components have fewer registered adapters than current cache capacity.',
        'CPU repeats are not independent workload repeats; no seed-level CI or Full benefit.',
        'No wire encoding, source/epoch/physical validation, timeout or capacity changed.'])
with out.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(out),targeted_samples=targeted_total,
    exact_stack_lines=result['exact_stack_lines'][:8],
    cases=[{k:v for k,v in c.items() if k!='samples'} for c in cases],invalid_json_behavior=invalid),indent=2))
