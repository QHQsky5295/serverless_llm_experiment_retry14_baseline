"""Reuse D125 small evidence packaging and D124 component table workflow."""
import csv
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

root=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw=root/'results/ieee_tc/p2_backend_qualification/d127_20260930'
other=root/'results/ieee_tc/p2_backend_qualification/d126_20260930'
parent=root/'paper_results/ieee_tc/p2_backend'
out=parent/'20260930_d127_rpc_decode'
assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inactive(unit):
    return subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
for directory,filename,unit in [(other,'cleanup_verification.log','primelora-d126-verify-20260930.scope'),
        (raw,'cleanup_decode1.log','primelora-d127-decode-20260930.scope'),
        (raw,'cleanup_decode2.log','primelora-d127-decode2-20260930.scope')]:
    text=(directory/filename).read_text()
    assert 'ActiveState=inactive' in text and inactive(unit)
    keys={'low','high','max','oom','oom_kill','oom_group_kill'}
    events={r.split()[0]:int(r.split()[1]) for r in text.splitlines()
            if len(r.split())==2 and r.split()[0] in keys}
    assert set(events)==keys and not any(events.values())
probe=raw/'rpc_decode_probe2.json'
x=json.loads(probe.read_text())
assert not x['production_changed'] and not x['production_candidate_accepted']
assert len(x['cases'])==1 and x['cases'][0]['model']=='7b'
assert x['historical_targeted_samples']==37606 and x['valid_number_and_unicode_equality']
for ref in x['source_refs']:assert sha(Path(ref['path']))==ref['sha256'],ref['path']
assert 'Ran 288 tests' in (other/'verify.log').read_text() and '\nOK\n' in (other/'verify.log').read_text()
verification=json.loads((parent/'20260930_d126_control_occupancy/verification.json').read_text())
assert verification['pass_checks']
for ref in verification['source_refs']:assert sha(Path(ref['path']))==ref['sha256'],ref['path']
samples=x['cases'][0]['samples']
assert len(samples)==60
for method in ('stdlib','msgspec'):
    assert sum(row['method']==method for row in samples)==30
out.mkdir()
with (out/'samples.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(samples[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(samples)
with (out/'summary.json').open('x') as f:
    json.dump(dict(x,decision='component_only_not_selected_as_standalone_Full_optimizer',
        verification=dict(source_refs_checked=len(x['source_refs']),d126_refs_checked=len(verification['source_refs']),
            smoke_tests=288,smoke_s=22.535,production_changes=False),
        probe_sha256=sha(probe)),f,indent=2,allow_nan=False)

bundle=parent/'20260930_d126_d127_analysis_sources.tar.gz'
assert not bundle.exists()
members={}
with tarfile.open(bundle,'x:gz') as archive:
    for directory in (other,raw):
        for p in sorted(directory.iterdir()):
            if not p.is_file() or p.stat().st_size>=64*1024 or p.suffix not in {'.py','.sh','.json','.txt','.log'}:continue
            if p.name in {'finalize.log','finalize_time.txt'}:continue  # Current writer, not a completed receipt.
            name=directory.name+'/'+p.name
            data=p.read_bytes()
            assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
            members[name]=hashlib.sha256(data).hexdigest()
            archive.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames())==set(members)
    for name,expected in members.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected
with (parent/'20260930_d126_d127_analysis_sources.sha256').open('x') as f:f.write(sha(bundle)+'  '+bundle.name+'\n')
with (parent/'20260930_d126_d127_analysis_sources_members.json').open('x') as f:json.dump(dict(
    bundle=bundle.name,member_sha256=members,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,members=len(members),
    sha256=sha(bundle),output=str(out),cleanup=True)))
