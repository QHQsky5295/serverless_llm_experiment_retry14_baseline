#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d864_20261026/native
unit=primelora-tc-aux-$(cat /proc/sys/kernel/random/uuid | tr -d -).scope
exec systemd-run --user --scope --unit="$unit" -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 taskset -c 2,3,26,27 env CUDA_VISIBLE_DEVICES= PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -B "$RAW/launch.py" > "$RAW/start.txt" 2>&1
