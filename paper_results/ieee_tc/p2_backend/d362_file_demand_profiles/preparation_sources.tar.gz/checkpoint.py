"""Reuse the bounded D356 preparation seal; explicit D362 paths only."""
import ast,hashlib,json,os,re,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d362_file_demand_profiles'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0' and os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
test=json.loads((raw.parent/'d362_tests1.json').read_text());assert test['passed']
assert 'Ran 536 tests' in (raw.parent/'d362_tests1.log').read_text()
for name,sha in test['sources'].items():assert p.digest(ROOT/name)==sha
old=json.loads((raw/'preparation_scope.json').read_text())['identity']
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
resources={k:(Path(old['path'])/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
assert resources['memory.swap.current'].strip()=='0'
assert all(int(v)==0 for _,v in (line.split() for line in resources['memory.events'].splitlines()))
cleanup=p.stop_scope_identity(old);assert cleanup['released'] and not cleanup['hard_kill']
with (raw/'prepare_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,resources=resources,cleanup=cleanup),f,indent=2)
prepared=json.loads((out/'prepare.json').read_text())
for ref in prepared['source_refs']+[prepared['spec']]:
    path=Path(ref['path']);assert p.digest(path if path.is_absolute() else ROOT/path)==ref['sha256']
assert p.check_plan()==prepared['plan_sha256']=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')==prepared['metric_protocol_sha256']=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=[x for x in sorted(raw.iterdir()) if x.is_file()]
files.extend(raw.parent/x for x in ('d362_prepare.py','d362_tests1.log','d362_tests1.json'))
assert len({x.name for x in files})==len(files)
archive=out/'preparation_sources.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in files:
        data=path.read_bytes();check(data)
        if path.suffix=='.py':ast.parse(data)
        if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
        bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    assert len(bundle.getmembers())==len(files)
    for path in files:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count']==147 and protected['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
with (out/'checkpoint.json').open('x') as f:
    json.dump(dict(passed=True,tests=536,resources=resources,protected=protected,gpu_runs=0,
        archive_sha256=p.digest(archive),archive_members={x.name:p.digest(x) for x in files}),f,indent=2)
names=['scripts/ieee_tc_preflight.py','scripts/ieee_tc/prepare_d298_capacity.py',
    'scripts/ieee_tc/run_d298_capacity_source.sh','scripts/ieee_tc/export_d298_profiles.py',
    'tests/test_ieee_tc_preflight.py','tests/test_ieee_tc_control_profile_analysis.py',
    'configs/ieee_tc/20261009_d362_7b_file_demand_source.yaml',
    'docs/ieee_tc/D362_FILE_DEMAND_PROFILE_REFRESH.md','docs/ieee_tc/EXECUTION_STATUS.md']
names.extend(str(x.relative_to(ROOT)) for x in sorted(out.iterdir()) if x.is_file())
for name in names:check((ROOT/name).read_bytes())
with (out/'preparation.sha256').open('x') as f:
    for name in names:f.write(p.digest(ROOT/name)+'  '+name+'\n')
names.append(str((out/'preparation.sha256').relative_to(ROOT)))
subprocess.run(['sha256sum','-c',str(out/'preparation.sha256')],cwd=ROOT,check=True)
subprocess.run(['bash','-n','scripts/ieee_tc/run_d298_capacity_source.sh'],cwd=ROOT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (raw/'checkpoint_receipt.json').open('x') as f:json.dump(dict(passed=True,identity=identity,paths=names),f,indent=2)
print(json.dumps(dict(passed=True,tests=536,paths=len(names),archive_bytes=archive.stat().st_size)))
