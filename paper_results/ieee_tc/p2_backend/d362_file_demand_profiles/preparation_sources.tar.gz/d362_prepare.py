"""Bounded regression and preparation of one affected-profile calibration."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
parent=Path(__file__).resolve().parent
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],8*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
tests=['tests.test_ieee_tc_preflight.MeasuredAdmissionInitializer',
    'tests.test_ieee_tc_preflight.CapacityProbeObservation',
    'tests.test_ieee_tc_core_interleave','tests.test_ieee_tc_scheduler_observation',
    'tests.test_ieee_tc_pending_gpu_pipeline','tests.test_ieee_tc_pending_admission',
    'tests.test_ieee_tc_core_timing','tests.test_ieee_tc_core_timing_analysis',
    'tests.test_ieee_tc_control_profile_analysis','tests.test_ieee_tc_gpu_references',
    'tests.test_ieee_tc_request_lifecycle','tests.test_ieee_tc_admission',
    'tests.test_ieee_tc_hit_host_transaction','tests.test_ieee_tc_native_retirement']
with (parent/'d362_tests1.log').open('x') as f:
    tested=subprocess.run([sys.executable,'-m','unittest',*tests,'-q'],cwd=ROOT,
        stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
record=dict(identity=identity,returncode=tested.returncode,passed=tested.returncode==0,
    gate=gate,
    sources={name:p.digest(ROOT/name) for name in ('scripts/ieee_tc_preflight.py',
        'scripts/ieee_tc/prepare_d298_capacity.py','scripts/ieee_tc/run_d298_capacity_source.sh',
        'tests/test_ieee_tc_preflight.py','faaslora/scheduling/core_interleave.py',
        'scripts/ieee_tc/export_d298_profiles.py','tests/test_ieee_tc_control_profile_analysis.py',
        'configs/ieee_tc/20261009_d362_7b_file_demand_source.yaml')},
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')})
with (parent/'d362_tests1.json').open('x') as f:json.dump(record,f,indent=2)
tested.check_returncode()
from scripts.ieee_tc.prepare_d298_capacity import prepare_control_profiles
prepare_control_profiles(file_demand=True)
raw=parent/'d362_20261009'
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['changed']==['/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py']
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
with (raw/'preparation_scope.json').open('x') as f:
    json.dump(dict(identity=identity,passed=True,protected=protected,
        resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(passed=True,preparation_scope=identity['unit'])))
