"""Post-release collection and existing source validators; no live measurement work."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

raw=Path(__file__).resolve().parent
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],4*p.GIB);assert gate['preflight_pass'],gate['issues']
launch=json.loads((raw/'source1_launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
stop=(raw/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive')==stop.count('MainPID=0')==3
assert subprocess.run(['tmux','has-session','-t','tc-d362-source'],stderr=subprocess.DEVNULL).returncode!=0
starter=json.loads((raw/'launch_gate.json').read_text())['identity']
assert p.scope_still_owned(starter) and not p.owned_pids(Path(starter['path']))
resources={k:(Path(starter['path'])/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
closed=p.stop_scope_identity(starter)
assert closed['released'] and not closed['hard_kill'] and not Path(starter['path']).exists()
with (raw/'starter_cleanup.json').open('x') as f:
    json.dump(dict(identity=starter,resources=resources,cleanup=closed),f,indent=2)
commands=[
    ('collection1.log',[sys.executable,str(raw/'collect_closure.py')]),
    ('analysis_tests1.log',[sys.executable,'-m','unittest',
        'tests.test_ieee_tc_control_profile_analysis',
        'tests.test_ieee_tc_core_interleave',
        'tests.test_ieee_tc_launch.SourceProfileDomainCoverage',
        'tests.test_ieee_tc_launch.HistoricalServiceRebin',
        'tests.test_ieee_tc_launch.MeasuredSourceProfileExport',
        'tests.test_ieee_tc_preflight.CapacityProbeObservation','-q']),
    ('analysis1.log',[sys.executable,str(raw/'analyze.py')]),
]
results=[]
try:
    for name,command in commands:
        with (raw/name).open('x') as f:
            completed=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,
                env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
        results.append(dict(log=name,command=command,returncode=completed.returncode))
        completed.check_returncode()
finally:
    record=dict(identity=identity,gate=gate,commands=results,
        passed=len(results)==len(commands) and all(r['returncode']==0 for r in results),
        resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')})
    with (raw/'offline_execution_receipt.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record),flush=True)
