"""Close only the already-empty, receipt-bound launch-preparation scope."""
import json,sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
identity=json.loads((raw/'start_receipt.json').read_text())['identity']
assert p.scope_still_owned(identity) and not p.owned_pids(Path(identity['path']))
resources={k:(Path(identity['path'])/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
closed=p.stop_scope_identity(identity);assert closed['released'] and not closed['hard_kill']
with (raw/'starter_cleanup.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,cleanup=closed),f,indent=2)
print(json.dumps(dict(released=True,unit=identity['unit'])))
