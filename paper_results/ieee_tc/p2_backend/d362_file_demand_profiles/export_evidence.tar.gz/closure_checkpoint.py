"""Seal D362 export, exact-scope cleanup and checked curated Git backup."""
import ast, hashlib, io, json, os, pathlib, re, subprocess, sys, tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d362_file_demand_profiles'
identity=p.scope_identity(p.cg_path().name);group=pathlib.Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],4*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
export=json.loads((raw/'export1_receipt.json').read_text());assert export['passed']
old=export['identity'];oldgroup=pathlib.Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(oldgroup)
resources={k:(oldgroup/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
closed=p.stop_scope_identity(old);assert closed['released'] and not closed['hard_kill']
with (raw/'export_cleanup.json').open('x') as f:json.dump(dict(identity=old,resources=resources,cleanup=closed),f,indent=2)
manifest=json.loads((out/'initialization/manifest.json').read_text())
assert manifest['passed'] and manifest['coverage']['class_domain_covered']
assert manifest['summary']['requests']==1669 and manifest['summary']['representative_requests']==1635
assert manifest['coverage']['measured_service_classes']==200
assert manifest['coverage']['measured_preparation_classes']==24
assert manifest['file_demand_transaction_audit']['file_transactions']==969
assert manifest['n_correct'] is None and not manifest['full_qualified']
for ref in manifest['bindings'].values():assert p.digest(pathlib.Path(ref['path']))==ref['sha256']
for line in (out/'measurement_outputs.sha256').read_text().splitlines():
    sha,name=line.split('  ',1);assert p.digest(out/name)==sha
assert p.check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count']==147 and protected['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members=[raw/n for n in ('export_profiles.py','export1.log','export1_receipt.json',
    'export_cleanup.json','measurement_seal_receipt.json','measurement_seal_cleanup.json','closure_checkpoint.py')]
archive=out/'export_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in members:
        check(path.read_bytes());bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
record=dict(passed=True,calibration_complete=True,full_performance_qualified=False,n_correct=None,
    source_execution_commit=manifest['source_execution_commit'],source_run=manifest['source_run'],
    measured_calls=1635,native_calls=1669,service_classes=200,preparation_classes=24,
    file_demand_transactions=969,advanced_owner_epoch_transactions=191,
    tests_after_release=50,protected=protected,export_resources=resources,
    export_evidence=dict(sha256=p.digest(archive),bytes=archive.stat().st_size),
    no_figures=True,next='D363 first100 then complete W0 against retained D358/D353/D336')
with (out/'completion.json').open('x') as f:json.dump(record,f,indent=2)
with (out/'completion.sha256').open('x') as f:
    for path in sorted(out.rglob('*')):
        if path.is_file() and path.name!='completion.sha256':
            f.write(p.digest(path)+'  '+str(path.relative_to(out))+'\n')
docs=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D362_FILE_DEMAND_PROFILE_REFRESH.md']
names=docs+[str(path.relative_to(ROOT)) for path in sorted(out.rglob('*')) if path.is_file()]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
archive_members=0
for name in names:
    data=(ROOT/name).read_bytes();check(data)
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as bundle:
            for member in bundle.getmembers():
                assert member.isfile() and not pathlib.Path(member.name).is_absolute() and '..' not in pathlib.Path(member.name).parts
                payload=bundle.extractfile(member).read();check(payload)
                if member.name.endswith('.py'):ast.parse(payload)
                archive_members+=1
subprocess.run(['sha256sum','-c','completion.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert staged and set(staged)<=set(names) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
with (raw/'closure_checkpoint_receipt.json').open('x') as f:
    json.dump(dict(passed=True,identity=identity,staged=staged,archive_members_checked=archive_members,
        resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(passed=True,staged=len(staged),archive_members_checked=archive_members)),flush=True)
