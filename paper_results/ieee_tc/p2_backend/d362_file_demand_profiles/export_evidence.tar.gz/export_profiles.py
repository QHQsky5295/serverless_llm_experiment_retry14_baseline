"""Use the existing strict exporter on the sealed D362 measurements."""
import json, os, pathlib, subprocess, sys
ROOT = pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
raw = pathlib.Path(__file__).resolve().parent
identity = p.scope_identity(p.cg_path().name)
group = pathlib.Path(identity['path'])
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 4*p.GIB)
assert gate['preflight_pass'], gate['issues']
old = json.loads((raw/'measurement_seal_receipt.json').read_text())['identity']
assert p.scope_still_owned(old) and not p.owned_pids(pathlib.Path(old['path']))
closed = p.stop_scope_identity(old)
assert closed['released'] and not closed['hard_kill']
with (raw/'measurement_seal_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,cleanup=closed),f,indent=2)
with (raw/'export1.log').open('x') as log:
    result = subprocess.run([sys.executable,'-m','scripts.ieee_tc.export_d298_profiles','d362'],
        cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
with (raw/'export1_receipt.json').open('x') as f:
    json.dump(dict(passed=result.returncode==0,returncode=result.returncode,identity=identity,gate=gate,
        resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}),f,indent=2)
result.check_returncode()
print(json.dumps(dict(passed=True,identity=identity)),flush=True)
