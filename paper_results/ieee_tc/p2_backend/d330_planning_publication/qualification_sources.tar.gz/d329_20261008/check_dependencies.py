"""Bounded CPU-only D329 witnesses; reuse the existing test fixtures and gates."""
import contextlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d329_host_dependencies'
assert not OUT.exists()
assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
group = p.cg_path()
identity = p.scope_identity(group.name)
assert group == Path(identity['path'])
assert set(os.sched_getaffinity(0)) == {2, 3, 26, 27}
for name, value in {'memory.high': 3*1024**3, 'memory.max': 4*1024**3,
                    'memory.swap.max': 0}.items():
    assert int((group/name).read_text()) == value
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'],text=True).strip()
files = [Path(__file__), ROOT/'tests/test_ieee_tc_host_observation_freshness.py',
    ROOT/'tests/test_ieee_tc_worker_observation.py', ROOT/'tests/test_ieee_tc_gpu_references.py',
    ROOT/'faaslora/memory/gpu_monitor.py', ROOT/'faaslora/memory/residency_manager.py',
    ROOT/'faaslora/experiment/instance_pool.py', ROOT/'faaslora/preloading/preloading_planner.py']
refs = [dict(path=str(path), sha256=p.digest(path)) for path in files]
def protected():
    seal = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
    known = Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
    assert seal['entry_count'] == 147 and seal['changed'] == [str(known)]
    assert p.digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
    for path, sha in [('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md', '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'),
        (str(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'), '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'),
        (str(ROOT/'configs/generated/lora_manifest_1000.json'), '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df')]:
        assert p.digest(Path(path)) == sha
    return seal
before = protected()
with (RAW/'tests.log').open('x') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
    start = time.monotonic()
    suite = unittest.defaultTestLoader.loadTestsFromNames([
        'tests.test_ieee_tc_host_observation_freshness',
        'tests.test_ieee_tc_worker_observation.NativeHostFootprint',
        'tests.test_ieee_tc_worker_observation.NativeHostRoutingProjection'])
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    elapsed = time.monotonic() - start
assert result.wasSuccessful()
import torch
assert not torch.cuda.is_initialized()
for ref in refs:
    assert p.digest(Path(ref['path'])) == ref['sha256']
after = protected()
resources = {name:(group/name).read_text().strip() for name in
    ['memory.peak','memory.events','memory.swap.current','memory.high','memory.max','memory.swap.max']}
payload = dict(kind='d329_host_observation_dependency_witnesses_v1',
    scope=identity, tests=result.testsRun, passed=result.wasSuccessful(),
    elapsed_including_import_s=elapsed, torch_version=torch.__version__,
    cuda_initialized=torch.cuda.is_initialized(), gpu_performance_result=False,
    source_refs=refs, test_log=dict(path=str(RAW/'tests.log'),sha256=p.digest(RAW/'tests.log')),
    protected_before=before, protected_after=after, resources_before_process_exit=resources,
    production_changes=False, formal_qualification=False, figures_generated=False,
    decision='reject_owner_epoch_or_model_identity_as_a_storage_immutability_witness',
    caveats=['CPU real-tensor fixture, not workload frequency or GPU performance',
        'pinning flip is a mocked backend observation, not real cudaHostRegister',
        'does not prove that a separately enforced storage-lifetime design is impossible'])
OUT.mkdir(parents=True)
with (OUT/'witnesses.json').open('x') as f:
    json.dump(payload,f,indent=2,allow_nan=False)
print(json.dumps(dict(tests=result.testsRun,passed=True,elapsed_s=elapsed,scope=identity,resources=resources)))
