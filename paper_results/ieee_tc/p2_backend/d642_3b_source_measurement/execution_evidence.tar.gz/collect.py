"""Reuse exact-owned source closure and check complete 3B measurements."""
import collections, json, math, os, statistics, subprocess, sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline');RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);save('analysis_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
launch=read(RAW/'source1_launch.json')
assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
subprocess.run([sys.executable,str(RAW/'remote_control.py'),'stop'],check=True)
source=RAW.parent/'d362_20261009/collect_closure.py'
code=source.read_text().replace('d362_20261009','d642_20261017').replace('d80_20260927/7b/transfers-','d80_20260927/3b/transfers-')
launcher=read(RAW/'launcher_identity.json');group=Path(launcher['path'])
assert p.scope_still_owned(launcher)
assert all(not path.read_text().split() for path in group.rglob('cgroup.procs'))
exec(compile(code,str(source),'exec'),dict(__file__=__file__,__name__='closure'))
assert not group.exists()
run=read(RAW/'source1.json')
assert run['pass'] and run['stage']=='complete' and run['shutdown_called'] and run['profile_workspaces_removed']
assert len(run['requests'])==368 and len(run['profile_waves'])==46
spec=ROOT/'paper_results/ieee_tc/p2_backend/d640_3b_migration/source_spec.json'
assert p.digest(spec)==run['source_profile_spec_sha256'] and read(spec)==run['source_profile_spec']
index=ROOT/run['source_profile_spec']['content_index']['path']
assert p.digest(index)==run['source_profile_spec']['content_index']['sha256']
from faaslora.storage.http_artifact_store import HttpArtifactStoreClient
from scripts.ieee_tc.export_d298_profiles import completed_gap_samples
content=read(index);client=HttpArtifactStoreClient(endpoint='http://127.0.0.1:1');client.configure_content_manifest(content)
pool=Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama32_3b_a500_v1_modelscope')
identities={r['id']:client.routing_identity(r['id'],(pool/r['id']/'adapter_config.json').read_bytes()) for r in content['artifacts']}
samples,coverage=completed_gap_samples(run,source_sha=p.digest(RAW/'source1.json'),identities=identities)
save('coverage.json',coverage)
assert len(samples)==360
transfers=[json.loads(line) for line in (RAW/'remote_transfers.jsonl').read_text().splitlines()]
remote={r['transfer_id']:r for r in transfers}
assert len(remote)==len(transfers)==len(run['remote_transfers'])
assert set(remote)=={r['http_transfer_id'] for r in run['remote_transfers']}
clock=read(RAW/'remote_health.json')['3b']['clock_id']
for r in run['remote_transfers']:
    s=remote[r['http_transfer_id']]
    assert s['clock_id']==clock and s['outcome']=='sent' and r['state']=='published'
    assert r['content_verified'] and r['published_archive_verified']
    assert r['artifact_id']==s['artifact_id'] and r['remote_archive_sha256']==s['archive_sha256']
    assert r['transferred_bytes']==s['archive_bytes']==s['bytes_read']==s['bytes_written']
    assert not r['remote_pack_performed'] and not s['pack_performed'] and not s['temporary_created']
life={e['event']:e['at'] for e in run['physical_allocation']['events']}
assert run['physical_allocation']['released'] and life['release']>life['acquire']
watch=[]
for line in (RAW/'source1_launch.launch/watchdog.jsonl').open():
    r=json.loads(line)
    if r.get('event')=='resource_sample':watch.append(r)
assert watch and not any(r['decision']['abort_reasons'] for r in watch)
roles={f'source-profile/w{i}/l{j}':w['role'] for i,w in enumerate(run['source_profile_spec']['waves']) for j in range(len(w['requests']))}
groups=collections.defaultdict(list)
for q in run['requests']:
    assert q['pass'] and q['actual_tokens']==q['target_tokens']==q['timing']['native_output_tokens']
    assert q['timing']['native_terminal_observed'] and q['reservation_released']
    if roles[q['request_id']]=='representative_measurement':groups[q['requested_source']].append(q)
def mean(rows,key):return statistics.mean(key(r) for r in rows)
descriptive={source:dict(n=len(rows),acquisition_mean_ms=mean(rows,lambda r:1000*(r['acquired_monotonic_s']-r['admitted_monotonic_s'])),
    admitted_to_first_mean_ms=mean(rows,lambda r:1000*(r['first_token_monotonic_s']-r['admitted_monotonic_s'])),
    native_tpot_mean_ms=mean([r for r in rows if r['actual_tokens']>1],lambda r:r['timing']['native_tpot_ms'])) for source,rows in groups.items()}
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
record=dict(passed=True,experiment_pass=True,kind='d642_complete_3b_source_measurement_v1',
    source_execution_commit=(RAW/'source_commit.txt').read_text().strip(),
    request_cases=368,measured_cases=360,warmup_retained=8,requests_token_contract_pass=368,
    startup_latency_ms=run['startup_latency_ms'],physical_gpu_seconds=life['release']-life['acquire'],
    fetches=len(transfers),wire_bytes=sum(r['transferred_bytes'] for r in run['remote_transfers']),request_packing=0,
    source_descriptive=descriptive,coverage=coverage,
    service_memory_peak=max(r['service']['memory.peak'] for r in watch),
    min_host_available_bytes=min(r['host']['available_bytes'] for r in watch),
    memory_events={k:max(r['service']['memory.events'][k] for r in watch) for k in ('high','max','oom','oom_kill')},
    service_swap_peak=max(r['service']['memory.swap.current'] for r in watch),protected=protected,
    local_launcher_path_gone=not group.exists(),remote_stopped=read(RAW/'remote_stop.json')['all_owned_units_inactive'],
    main_performance_point=False,full_profile_eligible=False,n_correct=None,common_SLO_qualified=False,
    independent_runs=1,CI=None,
    caveat='Source-only measured intervals, not Full/admission initialization or SLO evidence. Host file/tensor representations are separate. Prior D641 changed compiler/page cache initial state; no causal startup speedup claim.',
    evidence={name:p.digest(RAW/name) for name in ('source1.json','source1_launch.json','remote_transfers.jsonl','remote_monitor.log','local_cleanup.json','remote_stop.json','coverage.json','launch_gate.json')})
save('measurement_audit.json',record)
print(json.dumps({k:record[k] for k in ('passed','request_cases','measured_cases','startup_latency_ms','physical_gpu_seconds','fetches','wire_bytes','source_descriptive','service_memory_peak','memory_events')}))
