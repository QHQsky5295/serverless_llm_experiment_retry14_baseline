"""Finish the same explicit checkpoint after a new-document EOF whitespace check."""
import json,os,re,subprocess,sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline');RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d642_3b_launch_alignment'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name)
with (RAW/'publication_identity.json').open('x') as f:json.dump(identity,f,indent=2)
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert json.loads((RAW/'backup_closure.json').read_text())['path_gone']
assert p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')['pass']
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
names=['scripts/ieee_tc/run_d298_capacity_source.sh','docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D642_3B_SOURCE_LAUNCH_ALIGNMENT.md']
names += [str((OUT/name).relative_to(ROOT)) for name in ('qualification.json','execution_evidence.tar.gz','result.sha256')]
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
for name in names:
    data=(ROOT/name).read_bytes();assert token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: align 3B source launch with existing native compiler and startup contract (D642)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
with (RAW/'backup_receipt.json').open('x') as f:json.dump(dict(passed=True,head=head,remote=remote,identity=identity,files=names,prior_failure='new untracked document extra EOF blank; fixed before commit, no experiment started'),f,indent=2)
print(json.dumps(dict(passed=True,head=head,remote_equal=True)))
