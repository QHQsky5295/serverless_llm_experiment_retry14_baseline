"""Source-only audit after closure; do not export an admission-enabled profile."""
import ast
from pathlib import Path
source=Path(__file__).resolve().parent/'collect.py'
code=source.read_text()
code=code.replace("save('analysis_identity.json',identity)","save('analysis2_identity.json',identity)",1)
begin=code.index("subprocess.run([sys.executable,str(RAW/'remote_control.py'),'stop']")
end=code.index("run=read(RAW/'source1.json')",begin)
code=code[:begin]+'''assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
closed=read(RAW/'local_cleanup.json');group=Path(closed['identity']['path'])
assert not group.exists()
assert read(RAW/'analysis_closure.json')['path_gone']
''' +code[end:]
code=code.replace('from scripts.ieee_tc.export_d298_profiles import completed_gap_samples\n','')
code=code.replace("samples,coverage=completed_gap_samples(run,source_sha=p.digest(RAW/'source1.json'),identities=identities)",
    "coverage=p.source_profile_class_coverage(run,identities)")
code=code.replace("assert len(samples)==360", "assert sum(len(w['requests']) for w in run['source_profile_spec']['waves'] if w['role']=='representative_measurement')==360")
needle="    assert q['timing']['native_terminal_observed'] and q['reservation_released']\n"
assert code.count(needle)==1
code=code.replace(needle,needle+'''    t=q['timing']
    assert t['native_clock_id']==q['native_clock_id']==q['admission_clock_id']
    assert q['first_token_monotonic_s']==t['native_first_token_monotonic_s']
    assert q['last_token_monotonic_s']==t['native_last_token_monotonic_s']
    if q['actual_tokens']>1:
        assert abs((q['last_token_monotonic_s']-q['first_token_monotonic_s'])*1000/(q['actual_tokens']-1)-t['native_tpot_ms'])<=1
''',1)
code=code.replace("record=dict(passed=True,experiment_pass=True,", "record=dict(admission_profile_export_attempt='refused: source-only lacks pending_kv_admission; no validator weakened, no GPU rerun',passed=True,experiment_pass=True,",1)
ast.parse(code)
exec(compile(code,str(source),'exec'))
