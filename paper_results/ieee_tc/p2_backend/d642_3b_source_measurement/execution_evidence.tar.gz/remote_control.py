"""Reuse frozen service controls with this campaign's unique ownership."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d641_20261017/remote_control.py')
code=source.read_text().replace('d641_20261017','d642_20261017').replace('d641-source','d642-source').replace('d636->d641','d636->d642')
exec(compile(code,str(source),'exec'))
