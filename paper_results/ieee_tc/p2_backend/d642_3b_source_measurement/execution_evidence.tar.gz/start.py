"""Reuse D641 source launch after the independently checked entry alignment."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d641_20261017/start.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("assert head==remote=='02f438519d2cca90aa2b710466900dac1daca2a6'",
        "assert head==remote==read(RAW/'backup_receipt.json')['head']")
replace("previous=RAW.parent/'d640_20261017'","previous=RAW")
replace("previous/'backup_closure.json'","previous/'publication_closure.json'")
replace("assert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==audit['inputs']['runner_sha256']",
        "assert read(RAW/'qualification.json')['passed']\nassert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==read(RAW/'qualification.json')['runner_sha256']")
code=code.replace('tc-d641-source','tc-d642-source').replace('run_d298_capacity_source.sh d641','run_d298_capacity_source.sh d642')
exec(compile(code,str(source),'exec'))
