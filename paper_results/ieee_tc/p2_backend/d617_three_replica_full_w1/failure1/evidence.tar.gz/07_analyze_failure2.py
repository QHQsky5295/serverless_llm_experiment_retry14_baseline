"""Resume post-release analysis after collector output; no downloads or replay repeated."""
from pathlib import Path
source=Path(__file__).resolve().parent/'analyze_failure.py'
body=source.read_text()
old="from pathlib import Path\n"
assert body.count(old)==1
body=body.replace(old,old+"ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')\n")
assert body.count("raw/'analysis_identity.json'")==1
body=body.replace("raw/'analysis_identity.json'","raw/'analysis2_identity.json'")
start=body.index('hashes = {}\n')
end=body.index('# Reuse the existing partial-result protocol;',start)
body=body[:start]+'''remote_saved=json.loads((raw/'remote_stop.json').read_text())
assert remote_saved['all_owned_units_inactive'] and remote_saved['download_hashes_match_remote']
for name,expected in remote_saved['hashes'].items():assert p.digest(raw/name)==expected
'''+body[end:]
old="save(raw/'failure_mechanism.json',dict(outcome=outcome,mechanism=mechanism))"
assert body.count(old)==1
body=body.replace(old,"assert json.loads((raw/'failure_mechanism.json').read_text())==dict(outcome=outcome,mechanism=mechanism)")
exec(compile(body,str(source),'exec'),dict(__file__=str(Path(__file__).resolve()),__name__='d617_failure_analysis2'))
