"""Reuse D615 qualified implementation/configuration; bind the full existing W1."""
import ast, copy, json, os, subprocess, sys
from pathlib import Path
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'qualification_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='2d19bd2bfffa2b07ee0c92376ea6646ea211ea20'
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
parent=RAW.parent/'d615_20261017'
old=read(parent/'qualification.json')
assert old['passed'] and old['count']==4000
assert old['three_replica_checks']['passed'] and old['three_replica_checks']['case_count']==192
assert old['control_tests_run']==21 and old['reused_cpu_regression_tests']==406 and old['reused_focused_tests']==16
for path,sha in {**old['refs'],**old['preserved']}.items():
    if Path(path)!=shell:assert p.digest(Path(path))==sha,path
previous=RAW.parent/'d610_20261017'
for name in ('focused_receipt.json','regression_receipt.json'):
    reg=read(previous/name);assert reg['passed'] and reg['returncode']==0
    for path,sha in reg['sources'].items():assert p.digest(Path(path))==sha,path
for phase in ('qualification3','backup','start','analysis','publication'):
    closed=read(parent/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
auditpath=ROOT/'paper_results/ieee_tc/p2_backend/d615_three_replica_full_w2/result1/summary.json'
audit=read(auditpath)['audit']
assert audit['passed'] and audit['fixed_workload_complete4000']
storage=RAW.parent.parent/'storage_maintenance/d616_20261017'
for phase in ('storage','publication'):
    closed=read(storage/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
gate=p.preflight([ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
paths=[ROOT/'configs/ieee_tc/20261017_d615_7b_three_replica_full_w2.yaml',
       ROOT/'configs/ieee_tc/20261017_d617_7b_three_replica_full_w1.yaml']
configs=[yaml.safe_load(path.read_text()) for path in paths]
normalized=copy.deepcopy(configs)
for row in normalized:
    row['experiment'].pop('output_dir')
    row['storage'].pop('nvme_cache_dir');row['storage'].pop('host_cache_dir')
assert normalized[0]==normalized[1], 'no W1-specific model or policy tuning'
assert configs[1]['resource_coordination']['max_instances']==3
assert configs[1]['resource_coordination']['min_instances']==1
assert configs[1]['model']['visible_device_ids']==configs[1]['hardware']['gpu_device_ids']==[0,1,2,3]
for path in (Path(configs[1]['experiment']['output_dir']),Path(configs[1]['storage']['nvme_cache_dir']),Path(configs[1]['storage']['host_cache_dir'])):
    assert not path.exists(),path
body=shell.read_text();start=body.index('  d617)\n');end=body.index('    ;;\n',start)+len('    ;;\n')
branch=body[start:end]
assert paths[1].name in branch and 'PREFIX_COUNT=\n' in branch and 'SCENARIO=tc_ieee_full\n' in branch
restored=(body[:start]+body[end:]).replace(' || "${1:-d293}" == d617','')
assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
observer_line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd328' in line)
assert 'd617' not in observer_line
w1line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd533' in line)
w2line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd554' in line)
assert 'd617' in w1line and 'd617' not in w2line
oldw1path=RAW.parent/'d551_20261015/qualification.json'
oldw1=read(oldw1path)['prime_plan']
plan=FrozenReplayPlan.load(oldw1['source_path'],profile='W1')
assert plan.identity()==oldw1 and len(plan.entries)==plan.source_count==4000
assert plan.identity()['view_sha256']=='103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
assert FrozenReplayPlan.from_launch_context(dict(plan=plan.identity(),tiny_witness=False,replay_scope='full_source_v1'))==plan
from scripts.run_all_experiments import ScenarioRunner, _prepare_scenario_runtime_model_config, _normalize_runtime_concurrency_cap
full=configs[1];scenario=next(row for row in full['scenarios'] if row['name']=='tc_ieee_full')
coord=dict(full['resource_coordination'],**scenario.get('resource_coordination',{}))
runner=ScenarioRunner.__new__(ScenarioRunner)
runner.model_cfg=_prepare_scenario_runtime_model_config(_normalize_runtime_concurrency_cap(full['model']),full['workload'],coord)
runner.coord_cfg=coord;runner._initial_runtime_pending=True
runner._service_profiles=runner._load_ieee_service_profiles();runner._load_ieee_preparation_profiles()
buildpath=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=read(buildpath);assert build['passed'] and build['actual_closure']['passed'] and build['actual_closure']['path_gone']
assert not Path(build['actual_closure']['identity']['path']).exists()
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256'],path
helpers=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),shell])
for path in helpers:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    else:subprocess.run(['bash','-n',str(path)],check=True)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
refs=[*helpers,*paths,parent/'qualification.json',parent/'qualification3_closure.json',
      parent/'analysis_closure.json',parent/'publication_closure.json',auditpath,oldw1path,buildpath,
      storage/'storage_result.json',storage/'storage_closure.json',storage/'publication_closure.json',
      previous/'focused_receipt.json',previous/'regression_receipt.json',
      RAW.parent/'d550_20261015/close.py',ROOT/'docs/ieee_tc/D614_RESOURCE_WORKING_POINT_AUDIT.md']
refs += [Path(path) for path in old['refs'] if Path(path)!=shell]
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
import torch
assert not torch.cuda.is_initialized()
save(RAW/'qualification.json',dict(passed=True,scope=identity,protected=protected,preserved=old['preserved'],
    prime_plan=plan.identity(),source_count=4000,count=4000,configuration_changes={},
    same_model_working_point_as_d615=True,unchanged_other_model_control_settings=True,
    three_replica_checks=old['three_replica_checks'],control_tests_run=0,reused_control_tests=21,
    reused_cpu_regression_tests=406,reused_focused_tests=16,reused_input_tests=386,
    exact_profiles_loaded=True,observer=None,ordinary_full_replay=True,ranking_eligible=False,
    preflight=gate,refs={str(path):p.digest(path) for path in refs},
    resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,count=4000,profile='W1',same_model_working_point_as_d615=True,
    view_sha256=plan.identity()['view_sha256'],new_tests=0,reused_regression=406,reused_focused=16,
    reused_control_tests=21,reused_config_checks=192,exact_profiles_loaded=True)))
