"""D617 closure: reuse D452 exact-owned cleanup/download checks."""
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

own_identity = p.scope_identity(p.cg_path().name)
own_group = Path(own_identity['path'])
assert (own_group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (own_group/'memory.swap.max').read_text().strip() == '0'
gate = p.preflight([p.ROOT], 4*p.GIB)
# Closure is not a new launch: the run may have crossed the start-floor while
# writing its retained logs.  Record that gate honestly and reject only a
# live-resource/safety issue, not the expected post-run disk condition.
assert not any('host_memory_below_stop' in issue or 'filesystem_below_stop' in issue
               for issue in gate['issues']), gate['issues']
raw = Path(__file__).resolve().parent
with (raw/'analysis_identity.json').open('x') as stream:json.dump(own_identity,stream,indent=2)
assert gate['memory']['MemAvailable'] >= 16*p.GIB
assert all(row['free_bytes'] >= 101*p.GIB for row in gate['filesystems'])
run = raw/'7b_three_replica_full_w1'
launch = json.loads((run/'launch.json').read_text())
assert not launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
local = json.loads((raw/'local_cleanup.json').read_text())
assert local['passed'] and local['service_path_gone'] and local['auxiliary_path_gone'] and local['actual_recursive_procs_empty']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
starter = json.loads((raw/'start_closure.json').read_text())
assert starter['passed'] and starter['path_gone'] and starter['actual_recursive_procs_empty']
stop = (raw/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive') == 3 and stop.count('MainPID=0') == 3
transfer_paths = [line for line in stop.splitlines()
    if line.startswith('/home/lab14/primelora_remote/tc/d80_20260927/7b/transfers-') and line.endswith('.jsonl')]
assert len(transfer_paths) == 1
paths = {
    'remote_transfers.jsonl': transfer_paths[0],
    'remote_monitor.log': '/home/lab14/primelora_remote/tc/d617_20261017/remote_monitor.log',
}
hashes = {}
for name, remote_path in paths.items():
    destination = raw/name
    assert not destination.exists()
    expected = subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','sha256sum',remote_path],text=True).split()[0]
    subprocess.run(['scp','-q','-o','BatchMode=yes',f'primelora-artifact-174:{remote_path}',str(destination)],check=True)
    assert p.digest(destination) == expected
    hashes[name] = expected
with (raw/'remote_stop.json').open('x') as f:
    json.dump(dict(all_owned_units_inactive=True,ports_18080_18081_absent=True,
        local_gpu_release_verified_before_remote_stop=True,download_hashes_match_remote=True,
        hashes=hashes,stop_log_sha256=p.digest(raw/'remote_stop.log')),f,indent=2)
print(json.dumps(dict(local_aux_inactive=True,remote_inactive=True,hashes=hashes)))

# Reuse the existing partial-result protocol; never promote interruption to success.
import ast, importlib.util, ijson, os, re
from types import SimpleNamespace
assert os.sched_getaffinity(0)=={2,3,26,27}
assert (own_group/'memory.high').read_text().strip()==str(3*p.GIB)
outcome_path=run/'launch.launch/physical_deployment/main_outcome.json'
def selected(prefix):
    with outcome_path.open('rb') as stream:return next(ijson.items(stream,prefix,use_float=True))
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
outcome={name:selected(name) for name in
    ('run_completed','error','cleanup_errors','measurement_errors','cleanup','launch_contract','cpu_frontend_preparation')}
assert not outcome['run_completed']
assert 'CPU frontend device is unknown or already claimed' in outcome['error']['traceback']
mechanism={name:selected('mechanism_events.'+name) for name in
    ('_ieee_activations','_ieee_control_events','_ieee_scalein_events','_ieee_runtime_quarantine_events')}
save(raw/'failure_mechanism.json',dict(outcome=outcome,mechanism=mechanism))
summary=json.loads((run/'launch.launch/physical_deployment/summary.json').read_text())
physical=json.loads((run/'launch.launch/physical_deployment/physical_resource_summary.json').read_text())
assert summary['n_plan']==physical['n_plan']==4000
assert summary['n_terminal']==summary['n_native_contract_complete']==1519
assert summary['gpu_seconds'] is None and physical['physical_gpu_seconds_total'] is None
assert not summary['measurement_complete'] and not summary['open_lease_ids']
assert abs(sum(b-a for spans in summary['device_intervals'].values() for a,b in spans)
           -summary['gpu_seconds_observed'])<1e-6
replay_rows=[json.loads(line) for line in (run/'launch.launch/replay.jsonl').read_text().splitlines()]
replay_end=replay_rows[-1]
assert replay_end['event']=='replay_incomplete' and replay_end['N_plan']==4000
resource_rows=[r for line in (run/'launch.launch/watchdog.jsonl').read_text().splitlines()
               if (r:=json.loads(line))['event']=='resource_sample']
assert resource_rows
resources=dict(samples=len(resource_rows),
    peak_bytes=max(r['service']['memory.peak'] for r in resource_rows),
    max_swap_bytes=max(r['service']['memory.swap.current'] for r in resource_rows),
    events={k:max(r['service']['memory.events'][k] for r in resource_rows)
            for k in ('high','max','oom','oom_kill')},
    aborts=[r['decision']['abort_reasons'] for r in resource_rows if r['decision']['abort_reasons']],
    foreign_compute_samples=sum(bool(r['gpu']['foreign_compute_processes']) for r in resource_rows))
server_rows=[json.loads(line) for line in (raw/'remote_transfers.jsonl').read_text().splitlines()]
transfers=selected('remote_transfers')
remote=dict(server_count=len(server_rows),local_count=len(transfers),
    server_outcomes={},local_states={},request_time_pack_count=sum(bool(r['pack_performed']) for r in server_rows),
    wire_bytes_sent=sum(r['bytes_written'] for r in server_rows))
from collections import Counter
remote['server_outcomes']=dict(Counter(r['outcome'] for r in server_rows))
remote['local_states']=dict(Counter(r['state'] for r in transfers))

# Execute the actual unchanged selection method, without importing GPU libraries.
source=ROOT/'scripts/run_all_experiments.py'
tree=ast.parse(source.read_text())
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ScenarioRunner')
method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_select_dedicated_device_id')
module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),method],type_ignores=[])
namespace={}
exec(compile(ast.fix_missing_locations(module),str(source),'exec'),namespace)
selector=namespace['_select_dedicated_device_id']
spec=importlib.util.spec_from_file_location('d617_cpu_frontend',ROOT/'faaslora/cpu_frontend.py')
cpu=importlib.util.module_from_spec(spec);spec.loader.exec_module(cpu)
def witness(preparation_devices):
    pool=cpu.CPUFrontendPool(devices=preparation_devices,create=lambda device,notice:object())
    import time
    pool.start(deployment_notice_s=time.monotonic())
    for device in (0,1,2):pool.claim(device)
    slots=[SimpleNamespace(device_id=d,status='draining' if d==1 else 'running') for d in (0,1,2)]
    runner=SimpleNamespace(_available_device_ids=lambda:[0,1,2,3],
        model_cfg={'tensor_parallel_size':1},instance_pool=SimpleNamespace(get_all_slots=lambda:slots),
        _pending_scale_up_device_ids=set(),_failed_runtime_device_ids=set())
    device=selector(runner)
    error=None
    try:pool.claim(device)
    except RuntimeError as exc:error=str(exc)
    return dict(preparation_devices=list(preparation_devices),selected_device=device,error=error,
        retained_devices=[s.device_id for s in slots],claimed_before=[0,1,2])
partial=witness([0,1,2]);complete=witness([0,1,2,3])
assert partial['selected_device']==complete['selected_device']==3
assert partial['error']=='CPU frontend device is unknown or already claimed' and complete['error'] is None
assert outcome['cpu_frontend_preparation']['legal_devices']==[0,1,2]
save(raw/'device_set_witness.json',dict(passed=True,partial_preparation_set=partial,
    full_preparation_set_control=complete,actual_unchanged_selector=True,
    actual_cpu_pool_class=True,no_gpu_spawn=True,no_production_edit=True,
    source_sha256={str(f):p.digest(f) for f in (source,ROOT/'faaslora/cpu_frontend.py')}))
service_log=(run/'launch.launch/service.log').read_text()
worker_roots=sorted(set(re.findall(r'preserved dedicated worker workdir: (\S+)',service_log)))
worker_files=[]
for value in worker_roots:
    folder=Path(value);assert folder.is_relative_to(ROOT/'results/worker_failures')
    for name in ('worker.log','cpu_prepared.json','cpu_activated.json','ready.json','process.json'):
        path=folder/name
        if path.is_file():worker_files.append(dict(path=str(path),sha256=p.digest(path),bytes=path.stat().st_size))
protected=p.verify_seal(raw.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
preserved=json.loads((raw/'qualification.json').read_text())['preserved']
for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
refs=[outcome_path,run/'launch.json',run/'launch.launch/service.log',
    run/'launch.launch/replay.jsonl',run/'launch.launch/watchdog.jsonl',
    run/'launch.launch/physical_deployment/summary.json',
    run/'launch.launch/physical_deployment/physical_resource_summary.json',
    run/'launch.launch/physical_deployment/request_terminals.jsonl',
    raw/'remote_transfers.jsonl',raw/'remote_monitor.log',raw/'remote_stop.json',
    raw/'local_cleanup.json',raw/'failure_mechanism.json',raw/'device_set_witness.json',
    Path(__file__),source,ROOT/'faaslora/cpu_frontend.py']
refs += list((run/'launch.launch/physical_allocations').glob('*.jsonl'))
record=dict(passed=True,failure_evidence_qualified=True,full_performance_complete=False,
    ranking_eligible=False,numerical_correctness_qualified=False,n_correct=None,
    n_plan=4000,n_external_arrived=replay_end['N_arrived'],
    n_external_submitted=replay_end['N_submitted'],n_terminal=summary['n_terminal'],
    n_native_contract_complete=summary['n_native_contract_complete'],
    n_controller_interrupted=summary['n_interrupted'],
    interrupted_is_not_all_outstanding_external_requests=True,
    unarrived_not_counted_as_failed=True,physical_gpu_seconds_total=None,
    physical_gpu_seconds_observed=summary['gpu_seconds_observed'],
    source_commit=json.loads((raw/'launch_gate.json').read_text())['head'],
    launch_classification_retained=launch['classification'],
    launch_secondary_error=launch['error'],
    primary_failure='CPU preparation/placement device-set mismatch during scale-in/scale-out overlap',
    classification_interpretation='System implementation activation failure; replay disconnect is secondary, not evidence of external interference or OOM',
    selection_device_3_inferred_from_live_ownership_and_actual_method=True,
    no_direct_target_device_event=True,no_fix_or_rerun=True,
    resources=resources,remote=remote,protected=protected,preserved=preserved,
    device_set_witness=dict(partial=partial,control=complete),
    worker_files=worker_files,refs=[dict(path=str(f),sha256=p.digest(f),bytes=f.stat().st_size) for f in refs],
    scope=own_identity)
save(raw/'failure_analysis.json',record)
print(json.dumps({k:record[k] for k in ('passed','full_performance_complete','n_plan',
    'n_external_arrived','n_external_submitted','n_terminal','n_controller_interrupted',
    'physical_gpu_seconds_observed','primary_failure','resources','remote')},indent=2))
