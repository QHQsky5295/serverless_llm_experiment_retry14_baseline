"""D617 failed-run publication, adapted from D615 explicit-source publisher.
Preserve the failed performance run, exact method witness and analysis attempts.
No new inference, production edit or incomplete-run performance ranking.
"""
import ast, hashlib, io, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d617_three_replica_full_w1/failure1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD')=='dbcb0ef11b3fd0e28f85a3f57d334914668a6572'
assert not git('diff','--cached','--name-only')
assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')
audit=read(RAW/'failure_analysis.json')
assert audit['passed'] and audit['failure_evidence_qualified']
assert not audit['full_performance_complete'] and not audit['ranking_eligible']
assert audit['n_plan']==4000 and audit['n_terminal']==1519 and audit['n_correct'] is None
assert audit['physical_gpu_seconds_total'] is None and audit['no_fix_or_rerun']
for ref in audit['refs']+audit['worker_files']:
    assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
for name in ('qualification','backup','start','analysis','analysis2'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
local=read(RAW/'local_cleanup.json')
assert local['passed'] and not local['launch_passed']
assert local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists()
assert not Path(local['auxiliary_identity']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
binding=read(RAW/'qualification.json')
for path,sha in {**binding['refs'],**binding['preserved']}.items():
    assert p.digest(Path(path))==sha,path
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),*RAW.glob('*.json'),
    *(path for path in RAW.glob('*.log') if path.name!='remote_monitor.log')])
files += [Path(ref['path']) for ref in audit['worker_files']]
run=RAW/'7b_three_replica_full_w1'
files += [run/'launch.json',run/'launch.launch/service.log',run/'launch.launch/replay.jsonl',
    run/'launch.launch/service_ingress.jsonl',
    *sorted((run/'launch.launch/physical_deployment').glob('*.json')),
    run/'launch.launch/physical_deployment/request_terminals.jsonl',
    *sorted((run/'launch.launch/physical_allocations').glob('*.jsonl')),
    ROOT/'docs/ieee_tc/D617_THREE_REPLICA_FULL_W1.md',
    RAW.parent/'d615_20261017/publish_result.py',
    RAW.parent/'d550_20261015/close.py']
files=[path for path in dict.fromkeys(files) if path.name!='main_outcome.json']
OUT.mkdir(parents=True,exist_ok=False);members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as bundle:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<8*1024*1024;clean(data)
        if path.suffix=='.py':ast.parse(data)
        name=f'{i:02d}_{path.name}';info=tarfile.TarInfo(name)
        info.size,info.mode,info.mtime=len(data),0o600,0
        bundle.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'summary.json',dict(passed=True,failure_evidence_qualified=True,
    native_full_qualified=False,full_performance_complete=False,
    independent_numerical_correctness='unknown',raw_n_correct=None,ranking_eligible=False,
    audit=audit,protected=protected,execution_commit=audit['source_commit'],
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz')))
with (OUT/'result.sha256').open('x') as stream:
    for name in ('summary.json','evidence.tar.gz'):stream.write(p.digest(OUT/name)+'  '+name+'\n')
names=['docs/ieee_tc/D617_THREE_REPLICA_FULL_W1.md','docs/ieee_tc/EXECUTION_STATUS.md']
names += [str((OUT/name).relative_to(ROOT)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
for name in names:
    if not name.endswith('.tar.gz'):clean((ROOT/name).read_bytes())
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: preserve failed W1 activation and device-domain cause (D617)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD');remote=git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))

