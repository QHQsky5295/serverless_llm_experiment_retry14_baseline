"""Small immutable D180 evidence/table delivery, following D174 probe outputs."""
from collections import Counter
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX = '20261003_d180_request_scoped_footprint'

def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert subprocess.check_output(['systemctl', '--user', 'show',
    'primelora-d180-probe1-20261003.scope', '-p', 'LoadState', '--value'], text=True).strip() == 'not-found'
events = dict(line.split() for line in (RAW/'probe1_memory_events.txt').read_text().splitlines())
assert all(int(v) == 0 for v in events.values())
assert (RAW/'probe1_swap.txt').read_text().strip() == '0'
scope = (RAW/'probe1_scope.txt').read_text()
assert 'InvocationID=204014b8ae83422cb14c3bf6b382a320' in scope
assert 'Exit status: 0' in (RAW/'probe1_time.txt').read_text()
for line in (RAW/'probe1_sources.sha256').read_text().splitlines():
    expected, name = line.split(maxsplit=1)
    path = ROOT/name
    assert sha(path) == expected, name
probe = json.loads((RAW/'probe1.json').read_text())
assert len(probe['retained_snapshot_targets']) == 64
assert probe['service_class_comparisons'] == 192
assert len(probe['cases']) == 5 and len(probe['rejections']) == 3
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
groups = []
for index in range(4):
    values = [r for r in probe['retained_snapshot_targets'] if r['snapshot'] == index]
    assert values and all(r['exact_target_footprint_class_and_all_identities_equal'] for r in values)
    columns = ('registered_adapters', 'full_tensor_checks', 'target_tensor_checks', 'check_reduction_fraction')
    assert all(len({r[k] for r in values}) == 1 for k in columns)
    groups.append(dict(snapshot=index, **{k: values[0][k] for k in columns},
                       compared_targets=len(values), gpu_targets=sum(r['tier']=='gpu' for r in values),
                       host_targets=sum(r['tier']=='host' for r in values)))

doc = ROOT/'docs/ieee_tc/D180_REQUEST_SCOPED_FOOTPRINT_STUDY.md'
members = [RAW/name for name in ('probe.py','run_cpu.sh','probe1.json','probe1.csv',
    'probe1.log','probe1_scope.txt','probe1_sources.sha256','probe1_time.txt',
    'probe1_memory_events.txt','probe1_swap.txt','curate.py','run_curate.sh')]
members.append(doc)
sources = {str(p): sha(p) for p in members}
with (OUT/(PREFIX+'.csv')).open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(groups[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(groups)
table = ['# D180 dependency-study table', '',
    'CPU/saved-observation study; no serving latency measurement, no CI, no model acceptance.', '',
    '| Snapshot | Adapters | Full tensor checks | Target checks | Reduction | GPU/HOST targets |',
    '|---|---:|---:|---:|---:|---:|']
for r in groups:
    table.append(f"| {r['snapshot']} | {r['registered_adapters']} | {r['full_tensor_checks']} | "
        f"{r['target_tensor_checks']} | {100*r['check_reduction_fraction']:.3f}% | {r['gpu_targets']}/{r['host_targets']} |")
table += ['', '64 target footprints and 192 service classes match; all identity fields preserved.',
    'Shared-storage counterexample: reachable=512 bytes, globally reclaimable=0 bytes.',
    'Unrelated malformed tensors are not checked by target observation; global safety equivalence is NOT claimed.',
    'A scoped production schema, freshness/sharing tests, and complete 7B replay remain pending.']
with (OUT/(PREFIX+'_table.md')).open('x') as stream:
    stream.write('\n'.join(table)+'\n')
bundle = OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output, tarfile.open(fileobj=output, mode='w:gz') as archive:
    for p in members:
        # Only explicit small evidence; never remote credentials or raw large data.
        archive.add(p, arcname=p.name, recursive=False)
with tarfile.open(bundle, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(members)
    for p in members:
        assert hashlib.sha256(archive.extractfile(p.name).read()).hexdigest() == sources[str(p)]
result = dict(kind='d180_dependency_study_curated_v1', status='component_pass_not_serving_qualified',
    probe=probe, summary=groups, source_sha256=sources, protected_after=protected,
    probe_scope_absent=True, probe_memory_events=events, probe_swap_bytes=0,
    plot_decision='Exact comparison/status table, not a performance figure; no n=1 CI.',
    production_changed=False, gpu_execution=False, remote_operation=False,
    evidence_bundle=dict(path=str(bundle), sha256=sha(bundle), bytes=bundle.stat().st_size,
                         members=len(members)),
    output_csv_sha256=sha(OUT/(PREFIX+'.csv')), table_sha256=sha(OUT/(PREFIX+'_table.md')))
with (OUT/(PREFIX+'.json')).open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
print(json.dumps(dict(status='PASS', summary=groups, evidence_bundle=result['evidence_bundle'],
                     curated_sha256=sha(OUT/(PREFIX+'.json'))), indent=2))
