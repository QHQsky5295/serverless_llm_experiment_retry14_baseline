#!/usr/bin/env bash
# Derived from D174/D178: unchanged bounded CPU resource protocol.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in probe1) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d180_20261003
unit="primelora-d180-${phase}-20261003.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sha256sum faaslora/memory/gpu_monitor.py faaslora/experiment/instance_pool.py scripts/run_all_experiments.py "$raw/probe.py" "$raw/run_cpu.sh" > "$raw/${phase}_sources.sha256"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
set +e
/usr/bin/time -v -o "$raw/${phase}_time.txt" /home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python "$raw/probe.py" > "$raw/${phase}.log" 2>&1
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/${phase}_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/${phase}_swap.txt"
exit "$code"
