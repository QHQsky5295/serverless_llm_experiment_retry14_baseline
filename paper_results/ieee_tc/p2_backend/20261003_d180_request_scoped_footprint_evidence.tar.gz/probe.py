"""D174-derived target-footprint dependency study; NOT a production parser.

Uses existing tiny native CPU fixtures and retained D169 native observations.
No weights/traces generated, CUDA execution or serving-performance claim.
"""
import copy
import csv
import dataclasses
import hashlib
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace
from unittest.mock import patch

import torch
from scripts.ieee_tc_preflight import verify_seal
from faaslora.memory import gpu_monitor as monitor
from faaslora.experiment.instance_pool import NativeSourceSnapshot, ServiceClassBins
from tests.test_ieee_tc_worker_observation import NativeHostFootprint

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
PARENT = '74c417e3cba3c5c4358e89240b1036565cea12ba'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == PARENT
assert not torch.cuda.is_initialized()
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147, protected
assert protected['plan_sha256'] == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
metric_sha = hashlib.sha256((ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md').read_bytes()).hexdigest()
assert metric_sha == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'


def host_class(graph, aid):
    """Only dependency fields of the existing service-class definition."""
    matches = [a for a in graph['host_adapter_footprints'] if a['adapter_int_id'] == aid]
    if not matches:
        return None
    assert len(matches) == 1
    adapter = matches[0]
    allocations = graph['host_allocations']
    used = [allocations[i] for i in adapter['allocation_ids']]
    capacity = sum(a['allocated_bytes'] for a in used)
    assert capacity == adapter['storage_bytes']
    pinning = {a['pinned'] for a in used}
    representation = 'native_cpu_dense_ab_v1:' + ','.join(sorted(set(adapter['dtypes'])))
    representation += ':' + ('pinned' if pinning == {True} else
                             'unpinned' if pinning == {False} else 'mixed_pinning')
    if adapter['has_packed_modules']:
        representation += ':packed'
    return capacity, representation


def target_observe(native, aid):
    # Test-only restricted manager. This result MUST NOT be published as a
    # full registered-cache observation or used for budget/eviction decisions.
    models = native.list_adapters()
    selected = {aid: models[aid]} if aid in models else {}
    graph = monitor._ieee_lora_host_inventory(
        SimpleNamespace(list_adapters=lambda: dict(selected)), include_tensor_views=False)
    return graph


def capture(function):
    calls = []
    original = torch.Tensor.is_pinned
    def observed(tensor):
        calls.append(id(tensor))
        return original(tensor)
    with patch.object(torch.Tensor, 'is_pinned', observed):
        value = function()
    return value, len(calls)


cases = []
for case in ('shared', 'partial', 'packed', 'missing', 'target_mutation'):
    native, models = NativeHostFootprint().native_models()
    target = 99 if case == 'missing' else 8
    if case == 'partial':
        models[8].loras['shared'].lora_a = models[8].loras['shared'].lora_a[:1, :4]
        models[8].loras['shared'].lora_b = models[8].loras['shared'].lora_b[:4, :1]
    elif case == 'packed':
        layer = models[8].loras['shared']
        models[8].loras = {'qkv': SimpleNamespace(lora_a=[layer.lora_a, None],
                                                lora_b=[layer.lora_b, None])}
    before = host_class(target_observe(native, target), target)
    if case == 'target_mutation':
        models[8].loras = {'new': SimpleNamespace(
            lora_a=torch.empty((4, 64), dtype=torch.float16),
            lora_b=torch.empty((64, 4), dtype=torch.float16))}
    full, full_calls = capture(lambda: monitor._ieee_lora_host_inventory(native, include_tensor_views=False))
    scoped, scoped_calls = capture(lambda: target_observe(native, target))
    assert host_class(full, target) == host_class(scoped, target), case
    if case == 'target_mutation':
        assert before != host_class(scoped, target)
    if case == 'missing':
        assert scoped_calls == 0 and host_class(scoped, target) is None
    full_row = next((a for a in full['host_adapter_footprints'] if a['adapter_int_id'] == target), None)
    scoped_row = next((a for a in scoped['host_adapter_footprints'] if a['adapter_int_id'] == target), None)
    cases.append(dict(case=case, full_tensor_checks=full_calls, target_tensor_checks=scoped_calls,
        exact_target_class_equal=True,
        global_union_bytes=full['host_tensor_storage_bytes'],
        target_reachable_bytes=scoped_row['storage_bytes'] if scoped_row else None,
        global_exclusive_bytes=full_row['exclusive_storage_bytes'] if full_row else None,
        isolated_exclusive_bytes_NOT_RECLAIMABLE=scoped_row['exclusive_storage_bytes'] if scoped_row else None))

rejections = []
for case in ('unsupported_target', 'incomplete_pair', 'pinning_disagreement'):
    native, models = NativeHostFootprint().native_models()
    if case == 'unsupported_target':
        models[8].loras['shared'].bias = torch.empty((4,))
    elif case == 'incomplete_pair':
        models[8].loras['shared'].lora_b = None
    incompatible = models[8].loras['shared'].lora_b
    observed = (lambda tensor: tensor is incompatible) if case == 'pinning_disagreement' else torch.Tensor.is_pinned
    with patch.object(torch.Tensor, 'is_pinned', observed):
        errors = []
        for function in (lambda: monitor._ieee_lora_host_inventory(native, include_tensor_views=False),
                         lambda: target_observe(native, 8)):
            try:
                function()
            except ValueError as error:
                errors.append(str(error))
        assert len(errors) == 2 and errors[0] == errors[1], (case, errors)
    rejections.append(dict(case=case, both_reject=True, error=errors[0]))

# Deliberate scope distinction: an unrelated malformed tensor is not examined
# by target observation. This is an explicit implementation obligation, not a
# claim of globally identical validation or an ignored failing fixture.
native, models = NativeHostFootprint().native_models()
models[7].loras['private'].bias = torch.empty((4,))
try:
    monitor._ieee_lora_host_inventory(native, include_tensor_views=False)
except ValueError:
    unrelated_full_rejects = True
else:
    raise AssertionError('full validation unexpectedly accepted unrelated malformed tensor')
assert host_class(target_observe(native, 8), 8) is not None

source = RAW.parent / 'd169_20261002/7b_probe1.json'
assert 0 < source.stat().st_size < 64 * 1024**2
raw = source.read_bytes()
source_sha = hashlib.sha256(raw).hexdigest()
assert source_sha == 'ead0c5c81acc52c502874e9d45cfba111665f875220e23467c2e716a0d770602'
snapshots = [row['sources_before'] for row in json.loads(raw)['warm_batches']]
del raw
assert len(snapshots) == 4
rows = []
exact_classes = 0
for index, view in enumerate(snapshots):
    full = NativeSourceSnapshot.from_native(view, expected_clock_id=view['clock_id'],
        received_monotonic_s=view['captured_monotonic_s'] + 1)
    graph = view['native_footprints']
    full_tensor_checks = len(graph['host_tensor_views'])
    for source_state in full.sources:
        aid = source_state.adapter_int_id
        adapter = next(a for a in graph['host_adapter_footprints'] if a['adapter_int_id'] == aid)
        selected = adapter['allocation_ids']
        remap = {old: new for new, old in enumerate(selected)}
        allocations = [{**graph['host_allocations'][old], 'allocation_id': remap[old], 'adapter_ids': [aid]}
                       for old in selected]
        isolated = {**adapter, 'allocation_ids': [remap[old] for old in selected],
                    'exclusive_storage_bytes': adapter['storage_bytes']}
        subset_graph = dict(host_allocations=allocations, host_adapter_footprints=[isolated])
        capacity, representation = host_class(subset_graph, aid)
        assert (capacity, representation) == (source_state.host_storage_bytes, source_state.host_representation)
        target = dataclasses.replace(source_state, host_storage_bytes=capacity, host_representation=representation)
        # Full metadata for target; others retain all fresh identity fields but
        # no footprint. No parser is bypassed in production: this object is
        # constructed ONLY inside this dependency experiment.
        scoped_state = dataclasses.replace(full,
            sources=tuple(target if s.adapter_int_id == aid else dataclasses.replace(s,
                host_storage_bytes=None, host_representation=None, gpu_slot_capacity_bytes=None,
                gpu_representation=None) for s in full.sources),
            host_tensor_storage_bytes=None, gpu_pool_storage_bytes=None)
        assert scoped_state.identity_view() == full.identity_view()
        bins = ServiceClassBins((16, 616, 759), (64, 128, 256), (8, 16, 64),
                                tuple(sorted({capacity, target.gpu_slot_capacity_bytes})), (1, 4, 8))
        for prompt, output, admitted in ((16, 64, 1), (616, 128, 4), (759, 256, 8)):
            features = dict(prompt_tokens=prompt, declared_output_tokens=output, admitted_after_accept=admitted)
            assert target.service_class(bins, **features) == source_state.service_class(bins, **features)
            exact_classes += 1
        target_checks = sum(v['adapter_int_id'] == aid for v in graph['host_tensor_views'])
        rows.append(dict(snapshot=index, adapter_int_id=aid, tier=source_state.tier,
            registered_adapters=len(full.registered_cpu_adapter_ids),
            full_tensor_checks=full_tensor_checks, target_tensor_checks=target_checks,
            check_reduction_fraction=(full_tensor_checks-target_checks)/full_tensor_checks,
            target_reachable_bytes=capacity,
            full_exclusive_bytes=adapter['exclusive_storage_bytes'],
            exact_target_footprint_class_and_all_identities_equal=True))

result = dict(kind='d180_request_scoped_footprint_dependency_study_v1', parent_commit=PARENT,
    protected_artifacts=protected, metric_protocol_sha256=metric_sha,
    torch_version=str(torch.__version__), source=str(source), source_sha256=source_sha,
    cases=cases, rejections=rejections, retained_snapshot_targets=rows,
    service_class_comparisons=exact_classes,
    validation_scope_difference=dict(unrelated_malformed_tensor_global_rejects=unrelated_full_rejects,
        target_observation_does_not_check_it=True, global_validation_equivalence_claim=False),
    production_code_changed=False, cuda_executed=False, end_to_end_performance_measured=False,
    caveat='Deterministic dependency/work-count study, not RPC latency, global memory safety qualification, or model acceptance.')
assert not torch.cuda.is_initialized()
with (RAW/'probe1.json').open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
with (RAW/'probe1.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps(dict(status='PASS', cases=len(cases), negative_cases=len(rejections),
    saved_targets=len(rows), service_class_comparisons=exact_classes,
    source_sha256=source_sha, validation_scope_difference=result['validation_scope_difference']), indent=2))
