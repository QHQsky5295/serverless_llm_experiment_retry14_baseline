"""Existing D140 resource audit adapted to pre-request diagnostic failure."""
import hashlib
import json
from pathlib import Path
import subprocess
from scripts.ieee_tc_preflight import digest, verify_seal

root=Path.cwd()
raw=root/'results/ieee_tc/p2_backend_qualification/d142_20261001'
e=raw/'7b_full_w0_prefix1/launch.launch'
launch=json.loads((e.parent/'launch.json').read_text())
assert launch['service_returncode']==139 and not launch['pass']
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert 'Command terminated by signal 11' in (raw/'controller_prefix1_time.txt').read_text()
replay=[json.loads(line) for line in (e/'replay.jsonl').read_text().splitlines()]
terminal=[r for r in replay if r['event']=='replay_incomplete']
assert len(terminal)==1 and terminal[0]['N_plan']==1000
assert terminal[0]['N_arrived']==terminal[0]['N_submitted']==0
assert not (e/'physical_deployment/summary.json').exists()
resources = dict(samples=0, peak_bytes=0, min_host_available_bytes=2**63,
                 events={}, max_swap_bytes=0, warnings=0, abort_reasons=[])
for line in (e / 'watchdog.jsonl').open():
    r = json.loads(line)
    if r['event'] != 'resource_sample':
        continue
    resources['samples'] += 1
    resources['warnings'] += r['decision']['warning']
    resources['abort_reasons'].extend(r['decision']['abort_reasons'])
    resources['peak_bytes'] = max(resources['peak_bytes'], r['service']['memory.peak'])
    resources['min_host_available_bytes'] = min(resources['min_host_available_bytes'], r['host']['available_bytes'])
    resources['max_swap_bytes'] = max(resources['max_swap_bytes'], r['service']['memory.swap.current'])
    for k in ('high', 'max', 'oom', 'oom_kill'):
        resources['events'][k] = max(resources['events'].get(k, 0), r['service']['memory.events'].get(k, 0))

assert resources['samples']==7 and not any(resources['events'].values())
assert not resources['warnings'] and not resources['abort_reasons']
for line in (e/'watchdog.jsonl').open():
    row=json.loads(line)
    gpu=row.get('gpu',row.get('gpu_initial'))
    if gpu is not None:
        assert not gpu['service_held_gpu_uuids'] and gpu['service_native_contexts_clear']
disabled=(raw/'import_probe2_0.log').read_text()
enabled=(raw/'import_probe2_1.log').read_text()
assert 'IMPORT_COMPLETE' in disabled and 'exited normally' in disabled
assert 'received signal SIGSEGV' in enabled and 'faulthandler_thread' in enabled
assert 'PyCode_Addr2Line (co=0x0' in enabled and 'IMPORT_COMPLETE' not in enabled
for flag in ('0','1'):
    assert 'GLIBCXX_3.4.30' in (raw/f'import_probe_{flag}.log').read_text()
    assert 'IMPORT_START' not in (raw/f'import_probe_{flag}.log').read_text()
units=['primelora-tc-svc-3fb290a6fbed48d2860141e5431fb32c.scope',
       'primelora-tc-aux-dae5ca5ee82149f3bdc7ad0e7c26d644.scope',
       'primelora-d142-import-probe-20261001.scope','primelora-d142-import-probe2-20261001.scope']
for unit in units:
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
cleanup={}
for name in ('prelaunch','health','prefix1_aux','import','import2','qualification'):
    path=raw/f'{name}_cleanup.txt'
    rows=path.read_text().splitlines()
    events={r.split()[0]:int(r.split()[1]) for r in rows
        if r.startswith(('low ','high ','max ','oom ','oom_kill ','oom_group_kill '))}
    assert len(events)==6 and not any(events.values())
    assert 'TasksCurrent=0' in rows
    cleanup[name]=dict(sha256=digest(path),memory_events=events)
pre=json.loads((raw/'prelaunch_verification.json').read_text())
restored={'faaslora/__init__.py','faaslora/utils/logger.py'}
removed={'tests/test_ieee_tc_stack_diagnostic.py'}
for name,expected in pre['source_sha256'].items():
    p=Path(name) if name.startswith('/') else root/name
    rel=str(p.relative_to(root)) if p.is_relative_to(root) else None
    if rel in restored|removed:
        archived=subprocess.check_output(['git','show','f5f62c2c9fe0f2b1daa19b32134cd69300177065:'+rel])
        assert hashlib.sha256(archived).hexdigest()==expected
        if rel in restored:
            assert p.read_bytes()==subprocess.check_output(['git','show','d12075c6cf283204b7d7023cd4598872c664d981:'+rel])
        else:
            assert not p.exists()
    else:
        assert digest(p)==expected,name
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
result=dict(kind='d142_rejected_stack_observer_v1',formal_performance_result=False,
    decision='withdraw observer; restore exact pre-diagnostic serving files',
    experiment=dict(N_plan=1000,source_workload_count=4000,N_arrived=0,N_submitted=0,
        N_terminal=0,N_correct=None,gpu_seconds=None,service_returncode=139,
        sampled_gpu_contexts_present=False,complete_performance_data=False),
    resources=resources,cleanup=cleanup,prelaunch_ref_count=len(pre['source_sha256']),
    protected=protected,
    causal_probe=dict(disabled='imports completed normally',enabled='SIGSEGV in faulthandler_thread -> PyCode_Addr2Line(co=NULL)',
        interpreter='Anaconda CPython3.12.12',gpu_models_loaded=False,
        first_attempt='debugger GLIBCXX load failure before either inferior started',
        corrected_debugger='clean debugger LD_LIBRARY_PATH only; original path restored for inferior',
        repeated_gpu_replays=0,upstream_issue_equivalence_proven=False),
    diagnostic_quality_qualified=False,
    remote=dict(monitor_sha256=digest(raw/'remote_monitor_prefix1_final.log'),
        services_stopped=True,packing_path_changed=False,cache_rebuilt=False,
        transfer_journal_with_health_clock_found=False),
    restored_source_sha256={p:digest(root/p) for p in restored},
    qualification_checkpoint='f5f62c2c9fe0f2b1daa19b32134cd69300177065',
    performance_gate='both models still open; ordinary Full and SLO/numeric qualification pending')
out=root/'paper_results/ieee_tc/p2_backend/20261001_d142_diagnostic_failure.json'
with out.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(out),sha256=digest(out),resource=resources,protected=147,restored=True)))
