"""D123 diagnostic interface, D137 configuration, current backed serving code."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight
from faaslora.runtime_configuration import resolve_facade_lora_capacity
from faaslora.datasets.workload_generator import FrozenReplayPlan

root=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw=root/'results/ieee_tc/p2_backend_qualification/d142_20261001'
previous=root/'results/ieee_tc/p2_backend_qualification/d137_20261001'
expected_commit='f5f62c2c9fe0f2b1daa19b32134cd69300177065'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==expected_commit
dirty=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty)<={'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'},dirty
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))=='fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old,new=[yaml.safe_load(p.read_text()) for p in
         (previous/'7b_main_config_full1.yaml',raw/'7b_main_config_prefix1.yaml')]
assert old['workload']['total_requests']==4000 and new['workload']['total_requests']==1000
for config in (old,new):
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
    del config['workload']['total_requests']
assert old==new,'configuration differs beyond prefix count and three fresh paths'
assert not (raw/'7b_full_w0_prefix1/launch.json').exists()
assert not (raw/'7b_nvme_prefix1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d142-7b-prefix1/tc_ieee_full').exists()
# Reuse the previous frozen map; refresh only reviewed, committed D141/D142 files.
prior=root/'results/ieee_tc/p2_backend_qualification/d140_20261001/prelaunch_verification.json'
assert digest(prior)=='0ff53fab1178d053685101e2a0888182002e581fe069c2e01b8f536df6af613d'
refs=dict(json.loads(prior.read_text())['source_sha256'])
changed={'faaslora/preloading/preloading_planner.py','faaslora/memory/residency_manager.py',
         'tests/test_ieee_tc_transfer_pressure.py','faaslora/__init__.py','faaslora/utils/logger.py',
         'tests/test_ieee_tc_stack_diagnostic.py'}
for name,expected in tuple(refs.items()):
    path=Path(name) if name.startswith('/') else root/name
    local=str(path.relative_to(root)) if path.is_relative_to(root) else None
    if local in changed:
        expected=hashlib.sha256(subprocess.check_output(['git','show',expected_commit+':'+local],cwd=root)).hexdigest()
        refs[name]=expected
    assert digest(path)==expected,name
for name in changed:
    expected=hashlib.sha256(subprocess.check_output(['git','show',expected_commit+':'+name],cwd=root)).hexdigest()
    assert digest(root/name)==expected,name
    refs[name]=expected
assert 'Ran 335 tests in 75.091s\n\nOK\n' in (raw/'test.log').read_text()
subprocess.run(['sha256sum','-c',str(raw/'test_sources.sha256')],check=True,cwd=root)
interface=root/'paper_results/ieee_tc/p2_backend/20260930_d122_diagnostic_prefix'
assert digest(interface/'verification.json')=='f266677bbdf57a667de6857a34f57c678e8c17ccfecff5ba5f28ee0303ab51d0'
assert digest(interface/'summary.json')=='57f55221ffc0b81da08de2eb50280e571a8d4ade0f9383597fcecf4b63c996c2'
context=json.loads((interface/'summary.json').read_text())['next_diagnostic_input']
plan=FrozenReplayPlan.from_launch_context(context)
before=json.loads((previous/'prelaunch_verification.json').read_text())
assert len(plan.entries)==1000 and plan.source_count==4000 and plan.profile=='W0'
assert plan.source_sha256==before['trace']['source_sha256']
model=resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras']==24 and model['runtime_concurrency_cap']==2
assert model['max_num_seqs']==2 and model['max_loras']==4
for key in ('ieee_service_profile','ieee_preparation_profile'):
    binding=new['resource_coordination'][key]
    assert digest(Path(binding['path']))==binding['sha256']
for path in [raw/name for name in ('7b_main_config_prefix1.yaml','run_7b_full_w0_prefix1.sh',
    'profile_controller_python.sh','activate_services_prefix1.sh','check_health.sh',
    'verify_prefix1_prelaunch.py','prepare_prefix1.sh')]+[interface/'summary.json',interface/'verification.json',root/'faaslora/utils/logger.py',root/'faaslora/__init__.py',raw/'test_sources.sha256',raw/'test.log']:
    refs[str(path)]=digest(path)
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
resources=preflight([root,raw],32*1024**3)
assert resources['preflight_pass'],resources['issues']
receipt=dict(kind='d142_periodic_stack_prefix_prelaunch_v1',time_unix=time.time(),
    run='d142_7b_full_w0_prefix1',evidence_commit=expected_commit,runtime_source_commit=expected_commit,
    serving_policy_change=False,diagnostic_hook_opt_in=True,same_configuration_except_owned_paths_and_population=True,
    diagnostic_instrumentation=True,formal_performance_result=False,source_sha256=refs,
    protected=protected,resource_preflight=resources,trace=plan.identity(),subset=before['subset'],
    replay_scope='diagnostic_prefix_v1',diagnostic_prefix_count=1000,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    hypothesis='Current controller CPU work delays ready generation replies; distinguish controller/frontend/planner/native core samples before choosing optimization.',
    observer=dict(implementation='CPython3.12 faulthandler.dump_traceback_later',
        period_seconds=2.0,all_threads=True,includes_idle=True,immediate_per_dump_write=True,
        cpu_time_profile=False,collect_locals=False,native_extension_frames=False,
        missing_role_samples='report missing; do not infer zero cost'),
    comparison='Current-version diagnostic, not paired to obsolete D123 code or ordinary Full timing.',
    reused_initialization='D88/D89 and unchanged D137 7B parent config; no new profile/data/cache',
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),sha256=digest(raw/'prelaunch_verification.json'),
    protected=147,source_refs=len(refs),population=1000,source_count=4000,resource_pass=True,formal=False)))
