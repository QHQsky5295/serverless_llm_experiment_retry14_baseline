#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d142_20261001
unit=primelora-d142-import-probe2-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/import2_scope.txt"
sha256sum faaslora/__init__.py faaslora/utils/logger.py scripts/run_all_experiments.py > "$raw/import2_sources.sha256"
exec /usr/bin/time -v -o "$raw/import2_time.txt" /usr/bin/python3 "$raw/probe_import2.py" > "$raw/import2_pair.log" 2>&1
