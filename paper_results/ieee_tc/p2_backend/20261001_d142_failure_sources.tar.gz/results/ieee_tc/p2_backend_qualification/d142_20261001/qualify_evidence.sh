#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d142_20261001
unit=primelora-d142-qualification-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/qualification_scope.txt"
export PYTHONPATH=$PWD
exec /usr/bin/time -v -o "$raw/qualification_time.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/curate_qualification.py" > "$raw/qualification.log" 2>&1
