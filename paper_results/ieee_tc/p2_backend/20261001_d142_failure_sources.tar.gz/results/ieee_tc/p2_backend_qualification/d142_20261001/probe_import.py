"""One CPU-only import pair; simulated diagnostic receipt, no model/replay."""
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d142_20261001'
native = '/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python'
if len(sys.argv) == 3 and sys.argv[1] == '--worker':
    flag = sys.argv[2]
    assert flag in ('0','1') and os.environ['CUDA_VISIBLE_DEVICES'] == ''
    folder=raw/('import_probe_'+flag)
    folder.mkdir()
    group=next(r[3:] for r in Path('/proc/self/cgroup').read_text().splitlines() if r.startswith('0::'))
    with (folder/'receipt.json').open('x') as f:
        json.dump(dict(cpu_only_fixture=True,allow_exec=True,
            service_identity=dict(path='/sys/fs/cgroup'+group),
            external_replay=dict(replay_scope='diagnostic_prefix_v1',diagnostic_prefix_count=1000)),f)
    os.environ.update(FAASLORA_TC_STACK_SAMPLING=flag,FAASLORA_FORMAL_RUN='0',
        FAASLORA_TC_LAUNCH_RECEIPT=str(folder/'receipt.json'))
    sys.path.insert(0,str(root))
    print('IMPORT_START',flush=True)
    runpy.run_path(str(root/'scripts/run_all_experiments.py'),run_name='__import_only__')
    print('IMPORT_COMPLETE',flush=True)
else:
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',
        HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_NO_USAGE_STATS='1',
        FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY='uncached_background_v1',
        PYTORCH_ALLOC_CONF='pinned_max_cached_size_mb:0,pinned_use_background_threads:True')
    for flag in ('0','1'):
        with (raw/f'import_probe_{flag}.log').open('x') as out:
            result=subprocess.run(['/usr/bin/gdb','-nx','--batch','-ex','set pagination off',
                '-ex','set confirm off','-ex','run','-ex','thread apply all bt 15',
                '--args',native,str(Path(__file__).resolve()),'--worker',flag],
                env=env,stdout=out,stderr=subprocess.STDOUT,timeout=90)
        print(json.dumps(dict(flag=flag,gdb_returncode=result.returncode)),flush=True)
