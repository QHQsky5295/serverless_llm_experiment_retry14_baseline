"""D120: adapt D113 verification; retain failed attempt, no replay or reanalysis."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d120_20260930'
out = root/'paper_results/ieee_tc/p2_backend/20260930_d120_control_occupancy'
assert not (out/'verification.json').exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
unit = 'primelora-d120-occupancy2-20260930.scope'
fields = dict(line.split('=',1) for line in subprocess.check_output(
    ['systemctl','--user','show',unit,'-p','InvocationID','-p','ControlGroup','-p','TasksCurrent'],text=True).splitlines())
assert fields['InvocationID'] == 'fa7cf5cee2e543feb2ce7f0b820b2983' and fields['TasksCurrent'] == '0'
assert fields['ControlGroup'] == '/user.slice/user-1001.slice/user@1001.service/app.slice/'+unit
cg = Path('/sys/fs/cgroup'+fields['ControlGroup'])
assert not (cg/'cgroup.procs').read_text().strip()
assert 'populated 0' in (cg/'cgroup.events').read_text().splitlines()
events = dict(line.split() for line in (cg/'memory.events').read_text().splitlines())
assert all(events[k] == '0' for k in ('high','max','oom','oom_kill'))
subprocess.run(['systemctl','--user','stop',unit],check=True)
assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
before = json.loads((root/'results/ieee_tc/p2_backend_qualification/d119_20260930/prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    path = Path(name) if name.startswith('/') else root/name
    assert digest(path) == expected, name
summary = json.loads((out/'summary.json').read_text())
for ref in summary['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256'], ref['path']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert summary['population'] == dict(planned=4000,terminal=4000,native_success=2890,failed=1110)
assert summary['formal_performance_result'] is False
assert summary['phase_summaries']['gate_to_terminal']['max_concurrent_requests'] == 8
assert digest(out/'summary.json') == '26ea0ce8153066693e44118fb29a0fd701089dd5efde15520201e1cc96141e73'
refs = [out/p for p in ('summary.json','request_occupancy.csv','sampled_occupancy.csv','control_observations.csv')]
refs += [root/'scripts/analyze_control_path_overhead.py',root/'tests/test_ieee_tc_control_timeline.py',root/'docs/ieee_tc/D120_CONTROL_OCCUPANCY.md']
bundle_files = [raw/p for p in ('run_occupancy_audit.sh','run_occupancy_audit2.sh','scope_before.txt','scope_before2.txt',
    'audit_wrapper.log','audit_wrapper2.log','audit_time.txt','audit_time2.txt','analyzer_attempt1.py',
    'cleanup_inspect.sh','inspect_cleanup.log','cleanup_audit1.sh','audit1_cleanup.log','verify_and_close.py','verify.sh')]
bundle = out/'small_analysis_sources.tar.gz'
assert not bundle.exists()
with tarfile.open(bundle,'x:gz') as archive:
    for path in bundle_files:
        archive.add(path,arcname=path.name)
with tarfile.open(bundle,'r:gz') as archive:
    for path in bundle_files:
        assert hashlib.sha256(archive.extractfile(path.name).read()).hexdigest() == digest(path)
refs += [bundle]
receipt = dict(kind='d120_offline_evidence_verification_v1',formal_performance_result=False,
    production_source_commit=before['runtime_source_commit'],production_sources_checked=len(before['source_sha256']),
    protected=protected,closed_scopes=[dict(unit=unit,identity=fields,events=events,closed=True)],
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
with (out/'verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
with (out/'small_analysis_sources.sha256').open('x') as handle:
    handle.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(pass_checks=True,production_sources=receipt['production_sources_checked'],protected=147,
    bundle_members=len(bundle_files),verification_sha256=digest(out/'verification.json'))))
