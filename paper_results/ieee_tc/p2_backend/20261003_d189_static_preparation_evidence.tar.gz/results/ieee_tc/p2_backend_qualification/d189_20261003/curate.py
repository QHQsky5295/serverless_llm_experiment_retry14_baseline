"""D188 evidence delivery reused for D189 CPU qualification (no microbenchmark)."""
import ast
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT = Path.cwd()
RAW = ROOT/'results/ieee_tc/p2_backend_qualification/d189_20261003'
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX = '20261003_d189_static_preparation'
PARENT = '40e92a0301688046f428da258bebb48da3a19639'

def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()

def tree(path, old=False):
    data = subprocess.check_output(['git','show',PARENT+':'+path]) if old else (ROOT/path).read_bytes()
    return ast.parse(data, filename=path)

def stripped(node, class_name, methods, extra=(), imports=()):
    node = copy.deepcopy(node)
    node.body = [item for item in node.body if not (
        isinstance(item, (ast.ClassDef, ast.FunctionDef)) and item.name in extra) and not (
        isinstance(item, ast.ImportFrom) and item.module in imports)]
    cls = next(item for item in node.body if isinstance(item, ast.ClassDef) and item.name == class_name)
    cls.body = [item for item in cls.body if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
                or item.name not in methods]
    return ast.dump(node, include_attributes=False)

storage = 'faaslora/storage/http_artifact_store.py'
residency = 'faaslora/memory/residency_manager.py'
runner = 'scripts/run_all_experiments.py'
old, new = tree(storage, True), tree(storage)
storage_methods = ('__init__','configure_content_manifest','preparation_descriptions')
assert stripped(old, 'HttpArtifactStoreClient', storage_methods, imports=('collections.abc','dataclasses')) == stripped(
    new, 'HttpArtifactStoreClient', storage_methods,
    extra=('preparation_content_sha256','FrozenPreparationDescriptions'), imports=('collections.abc','dataclasses'))
old, new = tree(residency, True), tree(residency)
residency_methods = ('__init__','_expected_content','_static_preparation_targets','preparation_snapshot')
assert stripped(old, 'LocalSourceReferences', residency_methods, imports=('types',)) == stripped(
    new, 'LocalSourceReferences', residency_methods, imports=('types',))
old_digest = next(node for node in ast.walk(old) if isinstance(node, ast.FunctionDef) and node.name == '_expected_content')
new_digest = next(node for node in tree(storage).body if isinstance(node, ast.FunctionDef) and node.name == 'preparation_content_sha256')
# Only the old local import becomes the new helper's docstring; all validation,
# canonicalization and SHA construction statements are exactly the same AST.
assert ast.dump(ast.Module(body=old_digest.body[1:], type_ignores=[])) == ast.dump(
    ast.Module(body=new_digest.body[1:], type_ignores=[]))
old, new = tree(runner, True), tree(runner)
count = 0
for node in ast.walk(old):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in (
            '_add_ieee_dedicated_instance','_plan_ieee_preparation_for_slot'):
        for call in ast.walk(node):
            if isinstance(call, ast.Attribute) and call.attr == 'preparation_manifests':
                call.attr = 'preparation_descriptions'
                count += 1
assert count == 2 and ast.dump(old) == ast.dump(new)
changed = set(subprocess.check_output(['git','diff','--name-only',PARENT,'--','faaslora','scripts','configs/ieee_tc'],text=True).splitlines())
assert changed == {storage,residency,runner}

assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
rows = []
identities = {'tests1':'4c3ee4f9bb9846b098b5efebf6751e03',
              'regression1':'99774dd2cbce4ee08e5f5962b88cead3'}
members = []
for phase, identity in identities.items():
    unit = 'primelora-d189-'+phase+'-20261003.scope'
    for prop, value in (('LoadState','not-found'),('InvocationID',''),('ControlGroup','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == value
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    assert 'InvocationID='+identity in (RAW/(phase+'_scope.txt')).read_text()
    log = (RAW/(phase+'.log')).read_text()
    summary = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s\n\nOK$',log,re.M)
    assert len(summary) == 1
    count, elapsed = summary[0]
    timing = (RAW/(phase+'_time.txt')).read_text()
    assert 'Exit status: 0' in timing
    events = dict(line.split() for line in (RAW/(phase+'_memory_events.txt')).read_text().splitlines())
    assert all(int(v) == 0 for v in events.values())
    assert (RAW/(phase+'_swap.txt')).read_text().strip() == '0'
    for when in ('before','after'):
        encoded = (RAW/(phase+'_protected_'+when+'.json')).read_text()
        # Qualified CPU environment writes this single platform notice on
        # stdout before the preflight JSON. Reject any other prefix/trailer.
        prefix, payload = encoded.split('\n', 1)
        assert re.fullmatch(r'INFO \d{2}-\d{2} \d{2}:\d{2}:\d{2} \[__init__\.py:216\] Automatically detected platform cuda\.', prefix)
        checked = json.loads(payload)
        assert checked['pass'] and checked['entry_count'] == 147
    for line in (RAW/(phase+'_sources.sha256')).read_text().splitlines():
        digest, path = line.split('  ',1)
        assert sha(ROOT/path) == digest
    rows.append(dict(phase=phase,tests=int(count),status='PASS',test_body_seconds=float(elapsed),
        command_elapsed=re.search(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\): (\S+)',timing).group(1),
        max_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',timing).group(1)),
        invocation_id=identity,scope_absent=True,memory_events=events,swap_bytes=0))
    members.extend(RAW/(phase+suffix) for suffix in ('.log','_scope.txt','_time.txt','_memory_events.txt',
        '_swap.txt','_protected_before.json','_protected_after.json','_sources.sha256','_sources.tar.gz'))

protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert protected['plan_sha256'] == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
doc = ROOT/'docs/ieee_tc/D189_STATIC_PREPARATION_DESCRIPTIONS.md'
assert f"| 新增13项＋既有文件观察8项 | {rows[0]['tests']} | 全通过 | {rows[0]['test_body_seconds']:.3f} |" in doc.read_text()
assert f"| 完整既有请求/owner/规划/取消/退役回归 | {rows[1]['tests']} | 全通过 | {rows[1]['test_body_seconds']:.3f} |" in doc.read_text()
table = ['# D189 CPU qualification', '', 'No inference, performance claim or independent seed CI.', '',
         '| Check | Tests | Result | Body seconds | Command elapsed | Peak RSS KiB |',
         '|---|---:|---|---:|---|---:|']
for row in rows:
    table.append(f"| {row['phase']} | {row['tests']} | PASS | {row['test_body_seconds']:.3f} | {row['command_elapsed']} | {row['max_rss_kib']} |")
with (OUT/(PREFIX+'.csv')).open('x',newline='') as f:
    keys=('phase','tests','status','test_body_seconds','command_elapsed','max_rss_kib','invocation_id','scope_absent','swap_bytes')
    writer=csv.DictWriter(f,fieldnames=keys,lineterminator='\n')
    writer.writeheader()
    writer.writerows({k:row[k] for k in keys} for row in rows)
with (OUT/(PREFIX+'_table.md')).open('x') as f:
    f.write('\n'.join(table)+'\n')
members.extend(RAW/name for name in ('run_cpu.sh','curate.py','run_curate.sh','check_staged.py'))
members.extend(RAW/name for name in ('curate1_source.py','run_curate1_source.sh',
    'curate1.log','curate1_scope.txt','curate1_time.txt','curate1_memory_events.txt','curate1_swap.txt'))
members.extend((doc,ROOT/'tests/test_ieee_tc_static_preparation.py',ROOT/storage,ROOT/residency,ROOT/runner))
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret) > 16
def inspect(data,name):
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for member in archive.getmembers():
                assert member.isfile() and '..' not in Path(member.name).parts and not member.name.startswith('/')
                inspect(archive.extractfile(member).read(),member.name)
    if name.endswith('.py'):
        ast.parse(data,filename=name)
for path in members:
    inspect(path.read_bytes(),str(path))
    if path.suffix == '.sh':
        subprocess.run(['bash','-n',str(path)],check=True)
sources={str(p):sha(p) for p in members}
bundle=OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output, tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members:
        archive.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers()) == len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(str(path.relative_to(ROOT))).read()).hexdigest() == sources[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as f:
    f.write(sha(bundle)+'  '+bundle.name+'\n')
result=dict(kind='d189_static_preparation_qualification_v1',parent=PARENT,
    status='cpu_qualified_full_replay_pending',tests=rows,protected_after=protected,
    source_sha256=sources,scope_ast_check='PASS: two runner calls; only declared storage/owner methods',
    exact_content_digest_validation_ast=True,production_changed=True,gpu_execution=False,remote_operation=False,
    numeric_qualification=False,performance_accepted=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    table_sha256=sha(OUT/(PREFIX+'_table.md')),csv_sha256=sha(OUT/(PREFIX+'.csv')))
with (OUT/(PREFIX+'.json')).open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS',tests=[r['tests'] for r in rows],protected=147,
    curated_sha256=sha(OUT/(PREFIX+'.json')),evidence_bundle=result['evidence_bundle']),indent=2))
