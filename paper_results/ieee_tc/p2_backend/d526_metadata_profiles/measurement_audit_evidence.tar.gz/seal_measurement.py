"""Seal D526 measured observations before strict affected-profile export."""
import ast,hashlib,json,os,pathlib,re,subprocess,sys,tarfile
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline');sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d526_metadata_profiles'
own_identity=p.scope_identity(p.cg_path().name);own_group=pathlib.Path(own_identity['path'])
with (raw/'seal_identity.json').open('x') as f:json.dump(own_identity,f,indent=2)
assert (own_group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (own_group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],4*p.GIB);assert gate['preflight_pass'],gate['issues']
receipt=json.loads((raw/'analysis_receipt.json').read_text())
assert receipt['passed'] and not receipt['profile_exported']
offline=json.loads((raw/'offline_execution_receipt.json').read_text())
assert offline['passed'] and receipt['identity']==offline['identity']
closed=json.loads((raw/'analysis_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert closed['identity']==offline['identity'] and not pathlib.Path(closed['identity']['path']).exists()
run=json.loads((raw/'source1.json').read_text())
assert run['pass'] and run['stage']=='complete' and run['physical_allocation']['released']
assert len(run['requests'])==1669 and all(q['pass'] for q in run['requests'])
source_sha=p.digest(raw/'source1.json')
assert source_sha==json.loads((out/'measurement_summary1.json').read_text())['source_run_sha256']
coverage=json.loads((out/'coverage1.json').read_text())
control=json.loads((out/'control_interleave_audit1.json').read_text())
file_audit=json.loads((out/'file_demand_audit1.json').read_text())
assert file_audit['request_count']==1669 and file_audit['file_transactions']>0
assert receipt['profile_eligible']==(coverage['class_domain_covered'] and control['triggered'])
del run
token=pathlib.Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
paths=[raw/n for n in ('source1_launch.json','source_commit.txt','source1_launcher.log','launcher_identity.json',
    'remote_start.log','remote_stop.log','remote_stop.json','remote_health.json','remote_transfers.jsonl','remote_monitor.log',
    'local_cleanup.json','analysis1.log','analysis_tests1.log','collection1.log','analysis_receipt.json',
    'offline_execution_receipt.json','analysis_closure.json','start_closure.json',
    'analyze.py','run_analysis.py','collect_closure.py','start_remote.sh','stop_remote.sh',
    'check_remote_health_stdlib.py','capture_launcher.py','start.py','start_receipt.json','launch_gate.json',
    'seal_measurement.py','close.py')]
paths += [raw/'source1_launch.launch'/n for n in ('service.log','watchdog.jsonl')]
archive=out/'measurement_audit_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in paths:
        check(path.read_bytes())
        if path.suffix=='.py':ast.parse(path.read_bytes())
        tar.add(path,arcname=str(path.relative_to(raw)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for path in paths:assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw))).read()).hexdigest()==p.digest(path)
seal=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known=pathlib.Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['entry_count']==147 and seal['changed']==[str(known)]
assert p.digest(known)=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
execution=(raw/'source_commit.txt').read_text().strip()
assert execution=='6b22e02bfbc4a513e7e5ccf8b27715c2fcebe3cb'
prepared=ROOT/'paper_results/ieee_tc/p2_backend/d524_metadata_profiles'
inputs=[prepared/name for name in ('source_spec.json','development_contract.json','launch_config_binding.json')]
inputs.append(ROOT/'configs/ieee_tc/20261014_d524_7b_metadata_source.yaml')
for path in inputs:
    committed=subprocess.check_output(['git','show',execution+':'+str(path.relative_to(ROOT))],cwd=ROOT)
    assert hashlib.sha256(committed).hexdigest()==p.digest(path)
paths += inputs
metadata=json.loads((out/'metadata_publication_audit1.json').read_text())
assert metadata['installed'] and metadata['triggered'] and not metadata['numerical_correctness_qualified']
checkpoint=dict(passed=True,measurement_complete=True,profile_complete=receipt['profile_eligible'],
    full_qualified=False,source_execution_commit=execution,
    source_run=dict(path=str(raw/'source1.json'),sha256=source_sha,bytes=(raw/'source1.json').stat().st_size),
    raw_source_retained=True,archive_bytes=archive.stat().st_size,protection=seal,
    source_refs=[dict(path=str(path),sha256=p.digest(path)) for path in paths],
    plan_sha256=p.check_plan(),metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'))
with (out/'measurement_checkpoint.json').open('x') as f:
    json.dump(checkpoint,f,indent=2)
with (out/'measurement_outputs.sha256').open('x') as f:
    for name in ('coverage1.json','measurement_summary1.json','native_requests1.csv',
                 'control_interleave_audit1.json','file_demand_audit1.json','metadata_publication_audit1.json','measurement_audit_evidence.tar.gz','measurement_checkpoint.json'):
        f.write(p.digest(out/name)+'  '+name+'\n')
with (raw/'measurement_seal_receipt.json').open('x') as f:json.dump(dict(passed=True,identity=p.scope_identity(p.cg_path().name)),f,indent=2)
print(json.dumps(dict(passed=True,archive_bytes=archive.stat().st_size,profile_eligible=receipt['profile_eligible'],control_delta=control['delta'])),flush=True)
