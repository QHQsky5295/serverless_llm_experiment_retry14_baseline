"""D524 gated starter, retaining the qualified stdlib-only management client."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
previous=raw.parent/'d525_20261014'
pub=ROOT/'paper_results/ieee_tc/p2_backend/d525_native_integer_contract'
inputs=ROOT/'paper_results/ieee_tc/p2_backend/d524_metadata_profiles'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
def save(name,value):
    with (raw/name).open('x') as stream:json.dump(value,stream,indent=2)
save('start_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote=='6b22e02bfbc4a513e7e5ccf8b27715c2fcebe3cb'
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','scripts','faaslora','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
tested=json.loads((pub/'cpu_qualification.json').read_text())
assert tested['passed'] and tested['tests']==393 and not tested['cuda_initialized']
for name,sha in tested['sources'].items():assert p.digest(ROOT/name)==sha
checkpoint=json.loads((pub/'checkpoint.json').read_text())
assert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==checkpoint['runner_sha256']
for name in ('cpu','backup','backup2'):
    closed=json.loads((previous/(name+'_closure.json')).read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
receipt=json.loads((previous/'backup_receipt.json').read_text())
assert receipt['passed'] and receipt['head']==head
assert p.digest(pub/'checkpoint.json')==receipt['checkpoint_sha256']
prepared=json.loads((inputs/'prepare.json').read_text())
for item in prepared['source_refs']+[prepared['spec']]:
    path=Path(item['path'])
    # Old configuration source records remain unchanged; no old times are used.
    assert p.digest(path if path.is_absolute() else ROOT/path)==item['sha256']
assert prepared['waves']==135 and prepared['cases']==1669
assert p.digest(inputs/'source_spec.json')=='847182165fcbe44bf132dce1f67ee61c844371ef5cce6ff9ffdabffd5936a179'
old=json.loads((raw.parent/'d524_20261014/source1.json').read_text())
assert not old['pass'] and old['profile_workspaces_removed']
assert all(not Path(path).exists() for path in old['owned_profile_workspaces'].values())
gate=p.preflight([ROOT],8*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not (raw/'source1.json').exists() and not (raw/'source1_launch.json').exists()
assert subprocess.run(['tmux','has-session','-t','tc-d526-source'],stderr=subprocess.DEVNULL).returncode!=0
protected=p.verify_seal(raw.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
save('launch_gate.json',dict(passed=True,head=head,remote=remote,gate=gate,identity=identity,
    protected=protected,reused_input_spec=dict(path=str(inputs/'source_spec.json'),sha256=p.digest(inputs/'source_spec.json'))))
for name in ('start_remote.sh','stop_remote.sh'):
    subprocess.run(['bash','-n',str(raw/name)],check=True)
subprocess.run(['bash',str(raw/'start_remote.sh')],check=True)
subprocess.run([sys.executable,str(raw/'check_remote_health_stdlib.py')],cwd=ROOT,check=True)
subprocess.run(['tmux','new-session','-d','-s','tc-d526-source','-c',str(ROOT),
    'bash scripts/ieee_tc/run_d298_capacity_source.sh d526'],check=True)
save('start_receipt.json',dict(launched=True,head=head,remote=remote,tmux='tc-d526-source',identity=identity))
print(json.dumps(dict(launched=True,head=head,tmux='tc-d526-source')),flush=True)
