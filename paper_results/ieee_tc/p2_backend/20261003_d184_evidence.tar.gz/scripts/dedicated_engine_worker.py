#!/usr/bin/env python3
"""
Dedicated engine worker for scale-out.

This process must be launched as a fresh Python interpreter so the runtime's
CUDA-visible GPU set can be pinned before vLLM / torch initialize any CUDA
context.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
import warnings
from pathlib import Path
from typing import Any, Dict, Optional

# 抑制 Mistral tokenizer 反复打印的已知弃用提示；保留真正的 worker 异常输出。
warnings.filterwarnings(
    "ignore",
    message=r"`get_control_token` is deprecated\. Use `get_special_token` instead\.",
    category=FutureWarning,
    module=r"mistral_common\.tokens\.tokenizers\.tekken",
)
_mistral_warning_filter = "ignore::FutureWarning:mistral_common.tokens.tokenizers.tekken"
_pythonwarnings = os.environ.get("PYTHONWARNINGS", "").strip()
if _mistral_warning_filter not in _pythonwarnings.split(","):
    os.environ["PYTHONWARNINGS"] = (
        f"{_pythonwarnings},{_mistral_warning_filter}" if _pythonwarnings else _mistral_warning_filter
    )


def _write_ready(path: Path, payload: Dict[str, Any]) -> None:
    # The complete post-initialize configuration is larger than the old address
    # only reply. Publish it atomically so the parent cannot read a partial JSON.
    pending = path.with_name(path.name + '.pending')
    pending.write_text(json.dumps(payload), encoding="utf-8")
    pending.replace(path)


def _push_env_updates(updates: Dict[str, str]) -> Dict[str, Optional[str]]:
    previous: Dict[str, Optional[str]] = {}
    for key, value in updates.items():
        previous[key] = os.environ.get(key)
        os.environ[key] = value
    return previous


def _restore_env_updates(previous: Dict[str, Optional[str]]) -> None:
    for key, value in previous.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value


def _decode_prepared_request(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Preserve the parent canonical plan; never guard/truncate it a second time."""
    if '_prepared_request' not in kwargs:
        return kwargs
    from scripts.run_all_experiments import RequestExecutionPlan
    values = kwargs['_prepared_request']
    if (not isinstance(values, dict) or set(values) != {'prompt', 'input_tokens', 'max_tokens'}
            or not isinstance(values['prompt'], str)
            or any(type(values[key]) is not int or values[key] <= 0 for key in ('input_tokens', 'max_tokens'))
            or any(values[key] != kwargs.get(key) for key in values)):
        raise ValueError('prepared request identity differs across RPC boundary')
    return {**kwargs, '_prepared_request': RequestExecutionPlan(**values)}


async def _run_worker(payload_path: Path, ready_path: Path) -> None:
    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    repo_root = Path(payload["repo_root"]).resolve()
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))

    model_cfg = dict(payload["model_cfg"])
    policy = model_cfg.get('ieee_native_host_allocator_policy')
    marker = os.environ.get('FAASLORA_IEEE_NATIVE_HOST_ALLOCATOR_POLICY')
    if policy is not None or marker:
        setting = 'pinned_max_cached_size_mb:0'
        if policy == 'uncached_background_v1':
            setting += ',pinned_use_background_threads:True'
        if (policy not in ('uncached_v1', 'uncached_background_v1') or marker != policy
                or os.environ.get('PYTORCH_ALLOC_CONF') != setting
                or any(key in os.environ for key in ('PYTORCH_CUDA_ALLOC_CONF', 'PYTORCH_HIP_ALLOC_CONF'))):
            raise ValueError('native HOST allocator candidate must be configured before worker imports')
    cost_model = dict(payload["cost_model"])
    device_id = payload.get("device_id")
    tp = max(1, int(model_cfg.get("tensor_parallel_size", 1) or 1))

    if device_id is not None:
        model_cfg["device_id"] = int(device_id)

    # The parent process has already pinned this worker's exact CUDA-visible GPU
    # set before launching the child. Do not re-derive a second mask here.
    env_updates: Dict[str, str] = {}

    previous_env = _push_env_updates(env_updates)
    try:
        from scripts.run_all_experiments import (
            InferenceEngine,
            _build_local_tp_runtime_env_updates,
            _encode_rpc_frame,
            _RPC_FRAME_MAX_BYTES,
        )

        executor_backend = model_cfg.get("distributed_executor_backend")
        previous_env.update(
            _push_env_updates(
                _build_local_tp_runtime_env_updates(
                    tp=tp,
                    executor_backend=str(executor_backend) if executor_backend is not None else None,
                )
            )
        )

        engine = InferenceEngine(model_cfg, cost_model)
        stop_event = asyncio.Event()

        async def _handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
            rpc = {}
            try:
                while True:
                    response: Dict[str, Any]
                    line = await reader.readline()
                    if not line:
                        break
                    rpc = json.loads(line.decode("utf-8"))
                    cmd = rpc.get("cmd")
                    kwargs = rpc.get("kwargs", {}) or {}
                    try:
                        worker_rpc_queue_ms = max(
                            0.0,
                            (time.time() - float(rpc.get("client_send_wall_time", time.time()))) * 1000.0,
                        )
                    except Exception:
                        worker_rpc_queue_ms = 0.0
                    if cmd == "generate":
                        progress_id = rpc.get('native_event_rpc_id')
                        if progress_id is not None:
                            if not isinstance(progress_id, str) or not progress_id:
                                raise ValueError('invalid service progress RPC identity')
                            def publish_progress(event):
                                # Exactly two bounded frames per successful request;
                                # write immediately, not after full generation.
                                writer.write(_encode_rpc_frame({'native_event_rpc_id': progress_id,
                                    'native_event': event}))
                            kwargs['native_event_observer'] = publish_progress
                        started_at = time.perf_counter()
                        generate_started_wall_time = time.time()
                        generate_ret = await engine.generate(**_decode_prepared_request(kwargs))
                        worker_wall_ms = max(0.0, (time.perf_counter() - started_at) * 1000.0)
                        worker_response_ready_wall_time = time.time()
                        if isinstance(generate_ret, tuple) and len(generate_ret) == 4:
                            ttft_ms, tpot_ms, out_tokens, timing = generate_ret
                        else:
                            ttft_ms, tpot_ms, out_tokens = generate_ret
                            timing = dict(getattr(engine, "last_timing", {}) or {})
                        timing.setdefault("worker_wall_e2e_ms", worker_wall_ms)
                        timing["worker_rpc_handler_wall_ms"] = worker_wall_ms
                        timing["worker_rpc_queue_ms"] = worker_rpc_queue_ms
                        timing["worker_generate_started_wall_time"] = generate_started_wall_time
                        timing["worker_response_ready_wall_time"] = worker_response_ready_wall_time
                        response = {
                            "ok": True,
                            "result": {
                                "ttft_ms": ttft_ms,
                                "tpot_ms": tpot_ms,
                                "output_tokens": out_tokens,
                                "timing": timing,
                            },
                        }
                    elif cmd == "load_lora_to_gpu_and_measure":
                        load_ms, ok = await engine.load_lora_to_gpu_and_measure(**kwargs)
                        response = {"ok": True, "result": {"load_ms": load_ms, "ok": ok}}
                    elif cmd == "ieee_worker_observation":
                        result = await engine.ieee_worker_observation(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == "ieee_scheduler_observation":
                        result = await engine.ieee_scheduler_observation(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == "ieee_prepare_host":
                        result = await engine.ieee_prepare_host(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == "ieee_transfer_event":
                        result = await engine.ieee_transfer_event(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == "ieee_register_pending":
                        result = await engine.ieee_register_pending(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == "ieee_register_pending_gpu_reference":
                        result = await engine.ieee_register_pending_gpu_reference(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == "ieee_close_pending":
                        result = await engine.ieee_close_pending(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == 'ieee_retire_generation':
                        result = await engine.ieee_retire_generation(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == 'ieee_generation_observation':
                        result = await engine.ieee_generation_observation()
                        response = {"ok": True, "result": result}
                    elif cmd == 'ieee_routing_sources':
                        result = await engine.ieee_routing_sources()
                        response = {"ok": True, "result": result}
                    elif cmd == 'ieee_request_sources':
                        result = await engine.ieee_request_sources(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == 'ieee_source_identities':
                        result = await engine.ieee_source_identities()
                        response = {"ok": True, "result": result}
                    elif cmd == "ieee_gpu_reference":
                        result = await engine.ieee_gpu_reference(**kwargs)
                        response = {"ok": True, "result": result}
                    elif cmd == "unload_lora_adapter":
                        result = await engine.unload_lora_adapter(**kwargs)
                        response = {"ok": True, "result": {"unloaded": result}}
                    elif cmd == "shutdown":
                        response = {"ok": True}
                        stop_event.set()
                    else:
                        response = {"ok": False, "error": f"unknown_cmd:{cmd}"}
                    if 'native_event_rpc_id' in rpc:
                        response['native_event_rpc_id'] = rpc['native_event_rpc_id']
                    writer.write(_encode_rpc_frame(response))
                    await writer.drain()
                    if cmd == "shutdown":
                        break
            except Exception as exc:  # pragma: no cover - exercised via parent integration
                try:
                    response = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
                    if 'native_event_rpc_id' in rpc:
                        response['native_event_rpc_id'] = rpc['native_event_rpc_id']
                    writer.write(_encode_rpc_frame(response))
                    await writer.drain()
                except Exception:
                    pass
            finally:
                writer.close()
                try:
                    await writer.wait_closed()
                except Exception:
                    pass

        try:
            await engine.initialize()
            server = await asyncio.start_server(_handle_client, host="127.0.0.1", port=0,
                                                limit=_RPC_FRAME_MAX_BYTES)
            sock = server.sockets[0]
            host, port = sock.getsockname()[:2]
            _write_ready(ready_path, {"status": "ready", "host": host, "port": int(port),
                "configuration_contract": "initialized_model_config_v1",
                "model_config": engine.model_cfg})
            async with server:
                await stop_event.wait()
        finally:
            try:
                await engine.shutdown()
            except Exception:
                pass
    finally:
        _restore_env_updates(previous_env)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--payload", required=True)
    parser.add_argument("--ready-file", required=True)
    args = parser.parse_args()

    payload_path = Path(args.payload).resolve()
    ready_path = Path(args.ready_file).resolve()

    try:
        asyncio.run(_run_worker(payload_path, ready_path))
    except Exception as exc:
        try:
            _write_ready(ready_path, {"status": "error", "error": f"{type(exc).__name__}: {exc}"})
        except Exception:
            pass
        raise


if __name__ == "__main__":
    main()
