"""D181 evidence/seal workflow reused for D184's two serving-file boundary."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal

RAW = Path(__file__).parent.resolve()
OUT = ROOT / 'paper_results/ieee_tc/p2_backend'
BASE = '99ea14a6e035ca1116cde3e04eedfac35d54e744'
PLAN = '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
V1 = '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
assert check_plan() == PLAN and digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == V1
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
serving = {
    'scripts/run_all_experiments.py': ({'SubprocessInferenceEngineProxy._rpc',
        'ScenarioRunner._acquire_runtime_gpu_reference', 'ScenarioRunner._register_ieee_pending_admission',
        'ScenarioRunner._ieee_protect_selected_source', 'ScenarioRunner._exec_request_in_reservation'},
        {'InferenceEngine.ieee_register_pending_gpu_reference',
         'SubprocessInferenceEngineProxy.ieee_register_pending_gpu_reference'}),
    'scripts/dedicated_engine_worker.py': ({'_run_worker'}, set()),
}
class Functions(ast.NodeVisitor):
    def __init__(self): self.prefix = []; self.found = {}
    def visit_ClassDef(self, node):
        self.prefix.append(node.name); self.generic_visit(node); self.prefix.pop()
    def visit_FunctionDef(self, node): self.found['.'.join(self.prefix+[node.name])] = node
    visit_AsyncFunctionDef = visit_FunctionDef
for rel, (changed, added) in serving.items():
    before = ast.parse(subprocess.check_output(['git', 'show', BASE+':'+rel], cwd=ROOT, text=True))
    after = ast.parse((ROOT/rel).read_text())
    old, new = Functions(), Functions(); old.visit(before); new.visit(after)
    assert set(new.found)-set(old.found) == added and not set(old.found)-set(new.found), rel
    actual = {name for name in old.found if ast.dump(old.found[name]) != ast.dump(new.found[name])}
    assert actual == changed, (rel, actual, changed)
    class Restore(ast.NodeTransformer):
        def __init__(self): self.prefix = []
        def visit_ClassDef(self, node):
            self.prefix.append(node.name); self.generic_visit(node); self.prefix.pop(); return node
        def visit_FunctionDef(self, node):
            key = '.'.join(self.prefix+[node.name])
            if key in added: return None
            return old.found[key] if key in changed else node
        visit_AsyncFunctionDef = visit_FunctionDef
    assert ast.dump(before) == ast.dump(Restore().visit(after)), rel
unchanged = ['faaslora/memory/gpu_monitor.py', 'faaslora/memory/residency_manager.py',
    'faaslora/experiment/instance_pool.py', 'faaslora/preloading/preloading_planner.py',
    'faaslora/preloading/planning_cpu.py', 'faaslora/scheduling/resource_coordinator.py',
    'faaslora/scheduling/vllm_ieee_frontend.py']
for rel in unchanged:
    assert (ROOT/rel).read_bytes() == subprocess.check_output(['git', 'show', BASE+':'+rel], cwd=ROOT)
rows, cleanup = [], []
for phase, count in (('tests1', 103), ('regression1', 1005)):
    log = (RAW/f'{phase}.log').read_text()
    match = re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK\s*$', log)
    assert match and int(match[1]) == count, phase
    with tarfile.open(RAW/f'{phase}_sources.tar.gz', 'r:gz') as archive:
        for line in (RAW/f'{phase}_sources.sha256').read_text().splitlines():
            sha, path = line.split(maxsplit=1)
            assert hashlib.sha256(archive.extractfile(path).read()).hexdigest() == sha, (phase, path)
            if phase == 'regression1' or path != 'tests/test_ieee_tc_pending_gpu_pipeline.py':
                assert digest(ROOT/path) == sha, (phase, path)
    identity = re.search(r'^InvocationID=([a-f0-9]{32})$', (RAW/f'{phase}_scope.txt').read_text(), re.M)[1]
    group = re.search(r'^ControlGroup=(.+)$', (RAW/f'{phase}_scope.txt').read_text(), re.M)[1]
    state = subprocess.check_output(['systemctl', '--user', 'show', f'primelora-d184-{phase}-20261003.scope',
        '-p', 'ActiveState', '-p', 'InvocationID', '-p', 'ControlGroup'], text=True)
    assert state.splitlines() == ['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert not Path('/sys/fs/cgroup'+group).exists()
    assert all(int(line.split()[1]) == 0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text()) == 0
    assert 'Exit status: 0' in (RAW/f'{phase}_time.txt').read_text()
    rows.append(dict(phase=phase, tests=count, errors=0, status='pass', elapsed_test_s=float(match[2])))
    cleanup.append(dict(phase=phase, actual_invocation_id=identity, returncode=0,
        cleanup='automatic_removal_verified', final_memory_events_zero=True, final_swap_zero=True))
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
doc = ROOT/'docs/ieee_tc/D184_PENDING_GPU_PIPELINE.md'
assert 'DRAFT' not in doc.read_text()
for row in rows:
    assert f"| {row['phase']} | {row['tests']} | 0 | pass |" in doc.read_text()
with (RAW/'cleanup_verified.json').open('x') as out: json.dump(cleanup, out, indent=2)
table = OUT/'20261003_d184_pending_gpu_pipeline.csv'
with table.open('x', newline='') as out:
    writer = csv.DictWriter(out, fieldnames=list(rows[0]), lineterminator='\n'); writer.writeheader(); writer.writerows(rows)
refs = [ROOT/p for p in serving] + [ROOT/'tests/test_ieee_tc_pending_gpu_pipeline.py', RAW/'run_cpu.sh', RAW/'verify.py']
curated = OUT/'20261003_d184_pending_gpu_pipeline.json'
with curated.open('x') as out:
    json.dump(dict(kind='ordered_pending_gpu_pipeline_qualification_v1', base_commit=BASE,
        metric_protocol_sha256=V1, plan_sha256=PLAN, rows=rows, cleanup=cleanup,
        source_sha256={str(p): digest(p) for p in refs}, new_test_methods=11,
        tests_regression=1005, tests_targeted_executions=103,
        targeted_repeated_imported_tests=36, test_counts_overlap=True,
        no_new_gpu_run=True, end_to_end_improvement_qualified=False, n_correct=None,
        formal_g1_g2_qualified=False, common_reference_frozen=False,
        table_sha256=digest(table), document_sha256=digest(doc)), out, indent=2)
verification = OUT/'20261003_d184_verification.json'
with verification.open('x') as out:
    json.dump(dict(passed=True, base_commit=BASE, non_target_serving_ast_unchanged=True,
        byte_identical_files=unchanged, protected=protected, cleanup=cleanup,
        curated_sha256=digest(curated), table_sha256=digest(table), document_sha256=digest(doc)), out, indent=2)
members = sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size < 2*1024**2
    and not p.name.startswith('verify1') and p.suffix != '.lock')
extras = [doc, curated, verification, table] + [ROOT/p for p in serving] + [ROOT/'tests/test_ieee_tc_pending_gpu_pipeline.py']
hashes = {}
bundle = OUT/'20261003_d184_evidence.tar.gz'
with tarfile.open(bundle, 'x:gz') as archive:
    for path in members+extras:
        name = 'raw/'+str(path.relative_to(RAW)) if path in members else str(path.relative_to(ROOT))
        hashes[name] = digest(path); archive.add(path, arcname=name, recursive=False)
with tarfile.open(bundle, 'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, sha in hashes.items(): assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == sha
with (OUT/'20261003_d184_evidence_members.json').open('x') as out:
    json.dump(dict(passed=True, member_sha256=hashes, source_raw_retained_and_bound=True), out, indent=2)
with (OUT/'20261003_d184_evidence.sha256').open('x') as out: out.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True, curated_sha256=digest(curated), bundle_sha256=digest(bundle),
    members=len(hashes), bundle_bytes=bundle.stat().st_size, cleanup=cleanup), indent=2))
