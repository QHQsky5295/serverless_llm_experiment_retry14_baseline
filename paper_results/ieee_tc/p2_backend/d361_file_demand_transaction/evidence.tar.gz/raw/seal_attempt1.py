"""D361 bounded checkpoint; reuse D360 sealing and exact scope cleanup rules."""
import ast
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
out=ROOT/'paper_results/ieee_tc/p2_backend/d361_file_demand_transaction'
gate=p.preflight([ROOT],4*p.GIB)
assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
out.mkdir(parents=True,exist_ok=False)
records={};closed=[]
for tag in ('cpu1','cpu2','native1','cpu3'):
    record=json.loads((raw/(tag+'_receipt.json')).read_text())
    assert record['passed'] is (tag!='cpu1')
    identity=record['identity'];group=Path(identity['path'])
    assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    cleanup=p.stop_scope_identity(identity)
    assert cleanup['released'] and not cleanup['hard_kill']
    closed.append(dict(tag=tag,identity=identity,resources=resources,cleanup=cleanup))
    records[tag]=record
with (raw/'test_cleanup.json').open('x') as f:json.dump(closed,f,indent=2)
for name,sha in records['cpu3']['sources'].items(): assert p.digest(ROOT/name)==sha,name
# Only a clarifying comment was added after native1. Preserve the exact
# executed native source too, and prove its digest rather than rebinding it.
comment=('        # A file-owner witness protects immutable input, not an old native\n'
         '        # residency/capacity decision. Directory identity was checked above;\n'
         '        # every native identity, pin and allocation check below uses live state\n'
         '        # in this same serialized turn. Without that witness, retain the strict\n'
         '        # historical epoch rule; no generic ignore-stale option is provided.\n')
native_payload={}
for name,sha in records['native1']['sources'].items():
    data=(ROOT/name).read_bytes()
    if name=='faaslora/memory/residency_manager.py':
        assert data.count(comment.encode())==1
        previous=data.replace(comment.encode(),b'')
        assert ast.dump(ast.parse(previous))==ast.dump(ast.parse(data))
        data=previous
    assert hashlib.sha256(data).hexdigest()==sha,name
    native_payload['native1/'+name]=data
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert protected['changed']==[known] and protected['entry_count']==147
assert p.digest(Path(known))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
with (raw/'protected.json').open('x') as f:json.dump(protected,f,indent=2)
paths=[raw/name for name in ('cpu1.log','cpu2.log','native1.log','cpu3.log',
    'cpu1_receipt.json','cpu2_receipt.json','native1_receipt.json','cpu3_receipt.json',
    'cpu1_sources.tar.gz','test_cleanup.json','test_candidate.py','seal_candidate.py','protected.json')]
paths += [ROOT/name for name in records['cpu3']['sources']]
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
payloads={str(x.relative_to(ROOT)):x.read_bytes() for x in paths} | native_payload
assert token and all(token not in data for data in payloads.values())
archive=out/'evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for name,data in payloads.items():
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644
        tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(payloads)
    for name,data in payloads.items(): assert tar.extractfile(name).read()==data
evidence=dict(kind='d361_protected_file_demand_candidate_v1',
    code_parent='c19a375b80baa69f74df534e4a9b41578b584e1a',
    cpu_tests=443,native_environment_cpu_tests=443,new_gpu_runs=0,no_figures=True,
    production_performance_qualified=False,formal_qualification=False,n_correct=None,
    first_test_failure='new fixture assumed adapter1 present; real fixture starts empty',
    native1_current_source_difference='clarifying comment only; exact source archived and AST-equal',
    archive_sha256=p.digest(archive),source_sha256=records['cpu3']['sources'],
    plan_sha256=p.check_plan(),protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    tests={tag:dict(passed=r['passed'],resources=r['after']) for tag,r in records.items()},
    exact_test_scope_cleanup=closed,protected=protected,
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in paths])
with (out/'evidence.json').open('x') as f:json.dump(evidence,f,indent=2)
with (out/'evidence.sha256').open('x') as f:
    for name in ('evidence.json','evidence.tar.gz'): f.write(p.digest(out/name)+'  '+name+'\n')
own=p.scope_identity(p.cg_path().name)
with (raw/'seal_scope.json').open('x') as f:
    json.dump(dict(identity=own,resources={k:(Path(own['path'])/k).read_text() for k in (
        'memory.peak','memory.events','memory.swap.current')}),f,indent=2)
print(json.dumps(dict(tests_closed=len(closed),archive_bytes=archive.stat().st_size,
    archive_members=len(payloads),cpu_tests=443,native_cpu_tests=443)))
