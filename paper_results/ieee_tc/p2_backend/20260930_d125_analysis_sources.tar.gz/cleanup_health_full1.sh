#!/usr/bin/env bash
set -euo pipefail
unit=primelora-d125-health-20260930.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = d0e91fb489bb48c08837a9e14d1ae8e4
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d125-health-20260930.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
grep -qx 'populated 0' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
