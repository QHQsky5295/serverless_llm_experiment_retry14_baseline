#!/usr/bin/env bash
set -euo pipefail
# Reuse D125 exact-identity / empty-domain cleanup; only D125 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-09bcef61bfa14b20bc099a54c88ea642.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-cb5a52372bb94bd3b012b0b3a2e68b5f.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 61fa7a7966244155b68ebc78d3191d7c
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-cb5a52372bb94bd3b012b0b3a2e68b5f.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
