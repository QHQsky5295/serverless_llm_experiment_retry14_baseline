"""Existing D118 curator adapted to unsuccessful D125, with D110 failure handling; run in a 4 GiB scope.

Read only the bounded jq streaming projection, never the full 11.51 GB JSON tree.
Keep failed requests and separate execution/measurement from qualification.
"""
import json
import math
import sys
from collections import Counter
from pathlib import Path
from statistics import mean

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.metrics.metrics_collector import NativeV1TokenTimeline

raw = ROOT/'results/ieee_tc/p2_backend_qualification/d125_20260930'
run = raw/'7b_full_w0_full1'
evidence = run/'launch.launch'
out = ROOT/'paper_results/ieee_tc/p2_backend/20260930_d125_7b_full_w0_full1.json'
projection = raw/'full_full1_request_projection.json'
original = raw/'7b_outputs_full1/experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d125_7b_full_w0_full1.json'
assert not out.exists()
load = lambda path: json.loads(path.read_text())
assert 'Exit status: 0' in (raw/'full_full1_projection_time.txt').read_text()
assert projection.stat().st_size < 256 * 1024**2
assert (evidence/'physical_deployment/main_outcome.json').stat().st_size == 79660115
assert original.stat().st_size == 11510552337
rows = load(projection)['requests']
outcome = load(evidence/'physical_deployment/main_outcome.json')
launch = load(run/'launch.json')
physical = load(evidence/'physical_deployment/summary.json')
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
good = [r for r in rows if r['success'] is True]
assert len(good) == 3456  # Observed terminal population, not a qualification requirement.
assert outcome['run_completed'] and outcome['error'] is None
assert not outcome['formal_comparison_qualified'] and not outcome['interrupted_replays']
assert outcome['cleanup']['complete'] and not outcome['cleanup_errors'] and not outcome['measurement_errors']
assert outcome['cleanup']['inventory_after']['allocated_file_bytes'] == 0
assert all(not Path(r['path']).exists() for r in outcome['cleanup']['roots'])
assert all(r['released'] for r in physical['allocation_journals'])
assert not physical['open_lease_ids'] and physical['measurement_complete']
assert not physical['eligible_correctness'] and physical['n_correct'] is None
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']

def jsonlines(path):
    with path.open() as handle:
        for line in handle:
            yield json.loads(line)

terminals = list(jsonlines(evidence/'physical_deployment/request_terminals.jsonl'))
replay = list(jsonlines(evidence/'replay.jsonl'))
ingress = list(jsonlines(evidence/'service_ingress.jsonl'))
submitted = [r for r in replay if r['event'] == 'request_submitted']
assert len(terminals) == len(submitted) == 4000
assert {r['request_id'] for r in rows} == {r['request_id'] for r in terminals} == {r['request_id'] for r in submitted}
by_request = {r['request_id']: r for r in rows}
assert all(r['success'] == by_request[r['request_id']]['success'] for r in terminals)
assert all(r['native_contract_matched'] for r in terminals if r['success'])
for t in terminals:
    if t['success']:
        r = by_request[t['request_id']]
        assert r['completion_tokens'] == t['target_tokens']
        assert r['completion_token_ids_sha256'] == t['completion_token_ids_sha256']
        assert r['canonical_prompt_sha256'] == t['canonical_prompt_sha256']

remote = list(jsonlines(raw/'remote_7b_full1_transfers.jsonl'))
transfers = outcome['remote_transfers']
assert len(remote) == len(transfers) > 0
by_uuid = {r['transfer_id']: r for r in remote}
assert len(by_uuid) == len(remote) and set(by_uuid) == {r['http_transfer_id'] for r in transfers}
for r in transfers:
    peer = by_uuid[r['http_transfer_id']]
    assert peer['artifact_id'] == r['artifact_id']
    assert not peer['pack_performed'] and not peer['temporary_created']
    if r['state'] == 'published':
        assert peer['bytes_written'] == r['transferred_bytes']
        assert r['content_verified'] and r['published_archive_verified']
        assert r['payload_bytes_verified'] == r['payload_bytes_expected']
    else:
        assert r['state'] == 'not_published' and r['content_verified'] is False
        assert 0 <= r['transferred_bytes'] <= peer['bytes_written']
        assert 'payload_bytes_verified' not in r or r['payload_bytes_verified'] is None
    assert peer['clock_id'] == 'remote-process-monotonic:50ebe91f58f548508f490ce027f2c8b0'
assert Counter(r['state'] for r in transfers) == Counter(published=128, not_published=1)

samples = 0
peak = swap = 0
available = float('inf')
events = Counter()
resource_warnings = 0
for r in jsonlines(evidence/'watchdog.jsonl'):
    if r['event'] != 'resource_sample':
        continue
    samples += 1
    resource_warnings += bool(r['decision']['warning'])
    assert not r['decision']['abort_reasons']
    peak = max(peak, r['service']['memory.peak'])
    swap = max(swap, r['service']['memory.swap.current'])
    available = min(available, r['host']['available_bytes'])
    for k in ('high', 'max', 'oom', 'oom_kill'):
        events[k] = max(events[k], r['service']['memory.events'].get(k, 0))

failures = Counter(r.get('failure_observation', {}).get('exception_type') or r.get('error') or 'unspecified_returned_failure'
                   for r in rows if not r['success'])
metrics = {}
for key in ('overall_ttft_ms', 'overall_e2e_ms', 'dispatch_admission_wait_ms',
            'runtime_slot_wait_ms', 'service_ttft_ms', 'vllm_ttft_ms',
            'pre_runtime_service_shell_ms', 'parent_rpc_overhead_ms', 'tpot_ms',
            'dispatch_window_wait_ms', 'arrival_release_lateness_ms', 'lora_io_ms',
            'parent_response_pickup_delay_ms', 'parent_thread_resume_delay_ms'):
    v = sorted(r[key] for r in good if isinstance(r.get(key), (int, float)) and math.isfinite(r[key]))
    metrics[key] = dict(n=len(v), mean=mean(v) if v else None,
                       p50_type1=v[math.ceil(.5*len(v))-1] if v else None,
                       p95_type1=v[math.ceil(.95*len(v))-1] if v else None,
                       p99_type1=v[math.ceil(.99*len(v))-1] if v else None)
deployment = load(evidence/'physical_deployment/deployment.json')
timing_errors = Counter()
timing_violations = []
native_stages = {k: [] for k in (
    'admission_to_engine_dispatch_ms', 'engine_entry_to_queue_ms',
    'native_engine_queue_ms', 'native_prefill_ms', 'native_decode_ms',
    'worker_completion_notification_ms', 'worker_to_controller_completion_ms')}
single_token = 0
confirmed_tiers = Counter()
for r in good:
    t = r['native_token_timing']
    assert r['generation_contract'] == 'fixed_length_greedy_v1'
    assert r['timing_contract'] == 'ieee_tc_native_v1'
    assert r['completion_token_source'] == 'vllm_token_ids'
    assert r['output_contract_match'] is True
    n = r['completion_tokens']
    assert n == r['output_tokens'] == r['requested_completion_tokens'] == t['native_output_tokens']
    check = NativeV1TokenTimeline.service_breakdown(t,
        admitted_at=t['controller_admitted_monotonic_s'],
        completed_at=t['controller_completed_monotonic_s'],
        clock_id=physical['clock_id'])
    ref = r['retained_reference_evidence']
    admission = ref['source_admission']
    assert ref['confirmed_dispatch_snapshot'] is True
    assert admission['kind'] == 'selected_source_admission_v1'
    assert admission['clock_id'] == physical['clock_id']
    assert 0 < admission['admitted_monotonic_s'] <= t['native_dispatch_monotonic_s']
    tier = r['readiness_tier_before_dispatch']
    assert tier in ('gpu', 'host', 'nvme', 'remote')
    assert admission['source']['tier'] == tier
    confirmed_tiers[tier] += 1
    arrival = deployment['arrival_start_s'] + r['scheduled_arrival_offset_s']
    errors = {
        'user_ttft_ms': abs(r['overall_ttft_ms'] - (t['native_first_token_monotonic_s']-arrival)*1000),
        'controller_result_e2e_ms': abs(r['overall_e2e_ms'] - (t['controller_completed_monotonic_s']-arrival)*1000),
        'dispatch_ms': abs(r['dispatch_admission_wait_ms'] - (t['controller_admitted_monotonic_s']-arrival)*1000),
        'service_decomposition_ms': abs(r['service_e2e_ms']-sum(check[k] for k in native_stages)),
        'dispatch_decomposition_ms': abs(r['dispatch_admission_wait_ms']-sum(r[k] for k in
            ('dispatch_window_wait_ms','runtime_slot_wait_ms','arrival_release_lateness_ms'))),
    }
    if n > 1:
        errors['tpot_ms'] = abs(r['tpot_ms'] - (t['native_last_token_monotonic_s']-t['native_first_token_monotonic_s'])*1000/(n-1))
    else:
        single_token += 1
        assert r['tpot_ms'] is None and t['native_tpot_ms'] is None
    for k, value in errors.items():
        assert math.isfinite(value), (r['request_id'], k, value)
        if value > 1.0:
            timing_violations.append(dict(request_id=r['request_id'], metric=k,
                error_ms=value, tolerance_ms=1.0, reference_arrival_s=arrival,
                scheduled_arrival_offset_s=r['scheduled_arrival_offset_s']))
        timing_errors[k] = max(timing_errors[k], value)
    for k in native_stages:
        native_stages[k].append(check[k])
native_metrics = {k: dict(n=len(v), mean=mean(v), p95_type1=sorted(v)[math.ceil(.95*len(v))-1],
                         p99_type1=sorted(v)[math.ceil(.99*len(v))-1])
                  for k,v in native_stages.items()}
retries = [r.get('prior_routing_attempt_count', 0) for r in good]
mechanisms = outcome['mechanism_events']
preliminary = load(raw/'full_full1_preliminary.json')
assert preliminary['population']['success'] == len(good)
quarantines = mechanisms['_ieee_runtime_quarantine_events']
assert len(quarantines) == 35 and all(r['state'] == 'released' for r in quarantines)
assert len({r['instance_id'] for r in quarantines}) == len(quarantines)
for r in quarantines:
    assert r['started_monotonic_s'] <= r['drained_monotonic_s'] <= r['released_monotonic_s']
quarantine_durations = sorted(r['released_monotonic_s']-r['started_monotonic_s'] for r in quarantines)
zero_ready = [r for r in mechanisms['_ieee_control_events']
              if r.get('ready_instances') == 0 and r.get('queue_depth', 0) > 0]
before = load(raw/'prelaunch_verification.json')
for name, expected in before['source_sha256'].items():
    path = Path(name) if name.startswith('/') else ROOT/name
    assert p.digest(path) == expected, name
assert physical['n_native_contract_complete'] == len(good) == 3456
assert math.isclose(sum(physical['window_gpu_seconds'].values()), physical['gpu_seconds'], abs_tol=1e-6)
assert len(good) == 3456 and sum(failures.values()) == 544
assert launch['service_returncode'] == launch['replay_returncode'] == launch['watchdog_returncode'] == 0
outer_ms, completion_gaps_ms = [], []
all_terminal_ms, failed_terminal_ms = [], []
for terminal in terminals:
    r = by_request[terminal['request_id']]
    arrival = deployment['arrival_start_s'] + r['scheduled_arrival_offset_s']
    terminal_ms = (terminal['at'] - arrival) * 1000
    assert terminal_ms >= 0
    all_terminal_ms.append(terminal_ms)
    if not terminal['success']:
        failed_terminal_ms.append(terminal_ms)
        continue
    controller = r['native_token_timing']['controller_completed_monotonic_s']
    assert terminal['at'] >= controller
    outer_ms.append((terminal['at'] - arrival) * 1000)
    completion_gaps_ms.append((terminal['at'] - controller) * 1000)
assert len(all_terminal_ms) == 4000 and len(failed_terminal_ms) == 544
assert len(outer_ms) == len(completion_gaps_ms) == len(good) == 3456
def summary_ms(values):
    v = sorted(values)
    return dict(n=len(v), mean=mean(v), p95_type1=v[math.ceil(.95*len(v))-1],
                p99_type1=v[math.ceil(.99*len(v))-1])
completion_boundaries = dict(controller_result='native_token_timing.controller_completed_monotonic_s',
    outer_terminal='request_terminals.jsonl:at after reservation/global admission release',
    client_response_observed=False,
    population_note='Controller/outer gap and internal E2E are success-only; all/failed terminal outcome fields are separately labeled, not successful service latency.',
    all_terminal_outcome_latency_ms=summary_ms(all_terminal_ms),
    failed_terminal_outcome_latency_ms=summary_ms(failed_terminal_ms),
    internal_outer_terminal_latency_ms=summary_ms(outer_ms),
    controller_to_outer_terminal_ms=summary_ms(completion_gaps_ms),
    caveat='Neither internal event is client response receipt; raw controller E2E unchanged.')
cancellation_records = {}
for key in ('_ieee_residency_epochs','_ieee_file_preparation_plans','_ieee_gpu_preparation_plans'):
    assert not any(r.get('state') == 'failed' for r in mechanisms[key]), key
    cancellation_records[key] = [
        dict(scalar_fields={k:v for k,v in r.items() if v is None or isinstance(v,(str,bool,int,float))},
             record_keys=sorted(r), non_scalar_keys=sorted(k for k,v in r.items()
                 if v is not None and not isinstance(v,(str,bool,int,float))))
        for r in mechanisms[key] if r.get('state') == 'cancelled']
    assert all(r['scalar_fields']['error_type'] == 'CancelledError'
               for r in cancellation_records[key]), key
last_terminal = max(r['at'] for r in terminals)
cancellation_timeline = [
    dict(target_replica=r['target_replica'], started_at=r['started_at'],
         terminal_at=r['terminal_at'], terminal_minus_last_request_s=r['terminal_at']-last_terminal)
    for r in mechanisms['_ieee_residency_epochs'] if r.get('state') == 'cancelled']
# Link the observed unpublished download to its physical I/O owner and demand
# subscriber. Do not infer a transport error or alter the failed population.
unpublished_evidence = []
contract = outcome['coordination_after_shutdown']['ieee_full_launch_contract']
assert contract['request_deadline_origin'] == 'planned_arrival'
for transfer in transfers:
    if transfer['state'] == 'published':
        continue
    pressure = [r for r in outcome['transfer_pressure']
        if r['adapter_id'] == transfer['artifact_id']
        and r['file_owner_id'] == transfer['local_source_owner_id']
        and r['source_tier'] == 'remote' and r['target_tier'] == 'nvme'
        and r.get('io_started_at', math.inf) <= transfer['loading_started_monotonic_s']
        and r.get('io_joined_at', -math.inf) >= transfer['client_completed_monotonic_s']]
    jobs = [r for r in outcome['coordination_after_shutdown']['ieee_movements']
        if r['key'][:3] == [transfer['local_source_owner_id'], 'nvme', transfer['artifact_id']]
        and r['created_at'] <= transfer['loading_started_monotonic_s'] <= r['finished_at']]
    assert len(pressure) == len(jobs) == 1
    pressure, job = pressure[0], jobs[0]
    assert pressure['clock_id'] == transfer['loading_clock_id'] == physical['clock_id']
    assert pressure['operation_outcome'] == job['state'] == 'cancelled'
    assert pressure['operation_error_type'] == 'CancelledError' and pressure['caller_cancelled']
    assert len(job['subscriptions']) == 1
    subscription = next(iter(job['subscriptions'].values()))
    assert subscription['metadata']['trigger_reason'] == 'demand'
    plan_id = subscription['metadata']['plan_id']
    assert plan_id.startswith('request:')
    request_id = plan_id.removeprefix('request:')
    request = by_request[request_id]
    assert not request['success']
    assert request['failure_observation']['exception_type'] == 'TimeoutError'
    arrival = deployment['arrival_start_s'] + request['scheduled_arrival_offset_s']
    deadline = arrival + contract['request_timeout_s']
    unpublished_evidence.append(dict(transfer=transfer, pressure=pressure, job=job,
        request_id=request_id, planned_arrival_s=arrival, protection_deadline_s=deadline,
        loading_start_after_arrival_s=transfer['loading_started_monotonic_s'] - arrival,
        withdrawal_after_deadline_ms=(subscription['withdrawn_at'] - deadline) * 1000,
        request_failure_observation=request['failure_observation'],
        interpretation='Demand job cancelled with sole subscriber returning TimeoutError; '
            'complete received archive, no content publication. This request only, not all timeout causes.'))
result = dict(kind='d125_completed_unsuccessful_canonical_full_v1', model='7b', workload='W0',
    execution_commit='e7d4c91aa4347f26a1f08672b54a5ad4b3228d78',
    full_qualified=False, native_contract_completion_pass=False, formal_performance_result=False, baselines='paused',
    diagnostic_instrumentation=False, frozen_source_refs_checked=len(before['source_sha256']),
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    population=dict(planned=4000, publisher_submitted=4000, runner_started=len(rows),
        terminal=len(terminals), success=len(good), native_contract_matched=len(good),
        failure_observations=dict(failures),
        replay_event_counts=dict(Counter(r['event'] for r in replay)),
        ingress_event_counts=dict(Counter(r['event'] for r in ingress))),
    execution_completed=outcome['run_completed'], qualification='failed_full_completion_numerical_adapter_and_formal_slo_pending',
    launcher_cleanup_pass=launch['pass'],
    cleanup=outcome['cleanup'] | dict(inventory_before=None, inventory_after=None),
    resources=dict(samples=samples, peak_bytes=peak, min_host_available_bytes=available,
                   max_events=dict(events), max_swap_bytes=swap, warning_samples=resource_warnings),
    physical=physical,
    observed_completion_boundaries=completion_boundaries,
    cancellation_records=cancellation_records,
    cancellation_timeline=cancellation_timeline,
    supersession_stages={k:dict(Counter(r.get('preparation_supersession',{}).get('stage')
        for r in mechanisms[k] if r.get('state')=='superseded')) for k in
        ('_ieee_residency_epochs','_ieee_file_preparation_plans','_ieee_gpu_preparation_plans')},
    source_observation_stats=mechanisms['_ieee_source_observation_stats'],
    zero_ready_with_queue=dict(events=len(zero_ready), first=zero_ready[0] if zero_ready else None,
        actions=dict(Counter(r['action'] for r in zero_ready)),
        outcomes=dict(Counter(r.get('outcome') for r in zero_ready))),
    selected_source_retries_on_success=dict(requests_with_retry=sum(x > 0 for x in retries),
        total=sum(retries), maximum=max(retries), note='Only retained retries of successful requests; not all failed snapshot attempts.'),
    mechanism_counts={k: dict(Counter(r.get('state', 'not_a_state_event') for r in v))
                      for k, v in mechanisms.items() if isinstance(v, list)},
    remote=dict(uuid_pairs=len(transfers), client_received_bytes=sum(r['transferred_bytes'] for r in transfers),
        server_socket_written_bytes=sum(r['bytes_written'] for r in remote),
        byte_mismatches=preliminary['remote']['byte_mismatches'],
        verified_published_logical_bytes=sum(r['payload_bytes_verified'] for r in transfers if r['state']=='published'),
        states=dict(Counter(r['state'] for r in transfers)),
        not_published=preliminary['remote']['not_published'], request_packing=0,
        unpublished_loading_records=[r for r in transfers if r['state'] != 'published'],
        unpublished_evidence=unpublished_evidence,
        unpublished_cause='demand_job_cancelled_with_sole_subscriber_timeout',
        server_journal='transfers-8566d2902a8b4a53b3d69c990de693ce.jsonl'),
    quarantine=dict(events=len(quarantines), released=len(quarantines),
        mean_isolation_to_release_s=mean(quarantine_durations) if quarantine_durations else None,
        p95_isolation_to_release_s=quarantine_durations[math.ceil(.95*len(quarantine_durations))-1] if quarantine_durations else None,
        first_four_runtime_successes=preliminary['first_four_runtime_successes'],
        first_four_activation_categories=preliminary['first_four_activation_categories'],
        replacement_successes=preliminary['replacement_successes'],
        replacement_successful_runtimes=preliminary['replacement_successful_runtimes']),
    conditional_success_latency_ms=metrics,
    native_stage_metrics_ms=native_metrics,
    timing_validation=dict(requests=len(good), single_token_requests=single_token,
        max_error_ms=dict(timing_errors), tolerance_ms=1.0, pass_tolerance=not timing_violations,
        violations=timing_violations, requests_over_tolerance=len({v['request_id'] for v in timing_violations}),
        contract='ieee_tc_native_v1', direct_planned_arrival_boundary=True),
    readiness_tier_counts=dict(Counter(r['readiness_tier_before_dispatch'] for r in good)),
    readiness_evidence=dict(confirmed_pre_generation_requests=sum(confirmed_tiers.values()),
        source_admission_tier_counts=dict(confirmed_tiers), conflicts=0,
        qualification='Selected-source identity/clock/order only; not a complete A4 epoch study or numerical adapter proof.'),
    conditional_latency_caveat='3456 native-contract successes only; 544 failures retained. Numerical adapter correctness and common warm SLO remain pending. No formal ranking or isolated cross-run causal estimate.',
    protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json'),
    next='Back up this complete diagnostic, then follow Prime-first mainline using measured phase evidence; baselines stay paused. No blind replay or formal SLO claim.')
assert result['protected']['pass']
refs = [raw/'prelaunch_verification.json', raw/'health_3b.json', raw/'health_7b.json',
    run/'launch.json', evidence/'physical_deployment/main_outcome.json',
    evidence/'physical_deployment/summary.json', evidence/'physical_deployment/request_terminals.jsonl',
    evidence/'physical_deployment/deployment.json', evidence/'watchdog.jsonl',
    evidence/'service_ingress.jsonl', evidence/'replay.jsonl', evidence/'service.log',
    raw/'7b_main_config_full1.yaml', raw/'run_7b_full_w0_full1.sh',
    raw/'remote_7b_full1_transfers.jsonl', raw/'remote_monitor_full1_final.log', raw/'remote_copy_receipt.txt',
    raw/'stop_services_full1.sh', raw/'stop_remote_after_full1.sh', raw/'stop_services_full1.log',
    raw/'cleanup_local_aux_full1.sh', raw/'cleanup_local_aux_full1.log',
    raw/'cleanup_metadata_full1.sh', raw/'metadata_cleanup_full1.log',
    Path(__file__), projection, raw/'project_full_full1.sh',
    ROOT/'results/ieee_tc/p2_backend_qualification/d96_20260928/project_full_attempt3.jq',
    raw/'full_full1_projection_time.txt', raw/'full_full1_projection_scope.txt',
    raw/'full_full1_preliminary.json', raw/'collect_full1_preliminary.py',
    raw/'inspect_full1_metadata.sh', raw/'full_full1_metadata.log',
    raw/'full_full1_metadata_scope.txt', raw/'full_full1_metadata_time.txt', original,
    ROOT/'scripts/run_all_experiments.py', ROOT/'faaslora/memory/residency_manager.py',
    ROOT/'faaslora/preloading/preloading_planner.py']
result['source_refs'] = [dict(path=str(path), sha256=p.digest(path)) for path in refs]
with out.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps(dict(output=str(out), sha256=p.digest(out), population=result['population'],
    resources=result['resources'], remote=result['remote'], stats=result['source_observation_stats'],
    retries=result['selected_source_retries_on_success'], conditional_metrics=metrics)))
