"""Reuse verified D595 exact-identity stop; never operate on unrelated scopes."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/stop_regression.py')
exec(compile(source.read_text(),str(source),'exec'))
