"""Reuse D549/D601 qualified CPU environment, modules isolated sequentially."""
from pathlib import Path
source = Path(__file__).resolve().parent/'run_tests.py'
body = source.read_text().replace('tests.test_ieee_tc_native_bridge', 'tests.test_ieee_tc_native_retirement')
marker = "exec(compile(code, str(source), 'exec'))"
assert body.count(marker) == 1
body = body.replace(marker, '''
code = code.replace("phase in ('focused','regression')", "phase in ('regression2',)")
old = """    result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)"""
assert code.count(old) == 1
code = code.replace(old, """    completed=[]
    for module_name in tests:
        invocation=[sys.executable,'-B','-m','unittest',module_name,'-v']
        log.write('Module: '+module_name+'\\n');log.flush()
        outcome=subprocess.run(invocation,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)
        completed.append(dict(command=invocation,returncode=outcome.returncode))
        if outcome.returncode:break
    from types import SimpleNamespace
    result=SimpleNamespace(returncode=max(abs(row['returncode']) for row in completed))
    command=completed""
)
exec(compile(code, str(source), 'exec'))
''')
exec(compile(body, str(source), 'exec'))
