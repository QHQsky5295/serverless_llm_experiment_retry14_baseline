"""Stop only this resource-pressured CPU test, preserving its actual outcome."""
import json,sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=json.loads((RAW/'regression_identity.json').read_text())
assert p.scope_still_owned(identity)
cg=Path(identity['path'])
before={k:(cg/k).read_text().strip() for k in ('memory.current','memory.peak','memory.events','memory.swap.current')}
record=dict(identity=identity,resources_before=before,host_before=p.host_sample(),
    reason='Bounded CPU regression has sustained memory.high pressure with auxiliary spawned workers; selected interpreter differs from prior qualified regression. Stop before OOM, preserve unresolved test outcome.',
    classification='cpu_test_environment_pressure_not_performance_result')
with (RAW/'regression_stop_before.json').open('x') as f:json.dump(record,f,indent=2)
closure=p.stop_scope_identity(identity,grace_seconds=10)
assert closure['released'] and not cg.exists()
record.update(passed=False,stop_completed=True,closure=closure,path_gone=True,
    log_sha256=p.digest(RAW/'regression.log'))
with (RAW/'regression_stopped.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(stop_completed=True,released=True,resources_before=before)))
