"""Reuse D605 explicit-path, verified-bundle backup for D606 qualified candidate."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d605_20261017/publish.py')
code=source.read_text()
def replace(old,new,count=1):
    global code
    assert code.count(old)==count,old
    code=code.replace(old,new)
replace("assert head=='161fa069e004ed54622dbc5922f72ee56f624f02'",
        "assert head=='161a246195bd9b46f9e396c8e7156de7f52250ab'")
start=code.index('for directory,name in (')
end=code.index('\nprotected=',start)
code=code[:start]+"""for name in ('focused','component','component2','bootstrap','regression2'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
result=read(RAW/'component_result2.json')
assert result['passed'] and not result['production_source_unchanged'] and not result['formal_performance']
assert p.digest(ROOT/'faaslora/memory/residency_manager.py')==result['candidate_source_sha256']
for phase in ('focused','regression2'):
    receipt=read(RAW/(phase+'_receipt.json'))
    assert receipt['passed']
    for path,sha in receipt['sources'].items():assert p.digest(Path(path))==sha,path
stopped=read(RAW/'regression_stopped.json')
assert stopped['stop_completed'] and stopped['closure']['released'] and stopped['path_gone']
assert not Path(stopped['identity']['path']).exists()
preserved=read(STORAGE/'prechecks.json')['preserved']
for path,sha in preserved.items():assert p.digest(Path(path))==sha
"""+code[end:]
start=code.index('groups=[')
end=code.index('\nfor directory,out,members in groups:',start)
code=code[:start]+"""groups=[(RAW,ROOT/'paper_results/ieee_tc/p2_backend/d606_canonical_file_observations',
    ['compare_inventory.py','compare_inventory2.py','run_tests.py','run_regression.py',
     'close.py','close2.py','publish.py','focused_identity.json','focused_gate.json',
     'focused_receipt.json','focused.log','focused_source.tar.gz','focused_closure.json',
     'component_identity.json','component.log','component_closure.json',
     'component_attempt1_failure.json','component2_identity.json','component2_closure.json',
     'component2.log','component_result2.json','regression_identity.json',
     'regression_gate.json','regression.log','regression_source.tar.gz',
     'stop_regression.py','regression_stop_before.json','regression_stopped.json',
     'run_regression_qualified.py','run_regression_qualified2.py',
     'bootstrap_failure.json','close_bootstrap_failure.py','bootstrap_identity.json',
     'bootstrap_closure.json','close_regression2.py','regression2_identity.json',
     'regression2_gate.json','regression2_receipt.json','regression2.log',
     'regression2_source.tar.gz','regression2_closure.json'])]
names=['faaslora/memory/residency_manager.py','tests/test_ieee_tc_file_observation.py',
       'tests/test_ieee_tc_static_preparation.py','tests/test_ieee_tc_request_lifecycle.py',
       'docs/ieee_tc/D606_CANONICAL_FRESH_FILE_OBSERVATIONS.md','docs/ieee_tc/EXECUTION_STATUS.md']
"""+code[end:]
replace("paths.append(RAW.parent.parent/'storage_maintenance/d592_20261017/close.py')", """paths.extend([
        RAW.parent.parent/'storage_maintenance/d592_20261017/close.py',
        RAW.parent/'d605_20261017/publish.py',
        RAW.parent/'d605_20261017/compare_inventory.py',
        RAW.parent/'d595_20261017/run_tests.py',
        RAW.parent/'d595_20261017/stop_regression.py'])""")
replace('production_serving_change=False,gpu_experiment=False',
        'production_serving_change=True,gpu_experiment=False')
start=code.index('    if directory==STORAGE:')
end=code.index("    save(out/'summary.json'",start)
code=code[:start]+"""    summary.update(component=result,first_attempt=read(RAW/'component_attempt1_failure.json'),
        focused=read(RAW/'focused_receipt.json'),regression=read(RAW/'regression2_receipt.json'),
        aborted_regression=stopped,bootstrap_failure=read(RAW/'bootstrap_failure.json'),
        decision='cpu_qualified_candidate_full_w2_replay_pending',
        metric_v1_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
        metric_single_run_v2_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
        plan_sha256=p.check_plan(),
        caveat='Closed metadata-tree/tiny-fixture component measurements, not GPU serving improvement.')
"""+code[end:]
replace('tc: preserve closed W2 evidence and bounded fresh-inventory prototype outcome (D604-D605)',
        'tc: qualify canonical per-call file observations with fresh capacity checks (D606)')
exec(compile(code,str(source),'exec'))
