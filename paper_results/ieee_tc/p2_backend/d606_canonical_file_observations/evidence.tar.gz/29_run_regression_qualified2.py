"""D595 runner reused; sequential module processes in the D549 CPU interpreter."""
from pathlib import Path
source=Path(__file__).resolve().parent/'run_tests.py'
body=source.read_text().replace('tests.test_ieee_tc_native_bridge', 'tests.test_ieee_tc_native_retirement')
marker="exec(compile(code, str(source), 'exec'))"
assert body.count(marker)==1
namespace={'__file__':str(Path(__file__)), '__name__':'__main__'}
exec(compile(body.replace(marker,''),str(source),'exec'),namespace)
code=namespace['code']
code=code.replace("phase in ('focused','regression')", "phase in ('regression2',)")
old="    result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)"
assert code.count(old)==1
new="""    completed=[]
    for module_name in tests:
        invocation=[sys.executable,'-B','-m','unittest',module_name,'-v']
        log.write('Module: '+module_name+'\\n');log.flush()
        outcome=subprocess.run(invocation,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)
        completed.append(dict(command=invocation,returncode=outcome.returncode))
        if outcome.returncode:break
    from types import SimpleNamespace
    result=SimpleNamespace(returncode=max(abs(row['returncode']) for row in completed))
    command=completed"""
code=code.replace(old,new)
exec(compile(code,str(namespace['source']),'exec'))
