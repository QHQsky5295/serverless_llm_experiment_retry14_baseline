"""Use existing regression runner; explicitly name the native-retirement module."""
from pathlib import Path
source = Path(__file__).resolve().parent/'run_tests.py'
code = source.read_text()
assert code.count('tests.test_ieee_tc_native_bridge') == 1
code = code.replace('tests.test_ieee_tc_native_bridge', 'tests.test_ieee_tc_native_retirement')
exec(compile(code, str(source), 'exec'))
