"""Record actual empty scope after wrapper syntax failure, then exact closure."""
import json, sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity('primelora-tc-aux-d6060000000000000000000000000005.scope')
group=Path(identity['path'])
assert p.scope_still_owned(identity)
assert all(not path.read_text().split() for path in group.rglob('cgroup.procs'))
with (RAW/'bootstrap_identity.json').open('x') as stream:json.dump(identity,stream,indent=2)
source=RAW.parent.parent/'storage_maintenance/d592_20261017/close.py'
code=source.read_text().replace("('cleanup', 'storage', 'curation', 'publication')", "('bootstrap',)")
sys.argv=[str(__file__),'bootstrap']
exec(compile(code,str(source),'exec'))
