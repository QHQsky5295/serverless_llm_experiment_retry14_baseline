"""Same exact-owned closure for repaired qualification."""
from pathlib import Path
source=Path(__file__).resolve().parent/'close.py'
code=source.read_text().replace("'focused', 'regression', 'component', 'publication'",
                              "'regression2',")
exec(compile(code,str(source),'exec'))
