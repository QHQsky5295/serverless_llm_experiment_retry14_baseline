"""D605 comparison driver reused for canonical producer/consumer representation."""
import contextlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d605_20261017/compare_inventory.py')
code = source.read_text()
def replace(old, new, count=1):
    global code
    assert code.count(old) == count, old
    code = code.replace(old, new)

replace('import ast', 'import ast\nimport inspect\nimport textwrap')
replace("old_commit = '161fa069e004ed54622dbc5922f72ee56f624f02'",
        "old_commit = '161a246195bd9b46f9e396c8e7156de7f52250ab'")
replace('assert hashlib.sha256(old_source).hexdigest() == p.digest(ROOT/relative)',
        'candidate_source_sha256 = p.digest(ROOT/relative)')
start = code.index('candidate_text = parent_text')
end = code.index('\nfunctions = {}', start)
code = code[:start] + """candidate_text = inspect.getsource(module._local_file_inventory)
owner_node = next(n for n in ast.parse(old_source).body
    if isinstance(n, ast.ClassDef) and n.name == 'LocalSourceReferences')
method_node = next(n for n in owner_node.body
    if isinstance(n, ast.FunctionDef) and n.name == '_planning_source_observations')
parent_method_text = textwrap.dedent(ast.get_source_segment(old_source.decode(), method_node))
namespace = dict(module.__dict__)
exec(compile(parent_method_text, '<d606-parent-projection>', 'exec'), namespace)
methods = {'parent': namespace['_planning_source_observations'],
           'prototype': module.LocalSourceReferences._planning_source_observations}
""" + code[end:]
replace("with patch.object(module,'_local_file_inventory',function):",
        "with (patch.object(module,'_local_file_inventory',function),\n"
        "              patch.object(type(owner),'_planning_source_observations',methods[variant])):")
replace('captured[file].st_mtime_ns', 'captured[str(file)].st_mtime_ns')
replace("pool = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')",
        "pool = Path('/tmp/tc-d557-7bv/remote_artifacts')")
replace('assert pool.resolve()==pool and pool.is_dir()', """assert pool.resolve()==pool and pool.is_dir()
campaign=RAW.parent.parent/'vllm_qualification/d557_20261016'
closed=json.loads((campaign/'publication_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
launch=json.loads((campaign/'launch7b.json').read_text())
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not Path(launch['service_identity']['path']).exists()
""")
replace('assert hashlib.sha256(old_source).hexdigest()==p.digest(ROOT/relative)',
        'assert candidate_source_sha256==p.digest(ROOT/relative)')
replace("kind='d605_fresh_inventory_component_prototype_v1'",
        "kind='d606_canonical_fresh_inventory_candidate_v1'")
replace('prototype_function=candidate_text,',
        "prototype_function=candidate_text, parent_projection=parent_method_text,\n"
        "    candidate_projection=inspect.getsource(methods['prototype']),\n"
        "    candidate_source_sha256=candidate_source_sha256,\n"
        "    reused_driver_sha256=p.digest(source),")
replace('real_pool=str(pool),pool_inventory_output_sha256=',
        "real_pool=str(pool),tree_semantics='closed_vllm_transfer_metadata_not_adapter_payload',\n"
        "    full_500_adapter_inventory_test=False,pool_inventory_output_sha256=")
replace('production_source_unchanged=True', 'production_source_unchanged=False')
with (Path(__file__).resolve().parent/'component.log').open('x') as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        exec(compile(code, str(source), 'exec'))
