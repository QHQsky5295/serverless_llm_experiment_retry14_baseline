"""Reuse D595 bounded regression runner with D606's affected source/test set."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/run_tests.py')
code = source.read_text()
start = code.index('paths=[ROOT/name')
end = code.index('\nrefs=', start)
code = code[:start] + """paths=[ROOT/name for name in (
    'faaslora/memory/residency_manager.py',
    'tests/test_ieee_tc_file_observation.py',
    'tests/test_ieee_tc_static_preparation.py',
    'tests/test_ieee_tc_request_lifecycle.py',
    'tests/test_ieee_tc_transfer_pressure.py',
    'tests/test_ieee_tc_request_footprints.py',
    'tests/test_ieee_tc_preparation_snapshot_copy.py')]""" + code[end:]
start = code.index('tests=(')
end = code.index('\ncommand=', start)
code = code[:start] + """tests=(['tests.test_ieee_tc_file_observation',
    'tests.test_ieee_tc_static_preparation', 'tests.test_ieee_tc_request_lifecycle']
    if phase=='focused' else ['tests.test_ieee_tc_launch',
    'tests.test_ieee_tc_cpu_frontend_integration',
    'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_request_footprints',
    'tests.test_ieee_tc_preparation_snapshot_copy',
    'tests.test_ieee_tc_frontend_preparation', 'tests.test_ieee_tc_native_bridge'])""" + code[end:]
exec(compile(code, str(source), 'exec'))
