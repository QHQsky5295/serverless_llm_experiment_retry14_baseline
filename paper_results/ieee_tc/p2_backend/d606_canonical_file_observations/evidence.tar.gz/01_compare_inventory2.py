"""Repair only provenance-variable shadowing; preserve failed attempt evidence."""
from pathlib import Path
source = Path(__file__).resolve().parent/'compare_inventory.py'
body = source.read_text()
old = 'reused_driver_sha256=p.digest(source)'
assert body.count(old) == 1
body = body.replace(old, "reused_driver_sha256=p.digest(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d605_20261017/compare_inventory.py'))")
marker = 'with (Path(__file__).resolve().parent/'
assert body.count(marker) == 1
body = body.replace(marker, """code = code.replace("'component_identity.json'", "'component2_identity.json'")
code = code.replace("'component_result.json'", "'component_result2.json'")
with (Path(__file__).resolve().parent/""")
body = body.replace("'component.log'", "'component2.log'")
exec(compile(body, str(source), 'exec'))
