"""D198 bounded qualification sealing, adapted to D209 acquisition identity consumer."""
import ast
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT = Path.cwd()
RAW = ROOT/'results/ieee_tc/p2_backend_qualification/d209_20261003'
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX = '20261003_d209_acquisition_identity'
PARENT = 'a19365ef15f9d03885d1981b2e28c4fbbc445955'

def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()

monitor = 'scripts/run_all_experiments.py'
def tree(old):
    data = subprocess.check_output(['git', 'show', PARENT+':'+monitor]) if old else (ROOT/monitor).read_bytes()
    return ast.parse(data)

class StripAllowed(ast.NodeTransformer):
    def visit_AsyncFunctionDef(self, node):
        if node.name == '_acquire_runtime_gpu_reference': return None
        return node

assert ast.dump(StripAllowed().visit(tree(True))) == ast.dump(StripAllowed().visit(tree(False)))
changed = set(subprocess.check_output(['git','diff','--name-only',PARENT,'--','faaslora','scripts','configs/ieee_tc'],text=True).splitlines())
assert changed == {monitor}
for path in ('faaslora/memory/gpu_monitor.py','faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py',
             'faaslora/preloading/planning_cpu.py','faaslora/experiment/instance_pool.py',
             'faaslora/scheduling/resource_coordinator.py'):
    assert (ROOT/path).read_bytes() == subprocess.check_output(['git','show',PARENT+':'+path])
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()

rows, members = [], []
for phase in ('tests1', 'tests2', 'tests3', 'regression1', 'probe1'):
    unit = 'primelora-d209-'+phase+'-20261003.scope'
    receipt = dict(line.split('=',1) for line in (RAW/(phase+'_scope.txt')).read_text().splitlines())
    assert re.fullmatch('[0-9a-f]{32}', receipt['InvocationID'])
    assert receipt['MemoryHigh']=='3221225472' and receipt['MemoryMax']=='4294967296'
    assert receipt['MemorySwapMax']=='0'
    for prop, value in (('LoadState','not-found'),('InvocationID',''),('ControlGroup','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == value
    assert not Path('/sys/fs/cgroup'+receipt['ControlGroup']).exists()
    log = (RAW/(phase+'.log')).read_text()
    timing = (RAW/(phase+'_time.txt')).read_text()
    expected_exit = 1 if phase in ('tests1', 'tests2') else 0
    assert f'Exit status: {expected_exit}' in timing
    if phase in ('tests1', 'tests2'):
        summary = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s\n\nFAILED \(errors=1\)$',log,re.M)
        assert len(summary)==1 and int(summary[0][0])==222
        assert "AttributeError: 'NoneType' object has no attribute" in log
        tests, elapsed, status = 222,float(summary[0][1]),'FAILED_old_fixture_field'
    elif phase == 'probe1':
        tests, elapsed, status = None,None,'PASS'
    else:
        summary = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s\n\nOK$',log,re.M)
        assert len(summary)==1
        tests, elapsed = int(summary[0][0]),float(summary[0][1])
        assert tests==222 if phase=='tests3' else tests>=1125
        status='PASS'
    events = dict(line.split() for line in (RAW/(phase+'_memory_events.txt')).read_text().splitlines())
    assert all(int(v)==0 for v in events.values())
    assert (RAW/(phase+'_swap.txt')).read_text().strip()=='0'
    for when in ('before','after'):
        encoded=(RAW/(phase+'_protected_'+when+'.json')).read_text()
        checked=json.loads(encoded)
        assert checked['pass'] and checked['entry_count']==147
    with tarfile.open(RAW/(phase+'_sources.tar.gz'),'r:gz') as sources:
        for line in (RAW/(phase+'_sources.sha256')).read_text().splitlines():
            digest,path=line.split('  ',1)
            assert hashlib.sha256(sources.extractfile(path).read()).hexdigest()==digest
            if path.startswith(('scripts/', 'faaslora/')) or (phase not in ('tests1', 'tests2') and path.startswith('tests/')):
                assert sha(ROOT/path)==digest,path
    rows.append(dict(phase=phase,tests=tests,status=status,test_body_seconds=elapsed,
        invocation_id=receipt['InvocationID'],scope_absent=True,memory_events=events,
        memory_peak_bytes=int((RAW/(phase+'_memory_peak.txt')).read_text()),swap_bytes=0))
    members.extend(RAW/(phase+suffix) for suffix in ('.log','_scope.txt','_time.txt','_memory_events.txt',
        '_swap.txt','_memory_peak.txt','_protected_before.json','_protected_after.json','_sources.sha256','_sources.tar.gz'))

probe=json.loads((RAW/'probe1.json').read_text())
assert len(probe['rows'])==10 and probe['parent_commit']==PARENT
assert probe['candidate_runner_sha256']==sha(ROOT/monitor)
assert sum(r['requests'] for r in probe['retained_d203_source_coverage'])==4000
assert probe['gpu_performance_qualified'] is False
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
assert protected['plan_sha256']=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
doc=ROOT/'docs/ieee_tc/D209_ACQUISITION_IDENTITY.md'
assert '状态：CPU 资格完成，普通 Full 待执行' in doc.read_text()
table=['# D209 acquisition identity qualification','',
    'CPU qualification and exact-parent component checks only; no GPU inference gain or CI.','',
    '| Check | Tests | Result | Body seconds | Peak memory bytes |',
    '|---|---:|---|---:|---:|']
for row in rows:
    table.append(f"| {row['phase']} | {row['tests']} | {row['status']} | {row['test_body_seconds']} | {row['memory_peak_bytes']} |")
table+=['','| Source | Full graphs parent/candidate | Target graphs parent/candidate | Identity reads parent/candidate | Fresh reads parent/candidate |',
        '|---|---:|---:|---:|---:|']
for old,new in zip(probe['rows'][::2],probe['rows'][1::2]):
    table.append(f"| {old['tier']} | {old['routing_graph_queries']}/{new['routing_graph_queries']} | {old['request_graph_queries']}/{new['request_graph_queries']} | {old['identity_only_queries']}/{new['identity_only_queries']} | {old['total_fresh_source_queries']}/{new['total_fresh_source_queries']} |")
table+=['','| D203 selected source | Native | Requests |','|---|---|---:|']
for r in probe['retained_d203_source_coverage']:
    table.append(f"| {r['tier']} | {r['native']} | {r['requests']} |")
table+=['',probe['coverage_caveat'],'']
with (OUT/(PREFIX+'_table.md')).open('x') as f: f.write('\n'.join(table))
with (OUT/(PREFIX+'.csv')).open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(probe['rows'][0]),lineterminator='\n')
    writer.writeheader();writer.writerows(probe['rows'])
members.extend(RAW/name for name in ('run_cpu.sh','probe.py','probe1.json','probe1.csv','curate.py','check_staged.py'))
members.extend((doc,ROOT/monitor,ROOT/'tests/test_ieee_tc_identity_recheck.py',ROOT/'tests/test_ieee_tc_request_lifecycle.py'))
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret)>16
def inspect(data,name):
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for item in archive.getmembers():
                assert item.isfile() and '..' not in Path(item.name).parts and not item.name.startswith('/')
                inspect(archive.extractfile(item).read(),item.name)
    if name.endswith('.py'): ast.parse(data,filename=name)
for path in members:
    inspect(path.read_bytes(),str(path))
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
sources={str(p):sha(p) for p in members}
bundle=OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output,tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members: archive.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers())==len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(str(path.relative_to(ROOT))).read()).hexdigest()==sources[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as f: f.write(sha(bundle)+'  '+bundle.name+'\n')
result=dict(kind='d209_acquisition_identity_qualification_v1',parent=PARENT,
    status='cpu_qualified_ordinary_full_pending',tests=rows,component=probe,protected_after=protected,
    source_sha256=sources,native_owner_planner_admission_unchanged=True,
    runtime_change='Acquire-source observation uses fresh identity endpoint; full physical demand checks unchanged.',
    gpu_execution=False,remote_operation=False,numeric_qualification=False,performance_accepted=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    table_sha256=sha(OUT/(PREFIX+'_table.md')),csv_sha256=sha(OUT/(PREFIX+'.csv')))
with (OUT/(PREFIX+'.json')).open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS',protected=147,curated_sha256=sha(OUT/(PREFIX+'.json')),
                     evidence_bundle=result['evidence_bundle']),indent=2))
