"""D209 exact-parent acquisition comparison, reusing the D178 component harness."""
import ast
import asyncio
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import subprocess
from types import MethodType
import scripts.run_all_experiments as implementation
from tests.test_ieee_tc_request_lifecycle import SelectedSourceAdmissionIntegration

ROOT = Path.cwd()
RAW = ROOT/'results/ieee_tc/p2_backend_qualification/d209_20261003'
PARENT = 'a19365ef15f9d03885d1981b2e28c4fbbc445955'
source = subprocess.check_output(['git','show',PARENT+':scripts/run_all_experiments.py'],text=True)
functions = [n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.AsyncFunctionDef)
             and n.name == '_acquire_runtime_gpu_reference']
assert len(functions) == 1
namespace = dict(vars(implementation))
exec(compile(ast.Module(body=functions,type_ignores=[]),'<exact-parent-recheck>','exec'),namespace)
rows=[]
for tier in ('gpu','host','host_file','nvme','remote'):
    for version in ('parent','candidate'):
        case=SelectedSourceAdmissionIntegration()
        try:
            runner,slot,trace,plan,owner,_ = case.build(tier if tier in ('gpu','host') else 'remote')
            if tier not in ('gpu','host'):
                case.file_source(runner,trace,publish=tier!='remote',host=tier=='host_file')
            if version == 'parent':
                runner._acquire_runtime_gpu_reference = MethodType(namespace['_acquire_runtime_gpu_reference'],runner)
            result=asyncio.run(runner._exec_request(trace,4,0.,request_plan=plan))
            assert result.success,result.error
            expected='host' if tier=='host_file' else tier
            assert result.readiness_tier_before_dispatch==expected
            counts=Counter(call.kwargs['operation'] for call in slot.engine.ieee_gpu_reference.await_args_list)
            assert counts['source_snapshot']==0 and counts['demand_load_and_acquire']==1
            state=owner.snapshot()
            assert state['live_leases']==state['live_host_source_leases']==slot.active_requests==0
            rows.append(dict(tier=tier,version=version,
                routing_graph_queries=counts['routing_source_snapshot'],
                request_graph_queries=counts['request_source_snapshot'],
                identity_only_queries=counts['source_identity_snapshot'],
                total_fresh_source_queries=counts['routing_source_snapshot']+counts['source_identity_snapshot']+counts['request_source_snapshot'],
                demand_transactions=counts['demand_load_and_acquire'],
                host_holds=counts['hold_host_source'],host_releases=counts['release_host_source'],
                success=True,dispatch_tier=expected,live_gpu_leases=0,live_host_leases=0))
        finally:
            case.doCleanups()
for old,new in zip(rows[::2],rows[1::2]):
    expected=int(old['tier'] in ('host_file','nvme','remote'))
    assert old['routing_graph_queries']-new['routing_graph_queries']==expected
    assert new['identity_only_queries']-old['identity_only_queries']==expected
    excluded={'version','routing_graph_queries','identity_only_queries'}
    assert {k:v for k,v in old.items() if k not in excluded}=={k:v for k,v in new.items() if k not in excluded}
payload=dict(kind='native_acquisition_identity_component_v1',parent_commit=PARENT,
    parent_runner_sha256=hashlib.sha256(source.encode()).hexdigest(),
    candidate_runner_sha256=hashlib.sha256((ROOT/'scripts/run_all_experiments.py').read_bytes()).hexdigest(),
    gpu_performance_qualified=False,numerical_full_pool_qualified=False,rows=rows)

projection = ROOT/'results/ieee_tc/p2_backend_qualification/d203_20261003/full_full1_request_projection.json'
assert projection.stat().st_size < 40*1024**2
projection_sha = hashlib.file_digest(projection.open('rb'),'sha256').hexdigest()
assert projection_sha == '3e5250e0b34c152f06e7c520bd84469cfa483e2f6414da5d428f848929ffc8cc'
requests = json.loads(projection.read_text())['requests']
assert len(requests) == len({r['request_id'] for r in requests}) == 4000
coverage = Counter()
for request in requests:
    selected = request['retained_reference_evidence']['source_admission']['source']
    assert type(selected['native']) is bool
    coverage[(selected['tier'], selected['native'])] += 1
payload['retained_d203_source_coverage'] = [
    dict(tier=tier,native=native,requests=count) for (tier,native),count in sorted(coverage.items())]
payload['retained_d203_projection_sha256'] = projection_sha
payload['coverage_caveat'] = 'Recorded selected-source populations, not measured acquisition RPC counts or latency causality.'

with (RAW/'probe1.json').open('x') as out: json.dump(payload,out,indent=2,allow_nan=False)
with (RAW/'probe1.csv').open('x',newline='') as out:
    writer=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
print(json.dumps(payload,indent=2))
