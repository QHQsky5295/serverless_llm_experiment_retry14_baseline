"""Reuse the D828 closed-evidence publisher for read-only D830 analysis."""
from pathlib import Path

_template = Path(__file__).resolve().parent.parent / 'd828_20261025/publish.py'
_source = _template.read_text()
for _old, _new in (
    ('d828_post_file_owner_turn', 'd830_selected_owner_completion'),
    ("summary['matched_remote_cohort'] == 498", "summary['matched_remote_cohort'] == 503"),
    ("assert summary['groups']['all']['native_copy_present'] == 0\nassert summary['groups']['all']['epoch_advanced'] == 113",
     "assert summary['groups']['all']['selected_finished_last'] == 178\nassert summary['groups']['ttft_fail']['n'] == 225"),
    ("for phase in ('analysis', 'focused', 'regression'):", "for phase in ('analysis_attempt2',):"),
    ("    ('d610_20261017', 'run_tests.py'), ('d595_20261017', 'run_tests.py'),\n    ('d827_20261025', 'publish.py'), ('d824_20261025', 'backup.py')",
     "    ('d828_20261025', 'analyze.py'), ('d828_20261025', 'publish.py'),\n    ('d824_20261025', 'backup.py')"),
    ("new_gpu_replays=0, production_candidate=True", "new_gpu_replays=0, production_candidate=False"),
    ('distinct_regression_tests=370, focused_tests_included=57',
     'distinct_regression_tests=0, focused_tests_included=0'),
    ("decision='One admitted owner anchor candidate CPU-qualified; complete unchanged 3B W2 next.'",
     "decision='503 request joins validated; inspect owned readiness/settlement split next, no runtime candidate selected.'"),
    ('D828_POST_FILE_OWNER_TURN_20261025.md', 'D830_SELECTED_OWNER_COMPLETION_20261025.md'),
    ("production_sources=read(RAW/'regression_receipt.json')['sources']",
     "production_sources={}, failed_attempt=read(RAW/'attempt1_failure.json')"),
    ('distinct_tests=370', 'distinct_tests=0'),
):
    assert _old in _source, _old
    _source = _source.replace(_old, _new)
exec(compile(_source, str(_template), 'exec'), globals())
