"""Reuse explicit-path D824 backup; D830 contains analysis only."""
from pathlib import Path

_template = Path(__file__).resolve().parent.parent / 'd824_20261025/backup.py'
_source = _template.read_text()
for _old, _new in (
    ('d824_current_ingress_pending', 'd830_selected_owner_completion'),
    ('107185c45f49a891c0b391b1140b7d765e83daea', 'e48f93ad73ef1deb207e8975cb048c96abd1dbb4'),
    ("OUT/'final_manifest.json'", "OUT/'manifest.json'"),
    ('D824_CURRENT_INGRESS_AND_CONTROL_20261025.md', 'D830_SELECTED_OWNER_COMPLETION_20261025.md'),
    ('len(set(paths)) == 20', 'len(set(paths)) == 7'),
    ('backup/d824-current-ingress-control-20261025', 'backup/d830-selected-owner-completion-20261025'),
    ('tc: preserve current 3B ingress and actual scaling-trigger diagnosis (D824)',
     'tc: preserve selected-owner completion dependency evidence (D830)'),
    ("git('diff','--cached','--check')", "git('-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check')"),
):
    assert _old in _source, _old
    _source = _source.replace(_old, _new)
exec(compile(_source, str(_template), 'exec'), globals())
