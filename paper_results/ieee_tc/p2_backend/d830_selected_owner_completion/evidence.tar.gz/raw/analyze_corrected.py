"""Correct the owner namespace join; preserve D830's failed first attempt."""
from pathlib import Path

_here = Path(__file__).resolve().parent
_attempt = _here / 'analyze.py'
_namespace = {'__file__': str(_attempt)}
_wrapper = _attempt.read_text()
exec(compile(_wrapper[:_wrapper.index('exec(compile(_source')], str(_attempt), 'exec'), _namespace)
_program = _namespace['_source']
for _old, _new in (
    ('analysis_identity.json', 'analysis_attempt2_identity.json'),
    ('resource_gate.json', 'resource_gate_attempt2.json'),
    ('analysis_receipt.json', 'analysis_attempt2_receipt.json'),
    ("        ordered = sorted", """        pending = evidence['pending_kv_admission']['receipt']
        selected_scheduler_owner = pending['scheduler_owner_id']
        assert pending['scheduler_pid'] == receipt['worker_pid']
        assert pending['clock_id'] == receipt['clock_id']
        assert request['instance_id'] == snapshot['instance_id']
        ordered = sorted"""),
    ("assert ordered and receipt['owner_id'] in record['participants']",
     "assert ordered and selected_scheduler_owner in record['participants']"),
    ("selected = record['participants'][receipt['owner_id']]['finish_receipt']",
     "selected = record['participants'][selected_scheduler_owner]['finish_receipt']"),
    ("assert selected['owner_id'] == receipt['owner_id']",
     "assert selected['owner_id'] == selected_scheduler_owner"),
    ("if item[1] == receipt['owner_id']", "if item[1] == selected_scheduler_owner"),
    ("            participants=len(ordered), selected_finish_position=position,",
     """            native_cache_owner_id=receipt['owner_id'],
            scheduler_pressure_owner_id=selected_scheduler_owner,
            native_worker_pid=receipt['worker_pid'],
            participants=len(ordered), selected_finish_position=position,"""),
    ("        'No counterfactual SLO, no latency subtraction, no causal speedup claim.',",
     """        'Native cache and scheduler pressure owner IDs differ by design; join through the same request pending receipt and matching native worker PID/clock.',
        'No counterfactual SLO, no latency subtraction, no causal speedup claim.',"""),
    ("OLD/'pressure_diagnosis.json', Path(__file__))]",
     "OLD/'pressure_diagnosis.json', Path(__file__), _attempt, _namespace['_template'])]"),
):
    assert _old in _program, _old
    _program = _program.replace(_old, _new)
with (_here / 'analysis_attempt2_program.py.snapshot').open('x') as _handle:
    _handle.write(_program)
exec(compile(_program, str(_here / 'analysis_attempt2_program.py.snapshot'), 'exec'), globals())
