"""Reuse D828's exact receipt join to inspect selected-owner finish dependencies."""
import hashlib
from pathlib import Path

_raw = Path(__file__).resolve().parent
_template = _raw.parent / 'd828_20261025/analyze.py'
assert hashlib.sha256(_template.read_bytes()).hexdigest() == '428135938bf3eef39f905e245c31b589899da729f72c8cedad661ec1b15ebb55'
_source = _template.read_text()
for _old, _new in (
    ('d826_3b_single_verification_full_w2/preparation_analysis', 'd829_3b_admitted_owner_anchor_full_w2/preparation_analysis'),
    ('d828_post_file_owner_turn', 'd830_selected_owner_completion'),
    ('d827_20261025/backup_identity.json', 'd829_20261025/finish_identity.json'),
    ('assert len(cohort) == 498', 'assert len(cohort) == 503'),
    ('matched_remote_cohort=498', 'matched_remote_cohort=503'),
    ('All 498 previously matched requests retained; other 15 selected-Remote',
     'All 503 previously matched requests retained; other 8 selected-Remote'),
):
    assert _old in _source, _old
    _source = _source.replace(_old, _new)
_start = _source.index("        snapshot = evidence['snapshot_before_acquisition']")
_end = _source.index('        rows.append(row)', _start)
_source = _source[:_start] + '''        snapshot = evidence['snapshot_before_acquisition']
        receipt = evidence['receipt']
        proof = receipt['file_demand_transaction']
        assert snapshot['acquisition_observation_scope'] == 'admission_owner_identity_only_v1'
        assert snapshot['owner_id'] == receipt['owner_id']
        assert snapshot['clock_id'] == receipt['clock_id'] == record['clock_id']
        assert proof['validated_epoch'] >= proof['observed_epoch'] >= snapshot['epoch']
        assert proof['live_native_constraints_checked'] and not proof['controller_capacity_snapshot_reused']
        assert receipt['file_source_witness']['lease_id'] == evidence['local_source_reference']['lease_id']
        assert all(member['state'] == 'finished' for member in record['participants'].values())
        ordered = sorted((member['finish_receipt']['observed_at'], owner)
                         for owner, member in record['participants'].items())
        assert ordered and receipt['owner_id'] in record['participants']
        selected = record['participants'][receipt['owner_id']]['finish_receipt']
        assert selected['owner_id'] == receipt['owner_id']
        assert selected['transfer_id'] == record['transfer_id']
        assert selected['clock_id'] == record['clock_id']
        joined, first, target, last, end, load = (
            record['io_joined_at'], ordered[0][0], selected['observed_at'],
            ordered[-1][0], record['finished_at'], receipt['native_load_started_monotonic_s'])
        assert joined <= first <= target <= last <= end <= load
        position = next(i for i, item in enumerate(ordered, 1) if item[1] == receipt['owner_id'])
        row = dict(request_id=key, ordinal=int(previous['ordinal']),
            adapter_id=request['adapter_id'], ttft_pass=previous['ttft_pass'] == 'True',
            participants=len(ordered), selected_finish_position=position,
            selected_finished_last=position == len(ordered),
            io_join_to_first_native_finish_ms=1000*(first-joined),
            first_to_selected_finish_ms=1000*(target-first),
            selected_to_last_finish_ms=1000*(last-target),
            last_native_finish_to_controller_finish_ms=1000*(end-last),
            selected_to_controller_finish_ms=1000*(end-target),
            controller_finish_to_native_load_ms=1000*(load-end),
            selected_finish_rpc_channel_ms=selected['timing']['parent_rpc_channel_acquire_ms'],
            selected_finish_rpc_send_ms=selected['timing']['parent_rpc_send_flush_ms'],
            selected_finish_rpc_wait_ms=selected['timing']['parent_rpc_wait_response_ms'])
        assert abs(sum(row[name] for name in (
            'io_join_to_first_native_finish_ms', 'first_to_selected_finish_ms',
            'selected_to_last_finish_ms', 'last_native_finish_to_controller_finish_ms'))
            - float(previous['pressure_finish_ms'])) < 1e-5
        assert abs(row['controller_finish_to_native_load_ms']
            - float(previous['after_pressure_finish_to_load_ms'])) < 1e-5
''' + _source[_end:]
_source = _source.replace(
    "native_copy_present=sum(row['selected_native_copy_present'] for row in selected),\n        epoch_advanced=sum(row['validated_epoch'] > row['identity_epoch'] for row in selected)",
    "selected_finished_last=sum(row['selected_finished_last'] for row in selected),\n        selected_position_counts={str(i): sum(row['selected_finish_position'] == i for row in selected) for i in (1, 2, 3)}")
assert 'selected_native_copy_present' not in _source
exec(compile(_source, str(_raw / 'analyze.py.reused'), 'exec'), globals())
