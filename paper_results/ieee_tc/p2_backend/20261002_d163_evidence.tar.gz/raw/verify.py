"""Reuse D159 bounded evidence seal for D163; no serving gain inferred."""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
BASE = '2765a51bd844bd38f4b6bfde79905757c9dacdb2'

def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
tests = []
for phase, count in (('targeted1', 6), ('regression1', 822), ('micro1', None)):
    log = (RAW/f'{phase}.log').read_text()
    elapsed = (RAW/f'{phase}_time.txt').read_text()
    assert 'Exit status: 0' in elapsed
    body_seconds = None
    if count is not None:
        match = re.search(r'Ran (\d+) tests in ([\d.]+)s', log)
        assert match and int(match[1]) == count and '\nOK\n' in log
        body_seconds = float(match[2])
    receipt = (RAW/f'{phase}_scope.txt').read_text()
    invocation = re.search(r'^InvocationID=([a-f0-9]{32})$', receipt, re.M)[1]
    cleanup = (RAW/f'{phase}_cleanup.txt').read_text()
    assert f'actual_invocation={invocation}' in cleanup
    assert 'cleanup=automatic_removal_verified' in cleanup
    unit = f'primelora-d163-{phase}-20261002.scope'
    assert subprocess.check_output(['systemctl', '--user', 'show', unit, '-p', 'ActiveState', '--value'], text=True).strip() == 'inactive'
    assert not subprocess.check_output(['systemctl', '--user', 'show', unit, '-p', 'InvocationID', '--value'], text=True).strip()
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice', unit).exists()
    events = dict(line.split() for line in (RAW/f'{phase}_final_memory_events.txt').read_text().splitlines())
    assert all(int(value) == 0 for value in events.values())
    assert int((RAW/f'{phase}_final_swap.txt').read_text()) == 0
    tests.append(dict(phase=phase, count=count, exit_code=0, body_seconds=body_seconds,
        maximum_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)', elapsed)[1]),
        actual_invocation_id=invocation, cleanup_verified=True, final_memory_events=events,
        final_swap_bytes=0, raw_log_sha256=sha(RAW/f'{phase}.log')))

from scripts.ieee_tc_preflight import verify_seal
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
refs = {
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'): '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md': '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'paper_results/ieee_tc/p2_backend/20261002_d160_7b_full_w0_full1.json': '67db3cf4b7a3f7a26d6cbd8f355b398945439f855fc9e1cd0254104fbdc9d777',
    ROOT/'paper_results/ieee_tc/p2_backend/20261002_d162_prefix_diagnostic.json': 'ea9ae817196f8f8f5ccf2a5869469690ceb5e4aa53e5c53a606e337c21f9c8d5',
}
for path, expected in refs.items():
    assert sha(path) == expected, path
sources = ['faaslora/preloading/planning_cpu.py', 'tests/test_ieee_tc_planning_cpu.py']
unchanged = ['faaslora/preloading/preloading_planner.py', 'scripts/run_all_experiments.py',
             'faaslora/memory/residency_manager.py']
for name in sources+unchanged:
    ast.parse((ROOT/name).read_text())
for name in sources:
    assert f'{sha(ROOT/name)}  {name}' in (RAW/'regression1_sources.sha256').read_text()
for name in unchanged:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git', 'show', f'{BASE}:{name}'], cwd=ROOT)

# All pre-existing methods except envelope construction are bytecode-AST equal;
# the original worker entry/validator/formula calls and export methods are intact.
source_path = sources[0]
old_tree = ast.parse(subprocess.check_output(['git', 'show', f'{BASE}:{source_path}'], cwd=ROOT))
new_tree = ast.parse((ROOT/source_path).read_text())
def nodes(tree):
    return {node.name: node for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))}
old_nodes, new_nodes = nodes(old_tree), nodes(new_tree)
for name, node in old_nodes.items():
    if name != 'ValidatedPreparationPlan':
        assert ast.dump(node) == ast.dump(new_nodes[name]), name
old_methods, new_methods = nodes(old_nodes['ValidatedPreparationPlan']), nodes(new_nodes['ValidatedPreparationPlan'])
for name, node in old_methods.items():
    if name != '_from_worker_result':
        assert ast.dump(node) == ast.dump(new_methods[name]), name

component = json.loads((RAW/'membership_component.json').read_text())
assert component['exact_output'] and not component['inference'] and not component['formal_result']
assert len(component['rows']) == 12
for ref in component['source_refs']:
    assert sha(ref['path']) == ref['sha256']
for row in component['rows']:
    assert row['exact_output']
    assert row['counted_decodes_per_operation'] == (2 if row['variant'] == 'legacy' else 1)
doc = ROOT/'docs/ieee_tc/D163_IMMUTABLE_PLAN_MEMBERSHIP.md'
subprocess.run(['git', 'diff', '--check', '--', *sources, str(doc)], cwd=ROOT, check=True)
curated = OUT/'20261002_d163_plan_membership.json'
result = dict(kind='d163_immutable_plan_membership_qualification_v1', base_commit=BASE,
    source_sha256={p:sha(ROOT/p) for p in sources+unchanged}, tests=tests,
    protected=protected, frozen_references={str(p):s for p,s in refs.items()}, component=component,
    original_formulas_worker_and_exports_unchanged=True, performance_run_completed=False,
    formal_g1_g2_qualified=False, qualification='representation_correctness_and_component_only',
    next='Ordinary 7B Full4000 W0 without observer; same D160 cap4 and D157 profiles.',
    caveats=['Tiny fixture timings are not serving latency or a confidence interval.',
             'Additional immutable key-index creation is part of the candidate and must be included in Full.',
             'Numerical adapter identity, common warm/Resident references and G1/G2 remain open.'])
save(curated, result)
csv_path = OUT/'20261002_d163_plan_membership.csv'
with csv_path.open('x', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(component['groups'][0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(component['groups'])
verification = OUT/'20261002_d163_verification.json'
save(verification, dict(pass_=True, document_sha256=sha(doc), curated_sha256=sha(curated),
    csv_sha256=sha(csv_path), protected=protected, formula_worker_and_export_AST_unchanged=True))
members = sorted(p for p in RAW.iterdir() if p.is_file() and not p.name.startswith('verify1')
                 and p.stat().st_size < 2*1024**2
                 and p.suffix in {'.py','.sh','.log','.txt','.json','.jsonl','.sha256'})
extras = [ROOT/p for p in sources] + [doc, curated, csv_path]
bundle = OUT/'20261002_d163_evidence.tar.gz'
hashes = {}
with tarfile.open(bundle, 'x:gz') as tar:
    for p in members+extras:
        name = ('raw/'+p.name) if p in members else str(p.relative_to(ROOT))
        data = p.read_bytes()
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
        hashes[name] = hashlib.sha256(data).hexdigest()
        tar.add(p, arcname=name, recursive=False)
with tarfile.open(bundle, 'r:gz') as tar:
    assert set(tar.getnames()) == set(hashes)
    for name, digest in hashes.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
save(OUT/'20261002_d163_evidence_members.json', dict(member_sha256=hashes, pass_=True))
with (OUT/'20261002_d163_evidence.sha256').open('x') as handle:
    handle.write(sha(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(pass_=True, tests=tests, curated_sha256=sha(curated),
    bundle_sha256=sha(bundle), bundle_bytes=bundle.stat().st_size, members=len(hashes)), indent=2))
