"""D153 paired-component method, reusing actual existing planner test fixtures.

No synthetic enlarged epoch, weights, trace, GPU, network or serving claim.
The old operation is the unmodified Python Mapping mixin previously inherited.
"""
from collections.abc import Mapping
from collections import Counter
import hashlib
import json
from pathlib import Path
import pickle
import statistics
import subprocess
import time
from unittest.mock import patch

from faaslora.preloading.planning_cpu import execute_planning_message, ValidatedPreparationPlan
from tests.test_ieee_tc_planning_cpu import PlanningCPU

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
rows = []
fixtures = []
loads = pickle.loads
for mode in ('residency', 'handoff'):
    case = PlanningCPU()
    try:
        args, runner, _ = case.inputs(mode)
        payload, receipt = execute_planning_message(pickle.dumps(('owned_execution_epoch',
            runner._stack.preloading_planner.max_dp_buffer_bytes, args), protocol=5))
        sealed = ValidatedPreparationPlan._from_worker_result(payload, receipt)
        expected = sealed.execution_bundle_copy()
        assert tuple(expected[0]) == tuple(receipt['plan_keys'])
        fixture = dict(mode=mode, payload_bytes=len(payload), plan_sha256=receipt['plan_sha256'],
            plan_keys=list(receipt['plan_keys']), independent_serving_run=False)
        fixtures.append(fixture)
        for repeat in range(3):
            order = ('legacy', 'candidate') if repeat % 2 == 0 else ('candidate', 'legacy')
            for variant in order:
                counts = Counter()
                def counted_loads(*args, **kwargs):
                    counts['payload_decode'] += 1
                    return loads(*args, **kwargs)
                def present(key):
                    return (Mapping.__contains__(sealed, key) if variant == 'legacy'
                            else key in sealed)
                # Same key-only question followed by the same necessary open.
                with patch('faaslora.preloading.planning_cpu.pickle.loads', side_effect=counted_loads):
                    assert present('source_view')
                    opened = sealed.execution_bundle_copy()
                assert opened == expected
                assert counts['payload_decode'] == (2 if variant == 'legacy' else 1)
                began = time.perf_counter_ns()
                for _ in range(100):
                    assert present('source_view')
                    opened = sealed.execution_bundle_copy()
                elapsed_ns = time.perf_counter_ns() - began
                assert opened == expected
                rows.append(dict(mode=mode, repeat=repeat, variant=variant,
                    iterations=100, mean_member_then_open_ns=elapsed_ns / 100,
                    counted_decodes_per_operation=counts['payload_decode'], exact_output=True))
    finally:
        case.doCleanups()
groups = []
for mode in ('residency', 'handoff'):
    for variant in ('legacy', 'candidate'):
        selected = [r for r in rows if r['mode'] == mode and r['variant'] == variant]
        groups.append(dict(mode=mode, variant=variant, paired_component_repeats=3,
            mean_member_then_open_ns=statistics.mean(r['mean_member_then_open_ns'] for r in selected),
            counted_decodes_per_operation=selected[0]['counted_decodes_per_operation']))
sources = [Path(__file__), ROOT/'faaslora/preloading/planning_cpu.py',
    ROOT/'tests/test_ieee_tc_planning_cpu.py', ROOT/'tests/test_ieee_tc_transfer_pressure.py',
    ROOT/'faaslora/preloading/preloading_planner.py']
result = dict(kind='d163_immutable_plan_membership_component_v1', fixtures=fixtures,
    groups=groups, rows=rows, exact_output=True, inference=False, formal_result=False,
    evidence_base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    source_refs=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources],
    caveats=['Existing tiny planner correctness fixtures, not representative live full epochs.',
             'Three paired CPU repetitions are not workload runs or a confidence interval.',
             'Payload decode count reduction is exact; timing cannot be extrapolated to TTFT or GPU-s.',
             'Ordinary Full4000 without observer remains necessary; no extra profile or capacity change.'])
with (RAW/'membership_component.json').open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps(groups, indent=2))
