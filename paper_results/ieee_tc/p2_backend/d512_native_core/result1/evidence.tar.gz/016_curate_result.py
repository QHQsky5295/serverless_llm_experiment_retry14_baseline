"""Reuse D511 bounded provenance/archive workflow for completed D512 analysis."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d512_native_core'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'curation_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
for name in ('collection','analysis','operation'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty']
    assert not Path(closed['identity']['path']).exists()
audit=read(OUT/'analysis1/native_audit.json')
completion=read(OUT/'analysis1/completion.json')
operations=read(OUT/'operation_detail1/summary.json')
core=read(OUT/'analysis1/core_timing/summary.json')
resource=read(OUT/'analysis1/resource_remote.json')
assert audit['terminal_success']==1000 and audit['terminal_failure']==0
assert completion['complete_processes']==completion['processes']==10
assert completion['complete_request_observations']==1000
assert read(RAW/'actual_input_witness.json')['passed']
assert read(RAW/'analysis1_receipt.json')['returncode']==0
assert read(RAW/'operation_receipt.json')['passed']
assert p.check_plan()=='f851e6da5237cb706f5a167dd1180984d5d02694fa6568f1720e0e5aada0b1f5'
frozen={ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in frozen.items(): assert p.digest(path)==sha,path
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
subprocess.run(['git','diff','--exit-code','db44e8f068eb30c69466f32ad3d147ffbc45f9e2','--',
    'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=ROOT,check=True)
manifest=read(OUT/'analysis1/manifest.json')
for name,sha in manifest['outputs'].items(): assert p.digest(OUT/'analysis1'/name)==sha,name
refs={}
for record in (manifest,completion,resource,operations,core):
    for ref in record.get('source_refs',record.get('sources',[])):
        assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
        refs[ref['path']]=ref['sha256']
assert p.digest(Path(audit['evidence']['source']))==audit['evidence']['source_sha256']
tests=('tests.test_ieee_tc_control_timeline','tests.test_ieee_tc_decode_overlap',
       'tests.test_ieee_tc_core_timing','tests.test_ieee_tc_core_timing_analysis')
with (RAW/'result_tests.log').open('x') as f:
    subprocess.run([sys.executable,'-B','-m','unittest',*tests,'-q'],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
match=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK',(RAW/'result_tests.log').read_text())
assert match and int(match[1])==128
test_sources={str(ROOT/(name.replace('.','/')+'.py')):p.digest(ROOT/(name.replace('.','/')+'.py')) for name in tests}
destination=OUT/'result1';destination.mkdir(exist_ok=False)
summary=dict(kind='d512_current_native_core_diagnostic_result_v1',passed=True,
    source_commit=read(RAW/'launch_gate.json')['head'],stats=audit['stats'],
    native_contract_count=1000,n_correct=None,formal_performance_result=False,ranking_eligible=False,
    core_processes=completion['processes'],complete_request_observations=1000,
    window_gpu_seconds=audit['window_gpu_seconds'],resources=resource['resources'],remote=resource['remote'],
    operations=operations,request_groups=core['groups'],
    observer_overhead_included=True,thresholds=completion['thresholds'],
    threshold_note='D394 frozen ruler, not provisional; legacy analyzer caveat text is superseded only in interpretation.',
    result_doc='docs/ieee_tc/D512_NATIVE_CORE_DIAGNOSTIC_RESULT.md',
    metric_interpretation_doc='docs/ieee_tc/BASELINE_PUBLICATIONS_AND_OPTIMALITY_20261014.md',
    no_figures=True,new_gpu_runs_in_postprocessing=0,
    source_refs=[dict(path=path,sha256=sha) for path,sha in sorted(refs.items())])
save(destination/'summary.json',summary)
files=[path for folder in (OUT/'analysis1',OUT/'operation_detail1') for path in sorted(folder.rglob('*')) if path.is_file()]
files += [RAW/name for name in ('analyze_prefix.py','cross_contract.py','run_analysis.py',
    'summarize_operations.py','close_analysis.py','curate_result.py','close_after_release.py',
    'collect_closure.py','close.py','actual_input_witness.json','collection_receipt.json',
    'collection_closure.json','analysis_identity.json','analysis_closure.json','analysis1_receipt.json',
    'analysis_tests1_receipt.json','analysis_tests1.log','operation_identity.json','operation_closure.json',
    'operation_receipt.json','local_cleanup.json','remote_stop.json','completion_receipt.json','result_tests.log')]
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
members={}
archive=destination/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<32*1024*1024
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
        name=f'{i:03d}_{path.name}'
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o600;item.mtime=0
        tar.addfile(item,io.BytesIO(data))
        members[name]=dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
assert archive.stat().st_size<2*1024*1024
save(destination/'manifest.json',dict(passed=True,scope=identity,production_changed=False,
    tests=dict(count=int(match[1]),seconds=float(match[2]),sources=test_sources),protected=protected,
    preserved={str(path):sha for path,sha in frozen.items()},source_refs=summary['source_refs'],
    archive_members=members,outputs={name:p.digest(destination/name) for name in ('summary.json','evidence.tar.gz')}))
save(RAW/'curation_receipt.json',dict(passed=True,identity=identity,tests=int(match[1]),
    archive_bytes=archive.stat().st_size,manifest_sha256=p.digest(destination/'manifest.json'),
    resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(read(RAW/'curation_receipt.json')))
