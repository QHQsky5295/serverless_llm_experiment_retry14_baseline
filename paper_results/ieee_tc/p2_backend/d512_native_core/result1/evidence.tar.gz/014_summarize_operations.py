"""Aggregate observed operation costs only; no new inference or causal subtraction."""
import collections
import csv
import json
import math
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
BASE=ROOT/'paper_results/ieee_tc/p2_backend/d512_native_core'
identity=p.scope_identity(p.cg_path().name)
group=Path(identity['path'])
with (RAW/'operation_identity.json').open('x') as stream:json.dump(identity,stream,indent=2)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
closed=json.loads((RAW/'analysis_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
manifest=json.loads((BASE/'analysis1/manifest.json').read_text())
for name,expected in manifest['outputs'].items():assert p.digest(BASE/'analysis1'/name)==expected
with (BASE/'analysis1/core_timing/boundaries.csv').open() as f:
    boundaries=list(csv.DictReader(f))
with (BASE/'analysis1/core_timing/processes.csv').open() as f:
    processes=list(csv.DictReader(f))
assert all(r['complete']=='True' and r['truncated']=='False' for r in processes)
bins=collections.defaultdict(list)
for row in boundaries:
    if row['boundary']=='client':bins[row['label'],row['state']].append(row)
rows=[]
for (label,state),items in sorted(bins.items()):
    n=sum(int(r['count']) for r in items)
    wall=math.fsum(float(r['total_ms']) for r in items)
    cpu=math.fsum(float(r['thread_cpu_ms']) for r in items)
    rows.append(dict(label=label,state=state,count=n,total_wall_ms=wall,total_thread_cpu_ms=cpu,
        mean_wall_ms=wall/n,thread_cpu_over_wall=cpu/wall,max_single_call_ms=max(float(r['max_ms']) for r in items)))
out=BASE/'operation_detail1';out.mkdir(exist_ok=False)
with (out/'operations.csv').open('x') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
totals={state:math.fsum(r['total_wall_ms'] for r in rows if r['state']==state)
    for state in ('work','idle_at_entry')}
summary=dict(kind='d512_control_operation_aggregation_v1',processes=len(processes),
    total_completed_spans=sum(int(r['spans']) for r in processes),client_wall_ms=totals,
    total_observer_s=sum(int(r['observer_ns']) for r in processes)/1e9,
    total_write_s=sum(int(r['write_ns']) for r in processes)/1e9,
    summed_process_envelope_s=sum(int(r['last_ns'])-int(r['first_ns']) for r in processes)/1e9,
    operation_rows=rows,formal_performance_result=False,n_correct=None,
    caveats=['Client sums are host time across distinct process lifetimes, not added request latency or GPU time.',
        'Idle-at-entry describes the parent input entry, not each child call. Concurrent request intervals overlap.',
        'Observer includes write, not their sum; the totals are not subtracted from latency.',
        'No pooled P95 inferred from process-level P95. Detailed per-process Type-1 P95 remains in boundaries.csv.'],
    sources=[dict(path=str(x),sha256=p.digest(x)) for x in
        (Path(__file__),BASE/'analysis1/core_timing/boundaries.csv',BASE/'analysis1/core_timing/processes.csv')])
with (out/'summary.json').open('x') as f:json.dump(summary,f,indent=2,allow_nan=False)
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
with (RAW/'operation_receipt.json').open('x') as f:
    json.dump(dict(passed=True,identity=identity,resources=resources,gate=gate),f,indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ('sources','caveats','operation_rows')}))
print(json.dumps(sorted((r for r in rows if r['state']=='work'),key=lambda r:-r['total_wall_ms'])[:8]))
