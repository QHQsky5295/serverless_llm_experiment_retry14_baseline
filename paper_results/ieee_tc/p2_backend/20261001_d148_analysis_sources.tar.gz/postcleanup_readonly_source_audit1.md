# D148 后处理等待期间的只读核查

2026-10-01，源码 `1eaf15a4`；没有修改 serving、配置、生成或指标定义，
没有开始新诊断、重算旧栈采样或重读历史巨型结果。下面仅约束待分析问题，
不是已接受的优化候选，也不证明任何端到端因果效应。

## 原生状态传输及保存

- `scripts/run_all_experiments.py:15474` 附近的 `observe_source` 仍调用完整
  `ieee_gpu_reference(operation='source_snapshot')`，随后完整验证
  `NativeSourceSnapshot.from_native` 并提交到实际 selected slot。
- 该函数生成 `snapshot_evidence` 时仅移除 `native_footprints`，保留
  其余字段。`faaslora/memory/gpu_monitor.py:758` 附近的生产者同时产生
  `native_staging_footprints`；即使 staging 为空，这也是当前 registered
  HOST inventory 的独立深复制。因此“已去掉所有重复张量清单”并不成立。
- `_ieee_protect_selected_source` 的非 native 分支也以完整 source snapshot
  检查是否出现更快的 native copy。这里不能为了变快省略新鲜程度、source
  身份、owner/epoch 或实际引用保护。
- D132 已有 `ieee_routing_sources` 在独立 frontend 完整验证后投影，不使用
  陈旧缓存；目前仅在路由采集调用，接口注释明确 admission/planning 继续
  使用完整 inventory。是否能安全用于其他“只消费 source state”的边界，
  必须逐消费者核对，不能默认 planning/admission 都只需简化消息。
- 现有 `test_measured_footprints_reach_request_without_duplicating_tensor_inventory`
  只注入/检查 `native_footprints`，没有覆盖 `native_staging_footprints`。
  这是测试覆盖事实，不是已经观察到的错误计算。

结果体积大与请求证据保留有关，但末尾 `save_results` 在业务后执行；
不能把后处理时间当作在线 TTFT，也不能仅由 15.29 GB 文件大小估计 CPU
阻塞或推断一个字段解释全部排队。仍先完成 D148 的真实阶段分解。

## 历史采样的函数归属

复用已封存 `paper_results/ieee_tc/p2_backend/20261001_d143_prefix_diagnostic.json`
的现有汇总，不重新读取原始栈文件。业务期 nearest-project 的
`source_snapshot` 44 次来自 `faaslora/memory/residency_manager.py`；
`_local_file_inventory` 39 次也在该文件。该模块有文件 owner 和原生 owner
两个同名 `source_snapshot` 定义，仅文件名／函数名汇总还不足以精确归属
全部 44 次，需要已有栈的 caller／行号佐证。不能把它们直接视为 GPU
monitor 的设备查询。
采样是 GIL 有偏的出现次数，不是 wall/CPU 比例，inclusive 行不相加。

当前文件层 `source_snapshot(adapter_id)` 在锁内调用 `_validated_source`，
后者由 `_source_observation` 检查实际文件集合、签名和 footprint。
需要逐 caller 区分文件 source、原生 source 和占用查询，不将“状态查询”
一概归因为 D147 已修改的 CLI 路径。已有不可变内容、受管发布和重新检查
的正确性要求必须保留，不以关闭验证来制造优化。

## 官方源码核查（2026-10-01，只读）

已联网读取 vLLM `v0.30.0` 的原始代码，而非只依赖技能中的通用吞吐数字：

- [worker_manager.py](https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/vllm/lora/worker_manager.py)：
  LRU 路径在已注册且非 load-inplace 时复用对象；重新加载先验证再驱逐。
  其注释的单线程 core 调用条件不能直接移植为本项目所有控制任务无竞争。
- [model_manager.py](https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/vllm/lora/model_manager.py)：
  `list_adapters` 复制注册字典，不扫描张量；`_add_adapter` 先进行合并变换。
  mapping 元数据同时依赖 mapping 和 slot layout，不能仅凭前者不变就复用。
- [lora_weights.py](https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/vllm/lora/lora_weights.py)：
  `optimize` 会原位缩放 B；因此“模型对象相同”不是内容永不变化的证明。

本地已安装后端对应方法也已检查；未安装、升级或改写环境。以上支持区分
注册成员、动态 slot 状态与张量表示，不足以证明可安全跨调用缓存完整 inventory。
如后续考虑增量观测，必须覆盖本项目 staging、替换、释放、共享 storage 和
实际张量变化边界；如只投影已验证消息，必须证明各消费者所需字段完整。
本项目 `NativeSourceSnapshot` 的完整校验与路由投影已有不同 schema，不能
把 routing-only 投影直接冒充 admission 的物理验证结果。

## 下一步边界

本次不选定下一优化、不重做 D121/D132 微测、不增加 GPU 诊断。
先完成同一 D148 投影、curation、occupancy、结果表和备份，再根据真实
未达标阶段及上述源码事实，选一个可证伪的假设，并按计划补原始文献/官方
实现依据、最小验证及完整回放。3B、数值 adapter 和正式矩阵仍开放。
