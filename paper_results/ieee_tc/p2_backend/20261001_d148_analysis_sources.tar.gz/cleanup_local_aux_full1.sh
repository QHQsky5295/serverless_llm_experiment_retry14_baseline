#!/usr/bin/env bash
set -euo pipefail
unit=primelora-tc-aux-8af03bdfb52a4e19ae9ce74839358f58.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 92607fdb22fd404b82a5ba55c99a8403
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-8af03bdfb52a4e19ae9ce74839358f58.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
date -Is
