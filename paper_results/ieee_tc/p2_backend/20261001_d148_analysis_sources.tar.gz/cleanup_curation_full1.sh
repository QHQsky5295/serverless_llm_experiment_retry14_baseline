#!/usr/bin/env bash
set -euo pipefail
# Prepared for actual D148 curation; MUST wait for empty domain.
date -Is
unit=primelora-d148-full1-curate-20261001.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 56c5ac2607cf403c9e142ee6eac3e5f1
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d148-full1-curate-20261001.scope
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
