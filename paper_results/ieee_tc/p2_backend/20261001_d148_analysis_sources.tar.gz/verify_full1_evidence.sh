#!/usr/bin/env bash
# Reuse D145 closure protocol for observed D148 completion; no repeated tests.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d148_20261001
unit=primelora-d148-full1-evidence1-20261001.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_evidence_scope.txt"
export PYTHONUNBUFFERED=1
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python - <<'PY'
import csv, json, math, subprocess
from datetime import datetime, timezone
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d148_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
before = json.loads((raw/'prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    p = Path(name) if name.startswith('/') else root/name
    assert digest(p) == expected, name
assert len(before['source_sha256']) == 225
assert before['runtime_source_commit'] == '1eaf15a4eb82abd847b6b8cd08eff97b06b6ef24'
full = out/'20261001_d148_7b_full_w0_full1.json'
assert digest(full) == 'a0f8d157150b73fb4d36fa2e6d1a9549da05a0e4ee8de50577fa919d4706d535'
x = json.loads(full.read_text())
assert x['native_contract_completion_pass'] and not x['full_qualified']
assert not x['formal_performance_result'] and x['launcher_cleanup_pass']
assert x['execution_completed'] and x['cleanup']['complete']
launch = json.loads((raw/'7b_full_w0_full1/launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert all(launch[k] == 0 for k in ('service_returncode','replay_returncode','watchdog_returncode'))
assert x['population']['success'] == x['population']['native_contract_matched'] == 4000
assert x['population']['terminal'] == x['population']['planned'] == 4000
assert x['population']['failure_observations'] == {}
assert x['timing_validation']['requests'] == 4000
assert max(x['timing_validation']['max_error_ms'].values()) <= 1.0
assert x['timing_validation']['pass_tolerance'] and x['timing_validation']['violations'] == []
assert x['timing_validation']['requests_over_tolerance'] == 0
assert x['physical']['n_correct'] is None and not x['physical']['eligible_correctness']
assert x['physical']['measurement_complete'] and not x['physical']['open_lease_ids']
assert not x['observed_completion_boundaries']['client_response_observed']
assert x['quarantine']['events'] == x['quarantine']['released'] == 0
assert x['remote']['uuid_pairs'] == 132
assert not x['remote']['byte_mismatches'] and x['remote']['request_packing'] == 0
assert x['remote']['states'] == {'published':132}
assert x['remote']['client_received_bytes'] == x['remote']['server_socket_written_bytes'] == 131480060
assert x['readiness_evidence']['confirmed_pre_generation_requests'] == 4000
assert x['readiness_evidence']['conflicts'] == 0
comparison = x['d137_request_contract_comparison']
assert comparison['request_ids_identical'] and comparison['requests'] == 4000
for field, audit in comparison['fields'].items():
    if field == 'completion_token_ids_sha256':
        assert audit['equal_requests'] == 3890 and len(audit['changed_request_ids']) == 110
    else:
        assert audit['equal_requests'] == 4000 and audit['changed_request_ids'] == []
planning = x['planning_cpu_diagnostics']
assert planning['events'] == 2047
assert set(planning['by_operation']) == {'owned_execution_epoch'}
op = planning['by_operation']['owned_execution_epoch']
assert op['events'] == op['receipt_rows'] == 2047
assert op['state_counts'] == {'completed':2046, 'cancelled_result_discarded':1}
assert op['errors'] == {'CancelledError':1}
for removed in x['cleanup']['roots']:
    assert not Path(removed['path']).exists(), removed['path']
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == x['metric_protocol_sha256']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
reused, checked = [], 0
for ref in x['source_refs']:
    p = Path(ref['path'])
    if p.name == 'experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d148_7b_full_w0_full1.json':
        st = p.stat()
        assert st.st_size == 15289629214 and st.st_mtime_ns <= full.stat().st_mtime_ns
        reused.append(dict(**ref,bytes=st.st_size,mtime_ns=st.st_mtime_ns,inode=st.st_ino,
                           verification='reuse_completed_curator_stream_hash_plus_stat'))
    else:
        assert digest(p) == ref['sha256'], ref['path']
        checked += 1
assert len(reused) == 1
failure = out/'20261001_d148_7b_full_w0_failure_breakdown.json'
f = json.loads(failure.read_text())
assert f['population'] == dict(planned=4000,success=4000,timeout=0,returned_error=0)
assert f['returned_categories'] == {}
assert f['failure_observation_clock_id'] == x['physical']['clock_id']
assert f['projection_sha256'] == digest(raw/'full_full1_request_projection.json')
assert f['source_script_sha256'] == digest(raw/'collect_full1_failure_breakdown.py')
assert not f['timeout_requests'] and not f['returned_requests']
assert f['returned_generation_submission_states'] == {}
assert f['returned_error_messages'] == {}
assert f['first_timeout'] is None and f['first_returned_error'] is None
occupancy_dir = out/'20261001_d148_control_occupancy'
occupancy = json.loads((occupancy_dir/'summary.json').read_text())
assert occupancy['population'] == dict(planned=4000,terminal=4000,native_success=4000,failed=0)
assert occupancy['phase_population'] == 'complete_native_success_population' and occupancy['failures'] == []
for ref in occupancy['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256']
phases = occupancy['phase_summaries']
assert all(v['n'] == 4000 for v in phases.values())
phase_sum = math.fsum(phases[k]['total_request_seconds'] for k in (
    'gate_to_source_admission','source_to_native_dispatch','native_dispatch_to_last_token',
    'last_token_to_controller_completion','controller_completion_to_terminal'))
assert math.isclose(phase_sum,phases['gate_to_terminal']['total_request_seconds'],abs_tol=1e-6)
with (occupancy_dir/'request_occupancy.csv').open() as h:
    rows = list(csv.DictReader(h))
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
controls = occupancy['control_observations']
assert controls['source_event_count'] == 2015 and controls['in_request_window_count'] == 2014
assert len(controls['outside_request_window']) == 1
assert sum(v['samples'] for v in controls['by_phase'].values()) == 2014
assert controls['outside_request_window'][0]['boundary'] == 'after_request_window'
for filename in ('full_full1_projection_time.txt','full_full1_curation_time.txt',
                 'full_full1_failure_time.txt','full_full1_metadata_time.txt','audit_time1.txt'):
    assert 'Exit status: 0' in (raw/filename).read_text(), filename
# Post-cleanup readback, not a reconstructed historical cleanup stdout.
stage_ids = {
 'metadata':('primelora-d148-full1-metadata-20261001.scope','full_full1_metadata_scope.txt','5a33144d8c984a1ea5854865ead8883e'),
 'projection':('primelora-d148-full1-project-20261001.scope','full_full1_projection_scope.txt','b950242006254cc986cfc50f9ff71342'),
 'curation':('primelora-d148-full1-curate-20261001.scope','full_full1_curation_scope.txt','56c5ac2607cf403c9e142ee6eac3e5f1'),
 'occupancy':('primelora-d148-occupancy1-20261001.scope','scope_before1.txt','d13fd7de43374752a77243f587fde700')}
post_cleanup = []
for stage,(unit,filename,invocation) in stage_ids.items():
    assert 'InvocationID='+invocation in (raw/filename).read_text()
    active = subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()
    assert active == 'inactive', unit
    post_cleanup.append(dict(stage=stage,unit=unit,historical_invocation=invocation,
        scope_receipt=filename,current_state=active,verification='post_cleanup_readback_not_original_stdout'))
receipt_lines = (raw/'cleanup_occupancy_full1.log').read_text().splitlines()
names = {'low','high','max','oom','oom_kill','oom_group_kill'}
events = dict(line.split() for line in receipt_lines if len(line.split())==2 and line.split()[0] in names)
assert set(events) == names and all(int(v)==0 for v in events.values())
# Existing unchanged analysis regression is reused, not rerun to pad work.
prior = out/'20261001_d137_evidence_verification.json'
assert digest(prior) == '18b496f98daf9aa48aab8d98d68b75507df33798bd8b29b470e75d3a98da4c17'
assert json.loads(prior.read_text())['pass_checks']
refs = [full,failure,prior,raw/'collect_full1_failure_breakdown.py',raw/'full_full1_failure_time.txt',
        raw/'summarize_full_full1.py',raw/'verify_full1_evidence.sh',raw/'full_full1_curation_time.txt',
        raw/'run_occupancy_audit1.sh',raw/'cleanup_occupancy_full1.sh',raw/'cleanup_occupancy_full1.log',
        raw/'scope_before1.txt',raw/'audit_time1.txt',root/'docs/ieee_tc/D148_FULL_W0_FULL1.md',
        root/'scripts/analyze_control_path_overhead.py',root/'tests/test_ieee_tc_control_timeline.py',
        raw/'full_full1_metadata_compaction.sha256']
refs += [raw/name for _,name,_ in stage_ids.values()]
maintenance = {
 'public_download_cache_audit1.json':'3b7ebafd2420aa73f5575eafbac26ad87a1b4e9e098b5651d7c576314356cd5b',
 'public_download_cache_complete1.json':'537784465d396ce18eae77fec0c8cabe3e07a1693a09770b1e2e38993ff4d339'}
for name, expected in maintenance.items():
    assert digest(raw/name) == expected, name
refs += [raw/name for name in (*maintenance, 'public_download_cache_operations1.jsonl',
 'audit_public_download_cache.py','postcleanup_readonly_source_audit1.md',
 'cleanup_projection_full1.sh','cleanup_curation_full1.sh')]
refs += [out/'20261001_d137_7b_full_w0_full1.json',
         out/'20261001_d145_7b_full_w0_full1.json']
refs += [p for p in occupancy_dir.iterdir() if p.is_file()]
receipt = dict(kind='d148_full1_evidence_verification_v1',pass_checks=True,
    verified_at=datetime.now(timezone.utc).isoformat(),full_qualified=False,formal_performance_result=False,
    frozen_source_refs_checked=len(before['source_sha256']),curated_source_refs_rehashed=checked,
    reused_large_source_hash=reused,source_commit=before['runtime_source_commit'],
    protected=protected,post_cleanup_readback=post_cleanup,
    failed_population_preserved=True,prior_d145_timeout_root_cause_unresolved=True,
    regression_reused=str(prior),refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
dest = out/'20261001_d148_evidence_verification.json'
with dest.open('x') as h:
    json.dump(receipt,h,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(dest),sha256=digest(dest),frozen_sources=225,
    curated_sources_rehashed=checked,reused_large_source_hash=len(reused),protected=147)))
PY
