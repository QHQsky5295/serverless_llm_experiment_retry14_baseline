"""Reuse D174 exact-parent/retained-snapshot qualification for physical consumers.

Tiny CPU fixtures and Python copy timings only: no native RPC/CUDA/E2E claim.
"""
import ast
import copy
import csv
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import time
from types import SimpleNamespace
from unittest.mock import patch
import torch
from faaslora.memory import gpu_monitor as monitor
from faaslora.experiment.instance_pool import NativeSourceSnapshot
from tests.test_ieee_tc_worker_observation import NativeHostPhysicalProjection

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
PARENT = '5fadd45fb6a8be47c7a6e39ed65d8b1f4f2ecc4d'
previous = subprocess.check_output(['git', 'show', PARENT+':faaslora/memory/gpu_monitor.py'], cwd=ROOT)
cls = next(n for n in ast.parse(previous).body if isinstance(n, ast.ClassDef)
           and n.name == 'IEEEWorkerObservationExtension')
namespace = dict(vars(monitor))
exec(compile(ast.Module(body=[cls], type_ignores=[]), 'backed_5fadd45_extension', 'exec'), namespace)
old = namespace['IEEEWorkerObservationExtension'].ieee_gpu_reference
new = monitor.IEEEWorkerObservationExtension.ieee_gpu_reference
original = {name: getattr(torch.Tensor, name) for name in ('is_pinned', 'stride', 'element_size', 'storage_offset')}
cases = []
for case in ('shared', 'partial', 'packed', 'empty', 'staged_alias', 'unsupported_tensor', 'pinning_disagreement'):
    fixture = NativeHostPhysicalProjection()
    fixture.setUp()
    models = fixture.models
    if case == 'partial':
        models[8].loras['shared'].lora_a = models[8].loras['shared'].lora_a[:1, :4]
        models[8].loras['shared'].lora_b = models[8].loras['shared'].lora_b[:4, :1]
    elif case == 'packed':
        layer = models[8].loras['shared']
        models[8].loras = {'qkv': SimpleNamespace(lora_a=[layer.lora_a, None], lora_b=[layer.lora_b, None])}
    elif case == 'empty': models.clear()
    elif case == 'staged_alias':
        fixture.staged[9] = SimpleNamespace(id=9, rank=4, loras=models[8].loras)
    elif case == 'unsupported_tensor': models[8].loras['shared'].bias = torch.empty((4,))
    incompatible = models[7].loras['shared'].lora_b if case == 'pinning_disagreement' else None
    outputs, counts = {}, {}
    for name, function in (('parent', old), ('candidate', new)):
        calls = dict.fromkeys(original, 0)
        def wrapper(key):
            def counted(tensor, *args, **kwargs):
                calls[key] += 1
                if key == 'is_pinned' and incompatible is not None: return tensor is incompatible
                return original[key](tensor, *args, **kwargs)
            return counted
        with fixture.observations(), \
             patch.dict(namespace, {'_ieee_lora_pool_inventory': lambda *a, **kw: fixture.pool}), \
             patch.object(torch.Tensor, 'is_pinned', wrapper('is_pinned')), \
             patch.object(torch.Tensor, 'stride', wrapper('stride')), \
             patch.object(torch.Tensor, 'element_size', wrapper('element_size')), \
             patch.object(torch.Tensor, 'storage_offset', wrapper('storage_offset')):
            try: value = dict(result=function(fixture.worker, operation='source_snapshot'))
            except ValueError as error: value = dict(error_type=type(error).__name__, error=str(error))
        outputs[name], counts[name] = value, calls
    expected = copy.deepcopy(outputs['parent'])
    if 'result' in expected:
        for key in ('native_footprints', 'native_staging_footprints'):
            del expected['result'][key]['host_tensor_views']
    assert expected == outputs['candidate'], case
    assert counts['parent']['is_pinned'] == counts['candidate']['is_pinned']
    assert all(counts['candidate'][key] == 0 for key in original if key != 'is_pinned')
    cases.append(dict(case=case, all_other_fields_or_error_equal=True, work_counts=counts,
                      expected_error=outputs['parent'].get('error')))

source = RAW.parent/'d169_20261002/7b_probe1.json'
assert 0 < source.stat().st_size < 64*1024**2
raw = source.read_bytes()
source_sha = hashlib.sha256(raw).hexdigest()
assert source_sha == 'ead0c5c81acc52c502874e9d45cfba111665f875220e23467c2e716a0d770602'
snapshots = [row['sources_before'] for row in json.loads(raw)['warm_batches']]
del raw
assert len(snapshots) == 4
rows, timings = [], []
for index, full in enumerate(snapshots):
    projected = {**full}
    for key in ('native_footprints', 'native_staging_footprints'):
        projected[key] = {k: v for k, v in full[key].items() if k != 'host_tensor_views'}
    for key in set(full) - {'native_footprints', 'native_staging_footprints'}:
        assert full[key] == projected[key]
    a = NativeSourceSnapshot.from_native(full, expected_clock_id=full['clock_id'],
                                        received_monotonic_s=full['captured_monotonic_s']+1.)
    b = NativeSourceSnapshot.from_native(projected, expected_clock_id=full['clock_id'],
                                        received_monotonic_s=full['captured_monotonic_s']+1.)
    assert a == b
    # Replay the retained allocator counters, not current machine state. The
    # consumer must give the same answer with/without descriptive HOST views.
    saved = full['native_host_allocator']
    assert saved['available'] is True
    stats = {'allocated_bytes.current': saved['pinned_allocated_bytes'],
             'active_bytes.current': saved['pinned_active_bytes'],
             'allocations.current': saved['pinned_blocks'],
             'active_requests.current': saved['pinned_active_blocks']}
    with patch.object(monitor, 'torch', SimpleNamespace(cuda=SimpleNamespace(host_memory_stats=lambda: stats))):
        before = monitor._ieee_pinned_host_observation(full['native_staging_footprints'])
        after = monitor._ieee_pinned_host_observation(projected['native_staging_footprints'])
    assert before == after == saved
    # Current empty-staging branch copies only HOST inventory, not GPU pool.
    assert full['native_staging_footprints']['host_staged_adapter_ids'] == []
    values = {'parent': full['native_staging_footprints'],
              'candidate': projected['native_staging_footprints']}
    for value in values.values(): copy.deepcopy(value)  # One common warmup.
    for block in range(3):
        order = ('parent', 'candidate') if block % 2 == 0 else ('candidate', 'parent')
        for label in order:
            start = time.perf_counter_ns()
            for _ in range(10): copied = copy.deepcopy(values[label])
            elapsed = (time.perf_counter_ns()-start)/1e6/10
            assert copied == values[label]
            timings.append(dict(snapshot=index, block=block, variant=label, mean_copy_ms=elapsed))
    encoded = lambda value: len(json.dumps(value, ensure_ascii=True, allow_nan=False, separators=(',', ':')).encode())
    ms = {label: statistics.median(r['mean_copy_ms'] for r in timings
          if r['snapshot'] == index and r['variant'] == label) for label in values}
    rows.append(dict(snapshot=index, registered_adapters=len(a.registered_cpu_adapter_ids),
        host_views=len(values['parent']['host_tensor_views']),
        json_bytes_before=encoded(full), json_bytes_after=encoded(projected),
        host_deepcopy_before_ms=ms['parent'], host_deepcopy_after_ms=ms['candidate'],
        host_deepcopy_reduction_fraction=(ms['parent']-ms['candidate'])/ms['parent'],
        exact_source_and_allocator_equal=True))
result = dict(kind='d202_physical_host_projection_component_v1', parent_commit=PARENT,
    original_monitor_sha256=hashlib.sha256(previous).hexdigest(), torch_version=torch.__version__,
    cases=cases, source=str(source), source_sha256=source_sha, retained_snapshots=rows,
    timing_blocks=timings, cuda_executed=False, end_to_end_performance_measured=False,
    caveat='Saved physical states, CPU tiny storages, Python deepcopy only; not actual native RPC bytes/time or workload repeats. Mocked owner and allocator counters are not CUDA qualification.')
with (RAW/'probe2.json').open('x') as stream: json.dump(result, stream, indent=2, allow_nan=False)
with (RAW/'probe2.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader(); writer.writerows(rows)
print(json.dumps(result, indent=2))
