"""D198 bounded qualification sealing, adapted to D202 physical HOST consumers."""
import ast
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT = Path.cwd()
RAW = ROOT/'results/ieee_tc/p2_backend_qualification/d202_20261003'
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX = '20261003_d202_physical_host'
PARENT = '5fadd45fb6a8be47c7a6e39ed65d8b1f4f2ecc4d'

def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()

monitor = 'faaslora/memory/gpu_monitor.py'
def tree(old):
    data = subprocess.check_output(['git', 'show', PARENT+':'+monitor]) if old else (ROOT/monitor).read_bytes()
    return ast.parse(data)

class StripAllowed(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        if node.name == 'ieee_gpu_reference': return None
        if node.name == '_ieee_lora_host_inventory':
            node.body = node.body[1:]  # Only its documentation changed.
        return node

assert ast.dump(StripAllowed().visit(tree(True))) == ast.dump(StripAllowed().visit(tree(False)))
changed = set(subprocess.check_output(['git','diff','--name-only',PARENT,'--','faaslora','scripts','configs/ieee_tc'],text=True).splitlines())
assert changed == {monitor}
for path in ('faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py',
             'faaslora/preloading/planning_cpu.py','faaslora/experiment/instance_pool.py',
             'faaslora/scheduling/resource_coordinator.py'):
    assert (ROOT/path).read_bytes() == subprocess.check_output(['git','show',PARENT+':'+path])
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()

rows, members = [], []
for phase in ('tests1', 'tests2', 'regression1', 'probe1', 'probe2'):
    unit = 'primelora-d202-'+phase+'-20261003.scope'
    receipt = dict(line.split('=',1) for line in (RAW/(phase+'_scope.txt')).read_text().splitlines())
    assert re.fullmatch('[0-9a-f]{32}', receipt['InvocationID'])
    assert receipt['MemoryHigh']=='3221225472' and receipt['MemoryMax']=='4294967296'
    assert receipt['MemorySwapMax']=='0'
    for prop, value in (('LoadState','not-found'),('InvocationID',''),('ControlGroup','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == value
    assert not Path('/sys/fs/cgroup'+receipt['ControlGroup']).exists()
    log = (RAW/(phase+'.log')).read_text()
    timing = (RAW/(phase+'_time.txt')).read_text()
    expected_exit = 1 if phase in ('tests1', 'probe1') else 0
    assert f'Exit status: {expected_exit}' in timing
    if phase == 'tests1':
        assert 'Ran 79 tests in 0.051s' in log and 'FAILED (failures=2, errors=1)' in log
        tests, elapsed, status = 79, .051, 'FAILED_fixture_corrected'
    elif phase == 'probe1':
        assert "AttributeError: 'types.SimpleNamespace' object has no attribute 'modules'" in log
        tests, elapsed, status = None, None, 'FAILED_fixture_namespace_corrected'
    elif phase == 'probe2':
        tests, elapsed, status = None, None, 'PASS'
    else:
        summary = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s\n\nOK$',log,re.M)
        assert len(summary)==1
        tests, elapsed = int(summary[0][0]), float(summary[0][1])
        assert tests == (79 if phase == 'tests2' else 1122)
        status='PASS'
    events = dict(line.split() for line in (RAW/(phase+'_memory_events.txt')).read_text().splitlines())
    assert all(int(v)==0 for v in events.values())
    assert (RAW/(phase+'_swap.txt')).read_text().strip()=='0'
    for when in ('before','after'):
        encoded=(RAW/(phase+'_protected_'+when+'.json')).read_text()
        prefix, payload=encoded.split('\n',1)
        assert re.fullmatch(r'INFO \d{2}-\d{2} \d{2}:\d{2}:\d{2} \[__init__\.py:216\] Automatically detected platform cuda\.',prefix)
        checked=json.loads(payload)
        assert checked['pass'] and checked['entry_count']==147
    with tarfile.open(RAW/(phase+'_sources.tar.gz'),'r:gz') as sources:
        for line in (RAW/(phase+'_sources.sha256')).read_text().splitlines():
            digest,path=line.split('  ',1)
            assert hashlib.sha256(sources.extractfile(path).read()).hexdigest()==digest
            if phase!='tests1' or not path.startswith('tests/'):
                assert sha(ROOT/path)==digest,path
    rows.append(dict(phase=phase,tests=tests,status=status,test_body_seconds=elapsed,
        invocation_id=receipt['InvocationID'],scope_absent=True,memory_events=events,
        memory_peak_bytes=int((RAW/(phase+'_memory_peak.txt')).read_text()),swap_bytes=0))
    members.extend(RAW/(phase+suffix) for suffix in ('.log','_scope.txt','_time.txt','_memory_events.txt',
        '_swap.txt','_memory_peak.txt','_protected_before.json','_protected_after.json','_sources.sha256','_sources.tar.gz'))

probe=json.loads((RAW/'probe2.json').read_text())
assert len(probe['cases'])==7 and len(probe['retained_snapshots'])==4 and len(probe['timing_blocks'])==24
assert sha(Path(probe['source']))==probe['source_sha256']
assert all(row['all_other_fields_or_error_equal'] for row in probe['cases'])
assert all(row['exact_source_and_allocator_equal'] for row in probe['retained_snapshots'])
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
assert protected['plan_sha256']=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
doc=ROOT/'docs/ieee_tc/D202_PHYSICAL_HOST_REPRESENTATION.md'
assert '状态：CPU 资格完成，普通 Full 待执行' in doc.read_text()
table=['# D202 physical HOST representation qualification','',
    'CPU qualification and saved-state copy component only; no inference gain or independent-run CI.','',
    '| Check | Tests | Result | Body seconds | Peak memory bytes |',
    '|---|---:|---|---:|---:|']
for row in rows:
    table.append(f"| {row['phase']} | {row['tests']} | {row['status']} | {row['test_body_seconds']} | {row['memory_peak_bytes']} |")
table+=['','| Snapshot | Adapters | Views omitted per HOST table | Full JSON bytes before/after | HOST deepcopy ms before/after |',
        '|---|---:|---:|---:|---:|']
for r in probe['retained_snapshots']:
    table.append(f"| {r['snapshot']} | {r['registered_adapters']} | {r['host_views']} | {r['json_bytes_before']}/{r['json_bytes_after']} | {r['host_deepcopy_before_ms']:.6f}/{r['host_deepcopy_after_ms']:.6f} |")
table+=['','Copy values are medians of three alternating-order blocks, ten copies per block;',
        'not CUDA inventory, RPC latency, end-to-end speedup or three workload repetitions.','']
with (OUT/(PREFIX+'_table.md')).open('x') as f: f.write('\n'.join(table))
with (OUT/(PREFIX+'.csv')).open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(probe['retained_snapshots'][0]),lineterminator='\n')
    writer.writeheader();writer.writerows(probe['retained_snapshots'])
members.extend(RAW/name for name in ('run_cpu.sh','run_probe2.sh','probe.py','probe2.py',
    'probe2.json','probe2.csv','curate.py','check_staged.py'))
members.extend((doc,ROOT/monitor,ROOT/'tests/test_ieee_tc_gpu_references.py',ROOT/'tests/test_ieee_tc_worker_observation.py'))
secret=(Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret)>16
def inspect(data,name):
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for item in archive.getmembers():
                assert item.isfile() and '..' not in Path(item.name).parts and not item.name.startswith('/')
                inspect(archive.extractfile(item).read(),item.name)
    if name.endswith('.py'): ast.parse(data,filename=name)
for path in members:
    inspect(path.read_bytes(),str(path))
    if path.suffix=='.sh': subprocess.run(['bash','-n',str(path)],check=True)
sources={str(p):sha(p) for p in members}
bundle=OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output,tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members: archive.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers())==len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(str(path.relative_to(ROOT))).read()).hexdigest()==sources[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as f: f.write(sha(bundle)+'  '+bundle.name+'\n')
result=dict(kind='d202_physical_host_projection_qualification_v1',parent=PARENT,
    status='cpu_qualified_ordinary_full_pending',tests=rows,component=probe,protected_after=protected,
    source_sha256=sources,native_owner_planner_admission_unchanged=True,
    runtime_change='Existing HOST graph-only projection selected in physical consumers; helper/isolated observation behavior unchanged.',
    gpu_execution=False,remote_operation=False,numeric_qualification=False,performance_accepted=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    table_sha256=sha(OUT/(PREFIX+'_table.md')),csv_sha256=sha(OUT/(PREFIX+'.csv')))
with (OUT/(PREFIX+'.json')).open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS',protected=147,curated_sha256=sha(OUT/(PREFIX+'.json')),
                     evidence_bundle=result['evidence_bundle']),indent=2))
