"""Reuse sealed D612 explicit-path publication for the bounded D674 audit."""
import ast
import hashlib
from pathlib import Path
import sys
source = Path(__file__).resolve().parent.parent/'d612_20261017/publish.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace('d612_w2_quality_resource_diagnosis', 'd674_proactive_host_inventory_audit')
replace('f72091155cd3bb258651fc461db11b9113c72faf', 'a3dab155b8aa2d90cd1ecd27fa26d7f19aefc20c')
replace("diagnosis=read(RAW/'diagnosis.json')", "diagnosis=read(RAW/'diagnosis2.json')")
replace("for name in ('analysis',):", "for name in ('analysis','analysis2'):")
replace("assert read(RAW/'analysis_receipt.json')['diagnosis_sha256']==p.digest(RAW/'diagnosis.json')",
        "assert read(RAW/'analysis2_receipt.json')['diagnosis_sha256']==p.digest(RAW/'diagnosis2.json')")
replace("assert sum(x['n'] for x in diagnosis['matched_transitions'].values())==8000//2",
        "assert diagnosis['ordinal_signature_crosscheck']['transactions']==982")
replace("assert diagnosis['runs']['D607']['all']['joint']==3762",
        "assert diagnosis['ordinal_signature_crosscheck']['first_second_same']==855")
replace("assert diagnosis['runs']['D611']['all']['joint']==3819",
        "assert diagnosis['ordinal_signature_crosscheck']['second_third_same']==982")
replace('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md', 'D674_PROACTIVE_HOST_INVENTORY_AUDIT.md')
replace("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']",
        """files += [doc,RAW.parent/'d660_20261018/close.py',
    RAW.parent/'d612_20261017/publish.py',
    RAW.parent/'d668_20261018/summarize_operations.py',
    RAW.parent/'d673_20261018/publication_receipt.json',
    RAW.parent/'d673_20261018/publication_closure.json']""")
replace('d612_reused_parent_closed_log_diagnosis_v1', 'd674_proactive_host_inventory_audit_v1')
replace('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
        'tc: isolate proactive HOST postcheck repetition without stale storage reuse (D674)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('Sealed publication source and explicit D674 guards checked; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
