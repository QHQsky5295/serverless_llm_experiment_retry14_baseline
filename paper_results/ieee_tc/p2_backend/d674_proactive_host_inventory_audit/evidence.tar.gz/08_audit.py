"""Bounded D668 parent-call audit, reusing its sealed statistics implementation.

No inference, instrumentation, storage cache, or reconstructed request latency.
"""
import ast
import collections
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
BASE = ROOT/'paper_results/ieee_tc/p2_backend/d668_3b_host_inventory_prefix1/completion'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 32*1024*1024)
assert gate['preflight_pass'], gate['issues']
save(RAW/'analysis_resource_gate.json', gate)

source = RAW.parent/'d668_20261018/summarize_operations.py'
assert p.digest(source) == '19b885cb354ee2b7ba19957dc6852997cc6ec78afc0753ea074692a7a837551c'
tree = ast.parse(source.read_text())
stats_node, = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'stats']
exec(compile(ast.Module(body=[stats_node], type_ignores=[]), str(source), 'exec'))
inventory = BASE/'core_timing/host_inventory.csv'
assert p.digest(inventory) == '7704f5e8e0bc11bb87423a87d2d8fffa424349a85c25df58448f6ba55d9ee902'
with inventory.open() as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == 16329
assert len([r for r in rows if r['boundary'] == 'host_inventory']) == 9233
parents = collections.defaultdict(list)
for row in rows:
    if row['boundary'] == 'host_inventory':
        assert row['outcome'] == 'returned'
        parents[row['process'], row['parent']].append(row)
sequence_groups = collections.defaultdict(list)
for key, items in parents.items():
    items.sort(key=lambda r: int(r['begin_ns']))
    assert len({r['label'] for r in items}) == len({r['state'] for r in items}) == 1
    assert all(int(a['end_ns']) <= int(b['begin_ns']) for a,b in zip(items,items[1:]))
    seq = tuple(r['scope'] for r in items)
    sequence_groups[items[0]['label'], items[0]['state'], seq].append(items)

sequences = []
for (label,state,seq), transactions in sorted(sequence_groups.items()):
    flat = [r for items in transactions for r in items]
    summary = stats(flat)
    assert summary['unique_parents'] == len(transactions)
    sequences.append(dict(label=label, state=state, inventory_scopes=list(seq),
        transactions=len(transactions), all_inventory=summary,
        ordinal_inventory=[stats([items[index] for items in transactions])
                           for index in range(len(seq))],
        counts_and_bytes_equal=sum(len({(r['adapter_count'],r['allocation_count'],r['storage_bytes'])
                                       for r in items}) == 1 for items in transactions)))

registered = 'native_registered_tensor_storage_capacity'
candidate = [row for row in sequences if row['label'] == 'UTILITY/ieee_prepare_host//'
             and row['inventory_scopes'] == [registered]*3]
assert len(candidate) == 2
other_prepare = [row for row in sequences if row['label'] == 'UTILITY/ieee_prepare_host//'
                 and row not in candidate]
assert sum(row['transactions'] for row in candidate+other_prepare) == 982
assert sum(row['all_inventory']['count'] for row in candidate+other_prepare) == 2946

refs = [Path(__file__), source, inventory, BASE/'operation_detail1/operations.csv',
    ROOT/'faaslora/memory/gpu_monitor.py', ROOT/'faaslora/memory/residency_manager.py',
    ROOT/'faaslora/scheduling/vllm_ieee_scheduler.py', ROOT/'faaslora/scheduling/core_interleave.py',
    ROOT/'docs/ieee_tc/D329_HOST_STORAGE_DEPENDENCY_AUDIT.md',
    ROOT/'docs/ieee_tc/D352_TRANSACTION_LOCAL_HOST_EVIDENCE.md',
    ROOT/'docs/ieee_tc/D663_REGISTERED_HOST_TRANSACTION.md',
    ROOT/'docs/ieee_tc/D671_INDEPENDENT_HOST_GRAPH_COPY.md',
    ROOT/'docs/ieee_tc/D673_3B_RESIDUAL_SLO_AND_SCALING_PATH.md',
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
native = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')
refs += [native/'lora/worker_manager.py', native/'lora/model_manager.py',
         native/'v1/engine/core.py', native/'v1/executor/uniproc_executor.py']
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
diagnosis = dict(passed=True, kind='d674_same_transaction_host_inventory_audit_v1',
    inference_runs_added=0, production_changed=False, n_correct=None, ranking_eligible=False,
    source_refs=[dict(path=str(path),sha256=p.digest(path)) for path in refs],
    processes=len({r['process'] for r in rows}), inventory_rows=9233,
    sequences=sequences, candidate_registered_proactive=candidate,
    other_prepare_sequences=other_prepare,
    decision='qualify_registered_proactive_postcheck_reuse_only',
    excluded=['cross_call_epoch_or_ttl_cache','changed_staged_registration',
              'file_to_host_mutation','cost_provider_precheck_fusion_in_this_candidate',
              'repeat_D668_profiling','change_metric_thresholds'],
    caveats=[
        'D668 is a profiled 1000-request prefix, not D672 full-run call frequency.',
        'Counts/bytes equality does not prove tensor or pinning immutability.',
        'Ordinal wall totals overlap parent and request intervals; never subtract them from latency.',
        'The third scan is selected for path qualification, not yet eliminated or measured faster.',
        'Storage must be newly observed on every transaction; allocator and workspace must remain fresh.',
        'D663 demand witness does not by itself qualify the proactive pitched-copy path.'
    ], protected=protected)
save(RAW/'diagnosis.json', diagnosis)
save(RAW/'analysis_receipt.json', dict(passed=True, identity=identity,
    diagnosis_sha256=p.digest(RAW/'diagnosis.json'), resources={k:(group/k).read_text().strip()
    for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True, sequences=len(sequences), candidate=candidate,
                      other_prepare=other_prepare), ensure_ascii=False))
