"""Correct only a mismatched source path/SHA pair; preserve both original audits."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as stream:json.dump(data,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
original=RAW/'diagnosis2.json'
assert p.digest(original)=='3b15163251519783e35f2de35e134fcf518edddc61643dc592cc2422430a155c'
diagnosis=json.loads(original.read_text())
bad=diagnosis['source_refs'][-1]
assert bad==dict(path=str(RAW.parent/'d668_20261018/summarize_operations.py'),
    sha256='71b7192c565f144063c169ee65b88f12b035969506ba6f88f04749eff252e3af')
diagnosis['source_refs'][-1]=dict(path=str(RAW/'audit.py'),sha256=bad['sha256'])
diagnosis['source_refs'] += [dict(path=str(path),sha256=p.digest(path))
    for path in (Path(__file__),original)]
for row in diagnosis['source_refs']:
    assert p.digest(Path(row['path']))==row['sha256'],row['path']
diagnosis['provenance_correction']=dict(original=str(original),
    reason='audit2 expansion reused the source variable for D668; last path paired with audit.py SHA',
    old_pair=bad, corrected_pair=diagnosis['source_refs'][-3],
    observations_or_counts_changed=False, production_changed=False)
save(RAW/'diagnosis3.json',diagnosis)
save(RAW/'qualification_receipt.json',dict(passed=True,identity=identity,
    diagnosis_sha256=p.digest(RAW/'diagnosis3.json'),
    resources={k:(group/k).read_text().strip() for k in
               ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,source_refs_verified=len(diagnosis['source_refs']),
    diagnosis_sha256=p.digest(RAW/'diagnosis3.json'),observations_changed=False)))
