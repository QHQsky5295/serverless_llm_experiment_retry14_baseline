"""Refine the saved D674 sequence audit: equal scope is not unchanged storage."""
import ast
import hashlib
from pathlib import Path
source = Path(__file__).resolve().parent/'audit.py'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == '71b7192c565f144063c169ee65b88f12b035969506ba6f88f04749eff252e3af'
code = data.decode()
for old,new in (('analysis_identity.json','analysis2_identity.json'),
                ('analysis_resource_gate.json','analysis2_resource_gate.json'),
                ('analysis_receipt.json','analysis2_receipt.json'),
                ('diagnosis.json','diagnosis2.json')):
    assert old in code
    code = code.replace(old,new)
anchor = "save(RAW/'diagnosis2.json', diagnosis)"
assert code.count(anchor) == 1
code = code.replace(anchor, """
prepare = [items for items in parents.values() if items[0]['label']=='UTILITY/ieee_prepare_host//']
assert len(prepare)==982 and all(len(items)==3 for items in prepare)
def signature(row):
    return row['scope'],row['adapter_count'],row['allocation_count'],row['storage_bytes']
pairs = dict(transactions=len(prepare),
    first_second_same=sum(signature(r[0])==signature(r[1]) for r in prepare),
    second_third_same=sum(signature(r[1])==signature(r[2]) for r in prepare),
    three_registered_scope=sum(all(r['scope']==registered for r in items) for items in prepare),
    three_registered_scope_but_first_second_changed=sum(
        all(r['scope']==registered for r in items) and signature(items[0])!=signature(items[1])
        for items in prepare))
assert pairs==dict(transactions=982,first_second_same=855,second_third_same=982,
    three_registered_scope=942,three_registered_scope_but_first_second_changed=87)
diagnosis['ordinal_signature_crosscheck']=pairs
diagnosis['caveats'].append('87 same-registered-scope operations changed observed counts/bytes between scans one and two; no reuse across this boundary.')
diagnosis['source_refs'].append(dict(path=str(source),sha256=hashlib.sha256(data).hexdigest()))
"""+anchor)
code = code.replace("print(json.dumps(dict(passed=True, sequences=len(sequences), candidate=candidate,\n                      other_prepare=other_prepare), ensure_ascii=False))",
                    "print(json.dumps(dict(passed=True,ordinal_signature_crosscheck=pairs)))")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
