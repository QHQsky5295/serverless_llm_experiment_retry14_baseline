"""Use the verified D674 provenance correction; retain first publication failure."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path(__file__).resolve().parent/'publish.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='df846fc86e50e3148f2b08a5698221632a5253edac4a0590e810c558cb62e75a'
code=data.decode()
head=code[:code.index("if sys.argv[1:] == ['--check-only']:")]
ns={'__file__':__file__,'__name__':'__d674_publish2_expansion__'}
exec(compile(head,str(source),'exec'),ns)
expanded=ns['code']
for old,new in (('publication_identity.json','publication2_identity.json'),
                ('publication_resource_gate.json','publication2_resource_gate.json'),
                ('publication_receipt.json','publication2_receipt.json'),
                ("diagnosis=read(RAW/'diagnosis2.json')","diagnosis=read(RAW/'diagnosis3.json')"),
                ("for name in ('analysis','analysis2'):","for name in ('analysis','analysis2','qualification','publication'):"),
                ("assert read(RAW/'analysis2_receipt.json')['diagnosis_sha256']==p.digest(RAW/'diagnosis2.json')",
                 "assert read(RAW/'qualification_receipt.json')['diagnosis_sha256']==p.digest(RAW/'diagnosis3.json')")):
    assert old in expanded,old
    expanded=expanded.replace(old,new)
# Keep the exact earlier D673 receipt name; only this campaign's output changes.
expanded=expanded.replace("RAW.parent/'d673_20261018/publication2_receipt.json'",
                          "RAW.parent/'d673_20261018/publication_receipt.json'")
ast.parse(expanded)
if sys.argv[1:]==['--check-only']:
    print('Repaired provenance and explicit-path publication AST checked.')
elif not sys.argv[1:]:
    exec(compile(expanded,str(source),'exec'),globals())
else:
    raise SystemExit('expected no arguments or --check-only')
