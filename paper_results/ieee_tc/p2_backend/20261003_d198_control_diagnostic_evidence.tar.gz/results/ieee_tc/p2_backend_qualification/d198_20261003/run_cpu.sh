#!/usr/bin/env bash
# D198 bounded CPU qualification, reusing D184's resource/test entry.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
case "$phase" in tests1|tests2|regression1|regression2) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d198_20261003
unit="primelora-d198-${phase}-20261003.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/${phase}_scope.txt"
sources=(scripts/run_all_experiments.py faaslora/memory/gpu_monitor.py
  faaslora/utils/logger.py tests/test_ieee_tc_control_diagnostic.py tests/test_ieee_tc_stack_diagnostic.py
  tests/test_ieee_tc_planning_snapshot.py tests/test_ieee_tc_transfer_pressure.py
  tests/test_ieee_tc_planning_cpu.py tests/test_ieee_tc_gpu_references.py
  tests/test_ieee_tc_worker_observation.py scripts/dedicated_engine_worker.py
  faaslora/preloading/planning_cpu.py faaslora/preloading/preloading_planner.py "$raw/run_cpu.sh")
sha256sum "${sources[@]}" > "$raw/${phase}_sources.sha256"
tar -czf "$raw/${phase}_sources.tar.gz" "${sources[@]}"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
"$python" scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "$raw/${phase}_protected_before.json"
if test "$phase" = tests1 || test "$phase" = tests2; then
  args=(-m unittest tests.test_ieee_tc_control_diagnostic tests.test_ieee_tc_stack_diagnostic tests.test_ieee_tc_request_footprints tests.test_ieee_tc_planning_snapshot -v)
else
  args=(-m unittest tests.test_ieee_tc_control_diagnostic tests.test_ieee_tc_stack_diagnostic tests.test_ieee_tc_rpc_breakdown tests.test_ieee_tc_planning_snapshot tests.test_ieee_tc_static_preparation tests.test_ieee_tc_file_observation
    tests.test_http_artifact_store tests.test_ieee_tc_pending_gpu_pipeline tests.test_ieee_tc_pending_admission
    tests.test_ieee_tc_request_footprints tests.test_ieee_tc_identity_recheck
    tests.test_ieee_tc_request_lifecycle tests.test_ieee_tc_service_routing
    tests.test_ieee_tc_service_events tests.test_ieee_tc_native_retirement
    tests.test_ieee_tc_gpu_references tests.test_ieee_tc_worker_observation
    tests.test_ieee_tc_transfer_pressure tests.test_ieee_tc_planning_cpu tests.test_basic_smoke -v)
fi
set +e
/usr/bin/time -v -o "$raw/${phase}_time.txt" "$python" "${args[@]}" > "$raw/${phase}.log" 2>&1
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/${phase}_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/${phase}_swap.txt"
"$python" scripts/ieee_tc_preflight.py verify --seal paper_results/ieee_tc/safety/20260925_execution_start_protected.json > "$raw/${phase}_protected_after.json"
exit "$code"
