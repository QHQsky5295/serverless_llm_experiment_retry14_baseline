"""D188 evidence delivery reused for D198 CPU qualification (no microbenchmark)."""
import ast
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT = Path.cwd()
RAW = ROOT/'results/ieee_tc/p2_backend_qualification/d198_20261003'
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX = '20261003_d198_control_diagnostic'
PARENT = '81f998c9c36f98cbbfece56807d87c0d05129a74'

def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()

def tree(path, old=False):
    data = subprocess.check_output(['git','show',PARENT+':'+path]) if old else (ROOT/path).read_bytes()
    return ast.parse(data, filename=path)

def stripped(node, class_name, methods, extra=(), imports=()):
    node = copy.deepcopy(node)
    node.body = [item for item in node.body if not (
        isinstance(item, (ast.ClassDef, ast.FunctionDef)) and item.name in extra) and not (
        isinstance(item, ast.ImportFrom) and item.module in imports)]
    cls = next(item for item in node.body if isinstance(item, ast.ClassDef) and item.name == class_name)
    cls.body = [item for item in cls.body if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
                or item.name not in methods]
    return ast.dump(node, include_attributes=False)

runner = 'scripts/run_all_experiments.py'
monitor = 'faaslora/memory/gpu_monitor.py'
worker = 'scripts/dedicated_engine_worker.py'
logger = 'faaslora/utils/logger.py'
allowed_functions = {
    runner: {'InferenceEngine.ieee_gpu_reference', 'InferenceEngine.ieee_request_sources',
             'SubprocessInferenceEngineProxy._rpc'},
    monitor: {'IEEEWorkerObservationExtension.ieee_gpu_reference'},
    worker: {'_run_worker'},
    logger: {'diagnostic_control_enabled', 'diagnostic_control_event', 'enable_diagnostic_stack_sampling'},
}
class StripAllowed(ast.NodeTransformer):
    def __init__(self, allowed, imports=()):
        self.allowed, self.imports, self.scope = allowed, imports, []
    def visit_ClassDef(self, node):
        self.scope.append(node.name)
        self.generic_visit(node)
        self.scope.pop()
        return node
    def visit_FunctionDef(self, node):
        return None if '.'.join(self.scope+[node.name]) in self.allowed else node
    visit_AsyncFunctionDef = visit_FunctionDef
    def visit_ImportFrom(self, node):
        return None if node.module in self.imports else node
for path, methods in allowed_functions.items():
    imports = ('utils.logger',) if path == monitor else ()
    assert ast.dump(StripAllowed(methods, imports).visit(tree(path, True))) == ast.dump(
        StripAllowed(methods, imports).visit(tree(path))), path
changed = set(subprocess.check_output(['git','diff','--name-only',PARENT,'--','faaslora','scripts','configs/ieee_tc'],text=True).splitlines())
assert changed == set(allowed_functions)
for path in ('faaslora/memory/residency_manager.py','faaslora/preloading/preloading_planner.py',
             'faaslora/preloading/planning_cpu.py','faaslora/experiment/instance_pool.py',
             'faaslora/scheduling/resource_coordinator.py'):
    assert (ROOT/path).read_bytes() == subprocess.check_output(['git','show',PARENT+':'+path])
archive = ROOT/'docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D197_20261003.md'
assert sha(archive) == '3ff837acaf1d7ca1fe513afbf969fc12fb6034a665253004baefc50d4ae43639'

assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
rows = []
identities = {'tests1':'63d3ac2a573843668c7295e326df82f1',
              'regression1':'29cd7d6a3c03410687302bdd4caa1613'}
members = []
for phase, identity in identities.items():
    unit = 'primelora-d198-'+phase+'-20261003.scope'
    for prop, value in (('LoadState','not-found'),('InvocationID',''),('ControlGroup','')):
        assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == value
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    assert 'InvocationID='+identity in (RAW/(phase+'_scope.txt')).read_text()
    log = (RAW/(phase+'.log')).read_text()
    summary = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s\n\nOK$',log,re.M)
    assert len(summary) == 1
    count, elapsed = summary[0]
    timing = (RAW/(phase+'_time.txt')).read_text()
    assert 'Exit status: 0' in timing
    events = dict(line.split() for line in (RAW/(phase+'_memory_events.txt')).read_text().splitlines())
    assert all(int(v) == 0 for v in events.values())
    assert (RAW/(phase+'_swap.txt')).read_text().strip() == '0'
    for when in ('before','after'):
        encoded = (RAW/(phase+'_protected_'+when+'.json')).read_text()
        # Qualified CPU environment writes this single platform notice on
        # stdout before the preflight JSON. Reject any other prefix/trailer.
        prefix, payload = encoded.split('\n', 1)
        assert re.fullmatch(r'INFO \d{2}-\d{2} \d{2}:\d{2}:\d{2} \[__init__\.py:216\] Automatically detected platform cuda\.', prefix)
        checked = json.loads(payload)
        assert checked['pass'] and checked['entry_count'] == 147
    for line in (RAW/(phase+'_sources.sha256')).read_text().splitlines():
        digest, path = line.split('  ',1)
        assert sha(ROOT/path) == digest
    rows.append(dict(phase=phase,tests=int(count),status='PASS',test_body_seconds=float(elapsed),
        command_elapsed=re.search(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\): (\S+)',timing).group(1),
        max_rss_kib=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',timing).group(1)),
        invocation_id=identity,scope_absent=True,memory_events=events,swap_bytes=0))
    members.extend(RAW/(phase+suffix) for suffix in ('.log','_scope.txt','_time.txt','_memory_events.txt',
        '_swap.txt','_protected_before.json','_protected_after.json','_sources.sha256','_sources.tar.gz'))

assert [row['tests'] for row in rows] == [40, 1100]
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert protected['plan_sha256'] == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
doc = ROOT/'docs/ieee_tc/D198_CONTROL_BOUNDARY_DIAGNOSTIC.md'
assert f"| 新增诊断及相关状态/传输检查 | {rows[0]['tests']} | 全通过 | {rows[0]['test_body_seconds']:.3f} |" in doc.read_text()
assert f"| 完整请求/owner/规划/取消及诊断回归 | {rows[1]['tests']} | 全通过 | {rows[1]['test_body_seconds']:.3f} |" in doc.read_text()
table = ['# D198 CPU qualification', '', 'No inference, performance claim or independent seed CI.', '',
         '| Check | Tests | Result | Body seconds | Command elapsed | Peak RSS KiB |',
         '|---|---:|---|---:|---|---:|']
for row in rows:
    table.append(f"| {row['phase']} | {row['tests']} | PASS | {row['test_body_seconds']:.3f} | {row['command_elapsed']} | {row['max_rss_kib']} |")
with (OUT/(PREFIX+'.csv')).open('x',newline='') as f:
    keys=('phase','tests','status','test_body_seconds','command_elapsed','max_rss_kib','invocation_id','scope_absent','swap_bytes')
    writer=csv.DictWriter(f,fieldnames=keys,lineterminator='\n')
    writer.writeheader()
    writer.writerows({k:row[k] for k in keys} for row in rows)
with (OUT/(PREFIX+'_table.md')).open('x') as f:
    f.write('\n'.join(table)+'\n')
members.extend(RAW/name for name in ('run_cpu.sh','curate.py','run_curate.sh','check_staged.py'))
members.extend((doc, ROOT/'tests/test_ieee_tc_control_diagnostic.py',
    ROOT/'tests/test_ieee_tc_stack_diagnostic.py', ROOT/monitor, ROOT/runner,
    ROOT/worker, ROOT/logger))
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret) > 16
def inspect(data,name):
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for member in archive.getmembers():
                assert member.isfile() and '..' not in Path(member.name).parts and not member.name.startswith('/')
                inspect(archive.extractfile(member).read(),member.name)
    if name.endswith('.py'):
        ast.parse(data,filename=name)
for path in members:
    inspect(path.read_bytes(),str(path))
    if path.suffix == '.sh':
        subprocess.run(['bash','-n',str(path)],check=True)
sources={str(p):sha(p) for p in members}
bundle=OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output, tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members:
        archive.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers()) == len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(str(path.relative_to(ROOT))).read()).hexdigest() == sources[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as f:
    f.write(sha(bundle)+'  '+bundle.name+'\n')
result=dict(kind='d198_control_diagnostic_qualification_v1',parent=PARENT,
    status='cpu_qualified_diagnostic_prefix_pending',tests=rows,protected_after=protected,
    source_sha256=sources,scope_ast_check='PASS: explicit diagnostic boundaries in four files; all other runtime AST unchanged',
    native_owner_planner_admission_unchanged=True,production_changed=True,diagnostic_only=True,gpu_execution=False,remote_operation=False,
    numeric_qualification=False,performance_accepted=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    table_sha256=sha(OUT/(PREFIX+'_table.md')),csv_sha256=sha(OUT/(PREFIX+'.csv')))
with (OUT/(PREFIX+'.json')).open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS',tests=[r['tests'] for r in rows],protected=147,
    curated_sha256=sha(OUT/(PREFIX+'.json')),evidence_bundle=result['evidence_bundle']),indent=2))
