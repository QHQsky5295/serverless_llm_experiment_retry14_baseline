"""Reuse D169 qualification curation on a D96-style bounded projection."""
import csv
import json
import math
from pathlib import Path
from statistics import mean
from scripts.ieee_tc_preflight import (ROOT, digest, verify_seal, check_plan,
    validate_warm_native_sample, warm_reference_batches)

RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
def load(path):
    assert path.stat().st_size < 128*1024**2, str(path)
    return json.loads(path.read_text())

inputs=load(RAW/'inputs1.json')
data=load(RAW/'measurement_projection1.json')
launch=load(RAW/'7b_measure1_launch.json')
index_path=ROOT/'paper_results/ieee_tc/p2_backend/20261002_d168_warm_input_index.json'
index=load(index_path)
assert 'cleanup=automatic_removal_verified' in (RAW/'measure1_cleanup.txt').read_text()
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert data['config_sha256']==inputs['sources'][str(ROOT/'configs/ieee_tc/20261002_d169_7b_warm_reference.yaml')]
assert data['check_source_sha256']==inputs['sources'][str(ROOT/'scripts/ieee_tc_preflight.py')]
assert data['warm_reference_index_sha256']==digest(index_path)
assert data['warm_phase']=='measure' and data['batch_size']==8
expected=list(warm_reference_batches(index,'measure'))
batch_rows=[]
sample_rows=[]
for batch,spec in zip(data['warm_batches'],expected):
    assert all(batch[k]==spec[k] for k in ('group_id','batch_index','round','phase'))
    cases=[data['requests'][i] for i in batch['request_indices']]
    assert len(cases)==len(spec['selected'])==8
    complete=[]
    for c,selected in zip(cases,spec['selected']):
        assert all(c[k]==v for k,v in selected.items())
        assert c['batch_serial']==batch['serial']
        if c['pass_native']:
            measured=validate_warm_native_sample(c,c['timing'],c['actual_tokens'],c['reference']['adapter_int_id'])
            assert measured=={k:c[k] for k in measured}
            assert c['actual_tokens']==c['timing']['native_output_tokens']
            assert c['release']['released']
            assert c['reference']['adapter_int_id'] in batch['sources_before']['slot_adapter_ids']
            complete.append(c)
        sample_rows.append({k:c.get(k) for k in ('phase','round','group_id','batch_serial',
            'source_index','source_request_id','adapter_id','native_prompt_tokens',
            'target_tokens','actual_tokens','ttft_ms','tpot_ms','pass_native')})
    before=batch.get('scheduler_before',{})
    after=batch.get('scheduler_after',{})
    if batch['pass_native']:
        assert len(complete)==8 and batch['sources_before']['complete_for_native_caches']
        assert all(not s[k] for s in (before,after) for k in
            ('admitted','unretired_iterations','native_deferred_free_batches'))
        needed=sum(math.ceil((c['native_prompt_tokens']+c['target_tokens'])/before['kv_tokens_per_block']) for c in cases)
        assert needed==batch['full_declared_kv_blocks']<=before['kv_unreserved_free_blocks']
    batch_rows.append(dict(serial=batch['serial'],phase=batch['phase'],round=batch['round'],
        group_id=batch['group_id'],batch_index=batch['batch_index'],requests=len(cases),
        native_completed=len(complete),kv_full_context_required=batch.get('full_declared_kv_blocks'),
        kv_free_before=before.get('kv_unreserved_free_blocks'),kv_free_after=after.get('kv_unreserved_free_blocks'),
        all_decode_intersection_s=batch.get('all_decode_intersection_s'),passed=batch['pass_native']))

round_rows=[]
summary_rows=[]
if data['pass']:
    assert launch['pass'] and data['stage']=='complete' and data['shutdown_called']
    assert data['measured_warm_reference'] and data['calibration_candidate_complete']
    assert len(data['warm_batches'])==len(expected)==194
    assert len(data['requests'])==inputs['total_requests']==1552
    assert all(c['pass_native'] for c in data['requests'])
    assert sorted(i for b in data['warm_batches'] for i in b['request_indices'])==list(range(1552))
    assert not data['sources_after_eviction']['sources']
    assert all(a is None for a in data['sources_after_eviction']['slot_adapter_ids'])
    assert not data['common_reference_frozen'] and not data['formal_g1_g2_qualified']
    assert not data['semantic_full_pool_qualification']
    for group in index['groups']:
        gid=group['group_id']
        for rid in range(3):
            cases=[c for c in data['requests'] if c['phase']=='measurement' and c['group_id']==gid and c['round']==rid]
            assert len(cases)==256
            assert [c['source_index'] for c in cases]==[c['source_index'] for c in group['selected']]
            round_rows.append(dict(group_id=gid,round=rid,requests=len(cases),
                mean_native_ttft_ms=mean(c['ttft_ms'] for c in cases),
                mean_native_tpot_ms=mean(c['tpot_ms'] for c in cases)))
        current=[r for r in round_rows if r['group_id']==gid]
        t=mean(r['mean_native_ttft_ms'] for r in current)
        p=mean(r['mean_native_tpot_ms'] for r in current)
        summary_rows.append(dict(group_id=gid,lower_exclusive=group['lower_exclusive'],
            upper_inclusive=group['upper_inclusive'],samples_per_round=256,rounds=3,
            warm_ttft_ms=t,warm_tpot_ms=p,candidate_ttft_threshold_ms=5*t,
            candidate_tpot_threshold_ms=2*p))

physical=data.get('physical_allocation')
gpu_s=None
if physical:
    starts=[e['at'] for e in physical['events'] if e['event']=='acquire']
    ends=[e['at'] for e in physical['events'] if e['event']=='release']
    assert physical['released'] and len(starts)==len(ends)==len(physical['gpu_uuids'])==1
    gpu_s=ends[0]-starts[0]
watch=RAW/'7b_measure1_launch.launch/watchdog.jsonl'
with watch.open() as f: events=[json.loads(line) for line in f]
samples=[e for e in events if e['event']=='resource_sample']
assert samples
resource=dict(samples=len(samples),peak_memory_bytes=max(e['service']['memory.peak'] for e in samples),
    min_host_available_bytes=min(e['host']['available_bytes'] for e in samples),
    min_disk_free_bytes=min(p['free_bytes'] for e in samples for p in e['filesystems']),
    memory_events={k:max(e['service']['memory.events'][k] for e in samples)
                   for k in samples[0]['service']['memory.events']},
    max_swap_bytes=max(e['service']['memory.swap.current'] for e in samples),
    warnings=sum(e['decision']['warning'] for e in samples),
    aborts=[e['decision']['abort_reasons'] for e in samples if e['decision']['abort_reasons']])
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
refs=dict(inputs['sources'])
for name in ('inputs1.json','7b_measure1.json','7b_measure1_launch.json','measurement_projection1.json',
             'measure1_cleanup.txt','prepare.py','curate.py','run_cpu.sh','run_7b_measure1.sh',
             'project_warm.jq','project_measure1.sh','verify_measure_cleanup.sh'):
    refs[str(RAW/name)]=digest(RAW/name)
refs[str(watch)]=digest(watch)
result=dict(kind='d170_7b_common_warm_measurement_v1',passed=data['pass'],stage=data['stage'],
    error=data.get('error'),requested_measurements=1536,warmup_requests=16,
    native_completed=sum(c['pass_native'] for c in data['requests']),batch_size=8,
    round_means=round_rows,warm_threshold_candidates=summary_rows,
    physical_gpu_s=gpu_s,physical_released=bool(physical and physical['released']),
    service_returncode=launch['service_returncode'],watchdog_returncode=launch['watchdog_returncode'],
    actual_service_invocation=launch['service_identity']['invocation_id'],resource=resource,
    measured_warm_reference=bool(data['pass']),common_reference_frozen=False,n_correct=None,
    formal_g1_g2_qualified=False,semantic_full_pool_qualification=False,
    caveats=['Same-process repeated calibration rounds are not independent Full-run replicates.',
             'Common batch contract awaits 3B qualification; 7B candidates are not globally frozen.',
             'Native count and reference-ID checks do not close per-token numerical adapter identity.',
             'GPU-ready common metrology, not Prime Full or a performance comparison.'],
    plan_sha256=check_plan(),sources=refs,protected=protected)
with (OUT/'20261002_d170_warm_measurement.json').open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
for suffix,rows in (('rounds',round_rows),('thresholds',summary_rows),('batches',batch_rows),('samples',sample_rows)):
    if rows:
        with (OUT/f'20261002_d170_warm_{suffix}.csv').open('x',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
            writer.writeheader();writer.writerows(rows)
print(json.dumps({k:v for k,v in result.items() if k not in ('sources','protected')},indent=2))
