"""D168 exact-scope staged secret check reused for D170."""
import io
from pathlib import Path
import re
import subprocess
import tarfile

paths = subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().split('\0')[:-1]
allowed = {'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D170_WARM_REFERENCE_MEASUREMENT.md',
           'scripts/ieee_tc_preflight.py','tests/test_ieee_tc_warm_reference.py'}
allowed.add('configs/ieee_tc/20261002_d170_7b_warm_reference.yaml')
assert len(paths) == 11
assert all(p in allowed or p.startswith('paper_results/ieee_tc/p2_backend/20261002_d170_') for p in paths)
assert 'configs/generated/lora_manifest_1000.json' not in paths
token = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(token) > 16
count = 0
def inspect(data,name):
    global count
    assert token not in data, 'credential content found'
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    count += 1
    if name.endswith('.tar.gz'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
            for member in archive.getmembers():
                assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
                inspect(archive.extractfile(member).read(),member.name)
for path in paths:
    inspect(subprocess.check_output(['git','show',':'+path]),path)
print(f'PASS: {len(paths)} scoped files; {count} staged/archive entries checked; user manifest absent')
