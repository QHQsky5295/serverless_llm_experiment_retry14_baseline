# Reuse D96 streaming projection; retain every request, including failed ones.
# Only repeated per-batch tensor/source inventories are projected. Preserve the
# actual GPU-slot, cache-completeness and ownership facts used in validation.
reduce inputs as $item
  ({};
   if ($item | length) != 2 then .
   else $item[0] as $p | $item[1] as $v |
     if $p[0] == "warm_batches" and $p[2] == "sources_before" then
       if (["owner_id", "epoch", "clock_id", "captured_at_monotonic_s",
            "complete_for_native_caches", "slot_adapter_ids",
            "registered_cpu_adapter_ids", "registered_gpu_adapter_ids"]
           | index($p[3])) != null then setpath($p; $v) else . end
     else setpath($p; $v) end
   end)
