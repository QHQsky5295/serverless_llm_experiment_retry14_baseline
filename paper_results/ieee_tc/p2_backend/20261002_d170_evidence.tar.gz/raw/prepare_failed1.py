"""Bind D170 measurement to already-qualified D169; inspect output growth once."""
import json
import subprocess
from pathlib import Path
from scripts.ieee_tc_preflight import ROOT, digest, check_plan, verify_seal, warm_reference_batches
RAW=Path(__file__).parent.resolve()
PRIOR=ROOT/'results/ieee_tc/p2_backend_qualification/d169_20261002'
inputs=json.loads((PRIOR/'inputs1.json').read_text())
for name,sha in inputs['sources'].items():
    assert digest(Path(name))==sha, name
probe=ROOT/'paper_results/ieee_tc/p2_backend/20261002_d169_warm_probe.json'
assert digest(probe)=='6a288d09587488d3bb74d9fbf448c9e9cd6a153186dcffac0f5a6e234b31b3ad'
qualification=json.loads(probe.read_text())
assert qualification['passed'] and qualification['actual_7b_probe_complete']
path=PRIOR/'7b_probe1.json'
assert path.stat().st_size < 128*1024**2
# This is a NEW output-growth question, not a repeated performance curation.
d=json.loads(path.read_text())
sizes={k:len(json.dumps(v,separators=(',',':'))) for k,v in d.items()}
index=json.loads((ROOT/'paper_results/ieee_tc/p2_backend/20261002_d168_warm_input_index.json').read_text())
batches=warm_reference_batches(index,'measure')
assert len(batches)==194 and sum(len(b['selected']) for b in batches)==1552
assert sum(len(b['selected']) for b in batches if b['phase']=='measured')==1536
major={k:v for k,v in sizes.items() if v>100000}
# Conservative linear sizing only; not a proven runtime-memory bound.
linear=path.stat().st_size*194/4
result=dict(passed=True,sources=inputs['sources'],prior_probe_sha256=digest(probe),
    output_size_probe=dict(raw_bytes=path.stat().st_size(),compact_top_fields=major,
      linear_194_batch_bytes=linear),
    measured_requests=1536,warmup_requests=16,total_requests=1552,batches=194,
    batch_size=8,rounds=3,phase='measure',common_reference_frozen=False,
    plan_sha256=check_plan(),protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json'),
    runtime_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
assert result['protected']['pass'] and result['protected']['entry_count']==147
assert result['plan_sha256']=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
with (RAW/'inputs1.json').open('x') as f: json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ('sources','protected')},indent=2))
