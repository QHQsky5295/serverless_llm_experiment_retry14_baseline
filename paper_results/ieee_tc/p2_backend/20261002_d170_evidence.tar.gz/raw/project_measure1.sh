#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d170_20261002
unit=primelora-d170-project1-20261002.scope
test -s "$raw/measure1_cleanup.txt"
test -s "$raw/7b_measure1_launch.json"
test -s "$raw/7b_measure1.json"
test ! -e "$raw/measurement_projection1.json"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/project1_scope.txt"
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 "$raw/check_projection.py" > "$raw/project1_checks.log"
set +e
/usr/bin/time -v -o "$raw/project1_time.txt" jq --stream -n -f "$raw/project_warm.jq" "$raw/7b_measure1.json" > "$raw/measurement_projection1.json"
code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/project1_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/project1_swap.txt"
exit "$code"
