"""Reuse D169 scoped verification/bundle; no serving-source changes in D170."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT,digest,check_plan,verify_seal
RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
BASE='6a15274af4062c3a66fe7d51e7d7f910bcac895f'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
names=('scripts/ieee_tc_preflight.py','tests/test_ieee_tc_warm_reference.py',
 'configs/ieee_tc/20261002_d169_7b_warm_reference.yaml','scripts/run_all_experiments.py',
 'faaslora/memory/gpu_monitor.py','faaslora/memory/residency_manager.py',
 'faaslora/preloading/planning_cpu.py','faaslora/preloading/preloading_planner.py',
 'faaslora/experiment/instance_pool.py')
for name in names:
    assert (ROOT/name).read_bytes()==subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
curated=OUT/'20261002_d170_warm_measurement.json'
data=json.loads(curated.read_text())
assert data['passed'] and data['native_completed']==1552
assert data['measured_warm_reference'] and not data['common_reference_frozen']
assert not data['formal_g1_g2_qualified'] and data['n_correct'] is None
assert len(data['round_means'])==6 and len(data['warm_threshold_candidates'])==2
for path,sha in data['sources'].items(): assert digest(Path(path))==sha,path
assert 'Two exact streaming-projection fixtures PASS' in (RAW/'project1_checks.log').read_text()
cleanup=[]
for phase,code in (('prepare1',1),('prepare2',1),('prepare3',0),('project1',0),('curate1',0)):
    receipt=(RAW/f'{phase}_scope.txt').read_text()
    actual=re.search(r'^InvocationID=([a-f0-9]{32})$',receipt,re.M)[1]
    unit=f'primelora-d170-{phase}-20261002.scope'
    state=subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState',
                                  '-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines()==['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert all(int(line.split()[1])==0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text())==0
    assert f'Exit status: {code}' in (RAW/f'{phase}_time.txt').read_text()
    cleanup.append(dict(phase=phase,actual_invocation_id=actual,returncode=code,
                        cleanup='automatic_removal_verified'))
with (RAW/'cleanup_verified.json').open('x') as f: json.dump(cleanup,f,indent=2)
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
doc=ROOT/'docs/ieee_tc/D170_WARM_REFERENCE_MEASUREMENT.md'
tables=[OUT/f'20261002_d170_warm_{suffix}.csv' for suffix in ('rounds','thresholds','batches','samples')]
for table,count in zip(tables,(6,2,194,1552)):
    with table.open() as f: assert len(list(csv.DictReader(f)))==count
for p in RAW.glob('*.py'): ast.parse(p.read_text())
verification=OUT/'20261002_d170_verification.json'
with verification.open('x') as f:
    json.dump(dict(passed=True,base_commit=BASE,unchanged_source_paths=list(names),
        protected=protected,cleanup=cleanup,curated_sha256=digest(curated),
        table_sha256={str(p):digest(p) for p in tables},document_sha256=digest(doc)),f,indent=2)
members=sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size<2*1024**2
               and not p.name.startswith('verify1') and p.suffix!='.lock')
extras=[doc,curated,verification,*tables]
hashes={}
bundle=OUT/'20261002_d170_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for p in members+extras:
        name='raw/'+str(p.relative_to(RAW)) if p in members else str(p.relative_to(ROOT))
        hashes[name]=digest(p)
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha
with (OUT/'20261002_d170_evidence_members.json').open('x') as f:
    json.dump(dict(passed=True,member_sha256=hashes,
                  large_raw_results_retained_locally_and_bound_in_curated_sources=True),f,indent=2)
with (OUT/'20261002_d170_evidence.sha256').open('x') as f: f.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,cleanup=cleanup,curated_sha256=digest(curated),
    bundle_sha256=digest(bundle),members=len(hashes),bundle_bytes=bundle.stat().st_size),indent=2))
