#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d170_20261002
test -e "$raw/7b_measure1_launch.json"
test -e "$raw/7b_measure1.json"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test ! -e /proc/721356
for unit in primelora-tc-svc-3bfbb824545248308ed14a73a3a2ceb3.scope primelora-tc-aux-7e68b0a182db4f0bb50cc2c1ac84de69.scope; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test -z "$(systemctl --user show "$unit" -p ControlGroup --value)"
done
{ date --iso-8601=seconds; echo cleanup=automatic_removal_verified; } > "$raw/measure1_cleanup.txt"
