"""Small structural tests for D96-derived streaming projection; post-run only."""
import ast
import copy
import json
from pathlib import Path
import subprocess
RAW=Path(__file__).parent.resolve()
retained={'owner_id','epoch','clock_id','captured_at_monotonic_s',
    'complete_for_native_caches','slot_adapter_ids',
    'registered_cpu_adapter_ids','registered_gpu_adapter_ids'}
source=dict(pass_native=False,requests=[dict(pass_native=False,error='retained',timing={}),
    dict(pass_native=True,actual_tokens=7)],warm_batches=[dict(serial=0,phase='measurement',
    sources_before=dict(owner_id='x',epoch=4,complete_for_native_caches=True,
        slot_adapter_ids=[1,2,None],registered_cpu_adapter_ids=[1,2],
        sources=[dict(adapter_id=1,tensors=[dict(data=[1,2,3])])]),
    request_indices=[0,1],scheduler_before=dict(admitted=0),scheduler_after={})],
    error='kept',sources_after_eviction=dict(sources=[],slot_adapter_ids=[None]*8))
for fixture in (source,dict(source,warm_batches=[],requests=[])):
    expected=copy.deepcopy(fixture)
    for batch in expected['warm_batches']:
        batch['sources_before']={k:v for k,v in batch['sources_before'].items() if k in retained}
    actual=json.loads(subprocess.check_output(['jq','--stream','-n','-f',str(RAW/'project_warm.jq')],
        input=json.dumps(fixture).encode()))
    assert actual==expected
for name in ('prepare.py','curate.py','check_projection.py'):
    ast.parse((RAW/name).read_text())
print('Two exact streaming-projection fixtures PASS; failure/null/empty fields retained; AST PASS.')
