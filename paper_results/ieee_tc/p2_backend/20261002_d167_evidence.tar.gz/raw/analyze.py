"""D166 bounded curation reused to answer a new checkpoint-content question."""
import csv
import json
from pathlib import Path
from scripts.ieee_tc_preflight import (
    ROOT, digest, check_plan, verify_seal, checkpoint_slot_fingerprints,
    validate_checkpoint_slot_snapshot,
)

RAW = Path(__file__).parent.resolve()
OLD = RAW.parent/'d166_20261002'
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
refs = {}
def load(path, expected_sha=None):
    assert path.stat().st_size < 128*1024**2
    sha = digest(path)
    if expected_sha:
        assert sha == expected_sha, (path, sha)
    refs[str(path)] = sha
    return json.loads(path.read_text())

prior = load(OUT/'20261002_d166_slot_content.json',
             '54b318efcfd8df839d5741de20d487ec7b0e95155294bb8cd35b24064440604a')
inputs = load(OLD/'input_qualification2.json',
              '56d474d9d69e4724162ccb0a5f938b32d9415a8e7a61576ccd5bf5fdd8f66a16')
data = load(OLD/'7b_slot_content3.json',
            '29a4328edc3feeff3eac9cf39b59adec56ab1e61414b64ec3ab807a60768fbf8')
base_path = Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf/config.json')
base = load(base_path)
assert data['pass'] and prior['registered_to_slot_exact_content_qualified']
assert len(data['requests']) == len(inputs['rows']) == 22
assert data['plan_sha256'] == check_plan() == inputs['plan_sha256']
assert data['adapters'].keys() == inputs['adapters'].keys()
assert not data['performance_sample']
expected_by_id, configs, paths, classes = {}, {}, {}, {}
for q in data['requests']:
    aid = q['adapter_id']
    if aid in expected_by_id:
        continue
    directory = Path(q['reference']['lora_path'])
    assert directory.parent == Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
    assert directory.name == aid
    identity = inputs['adapters'][aid]
    weights, config_path = directory/'adapter_model.safetensors', directory/'adapter_config.json'
    assert digest(weights) == identity['weights_sha256']
    refs[str(weights)] = identity['weights_sha256']
    config = load(config_path, identity['config_sha256'])
    key = identity['weights_sha256']+':'+identity['config_sha256']
    if key not in classes:
        classes[key] = checkpoint_slot_fingerprints(weights, config, base, max_rank=64)
    expected_by_id[aid] = classes[key]
    configs[aid], paths[aid] = config, weights
assert len(classes) == 4 and len(expected_by_id) == 12
rows = []
snapshots = {}
for q, identity in zip(data['requests'], inputs['rows']):
    assert all(q[k] == v for k, v in identity.items())
    assert q['pass'] and q['actual_tokens'] == q['target_tokens']
    for phase in ('before', 'after'):
        sample = q['slot_content_'+phase]
        assert sample['pass']
        workers = sample['worker_observation']['workers']
        assert len(workers) == 1 and workers[0]['device_barrier_used']
        audit = workers[0]['slot_content_audit']
        assert audit['exact_content_pass'] and len(audit['adapters']) == 1
        a = audit['adapters'][0]
        assert a['adapter_int_id'] == q['reference']['adapter_int_id']
        assert a['rank'] == inputs['adapters'][q['adapter_id']]['rank']
        assert audit['slot_adapter_ids'][a['slot']] == a['adapter_int_id']
        result = validate_checkpoint_slot_snapshot(expected_by_id[q['adapter_id']], a['tensors'])
        rows.append(dict(request_id=q['request_id'], adapter_id=q['adapter_id'],
                         phase=phase, slot=a['slot'], rank=a['rank'],
                         compared_tensors=result['compared_tensors'],
                         failed_tensors=result['failed_tensors'], passed=result['passed']))
        snapshots.setdefault(q['adapter_id'], a['tensors'])

# Wrong known nonzero adapter, base/zero tensors, and omitted B scaling must
# fail against the SAME retained GPU measurement. These are offline controls,
# not new weights, model requests, or tolerance-adjusted output tests.
controls = []
for label, expected in (
    ('wrong_medical_for_finance', expected_by_id['medical_lora']),
    ('zero_rank8_for_finance', expected_by_id['writing_lora_0011']),
    ('omitted_B_scaling', checkpoint_slot_fingerprints(
        paths['finance_lora'], dict(configs['finance_lora'], lora_alpha=configs['finance_lora']['r']),
        base, max_rank=64)),
):
    result = validate_checkpoint_slot_snapshot(expected, snapshots['finance_lora'])
    controls.append(dict(control=label, rejected=not result['passed'],
                         failed_tensors=result['failed_tensors']))

fingerprints = RAW/'checkpoint_fingerprints.json'
with fingerprints.open('x') as f:
    json.dump(classes, f, indent=2, allow_nan=False)
refs[str(fingerprints)] = digest(fingerprints)
for rel in ('scripts/ieee_tc_preflight.py','tests/test_ieee_tc_artifact_audit.py',
            'faaslora/memory/gpu_monitor.py','scripts/run_all_experiments.py',
            'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'):
    refs[str(ROOT/rel)] = digest(ROOT/rel)
native = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')
for rel in ('lora/lora_model.py','lora/lora_weights.py','lora/model_manager.py',
            'lora/peft_helper.py','lora/utils.py','model_executor/models/llama.py'):
    refs[str(native/rel)] = digest(native/rel)
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
passed = all(r['passed'] for r in rows) and all(c['rejected'] for c in controls)
result = dict(kind='d167_independent_checkpoint_slot_content_v1', passed=passed,
    original_requests=22, logical_adapters=12, unique_weight_config_classes=4,
    snapshots=len(rows), compared_tensors=sum(r['compared_tensors'] for r in rows),
    failed_tensors=sum(r['failed_tensors'] for r in rows), negative_controls=controls,
    checkpoint_derived_snapshot_content_qualified=passed,
    per_token_execution_mapping_qualified=False, semantic_full_pool_qualification=False,
    performance_sample=False, common_slo_qualified=False, formal_g1_g2_qualified=False,
    n_correct=None, source_gpu_run='D166 slot_content3, no new GPU run',
    plan_sha256=check_plan(), metric_protocol_sha256=inputs['metric_protocol_sha256'],
    protected=protected, sources=refs)
with (OUT/'20261002_d167_checkpoint_slot_content.json').open('x') as f:
    json.dump(result, f, indent=2, allow_nan=False)
with (OUT/'20261002_d167_checkpoint_slot_content.csv').open('x', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader(); writer.writerows(rows)
print(json.dumps({k:v for k,v in result.items() if k not in ('sources','protected')}, indent=2))
raise SystemExit(0 if passed else 1)
