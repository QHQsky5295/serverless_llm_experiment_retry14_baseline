"""Reuse D166 scoped evidence verification; no GPU or historical rerun."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT, digest, verify_seal, check_plan

RAW = Path(__file__).parent.resolve()
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
BASE = 'e35ef2c6a4021ff118fc9b5651f2670b0fac4d46'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
prior = subprocess.check_output(['git','show',BASE+':scripts/ieee_tc_preflight.py'],cwd=ROOT,text=True)
new = (ROOT/'scripts/ieee_tc_preflight.py').read_text()
oldtree, newtree = ast.parse(prior), ast.parse(new)
added = {'checkpoint_slot_fingerprints','validate_checkpoint_slot_snapshot'}
filtered = ast.Module(body=[n for n in newtree.body if not isinstance(n, ast.FunctionDef)
                           or n.name not in added], type_ignores=[])
assert ast.dump(filtered) == ast.dump(oldtree)
for path in ('faaslora/memory/gpu_monitor.py','scripts/run_all_experiments.py',
             'faaslora/memory/residency_manager.py','faaslora/preloading/planning_cpu.py',
             'faaslora/preloading/preloading_planner.py','faaslora/experiment/instance_pool.py'):
    assert (ROOT/path).read_bytes()==subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
curated = OUT/'20261002_d167_checkpoint_slot_content.json'
data = json.loads(curated.read_text())
assert data['passed'] and not data['formal_g1_g2_qualified'] and data['n_correct'] is None
for path, sha in data['sources'].items():
    assert digest(Path(path))==sha, path
assert '\nRan 14 tests in ' in (RAW/'tests1.log').read_text()
assert (RAW/'tests1.log').read_text().rstrip().endswith('OK')
receipts = []
for phase in ('tests1','analysis1'):
    receipt = (RAW/f'{phase}_scope.txt').read_text()
    actual = re.search(r'^InvocationID=([a-f0-9]{32})$',receipt,re.M)[1]
    unit = f'primelora-d167-{phase}-20261002.scope'
    state = subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState',
                                    '-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines()==['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert all(int(line.split()[1])==0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text())==0
    assert 'Exit status: 0' in (RAW/f'{phase}_time.txt').read_text()
    receipts.append(dict(phase=phase, actual_invocation_id=actual,
                         cleanup='automatic_removal_verified'))
with (RAW/'cleanup_verified.json').open('x') as f:
    json.dump(receipts,f,indent=2)
# Existing preflight safety tests use the OS interpreter with qualified pidfds.
subprocess.run(['/usr/bin/python3','-m','unittest','tests.test_ieee_tc_preflight','-v'],
               cwd=ROOT, check=True)
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
doc = ROOT/'docs/ieee_tc/D167_CHECKPOINT_SLOT_CONTENT.md'
table = OUT/'20261002_d167_checkpoint_slot_content.csv'
verification = OUT/'20261002_d167_verification.json'
with verification.open('x') as f:
    json.dump(dict(passed=True, base_commit=BASE, only_new_preflight_functions=sorted(added),
        existing_preflight_ast_unchanged=True, serving_source_unchanged=True,
        protected=protected, cleanup=receipts, curated_sha256=digest(curated),
        table_sha256=digest(table), document_sha256=digest(doc)),f,indent=2)
members = sorted(p for p in RAW.iterdir() if p.is_file() and not p.name.startswith('verify1'))
extras = [ROOT/'scripts/ieee_tc_preflight.py', ROOT/'tests/test_ieee_tc_artifact_audit.py',
          doc, curated, table, verification]
hashes = {}
bundle = OUT/'20261002_d167_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for p in members+extras:
        assert p.stat().st_size < 2*1024**2
        name='raw/'+p.name if p in members else str(p.relative_to(ROOT))
        hashes[name]=digest(p)
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name, sha in hashes.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha
with (OUT/'20261002_d167_evidence_members.json').open('x') as f:
    json.dump(dict(passed=True, member_sha256=hashes),f,indent=2)
with (OUT/'20261002_d167_evidence.sha256').open('x') as f:
    f.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True, receipts=receipts, curated_sha256=digest(curated),
                     bundle_sha256=digest(bundle), members=len(hashes),
                     bundle_bytes=bundle.stat().st_size),indent=2))
