"""CPU-only qualification of the new source launch identity; no new input data."""
import json, os, subprocess, sys, unittest
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(name,obj):
    with (RAW/name).open('x') as f:json.dump(obj,f,indent=2)
identity=p.scope_identity(p.cg_path().name);save('qualification_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT,RAW],64*1024*1024);save('qualification_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
shell=ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh'
code=shell.read_text();old=subprocess.check_output(['git','show','HEAD:scripts/ieee_tc/run_d298_capacity_source.sh'],cwd=ROOT,text=True)
case=code[code.index('  d642)'):code.index('  d641)')]
start=code.index('if [[ "${1:-d298}" == d642 ]]; then')
end=code.index('\nfi',start)+3
binding=code[start:end]
reconstructed=code.replace(case,'',1).replace(binding+'\n','',1).replace(' == d641 || "${1:-d298}" == d642',' == d641',1)
assert reconstructed==old
subprocess.run(['bash','-n',str(shell)],check=True)
assert 'FAASLORA_WORKER_START_TIMEOUT_S=600' in binding
assert 'FAASLORA_KEEP_DEDICATED_WORKER_LOGS=1' in binding
contract=ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json'
sha='328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c'
assert p.digest(contract)==sha and sha in binding
from tests.test_tc_native_toolchain import ToolchainTests
with (RAW/'tests.log').open('x') as f:
    result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ToolchainTests))
assert result.wasSuccessful() and result.testsRun==8
os.environ.update(FAASLORA_TC_NATIVE_TOOLCHAIN_CONTRACT=str(contract),FAASLORA_TC_NATIVE_TOOLCHAIN_SHA256=sha)
from scripts import run_all_experiments as runtime
import torch
assert not torch.cuda.is_initialized()
assert runtime._native_build_receipt['contract_sha256']==sha
from scripts.ieee_tc_native_toolchain import bind_native_toolchain
_, child=bind_native_toolchain(os.environ,python=sys.executable)
assert child==runtime._native_build_receipt
prior=json.loads((ROOT/'paper_results/ieee_tc/p2_backend/d640_3b_migration/qualification.json').read_text())
for path in ('configs/ieee_tc/20261017_d641_3b_native_source.yaml',):
    assert p.digest(ROOT/path)==prior['inputs']['config_sha256']
spec=ROOT/'paper_results/ieee_tc/p2_backend/d640_3b_migration/source_spec.json'
assert p.digest(spec)==prior['inputs']['source_spec_sha256']
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
save('qualification.json',dict(passed=True,tests=8,legacy_source_unchanged=True,
    actual_entry_import_pass=True,no_cuda_initialized=True,toolchain=child,protected=protected,
    runner_sha256=p.digest(shell),config_sha256=prior['inputs']['config_sha256'],
    spec_sha256=p.digest(spec),cases=368,model_parameters_changed=False,
    initialization_timeout_seconds=600,request_timeout_changed=False,
    caveat='Launch qualification only. D641 may have warmed model/compiler/page caches; no performance attribution.'))
print(json.dumps(dict(passed=True,tests=8,actual_import=True,no_cuda_initialized=True)))
