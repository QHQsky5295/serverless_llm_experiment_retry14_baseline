"""Measure decoder CPU work on four retained native snapshots, no model run."""
import csv
import hashlib
import json
import math
from pathlib import Path
import time
import msgspec

RAW=Path(__file__).parent.resolve()
root=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
source=RAW.parent/'d169_20261002/7b_probe1.json'
assert 0<source.stat().st_size<64*1024**2
raw=source.read_bytes()
sha=hashlib.sha256(raw).hexdigest()
data=json.loads(raw)
del raw
snapshots=[b['sources_before'] for b in data['warm_batches']]
assert len(snapshots)==4
rows=[]
def identical(a,b):
    assert type(a) is type(b)
    if isinstance(a,dict):
        assert list(a)==list(b)
        for k in a: identical(a[k],b[k])
    elif isinstance(a,list):
        assert len(a)==len(b)
        for x,y in zip(a,b): identical(x,y)
    elif isinstance(a,float):
        assert math.isfinite(a) and a.hex()==b.hex()
    else: assert a==b
for i,s in enumerate(snapshots):
    payload=json.dumps(dict(ok=True,result=s),ensure_ascii=True).encode()+b'\n'
    assert len(payload)<=8*1024**2+1
    decoders=dict(original=lambda:json.loads(payload.decode('utf-8')),
                  candidate=lambda:msgspec.json.decode(payload))
    expected=decoders['original']()
    identical(expected,decoders['candidate']())
    for repeat in range(3):
        for name in (('original','candidate') if repeat%2==0 else ('candidate','original')):
            decode=decoders[name]
            started=time.perf_counter()
            for _ in range(20): value=decode()
            elapsed=time.perf_counter()-started
            identical(expected,value)
            rows.append(dict(snapshot=i,repeat=repeat,decoder=name,iterations=20,
                bytes=len(payload),mean_decode_ms=elapsed/20*1000,exact_tree_and_float_bits=True))
result=dict(kind='retained_native_json_decode_component_v1',source=str(source),source_sha256=sha,
    msgspec_version=msgspec.__version__,snapshots=len(snapshots),measurements=rows,
    no_gpu_run=True,no_end_to_end_performance_claim=True,
    caveat='Three alternating component rounds, not independent workload repetitions; no CI.')
with (RAW/'decoder_probe1.json').open('x') as f: json.dump(result,f,indent=2)
with (RAW/'decoder_probe1.csv').open('x',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
print(json.dumps(result,indent=2))
