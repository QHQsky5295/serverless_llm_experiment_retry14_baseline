#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
phase=$1
shift
case "$phase" in audit|apply) ;; *) exit 2;; esac
raw=results/ieee_tc/p2_backend_qualification/d172_20261002
unit="primelora-d172-cache-${phase}1-20261002.scope"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/cache_${phase}1_scope.txt"
export CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD"
set +e
/usr/bin/time -v -o "$raw/cache_${phase}1_time.txt" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/audit_public_download_cache.py" "$phase" "$@" > "$raw/cache_${phase}1.log" 2>&1

code=$?
set -e
group=$(systemctl --user show "$unit" -p ControlGroup --value)
test -n "$group"
awk '{print}' "/sys/fs/cgroup$group/memory.events" > "$raw/cache_${phase}1_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$group/memory.swap.current" > "$raw/cache_${phase}1_swap.txt"
exit "$code"
