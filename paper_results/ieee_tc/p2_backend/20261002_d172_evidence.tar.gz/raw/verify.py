"""Reuse D171 bounded qualification/seal/bundle; no repeated CPU or GPU test."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import tarfile
from scripts.ieee_tc_preflight import ROOT,digest,check_plan,verify_seal
RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
BASE='8647f89dd18cdaefa175471d025f7ce23d68a53b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert check_plan()=='0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
changed=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(changed)<={'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md',
                     'scripts/run_all_experiments.py'}
runner=ROOT/'scripts/run_all_experiments.py'
before=ast.parse(subprocess.check_output(['git','show',BASE+':scripts/run_all_experiments.py'],cwd=ROOT,text=True))
after=ast.parse(runner.read_text())
added=[n for n in after.body if isinstance(n,ast.FunctionDef) and n.name=='_decode_native_rpc_frame']
assert len(added)==1
after.body.remove(added[0])
bc=next(n for n in before.body if isinstance(n,ast.ClassDef) and n.name=='SubprocessInferenceEngineProxy')
ac=next(n for n in after.body if isinstance(n,ast.ClassDef) and n.name=='SubprocessInferenceEngineProxy')
for name in ('_rpc','_native_rpc_roundtrip'):
    original=next(n for n in bc.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    candidate=next(n for n in ac.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    assert ast.dump(original)!=ast.dump(candidate)
    ac.body[ac.body.index(candidate)]=original
assert ast.dump(before)==ast.dump(after), 'non-decoder serving structure changed'
probe=json.loads((RAW/'decoder_probe1.json').read_text())
assert probe['msgspec_version']=='0.21.1' and probe['snapshots']==4
assert digest(Path(probe['source']))==probe['source_sha256']
rows=probe['measurements']
assert len(rows)==24 and all(r['exact_tree_and_float_bits'] for r in rows)
summary=[]
for i in range(4):
    values={}
    for decoder in ('original','candidate'):
        matches=[r for r in rows if r['snapshot']==i and r['decoder']==decoder]
        assert [r['repeat'] for r in matches]==[0,1,2]
        assert all(r['iterations']==20 and r['bytes']>0 for r in matches)
        values[decoder]=statistics.mean(r['mean_decode_ms'] for r in matches)
    summary.append(dict(snapshot=i,bytes=matches[0]['bytes'],original_ms=values['original'],
        candidate_ms=values['candidate'],relative_reduction=(values['original']-values['candidate'])/values['original']))
for phase,count in (('tests2',55),('regression1',849)):
    log=(RAW/f'{phase}.log').read_text()
    assert f'Ran {count} tests' in log and log.rstrip().endswith('OK')
failed=(RAW/'tests1.log').read_text()
assert 'Ran 54 tests' in failed and 'FAILED (errors=1)' in failed and 'UnicodeDecodeError' in failed
assert (RAW/'test_ieee_tc_rpc_decode_failed1.py').is_file()
cleanup=[]
for phase in ('cache_audit1','cache_apply1','probe1','tests1','tests2','regression1'):
    receipt=(RAW/f'{phase}_scope.txt').read_text()
    actual=re.search(r'^InvocationID=([a-f0-9]{32})$',receipt,re.M)[1]
    tag=phase.replace('_','-')
    state=subprocess.check_output(['systemctl','--user','show',f'primelora-d172-{tag}-20261002.scope',
                                  '-p','ActiveState','-p','InvocationID','-p','ControlGroup'],text=True)
    assert state.splitlines()==['ControlGroup=', 'ActiveState=inactive', 'InvocationID=']
    assert all(int(line.split()[1])==0 for line in (RAW/f'{phase}_memory_events.txt').read_text().splitlines())
    assert int((RAW/f'{phase}_swap.txt').read_text())==0
    code=1 if phase=='tests1' else 0
    assert f'Exit status: {code}' in (RAW/f'{phase}_time.txt').read_text()
    cleanup.append(dict(phase=phase,actual_invocation_id=actual,returncode=code,
                        cleanup='automatic_removal_verified',final_memory_events_zero=True,final_swap_zero=True))
with (RAW/'cleanup_verified.json').open('x') as f: json.dump(cleanup,f,indent=2)
protected=verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
cache=json.loads((RAW/'public_download_cache_complete1.json').read_text())
assert cache['freed_file_allocated_bytes']==509206528 and cache['removed_files']==2
assert cache['audit_sha256']==digest(RAW/'public_download_cache_audit1.json')
assert cache['installed_environments_untouched'] and cache['tracked_projects_unchanged']
doc=ROOT/'docs/ieee_tc/D172_NATIVE_RPC_DECODE.md'
table=OUT/'20261002_d172_rpc_decode.csv'
with (RAW/'decoder_probe1.csv').open() as f: assert len(list(csv.DictReader(f)))==24
with table.open('xb') as f: f.write((RAW/'decoder_probe1.csv').read_bytes())
curated=OUT/'20261002_d172_rpc_decode.json'
refs=[runner,ROOT/'tests/test_ieee_tc_rpc_decode.py',RAW/'decoder_probe1.json',RAW/'probe.py',
      RAW/'public_download_cache_complete1.json',Path(probe['source'])]
with curated.open('x') as f:
    json.dump(dict(kind='native_rpc_decoder_qualification_v1',base_commit=BASE,
        summary=summary,probe=probe,cleanup=cleanup,cache_maintenance=cache,
        source_sha256={str(p):digest(p) for p in refs},tests_targeted=55,tests_regression=849,
        failed_test_attempts_preserved=1,source_sha256_after_tests=digest(runner),
        no_new_gpu_run=True,end_to_end_improvement_qualified=False,n_correct=None,
        formal_g1_g2_qualified=False,common_reference_frozen=False,
        table_sha256=digest(table),document_sha256=digest(doc)),f,indent=2)
for path in RAW.glob('*.py'): ast.parse(path.read_text())
verification=OUT/'20261002_d172_verification.json'
with verification.open('x') as f:
    json.dump(dict(passed=True,base_commit=BASE,non_decoder_serving_ast_unchanged=True,
        tests_passed=dict(targeted=55,regression=849),protected=protected,cleanup=cleanup,
        curated_sha256=digest(curated),table_sha256=digest(table),document_sha256=digest(doc)),f,indent=2)
members=sorted(p for p in RAW.rglob('*') if p.is_file() and p.stat().st_size<2*1024**2
               and not p.name.startswith('verify1') and p.suffix!='.lock')
extras=[doc,curated,verification,table,runner,ROOT/'tests/test_ieee_tc_rpc_decode.py']
hashes={}
bundle=OUT/'20261002_d172_evidence.tar.gz'
with tarfile.open(bundle,'x:gz') as tar:
    for p in members+extras:
        name='raw/'+str(p.relative_to(RAW)) if p in members else str(p.relative_to(ROOT))
        hashes[name]=digest(p)
        tar.add(p,arcname=name,recursive=False)
with tarfile.open(bundle,'r:gz') as tar:
    assert set(tar.getnames())==set(hashes)
    for name,sha in hashes.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha
with (OUT/'20261002_d172_evidence_members.json').open('x') as f:
    json.dump(dict(passed=True,member_sha256=hashes,source_raw_retained_and_bound=True),f,indent=2)
with (OUT/'20261002_d172_evidence.sha256').open('x') as f: f.write(digest(bundle)+'  '+bundle.name+'\n')
print(json.dumps(dict(passed=True,curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    members=len(hashes),bundle_bytes=bundle.stat().st_size,cleanup=cleanup),indent=2))
