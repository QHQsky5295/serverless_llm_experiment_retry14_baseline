#!/usr/bin/env bash
# Reuse the completed exact metadata4 projection; do NOT project again.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d203_20261003
unit=primelora-d203-full1-metadata5-20261003.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show primelora-d203-full1-metadata4-20261003.scope -p ActiveState --value)" = inactive
test -z "$(systemctl --user show primelora-d203-full1-metadata4-20261003.scope -p InvocationID --value)"
test ! -e /sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d203-full1-metadata4-20261003.scope
rg -q 'Exit status: 0' "$raw/full_full1_metadata4_project_time.txt"
test "$(stat -c %s "$raw/full_full1_main_outcome_projection4.json")" = 173117160
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_metadata5_scope.txt"
sha256sum "$raw/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json" "$raw/full_full1_main_outcome_projection4.json" > "$raw/full_full1_metadata_projection4.sha256"
set +e
/usr/bin/time -v -o "$raw/full_full1_metadata5_time.txt" /usr/bin/python3 "$raw/collect_full1_preliminary5.py" > "$raw/full_full1_metadata5.log" 2>&1
code=$?
set -e
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
awk '{print}' "/sys/fs/cgroup$cg/memory.events" > "$raw/full_full1_metadata5_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$cg/memory.swap.current" > "$raw/full_full1_metadata5_swap.txt"
exit "$code"
