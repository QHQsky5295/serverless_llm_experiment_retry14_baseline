#!/usr/bin/env bash
set -euo pipefail
# Existing D150 exact-identity cleanup, bound to this actual activation.
# Execute remotely ONLY after local terminal and physical GPU cleanup.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d203full1.service)
ids=(987612c9cfd2405eadc6e096b071535d e8904853bdeb472595e5a9f54718339c 0845c03e49ad4254ab473f32ef132b61)
pids=(1536346 1536348 1536351)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result
