"""Reuse D632 explicit-source backup; this is an unchanged-model W1 continuation."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d632_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("previous=read(RAW.parent/'d631_20261017/backup_receipt.json')", "previous=read(RAW.parent/'d632_20261017/publication_receipt.json')")
code=code.replace('D632','D633').replace('d632_min2_full_w2','d633_min2_full_w1')
code=code.replace('20261017_d632_7b_min2_full_w2','20261017_d633_7b_min2_full_w1')
code=code.replace('D633_MINIMUM_TWO_REPLICA_FULL_W2','D633_MINIMUM_TWO_REPLICA_FULL_W1')
code=code.replace("RAW/'qualification2_closure.json'", "RAW/'qualification_closure.json'")
start=code.index("files += [RAW/'qualification.json'")
end=code.index('for path in files:',start)
code=code[:start]+'''files += [RAW/'qualification.json',RAW/'qualification_closure.json',
    RAW.parent/'d632_20261017/qualification.json',RAW.parent/'d632_20261017/control_tests2.json',
    RAW.parent/'d632_20261017/control_tests2.log',RAW.parent/'d632_20261017/three_replica_checks2.json',
    ROOT/'configs/ieee_tc/20261017_d633_7b_min2_full_w1.yaml',
    ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',source]
''' + code[end:]
replace("model_cap_state_checks_new=binding['three_replica_checks']['case_count'],", "model_cap_state_checks_new=0,model_cap_state_checks_reused=binding['three_replica_checks']['case_count'],")
replace('same_model_working_point_as_d615=False','same_model_working_point_as_d632=True')
replace('tc: qualify minimum-two replica model point for full W2 (D633)', 'tc: bind unchanged minimum-two replica model point to full W1 (D633)')
exec(compile(code,str(source),'exec'))
