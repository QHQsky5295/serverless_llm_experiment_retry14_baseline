"""Reuse D619 full-W1 binding with the already qualified D632 min2 model point."""
from pathlib import Path

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d619_20261017/qualify.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
# The old template mentions its historical commit twice; replace only the live HEAD assertion.
old="assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='610388a44c0c270b27668f8822fdea1a5128bf96'"
replace(old,"assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='333e707826a44fee2758a6d74b97b18b397af490'")
replace("parent=RAW.parent/'d617_20261017'","parent=RAW.parent/'d632_20261017'")
start=code.index("native=read(previous/'native_reuse.json')")
end=code.index('gate=p.preflight',start)
code=code[:start]+'''# No production/model change: reuse the completed and backed-up D632 evidence.
for path,sha in {**old['refs'],**old['preserved']}.items():
    if Path(path)!=shell:assert p.digest(Path(path))==sha,path
candidate=RAW.parent/'d631_20261017'
reg=read(candidate/'qualification_receipt.json')
assert reg['passed'] and reg['returncode']==0
test_sources=reg['sources']
for path,sha in test_sources.items():assert p.digest(Path(path))==sha,path
assert p.digest(candidate/'qualification.log')==reg['log_sha256']
import re
assert sum(map(int,re.findall(r'Ran (\\d+) tests?',(candidate/'qualification.log').read_text())))==458
assert old['control_tests_run']==32 and old['three_replica_checks']['lower_bound']==2
assert old['three_replica_checks']['upper_bound']==3
for phase in ('qualification','qualification2','backup','start','collection','analysis','analysis2','publication'):
    closed=read(parent/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
local=read(parent/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
assert read(parent/'remote_stop.json')['all_owned_units_inactive']
auditpath=ROOT/'paper_results/ieee_tc/p2_backend/d632_min2_full_w2/result1/summary.json'
audit=read(auditpath)
completed=read(parent/'actual_qualification.json')
assert audit['passed'] and audit['audit']==completed
assert completed['passed'] and completed['protocol_bound_count']==4000
assert audit['comparison']['joint95_observed'] and audit['comparison']['budget_feasible_observed']
assert read(parent/'minimum_two_evidence.json')['passed']
assert read(parent/'publication_receipt.json')['head']=='333e707826a44fee2758a6d74b97b18b397af490'
''' + code[end:]
replace("ROOT/'configs/ieee_tc/20261017_d617_7b_three_replica_full_w1.yaml'", "ROOT/'configs/ieee_tc/20261017_d632_7b_min2_full_w2.yaml'")
replace("ROOT/'configs/ieee_tc/20261017_d619_7b_device_domain_full_w1.yaml'", "ROOT/'configs/ieee_tc/20261017_d633_7b_min2_full_w1.yaml'")
replace("assert configs[1]['resource_coordination']['min_instances']==1", "assert configs[1]['resource_coordination']['min_instances']==2")
code=code.replace("'  d619)\\n'", "'  d633)\\n'").replace('== d619','== d633').replace("'d619' not","'d633' not").replace("'d619' in","'d633' in")
start=code.index('refs=[*helpers');end=code.index("subprocess.run(['git','diff','--check']",start)
code=code[:start]+'''refs=[*helpers,*paths,parent/'qualification.json',auditpath,oldw1path,buildpath,
    parent/'actual_qualification.json',parent/'minimum_two_evidence.json',parent/'local_cleanup.json',
    parent/'remote_stop.json',parent/'publication_receipt.json',
    candidate/'qualification_receipt.json',candidate/'qualification.log',source,
    RAW.parent/'d550_20261015/close.py']
refs += [parent/(phase+'_closure.json') for phase in
    ('qualification','qualification2','backup','start','collection','analysis','analysis2','publication')]
refs += [Path(path) for path in old['refs'] if Path(path)!=shell]
refs += list(map(Path,test_sources))
''' + code[end:]
code=code.replace('same_model_working_point_as_d615=True','same_model_working_point_as_d632=True')
code=code.replace('reused_control_tests=21','reused_control_tests=32')
replace('reused_cpu_regression_tests=464,reused_focused_tests=60','reused_cpu_regression_tests=458,reused_focused_tests=0')
replace('new_tests=0,reused_regression=464,reused_focused=60','new_tests=0,reused_regression=458,reused_focused=0')
if __name__ == '__main__':
    exec(compile(code,str(source),'exec'))
