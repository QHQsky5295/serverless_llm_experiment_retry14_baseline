"""Reuse bounded D619 analysis after the separately verified collection."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d619_20261017/run_analysis.py')
assert hashlib.sha256(source.read_bytes()).hexdigest() == '61d8d5e09268b8602286e01dbce21465f01aff78bef2242dcfe76eca956d9f89'
code = source.read_text()
old = "commands=[('collection1.log',[sys.executable,str(raw/'collect_closure.py')]),\n          ('analysis1.log',[sys.executable,str(raw/'analyze.py')])]"
assert code.count(old) == 1
code = code.replace(old, '''
closed=json.loads((raw/'collection_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
binding=json.loads((raw/'qualification.json').read_text())
assert binding['passed'] and binding['count']==4000
assert binding['prime_plan']['profile']=='W1'
assert binding['prime_plan']['view_sha256']=='103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
for path,sha in {**binding['refs'],**binding['preserved']}.items():
    assert p.digest(Path(path))==sha,path
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')=='193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d'
correction=json.loads((raw/'description_correction.json').read_text())
assert correction['actual_workload_profile']=='W1'
assert correction['actual_view_sha256']==binding['prime_plan']['view_sha256']
assert correction['source_result_sha256']==json.loads((raw/'collection_receipt.json').read_text())['source_sha256']
commands=[('analysis1.log',[sys.executable,str(raw/'analyze.py')])]
''')
exec(compile(code, str(source), 'exec'))
