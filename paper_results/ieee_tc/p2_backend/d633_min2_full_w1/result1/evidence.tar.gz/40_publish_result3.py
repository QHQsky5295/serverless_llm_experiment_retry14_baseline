"""Validate both established compression-record schemas; retain earlier attempts."""
import ast
import contextlib
import hashlib
import io
from pathlib import Path
import sys

source=Path(__file__).resolve().parent/'publish_result2.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='953ab200e575189b1b217b558229a6d888d87a4b11332b7ef29df4389e679c35'
args=sys.argv[:]
namespace=dict(__file__=__file__,__name__='d633_compression_schema_template')
try:
    sys.argv=[str(source),'--check-only']
    with contextlib.redirect_stdout(io.StringIO()):
        exec(compile(data,str(source),'exec'),namespace)
finally:
    sys.argv=args
code=namespace['code']
def replace(old,new):
    global code
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new)
replace('publication2_identity.json','publication3_identity.json')
replace('publication2_resource_gate.json','publication3_resource_gate.json')
replace('publication2_receipt.json','publication3_receipt.json')
replace("('qualification','backup','start','collection','analysis','publication')",
        "('qualification','backup','start','collection','analysis','publication','publication2')")
replace("assert entries==[compression]", "assert compression['kind']=='lossless_closed_outcome_compression_v1'\nassert entries==[{key:value for key,value in compression.items() if key!='kind'}]")
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('Verified source chain, exact compression schemas and publication3 AST passed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'),dict(__file__=__file__,__name__='d633_publication3'))
else:
    raise SystemExit('expected no arguments or --check-only')
