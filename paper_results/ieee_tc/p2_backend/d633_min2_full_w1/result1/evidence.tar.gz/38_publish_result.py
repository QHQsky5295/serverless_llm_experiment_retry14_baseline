"""Reuse D632 publication checks for W1; keep the latency/resource trade-off."""
import ast
import contextlib
import hashlib
import io
from pathlib import Path
import sys

SOURCE = Path(__file__).resolve().parent.parent/'d632_20261017/publish_result.py'
data = SOURCE.read_bytes()
assert hashlib.sha256(data).hexdigest() == '5109a236ef3dccf6d4def1612811871fd5eee192a6b3655964fc304f31b25fb2'
args = sys.argv[:]
namespace = dict(__file__=__file__, __name__='d633_reused_publication_template')
try:
    sys.argv = [str(SOURCE), '--check-only']
    with contextlib.redirect_stdout(io.StringIO()):
        exec(compile(data, str(SOURCE), 'exec'), namespace)
finally:
    sys.argv = args
code = namespace['code']
def replace(old,new,count=1):
    global code
    assert code.count(old)==count,(old,code.count(old))
    code=code.replace(old,new)

replace('d632_min2_full_w2/result1','d633_min2_full_w1/result1')
replace('fa3b5eeda2ff395c5c7d6174d4fec32c0bda654e','20602b0aa99eb056eef7f866a7487548656863aa')
replace("assert not read(RAW/'analysis_receipt.json')['passed']\nassert read(RAW/'analysis2_receipt.json')['passed']",
        "assert read(RAW/'analysis_receipt.json')['passed']")
replace("('qualification','qualification2','backup','start','collection','analysis','analysis2')",
        "('qualification','backup','start','collection','analysis')")
replace("old_path=RAW.parent/'d621_20261017/actual_qualification.json'",
        "old_path=RAW.parent/'d619_20261017/actual_qualification.json'")
replace("reference=read(reference_path)['W2']","reference=read(reference_path)['W1']")
replace("reference['source_run']=='D557'","reference['source_run']=='D536'")
replace("old_run='D621'","old_run='D619'")
replace('same_production_source_model_minimum_replicas_revision_from_D621=True,',
        'same_production_source_model_minimum_replicas_revision_from_D619=True,')
begin=code.index("    conclusion='D632 min2/max3")
end=code.index("\n",begin)
code=code[:begin]+"    conclusion='D633 min2/max3 W1 completed 4000 native-contract requests, with 3842 joint passes (96.05%) and 6310.028822 GPU-s below its frozen 6756.571050 budget. Relative to D619 min1/max3, GPU time decreases 3.218870%, but P95 TTFT increases 8.832402% and joint SLO decreases 1.225 percentage points. Retain this trade-off and continue identical configuration W0; no splicing of old min1 results, independent numerical proof or global optimality claim.')"+code[end:]
replace('20261017_d621_7b_device_domain_full_w2.yaml','20261017_d619_7b_device_domain_full_w1.yaml')
replace('20261017_d632_7b_min2_full_w2.yaml','20261017_d633_7b_min2_full_w1.yaml')
begin=code.index("projection=RAW.parent/'d623_20261017/d621_projection.json'")
end=code.index('seen=set();changes=[]',begin)
code=code[:begin]+'''projection=RAW/'reference_contract_projection.json'
projection_summary=ROOT/'paper_results/ieee_tc/p2_backend/d619_device_domain_full_w1/result1/summary.json'
sealed=read(projection_summary)
assert sealed['passed'] and sealed['audit']==old
old_result=Path(old['evidence']['source'])
assert p.digest(old_result)==old['evidence']['source_sha256']
parent={}
with old_result.open('rb') as stream:
    for row in ijson.items(stream,'detailed_results.tc_ieee_full.requests.item',use_float=True):
        rid=row['request_id'];assert rid not in parent
        parent[rid]=dict(request_id=rid,adapter_id=row['adapter_id'],
            prompt_sha256=row['canonical_prompt_sha256'],target=row['requested_completion_tokens'],
            generation_contract=row['generation_contract'],token_source=row['completion_token_source'],
            arrival_s=row['scheduled_arrival_offset_s'],
            prompt_tokens=row['native_token_timing']['actual_prompt_tokens'],
            output_sha256=row['completion_token_ids_sha256'])
assert len(parent)==4000
save(projection,list(parent.values()))
''' + code[end:]
replace("row['workload']=='W2'","row['workload']=='W1'")
replace("comparison['all_published_W2_baselines']","comparison['all_published_W1_baselines']")
replace('Existing measured configurations only; vLLM has better raw tail and joint SLO but exceeds this budget; HydraServe uses less GPU time but misses joint SLO. No same-budget dominance or global optimum proof.',
        'All five published W1 measured configurations retained, including joint-SLO failures. These are observed points, not optimized same-budget alternatives or a proof of global optimality; independent numerical qualification remains unknown.')
replace("run=RAW/'7b_min2_full_w2'","run=RAW/'7b_min2_full_w1'")
replace('D632_MINIMUM_TWO_REPLICA_FULL_W2.md','D633_MINIMUM_TWO_REPLICA_FULL_W1.md',2)
replace("RAW.parent/'d621_20261017/publish_result.py',projection,projection_summary,baseline_csv,*configs,",
        "RAW.parent/'d621_20261017/publish_result.py',RAW.parent/'d632_20261017/publish_result.py',\n    RAW.parent/'d619_20261017/analyze.py',RAW.parent/'d619_20261017/analyze_prefix.py',\n    RAW.parent/'d619_20261017/run_analysis.py',projection,projection_summary,baseline_csv,*configs,")
replace("cap=read(RAW/'realized_replica_cap.json')", '''
cross=ROOT/'configs/ieee_tc/20261017_d632_7b_min2_full_w2.yaml'
cross_value=yaml.safe_load(cross.read_text())
for section,key in (('experiment','output_dir'),('storage','nvme_cache_dir'),('storage','host_cache_dir')):
    del cross_value[section][key]
assert normalized[1]==cross_value
comparison['same_model_configuration_as_D632_W2']=True
comparison['cross_workload_config_ref']=dict(path=str(cross),sha256=p.digest(cross))
correction=read(RAW/'description_correction.json')
assert correction['actual_workload_profile']==audit['workload_identity']['profile']=='W1'
assert correction['source_result_sha256']==audit['evidence']['source_sha256']
comparison['descriptive_template_label_correction']=correction
cap=read(RAW/'realized_replica_cap.json')''')
replace('tc: preserve min2 W2 SLO-resource tradeoff and full baseline comparison (D632)',
        'tc: seal min2 W1 validation with explicit latency-resource tradeoff (D633)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D632/D621 source hashes and D633 W1 publication adaptation/AST passed; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code,str(SOURCE),'exec'),dict(__file__=__file__,__name__='d633_publication'))
else:
    raise SystemExit('expected no arguments or --check-only')
