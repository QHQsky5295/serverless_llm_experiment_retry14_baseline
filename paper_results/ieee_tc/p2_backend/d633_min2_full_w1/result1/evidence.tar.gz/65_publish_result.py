"""Reuse D621 publication and audit the sole min1-to-min2 configuration change."""
import ast
import hashlib
from pathlib import Path
import sys

SOURCE = Path(__file__).resolve().parent.parent/'d621_20261017/publish_result.py'
data = SOURCE.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'e3541b4f4a813ac1167fb5bf7cea179c42750746f3124134a024f644859067f1'
code = data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d621_device_domain_full_w2/result1'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d632_min2_full_w2/result1'")
replace("assert git('rev-parse','HEAD')=='c2289327aeb3dc6cd086dfce2455ab2fb99924e7'",
        "assert git('rev-parse','HEAD')=='fa3b5eeda2ff395c5c7d6174d4fec32c0bda654e'")
replace("assert not git('diff','--cached','--name-only')", """gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
save(RAW/'publication_resource_gate.json',gate)
assert not git('diff','--cached','--name-only')""")
replace("assert read(RAW/'analysis_receipt.json')['passed']",
        "assert not read(RAW/'analysis_receipt.json')['passed']\nassert read(RAW/'analysis2_receipt.json')['passed']")
replace("for name in ('qualification','backup','start','analysis'):",
        "for name in ('qualification','qualification2','backup','start','collection','analysis','analysis2'):")
replace("old_path=RAW.parent/'d615_20261017/actual_qualification.json'",
        "old_path=RAW.parent/'d621_20261017/actual_qualification.json'")
replace("old_run='D615'","old_run='D621'")
replace('same_model_configuration_device_domain_revision_from_D615=True,',
        'same_production_source_model_minimum_replicas_revision_from_D621=True,')
old = "conclusion='D621 full W2 has 3798/4000 observed joint-SLO passes (94.95%), below the frozen 95% requirement by two requests, despite meeting the physical GPU-time budget. Relative to D615, GPU time and P95 TTFT are slightly lower but joint SLO is 0.475 percentage points worse. Retain this failed feasibility point; no rounding, same-key rerun, causal attribution, independent numerical qualification or final G1/G2 claim.'"
replace(old, "conclusion='D632 min2/max3 completed 4000 native-contract W2 requests: 3854 joint passes (96.35%), P95 TTFT 3553.622004 ms and 10914.192406 physical GPU-s, below the frozen 12086.669344 GPU-s budget. Compared with D621 min1/max3, joint SLO improves 1.4 percentage points and P95 TTFT decreases, while physical GPU time increases. Continue the same model configuration on W1 then W0; do not splice old min1 results. Independent numerical correctness and output differences remain unqualified; this is a known-workload single-run observation, not global superiority or a final G1/G2 claim.'")
replace("cap=read(RAW/'realized_replica_cap.json')", '''
import csv
import yaml
import ijson
configs=[ROOT/'configs/ieee_tc'/name for name in (
    '20261017_d621_7b_device_domain_full_w2.yaml',
    '20261017_d632_7b_min2_full_w2.yaml')]
normalized=[]
for path in configs:
    value=yaml.safe_load(path.read_text())
    del value['experiment']['output_dir']
    del value['storage']['nvme_cache_dir']
    del value['storage']['host_cache_dir']
    normalized.append(value)
def differences(left,right,prefix=()):
    assert type(left)==type(right),prefix
    if isinstance(left,dict):
        assert left.keys()==right.keys(),prefix
        return [change for key in left for change in differences(left[key],right[key],prefix+(key,))]
    return [] if left==right else [dict(path=list(prefix),reference=left,candidate=right)]
changes_config=differences(*normalized)
assert len(changes_config)==1 and changes_config[0]['path'][-1]=='min_instances'
assert changes_config[0]['reference']==1 and changes_config[0]['candidate']==2
old_binding=read(old_path.parent/'qualification.json')
for relative in ('scripts/run_all_experiments.py','faaslora/coordination/autoscaler.py',
                 'faaslora/cpu_frontend.py','faaslora/memory/residency_manager.py'):
    key=str(ROOT/relative)
    assert old_binding['refs'][key]==binding['refs'][key]==p.digest(ROOT/relative)
projection=RAW.parent/'d623_20261017/d621_projection.json'
projection_summary=ROOT/'paper_results/ieee_tc/p2_backend/d623_w2_slo_shortfall_diagnosis/summary.json'
sealed=read(projection_summary)
members=[v for v in sealed['archive_members'].values() if v['path']==str(projection)]
assert sealed['passed'] and len(members)==1
assert p.digest(projection)==members[0]['sha256']
parent={r['request_id']:r for r in read(projection)}
assert len(parent)==4000
seen=set();changes=[]
source_result=Path(audit['evidence']['source'])
assert p.digest(source_result)==audit['evidence']['source_sha256']
with source_result.open('rb') as stream:
    for request in ijson.items(stream,'detailed_results.tc_ieee_full.requests.item',use_float=True):
        rid=request['request_id'];assert rid not in seen;seen.add(rid)
        previous=parent[rid]
        checks={'adapter_id':'adapter_id','canonical_prompt_sha256':'prompt_sha256',
                'requested_completion_tokens':'target','generation_contract':'generation_contract',
                'completion_token_source':'token_source'}
        for key,old_key in checks.items():assert request[key]==previous[old_key],(rid,key)
        assert abs(request['scheduled_arrival_offset_s']-previous['arrival_s'])<1e-9
        assert request['native_token_timing']['actual_prompt_tokens']==previous['prompt_tokens']
        if request['completion_token_ids_sha256']!=previous['output_sha256']:
            changes.append(rid)
assert seen==set(parent)
comparison['matched_native_contract_count']=len(seen)
comparison['same_backend_output_hash_changes']=len(changes)
comparison['same_backend_changed_output_request_ids']=changes
comparison['same_backend_numerical_difference_cause']='unknown; no arithmetic equivalence or nondeterminism cause inferred'
comparison['normalized_config_differences']=changes_config
comparison['configuration_refs']={str(path):p.digest(path) for path in configs}
comparison['stage_mean_delta_ms']={key:value-old['stage_means_ms'][key] for key,value in audit['stage_means_ms'].items()}
comparison['equal_remote_count_and_bytes']=(old['remote_transfers']==audit['remote_transfers'] and old['remote_wire_bytes']==audit['remote_wire_bytes'])
comparison['source_order_phases']={'reference':old['source_order_phases'],'candidate':audit['source_order_phases']}
comparison['metric_protocol_sha256']=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')
comparison['single_run_protocol_sha256']=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')
minimum=read(RAW/'minimum_two_evidence.json')
assert minimum['passed'] and minimum['configured_min_instances']==2 and minimum['initial_activations']==2
comparison['minimum_two_evidence']=minimum
# Retain all five published baselines; do not interpret budget exclusion as tail dominance.
baseline_csv=ROOT/'paper_results/ieee_tc/main_comparison/d593_complete_7b/metrics.csv'
assert p.digest(baseline_csv)=='0e591949eaeb99e9255fbe2d6480a3070bb75b658ae3f5584daf2174cb66212f'
baseline_rows=[row for row in csv.DictReader(baseline_csv.read_text().splitlines())
    if row['workload']=='W2' and row['system']!='PrimeLoRA']
assert {row['system'] for row in baseline_rows}=={'vLLM','S-LoRA','ServerlessLLM','HydraServe','Loquetier'}
comparison['all_published_W2_baselines']=[dict(system=row['system'],source_run=row['run'],
    native_contract_count=int(row['binding_valid']),joint_slo=float(row['joint_slo']),
    p95_ttft_ms=float(row['p95_ttft_ms']),gpu_seconds=float(row['gpu_seconds']),
    joint95_observed=int(row['joint_good'])>=3800,
    within_frozen_budget=float(row['gpu_seconds'])<=reference['B_gpu_seconds'],
    PrimeLoRA_joint_percentage_point_delta=(audit['common_threshold_joint_count']-int(row['joint_good']))/40,
    PrimeLoRA_lower_better_p95_relative_change=(float(row['p95_ttft_ms'])-audit['stats']['p95_ttft_ms'])/float(row['p95_ttft_ms']),
    PrimeLoRA_lower_better_gpu_relative_change=(float(row['gpu_seconds'])-audit['stats']['physical_gpu_seconds'])/float(row['gpu_seconds']),
    independent_numerical_proof=False) for row in baseline_rows]
comparison['baseline_source']=dict(path=str(baseline_csv),sha256=p.digest(baseline_csv),
    interpretation='Existing measured configurations only; vLLM has better raw tail and joint SLO but exceeds this budget; HydraServe uses less GPU time but misses joint SLO. No same-budget dominance or global optimum proof.')
cap=read(RAW/'realized_replica_cap.json')''')
replace("run=RAW/'7b_device_domain_full_w2'","run=RAW/'7b_min2_full_w2'")
replace("ROOT/'docs/ieee_tc/D621_DEVICE_DOMAIN_FULL_W2.md',",
        "ROOT/'docs/ieee_tc/D632_MINIMUM_TWO_REPLICA_FULL_W2.md',\n    RAW.parent/'d621_20261017/publish_result.py',projection,projection_summary,baseline_csv,*configs,")
replace("names=['docs/ieee_tc/D621_DEVICE_DOMAIN_FULL_W2.md','docs/ieee_tc/EXECUTION_STATUS.md']",
        "names=['docs/ieee_tc/D632_MINIMUM_TWO_REPLICA_FULL_W2.md','docs/ieee_tc/EXECUTION_STATUS.md']")
replace('tc: retain W2 joint-SLO shortfall and complete lifecycle evidence (D621)',
        'tc: preserve min2 W2 SLO-resource tradeoff and full baseline comparison (D632)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D621 source SHA and D632 adaptation/AST passed; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code,str(SOURCE),'exec'),dict(__file__=__file__,__name__='d632_publication'))
else:
    raise SystemExit('expected no arguments or --check-only')
