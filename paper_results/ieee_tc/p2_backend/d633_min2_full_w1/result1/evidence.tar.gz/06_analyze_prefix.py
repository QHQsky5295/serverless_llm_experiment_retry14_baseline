"""Reuse D619's full W1 audit; preserve workload and measurement rules."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d619_20261017/analyze_prefix.py')
assert hashlib.sha256(source.read_bytes()).hexdigest() == 'd99edb2a1ab0c45e8ed92afb628614b46e07411f7dcf342fdd6696e436ec8756'
code = source.read_text()
for old, new in (
    ('7b_device_domain_full_w1', '7b_min2_full_w1'),
    ('d619_actual_initial_control_full4000_qualification_v1', 'd633_min2_full4000_w1_qualification_v1'),
):
    assert code.count(old) == 1, old
    code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
