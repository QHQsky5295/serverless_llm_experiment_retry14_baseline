"""Use verified D620 lossless storage for the old W1 source, without duplication."""
import ast
import contextlib
import hashlib
import io
from pathlib import Path
import sys

source=Path(__file__).resolve().parent/'publish_result.py'
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='cdb224b152014f56b731ddfc8a8879fa3aebff740e42fbfb755935c49962b7cd'
args=sys.argv[:]
namespace=dict(__file__=__file__,__name__='d633_publication_storage_template')
try:
    sys.argv=[str(source),'--check-only']
    with contextlib.redirect_stdout(io.StringIO()):
        exec(compile(data,str(source),'exec'),namespace)
finally:
    sys.argv=args
code=namespace['code']
def replace(old,new):
    global code
    assert code.count(old)==1,(old,code.count(old))
    code=code.replace(old,new)
replace('publication_identity.json','publication2_identity.json')
replace('publication_resource_gate.json','publication2_resource_gate.json')
replace('publication_receipt.json','publication2_receipt.json')
replace("('qualification','backup','start','collection','analysis')",
        "('qualification','backup','start','collection','analysis','publication')")
replace("assert p.digest(old_result)==old['evidence']['source_sha256']", '''
import gzip
compression_path=old_result.with_suffix(old_result.suffix+'.compression_receipt.json')
compression=read(compression_path)
storage_path=ROOT/'paper_results/ieee_tc/storage/d620_closed_evidence/summary.json'
storage=read(storage_path)
assert storage['passed'] and storage['storage']['source_archive_round_trip_verified']
entries=[row for row in storage['storage']['entries'] if row['source']==str(old_result)]
assert entries==[compression]
assert compression['removed_uncompressed_duplicate'] and not old_result.exists()
assert compression['source_sha256']==compression['audit_sha256']==old['evidence']['source_sha256']
old_archive=Path(compression['archive'])
assert p.digest(old_archive)==compression['archive_sha256']
digest=hashlib.sha256();decompressed_bytes=0
with gzip.open(old_archive,'rb') as stream:
    for block in iter(lambda:stream.read(1024*1024),b''):
        digest.update(block);decompressed_bytes+=len(block)
assert digest.hexdigest()==compression['source_sha256']
assert decompressed_bytes==compression['source_stamp']['size']
comparison['reference_lossless_storage']=dict(receipt=compression,
    receipt_path=str(compression_path),receipt_sha256=p.digest(compression_path),
    storage_summary_sha256=p.digest(storage_path),decompressed_sha_verified=True,
    duplicate_json_created=False)
''')
replace("with old_result.open('rb') as stream:","with gzip.open(old_archive,'rb') as stream:")
replace("RAW.parent/'d619_20261017/run_analysis.py',projection,projection_summary,baseline_csv,*configs,",
        "RAW.parent/'d619_20261017/run_analysis.py',projection,projection_summary,baseline_csv,*configs,compression_path,storage_path,")
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('D633 publication2 source hashes, verified-gzip adaptation and AST passed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'),dict(__file__=__file__,__name__='d633_publication2'))
else:
    raise SystemExit('expected no arguments or --check-only')
