"""Reuse exact-identity empty-scope closure for publication attempt three."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')
code=source.read_text()
old="name=sys.argv[1];assert name in ('qualification','qualification2','backup','start','analysis','analysis2','publication','publication2')"
assert code.count(old)==1
code=code.replace(old,"name='publication3'")
exec(compile(code,str(source),'exec'))
