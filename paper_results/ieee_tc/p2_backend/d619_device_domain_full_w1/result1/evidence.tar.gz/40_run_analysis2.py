"""Resume unchanged analyzer in its existing qualified vLLM environment.

Analysis1 used an unrelated interpreter without ijson; collection succeeded.
Preserve that failure and reuse its collected files, without replay/download.
"""
import json
from pathlib import Path

raw = Path(__file__).resolve().parent
receipt = json.loads((raw / 'analysis_receipt.json').read_text())
assert not receipt['passed']
assert [r['returncode'] for r in receipt['commands']] == [0, 1]
assert "ModuleNotFoundError: No module named 'ijson'" in (raw / 'analysis1.log').read_text()
closed = json.loads((raw / 'analysis_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
assert not (raw / 'actual_qualification.json').exists()
source = raw / 'run_analysis.py'
body = source.read_text()
old = "commands=[('collection1.log',[sys.executable,str(raw/'collect_closure.py')]),\n          ('analysis1.log',[sys.executable,str(raw/'analyze.py')])]"
assert body.count(old) == 1
body = body.replace(old, "commands=[('analysis2.log',[sys.executable,str(raw/'analyze.py')])]")
for old, new in [('analysis_identity.json', 'analysis2_identity.json'),
                 ('analysis_receipt.json', 'analysis2_receipt.json')]:
    assert body.count(old) == 1
    body = body.replace(old, new)
exec(compile(body, str(source), 'exec'), dict(__file__=str(source), __name__='d619_analysis2'))
