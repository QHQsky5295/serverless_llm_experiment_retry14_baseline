"""D619: reuse D615 explicit-source publication with observed trade-offs.
The retained D615 source is included in this result's hashed evidence archive.
"""
import ast, hashlib, io, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d619_device_domain_full_w1/result1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD')=='1d897b82dfb605f10eaaa7c1c4c40d702b5f64e7'
assert not git('diff','--cached','--name-only')
assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')
audit=read(RAW/'actual_qualification.json');mechanism=read(RAW/'initial_control_evidence.json')
assert audit['passed'] and audit['protocol_bound_count']==4000 and audit['native_tokens']==458224
assert audit['stats']['n_correct'] is None and audit['fixed_workload_complete4000']
assert mechanism['initial']['state']=='serving' and not mechanism['initial']['failures']
assert read(RAW/'analysis2_receipt.json')['passed']
for ref in audit['refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
for name in ('qualification','backup','start','analysis','analysis2'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
local=read(RAW/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
binding=read(RAW/'qualification.json')
for path,sha in {**binding['refs'],**binding['preserved']}.items():assert p.digest(Path(path))==sha,path
old_path=RAW.parent/'d551_20261015/actual_qualification.json'
old=read(old_path)
assert old['passed'] and old['protocol_bound_count']==4000 and old['native_tokens']==458224
assert old['workload_identity']==audit['workload_identity']
reference_path=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft/resident_references.json'
reference=read(reference_path)['W1']
assert reference['reference_frozen'] and reference['source_run']=='D536'
assert reference['budget_fraction']==0.75
comparison=dict(
    old_run='D551',reference_audit_path=str(old_path),reference_audit_sha256=p.digest(old_path),
    old_joint_count=old['common_threshold_joint_count'],new_joint_count=audit['common_threshold_joint_count'],
    joint_percentage_point_delta=(audit['common_threshold_joint_count']-old['common_threshold_joint_count'])/40,
    old_stats=old['stats'],new_stats=audit['stats'],
    relative_improvement_lower_better={key:(old['stats'][key]-audit['stats'][key])/old['stats'][key]
        for key in ('mean_ttft_ms','p95_ttft_ms','mean_tpot_ms','p95_tpot_ms','mean_e2e_ms','physical_gpu_seconds')},
    stage_means_ms={'reference':old['stage_means_ms'],'candidate':audit['stage_means_ms']},
    window_gpu_seconds={'reference':old['window_gpu_seconds'],'candidate':audit['window_gpu_seconds']},
    resource_reference=dict(path=str(reference_path),sha256=p.digest(reference_path),record=reference),
    U_over_B=audit['stats']['physical_gpu_seconds']/reference['B_gpu_seconds'],
    joint95_observed=audit['common_threshold_joint_count']>=3800,
    budget_feasible_observed=audit['stats']['physical_gpu_seconds']<=reference['B_gpu_seconds'],
    gpu_seconds_per_offered=audit['stats']['physical_gpu_seconds']/4000,
    gpu_seconds_per_correct=None,
    resident_resource_reduction_fraction=1-audit['stats']['physical_gpu_seconds']/reference['U_ref_gpu_seconds'],
    budget_headroom_gpu_seconds=reference['B_gpu_seconds']-audit['stats']['physical_gpu_seconds'],
    whole_cache_prestate_equivalence_proved=False,
    multiple_code_and_configuration_differences_from_D551=True,
    causal_single_mechanism_performance_attribution=False,
    candidate_selected_for_same_configuration_cross_workload_validation=True,
    conclusion='D619 full W1 meets observed latency and budget conditions. Relative to older D551 W1, GPU time is lower but joint SLO and latency are worse; retain all regressions. Multiple changes preclude single-mechanism causal attribution. This is not independent numerical qualification, cross-scene optimality or final G1/G2.')
cap=read(RAW/'realized_replica_cap.json')
assert cap['passed'] and cap['configured_max_instances']==3
assert cap['max_ready_plus_pending']==cap['max_target']==3
comparison['realized_replica_cap']=cap
# Native device-domain evidence, using retained CPU records and physical journals.
cpu=read(RAW/'cpu_preparation_evidence.json')
assert cpu['legal_devices']==[0,1,2,3]
active=[r for r in cpu['records'] if r['state']=='activation_sent']
assert len(active)==5 and len(cpu['records'])==6
assert all(r['process_returncode']==0 for r in cpu['records'])
for row in cpu['records']:
    obs=row['observation']
    assert obs['status']=='cpu_prepared' and not obs['engine_ready']
    state=obs['context_state']
    assert state['current_context']==state['primary_active']==0 and not state['torch_cuda_initialized']
    assert state['driver_device_count']==1
    assert state['cuda_visible_devices']==row['preparation']['gpu_uuid']
    if row['state']=='activation_sent':
        assert obs['prepared_at_s']<=row['activation']['granted_at_s']
run=RAW/'7b_device_domain_full_w1'
journals=sorted((run/'launch.launch/physical_allocations').glob('*.jsonl'))
leases=[]
for path in journals:
    rows=[json.loads(line) for line in path.read_text().splitlines()]
    acquire=[r for r in rows if r['event']=='acquire']
    release=[r for r in rows if r['event']=='release']
    bound=[r for r in rows if r['event']=='prepared_worker_bind']
    native=[r for r in rows if r['event']=='native_workers']
    assert len(acquire)==len(release)==len(bound)==len(native)==1
    assert acquire[0]['at']<release[0]['at'] and len(acquire[0]['gpu_uuids'])==1
    assert all(r['clock_id']==acquire[0]['clock_id'] for r in rows)
    matching=[r for r in active if r['preparation']['preparation_id']==bound[0]['preparation']['preparation_id']]
    assert len(matching)==1
    assert matching[0]['activation']['permission']['lease_id']==acquire[0]['lease_id']
    leases.append(dict(path=str(path),sha256=p.digest(path),uuid=acquire[0]['gpu_uuids'][0],
        begin=acquire[0]['at'],end=release[0]['at'],
        native_workers_at=native[0]['at'],preparation_id=bound[0]['preparation']['preparation_id']))
gpu3='GPU-c4663821-4888-e199-7151-d6298f8d45a5'
new=next(r for r in leases if r['uuid']==gpu3)
held=[r for r in leases if r['uuid']!=gpu3 and r['begin']<=new['begin']<r['end']]
assert len(held)==3
overlap=min(r['end'] for r in held)-new['begin']
assert overlap>0
service_log=run/'launch.launch/service.log'
text_log=service_log.read_text()
service_match=re.search(r'ieee-activation-[a-f0-9]+ gpu=3 active=[1-9][0-9]*[^\n]*',text_log)
assert service_match
physical=read(run/'launch.launch/physical_deployment/summary.json')
assert abs(sum(r['end']-r['begin'] for r in leases)-physical['gpu_seconds'])<1e-6
import ijson
outcome=run/'launch.launch/physical_deployment/main_outcome.json'
with outcome.open('rb') as handle:
    scalein=next(ijson.items(handle,'mechanism_events._ieee_scalein_events',use_float=True))
domain=dict(passed=True,cpu_preparation_records=6,activated_records=5,abandoned_records=1,
    all_processes_exited_zero=True,all_preparation_observed_cpu_only=True,
    legal_devices=cpu['legal_devices'],physical_leases=leases,
    other_three_devices_still_held_at_gpu3_acquire=held,
    four_device_physical_overlap_seconds=overlap,
    gpu3_service_log_excerpt=service_match.group(0),scalein_events=scalein,
    physical_overlap_included_in_U=True,source_refs={
        str(RAW/'cpu_preparation_evidence.json'):p.digest(RAW/'cpu_preparation_evidence.json'),
        str(service_log):p.digest(service_log),str(outcome):p.digest(outcome)})
save(RAW/'device_domain_evidence.json',domain)
comparison['device_domain_evidence']=domain
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),*RAW.glob('*.json'),
    *(path for path in RAW.glob('*.log') if path.name!='remote_monitor.log')])
files += [reference_path,old_path,run/'launch.json',run/'launch.launch/physical_deployment/summary.json',
    ROOT/'docs/ieee_tc/D619_DEVICE_DOMAIN_FULL_W1.md',
    RAW.parent/'d615_20261017/publish_result.py',RAW.parent/'d550_20261015/close.py']
files += journals
for folder in sorted(set(re.findall(r'preserved dedicated worker workdir: (\S+)',text_log))):
    path=Path(folder)/'worker.log'
    assert path.is_relative_to(ROOT/'results/worker_failures')
    if path.is_file():files.append(path)
OUT.mkdir(parents=True,exist_ok=False);members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as bundle:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<8*1024*1024;clean(data)
        if path.suffix=='.py':ast.parse(data)
        name=f'{i:02d}_{path.name}';info=tarfile.TarInfo(name)
        info.size,info.mode,info.mtime=len(data),0o600,0
        bundle.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'summary.json',dict(passed=True,native_full_qualified=True,full_performance_complete=True,
    independent_numerical_correctness='unknown',raw_n_correct=None,ranking_eligible=False,
    audit=audit,mechanism=mechanism,comparison=comparison,protected=protected,execution_commit=git('rev-parse','HEAD'),
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz')))
with (OUT/'result.sha256').open('x') as stream:
    for name in ('summary.json','evidence.tar.gz'):stream.write(p.digest(OUT/name)+'  '+name+'\n')
names=['docs/ieee_tc/D619_DEVICE_DOMAIN_FULL_W1.md','docs/ieee_tc/EXECUTION_STATUS.md']
names += [str((OUT/name).relative_to(ROOT)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
for name in names:
    if not name.endswith('.tar.gz'):clean((ROOT/name).read_bytes())
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: seal W1 device-domain validation and resource-latency trade-off (D619)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD');remote=git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
