"""D354: reuse sealed D351 timing streams; no inference or latency subtraction."""
import collections
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import summarize_core_host_spans, core_interval_overlap, write_csv

RAW=Path(__file__).resolve().parent
BASE=ROOT/'paper_results/ieee_tc/p2_backend/d351_core_timing/analysis1'
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d354_input_turns/analysis1'
identity=p.scope_identity(p.cg_path().name)
group=Path(identity['path'])
def sample():
    return {k:(group/k).read_text().strip() for k in
        ('memory.high','memory.max','memory.peak','memory.events','memory.swap.max','memory.swap.current')}
before=sample()
assert before['memory.high']==str(3*p.GIB) and before['memory.max']==str(4*p.GIB)
assert before['memory.swap.max']=='0' and os.sched_getaffinity(0)=={2,3,26,27}
gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not OUT.exists()
python='/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python'
command=[python,'-m','unittest','tests.test_ieee_tc_core_timing_analysis',
         'tests.test_ieee_tc_core_timing','-q']
passed=False
try:
    with (RAW/'tests.log').open('x') as f:
        result=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
    result.check_returncode()
    manifest=json.loads((BASE/'manifest.json').read_text())
    for name,expected in manifest['outputs'].items():
        assert p.digest(BASE/name)==expected,(name,'prior output digest mismatch')
    summary=json.loads((BASE/'core_timing/summary.json').read_text())
    assert summary['complete_processes']==summary['processes']==12
    assert summary['complete_request_observations']==summary['diagnostic_count']==1000
    with (BASE/'core_timing/decode_windows.csv').open() as f: windows=list(csv.DictReader(f))
    with (BASE/'core_timing/processes.csv').open() as f: processes=list(csv.DictReader(f))
    assert len(windows)==len({r['request_id'] for r in windows})==1000
    assert all(r['observation_complete']=='True' for r in windows)
    sources=[];turns=[];requests=[];process_rows=[]
    streams=[s for s in summary['sources'] if Path(s['path']).suffix=='.jsonl']
    assert len(streams)==12
    for source in streams:
        path=Path(source['path'])
        assert not path.is_symlink() and path.stat().st_size==source['bytes']<=64*1024**2
        assert p.digest(path)==source['sha256']
        events=[];digest=hashlib.sha256()
        with path.open('rb') as f:
            for i,line in enumerate(f):
                assert len(line)<=8192 and line.endswith(b'\n') and i<=200002
                digest.update(line)
                row=json.loads(line)
                if i==0: header=row
                else: events.append(row)
        assert digest.hexdigest()==source['sha256']
        assert header['clock_id']==summary['clock_id']
        assert header['event']=='native_core_host_timing_v1'
        assert header['diagnostic_prefix_count']==1000
        assert header['formal_performance_result'] is False and header['gpu_kernel_timing'] is False
        pid=header['pid']
        assert path.stem==f"{pid}-{header['start_ticks']}"
        old=[r for r in processes if r['pid']==str(pid)]
        assert len(old)==1 and old[0]['process']==path.stem and old[0]['complete']=='True'
        audit=summarize_core_host_spans(events,include_input_turns=True)
        assert audit['complete'] and audit['spans']==int(old[0]['spans'])
        turn=audit['input_turns']
        process_rows.append(dict(process=path.stem,pid=pid,spans=audit['spans'],
            **{k:turn[k] for k in ('input_turns','empty_input_turns','work_input_turns')},
            **{k+'_ms':v['total_ns']/1e6 for k,v in turn['index'].items()}))
        turns.extend(dict(process=path.stem,pid=pid,**r) for r in turn['records'])
        for w in (r for r in windows if r['worker_pid']==str(pid)):
            a,b=int(w['first_ns']),int(w['last_ns'])
            assert audit['first_ns']<=a<=b<=audit['last_ns']
            assert w['timing_tpot_miss'] in ('True','False')
            for category in ('client','input_nonclient','step'):
                measured=core_interval_overlap(audit['index'][category],a,b)/1e6
                assert math.isclose(measured,float(w[category+'_ms']),abs_tol=1e-9,rel_tol=1e-12)
            record=dict(request_id=w['request_id'],worker_pid=pid,tokens=int(w['tokens']),
                timing_tpot_miss=w['timing_tpot_miss']=='True',first_ns=a,last_ns=b,
                tpot_ms=float(w['tpot_ms']),decode_ms=float(w['decode_ms']),
                client_ms=float(w['client_ms']))
            record.update({key+'_ms':core_interval_overlap(value,a,b)/1e6
                           for key,value in turn['index'].items()})
            assert record['work_client_ms']<=record['client_ms']+1e-9
            requests.append(record)
        sources.append(source)
        del events,audit,turn
    assert len(requests)==len({r['request_id'] for r in requests})==1000
    hist=collections.Counter(('work' if r['unfinished_before'] else 'idle_at_entry',
        r['client_count'],r['utility_count']) for r in turns)
    histogram=[dict(state=s,client_count=c,utility_count=u,turn_count=n)
               for (s,c,u),n in sorted(hist.items())]
    groups=[]
    keys=[k for k in requests[0] if k.endswith('_ms')]
    for name,select in [('all',lambda r:True),('short_2_32',lambda r:2<=r['tokens']<=32),
                        ('long_33_256',lambda r:33<=r['tokens']<=256)]:
        for miss in (False,True):
            rows=[r for r in requests if select(r) and r['timing_tpot_miss']==miss]
            groups.append(dict(group=name,timing_tpot_miss=miss,count=len(rows),
                overlapping_after_first_utility=sum(r['work_clients_after_first_utility_ms']>0 for r in rows),
                **{'mean_'+k:math.fsum(r[k] for r in rows)/len(rows) if rows else None for k in keys}))
    def describe(values):
        values=sorted(values)
        return dict(count=len(values),total=math.fsum(values),
            mean=math.fsum(values)/len(values) if values else None,
            p50=values[math.ceil(.5*len(values))-1] if values else None,
            p95=values[math.ceil(.95*len(values))-1] if values else None,
            maximum=values[-1] if values else None)
    turn_summary=[]
    for state,select in [('work',lambda r:r['unfinished_before']>0),
                         ('idle_at_entry',lambda r:r['unfinished_before']==0)]:
        rows=[r for r in turns if select(r)]
        turn_summary.append(dict(state=state,nonempty_turns=len(rows),
            multi_client_turns=sum(r['client_count']>1 for r in rows),
            multi_utility_turns=sum(r['utility_count']>1 for r in rows),
            client_count=describe([r['client_count'] for r in rows]),
            utility_count=describe([r['utility_count'] for r in rows]),
            **{k+'_ms':describe([r[k]/1e6 for r in rows]) for k in
                ('client_ns','client_thread_cpu_ns','utility_ns','clients_after_first_ns',
                 'clients_after_first_utility_ns')}))
    for path in (BASE/'manifest.json',BASE/'core_timing/summary.json',
                 BASE/'core_timing/decode_windows.csv',BASE/'core_timing/processes.csv',
                 ROOT/'scripts/analyze_control_path_overhead.py',Path(__file__),
                 ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
                 Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
                 Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm/v1/engine/core.py')):
        sources.append(dict(path=str(path),bytes=path.stat().st_size,sha256=p.digest(path)))
    OUT.mkdir(parents=True,exist_ok=False)
    for name,rows in [('processes',process_rows),('turns',turns),('turn_histogram',histogram),
                      ('decode_windows',sorted(requests,key=lambda r:r['request_id'])),('groups',groups)]:
        write_csv(rows,OUT/(name+'.csv'))
    output=dict(kind='d354_retained_input_turn_audit_v1',new_gpu_run=False,
        formal_performance_result=False,gpu_kernel_timing=False,n_correct=None,
        diagnostic_contract='D351 intrusive prefix1000, before D352; not D353 ordinary Full',
        processes=len(process_rows),requests=len(requests),clock_id=summary['clock_id'],
        input_turns=sum(r['input_turns'] for r in process_rows),
        work_input_turns=sum(r['work_input_turns'] for r in process_rows),
        turn_summary=turn_summary,groups=groups,sources=sources,caveats=[
            'All intervals are observed host spans including instrumentation; no counterfactual latency is calculated.',
            'Work/idle is measured at parent entry; child operations can change scheduler work. No child eligibility inferred.',
            'Suffix is measured client time after the first client/utility in the same input turn; it excludes observer gaps.',
            'Suffix is a subset of client time, not an additional phase. Concurrent request intersections cannot be summed as service time.',
            'Host occupancy is not GPU idle or kernel time. Interleaving can also delay control completion and change batching.',
            'TPOT pass/miss is the unchanged provisional D170 timing ruler, not final qualification or a causal group assignment.'])
    with (OUT/'summary.json').open('x') as f:json.dump(output,f,indent=2,allow_nan=False)
    with (OUT/'manifest.json').open('x') as f:
        json.dump(dict(outputs={str(x.relative_to(OUT)):p.digest(x) for x in sorted(OUT.glob('*')) if x.is_file()},
                       source_refs=sources),f,indent=2)
    passed=True
    print(json.dumps(dict(input_turns=output['input_turns'],turn_summary=turn_summary,groups=groups)))
finally:
    with (RAW/'analysis_receipt.json').open('x') as f:
        json.dump(dict(passed=passed,identity=identity,before=before,after=sample(),gate=gate,
                       test_command=command,no_gpu_run=True),f,indent=2)
