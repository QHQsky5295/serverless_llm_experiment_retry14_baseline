"""D354 owned-scope closure and small reproducibility bundle, no model work."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
BASE=ROOT/'paper_results/ieee_tc/p2_backend/d354_input_turns'
identity=p.scope_identity(p.cg_path().name)
group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
receipt=json.loads((RAW/'analysis_receipt.json').read_text())
assert receipt['passed'] and receipt['no_gpu_run']
old=receipt['identity']
assert old!=identity and p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
cleanup=p.stop_scope_identity(old)
assert cleanup['released'] and not cleanup['hard_kill'] and not Path(old['path']).exists()
with (RAW/'analysis_scope_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,cleanup=cleanup),f,indent=2)
manifest=json.loads((BASE/'analysis1/manifest.json').read_text())
for name,expected in manifest['outputs'].items():
    assert p.digest(BASE/'analysis1'/name)==expected
for ref in manifest['source_refs']:
    assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
allowed='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert protected['changed']==[allowed]
assert p.digest(Path(allowed))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
user=ROOT/'configs/generated/lora_manifest_1000.json'
assert p.digest(user)=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='retry14_continuous_queue_v2'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
with (RAW/'protection.json').open('x') as f:
    json.dump(dict(protected=protected,allowed_historical_change=allowed,
                   user_manifest_sha256=p.digest(user),gate=gate),f,indent=2)
members={
    'audit_input_turns.py':RAW/'audit_input_turns.py',
    'seal_and_verify.py':Path(__file__),
    'analysis_receipt.json':RAW/'analysis_receipt.json',
    'analysis_scope_cleanup.json':RAW/'analysis_scope_cleanup.json',
    'tests.log':RAW/'tests.log',
    'protection.json':RAW/'protection.json',
    'analyze_control_path_overhead.py':ROOT/'scripts/analyze_control_path_overhead.py',
    'test_ieee_tc_core_timing_analysis.py':ROOT/'tests/test_ieee_tc_core_timing_analysis.py',
    'native_vllm_0_30_core.py':Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm/v1/engine/core.py'),
}
archive=BASE/'evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for name,path in members.items():bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    assert len(bundle.getmembers())==len(members)
    for member in bundle.getmembers():
        assert member.isfile() and member.name in members
        assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest()==p.digest(members[member.name])
with (BASE/'closure.json').open('x') as f:
    json.dump(dict(kind='d354_retained_audit_closure_v1',tests_passed=18,
        old_scope_closed=True,protected=protected,user_manifest_unchanged=True,
        archive=dict(path=str(archive.relative_to(ROOT)),sha256=p.digest(archive),
                     bytes=archive.stat().st_size,members={n:p.digest(x) for n,x in members.items()}),
        files={str(x.relative_to(ROOT)):p.digest(x) for x in sorted(BASE.rglob('*')) if x.is_file()},
        service_code_changed=False,new_gpu_run=False,formal_qualification=False),f,indent=2)
with (RAW/'seal_scope.json').open('x') as f:
    json.dump(dict(identity=identity,resources={k:(group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current')},passed=True),f,indent=2)
print(json.dumps(dict(passed=True,files=len(manifest['outputs']),archive_members=len(members),
    archive_bytes=archive.stat().st_size,protected_entries=protected['entry_count'])))
