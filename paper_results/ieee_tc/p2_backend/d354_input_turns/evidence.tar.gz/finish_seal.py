"""Resume D354 sealing only; retain original self-referential manifest failure."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
BASE=ROOT/'paper_results/ieee_tc/p2_backend/d354_input_turns'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],p.GIB);assert gate['preflight_pass'],gate['issues']
prior=json.loads((RAW/'analysis_scope_cleanup.json').read_text())
assert prior['cleanup']['released'] and not Path(prior['identity']['path']).exists()
failed=p.scope_identity('primelora-tc-aux-2b3c2a3cf8f5413e87d3eaf70770b124.scope')
assert p.scope_still_owned(failed) and not p.owned_pids(Path(failed['path']))
cleanup=p.stop_scope_identity(failed)
assert cleanup['released'] and not cleanup['hard_kill']
manifest=json.loads((BASE/'analysis1/manifest.json').read_text())
assert manifest['outputs']['manifest.json']==hashlib.sha256(b'').hexdigest()
verified={}
for name,expected in manifest['outputs'].items():
    if name=='manifest.json':continue
    assert p.digest(BASE/'analysis1'/name)==expected,(name,'non-self output mismatch')
    verified[name]=expected
assert set(verified)=={'decode_windows.csv','groups.csv','processes.csv','summary.json','turn_histogram.csv','turns.csv'}
for ref in manifest['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256']
with (BASE/'analysis1/validated_manifest.json').open('x') as f:
    json.dump(dict(outputs=verified,source_refs=manifest['source_refs'],
        original_manifest_sha256=p.digest(BASE/'analysis1/manifest.json'),
        original_self_entry_invalid=True,
        reason='Original writer opened manifest before output glob; self entry hashed the empty file. All six measured outputs and all sources match. Preserve original, exclude self in this index.',
        no_reanalysis=True,no_gpu_rerun=True),f,indent=2)
with (RAW/'seal_failure_receipt.json').open('x') as f:
    json.dump(dict(failed_identity=failed,cleanup=cleanup,returncode=1,
        failure='AssertionError on manifest.json self entry; analysis and six outputs unchanged',
        original_seal_script_sha256=p.digest(RAW/'seal_and_verify.py')) ,f,indent=2)
protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
allowed='/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'
assert protected['changed']==[allowed]
assert p.digest(Path(allowed))=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
with (RAW/'protection.json').open('x') as f:json.dump(dict(protected=protected,gate=gate),f,indent=2)
members={x.name:x for x in RAW.iterdir() if x.is_file()}
members.update({
    'analyze_control_path_overhead.py':ROOT/'scripts/analyze_control_path_overhead.py',
    'test_ieee_tc_core_timing_analysis.py':ROOT/'tests/test_ieee_tc_core_timing_analysis.py',
    'native_vllm_0_30_core.py':Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm/v1/engine/core.py')})
archive=BASE/'evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for name,path in members.items():bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    assert len(bundle.getmembers())==len(members)
    for member in bundle.getmembers():
        assert member.isfile() and member.name in members
        assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest()==p.digest(members[member.name])
with (BASE/'closure.json').open('x') as f:
    json.dump(dict(kind='d354_retained_audit_closure_v1',tests_passed=18,
        analysis_scope_closed=True,failed_seal_scope_closed=True,protected=protected,user_manifest_unchanged=True,
        archive=dict(path=str(archive.relative_to(ROOT)),sha256=p.digest(archive),
                     bytes=archive.stat().st_size,members={n:p.digest(x) for n,x in members.items()}),
        files={str(x.relative_to(ROOT)):p.digest(x) for x in sorted(BASE.rglob('*')) if x.is_file()},
        manifest_self_hash_failure_retained=True,service_code_changed=False,new_gpu_run=False,
        formal_qualification=False),f,indent=2)
with (RAW/'seal_scope.json').open('x') as f:
    json.dump(dict(identity=identity,resources={k:(group/k).read_text().strip() for k in
        ('memory.peak','memory.events','memory.swap.current')},passed=True),f,indent=2)
print(json.dumps(dict(passed=True,measured_outputs=len(verified),archive_members=len(members),
    archive_bytes=archive.stat().st_size,protected_entries=protected['entry_count'])))
