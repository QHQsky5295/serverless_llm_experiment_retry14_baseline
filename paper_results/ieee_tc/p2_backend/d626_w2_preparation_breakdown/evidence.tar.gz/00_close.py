"""Reuse exact-identity recursive-empty closure for the two bounded analyses."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/close.py')
exec(compile(source.read_text(),str(source),'exec'))
