"""Reuse sealed D594 remote timeline audit on the closed D621 W2 result."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/remote_diagnosis.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='79c0000d3af7f560627de1ae2fcdb8ea169e09a42f7a4068f19ec414ddec4936'
code=data.decode()
def replace(before,after):
    global code
    assert code.count(before)==1,before
    code=code.replace(before,after)
replace('import csv, json, math, os, subprocess, sys','import csv, gzip, json, math, os, subprocess, sys')
replace("OUT=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft'", "OUT=RAW/'derived'")
begin=code.index("old=read(OUT/'manifest.json')")
end=code.index('all_rows=[];',begin)
code=code[:begin]+'''parent_path=ROOT/'paper_results/ieee_tc/p2_backend/d623_w2_slo_shortfall_diagnosis/summary.json'
assert p.digest(parent_path)=='1a99156ef114c213eac1c095baa6ba849ea43c93e0d9cef86ca699413f449009'
parent=read(parent_path)
assert parent['passed'] and parent['diagnosis']['passed']
projection_path=RAW.parent/'d623_20261017/d621_projection.json'
assert p.digest(projection_path)=='0ae773542859f3f52e78bacf0f09fe46e176194189efa288c760e5bc743e6c00'
assert any(x['path']==str(projection_path) and x['sha256']==p.digest(projection_path)
    for x in parent['archive_members'].values())
rows=read(projection_path)
assert len(rows)==4000 and sum(r['joint'] for r in rows)==3798
assert sorted(r['source_index'] for r in rows)==list(range(4000))
stages={('D621',r['request_id']):dict(r,source_quarter=r['source_index']//1000+1,
    joint=str(r['joint'])) for r in rows}
assert len(stages)==4000
sources={r['path']:r['sha256'] for r in parent['diagnosis']['source_refs']
    if '/d621_' in r['path'] and '/experiment_results_' in r['path']}
assert len(sources)==1
sources.update({str(parent_path):p.digest(parent_path),str(projection_path):p.digest(projection_path)})
OUT.mkdir(exist_ok=False)
'''+code[end:]
replace("[('D551','W1'),('D554','W2')]", "[('D621','W2')]")
replace("with source.open('rb') as f:", "with gzip.open(source,'rb') as f:")
replace("sources[str(journal)]=p.digest(journal)", """sources[str(journal)]=p.digest(journal)
    assert sources[str(journal)]=='72ffe3acc6a911d16a473dc964c4270876719f673130b068a3ee056a84a917ab'""")
replace("tier=prep['tier'],joint=st['joint']=='True',transfer_id=remote['http_transfer_id'],", "tier=prep['tier'],joint=st['joint']=='True',dominant_ttft_stage=st['dominant_ttft_stage'],transfer_id=remote['http_transfer_id'],")
replace("cohorts += [('joint',str(v),[r for r in rows if r['joint']==v]) for v in (False,True)]", """cohorts += [('joint',str(v),[r for r in rows if r['joint']==v]) for v in (False,True)]
    cohorts += [('joint_false_preparation_dominant','True',[r for r in rows if not r['joint']
        and r['dominant_ttft_stage']=='admission_to_engine_dispatch_ms'])]""")
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('Sealed D594 adaptation AST passed; no analysis executed.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
