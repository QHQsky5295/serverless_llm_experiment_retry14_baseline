"""Reuse sealed D594 serial pressure barrier decomposition, without a new inference."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/pressure_diagnosis.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='0bf0f1fbc3b1be49a374e72f4ee57c1a5aeb72f739e9716ad96857a52f883ac3'
code=data.decode()
def replace(before,after):
    global code
    assert code.count(before)==1,before
    code=code.replace(before,after)
replace('import csv, json, math, os, subprocess, sys','import csv, gzip, json, math, os, subprocess, sys')
replace("OUT=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft'", "OUT=RAW/'derived'")
replace("[('D551','W1'),('D554','W2')]", "[('D621','W2')]")
assert code.count("with source.open('rb') as f:")==2
code=code.replace("with source.open('rb') as f:","with gzip.open(source,'rb') as f:")
replace("joint=old['joint']=='True',participants=len(s['participants']),", "joint=old['joint']=='True',dominant_ttft_stage=old['dominant_ttft_stage'],participants=len(s['participants']),")
replace("groups=[('all','all',values)]+[('quarter',str(i),[v for v in values if v['source_quarter']==i]) for i in range(1,5)]", """groups=[('all','all',values)]+[('quarter',str(i),[v for v in values if v['source_quarter']==i]) for i in range(1,5)]
    groups += [('joint',str(b),[v for v in values if v['joint']==b]) for b in (False,True)]
    groups += [('joint_false_preparation_dominant','True',[v for v in values if not v['joint']
        and v['dominant_ttft_stage']=='admission_to_engine_dispatch_ms'])]""")
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('Sealed D594 pressure adaptation AST passed; no analysis executed.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
