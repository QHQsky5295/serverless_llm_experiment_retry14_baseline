"""Reuse sealed D612 publication with the two closed D626 diagnostic receipts."""
import ast
import hashlib
from pathlib import Path
import sys

source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/publish.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code=data.decode()
def replace(before,after):
    global code
    assert code.count(before)==1,before
    code=code.replace(before,after)

replace('d612_w2_quality_resource_diagnosis','d626_w2_preparation_breakdown')
replace('f72091155cd3bb258651fc461db11b9113c72faf','9392fcab2f07ca973d0452d1aff2af27ff7471b7')
replace("diagnosis=read(RAW/'diagnosis.json')", """remote_receipt=read(RAW/'remote_diagnosis_receipt.json')
pressure_receipt=read(RAW/'pressure_diagnosis_receipt.json')
assert remote_receipt['passed'] and pressure_receipt['passed']
for receipt in (remote_receipt,pressure_receipt):
    for name,sha in receipt['outputs'].items():
        assert p.digest(RAW/'derived'/name)==sha,name
remote=read(RAW/'derived/remote_diagnosis.json')
pressure=read(RAW/'derived/pressure_diagnosis.json')
assert remote['passed'] and pressure['passed']
assert remote['results']['W2']['counts']==dict(requests=4000,selected_remote=506,
    has_owned_remote_receipt=495,owned_remote_but_native_reused=1)
assert pressure['results']['W2']['matched']==494
assert remote['results']['W2']['groups'][0]['n']==494
assert next(g for g in remote['results']['W2']['groups']
    if g['group']=='joint_false_preparation_dominant')['n']==105
refs={r['path']:r['sha256'] for r in remote_receipt['source_refs']}
for path,sha in pressure_receipt['sources'].items():
    if path in refs:assert refs[path]==sha
    refs[path]=sha
diagnosis=dict(passed=True,n_correct=None,ranking_eligible=False,inference_runs_added=0,
    source_refs=[dict(path=path,sha256=sha) for path,sha in sorted(refs.items())],
    remote=remote,pressure={**pressure,'results':{w:{k:v for k,v in r.items() if k!='rows'}
        for w,r in pressure['results'].items()}},
    all_pressure_rows_retained_in_archive=True,production_changed=False,
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'))
assert diagnosis['metric_protocol_sha256']=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert diagnosis['single_run_protocol_sha256']=='193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d'""")
replace("for name in ('analysis',):", "for name in ('remote_diagnosis','pressure_diagnosis'):")
replace("assert read(RAW/'analysis_receipt.json')['diagnosis_sha256']==p.digest(RAW/'diagnosis.json')", "assert len(pressure['results']['W2']['rows'])==494")
replace("assert sum(x['n'] for x in diagnosis['matched_transitions'].values())==8000//2", "assert remote['results']['W2']['server_all_transfers']['n']==497")
replace("assert diagnosis['runs']['D607']['all']['joint']==3762", "assert remote['results']['W2']['groups'][0]['joint']==382")
replace("assert diagnosis['runs']['D611']['all']['joint']==3819", "assert pressure['results']['W2']['remote_pressure_records']==497")
replace("assert not any('host_memory_below_stop' in x or 'filesystem_below_stop' in x for x in gate['issues'])", "assert gate['preflight_pass'],gate['issues']")
replace('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md','D626_W2_PREPARATION_BREAKDOWN.md')
replace("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']", """files += sorted((RAW/'derived').glob('*'))
parent=RAW.parent.parent/'main_comparison/d594_20261017'
files += [doc,parent/'remote_diagnosis.py',parent/'pressure_diagnosis.py',parent/'close.py',
    RAW.parent/'d612_20261017/publish.py',RAW.parent/'d625_20261017/publication_closure.json']""")
replace('d612_reused_parent_closed_log_diagnosis_v1','d626_closed_remote_preparation_breakdown_v1')
replace('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
        'tc: separate remote delivery and preparation control waits in W2 (D626)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:
    print('Sealed D612 publication adaptation AST passed; no publication executed.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
