#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d115_20260929
unit=primelora-d115-full10-curate-20260929.scope
test "$(systemctl --user show primelora-tc-svc-16ee4f86ca8743e293af67feb1723916.scope -p ActiveState --value)" = inactive
test "$(systemctl --user show primelora-d115-full10-project-20260929.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full10_curation_scope.txt"
exec /usr/bin/time -v -o "$raw/full_full10_curation_time.txt" \
  /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/summarize_full_full10.py" > "$raw/full_full10_curation.log" 2>&1
