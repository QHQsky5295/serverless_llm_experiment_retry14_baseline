# D96 bounded request projection adapted to the existing completed_scenario_windows
# failure-retention schema. Preserve every non-request outcome field, including
# original cleanup errors and all mechanism events. Metadata ends before byte
# 35696635 in this run; repeated request-native inventories are not materialized.
# Neither raw data nor its failure classification is changed.
reduce inputs as $item
  ({requests: []};
   if ($item | length) != 2 then .
   else $item[0] as $p | $item[1] as $v |
     if $p[0] == "completed_scenario_windows" then
       if $p[1] == "requests" and ($p | length) >= 4 then
         if $p[3] != "gpu_reference_evidence" then
           setpath(["requests"] + $p[2:]; $v)
         elif $p[4] == "prior_routing_attempts" and ($p[5] | type) == "number" then
           setpath(["requests", $p[2], "prior_routing_attempt_count"];
             ([getpath(["requests", $p[2], "prior_routing_attempt_count"]) // 0,
               $p[5] + 1] | max))
         elif (["generation_submission", "confirmed_dispatch_snapshot",
                "source_admission", "native_source_conflict", "file_source_conflict"]
                | index($p[4])) != null then
           setpath(["requests", $p[2], "retained_reference_evidence"] + $p[4:]; $v)
         else . end
       elif $p[1] != "requests" then
         setpath(["completed_scenario_metadata"] + $p[1:]; $v)
       else . end
     else setpath($p; $v) end
   end)
