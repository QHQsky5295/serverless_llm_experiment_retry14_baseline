#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d115_20260929
unit=primelora-d115-full10-metadata-20260929.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full10_metadata_scope.txt"
exec /usr/bin/time -v -o "$raw/full_full10_metadata_time.txt" \
  /usr/bin/python3 "$raw/inspect_full10_metadata.py" > "$raw/full_full10_metadata.log" 2>&1
