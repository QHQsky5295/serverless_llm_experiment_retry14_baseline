"""D112 curator adapted to D115 native-complete / failed-cleanup evidence.

Read the bounded outcome projection only, never the 9-GiB raw JSON. Preserve
cleanup failure and both observed internal completion boundaries. Not Full pass.
"""
import json
import math
import sys
from collections import Counter
from pathlib import Path
from statistics import mean

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.metrics.metrics_collector import NativeV1TokenTimeline

raw = ROOT/'results/ieee_tc/p2_backend_qualification/d115_20260929'
run = raw/'3b_full_w0_full10'
evidence = run/'launch.launch'
out = ROOT/'paper_results/ieee_tc/p2_backend/20260929_d115_3b_full_w0_full10.json'
projection = raw/'full_full10_outcome_projection.json'
original = evidence/'physical_deployment/main_outcome.json'
assert not out.exists()
load = lambda path: json.loads(path.read_text())
assert 'Exit status: 0' in (raw/'full_full10_outcome_projection_time.txt').read_text()
outcome = load(projection)
rows = outcome['requests']
launch = load(run/'launch.json')
physical = load(evidence/'physical_deployment/summary.json')
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
good = [r for r in rows if r['success'] is True]
assert len(good) == 4000
assert outcome['run_completed'] is False and outcome['error'] is None
assert not outcome['formal_comparison_qualified'] and not outcome['interrupted_replays']
assert outcome['cleanup']['complete'] is False
assert outcome['cleanup']['reason'] == 'shutdown_unresolved'
assert len(outcome['cleanup_errors']) == 1 and not outcome['measurement_errors']
assert outcome['cleanup_errors'][0]['stage'] == 'runtime_shutdown'
assert outcome['cleanup_errors'][0]['message'] == 'IEEE shutdown preserved a failed residency epoch'
for claim in outcome['cleanup']['roots']:
    path = Path(claim['path'])
    assert path.is_dir() and not path.is_symlink()
    assert (path.stat().st_dev, path.stat().st_ino) == (claim['device'], claim['inode'])
assert all(r['released'] for r in physical['allocation_journals'])
assert not physical['open_lease_ids'] and physical['measurement_complete']
assert not physical['eligible_correctness'] and physical['n_correct'] is None
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']

def jsonlines(path):
    with path.open() as handle:
        for line in handle:
            yield json.loads(line)

terminals = list(jsonlines(evidence/'physical_deployment/request_terminals.jsonl'))
replay = list(jsonlines(evidence/'replay.jsonl'))
ingress = list(jsonlines(evidence/'service_ingress.jsonl'))
submitted = [r for r in replay if r['event'] == 'request_submitted']
assert len(terminals) == len(submitted) == 4000
assert {r['request_id'] for r in rows} == {r['request_id'] for r in terminals} == {r['request_id'] for r in submitted}
by_request = {r['request_id']: r for r in rows}
assert all(r['success'] == by_request[r['request_id']]['success'] for r in terminals)
assert all(r['native_contract_matched'] for r in terminals if r['success'])
for t in terminals:
    if t['success']:
        r = by_request[t['request_id']]
        assert r['completion_tokens'] == t['target_tokens']
        assert r['completion_token_ids_sha256'] == t['completion_token_ids_sha256']
        assert r['canonical_prompt_sha256'] == t['canonical_prompt_sha256']

remote = list(jsonlines(raw/'remote_3b_full10_transfers.jsonl'))
transfers = outcome['remote_transfers']
assert len(remote) == len(transfers) > 0
by_uuid = {r['transfer_id']: r for r in remote}
assert len(by_uuid) == len(remote) and set(by_uuid) == {r['http_transfer_id'] for r in transfers}
for r in transfers:
    peer = by_uuid[r['http_transfer_id']]
    assert peer['artifact_id'] == r['artifact_id']
    assert not peer['pack_performed'] and not peer['temporary_created']
    if r['state'] == 'published':
        assert peer['bytes_written'] == r['transferred_bytes']
        assert r['content_verified'] and r['published_archive_verified']
        assert r['payload_bytes_verified'] == r['payload_bytes_expected']
    else:
        assert r['state'] == 'not_published' and r['content_verified'] is False
        assert 0 <= r['transferred_bytes'] <= peer['bytes_written']
        assert 'payload_bytes_verified' not in r or r['payload_bytes_verified'] is None
    assert peer['clock_id'] == 'remote-process-monotonic:630b3ec1ed4a4e6a880945b21df5842d'
transfer_states = Counter(r['state'] for r in transfers)
assert not (set(transfer_states) - {'published', 'not_published'})

samples = 0
peak = swap = 0
available = float('inf')
events = Counter()
resource_warnings = 0
for r in jsonlines(evidence/'watchdog.jsonl'):
    if r['event'] != 'resource_sample':
        continue
    samples += 1
    assert not r['decision']['abort_reasons']
    resource_warnings += bool(r['decision']['warning'])
    peak = max(peak, r['service']['memory.peak'])
    swap = max(swap, r['service']['memory.swap.current'])
    available = min(available, r['host']['available_bytes'])
    for k in ('high', 'max', 'oom', 'oom_kill'):
        events[k] = max(events[k], r['service']['memory.events'].get(k, 0))

failures = Counter(r.get('failure_observation', {}).get('exception_type') or r.get('error') or 'unspecified_returned_failure'
                   for r in rows if not r['success'])
metrics = {}
for key in ('overall_ttft_ms', 'overall_e2e_ms', 'dispatch_admission_wait_ms',
            'runtime_slot_wait_ms', 'service_ttft_ms', 'vllm_ttft_ms',
            'pre_runtime_service_shell_ms', 'parent_rpc_overhead_ms', 'tpot_ms',
            'dispatch_window_wait_ms', 'arrival_release_lateness_ms', 'lora_io_ms',
            'parent_response_pickup_delay_ms', 'parent_thread_resume_delay_ms'):
    v = sorted(r[key] for r in good if isinstance(r.get(key), (int, float)) and math.isfinite(r[key]))
    metrics[key] = dict(n=len(v), mean=mean(v) if v else None,
                       p50_type1=v[math.ceil(.5*len(v))-1] if v else None,
                       p95_type1=v[math.ceil(.95*len(v))-1] if v else None)
deployment = load(evidence/'physical_deployment/deployment.json')
timing_errors = Counter()
native_stages = {k: [] for k in (
    'admission_to_engine_dispatch_ms', 'engine_entry_to_queue_ms',
    'native_engine_queue_ms', 'native_prefill_ms', 'native_decode_ms',
    'worker_completion_notification_ms', 'worker_to_controller_completion_ms')}
single_token = 0
confirmed_tiers = Counter()
for r in good:
    t = r['native_token_timing']
    assert r['generation_contract'] == 'fixed_length_greedy_v1'
    assert r['timing_contract'] == 'ieee_tc_native_v1'
    assert r['completion_token_source'] == 'vllm_token_ids'
    assert r['output_contract_match'] is True
    n = r['completion_tokens']
    assert n == r['output_tokens'] == r['requested_completion_tokens'] == t['native_output_tokens']
    check = NativeV1TokenTimeline.service_breakdown(t,
        admitted_at=t['controller_admitted_monotonic_s'],
        completed_at=t['controller_completed_monotonic_s'],
        clock_id=physical['clock_id'])
    ref = r['retained_reference_evidence']
    admission = ref['source_admission']
    assert ref['confirmed_dispatch_snapshot'] is True
    assert admission['kind'] == 'selected_source_admission_v1'
    assert admission['clock_id'] == physical['clock_id']
    assert 0 < admission['admitted_monotonic_s'] <= t['native_dispatch_monotonic_s']
    tier = r['readiness_tier_before_dispatch']
    assert tier in ('gpu', 'host', 'nvme', 'remote')
    assert admission['source']['tier'] == tier
    confirmed_tiers[tier] += 1
    arrival = deployment['arrival_start_s'] + r['scheduled_arrival_offset_s']
    errors = {
        'user_ttft_ms': abs(r['overall_ttft_ms'] - (t['native_first_token_monotonic_s']-arrival)*1000),
        'controller_result_e2e_ms': abs(r['overall_e2e_ms'] - (t['controller_completed_monotonic_s']-arrival)*1000),
        'dispatch_ms': abs(r['dispatch_admission_wait_ms'] - (t['controller_admitted_monotonic_s']-arrival)*1000),
        'service_decomposition_ms': abs(r['service_e2e_ms']-sum(check[k] for k in native_stages)),
        'dispatch_decomposition_ms': abs(r['dispatch_admission_wait_ms']-sum(r[k] for k in
            ('dispatch_window_wait_ms','runtime_slot_wait_ms','arrival_release_lateness_ms'))),
    }
    if n > 1:
        errors['tpot_ms'] = abs(r['tpot_ms'] - (t['native_last_token_monotonic_s']-t['native_first_token_monotonic_s'])*1000/(n-1))
    else:
        single_token += 1
        assert r['tpot_ms'] is None and t['native_tpot_ms'] is None
    for k, value in errors.items():
        assert math.isfinite(value) and value <= 1.0, (r['request_id'], k, value)
        timing_errors[k] = max(timing_errors[k], value)
    for k in native_stages:
        native_stages[k].append(check[k])
native_metrics = {k: dict(n=len(v), mean=mean(v), p95_type1=sorted(v)[math.ceil(.95*len(v))-1])
                  for k,v in native_stages.items()}
retries = [r.get('prior_routing_attempt_count', 0) for r in good]
mechanisms = outcome['mechanism_events']
preliminary = load(raw/'full_full10_metadata_preliminary.json')
assert preliminary['population']['success'] == len(good)
quarantines = mechanisms['_ieee_runtime_quarantine_events']
assert len(quarantines) == 0 and all(r['state'] == 'released' for r in quarantines)
assert len({r['instance_id'] for r in quarantines}) == len(quarantines)
for r in quarantines:
    assert r['started_monotonic_s'] <= r['drained_monotonic_s'] <= r['released_monotonic_s']
quarantine_durations = sorted(r['released_monotonic_s']-r['started_monotonic_s'] for r in quarantines)
zero_ready = [r for r in mechanisms['_ieee_control_events']
              if r.get('ready_instances') == 0 and r.get('queue_depth', 0) > 0]
before = load(raw/'prelaunch_verification.json')
for name, expected in before['source_sha256'].items():
    path = Path(name) if name.startswith('/') else ROOT/name
    assert p.digest(path) == expected, name
assert physical['n_native_contract_complete'] == 4000
assert math.isclose(sum(physical['window_gpu_seconds'].values()), physical['gpu_seconds'], abs_tol=1e-6)
assert len(good) == 4000 and not failures
assert launch['service_returncode'] == 1 and launch['pass'] is False
assert launch['replay_returncode'] == launch['watchdog_returncode'] == 0
first_four = sorted(mechanisms['_ieee_activations'], key=lambda r: r['trigger_at'])[:4]
initial_ids = {r['target_replica'] for r in first_four}
assert len(initial_ids) == 4
replacements = [r for r in good if r['instance_id'] not in initial_ids]
outer_ms, completion_gaps_ms = [], []
for terminal in terminals:
    r = by_request[terminal['request_id']]
    arrival = deployment['arrival_start_s'] + r['scheduled_arrival_offset_s']
    controller = r['native_token_timing']['controller_completed_monotonic_s']
    assert terminal['at'] >= controller
    outer_ms.append((terminal['at'] - arrival) * 1000)
    completion_gaps_ms.append((terminal['at'] - controller) * 1000)
def summary_ms(values):
    v = sorted(values)
    return dict(n=len(v), mean=mean(v), p95_type1=v[math.ceil(.95*len(v))-1])
completion_boundaries = dict(controller_result='native_token_timing.controller_completed_monotonic_s',
    outer_terminal='request_terminals.jsonl:at after reservation/global admission release',
    client_response_observed=False,
    internal_outer_terminal_latency_ms=summary_ms(outer_ms),
    controller_to_outer_terminal_ms=summary_ms(completion_gaps_ms),
    caveat='Neither internal event is client response receipt; raw controller E2E unchanged.')
result = dict(kind='d115_native_contract_complete_cleanup_failed_full_v1', model='3b', workload='W0',
    execution_commit='2697758908ab644f84c191a0318f01cbea8f7a55',
    full_qualified=False, native_contract_completion_pass=True, formal_performance_result=False, baselines='paused',
    diagnostic_instrumentation=False, frozen_source_refs_checked=len(before['source_sha256']),
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    population=dict(planned=4000, publisher_submitted=4000, runner_started=len(rows),
        terminal=len(terminals), success=len(good), native_contract_matched=4000,
        failure_observations=dict(failures),
        replay_event_counts=dict(Counter(r['event'] for r in replay)),
        ingress_event_counts=dict(Counter(r['event'] for r in ingress))),
    execution_completed=outcome['run_completed'], qualification='native_contract_complete_cleanup_failed_numerical_adapter_and_formal_slo_pending',
    request_replay_completed=True,
    launcher_result_pass=launch['pass'],
    launcher_service_returncode=launch['service_returncode'],
    native_gpu_context_release_confirmed=launch['native_gpu_context_release_confirmed'],
    cleanup_errors=outcome['cleanup_errors'],
    mechanism_failure_records=preliminary['mechanism_failure_records'],
    observed_completion_boundaries=completion_boundaries,
    cleanup=outcome['cleanup'] | dict(inventory_before=None, inventory_after=None),
    resources=dict(samples=samples, peak_bytes=peak, min_host_available_bytes=available,
                   max_events=dict(events), max_swap_bytes=swap, warning_samples=resource_warnings),
    physical=physical,
    supersession_stages={k:dict(Counter(r.get('preparation_supersession',{}).get('stage')
        for r in mechanisms[k] if r.get('state')=='superseded')) for k in
        ('_ieee_residency_epochs','_ieee_file_preparation_plans','_ieee_gpu_preparation_plans')},
    source_observation_stats=mechanisms['_ieee_source_observation_stats'],
    zero_ready_with_queue=dict(events=len(zero_ready), first=zero_ready[0] if zero_ready else None,
        actions=dict(Counter(r['action'] for r in zero_ready)),
        outcomes=dict(Counter(r.get('outcome') for r in zero_ready))),
    selected_source_retries_on_success=dict(requests_with_retry=sum(x > 0 for x in retries),
        total=sum(retries), maximum=max(retries), note='Only retained retries of successful requests; not all failed snapshot attempts.'),
    mechanism_counts={k: dict(Counter(r.get('state', 'not_a_state_event') for r in v))
                      for k, v in mechanisms.items() if isinstance(v, list)},
    remote=dict(uuid_pairs=len(transfers), client_received_bytes=sum(r['transferred_bytes'] for r in transfers),
        server_socket_written_bytes=sum(r['bytes_written'] for r in remote),
        byte_mismatches=[dict(transfer_id=r['http_transfer_id'], state=r['state'],
            client_bytes=r['transferred_bytes'], server_bytes=by_uuid[r['http_transfer_id']]['bytes_written'])
            for r in transfers if r['transferred_bytes'] != by_uuid[r['http_transfer_id']]['bytes_written']],
        verified_published_logical_bytes=sum(r['payload_bytes_verified'] for r in transfers if r['state']=='published'),
        states=dict(Counter(r['state'] for r in transfers)),
        not_published=[r for r in transfers if r['state'] == 'not_published'], request_packing=0,
        unpublished_cause=None if transfer_states.get('not_published', 0) == 0 else 'See retained transfer evidence; no guessed cause.',
        server_journal='transfers-085455d634784028967260619da9ec03.jsonl'),
    quarantine=dict(events=len(quarantines), released=len(quarantines),
        mean_isolation_to_release_s=mean(quarantine_durations) if quarantine_durations else None,
        p95_isolation_to_release_s=quarantine_durations[math.ceil(.95*len(quarantine_durations))-1] if quarantine_durations else None,
        first_four_runtime_successes=len(good)-len(replacements),
        first_four_activation_categories=dict(Counter(r['category'] for r in first_four)),
        replacement_successes=len(replacements),
        replacement_successful_runtimes=len({r['instance_id'] for r in replacements})),
    conditional_success_latency_ms=metrics,
    native_stage_metrics_ms=native_metrics,
    timing_validation=dict(requests=len(good), single_token_requests=single_token,
        max_error_ms=dict(timing_errors), tolerance_ms=1.0,
        contract='ieee_tc_native_v1', direct_planned_arrival_boundary=True),
    readiness_tier_counts=dict(Counter(r['readiness_tier_before_dispatch'] for r in good)),
    readiness_evidence=dict(confirmed_pre_generation_requests=sum(confirmed_tiers.values()),
        source_admission_tier_counts=dict(confirmed_tiers), conflicts=0,
        qualification='Selected-source identity/clock/order only; not a complete A4 epoch study or numerical adapter proof.'),
    conditional_latency_caveat='All 4000 requests satisfy native generation contract, but a residency failure at cleanup makes Full qualification fail. Numerical adapter correctness and common warm SLO remain pending. No formal ranking or isolated causal estimate.',
    protected=p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json'),
    next='Back up failed Full evidence; causally test the observed subscription/retirement failure before any new replay. No swallowed error or physical guard removal; baselines stay paused.')
assert result['protected']['pass']
refs = [raw/'prelaunch_verification.json', raw/'health_3b.json', raw/'health_7b.json',
    run/'launch.json', original, evidence/'physical_deployment/summary.json',
    evidence/'physical_deployment/request_terminals.jsonl', evidence/'watchdog.jsonl',
    evidence/'service_ingress.jsonl', evidence/'replay.jsonl', evidence/'service.log',
    raw/'3b_main_config_full10.yaml', raw/'run_3b_full_w0_full10.sh',
    raw/'remote_3b_full10_transfers.jsonl', raw/'remote_monitor_full10_final.log',
    raw/'stop_services_full10.sh', raw/'stop_services_full10.log',
    raw/'cleanup_local_aux_full10.sh', raw/'cleanup_local_aux_full10.log',
    Path(__file__), projection, raw/'project_full10_outcome.sh', raw/'project_full10_outcome.jq',
    raw/'full_full10_outcome_projection_time.txt', raw/'full_full10_projection_scope.txt',
    raw/'full_full10_metadata_preliminary.json', raw/'inspect_full10_metadata.py',
    raw/'inspect_full10_metadata.sh', raw/'full_full10_metadata.log',
    raw/'full_full10_metadata_time.txt', raw/'full_full10_metadata_scope.txt',
    raw/'full_full10_metadata_memory_events.txt',
    ROOT/'scripts/run_all_experiments.py', ROOT/'faaslora/memory/residency_manager.py',
    ROOT/'faaslora/preloading/preloading_planner.py']
result['source_refs'] = [dict(path=str(path), sha256=p.digest(path)) for path in refs]
with out.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps(dict(output=str(out), sha256=p.digest(out), population=result['population'],
    resources=result['resources'], remote=result['remote'], stats=result['source_observation_stats'],
    retries=result['selected_source_retries_on_success'], conditional_metrics=metrics)))
