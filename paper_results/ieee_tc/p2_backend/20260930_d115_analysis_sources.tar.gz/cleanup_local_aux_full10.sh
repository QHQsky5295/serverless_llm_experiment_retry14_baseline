#!/usr/bin/env bash
set -euo pipefail
# Adapted D107 exact-identity and empty-cgroup cleanup.
date -Is
test "$(systemctl --user show primelora-tc-svc-16ee4f86ca8743e293af67feb1723916.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-tc-aux-2fe2c5fc77d54c0c866f1ff5cb716dbe.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = b6f84ea74a2046719339c73728ee2ff6
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-tc-aux-2fe2c5fc77d54c0c866f1ff5cb716dbe.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
