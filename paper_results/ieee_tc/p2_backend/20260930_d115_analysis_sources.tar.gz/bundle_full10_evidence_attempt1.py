"""Small evidence packaging only: no dataset duplication or raw-outcome read."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d115_20260929'
out = root/'paper_results/ieee_tc/p2_backend'
unit = 'primelora-d115-full10-evidence-20260930.scope'
def prop(name):
    return subprocess.check_output(['systemctl','--user','show',unit,'-p',name,'--value'],text=True).strip()
assert prop('InvocationID') == '94573a71349146388db7d26abdcafe5a'
assert prop('TasksCurrent') == '0'
cg = Path('/sys/fs/cgroup'+prop('ControlGroup'))
assert not (cg/'cgroup.procs').read_text().strip()
assert 'populated 0' in (cg/'cgroup.events').read_text()
events = (cg/'memory.events').read_text()
assert all(int(line.split()[1]) == 0 for line in events.splitlines())
with (raw/'full_full10_evidence_memory_events.txt').open('x') as f:
    f.write(events)
subprocess.run(['systemctl','--user','stop',unit],check=True)
assert prop('ActiveState') == 'inactive'
with (raw/'full_full10_evidence_cleanup.json').open('x') as f:
    json.dump(dict(unit=unit,invocation='94573a71349146388db7d26abdcafe5a',
                   verified_tasks=0,verified_populated=0,stopped=True),f,indent=2)

# Only top-level small scripts, configuration and receipts; no remote journal,
# monitor, projection, raw outcomes, model files, token files or cache roots.
members = sorted(p for p in raw.iterdir() if p.is_file() and
    p.stat().st_size < 64*1024 and p.suffix in {'.py','.sh','.jq','.yaml','.json','.log','.txt'})
bundle = out/'20260930_d115_analysis_sources.tar.gz'
assert not bundle.exists()
hashes = {}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        data = p.read_bytes()
        assert b'BEGIN OPENSSH PRIVATE KEY' not in data
        hashes[p.name] = hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
manifest = out/'20260930_d115_analysis_sources.sha256'
with manifest.open('x') as f:
    f.write(hashlib.sha256(bundle.read_bytes()).hexdigest()+'  '+bundle.name+'\n')
members_manifest = out/'20260930_d115_analysis_sources_members.json'
with members_manifest.open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,members=len(hashes),
                      sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),cleanup=True)))
