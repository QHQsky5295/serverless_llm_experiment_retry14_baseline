"""Bounded metadata-only adaptation of the existing D112 preliminary check.

D115 retained the full scenario after cleanup failure. Never json.load the
9-GiB outcome. The measured top-level final-property offset is verified below;
only the preceding 35.7-MB metadata object is parsed. Requests remain untouched.
This diagnoses failure; it cannot certify Full or final latency measurements.
"""
import collections
import hashlib
import json
import subprocess
from pathlib import Path

raw = Path(__file__).resolve().parent
e = raw / '3b_full_w0_full10/launch.launch'
source = e / 'physical_deployment/main_outcome.json'
assert subprocess.check_output(['systemctl', '--user', 'show',
    'primelora-tc-svc-16ee4f86ca8743e293af67feb1723916.scope', '-p',
    'ActiveState', '--value'], text=True).strip() == 'inactive'
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
offset = 35696635  # Observed exact byte offset, not a performance parameter.
assert source.stat().st_size == 9187872294
with source.open('rb') as f:
    prefix = f.read(offset)
    assert f.readline(128) == b'  "completed_scenario_windows": {\n'
assert prefix.rstrip().endswith(b',')
data = json.loads(prefix.rstrip()[:-1] + b'\n}\n')
assert data['kind'] == 'ieee_main_outcome_v1'
assert data['run_completed'] is False and data['error'] is None
assert data['cleanup_errors'] and not data['measurement_errors']
assert not data['interrupted_replays']
assert data['cleanup']['complete'] is False
deployment = json.loads((e/'physical_deployment/deployment.json').read_text())
physical = json.loads((e/'physical_deployment/summary.json').read_text())
launch = json.loads((raw/'3b_full_w0_full10/launch.json').read_text())
assert launch['service_returncode'] == 1 and not launch['pass']
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert physical['measurement_complete'] and not physical['open_lease_ids']
terminals = [json.loads(s) for s in (e/'physical_deployment/request_terminals.jsonl').open()]
assert len(terminals) == len({r['request_id'] for r in terminals}) == 4000
assert all(r['success'] and r['native_contract_matched'] for r in terminals)
events = data['mechanism_events']
failures = {}
fields = ('state', 'error', 'error_type', 'traceback', 'target_replica',
    'adapter_id', 'started_at', 'terminal_at', 'trigger_reason', 'plan_id',
    'intent_id', 'preparation_supersession')
for k, rows in events.items():
    if isinstance(rows, list):
        failures[k] = [{key:r[key] for key in fields if key in r}
            for r in rows if r.get('state') == 'failed' or
            (r.get('error_type') and r.get('error_type') != 'CancelledError')]
result = dict(kind='d115_metadata_only_failed_cleanup_diagnostic_v1',
    full_qualified=False, formal_performance_result=False,
    population=dict(planned=4000, terminal=4000, success=4000,
        native_contract_matched=4000, numerical_adapter_correctness_qualified=False),
    deployment=deployment, physical=physical, cleanup=data['cleanup'],
    cleanup_errors=data['cleanup_errors'], measurement_errors=data['measurement_errors'],
    mechanism_failure_records=failures,
    mechanism_state_counts={k:dict(collections.Counter(r.get('state','not_a_state_event')
        for r in rows)) for k,rows in events.items() if isinstance(rows,list)},
    source=dict(path=str(source), size_bytes=source.stat().st_size,
        metadata_end_offset=offset, metadata_prefix_sha256=hashlib.sha256(prefix).hexdigest()),
    caveat='Metadata only; full bounded request projection pending. Cleanup failure is retained; no Full pass or formal SLO/ranking claim.')
target = raw/'full_full10_metadata_preliminary.json'
with target.open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(path=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
    population=result['population'],failure_counts={k:len(v) for k,v in failures.items()},
    physical_gpu_seconds=physical['gpu_seconds']),indent=2))
