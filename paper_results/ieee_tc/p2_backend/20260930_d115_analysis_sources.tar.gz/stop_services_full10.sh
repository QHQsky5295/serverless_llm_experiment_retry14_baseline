#!/usr/bin/env bash
set -euo pipefail
# Existing D110 exact-identity cleanup, adapted to D115. Execute remotely ONLY
# after local main exit and GPU cleanup; never while inference is running.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d115full10.service)
ids=(17e9dba803b041f6afa9a3f50352016d b5ace292784c4b008c5f0d5100c72d56 ab6a0fd076a8483c9f68212192f208d3)
pids=(2453893 2453899 2453904)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result
