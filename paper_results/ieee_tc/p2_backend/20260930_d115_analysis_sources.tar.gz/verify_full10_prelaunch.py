"""Reuse D112 checks for one ordinary D114 native-async Full replay."""
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d115_20260929'
previous = root/'results/ieee_tc/p2_backend_qualification/d112_20260928'
expected_commit = '2697758908ab644f84c191a0318f01cbea8f7a55'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected_commit
dirty = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty) <= {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'}, dirty
old = yaml.safe_load((previous/'3b_main_config_full9.yaml').read_text())
new = yaml.safe_load((raw/'3b_main_config_full10.yaml').read_text())
for config in (old,new):
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
assert old == new, 'configuration changed beyond three fresh owned paths'
assert not (raw/'3b_full_w0_full10/launch.json').exists()
assert not (raw/'3b_nvme_full10/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d115-3b-full10/tc_ieee_full').exists()
before = json.loads((previous/'prelaunch_verification.json').read_text())
validation_path = root/'paper_results/ieee_tc/p2_backend/20260929_d114_native_async_transport/summary.json'
assert digest(validation_path) == 'a76afd819eee82d9974770e0d2634fd180bf57f0e38b1a4ffd5f836343901d5a'
validated = json.loads(validation_path.read_text())
validated_refs = {v['path']:v['sha256'] for v in validated['source_refs']}
changed = {'scripts/run_all_experiments.py','tests/test_ieee_tc_request_lifecycle.py',
           'tests/test_ieee_tc_native_retirement.py'}
refs = dict(before['source_sha256'])
for name, expected in list(refs.items()):
    path = Path(name) if name.startswith('/') else root/name
    rel = str(path.relative_to(root)) if path.is_relative_to(root) else str(path)
    if rel in changed:
        expected = validated_refs[str(root/rel)]
        refs[name] = expected
    assert digest(path) == expected, name
for name in changed:
    assert digest(root/name) == validated_refs[str(root/name)]
    refs[name] = validated_refs[str(root/name)]
for path in [raw/name for name in ('3b_main_config_full10.yaml','run_3b_full_w0_full10.sh',
    'activate_services_full10.sh','check_health.sh','verify_full10_prelaunch.py')]+[validation_path]:
    refs[str(path)] = digest(path)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
resources = preflight([root,raw],32*1024**3)
assert resources['preflight_pass'], resources['issues']
receipt = dict(kind='d115_native_async_full_prelaunch_v1',time_unix=time.time(),
    run='d115_3b_full_w0_full10',evidence_commit=expected_commit,
    runtime_source_commit=expected_commit,source_change='D114_native_async_socket_transport',
    same_configuration_except_owned_paths=True,diagnostic_instrumentation=False,
    formal_performance_result=False,source_sha256=refs,protected=protected,
    resource_preflight=resources,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    comparison='Ordinary D112 reference; one development repetition, no CI or formal SLO claim.',
    pending_metric_reconciliation='Controller completion vs outer terminal: preserve both, no relabeling.',
    reused_initialization='D88/D89; no new profiles or data; immutable published cache unchanged',
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as h:
    json.dump(receipt,h,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),sha256=digest(raw/'prelaunch_verification.json'),
    protected=147,source_refs=len(refs),same_config=True,resource_pass=True,formal=False)))
