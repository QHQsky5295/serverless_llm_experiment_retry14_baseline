#!/usr/bin/env bash
# Reuse D112 evidence closure; failed Full and completed requests stay distinct.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d115_20260929
unit=primelora-d115-full10-evidence-20260930.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full10_evidence_scope.txt"
export PYTHONUNBUFFERED=1
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -m unittest tests.test_ieee_tc_gpu_lifecycle tests.test_ieee_tc_external_replay tests.test_ieee_tc_native_timing -v
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python - <<'PY'
import json, subprocess
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d115_20260929'
before = json.loads((raw/'prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    p = Path(name) if name.startswith('/') else root/name
    assert digest(p) == expected, name
full = root/'paper_results/ieee_tc/p2_backend/20260929_d115_3b_full_w0_full10.json'
assert digest(full) == 'fd3e460a1cd676f2c7cc282dde1a2b7074b81efa1a758b95345a615b7db9768b'
x = json.loads(full.read_text())
assert x['native_contract_completion_pass'] and not x['full_qualified']
assert not x['formal_performance_result'] and not x['launcher_result_pass']
assert x['launcher_service_returncode'] == 1 and not x['cleanup']['complete']
assert x['cleanup']['reason'] == 'shutdown_unresolved'
assert x['population']['success'] == x['population']['native_contract_matched'] == 4000
assert x['population']['failure_observations'] == {}
assert x['timing_validation']['requests'] == 4000
assert max(x['timing_validation']['max_error_ms'].values()) <= 1.0
assert x['physical']['n_correct'] is None and not x['physical']['eligible_correctness']
assert x['physical']['measurement_complete'] and not x['physical']['open_lease_ids']
assert not x['observed_completion_boundaries']['client_response_observed']
assert x['quarantine']['events'] == 0 and x['remote']['uuid_pairs'] == 132
assert not x['remote']['byte_mismatches'] and x['remote']['request_packing'] == 0
assert x['mechanism_counts']['_ieee_residency_epochs']['failed'] == 1
for retained in x['cleanup']['roots']:
    st = Path(retained['path']).stat()
    assert (st.st_dev, st.st_ino) == (retained['device'], retained['inode'])
for stage in ('metadata', 'projection', 'curation'):
    events = dict(line.split() for line in (raw/f'full_full10_{stage}_memory_events.txt').read_text().splitlines())
    assert all(int(v) == 0 for v in events.values())
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == x['metric_protocol_sha256']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
reused = []
checked = 0
for ref in x['source_refs']:
    p = Path(ref['path'])
    if p.name == 'main_outcome.json':
        # Already streamed/hashed by the completed curator, not re-parsed/rehashed.
        st = p.stat()
        assert st.st_size == 9187872294 and st.st_mtime_ns <= full.stat().st_mtime_ns
        reused.append(dict(**ref, bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                           verification='reuse_completed_curator_stream_hash_plus_stat'))
    else:
        assert digest(p) == ref['sha256'], ref['path']
        checked += 1
# Small real jq-filter fixture: preserve failure, metadata and request identity;
# retain source proof but remove repeated inventories. No raw-data extraction.
fixture = dict(error='preserved', metadata=dict(empty=[]), completed_scenario_windows=dict(
    label='fixture', requests=[dict(request_id='r0', tokens=[1,2], gpu_reference_evidence=dict(
        source_admission=dict(tier='host'), generation_submission=dict(state='submitted'),
        prior_routing_attempts=[dict(x=1),dict(x=2)], huge_inventory=[dict(x=9)])),
        dict(request_id='r1',error='request-failure')]))
res = subprocess.run(['jq','--stream','-n','-f',str(raw/'project_full10_outcome.jq')],
    input=json.dumps(fixture),text=True,capture_output=True,check=True)
y = json.loads(res.stdout)
assert y['error'] == 'preserved' and y['metadata'] == dict(empty=[])
assert y['completed_scenario_metadata'] == dict(label='fixture')
assert len(y['requests']) == 2 and y['requests'][1]['error'] == 'request-failure'
r = y['requests'][0]
assert r['tokens'] == [1,2] and r['prior_routing_attempt_count'] == 2
assert r['retained_reference_evidence']['source_admission'] == dict(tier='host')
assert 'gpu_reference_evidence' not in r and 'huge_inventory' not in r
refs = [full,raw/'summarize_full_full10.py',raw/'verify_full10_evidence.sh',
        raw/'full_full10_curation_time.txt',raw/'full_full10_curation_memory_events.txt',
        root/'tests/test_ieee_tc_gpu_lifecycle.py',root/'tests/test_ieee_tc_external_replay.py',
        root/'tests/test_ieee_tc_native_timing.py']
receipt = dict(kind='d115_failed_full10_evidence_verification_v1',pass_checks=True,
    full_qualified=False,formal_performance_result=False,projection_fixture_pass=True,
    frozen_source_refs_checked=len(before['source_sha256']),curated_source_refs_rehashed=checked,
    reused_large_source_hash=reused,source_commit=before['runtime_source_commit'],
    protected=protected,refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
out = root/'paper_results/ieee_tc/p2_backend/20260930_d115_evidence_verification.json'
with out.open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(out),sha256=digest(out),frozen_sources=len(before['source_sha256']),
    curated_sources_rehashed=checked,reused_large_source_hash=len(reused),protected=147)))
PY
