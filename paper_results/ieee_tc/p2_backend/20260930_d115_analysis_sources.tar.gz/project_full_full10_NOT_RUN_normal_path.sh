#!/usr/bin/env bash
# Prepared but NEVER RUN: D115 retains requests in failed main_outcome instead.
exit 2
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d115_20260929
source_file="$raw/3b_outputs_full10/experiment_results_full_vllm_dedicated_a500_r4000_c8_tc_ieee_full_d115_3b_full_w0_full10.json"
target="$raw/full_full10_request_projection.json"
test -s "$raw/3b_full_w0_full10/launch.json"
test -s "$source_file"
test ! -e "$target"
test ! -e "$raw/full_full10_projection_time.txt"
test "$(systemctl --user show primelora-tc-svc-16ee4f86ca8743e293af67feb1723916.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d115-full10-project-20260929.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full10_projection_scope.txt"
# Reuse D101's launcher and the identical bounded D96 projection. Execute only
# after terminal/cleanup, in the existing 3/4-GiB analysis resource envelope.
# Failed requests are retained. Development results are not formal performance.
exec /usr/bin/time -v -o "$raw/full_full10_projection_time.txt" \
  jq --stream -n -f results/ieee_tc/p2_backend_qualification/d96_20260928/project_full_attempt3.jq \
  "$source_file" > "$target"
