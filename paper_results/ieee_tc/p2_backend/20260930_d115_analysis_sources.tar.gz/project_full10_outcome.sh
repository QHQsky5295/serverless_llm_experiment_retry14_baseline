#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d115_20260929
source_file="$raw/3b_full_w0_full10/launch.launch/physical_deployment/main_outcome.json"
target="$raw/full_full10_outcome_projection.json"
test -s "$raw/3b_full_w0_full10/launch.json"
test -s "$source_file"
test ! -e "$target"
test ! -e "$raw/full_full10_outcome_projection_time.txt"
test "$(systemctl --user show primelora-tc-svc-16ee4f86ca8743e293af67feb1723916.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d115-full10-project-20260929.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full10_projection_scope.txt"
exec /usr/bin/time -v -o "$raw/full_full10_outcome_projection_time.txt" \
  jq --stream -n -f "$raw/project_full10_outcome.jq" "$source_file" > "$target"
