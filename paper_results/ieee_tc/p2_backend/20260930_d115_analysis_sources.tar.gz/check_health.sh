#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d115_20260929
for spec in 3b:18080 7b:18081; do
  model=${spec%:*}
  port=${spec#*:}
  /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python scripts/remote_artifact_client.py \
    --endpoint "http://192.168.4.174:$port" \
    --token-file /home/qhq/.config/primelora-tc-d75/artifact.token \
    --timeout-s 10 --delivery-mode prepublished_gzip_v1 health \
    > "$raw/health_${model}.json"
  test -s "$raw/health_${model}.json"
  jq -e '.ok == true and .delivery_mode == "prepublished_gzip_v1" and .timing_contract == "artifact_timing_v2"' "$raw/health_${model}.json"
done
