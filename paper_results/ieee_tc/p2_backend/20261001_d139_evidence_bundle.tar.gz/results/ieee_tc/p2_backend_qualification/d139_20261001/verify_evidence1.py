"""Close D139 offline recovery, retaining all previous sealed evidence."""
import csv
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tarfile

from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d139_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
expected = {
    '3b':'0cc93b11529db20f721a380931d21626c1ae73bf0a8b03a69be1fec96b1b057e',
    '7b':'4a9c56e0894a2746577eba14c4affa7a3f62321adc038e66d62599b9f3cf826b',
}
testlog = (raw/'tests1.log').read_text()
assert 'Ran 38 tests in ' in testlog and '\nOK\n' in testlog
unit = 'primelora-d139-rpc-audit1-20261001.scope'
assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for name in ('inspect_cleanup.log','rpc_cleanup1.log'):
    lines=(raw/name).read_text().splitlines()
    events={line.split()[0]:int(line.split()[1]) for line in lines
            if line.startswith(('low ','high ','max ','oom ','oom_kill ','oom_group_kill '))}
    assert len(events)==6 and not any(events.values())
refs=[]
checks={}
for model, sha in expected.items():
    directory=out/f'20261001_d139_rpc_{model}'
    summary_path=directory/'summary.json'
    assert digest(summary_path)==sha
    summary=json.loads(summary_path.read_text())
    assert summary['complete_field_coverage'] and not summary['new_experiment']
    assert summary['population']==dict(planned=4000,terminal=4000,native_success=4000)
    assert summary['metric_protocol_sha256']=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
    for ref in summary['source_refs']:
        assert digest(Path(ref['path']))==ref['sha256']
    # Independent CSV recomputation checks emitted values without reopening any
    # large original result or repeating the already completed projection.
    request_csv=directory/'request_rpc_observations.csv'
    with request_csv.open() as f: rows=list(csv.DictReader(f))
    assert len(rows)==len({r['request_id'] for r in rows})==4000
    for metric in summary['metrics']:
        assert metric['valid']==4000 and metric['missing']==metric['null']==metric['invalid']==0
        values=sorted(float(r[metric['field']]) for r in rows)
        assert all(math.isfinite(v) and v>=0 for v in values)
        assert math.isclose(math.fsum(values)/4000,metric['mean'],rel_tol=1e-14,abs_tol=1e-12)
        assert values[3799]==metric['p95'] and values[1999]==metric['p50']
        assert values[-1]==metric['max'] and sum(v==0 for v in values)==metric['zero']
    checks[model]=dict(requests=4000,fields=len(summary['metrics']),independent_csv_statistics_pass=True)
    refs += [dict(path=str(p),sha256=digest(p)) for p in
             (summary_path,request_csv,directory/'rpc_metrics.csv')]
    assert 'Exit status: 0' in (raw/f'{model}_time1.txt').read_text()
prior=json.loads((root/'results/ieee_tc/p2_backend_qualification/d138_20261001/prelaunch_verification.json').read_text())
serving = ['scripts/run_all_experiments.py','scripts/dedicated_engine_worker.py',
           'faaslora/memory/gpu_monitor.py','faaslora/memory/residency_manager.py',
           'faaslora/scheduling/vllm_ieee_scheduler.py','faaslora/preloading/planning_cpu.py']
for name in serving:
    p=root/name
    recorded=prior['source_sha256'].get(name,prior['source_sha256'].get(str(p)))
    assert recorded is not None and digest(p)==recorded,name
protected=verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count']==147
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md')=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'))=='fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
files=[*sorted(raw.glob('*.sh')),*sorted(raw.glob('*.py')),
       raw/'tests1.log',raw/'tests_time1.txt',raw/'3b_time1.txt',raw/'7b_time1.txt',
       raw/'rpc_scope1.txt',raw/'inspect_cleanup.log',raw/'rpc_cleanup1.log',
       root/'scripts/analyze_control_path_overhead.py',root/'tests/test_ieee_tc_rpc_breakdown.py',
       root/'tests/test_ieee_tc_control_timeline.py',root/'docs/ieee_tc/D139_CONTROL_PATH_DIAGNOSIS.md']
files.extend(out/f'20261001_d139_rpc_{model}'/name
             for model in ('3b','7b') for name in ('summary.json','rpc_metrics.csv'))
assert len(files)==len(set(files)) and all(p.stat().st_size<512*1024 for p in files)
refs.extend(dict(path=str(p),sha256=digest(p)) for p in files)
result=dict(kind='d139_offline_rpc_recovery_evidence_v1',pass_checks=True,
            new_gpu_experiment=False,affected_tests=38,model_checks=checks,
            serving_unchanged=serving,protected=protected,refs=refs)
verification=out/'20261001_d139_evidence_verification.json'
with verification.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
files.append(verification)
bundle=out/'20261001_d139_evidence_bundle.tar.gz'
with bundle.open('xb') as handle:
    with tarfile.open(fileobj=handle,mode='w:gz') as archive:
        for p in files:archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers())==len(files)
    for member,path in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==digest(path)
checksum=out/'20261001_d139_evidence_bundle.sha256'
with checksum.open('x') as f:f.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(pass_checks=True,models=checks,protected_entries=147,
      verification_sha=digest(verification),bundle_sha=digest(bundle),bundle_bytes=bundle.stat().st_size,
      members=len(files)),indent=2))
