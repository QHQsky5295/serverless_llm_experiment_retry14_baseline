#!/usr/bin/env bash
# Offline recovery only. Reuse D138 guarded-analysis lifecycle and projections.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d139_20261001
unit=primelora-d139-rpc-audit1-20261001.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/rpc_scope1.txt"
export PYTHONUNBUFFERED=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
/usr/bin/time -v -o "$raw/tests_time1.txt" "$python" -m unittest tests.test_ieee_tc_rpc_breakdown tests.test_ieee_tc_control_timeline > "$raw/tests1.log" 2>&1
for pair in 3b:d138:b20177aa13cc677fea2c151d752d1ede10a78d01de2d258fc02303c0624d87bb 7b:d137:9d6e028dd9caa49283510f4db585e79170067addc70345f0397f95f27b5bb04d; do
  IFS=: read -r model day sha <<< "$pair"
  source=results/ieee_tc/p2_backend_qualification/${day}_20261001
  deployment=$source/${model}_full_w0_full1/launch.launch/physical_deployment
  /usr/bin/time -v -o "$raw/${model}_time1.txt" "$python" scripts/analyze_control_path_overhead.py \
    --rpc-breakdown --input "$source/full_full1_request_projection.json" \
    --deployment "$deployment/deployment.json" --terminals "$deployment/request_terminals.jsonl" \
    --sealed-summary "paper_results/ieee_tc/p2_backend/20261001_${day}_${model}_full_w0_full1.json" \
    --sealed-sha256 "$sha" \
    --output "paper_results/ieee_tc/p2_backend/20261001_d139_rpc_${model}" > "$raw/${model}_rpc1.log"
done
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
