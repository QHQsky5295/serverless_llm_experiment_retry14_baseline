#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d185_20261003
unit=primelora-d185-full1-evidence1-20261003.scope
{
  date -Is
  rg -qx 'InvocationID=f4e7a13784ed4829af153f8a361150d6' "$raw/full_full1_evidence1_scope.txt"
  jq -e '.pass_checks == true' paper_results/ieee_tc/p2_backend/20261003_d185_evidence_verification.json
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=f4e7a13784ed4829af153f8a361150d6\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=see_captured_evidence1_memory_events_and_swap_files\n'
} | tee "$raw/cleanup_evidence_full1.log"
