"""Reuse D100 failure audit; retain previously unseen returned errors verbatim."""
import collections
import hashlib
import json
from pathlib import Path

raw = Path(__file__).resolve().parent
projection = raw/'full_full1_request_projection.json'
assert projection.stat().st_size < 256 * 1024**2
assert 'Exit status: 0' in (raw/'full_full1_projection_time.txt').read_text()
rows = json.loads(projection.read_text())['requests']
failed = [r for r in rows if not r['success']]
physical = json.loads((raw/'7b_full_w0_full1/launch.launch/physical_deployment/summary.json').read_text())
assert all(r['failure_observation']['clock_id'] == physical['clock_id'] for r in failed)
timeouts = [r for r in failed if r['failure_observation']['exception_type'] == 'TimeoutError']
returned = [r for r in failed if r['failure_observation']['exception_type'] != 'TimeoutError']
assert len(rows) == 4000 and len(timeouts) + len(returned) == len(failed)
prefix = 'native RPC ownership unresolved; new generation withheld'
categories = collections.Counter()
for r in returned:
    if r['error'] == prefix:
        categories['parent_native_ownership_unresolved'] += 1
    elif r['error'].startswith('subprocess_native_rpc_failed_no_retry: RuntimeError: '+prefix):
        categories['subprocess_native_ownership_unresolved'] += 1
    else:
        categories['other_returned_error'] += 1

def evidence(r):
    ref = r.get('retained_reference_evidence', {})
    return dict(request_id=r['request_id'], instance_id=r.get('instance_id'),
        failure_observation=r['failure_observation'],
        request_phase_fields={k:r[k] for k in ('scheduled_arrival_offset_s',
            'dispatch_window_wait_ms','runtime_slot_wait_ms','arrival_release_lateness_ms',
            'dispatch_admission_wait_ms','readiness_tier_before_dispatch') if k in r},
        native_token_timing_present=isinstance(r.get('native_token_timing'),dict),
        generation_submission=ref.get('generation_submission'),
        source_admission_present='source_admission' in ref,
        source_tier=ref.get('source_admission', {}).get('source', {}).get('tier'),
        error_sha256=hashlib.sha256(r['error'].encode()).hexdigest())

result = dict(kind='d185_full1_failure_breakdown_v1', formal_performance_result=False,
    source_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    projection_path=str(projection), projection_sha256=hashlib.sha256(projection.read_bytes()).hexdigest(),
    population=dict(planned=4000, success=len(rows)-len(failed), timeout=len(timeouts), returned_error=len(returned)),
    failure_observation_clock_id=physical['clock_id'],
    returned_categories=dict(categories),
    returned_error_messages=dict(collections.Counter(r['error'] for r in returned)),
    returned_generation_submission_states=dict(collections.Counter(
        r.get('retained_reference_evidence', {}).get('generation_submission', {}).get('state', 'unrecorded')
        for r in returned)),
    first_timeout=evidence(min(timeouts, key=lambda r:r['failure_observation']['observed_monotonic_s'])) if timeouts else None,
    first_returned_error=evidence(min(returned, key=lambda r:r['failure_observation']['observed_monotonic_s'])) if returned else None,
    timeout_generation_submission_states=dict(collections.Counter(
        r.get('retained_reference_evidence', {}).get('generation_submission', {}).get('state', 'unrecorded')
        for r in timeouts)),
    timeout_requests=[evidence(r) for r in timeouts],
    returned_requests=[evidence(r) for r in returned],
    caveat='Missing evidence is not proof of no dispatch. not_submitted describes this generation, not other unsettled RPC ownership or physical release.')
out = Path('/home/qhq/serverless_llm_experiment_retry14_baseline/paper_results/ieee_tc/p2_backend/20261003_d185_7b_full_w0_failure_breakdown.json')
with out.open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps({k:v for k,v in result.items() if k not in ('returned_requests','timeout_requests')},indent=2))
