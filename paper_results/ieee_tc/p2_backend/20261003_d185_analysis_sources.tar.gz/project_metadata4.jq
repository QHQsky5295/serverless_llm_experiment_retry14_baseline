# Reuse D96 streaming setpath; no whole input load and no event filtering.
# Full mechanism, failures, transfers and planning receipts remain untouched.
# Final coordination's launch contract and movement records are consumed;
# other final coordination fields remain available in immutable original.
reduce inputs as $item
 ({};
  if ($item | length) != 2 then .
  else $item[0] as $p | $item[1] as $v |
    if ($v|type) == "number" and (($v|fabs) >= 9007199254740992) then
      error("number outside verified exact-integer range")
    elif $p[0] != "coordination_after_shutdown" or
         (["ieee_full_launch_contract", "ieee_movements"] | index($p[1])) != null
    then setpath($p; $v)
    else . end
  end)
