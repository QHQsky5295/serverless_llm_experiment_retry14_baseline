"""Small evidence packaging only: no dataset duplication or raw-outcome read."""
import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d185_20261003'
out = root/'paper_results/ieee_tc/p2_backend'
unit = 'primelora-d185-full1-evidence1-20261003.scope'
def prop(name):
    return subprocess.check_output(['systemctl','--user','show',unit,'-p',name,'--value'],text=True).strip()
# Verify completed exact-owned cleanup without repeating it.
receipt = (raw/'cleanup_evidence_full1.log').read_text()
assert 'ActiveState=inactive' in receipt
assert prop('ActiveState') == 'inactive'
assert not prop('InvocationID')
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
assert 'InvocationID=f4e7a13784ed4829af153f8a361150d6' in (raw/'full_full1_evidence1_scope.txt').read_text()
# Scope auto-removed; final counters are not reconstructed.


# One presentation-only correction after the prior verifier bound the document.
# Preserve its exact old bytes and validate the only changed leading marker.
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
verification = out/'20261003_d185_evidence_verification.json'
assert sha(verification) == 'f7ad7ced9f501d1ff0e893d90db19128ecec72db0181d6dcce854090d58fea08'
vr = json.loads(verification.read_text())
old_doc = raw/'document_before_table_format.md'
doc = root/'docs/ieee_tc/D185_FULL_W0_FULL1.md'
old_bytes, new_bytes = old_doc.read_bytes(), doc.read_bytes()
marker = b'+| mean_ttft (s) | 2.730194 | 2.730961 | -0.028% |'
assert old_bytes.count(marker) == 1
assert new_bytes == old_bytes.replace(marker, marker[1:], 1)
assert any(r['path'] == str(doc) and r['sha256'] == sha(old_doc) for r in vr['refs'])
assert not any(line.startswith(b'+|') for line in new_bytes.splitlines())
correction = dict(kind='d185_document_format_correction_v1',
    prior_verification_sha256=sha(verification),
    old_document=dict(path=str(old_doc),sha256=sha(old_doc)),
    current_document=dict(path=str(doc),sha256=sha(doc)),
    exact_change='Remove one leading plus from first comparison-table row',
    numerical_values_changed=False, prior_numeric_checks_reused=True)
correction_path = out/'20261003_d185_document_format_correction.json'
with correction_path.open('x') as h:
    json.dump(correction,h,indent=2,allow_nan=False)

# Only top-level small scripts, configuration and receipts; no remote journal,
# monitor, projection, raw outcomes, model files, token files or cache roots.
members = sorted(p for p in raw.iterdir() if p.is_file() and
    p.stat().st_size < 64*1024 and p.suffix in {'.py','.sh','.jq','.yaml','.json','.log','.txt'})
# Explicit streaming-projection source receipt.
extras = [raw/'full_full1_metadata_projection4.sha256',raw/'document_before_table_format.md']
assert all(p.is_file() and p.stat().st_size < 128*1024 for p in extras)
members = sorted(set(members + extras))
bundle = out/'20261003_d185_analysis_sources.tar.gz'
assert not bundle.exists()
hashes = {}
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        data = p.read_bytes()
        # Anchor actual PEM header; attempt1 matched its own check literal.
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line
                       for line in data.splitlines())
        hashes[str(p.relative_to(raw))] = hashlib.sha256(data).hexdigest()
        archive.add(p,arcname=str(p.relative_to(raw)),recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name, expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
manifest = out/'20261003_d185_analysis_sources.sha256'
with manifest.open('x') as f:
    f.write(hashlib.sha256(bundle.read_bytes()).hexdigest()+'  '+bundle.name+'\n')
members_manifest = out/'20261003_d185_analysis_sources_members.json'
with members_manifest.open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(bundle=str(bundle),bytes=bundle.stat().st_size,members=len(hashes),
                      sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),cleanup=True)))
