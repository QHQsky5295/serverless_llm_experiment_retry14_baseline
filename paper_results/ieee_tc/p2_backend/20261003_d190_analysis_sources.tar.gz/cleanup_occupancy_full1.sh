#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d190_20261003
unit=primelora-d190-occupancy1-20261003.scope
{
  date -Is
  rg -qx 'InvocationID=087786b70ba74cde8211232220ee006a' "$raw/scope_before1.txt"
  rg -q 'Exit status: 0' "$raw/audit_time1.txt"
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
  test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
  test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
  systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
  printf 'actual_invocation=087786b70ba74cde8211232220ee006a\nexit_code=0\ncleanup=automatic_removal_verified\nfinal_memory_events=occupancy1_memory_events.txt_and_occupancy1_swap.txt\n'
} | tee "$raw/cleanup_occupancy_full1.log"
