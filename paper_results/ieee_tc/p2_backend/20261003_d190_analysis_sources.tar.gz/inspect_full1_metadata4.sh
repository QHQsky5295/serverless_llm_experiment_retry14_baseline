#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d190_20261003
unit=primelora-d190-full1-metadata4-20261003.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_metadata4_scope.txt"
/usr/bin/python3 - "$raw/project_metadata4.jq" <<'PY'
import json, subprocess, sys
cases = [
 {'run_completed':True, 'error':None, 'cleanup_errors':[],
  'mechanism_events':{'events':[{'state':'failed','nested':{'x':[1,False,None,-0.0,1e-100]}}]},
  'coordination_after_shutdown':{'ieee_full_launch_contract':{'timeout':1800.0},'ieee_movements':[{'state':'cancelled'}], 'unused':[1,2]}},
 {'run_completed':False,'error':'string with \\" and newline\n', 'remote_transfers':[],
  'coordination_after_shutdown':{'ieee_full_launch_contract':{},'ieee_movements':[], 'unused':{'a':[]}}},
]
for case in cases:
    proc=subprocess.run(['jq','--stream','-c','-n','-f',sys.argv[1]],input=json.dumps(case),text=True,capture_output=True,check=True)
    expected=dict(case)
    expected['coordination_after_shutdown']={k:case['coordination_after_shutdown'][k] for k in ('ieee_full_launch_contract','ieee_movements')}
    assert json.loads(proc.stdout)==expected
negative=subprocess.run(['jq','--stream','-c','-n','-f',sys.argv[1]],input='{"x":9007199254740993}',text=True,capture_output=True)
assert negative.returncode != 0
print('two exact-tree projection fixtures and unsafe-number negative PASS')
PY
source_file="$raw/7b_full_w0_full1/launch.launch/physical_deployment/main_outcome.json"
target="$raw/full_full1_main_outcome_projection4.json"
/usr/bin/time -v -o "$raw/full_full1_metadata4_project_time.txt" \
 jq --stream -c -n -f "$raw/project_metadata4.jq" "$source_file" > "$target"
test "$(stat -c %s "$target")" -lt 134217728
sha256sum "$source_file" "$target" > "$raw/full_full1_metadata_projection4.sha256"
/usr/bin/time -v -o "$raw/full_full1_metadata4_time.txt" \
 /usr/bin/python3 "$raw/collect_full1_preliminary4.py" > "$raw/full_full1_metadata4.log" 2>&1
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
awk '{print}' "/sys/fs/cgroup$cg/memory.events" > "$raw/full_full1_metadata4_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$cg/memory.swap.current" > "$raw/full_full1_metadata4_swap.txt"
