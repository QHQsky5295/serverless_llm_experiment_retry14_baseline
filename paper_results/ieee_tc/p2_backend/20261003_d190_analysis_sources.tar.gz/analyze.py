"""Reuse D171 timing-bound analysis for completed D190; no replay, new thresholds or formal SLO claim."""
import csv
import json
import math
from pathlib import Path
from statistics import mean
from scripts.ieee_tc_preflight import ROOT, digest, check_plan
from scripts.analyze_control_path_overhead import provisional_timing_bound
from faaslora.metrics.metrics_collector import NativeV1TokenTimeline

RAW=Path(__file__).parent.resolve()
OUT=ROOT/'paper_results/ieee_tc/p2_backend'
prior=OUT/'20261003_d190_7b_full_w0_full1.json'
warm=OUT/'20261002_d170_warm_measurement.json'
index=OUT/'20261002_d168_warm_input_index.json'
projection=ROOT/'results/ieee_tc/p2_backend_qualification/d190_20261003/full_full1_request_projection.json'
deployment=projection.parent/'7b_full_w0_full1/launch.launch/physical_deployment/deployment.json'
protocol=ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
sources={str(p):digest(p) for p in (prior,warm,index,projection,deployment,protocol,
          ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'tests/test_ieee_tc_timing_bound.py',Path(__file__))}
assert sources[str(prior)]=='cdae93875a976a4cb332bba7158925b28475abb7b489741367b3b135596cda77'
assert sources[str(warm)]=='0ebc7587effe293dcb986d33fb932c100cbcb3384c56ab2c0b0bec73b2bdd88c'
assert sources[str(projection)]=='bdaacbf657446876efdb83137f073233b02fcc62a4b61a5020e1dd2e09b9877c'
assert sources[str(protocol)]=='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
plan_sha=check_plan()
load=lambda p:json.loads(p.read_text())
p,w,idx,d=map(load,(prior,warm,index,deployment))
for path in (projection,deployment):
    assert any(ref['path']==str(path) and ref['sha256']==sources[str(path)] for ref in p['source_refs'])
assert w['passed'] and w['measured_warm_reference'] and not w['common_reference_frozen']
assert w['n_correct'] is None and not p['full_qualified']
assert projection.stat().st_size<64*1024**2
rows=load(projection)['requests']
assert len(rows)==d['plan']['count']==4000
thresholds=[dict(group_id=t['group_id'],lower_exclusive=t['lower_exclusive'],
    upper_inclusive=t['upper_inclusive'],ttft_s=t['candidate_ttft_threshold_ms']/1000,
    tpot_s=t['candidate_tpot_threshold_ms']/1000) for t in w['warm_threshold_candidates']]
normalized=[]
# RPC timing normalization serializes native integer counts as x.0.
# jq 1.6 canonicalizes these to x; jq 1.7 retains their lexical form.
# Accept only exact positive JSON integers in the safe range, and cross-check
# against independently retained integer request counts. Never round/truncate.
def exact_count(value):
    if (type(value) not in (int,float) or not math.isfinite(value)
            or not 0 < value < 2**53 or int(value) != value):
        raise ValueError('not an exact positive JSON token count')
    return int(value)
assert exact_count(152)==exact_count(152.0)==152
for bad in (True,False,None,'152',0,-1,1.5,float('nan'),float('inf'),2**53):
    try:
        exact_count(bad)
    except ValueError:
        pass
    else:
        raise AssertionError(('invalid count accepted',bad))
count_representation_audit={'native_output_tokens':{},'actual_prompt_tokens':{}}
stages=('arrival_to_admission_s','admission_to_engine_dispatch_s','engine_entry_to_queue_s',
        'native_engine_queue_s','native_prefill_s')
errors=[]
for r in rows:
    assert r['success'] is True and r['output_contract_match'] is True
    assert r['generation_contract']=='fixed_length_greedy_v1'
    assert r['completion_token_source']=='vllm_token_ids'
    t=r['native_token_timing']
    check=NativeV1TokenTimeline.service_breakdown(t,admitted_at=t['controller_admitted_monotonic_s'],
        completed_at=t['controller_completed_monotonic_s'],clock_id=d['clock_id'])
    n=exact_count(t['native_output_tokens'])
    prompt_count=exact_count(t['actual_prompt_tokens'])
    assert type(r['input_tokens']) is int and prompt_count==r['input_tokens']
    assert type(r['completion_tokens']) is int
    for key in count_representation_audit:
        label=type(t[key]).__name__
        count_representation_audit[key][label]=count_representation_audit[key].get(label,0)+1
    assert n==r['completion_tokens']==r['requested_completion_tokens']
    arrival=d['arrival_start_s']+r['scheduled_arrival_offset_s']
    ttft=t['native_first_token_monotonic_s']-arrival
    tpot=(t['native_last_token_monotonic_s']-t['native_first_token_monotonic_s'])/(n-1) if n>1 else None
    sv=dict(arrival_to_admission_s=t['controller_admitted_monotonic_s']-arrival)
    for name in stages[1:]: sv[name]=check[name[:-2]+'_ms']/1000
    assert all(math.isfinite(v) and v>=0 for v in sv.values())
    es=[abs(ttft-r['overall_ttft_ms']/1000),abs(ttft-sum(sv.values()))]
    if n>1: es.append(abs(tpot-r['tpot_ms']/1000))
    else: assert r['tpot_ms'] is None
    assert max(es)<=.001
    errors.extend(es)
    assert r['retained_reference_evidence']['confirmed_dispatch_snapshot'] is True
    tier=r['readiness_tier_before_dispatch']
    assert tier in ('gpu','host','nvme','remote')
    normalized.append(dict(request_id=r['request_id'],success=True,prompt_tokens=prompt_count,
        token_count=n,ttft_s=ttft,tpot_s=tpot,tier=tier,**sv))
result=provisional_timing_bound(normalized,thresholds,offered_count=4000)
result['count_representation_audit']=count_representation_audit
result['exact_integer_decode_qualification']='2 positive representations and 10 invalid cases; all counts cross-checked against retained integer request fields; strict timing helper unchanged'
decisions=result.pop('decisions')
for r,decision in zip(normalized,decisions): r.update(decision)
for g in idx['groups']:
    assert sum(r['group_id']==g['group_id'] for r in normalized)==g['source_count']
def stats(values):
    values=sorted(values)
    return dict(mean=mean(values),p95=values[math.ceil(.95*len(values))-1]) if values else dict(mean=None,p95=None)
groups=[]
for kind,labels in [('all',['all']),('input_group',[0,1]),('tier',['gpu','host','nvme','remote']),
                    ('outcome',list(result['outcome_counts']))]:
    for label in labels:
        selected=[r for r in normalized if kind=='all' or r[{'input_group':'group_id','tier':'tier','outcome':'outcome'}[kind]]==label]
        count=len(selected)
        if not count: continue
        ts=stats([r['ttft_s'] for r in selected])
        ps=stats([r['tpot_s'] for r in selected if r['tpot_s'] is not None])
        item=dict(kind=kind,label=label,count=count,
            timing_pass_count=sum(r['timing_joint_pass'] for r in selected),
            timing_pass_fraction=sum(r['timing_joint_pass'] for r in selected)/count,
            mean_ttft_s=ts['mean'],p95_ttft_s=ts['p95'],mean_tpot_s=ps['mean'],p95_tpot_s=ps['p95'])
        for name in stages:
            item['mean_'+name]=mean(r[name] for r in selected)
            # Observed single span exceeds the entire first-token deadline, not a counterfactual.
            item[name+'_exceeds_ttft_threshold_count']=sum(r[name]>thresholds[r['group_id']]['ttft_s'] for r in selected)
        item['pre_engine_exceeds_ttft_threshold_count']=sum(
            r['arrival_to_admission_s']+r['admission_to_engine_dispatch_s']>thresholds[r['group_id']]['ttft_s'] for r in selected)
        assert abs(sum(item['mean_'+s] for s in stages)-ts['mean'])<1e-8
        groups.append(item)
result.update(plan_sha256=plan_sha,sources=sources,thresholds=thresholds,groups=groups,
    common_reference_frozen=False,source_run='D190 7B Full W0 development block41',run_count=1,
    physical_gpu_s=p['physical']['gpu_seconds'],gpu_s_per_offered=p['physical']['gpu_seconds']/4000,
    gpu_s_per_correct=None,resident_budget=None,max_timing_reconstruction_error_s=max(errors),
    interpretation='Timing-only upper bound under provisional common 7B candidates; z remains unknown. '
    'Conditional tier groups are not causal effects. Stage spans are observed, not counterfactual speedups. '
    'No CI, old-Prime superiority, globally frozen SLO, Resident budget or formal G1/G2 qualification.')
outputs=[(OUT/'20261003_d190_timing_groups.csv',groups),
         (OUT/'20261003_d190_timing_requests.csv',normalized)]
old_path=OUT/'20261003_d185_7b_full_w0_full1.json'
assert digest(old_path)=='159cfc9c5b32c1f909f6118bc7a9137ebe735998703a8fc08ee0b0790d6bc21e'
old=load(old_path)
result['sources'][str(old_path)]=digest(old_path)
comparison=[]
for label,key,stat,scale,unit in [
    ('mean_ttft','overall_ttft_ms','mean',1000,'s'),
    ('p95_ttft','overall_ttft_ms','p95_type1',1000,'s'),
    ('p99_ttft','overall_ttft_ms','p99_type1',1000,'s'),
    ('mean_internal_e2e','overall_e2e_ms','mean',1000,'s'),
    ('mean_dispatch_admission_wait','dispatch_admission_wait_ms','mean',1000,'s'),
    ('mean_service_ttft','service_ttft_ms','mean',1000,'s'),
    ('mean_native_ttft','vllm_ttft_ms','mean',1,'ms'),
    ('mean_tpot','tpot_ms','mean',1,'ms'),
    ('p95_tpot','tpot_ms','p95_type1',1,'ms'),
    ('mean_response_pickup','parent_rpc_response_pickup_delay_ms','mean',1,'ms'),
    ('physical_gpu_seconds',None,None,1,'GPU-s')]:
    a=old['conditional_success_latency_ms'][key][stat]/scale if key else old['physical']['gpu_seconds']
    b=p['conditional_success_latency_ms'][key][stat]/scale if key else p['physical']['gpu_seconds']
    assert a>0 and math.isfinite(a) and math.isfinite(b)
    comparison.append(dict(metric=label,unit=unit,d185=a,d190=b,lower_better_reduction=(a-b)/a))
outputs.append((OUT/'20261003_d190_vs_d185_comparison.csv',comparison))
for path,table in outputs:
    with path.open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
result['table_sha256']={str(path):digest(path) for path,_ in outputs}
with (OUT/'20261003_d190_timing_gap.json').open('x') as f: json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in result.items() if k not in ('sources','groups','table_sha256')},indent=2))
print(json.dumps(groups,indent=2))
