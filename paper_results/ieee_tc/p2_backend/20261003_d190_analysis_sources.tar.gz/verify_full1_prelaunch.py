"""Reuse D185 Full gates for the sole D189 immutable preparation candidate."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight, check_plan
from faaslora.runtime_configuration import resolve_facade_lora_capacity

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d190_20261003'
previous = root/'results/ieee_tc/p2_backend_qualification/d185_20261003'
calibration = root/'results/ieee_tc/p2_backend_qualification/d157_20261002'
expected_commit = '8a106bb5cc84317a02a089cfddb609065fc23ad7'
prior_runtime = '2615d240b567043e4ca92b0debc30a0480e0b347'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected_commit
dirty = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty) <= {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'}, dirty
assert check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old_path, new_path = previous/'7b_main_config_full1.yaml',raw/'7b_main_config_full1.yaml'
old, new = [yaml.safe_load(path.read_text()) for path in (old_path,new_path)]
for config in (old,new):
    assert config['workload']['total_requests'] == 4000
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
assert old == new, 'change beyond three fresh owned paths from actual D185 Full'
declared_profiles = ('ieee_service_profile','ieee_preparation_profile')
assert not (raw/'7b_full_w0_full1').exists()
assert not (raw/'7b_nvme_full1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d190-7b-full1/tc_ieee_full').exists()
prior = previous/'prelaunch_verification.json'
assert digest(prior) == 'ce8fd3e0239845d94a805fde9e63f1fbfab22c6fbfa2b5c1bb1b311bb1577647'
full_before = json.loads(prior.read_text())
refs = dict(full_before['source_sha256'])
allowed_changes = {
    'scripts/run_all_experiments.py', 'faaslora/storage/http_artifact_store.py',
    'faaslora/memory/residency_manager.py', 'tests/test_ieee_tc_static_preparation.py'}
actual_changed = set(subprocess.check_output(['git','diff','--name-only',prior_runtime,expected_commit,'--',
                                             'faaslora','scripts','tests'],cwd=root,text=True).splitlines())
assert actual_changed == allowed_changes, actual_changed
changes = []
for name, expected in tuple(refs.items()):
    path = Path(name) if name.startswith('/') else root/name
    actual = digest(path)
    if actual != expected:
        relative = str(path.relative_to(root))
        assert relative in allowed_changes, (name,expected,actual)
        before = subprocess.check_output(['git','show',prior_runtime+':'+relative],cwd=root)
        after = subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)
        assert hashlib.sha256(before).hexdigest() == expected
        assert hashlib.sha256(after).hexdigest() == actual
        changes.append(dict(path=relative,before=expected,after=actual))
        refs[name] = actual
for relative in allowed_changes:
    path = root/relative
    assert digest(path) == hashlib.sha256(subprocess.check_output(['git','show',expected_commit+':'+relative],cwd=root)).hexdigest()
    refs[str(path)] = digest(path)
verification_path = root/'paper_results/ieee_tc/p2_backend/20261002_d157_evidence_verification.json'
assert digest(verification_path) == '61b606b02363a85952fd53bf7d408c19de40875393468530c846aefed7934158'
verification = json.loads(verification_path.read_text())
assert verification['actual_native_qualification_pass'] and verification['native_contract_samples'] == 184
assert verification['class_domain_covered'] and not verification['full_qualified']
assembly_path = calibration/'main_assembly3.json'
assert digest(assembly_path) == 'b5b8b2cd97454151f34735ceea94d9521aa9619d88358488125b7246c3d61aa0'
assembly = json.loads(assembly_path.read_text())
assert assembly['pass'] and len(assembly['records']) == 1
record = assembly['records'][0]
assert record['pass'] and record['requests'] == 4000 and record['adapter_count'] == 500
assert record['one_runtime_capacity'] == 4 and record['four_runtime_capacity'] == 16
assert record['initialized_engines'] == 0 and not record['actual_inference']
model = resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras'] == 24
assert model['max_num_seqs'] == model['runtime_concurrency_cap'] == model['requested_runtime_concurrency_cap'] == model['max_loras'] == 4
manifest_path = root/'paper_results/ieee_tc/p2_backend/d157_7b_initialization/manifest.json'
assert digest(manifest_path) == '51419cc52b607deb61c71554163ceeda4f6dfda91916bf39af8965cc4c7676ad'
manifest = json.loads(manifest_path.read_text())
assert manifest['pass'] and manifest['coverage']['class_domain_covered']
for key in declared_profiles:
    binding = new['resource_coordination'][key]
    assert binding == manifest['bindings'][key]
    assert digest(root/binding['path']) == binding['sha256']
contract = json.loads((root/manifest['contract']['path']).read_text())
assert new['resource_coordination'] == contract['coordination'] | manifest['bindings']
trace, subset = full_before['trace'], full_before['subset']
assert trace['count'] == trace['source_count'] == 4000 and trace['profile'] == 'W0'
assert trace['view_sha256'] == 'a5331be2e2204483f18206825d9aaa18cbaa259fe0babfc303f989055819430d'
assert digest(Path(trace['source_path'])) == trace['source_sha256'] == 'efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
assert digest(Path(subset['path'])) == subset['sha256'] == 'aa94b21e1295aefde664e5b29c030a9e42e02af946369bfe9ae15336b89b3016'
for path in [raw/name for name in ('7b_main_config_full1.yaml','run_7b_full_w0_full1.sh',
    'activate_services_full1.sh','check_health.sh','run_health.sh','verify_full1_prelaunch.py','prepare_full1.sh')] + [
    verification_path,assembly_path,manifest_path,old_path,prior,root/'docs/ieee_tc/PLAN_APPROVED_20261002_PRIME_FIRST.md']:
    refs[str(path)] = digest(path)
qualification_path = root/'paper_results/ieee_tc/p2_backend/20261003_d189_static_preparation.json'
assert digest(qualification_path) == '7a148b19070c2b0e0d3241adec3dea43782403cb6d12bd52dafcd246cf283dd9'
qualification = json.loads(qualification_path.read_text())
assert qualification['kind'] == 'd189_static_preparation_qualification_v1'
assert qualification['status'] == 'cpu_qualified_full_replay_pending'
assert not qualification['performance_accepted'] and not qualification['numeric_qualification']
assert [row['tests'] for row in qualification['tests']] == [21, 1062]
assert all(row['status'] == 'PASS' and row['scope_absent'] for row in qualification['tests'])
for name, expected in qualification['source_sha256'].items():
    assert digest(Path(name)) == expected, name
    refs[name] = expected
refs[str(qualification_path)] = digest(qualification_path)
# Intervening D165-D170 worker extension adds an explicit isolated audit
# argument. Ordinary observation defaults to no audit; do not invent a config flag.
tree=ast.parse((root/'faaslora/memory/gpu_monitor.py').read_text())
fn=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='ieee_worker_observation')
defaults=dict(zip((a.arg for a in fn.args.kwonlyargs),fn.args.kw_defaults))
assert isinstance(defaults['audit_adapter_ids'],ast.Constant) and defaults['audit_adapter_ids'].value is None
assert isinstance(defaults['synchronize'],ast.Constant) and defaults['synchronize'].value is False
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
resources = preflight([root,raw],32*1024**3)
assert resources['preflight_pass'], resources['issues']
receipt = dict(kind='d190_7b_full_prelaunch_v1',time_unix=time.time(),run='d190_7b_full_w0_full1',
    evidence_commit=expected_commit,runtime_source_commit=expected_commit,source_change='D189 reuses validated immutable preparation descriptions and content/subset/live-geometry-bound static targets; fresh inventory, source withdrawal, budgets and execution checks unchanged',
    expected_source_changes=changes,declared_model_changes=[],declared_profile_changes=[],
    same_d185_configuration_except_owned_paths=True,d185_controls_unchanged=True,
    diagnostic_instrumentation=False,formal_performance_result=False,source_sha256=refs,
    protected=protected,resource_preflight=resources,trace=trace,subset=subset,
    replay_scope='ordinary_full_4000',diagnostic_prefix_count=None,
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),plan_sha256=check_plan(),
    comparison='D185 versus D189 immutable preparation metadata; descriptive n=1, not G1/G2 acceptance',
    hypothesis='Remove repeated static content/target construction without caching live source or capacity; measure full waiting, TTFT, TPOT and physical GPU time including service setup',
    detailed_cpu_profiler=False,reused_initialization='D156 completed lengths and D157 admission-enabled profiles',
    warm_reference_sha=None,resource_reference_sha=None,
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as handle:
    json.dump(receipt,handle,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),sha256=digest(raw/'prelaunch_verification.json'),
    protected=147,source_refs=len(refs),population=4000,resource_pass=True,formal=False,changes=changes)))
