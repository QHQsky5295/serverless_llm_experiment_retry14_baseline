#!/usr/bin/env bash
# Reuse D145 closure protocol for observed D190 completion; no repeated tests.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d190_20261003
unit=primelora-d190-full1-evidence1-20261003.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p ActiveState -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/full_full1_evidence1_scope.txt"
export PYTHONUNBUFFERED=1
/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python - <<'PY'
import csv, json, math, subprocess
from datetime import datetime, timezone
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal
root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d190_20261003'
out = root/'paper_results/ieee_tc/p2_backend'
before = json.loads((raw/'prelaunch_verification.json').read_text())
for name, expected in before['source_sha256'].items():
    p = Path(name) if name.startswith('/') else root/name
    assert digest(p) == expected, name
assert len(before['source_sha256']) == 438
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert before['runtime_source_commit'] == '8a106bb5cc84317a02a089cfddb609065fc23ad7'
full = out/'20261003_d190_7b_full_w0_full1.json'
assert digest(full) == 'cdae93875a976a4cb332bba7158925b28475abb7b489741367b3b135596cda77'
x = json.loads(full.read_text())
assert x['native_contract_completion_pass'] and not x['full_qualified']
assert not x['formal_performance_result'] and x['launcher_cleanup_pass']
assert x['execution_completed'] and x['cleanup']['complete']
launch = json.loads((raw/'7b_full_w0_full1/launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert all(launch[k] == 0 for k in ('service_returncode','replay_returncode','watchdog_returncode'))
assert x['population']['success'] == x['population']['native_contract_matched'] == 4000
assert x['population']['terminal'] == x['population']['planned'] == 4000
assert x['population']['failure_observations'] == {}
assert x['timing_validation']['requests'] == 4000
assert max(x['timing_validation']['max_error_ms'].values()) <= 1.0
assert x['timing_validation']['pass_tolerance'] and x['timing_validation']['violations'] == []
assert x['timing_validation']['requests_over_tolerance'] == 0
assert x['physical']['n_correct'] is None and not x['physical']['eligible_correctness']
assert x['physical']['measurement_complete'] and not x['physical']['open_lease_ids']
assert not x['observed_completion_boundaries']['client_response_observed']
assert x['quarantine']['events'] == x['quarantine']['released'] == 0
assert x['remote']['uuid_pairs'] == 132
assert not x['remote']['byte_mismatches'] and x['remote']['request_packing'] == 0
assert x['remote']['states'] == {'published':132}
assert x['remote']['client_received_bytes'] == x['remote']['server_socket_written_bytes'] == 131480060
assert x['readiness_evidence']['confirmed_pre_generation_requests'] == 4000
assert x['readiness_evidence']['conflicts'] == 0
comparison = x['d185_request_contract_comparison']
assert comparison['request_ids_identical'] and comparison['requests'] == 4000
for field, audit in comparison['fields'].items():
    if field == 'completion_token_ids_sha256':
        assert audit['equal_requests'] == 3870 and len(audit['changed_request_ids']) == 130
    else:
        assert audit['equal_requests'] == 4000 and audit['changed_request_ids'] == []
planning = x['planning_cpu_diagnostics']
assert planning['events'] == 2026
assert set(planning['by_operation']) == {'owned_execution_epoch', 'initialized_gpu_objective'}
op = planning['by_operation']['owned_execution_epoch']
assert op['events'] == op['receipt_rows'] == 2024
assert op['state_counts'] == {'completed':2024}
assert op['errors'] == {}
assert op['execution_objectives_ms']['n'] == 2024
assert op['execution_objectives_ms']['mean'] > 0
init = planning['by_operation']['initialized_gpu_objective']
assert init['events'] == init['receipt_rows'] == 2
assert init['state_counts'] == {'completed':2} and not init['errors']
assert (raw/'full_full1_main_outcome_projection4.json').stat().st_size == 97684264
assert (raw/'full_full1_main_outcome_projection4.json').stat().st_size < 128*1024**2
for removed in x['cleanup']['roots']:
    assert not Path(removed['path']).exists(), removed['path']
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == x['metric_protocol_sha256']
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
reused, checked = [], 0
for ref in x['source_refs']:
    p = Path(ref['path'])
    if p.name == 'experiment_results_full_vllm_dedicated_a500_r4000_c2_tc_ieee_full_d190_7b_full_w0_full1.json':
        st = p.stat()
        assert st.st_size == 244697732 and st.st_mtime_ns <= full.stat().st_mtime_ns
        reused.append(dict(**ref,bytes=st.st_size,mtime_ns=st.st_mtime_ns,inode=st.st_ino,
                           verification='reuse_completed_curator_stream_hash_plus_stat'))
    else:
        assert digest(p) == ref['sha256'], ref['path']
        checked += 1
assert len(reused) == 1
failure = out/'20261003_d190_7b_full_w0_failure_breakdown.json'
f = json.loads(failure.read_text())
assert f['population'] == dict(planned=4000,success=4000,timeout=0,returned_error=0)
assert f['returned_categories'] == {}
assert f['failure_observation_clock_id'] == x['physical']['clock_id']
assert f['projection_sha256'] == digest(raw/'full_full1_request_projection.json')
assert f['source_script_sha256'] == digest(raw/'collect_full1_failure_breakdown.py')
assert not f['timeout_requests'] and not f['returned_requests']
assert f['returned_generation_submission_states'] == {}
assert f['returned_error_messages'] == {}
assert f['first_timeout'] is None and f['first_returned_error'] is None
occupancy_dir = out/'20261003_d190_control_occupancy'
occupancy = json.loads((occupancy_dir/'summary.json').read_text())
assert occupancy['population'] == dict(planned=4000,terminal=4000,native_success=4000,failed=0)
assert occupancy['phase_population'] == 'complete_native_success_population' and occupancy['failures'] == []
for ref in occupancy['source_refs']:
    assert digest(Path(ref['path'])) == ref['sha256']
phases = occupancy['phase_summaries']
assert all(v['n'] == 4000 for v in phases.values())
phase_sum = math.fsum(phases[k]['total_request_seconds'] for k in (
    'gate_to_source_admission','source_to_native_dispatch','native_dispatch_to_last_token',
    'last_token_to_controller_completion','controller_completion_to_terminal'))
assert math.isclose(phase_sum,phases['gate_to_terminal']['total_request_seconds'],abs_tol=1e-6)
with (occupancy_dir/'request_occupancy.csv').open() as h:
    rows = list(csv.DictReader(h))
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
controls = occupancy['control_observations']
assert controls['source_event_count'] == controls['in_request_window_count'] == 1815
assert controls['outside_request_window'] == []
assert sum(v['samples'] for v in controls['by_phase'].values()) == 1815
for filename in ('full_full1_projection_time.txt','full_full1_curation_time.txt',
                 'full_full1_failure_time.txt','full_full1_metadata4_time.txt','audit_time1.txt'):
    assert 'Exit status: 0' in (raw/filename).read_text(), filename
# Post-cleanup readback, not a reconstructed historical cleanup stdout.
stage_ids = {
 'metadata':('primelora-d190-full1-metadata4-20261003.scope','full_full1_metadata4_scope.txt','1f477fc675d04aba9ed918856fcfdf66'),
 'projection':('primelora-d190-full1-project-20261003.scope','full_full1_projection_scope.txt','60071c3b30dc4cd7ab81d3c960ff958e'),
 'curation':('primelora-d190-full1-curate-20261003.scope','full_full1_curation_scope.txt','ad68d8ba0fec48d0b0dc39b40e6dba5b'),
 'occupancy':('primelora-d190-occupancy1-20261003.scope','scope_before1.txt','087786b70ba74cde8211232220ee006a')}
post_cleanup = []
for stage,(unit,filename,invocation) in stage_ids.items():
    assert 'InvocationID='+invocation in (raw/filename).read_text()
    active = subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()
    assert active == 'inactive', unit
    post_cleanup.append(dict(stage=stage,unit=unit,historical_invocation=invocation,
        scope_receipt=filename,current_state=active,verification='post_cleanup_readback_not_original_stdout'))
# Verify automatic scope removal; final counters are used only where captured.
for stage,(unit,_,_) in stage_ids.items():
    assert not subprocess.check_output(['systemctl','--user','show',unit,'-p','InvocationID','--value'],text=True).strip()
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    receipt_name = 'cleanup_occupancy_full1.log' if stage == 'occupancy' else f'full_full1_{stage}_cleanup.txt'
    receipt = (raw/receipt_name).read_text()
    assert 'ActiveState=inactive' in receipt
# D190 also evaluates the SAME provisional reference; no formal SLO claim.
timing_path = out/'20261003_d190_timing_gap.json'
timing = json.loads(timing_path.read_text())
assert timing['timing_joint_pass_count'] == 3375 and timing['joint_upper_bound'] == 3375/4000
assert timing['minimum_additional_timing_passes'] == 425
assert timing['outcome_counts'] == dict(timing_pass=3375,ttft_only_miss=493,tpot_only_miss=109,both_miss=23,failure=0)
assert not timing['common_reference_frozen'] and not timing['correctness_qualified']
assert timing['n_correct'] is None and timing['formal_joint_slo'] is None
assert not timing['formal_g1_g2_qualified'] and timing['resident_budget'] is None
assert timing['physical_gpu_s'] == x['physical']['gpu_seconds']
assert timing['max_timing_reconstruction_error_s'] <= .001
for path,sha in timing['sources'].items(): assert digest(Path(path)) == sha
for path,sha in timing['table_sha256'].items(): assert digest(Path(path)) == sha
for name,count in [('timing_groups',11),('timing_requests',4000),('vs_d185_comparison',11)]:
    with (out/('20261003_d190_'+name+'.csv')).open() as h: table=list(csv.DictReader(h))
    assert len(table)==count
analysis_unit='primelora-d190-analyze1-20261003.scope'
assert 'InvocationID=ba9b31d091ae4ed5a58c33a2b1de7d3c' in (raw/'analyze1_scope.txt').read_text()
assert 'Exit status: 0' in (raw/'analyze1_time.txt').read_text()
for line in (raw/'analyze1_memory_events.txt').read_text().splitlines(): assert int(line.split()[1])==0
assert int((raw/'analyze1_swap.txt').read_text())==0
assert subprocess.check_output(['systemctl','--user','show',analysis_unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
assert not subprocess.check_output(['systemctl','--user','show',analysis_unit,'-p','InvocationID','--value'],text=True).strip()
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',analysis_unit).exists()
# D190 uses the already-corrected D185 analyzer; no failed first timing attempt.
assert timing['count_representation_audit']=={'native_output_tokens':{'int':4000},'actual_prompt_tokens':{'int':4000}}
for line in (raw/'occupancy1_memory_events.txt').read_text().splitlines(): assert int(line.split()[1])==0
assert int((raw/'occupancy1_swap.txt').read_text())==0
# Direct metadata4 projection: no metadata3 failure or intermediate exists.
assert (raw/'full_full1_main_outcome_projection4.json').stat().st_size < 134217728
for stage in ('metadata4','projection','curation'):
    for line in (raw/f'full_full1_{stage}_memory_events.txt').read_text().splitlines():
        assert int(line.split()[1])==0
    assert int((raw/f'full_full1_{stage}_swap.txt').read_text())==0
# Three actual analysis consumers access only these final-coordination fields.
# All mechanism events, including nested details and failures, remain intact.
import ast
consumed=set()
for filename in ('collect_full1_preliminary4.py','summarize_full_full1.py'):
    tree=ast.parse((raw/filename).read_text())
    for node in ast.walk(tree):
        if (isinstance(node,ast.Subscript) and isinstance(node.value,ast.Subscript)
            and isinstance(node.value.slice,ast.Constant) and node.value.slice.value=='coordination_after_shutdown'):
            assert isinstance(node.slice,ast.Constant)
            consumed.add(node.slice.value)
assert consumed=={'ieee_full_launch_contract','ieee_movements'}
# Exact paper-table values are generated from the comparison, not hand-selected.
doc=(root/'docs/ieee_tc/D190_FULL_W0_FULL1.md').read_text()
with (out/'20261003_d190_vs_d185_comparison.csv').open() as handle:
    comparison_rows=list(csv.DictReader(handle))
assert len(comparison_rows)==11
for row in comparison_rows:
    expected=f"| {float(row['d185']):.6f} | {float(row['d190']):.6f} | {100*float(row['lower_better_reduction']):.3f}% |"
    assert expected in doc, row['metric']
# Existing unchanged timing helper's qualified source/tests are reused.
prior_timing=out/'20261002_d171_timing_gap.json'
assert digest(prior_timing)=='361bb4bc1ff7c49ac23449227d4dd31d7829cc87fbc86d7847c0658bb5dd7a15'
pt=json.loads(prior_timing.read_text())
for path in (root/'scripts/analyze_control_path_overhead.py',root/'tests/test_ieee_tc_timing_bound.py'):
    assert digest(path)==pt['sources'][str(path)]
# Existing unchanged analysis regression is reused, not rerun to pad work.
prior = out/'20261001_d137_evidence_verification.json'
assert digest(prior) == '18b496f98daf9aa48aab8d98d68b75507df33798bd8b29b470e75d3a98da4c17'
assert json.loads(prior.read_text())['pass_checks']
refs = [full,failure,prior,raw/'collect_full1_failure_breakdown.py',raw/'full_full1_failure_time.txt',
        raw/'summarize_full_full1.py',raw/'verify_full1_evidence.sh',raw/'full_full1_curation_time.txt',
        raw/'run_occupancy_audit1.sh',raw/'cleanup_occupancy_full1.sh',raw/'cleanup_occupancy_full1.log',
        raw/'scope_before1.txt',raw/'audit_time1.txt',root/'docs/ieee_tc/D190_FULL_W0_FULL1.md',
        root/'scripts/analyze_control_path_overhead.py',root/'tests/test_ieee_tc_control_timeline.py',
        raw/'full_full1_metadata_projection4.sha256']
refs += [raw/name for _,name,_ in stage_ids.values()]
refs += [raw/name for name in ('cleanup_projection_full1.sh','full_full1_projection_cleanup.txt',
 'cleanup_curation_full1.sh','full_full1_curation_cleanup.txt','full_full1_metadata_cleanup.txt')]
refs += [out/'20261003_d185_7b_full_w0_full1.json', out/'20261003_d190_vs_d185_comparison.csv']
refs += [p for p in occupancy_dir.iterdir() if p.is_file()]
refs += [raw/'cleanup_analyze1.sh',raw/'analyze1_cleanup.txt',raw/'occupancy1_memory_events.txt',raw/'occupancy1_swap.txt']
refs += [timing_path, prior_timing, raw/'analyze.py', raw/'run_cpu.sh',
    raw/'analyze1_scope.txt',raw/'analyze1_time.txt',raw/'analyze1.log',
    raw/'analyze1_memory_events.txt',raw/'analyze1_swap.txt',
    raw/'inspect_full1_metadata4.sh',
    raw/'collect_full1_preliminary4.py',raw/'project_metadata4.jq',
    raw/'full_full1_metadata4_project_time.txt',
    out/'20261003_d190_timing_groups.csv',out/'20261003_d190_timing_requests.csv']
receipt = dict(kind='d190_full1_evidence_verification_v1',pass_checks=True,
    verified_at=datetime.now(timezone.utc).isoformat(),full_qualified=False,formal_performance_result=False,
    frozen_source_refs_checked=len(before['source_sha256']),curated_source_refs_rehashed=checked,
    reused_large_source_hash=reused,source_commit=before['runtime_source_commit'],
    protected=protected,post_cleanup_readback=post_cleanup,
    failed_population_preserved=True,prior_d145_timeout_root_cause_unresolved=True,
    regression_reused=str(prior),refs=[dict(path=str(p),sha256=digest(p)) for p in refs])
dest = out/'20261003_d190_evidence_verification.json'
with dest.open('x') as h:
    json.dump(receipt,h,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(dest),sha256=digest(dest),frozen_sources=438,
    curated_sources_rehashed=checked,reused_large_source_hash=len(reused),protected=147)))
PY
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
awk '{print}' "/sys/fs/cgroup$cg/memory.events" > "$raw/full_full1_evidence1_memory_events.txt"
awk '{print}' "/sys/fs/cgroup$cg/memory.swap.current" > "$raw/full_full1_evidence1_swap.txt"
