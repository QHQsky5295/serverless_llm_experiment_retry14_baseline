#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d190_20261003
unit=primelora-d190-analyze1-20261003.scope
{
 date -Is
 rg -qx 'InvocationID=ba9b31d091ae4ed5a58c33a2b1de7d3c' "$raw/analyze1_scope.txt"
 rg -q 'Exit status: 0' "$raw/analyze1_time.txt"
 test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
 test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
 test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
 test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
 systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
 printf 'actual_invocation=ba9b31d091ae4ed5a58c33a2b1de7d3c\nexit_code=0\ncleanup=automatic_removal_verified\n'
 awk '{print}' "$raw/analyze1_memory_events.txt" "$raw/analyze1_swap.txt"
} | tee "$raw/analyze1_cleanup.txt"
