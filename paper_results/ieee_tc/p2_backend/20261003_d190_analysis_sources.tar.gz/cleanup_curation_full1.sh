#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d190_20261003
unit=primelora-d190-full1-curate-20261003.scope
{
 date -Is
 rg -qx 'InvocationID=ad68d8ba0fec48d0b0dc39b40e6dba5b' "$raw/full_full1_curation_scope.txt"
 rg -q 'Exit status: 0' "$raw/full_full1_curation_time.txt"
 test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
 test -z "$(systemctl --user show "$unit" -p InvocationID --value)"
 test ! -e "/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
 test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
 systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
 printf 'actual_invocation=ad68d8ba0fec48d0b0dc39b40e6dba5b\nexit_code=0\ncleanup=automatic_removal_verified\n'
 awk '{print}' "$raw/full_full1_curation_memory_events.txt" "$raw/full_full1_curation_swap.txt"
} | tee "$raw/full_full1_curation_cleanup.txt"
