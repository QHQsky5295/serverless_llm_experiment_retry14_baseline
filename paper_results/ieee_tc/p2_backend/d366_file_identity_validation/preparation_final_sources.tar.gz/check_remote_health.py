import json
import sys
import time
from pathlib import Path
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from faaslora.storage.http_artifact_store import HttpArtifactStoreClient

token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_text().strip()
results = {}
for model, port in [('3b',18080),('7b',18081)]:
    client = HttpArtifactStoreClient(endpoint=f'http://192.168.4.174:{port}', token=token,
        timeout_s=5, required_delivery_mode='prepublished_gzip_v1')
    for attempt in range(10):
        try:
            data = client.health()
            break
        except (OSError, RuntimeError):
            if attempt == 9:
                raise
            time.sleep(1)
    assert data['ok'] and data['delivery_mode'] == 'prepublished_gzip_v1'
    assert data['timing_contract'] == 'artifact_timing_v2'
    results[model] = data
with (Path(__file__).resolve().parent/'remote_health.json').open('x') as f:
    json.dump(results, f, indent=2)
print(json.dumps(results))

