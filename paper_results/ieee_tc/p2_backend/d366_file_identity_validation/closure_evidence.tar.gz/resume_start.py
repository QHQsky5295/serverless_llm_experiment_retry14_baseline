"""D366 resume before GPU launch; same remote units, model Python for client health."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d366_file_identity_validation'
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin',
    'refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',
    'faaslora','scripts','configs/ieee_tc','tests'],cwd=ROOT,text=True).strip()
binding=json.loads((OUT/'preparation_final.json').read_text())
for ref in binding['refs']+binding['raw_refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
subprocess.run(['sha256sum','-c','preparation_final.sha256'],cwd=OUT,check=True)
previous=json.loads((RAW/'launch_gate.json').read_text())
assert previous['passed'] and previous['head']==head
assert previous['preparation_cleanup']['released'] and not previous['preparation_cleanup']['hard_kill']
preparation=json.loads((RAW/'preparation_scope_final.json').read_text())['identity']
assert not Path(preparation['path']).exists()
old=previous['identity']
assert p.scope_still_owned(old) and not p.owned_pids(Path(old['path']))
cleanup=p.stop_scope_identity(old)
assert cleanup['released'] and not cleanup['hard_kill']
with (RAW/'start_attempt1_failure.json').open('x') as f:
    json.dump(dict(failed_phase='remote_health_import_before_tmux',
        error="ModuleNotFoundError: No module named 'numpy'",
        interpreter='/usr/bin/python3',remote_started=True,gpu_run_started=False,
        identity=old,cleanup=cleanup,old_start_sha256=p.digest(RAW/'start.py'),
        resume_changes='use existing model Python for health; no remote restart and no preparation cleanup repeat'),f,indent=2)
gate=p.preflight([ROOT],32*p.GIB);assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not (RAW/'7b_file_identity_validation_100').exists()
assert subprocess.run(['tmux','has-session','-t','tc-d366-file100'],stderr=subprocess.DEVNULL).returncode!=0
with (RAW/'resume_launch_gate.json').open('x') as f:
    json.dump(dict(passed=True,head=head,remote=remote,gate=gate,identity=identity,
                   failed_start_cleanup=cleanup),f,indent=2)
# Remote startup completed. Verify exact existing units; never start them twice.
import re
log=(RAW/'remote_start.log').read_text()
units=('primelora-artifact-tc-3b.service','primelora-artifact-tc-7b.service',
       'primelora-artifact-monitor-d366-file100.service')
blocks=[dict(line.split('=',1) for line in block.splitlines() if '=' in line)
        for block in log.split('\n\n')]
expected={block['Id']:block['InvocationID'] for block in blocks if block.get('Id') in units}
assert set(expected)==set(units)
command=['ssh','-o','BatchMode=yes','primelora-artifact-174','systemctl','--user','show',
         *units,'-p','Id','-p','InvocationID','-p','ActiveState','-p','MainPID']
current=subprocess.check_output(command,text=True)
observed=[dict(line.split('=',1) for line in block.splitlines() if '=' in line)
          for block in current.split('\n\n')]
assert len(observed)==3
for block in observed:
    assert block['InvocationID']==expected[block['Id']]
    assert block['ActiveState']=='active' and int(block['MainPID'])>0
with (RAW/'remote_resume_identity.json').open('x') as f:
    json.dump(dict(expected=expected,observed=observed,restarted=False),f,indent=2)
subprocess.run(['/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python',
    str(RAW/'check_remote_health.py')],check=True,cwd=ROOT)
subprocess.run(['tmux','new-session','-d','-s','tc-d366-file100','-c',str(ROOT),
    'bash scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh d366'],check=True)
with (RAW/'start_receipt.json').open('x') as f:
    json.dump(dict(launched=True,head=head,remote=remote,tmux='tc-d366-file100',identity=identity),f,indent=2)
print(json.dumps(dict(launched=True,head=head,tmux='tc-d366-file100',remote_restarted=False)))
