"""Close only the empty D366 verifier and record the pushed checkpoint."""
import json, pathlib, subprocess, sys
ROOT=pathlib.Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
raw=pathlib.Path(__file__).resolve().parent
receipt=json.loads((raw/'seal_receipt.json').read_text())
assert receipt['passed']
old=receipt['identity'];group=pathlib.Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(group)
resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
closed=p.stop_scope_identity(old)
assert closed['released'] and not closed['hard_kill'] and not group.exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote and head==sys.argv[1]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
record=dict(passed=True,head=head,remote_head=remote,identity=old,cleanup=closed,resources=resources,
    no_gpu_compute=True,next='D367 complete W0 against D358/D353/D336; no repeated D366 collection or cleanup')
with (raw/'closure_backup_receipt.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record),flush=True)
