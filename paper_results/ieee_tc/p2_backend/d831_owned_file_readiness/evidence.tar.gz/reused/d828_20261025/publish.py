"""Reuse D827 evidence packaging for D828's closed analysis and CPU tests."""
import hashlib
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d828_post_file_owner_turn'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())
def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
def ref(path):
    return dict(path=str(path), sha256=p.digest(path), bytes=path.stat().st_size)

identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
save(RAW/'publication_identity.json', identity)
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
summary = read(OUT/'summary.json')
assert summary['passed'] and summary['matched_remote_cohort'] == 498
assert summary['groups']['all']['native_copy_present'] == 0
assert summary['groups']['all']['epoch_advanced'] == 113
for row in summary['source_refs']:
    assert p.digest(Path(row['path'])) == row['sha256']
closed = []
for phase in ('analysis', 'focused', 'regression'):
    receipt = read(RAW/(phase+'_receipt.json'))
    assert receipt['passed'] and receipt['protected']['entry_count'] == 147
    for path, sha in receipt.get('sources', {}).items():
        assert p.digest(Path(path)) == sha
    assert receipt['resources']['memory.swap.current'] == '0'
    assert all(int(line.split()[1]) == 0 for line in receipt['resources']['memory.events'].splitlines())
    old = read(RAW/(phase+'_identity.json'))
    assert not Path(old['path']).exists() and not p.scope_still_owned(old)
    properties = subprocess.check_output(['systemctl', '--user', 'show', old['unit'],
        '-p', 'ActiveState', '-p', 'ControlGroup', '-p', 'InvocationID'], text=True)
    assert 'ActiveState=inactive' in properties and 'ControlGroup=\n' in properties
    closed.append(dict(phase=phase, identity=old, properties=properties, path_removed=True))
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
protected_path = RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json'
protected = p.verify_seal(protected_path)
assert protected['pass'] and protected['entry_count'] == 147
user = read(ROOT/'paper_results/ieee_tc/p2_backend/d827_workspace_retirement/closure.json')['user_protected']
for path, sha in user.items():
    assert p.digest(Path(path)) == sha
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
dependencies = [RAW.parent/name/file for name, file in (
    ('d610_20261017', 'run_tests.py'), ('d595_20261017', 'run_tests.py'),
    ('d827_20261025', 'publish.py'), ('d824_20261025', 'backup.py'))]
files = sorted(path for path in RAW.iterdir() if path.is_file())
for path in files + dependencies:
    if path.suffix == '.py':
        compile(path.read_text(), str(path), 'exec')
members = [(path, 'raw/'+path.name) for path in files] + [
    (path, 'reused/'+path.parent.name+'/'+path.name) for path in dependencies]
with tarfile.open(OUT/'evidence.tar.gz', 'x:gz') as archive:
    for path, name in members:
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(OUT/'evidence.tar.gz', 'r:gz') as archive:
    for path, name in members:
        digest = hashlib.sha256()
        with archive.extractfile(name) as handle:
            while chunk := handle.read(1024*1024):
                digest.update(chunk)
        assert digest.hexdigest() == p.digest(path)
closure = dict(passed=True, user_protected=user, protected_union_files=147,
    protected_manifest=ref(protected_path), closed_scopes=closed, gpu_idle=True,
    new_gpu_replays=0, production_candidate=True, formal_performance=False,
    end_to_end_performance_accepted=False, n_correct=None, ranking_eligible=False,
    distinct_regression_tests=370, focused_tests_included=57,
    decision='One admitted owner anchor candidate CPU-qualified; complete unchanged 3B W2 next.',
    plan=ref(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')),
    doc=ref(ROOT/'docs/ieee_tc/D828_POST_FILE_OWNER_TURN_20261025.md'),
    production_sources=read(RAW/'regression_receipt.json')['sources'],
    scope=identity, resources={name: (group/name).read_text().strip() for name in
        ('memory.peak', 'memory.events', 'memory.swap.current')},
    disk_free_bytes=os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize,
    baseline_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'],
        cwd='/home/qhq/serverless_llm_baselines', text=True).strip())
save(OUT/'closure.json', closure)
save(OUT/'manifest.json', dict(archive_members=[dict(member=name, **ref(path)) for path, name in members],
    files=[ref(path) for path in sorted(OUT.iterdir()) if path.is_file()]))
print(json.dumps(dict(passed=True, files=len(members), protected=147, new_gpu_replays=0,
    distinct_tests=370, disk_free_bytes=closure['disk_free_bytes'])))
