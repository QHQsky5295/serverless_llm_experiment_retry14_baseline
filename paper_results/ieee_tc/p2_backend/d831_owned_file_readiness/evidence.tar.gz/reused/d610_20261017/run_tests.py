"""Reuse bounded D595 qualification with exact D610 affected tests."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/run_tests.py')
code = source.read_text()
start = code.index('paths=[ROOT/name')
end = code.index('\nrefs=', start)
code = code[:start] + """paths=[ROOT/name for name in (
    'faaslora/memory/residency_manager.py',
    'tests/test_ieee_tc_file_observation.py',
    'tests/test_ieee_tc_request_lifecycle.py')]
""" + code[end:]
start = code.index('tests=(')
end = code.index('\ncommand=', start)
code = code[:start] + """tests=(['tests.test_ieee_tc_file_observation']
    if phase=='focused' else ['tests.test_ieee_tc_request_lifecycle',
    'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_static_preparation'])""" + code[end:]
old = '    result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)'
assert code.count(old) == 1
code = code.replace(old, """    completed=[]
    for module in tests:
        invocation=[sys.executable,'-B','-m','unittest',module,'-v']
        log.write('Module: '+module+'\\n');log.flush()
        outcome=subprocess.run(invocation,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)
        completed.append(dict(command=invocation,returncode=outcome.returncode))
        if outcome.returncode:break
    from types import SimpleNamespace
    result=SimpleNamespace(returncode=max(abs(row['returncode']) for row in completed))
    command=completed""")
exec(compile(code, str(source), 'exec'))
