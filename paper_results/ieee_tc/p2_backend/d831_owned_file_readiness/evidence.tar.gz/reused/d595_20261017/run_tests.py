"""Reuse D549 bounded CPU test receipt; no GPU or performance run."""
import json,os,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,obj):
    with path.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
phase=sys.argv[1];assert phase in ('focused','regression')
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/(phase+'_identity.json'),identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],8*1024*1024);save(RAW/(phase+'_gate.json'),gate)
assert gate['preflight_pass'],gate['issues']
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
paths=[ROOT/name for name in ('faaslora/scheduling/resource_coordinator.py',
    'tests/test_ieee_tc_transfer_pressure.py','scripts/run_all_experiments.py',
    'tests/test_ieee_tc_cpu_frontend_integration.py','tests/test_ieee_tc_launch.py')]
refs={str(path):p.digest(path) for path in paths}
with tarfile.open(RAW/(phase+'_source.tar.gz'),'x:gz') as archive:
    for path in paths:archive.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
tests=(['tests.test_ieee_tc_transfer_pressure.SharedPressureFanout',
    'tests.test_ieee_tc_transfer_pressure.SharedPressure','tests.test_ieee_tc_transfer_pressure.TransferPressure']
    if phase=='focused' else ['tests.test_ieee_tc_transfer_pressure',
        'tests.test_ieee_tc_cpu_frontend_integration','tests.test_ieee_tc_launch'])
command=[sys.executable,'-B','-m','unittest',*tests,'-v']
with (RAW/(phase+'.log')).open('x') as log:
    result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=900)
for path,sha in refs.items():assert p.digest(Path(path))==sha
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}
receipt=dict(passed=result.returncode==0,returncode=result.returncode,phase=phase,command=command,
    identity=identity,resources=resources,protected=protected,sources=refs,
    driver_sha256=p.digest(Path(__file__)),log_sha256=p.digest(RAW/(phase+'.log')))
save(RAW/(phase+'_receipt.json'),receipt)
print(json.dumps(dict(passed=receipt['passed'],phase=phase,resources=resources)))
assert receipt['passed']
