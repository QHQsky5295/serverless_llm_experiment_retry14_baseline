"""Reuse bounded D610 runner for the two added request-completion checks."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d610_20261017/run_tests.py')
code = source.read_text()
old = "'faaslora/memory/residency_manager.py',\n    'tests/test_ieee_tc_file_observation.py',\n    'tests/test_ieee_tc_request_lifecycle.py'"
new = "'faaslora/preloading/preloading_manager.py',\n    'faaslora/scheduling/resource_coordinator.py', 'scripts/run_all_experiments.py',\n    'tests/test_ieee_tc_transfer_pressure.py', 'tests/test_ieee_tc_request_lifecycle.py'"
assert code.count(old) == 1
code = code.replace(old, new)
old = "tests=(['tests.test_ieee_tc_file_observation']\n    if phase=='focused' else ['tests.test_ieee_tc_request_lifecycle',\n    'tests.test_ieee_tc_transfer_pressure', 'tests.test_ieee_tc_static_preparation'])"
new = "tests=['tests.test_ieee_tc_request_lifecycle.SelectedSourceAdmissionIntegration.'+name for name in (\n    'test_ready_file_settlement_remains_in_completion_not_tpot',\n    'test_late_file_settlement_failure_overrides_completed_native_generation')]"
assert code.count(old) == 1
code = code.replace(old, new)
code = code.replace("exec(compile(code, str(source), 'exec'))",
    "code = code.replace(\"RAW/(phase\", \"RAW/('completion_'+phase\")\nexec(compile(code, str(source), 'exec'))")
exec(compile(code, str(source), 'exec'))
