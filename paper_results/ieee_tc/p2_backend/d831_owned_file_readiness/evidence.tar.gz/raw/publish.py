"""Reuse D828 closed-evidence packaging for D831's bounded CPU qualification."""
from pathlib import Path

_template = Path(__file__).resolve().parent.parent/'d828_20261025/publish.py'
_source = _template.read_text()
_start = _source.index("summary = read(OUT/'summary.json')")
_end = _source.index('\nclosed = []', _start)
_qualification = '''# The only post-regression source change adds two tests plus their helper.
import ast
current = read(RAW/'completion_focused_receipt.json')['sources']
for path, sha in current.items():
    assert p.digest(Path(path)) == sha
test_path = ROOT/'tests/test_ieee_tc_request_lifecycle.py'
with tarfile.open(RAW/'attempt3_regression_source.tar.gz', 'r:gz') as archive:
    before = ast.parse(archive.extractfile(str(test_path.relative_to(ROOT))).read())
after = ast.parse(test_path.read_text())
added_methods = {'check_file_settlement_after_native_tokens',
    'test_ready_file_settlement_remains_in_completion_not_tpot',
    'test_late_file_settlement_failure_overrides_completed_native_generation'}
for node in after.body:
    if isinstance(node, ast.ClassDef) and node.name == 'SelectedSourceAdmissionIntegration':
        assert added_methods <= {getattr(item, 'name', '') for item in node.body}
        node.body = [item for item in node.body if getattr(item, 'name', '') not in added_methods]
assert ast.dump(before) == ast.dump(after), 'regression source changed beyond added completion tests'
for path, sha in read(RAW/'attempt3_regression_receipt.json')['sources'].items():
    if path != str(test_path):
        assert p.digest(Path(path)) == sha
'''
_source = _source[:_start]+_qualification+_source[_end:]
_old = "    assert receipt['passed'] and receipt['protected']['entry_count'] == 147\n    for path, sha in receipt.get('sources', {}).items():\n        assert p.digest(Path(path)) == sha"
_new = '''    assert receipt['passed'] == (phase not in ('focused', 'attempt2_focused'))
    assert receipt['protected']['entry_count'] == 147
    with tarfile.open(RAW/(phase+'_source.tar.gz'), 'r:gz') as snapshot:
        for path, sha in receipt['sources'].items():
            data = snapshot.extractfile(str(Path(path).relative_to(ROOT))).read()
            assert hashlib.sha256(data).hexdigest() == sha'''
assert _source.count(_old) == 1
_source = _source.replace(_old, _new)
for _old, _new in (
    ('d828_post_file_owner_turn', 'd831_owned_file_readiness'),
    ("for phase in ('analysis', 'focused', 'regression'):",
     "for phase in ('focused', 'attempt2_focused', 'attempt3_focused', 'attempt3_regression', 'completion_focused'):"),
    ("    ('d827_20261025', 'publish.py'), ('d824_20261025', 'backup.py')",
     "    ('d828_20261025', 'publish.py'), ('d824_20261025', 'backup.py')"),
    ('distinct_regression_tests=370, focused_tests_included=57',
     'distinct_regression_tests=435, focused_tests_included=91, retained_failed_attempts=2'),
    ("decision='One admitted owner anchor candidate CPU-qualified; complete unchanged 3B W2 next.'",
     "decision='Owned file readiness CPU-qualified; preserve terminal settlement and complete 3B W2 next.'"),
    ('D828_POST_FILE_OWNER_TURN_20261025.md', 'D831_OWNED_FILE_READINESS_20261025.md'),
    ("production_sources=read(RAW/'regression_receipt.json')['sources']",
     'production_sources=current, regression_extension=sorted(added_methods)'),
    ('distinct_tests=370', 'distinct_tests=435'),
):
    assert _old in _source, _old
    _source = _source.replace(_old, _new)
_out = Path('/home/qhq/serverless_llm_experiment_retry14_baseline/paper_results/ieee_tc/p2_backend/d831_owned_file_readiness')
_out.mkdir(parents=True, exist_ok=False)
exec(compile(_source, str(_template), 'exec'), globals())
