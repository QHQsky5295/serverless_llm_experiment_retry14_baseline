"""Preserve first fixture failure; reuse the same bounded test driver."""
from pathlib import Path

source = Path(__file__).with_name('run_tests.py')
code = source.read_text()
old = "exec(compile(code, str(source), 'exec'))"
assert code.count(old) == 1
# The reused D610 script constructs D595's final runner. Prefix only its
# output names, not the test selection, resource gates or protection seal.
replacement = '''code = code.replace("exec(compile(code, str(source), 'exec'))",
    "code = code.replace(\\\"RAW/(phase\\\", \\\"RAW/('attempt2_'+phase\\\")\\nexec(compile(code, str(source), 'exec'))")
exec(compile(code, str(source), 'exec'))'''
code = code.replace(old, replacement)
exec(compile(code, str(source), 'exec'))
