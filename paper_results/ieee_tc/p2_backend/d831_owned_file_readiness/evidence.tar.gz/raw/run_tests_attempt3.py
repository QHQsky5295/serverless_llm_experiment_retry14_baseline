"""Retain both previous attempts; qualify the corrected ownership fixture."""
from pathlib import Path

source = Path(__file__).with_name('run_tests_attempt2.py')
code = source.read_text()
assert code.count("attempt2_'+phase") == 1
code = code.replace("attempt2_'+phase", "attempt3_'+phase")
exec(compile(code, str(source), 'exec'))
