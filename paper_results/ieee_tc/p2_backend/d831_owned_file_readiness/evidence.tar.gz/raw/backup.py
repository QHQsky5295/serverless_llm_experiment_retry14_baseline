"""Reuse D824 exact-path backup, including only the five qualified source files."""
from pathlib import Path

_template = Path(__file__).resolve().parent.parent/'d824_20261025/backup.py'
_source = _template.read_text()
for _old, _new in (
    ('d824_current_ingress_pending', 'd831_owned_file_readiness'),
    ('107185c45f49a891c0b391b1140b7d765e83daea', '8b0158bfeb527b6f51d3e3dba567ff3fc0722b5d'),
    ("OUT/'final_manifest.json'", "OUT/'manifest.json'"),
    ('D824_CURRENT_INGRESS_AND_CONTROL_20261025.md', 'D831_OWNED_FILE_READINESS_20261025.md'),
    ("         ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',",
     "         ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',\n         *[Path(path) for path in closure['production_sources']],"),
    ('len(set(paths)) == 20', 'len(set(paths)) == 10'),
    ('backup/d824-current-ingress-control-20261025', 'backup/d831-owned-file-readiness-20261025'),
    ('tc: preserve current 3B ingress and actual scaling-trigger diagnosis (D824)',
     'tc: overlap verified file consumption with owned settlement (D831)'),
):
    assert _old in _source, _old
    _source = _source.replace(_old, _new)
exec(compile(_source, str(_template), 'exec'), globals())
