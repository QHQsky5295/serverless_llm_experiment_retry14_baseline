"""D518 explicit tested checkpoint, reusing D517 source/protection checks."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d518_native_step_boundaries'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path): return json.loads(path.read_text())
def save(path, value):
    with path.open('x') as f: json.dump(value, f, indent=2, allow_nan=False)

def main():
    identity = p.scope_identity(p.cg_path().name)
    save(RAW/'backup_identity.json', identity)
    group = Path(identity['path'])
    assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
    assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip() == '0'
    assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
    gate = p.preflight([ROOT],p.GIB); assert gate['preflight_pass'],gate['issues']
    result = read(RAW/'cpu_result.json')
    assert result['tests'] == dict(passed=True,count=163,errors=0,failures=0,skipped=0)
    for ref in result['refs']: assert p.digest(Path(ref['path'])) == ref['sha256'],ref['path']
    closure = read(RAW/'cpu_closure.json')
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
    assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
    dirt = {
        ROOT/'configs/generated/lora_manifest_1000.json': '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
        Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'): '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
        Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'): '337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
    for path, sha in dirt.items(): assert p.digest(path) == sha,path
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == '75dc40f7d8a09dff21b90caae12a8ba0a95a1806'
    assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
    token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
    def check(data):
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
    OUT.mkdir(exist_ok=False)
    members = {}
    with tarfile.open(OUT/'evidence.tar.gz','x:gz') as archive:
        for name in ('cpu_check.py','close.py','backup.py','cpu.log','cpu_result.json','cpu_closure.json'):
            data = (RAW/name).read_bytes();check(data)
            info = tarfile.TarInfo(name);info.size=len(data);info.mtime=0
            archive.addfile(info,io.BytesIO(data))
            members[name] = hashlib.sha256(data).hexdigest()
    with tarfile.open(OUT/'evidence.tar.gz','r:gz') as archive:
        assert set(archive.getnames()) == set(members)
        for name,sha in members.items(): assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == sha
    summary = dict(result, closure=closure, preserved={str(k):v for k,v in dirt.items()},
        archive_members=members, archive_sha256=p.digest(OUT/'evidence.tar.gz'),
        experimental_state='CPU_qualified_GPU_not_run', serving_policy_changed=False)
    save(OUT/'qualification.json',summary)
    paths = ['faaslora/utils/core_timing.py','faaslora/scheduling/vllm_ieee_scheduler.py',
        'tests/test_ieee_tc_core_timing.py','docs/ieee_tc/D518_NATIVE_STEP_BOUNDARIES.md',
        'docs/ieee_tc/EXECUTION_STATUS.md',str(OUT.relative_to(ROOT)/'qualification.json'),
        str(OUT.relative_to(ROOT)/'evidence.tar.gz')]
    subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
    for name in paths:
        data=(ROOT/name).read_bytes();assert len(data)<2*1024*1024;check(data)
    subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
    staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
    assert set(staged)==set(paths)
    for name in paths:
        data=subprocess.check_output(['git','show',':'+name],cwd=ROOT);check(data)
        assert hashlib.sha256(data).hexdigest()==p.digest(ROOT/name)
    subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
    subprocess.run(['git','commit','-m','tc: qualify bounded V2 step component diagnosis (D518)'],cwd=ROOT,check=True)
    subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
    assert head==remote
    save(RAW/'backup_receipt.json',dict(passed=True,head=head,remote=remote,paths=paths,
        tests=result['tests'],identity=identity,summary_sha256=p.digest(OUT/'qualification.json'),
        resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
    print(json.dumps(read(RAW/'backup_receipt.json')))

if __name__ == '__main__':main()
