"""D518 bounded CPU qualification of opt-in native step timing, no inference."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

def main():
    identity = p.scope_identity(p.cg_path().name)
    save(RAW/'cpu_identity.json', identity)
    group = Path(identity['path'])
    assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
    assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip() == '0'
    assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
    assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    gate = p.preflight([ROOT], p.GIB)
    assert gate['preflight_pass'], gate['issues']
    assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    seal = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')
    protected = p.verify_seal(seal)
    assert protected['pass'] and protected['entry_count'] == 147
    assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
    native = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages')
    runner = native/'vllm/v1/worker/gpu/model_runner.py'
    assert p.digest(runner) == '174c93db921c23cf0396eee4764be25b2bd2d4b6a06e9fa41ce3598b884ce8ce'
    tree = ast.parse(runner.read_text())
    cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'GPUModelRunner')
    methods = {x.name for x in cls.body if isinstance(x, ast.FunctionDef)}
    assert {'execute_model','add_requests','update_requests','prepare_inputs','prepare_attn','sample_tokens'} <= methods
    modules = ['tests.test_ieee_tc_core_timing', 'tests.test_ieee_tc_core_timing_analysis',
               'tests.test_ieee_tc_control_timeline', 'tests.test_ieee_tc_decode_overlap',
               'tests.test_ieee_tc_scheduler_observation']
    with (RAW/'cpu.log').open('x') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(modules))
    tests = dict(passed=result.wasSuccessful(), count=result.testsRun,
                 errors=len(result.errors), failures=len(result.failures), skipped=len(result.skipped))
    refs = [ROOT/x for x in ('faaslora/utils/core_timing.py', 'faaslora/scheduling/vllm_ieee_scheduler.py',
        'tests/test_ieee_tc_core_timing.py', 'scripts/run_all_experiments.py',
        'configs/ieee_tc/20261012_d476_7b_full_w0.yaml', 'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
        'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md')]
    refs += [native/x for x in ('vllm/v1/worker/gpu/model_runner.py', 'vllm/v1/worker/gpu/async_utils.py',
        'vllm/v1/worker/lora_model_runner_mixin.py', 'vllm/v1/worker/gpu/lora_utils.py',
        'vllm/v1/executor/uniproc_executor.py', 'vllm/v1/engine/core.py',
        'vllm/config/vllm.py', 'vllm/utils/torch_utils.py', 'torch/cuda/memory.py')]
    save(RAW/'cpu_result.json', dict(tests=tests, protected=protected, identity=identity,
        actual_gpu_run_complete=False, performance_improvement_proved=False,
        resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')},
        refs=[dict(path=str(path), sha256=p.digest(path)) for path in refs]))
    print(json.dumps(tests))
    assert tests['passed'] and not tests['skipped'], tests

if __name__ == '__main__':
    main()
