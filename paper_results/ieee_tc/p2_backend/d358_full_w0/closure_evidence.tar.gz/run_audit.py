"""D358 post-release audit, adapted from the completed D349 run_audit.py.

Not executable during measurement: requires native release, collection closure,
the unchanged startup resource gate and the complete 4000-request journal.
Uses the existing analyzers and tests; no new performance or metric framework.
"""
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
run = raw/'7b_full_w0'
physical = run/'launch.launch/physical_deployment'
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])


def read(path):
    return json.loads(path.read_text())


def sample():
    return {key: (group/key).read_text().strip() for key in (
        'memory.peak', 'memory.events', 'memory.swap.current',
        'memory.high', 'memory.max', 'memory.swap.max', 'cgroup.events')}


before = sample()
assert before['memory.high'] == str(3*p.GIB) and before['memory.max'] == str(4*p.GIB)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(
    ['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
gate = p.preflight([ROOT], 4*p.GIB)
assert gate['preflight_pass'], gate['issues']
collected = read(raw/'collection_receipt.json')
closed = collected['identity']
assert closed['unit'].startswith('primelora-tc-aux-') and closed['unit'] != identity['unit']
cg = Path(closed['path'])
assert not p.owned_pids(cg) and p.scope_still_owned(closed)
resources = {key: (cg/key).read_text() for key in (
    'memory.peak', 'memory.events', 'memory.swap.current', 'cgroup.events')}
cleanup = p.stop_scope_identity(closed)
assert cleanup['released'] and not cleanup['hard_kill'] and not cg.exists()
with (raw/'collection_scope_cleanup.json').open('x') as handle:
    json.dump(dict(identity=closed, resources=resources, inactive=True,
                   cleanup=cleanup), handle, indent=2)

launch = read(run/'launch.json')
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert launch['service_returncode'] == launch['watchdog_returncode'] == launch['replay_returncode'] == 0
summary = read(physical/'summary.json')
terminals = [json.loads(line) for line in (physical/'request_terminals.jsonl').read_text().splitlines()]
assert summary['n_plan'] == summary['n_terminal'] == summary['n_native_contract_complete'] == len(terminals) == 4000
assert len({row['request_id'] for row in terminals}) == 4000
assert all(row['success'] and row['native_contract_matched'] for row in terminals)
assert summary['measurement_complete'] and not summary['open_lease_ids'] and summary['n_correct'] is None
source = run/('experiment_results_full_vllm_dedicated_a500_r4000_c2'
              '_tc_ieee_full_d358_7b_full_w0.json')
assert source.resolve() == Path(collected['source_path']).resolve()
assert source.stat().st_size == collected['source_bytes']
assert p.digest(source) == collected['source_sha256']
remote = read(raw/'remote_stop.json')
assert remote['all_owned_units_inactive'] and remote['download_hashes_match_remote']
evidence = [source, run/'launch.json', physical/'summary.json', physical/'request_terminals.jsonl']
evidence += [raw/name for name in (
    'remote_transfers.jsonl', 'remote_monitor.log', 'remote_stop.json',
    'local_cleanup.json', 'collection_receipt.json')]
receipt = dict(kind='d358_complete_native_w0_closure_v1',
    source_commit='205cff857d39a70fec28e77bc40baf0afc1442ae',
    n_plan=4000, n_terminal=4000, n_native_contract_complete=4000,
    n_failed_from_terminal_journal=0, n_correct=None, formal_qualification=False,
    physical_gpu_seconds_total=summary['gpu_seconds'], launch_pass=True,
    native_gpu_context_release_confirmed=True, service_path_removed=True,
    remote_cleanup=remote,
    evidence={path.name: dict(path=str(path), sha256=p.digest(path)) for path in evidence},
    caveat='Complete native-contract development replay; not arithmetic or formal G1/G2 qualification.')
with (raw/'completion_receipt.json').open('x') as handle:
    json.dump(receipt, handle, indent=2, allow_nan=False)

python = '/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python'
commands = [
    [python, '-m', 'unittest', 'tests.test_ieee_tc_timing_bound',
     'tests.test_ieee_tc_launch.MainOutcomeRetention', 'tests.test_ieee_tc_decode_overlap',
     'tests.test_ieee_tc_hit_host_analysis', 'tests.test_ieee_tc_full_control_analysis', '-q'],
    [python, '-m', 'scripts.ieee_tc.analyze_d297_full', '--campaign', 'd358'],
    [python, '-m', 'scripts.ieee_tc.check_d299_full_context', '--campaign', 'd358'],
    [python, '-m', 'scripts.ieee_tc.check_d299_full_context', '--campaign', 'd358', '--reference', 'd336'],
    [python, '-m', 'scripts.ieee_tc.check_d299_full_context', '--campaign', 'd358', '--reference', 'd349'],
]
returncodes = []
try:
    with (raw/'audit1.log').open('x') as log:
        for command in commands:
            print(json.dumps(dict(command=command)), file=log, flush=True)
            completed = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            returncodes.append(completed.returncode)
            completed.check_returncode()
finally:
    with (raw/'offline_execution_receipt.json').open('x') as handle:
        json.dump(dict(identity=identity, before=before, after=sample(), commands=commands,
            preflight=gate, returncodes=returncodes,
            pass_all=len(returncodes) == len(commands) and not any(returncodes)), handle, indent=2)
print(json.dumps(dict(returncodes=returncodes, receipt=str(raw/'offline_execution_receipt.json'))))

