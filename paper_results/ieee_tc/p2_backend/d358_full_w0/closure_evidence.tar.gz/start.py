"""Verify backed candidate, fresh resource gate, unchanged remote, then launch."""
import json
from pathlib import Path
import subprocess
import sys
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend/d358_full_validation'
backup = json.loads((raw/'backup_receipt.json').read_text())
assert backup['passed']
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote = subprocess.check_output(['git','ls-remote','faaslora_origin',
    'refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head == remote == backup['head']
for name in backup['paths']:
    assert subprocess.check_output(['git','show',head+':'+name],cwd=ROOT) == (ROOT/name).read_bytes()
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',
    'faaslora','scripts','configs/ieee_tc','tests'],cwd=ROOT,text=True).strip()
binding = json.loads((out/'preparation.json').read_text())
for ref in binding['refs'] + binding['raw_refs']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
subprocess.run(['sha256sum','-c','preparation.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
old = backup['identity']; group = Path(old['path'])
assert p.scope_still_owned(old) and not p.owned_pids(group)
stopped = p.stop_scope_identity(old)
assert stopped['released'] and not stopped['hard_kill'] and not group.exists()
gate = p.preflight([ROOT],32*p.GIB)
assert gate['preflight_pass'], gate['issues']
assert not (raw/'7b_full_w0').exists()
assert subprocess.run(['tmux','has-session','-t','tc-d358-full'],stderr=subprocess.DEVNULL).returncode != 0
with (raw/'launch_gate.json').open('x') as f:
    json.dump(dict(passed=True,head=head,remote=remote,gate=gate,previous_cleanup=stopped,
        identity=p.scope_identity(p.cg_path().name)),f,indent=2)
subprocess.run(['bash',str(raw/'start_remote.sh')],check=True)
subprocess.run([sys.executable,str(raw/'check_remote_health.py')],check=True,cwd=ROOT)
print(json.dumps(dict(ready_to_launch=True,head=head,tmux='tc-d358-full',
    disk_free_bytes=gate['filesystems'][0]['free_bytes'])))

