"""D172-derived producer encoding study, not a serving-code modification.

Retained D169 observations are transformed using CURRENT routing projections.
Historical full native graphs are reported separately; no new model workload.
"""
import csv
from collections import Counter
from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import subprocess
import time

import msgspec
import torch
from scripts.ieee_tc_preflight import verify_seal
from scripts.run_all_experiments import _encode_rpc_frame, _decode_native_rpc_frame, _RPC_FRAME_MAX_BYTES
from faaslora.experiment.instance_pool import NativeSourceSnapshot

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
PARENT = 'ba299b41cfb359e3f772c65954a5bf02b2896bef'
PLAN_SHA = '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
METRIC_SHA = '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == PARENT
assert not torch.cuda.is_initialized()
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147 and protected['plan_sha256'] == PLAN_SHA
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == METRIC_SHA
sources = ['scripts/run_all_experiments.py', 'scripts/dedicated_engine_worker.py',
           'faaslora/experiment/instance_pool.py', 'tests/test_ieee_tc_rpc_decode.py']
source_shas = {}
for name in sources:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git', 'show', 'HEAD:'+name], cwd=ROOT)
    source_shas[name] = digest(ROOT/name)


def finite_primitives(value, ancestors=None):
    """Explicit study contract; ALL traversal overhead is timed, no fallback.

    Exact builtins, string keys, finite floats. Tuple follows JSON array
    semantics. Unicode validity is checked by the encoder, not replaced.
    """
    kind = type(value)
    if value is None or kind in (str, bool, int):
        return
    if kind is float:
        if not math.isfinite(value):
            raise ValueError('nonfinite RPC number')
        return
    if kind not in (dict, list, tuple):
        raise TypeError('unsupported RPC primitive')
    if ancestors is None:
        ancestors = set()
    identity = id(value)
    if identity in ancestors:
        raise ValueError('circular RPC value')
    ancestors.add(identity)
    try:
        if kind is dict:
            for key, item in value.items():
                if type(key) is not str:
                    raise TypeError('RPC keys must be exact strings')
                finite_primitives(item, ancestors)
        else:
            for item in value:
                finite_primitives(item, ancestors)
    finally:
        ancestors.remove(identity)


def guarded_encode(value):
    finite_primitives(value)
    body = msgspec.json.encode(value)
    if len(body) > _RPC_FRAME_MAX_BYTES:
        raise ValueError('dedicated RPC frame exceeds protocol byte limit')
    return body + b'\n'


def identical(a, b):
    assert type(a) is type(b), (type(a).__name__, type(b).__name__)
    if isinstance(a, dict):
        assert list(a) == list(b)
        for key in a:
            identical(a[key], b[key])
    elif isinstance(a, list):
        assert len(a) == len(b)
        for x, y in zip(a, b):
            identical(x, y)
    elif isinstance(a, float):
        assert math.isfinite(a) and a.hex() == b.hex()
    else:
        assert a == b


def outcome(fn, value):
    try:
        wire = fn(value)
    except Exception as exc:
        return dict(encode='rejected', exception=type(exc).__name__)
    result = dict(encode='accepted', bytes=len(wire), newline=wire.endswith(b'\n'))
    try:
        _decode_native_rpc_frame(wire)
    except Exception as exc:
        result.update(native_decode='rejected', decode_exception=type(exc).__name__)
    else:
        result['native_decode'] = 'accepted'
    return result


# Existing D172 correctness fixture, not new inference input.
fixture = dict(owner_id='copy-α', epoch=2**80, leased=True,
    allocation_ids=[0, 2**53+1], rank=16, counts={'4': 2}, sources=[None],
    prompt='中文\n𝄞\t"\\', confirmed=459919.250000003,
    floats=[0., -0., 5e-324, 1.7976931348623157e308])
shared = {'epoch': 2}
valid = [fixture, {'tuple': (1, 2., None)}, {'shared': [shared, shared]},
         {'words': ['NaN', 'Infinity', 'null', '\x00', '\u2028']}]
for value in valid:
    expected = json.loads(_encode_rpc_frame(value))
    wire = guarded_encode(value)
    identical(expected, json.loads(wire))
    identical(expected, _decode_native_rpc_frame(wire))
cycle = []
cycle.append(cycle)
edges = [('nan', {'x': float('nan')}), ('infinity', {'x': float('inf')}),
         ('negative_infinity', {'x': float('-inf')}), ('bytes', {'x': b'abc'}),
         ('set', {'x': {1, 2}}), ('integer_key', {1: 'a'}),
         ('colliding_keys', {1: 'a', '1': 'b'}), ('cycle', {'x': cycle}),
         ('lone_surrogate', {'x': '\ud800'})]
semantics = [dict(case=name, original=outcome(_encode_rpc_frame, value),
                  guarded=outcome(guarded_encode, value)) for name, value in edges]
assert all(row['guarded']['encode'] == 'rejected' for row in semantics)

# The 8 MiB limit applies to actual encoded bytes. Different whitespace/Unicode
# representation changes which payloads fit; do not claim equal rejection sets.
for name, value in [('ascii_old_exact_limit', {'x': 'a'*(_RPC_FRAME_MAX_BYTES-9)}),
                    ('ascii_old_limit_plus_one', {'x': 'a'*(_RPC_FRAME_MAX_BYTES-8)}),
                    ('unicode_old_over_limit', {'x': '中'*(_RPC_FRAME_MAX_BYTES//6)}),
                    ('both_over_limit', {'x': 'a'*(_RPC_FRAME_MAX_BYTES+1)})]:
    semantics.append(dict(case=name, original=outcome(_encode_rpc_frame, value),
                          guarded=outcome(guarded_encode, value)))

source = RAW.parent/'d169_20261002/7b_probe1.json'
assert 0 < source.stat().st_size < 64*1024**2
source_sha = digest(source)
assert source_sha == 'ead0c5c81acc52c502874e9d45cfba111665f875220e23467c2e716a0d770602'
snapshots = [b['sources_before'] for b in json.loads(source.read_bytes())['warm_batches']]
assert len(snapshots) == 4
messages = []
for index, view in enumerate(snapshots):
    state = NativeSourceSnapshot.from_native(view, expected_clock_id=view['clock_id'],
        received_monotonic_s=view['captured_monotonic_s']+1)
    aid = state.sources[0].adapter_int_id
    scoped = replace(state, host_tensor_storage_bytes=None, footprint_adapter_ids=(aid,))
    for shape, payload in (
            ('historical_full_native_graph', view),
            ('current_routing_projection', state.routing_wire(device_uuid=view['device_uuid'])),
            ('current_request_projection', scoped.request_wire(device_uuid=view['device_uuid'])),
            ('current_identity_projection', state.identity_view().routing_wire(device_uuid=view['device_uuid']))):
        messages.append((index, shape, dict(ok=True, result=payload)))
messages.append((-1, 'existing_small_primitive_fixture', fixture))
rows, shapes = [], []
for index, shape, value in messages:
    original = _encode_rpc_frame(value)
    candidate = guarded_encode(value)
    expected = json.loads(original)
    identical(expected, _decode_native_rpc_frame(candidate))
    identical(expected, json.loads(candidate))
    kinds = Counter()
    def census(item):
        kinds[type(item).__name__] += 1
        if isinstance(item, dict):
            for key, sub in item.items():
                kinds['dict_keys_'+type(key).__name__] += 1
                census(sub)
        elif isinstance(item, (list, tuple)):
            for sub in item:
                census(sub)
    census(value)
    shapes.append(dict(snapshot=index, shape=shape, original_bytes=len(original),
        guarded_bytes=len(candidate), type_counts=dict(kinds), exact_decoded_tree_and_float_bits=True))
    iterations = 20 if shape == 'historical_full_native_graph' else 200
    encoders = dict(original=_encode_rpc_frame, guarded=guarded_encode)
    for repeat in range(3):
        for name in (('original', 'guarded') if repeat % 2 == 0 else ('guarded', 'original')):
            started = time.perf_counter()
            for _ in range(iterations):
                encoded = encoders[name](value)
            elapsed = time.perf_counter()-started
            identical(expected, _decode_native_rpc_frame(encoded))
            rows.append(dict(snapshot=index, shape=shape, repeat=repeat, encoder=name,
                iterations=iterations, wire_bytes=len(encoded), mean_encode_ms=elapsed/iterations*1000,
                validation_included=name == 'guarded'))
result = dict(kind='d192_retained_producer_encoding_study_v1', parent_commit=PARENT,
    source=str(source), source_sha256=source_sha, plan_sha256=PLAN_SHA,
    metric_protocol_sha256=METRIC_SHA, unchanged_sources=source_shas,
    msgspec_version=msgspec.__version__, torch_version=str(torch.__version__),
    protected_artifacts=protected, shapes=shapes, valid_fixture_count=len(valid),
    edge_semantics=semantics, measurements=rows, production_code_changed=False,
    cuda_executed=False, current_projections_of_historical_observations=True,
    caveat='Three alternating CPU component rounds, not independent workload runs or end-to-end gains; rejection sets differ.')
assert not torch.cuda.is_initialized()
with (RAW/'probe1.json').open('x') as f:
    json.dump(result, f, indent=2, allow_nan=False)
with (RAW/'probe1.csv').open('x', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
    w.writeheader()
    w.writerows(rows)
print(json.dumps(dict(status='PASS', shapes=len(shapes), rows=len(rows),
    edge_cases=len(semantics), source_sha256=source_sha, msgspec_version=msgspec.__version__)))
