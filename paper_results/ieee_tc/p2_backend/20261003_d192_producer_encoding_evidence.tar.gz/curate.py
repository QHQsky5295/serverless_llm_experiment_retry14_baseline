"""D188-derived small-file table, evidence packaging and protection checks."""
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
from statistics import mean
import subprocess
import tarfile
from scripts.ieee_tc_preflight import verify_seal

ROOT = Path.cwd()
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend'
PREFIX = '20261003_d192_producer_encoding'
DOC = ROOT/'docs/ieee_tc/D192_PRODUCER_ENCODING_STUDY.md'
def sha(path):
    assert path.stat().st_size < 64*1024**2
    return hashlib.sha256(path.read_bytes()).hexdigest()

unit = 'primelora-d192-probe1-20261003.scope'
for prop, value in (('LoadState', 'not-found'), ('InvocationID', ''), ('ControlGroup', '')):
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p',prop,'--value'],text=True).strip() == value
assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','ba299b41cfb359e3f772c65954a5bf02b2896bef','--','faaslora','scripts','tests','configs/ieee_tc'],text=True).strip()
assert 'InvocationID=1032ef3910434c38a2c299eef201b087' in (RAW/'probe1_scope.txt').read_text()
assert 'Exit status: 0' in (RAW/'probe1_time.txt').read_text()
events = dict(line.split() for line in (RAW/'probe1_memory_events.txt').read_text().splitlines())
assert all(int(v) == 0 for v in events.values())
assert (RAW/'probe1_swap.txt').read_text().strip() == '0'
assert sha(RAW/'probe1.json') == '329dc91e3266a7d3f1fdad4a0bf765af4ec36e4836901004528fb4be6899eb4c'
probe = json.loads((RAW/'probe1.json').read_text())
assert probe['production_code_changed'] is False and probe['cuda_executed'] is False
assert sha(Path(probe['source'])) == probe['source_sha256']
for name, digest in probe['unchanged_sources'].items():
    assert sha(ROOT/name) == digest
protected = verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
assert protected == probe['protected_artifacts']
assert protected['plan_sha256'] == probe['plan_sha256']
assert sha(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == probe['metric_protocol_sha256']
assert probe['msgspec_version'] == '0.21.1'
assert len(probe['shapes']) == 17 and len(probe['measurements']) == 102
assert len(probe['edge_semantics']) == 13 and probe['valid_fixture_count'] == 4
groups = []
table = ['# D192 producer encoding component table', '',
    'Three alternating CPU component rounds, not independent serving runs. Guarded includes all validation.',
    'Rejected candidate: no serving change or corresponding full replay. Negative reductions are regressions.', '',
    '| 快照 | 消息形态 | 原 bytes | 原型 bytes | 原 ms | 校验＋原型 ms | 下降比例 |',
    '|---:|---|---:|---:|---:|---:|---:|']
document = DOC.read_text()
for shape in sorted(probe['shapes'],key=lambda s:(s['snapshot'],s['shape'])):
    assert shape['exact_decoded_tree_and_float_bits'] is True
    rows = [r for r in probe['measurements'] if (r['snapshot'],r['shape']) == (shape['snapshot'],shape['shape'])]
    assert len(rows) == 6
    timings = {}
    for name in ('original','guarded'):
        selected = [r for r in rows if r['encoder'] == name]
        assert len(selected) == 3 and sorted(r['repeat'] for r in selected) == [0,1,2]
        assert all(r['wire_bytes'] == shape[name+'_bytes'] for r in selected)
        assert all(r['validation_included'] == (name == 'guarded') for r in selected)
        assert all(r['iterations'] == (20 if shape['shape'] == 'historical_full_native_graph' else 200) for r in selected)
        timings[name] = mean(r['mean_encode_ms'] for r in selected)
    reduction = (timings['original']-timings['guarded'])/timings['original']
    group = dict(snapshot=shape['snapshot'],shape=shape['shape'],
        original_bytes=shape['original_bytes'],guarded_bytes=shape['guarded_bytes'],
        original_ms=timings['original'],guarded_ms=timings['guarded'],reduction_fraction=reduction)
    groups.append(group)
    line = (f"| {group['snapshot']} | {group['shape']} | {group['original_bytes']} | "
        f"{group['guarded_bytes']} | {group['original_ms']:.6f} | {group['guarded_ms']:.6f} | {reduction*100:.3f}% |")
    assert line in document, line
    table.append(line)
assert all(g['reduction_fraction'] < 0 for g in groups if g['shape'] == 'historical_full_native_graph')
with (OUT/(PREFIX+'.csv')).open('x',newline='') as f:
    writer = csv.DictWriter(f,fieldnames=list(groups[0]),lineterminator='\n')
    writer.writeheader()
    writer.writerows(groups)
with (OUT/(PREFIX+'_table.md')).open('x') as f:
    f.write('\n'.join(table)+'\n')
members = [RAW/name for name in ('probe.py','run_cpu.sh','probe1.json','probe1.csv','probe1.log',
    'probe1_scope.txt','probe1_time.txt','probe1_memory_events.txt','probe1_swap.txt',
    'probe1_protected_before.json','probe1_protected_after.json','curate.py','run_curate.sh','check_staged.py')]
members.append(DOC)
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert len(secret) > 16
for path in members:
    data = path.read_bytes()
    assert secret not in data
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in data.splitlines())
    assert not re.search(rb'\b(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}',data)
    if path.suffix == '.py':
        ast.parse(data,filename=str(path))
    if path.suffix == '.sh':
        subprocess.run(['bash','-n',str(path)],check=True)
source_shas = {str(p):sha(p) for p in members}
bundle = OUT/(PREFIX+'_evidence.tar.gz')
with bundle.open('xb') as output, tarfile.open(fileobj=output,mode='w:gz') as archive:
    for path in members:
        archive.add(path,arcname=path.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers()) == len(members)
    for path in members:
        assert hashlib.sha256(archive.extractfile(path.name).read()).hexdigest() == source_shas[str(path)]
with (OUT/(PREFIX+'_evidence.sha256')).open('x') as f:
    f.write(sha(bundle)+'  '+bundle.name+'\n')
result = dict(kind='d192_producer_encoding_study_curated_v1',
    status='reject_guarded_encoder_prototype_no_full_replay',probe=probe,groups=groups,
    source_sha256=source_shas,protected_after=protected,probe_scope_absent=True,
    probe_memory_events=events,probe_swap_bytes=0,
    plot_decision='Complete component table; no serving-performance figure or seed CI.',
    production_changed=False,gpu_execution=False,remote_operation=False,
    evidence_bundle=dict(path=str(bundle),sha256=sha(bundle),bytes=bundle.stat().st_size,members=len(members)),
    output_csv_sha256=sha(OUT/(PREFIX+'.csv')),table_sha256=sha(OUT/(PREFIX+'_table.md')))
with (OUT/(PREFIX+'.json')).open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(status='PASS',groups=len(groups),protected=147,
    curated_sha256=sha(OUT/(PREFIX+'.json')),evidence_bundle=result['evidence_bundle']),indent=2))
