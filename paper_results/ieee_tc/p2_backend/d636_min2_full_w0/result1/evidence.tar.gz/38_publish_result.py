"""Reuse D621's guarded evidence publication for the completed D636 W0.

No production, metric, input or historic result is rewritten. The offline
comparison is separate and closed before publication begins.
"""
import ast
import hashlib
from pathlib import Path
import sys

SOURCE = Path(__file__).resolve().parent.parent/'d621_20261017/publish_result.py'
data = SOURCE.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'e3541b4f4a813ac1167fb5bf7cea179c42750746f3124134a024f644859067f1'
code = data.decode()

def replace(old, new):
    global code
    assert code.count(old) == 1, (old, code.count(old))
    code = code.replace(old, new)

replace('d621_device_domain_full_w2/result1', 'd636_min2_full_w0/result1')
replace("RAW/'publication_identity.json'", "RAW/'publication2_identity.json'")
replace("RAW/'publication_receipt.json'", "RAW/'publication2_receipt.json'")
replace("assert git('rev-parse','HEAD')=='c2289327aeb3dc6cd086dfce2455ab2fb99924e7'",
        "assert git('rev-parse','HEAD')=='30ec27aad193bc3b0c672f54a4e609f597fec3fe'")
replace("assert not git('diff','--cached','--name-only')", """gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
save(RAW/'publication_resource_gate.json',gate)
assert not git('diff','--cached','--name-only')""")
replace("assert read(RAW/'analysis_receipt.json')['passed']",
        "assert read(RAW/'analysis2_receipt.json')['passed']")
replace("for name in ('qualification','backup','start','analysis'):",
        "for name in ('qualification','backup','start','analysis','collection','analysis2','publication','comparison'):")
begin = code.index("old_path=RAW.parent/'d615_20261017/actual_qualification.json'")
end = code.index("cap=read(RAW/'realized_replica_cap.json')", begin)
code = code[:begin] + """old_path=RAW.parent/'d624_20261017/actual_qualification.json'
reference_path=ROOT/'paper_results/ieee_tc/main_comparison/d593_complete_7b/metrics.csv'
comparison=read(RAW/'comparison_d624.json')
assert comparison['passed'] and comparison['matched_native_contract_count']==4000
assert comparison['candidate_audit']['sha256']==p.digest(RAW/'actual_qualification.json')
assert comparison['reference_audit']['sha256']==p.digest(old_path)
assert comparison['new_stats']==audit['stats']
assert not comparison['ranking_eligible'] and not comparison['cross_version_W1_W2_reuse_qualified']
fallback=read(RAW/'receipt_audit.json')
assert not fallback['differences'] and not fallback['unresolved']
assert p.digest(Path(fallback['source']['path']))==fallback['source']['sha256']
""" + code[end:]
replace("run=RAW/'7b_device_domain_full_w2'", "run=RAW/'7b_min2_full_w0'")
replace("ROOT/'docs/ieee_tc/D621_DEVICE_DOMAIN_FULL_W2.md',", """ROOT/'docs/ieee_tc/D636_PINNED_FALLBACK_FULL_W0.md',
    ROOT/'docs/ieee_tc/D635_PINNED_FALLBACK_OBSERVATION.md',
    ROOT/'docs/ieee_tc/NUMERICAL_REPRODUCIBILITY_BOUNDARY_20261017.md',
    RAW.parent/'d621_20261017/publish_result.py',
    RAW.parent/'d624_20261017/analyze.py', RAW.parent/'d624_20261017/analyze_prefix.py',
    RAW.parent/'d635_20261017/analyze.py',
    ROOT/'paper_results/ieee_tc/p2_backend/d635_pinned_fallback_observation/qualification.json',
    ROOT/'paper_results/ieee_tc/p2_backend/d634_min2_full_w0/failure1/summary.json',
    ROOT/'configs/ieee_tc/20261017_d624_7b_device_domain_full_w0.yaml',
    ROOT/'configs/ieee_tc/20261017_d636_7b_min2_full_w0.yaml',""")
replace("names=['docs/ieee_tc/D621_DEVICE_DOMAIN_FULL_W2.md','docs/ieee_tc/EXECUTION_STATUS.md']",
        "names=['docs/ieee_tc/D636_PINNED_FALLBACK_FULL_W0.md','docs/ieee_tc/EXECUTION_STATUS.md']")
replace('tc: retain W2 joint-SLO shortfall and complete lifecycle evidence (D621)',
        'tc: seal complete W0 after held-fallback repair with output audit (D636)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D621 publication source SHA and D636 adaptation/AST verified; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code, str(SOURCE), 'exec'), dict(__file__=__file__, __name__='d636_publication'))
else:
    raise SystemExit('expected no arguments or --check-only')
