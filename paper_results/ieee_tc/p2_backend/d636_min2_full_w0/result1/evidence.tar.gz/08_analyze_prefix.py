"""Reuse the sealed D624 W0 audit without changing measurement rules."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d624_20261017/analyze_prefix.py')
assert hashlib.sha256(source.read_bytes()).hexdigest() == '589d402435f76a3a4188bccc4f5280dab1840c61c273e5f498bdf06d94cad872'
code = source.read_text()
for old, new in (
    ('7b_device_domain_full_w0', '7b_min2_full_w0'),
    ('d624_actual_initial_control_full4000_qualification_v1', 'd636_min2_full4000_w0_qualification_v1'),
):
    assert code.count(old) == 1, old
    code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
