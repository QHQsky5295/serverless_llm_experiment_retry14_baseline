"""Reuse exact-owned empty scope closure for this offline comparison."""
import ast
import hashlib
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')
data = source.read_bytes()
code = data.decode()
old = "'publication','publication2')"
assert code.count(old) == 1
code = code.replace(old, "'publication','publication2','comparison')")
ast.parse(code)
exec(compile(code, str(source), 'exec'))
