"""Reuse D632/D633 request projection checks for the two complete W0 runs.

Offline only. Preserve code/config differences and unknown numerical correctness.
"""
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import ijson
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'comparison_identity.json', identity)
cg = Path(identity['path'])
assert (cg/'memory.high').read_text().strip() == str(3*p.GIB)
assert (cg/'memory.max').read_text().strip() == str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
gate = p.preflight([ROOT], 16*1024*1024)
assert gate['preflight_pass'], gate['issues']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
old_path = RAW.parent/'d624_20261017/actual_qualification.json'
old, new = read(old_path), read(RAW/'actual_qualification.json')
assert old['passed'] and new['passed']
assert old['workload_identity'] == new['workload_identity']
assert old['protocol_bound_count'] == new['protocol_bound_count'] == 4000
assert old['native_tokens'] == new['native_tokens'] == 458224
assert old['stats']['n_correct'] is new['stats']['n_correct'] is None
sealed = ROOT/'paper_results/ieee_tc/p2_backend/d624_device_domain_full_w0/result1/summary.json'
assert read(sealed)['audit'] == old

def projection(audit):
    path = Path(audit['evidence']['source'])
    assert p.digest(path) == audit['evidence']['source_sha256']
    rows = {}
    with path.open('rb') as stream:
        for row in ijson.items(stream, 'detailed_results.tc_ieee_full.requests.item', use_float=True):
            rid = row['request_id']
            assert rid not in rows
            rows[rid] = dict(request_id=rid, adapter_id=row['adapter_id'],
                prompt_sha256=row['canonical_prompt_sha256'],
                target=row['requested_completion_tokens'],
                generation_contract=row['generation_contract'],
                token_source=row['completion_token_source'],
                arrival_s=row['scheduled_arrival_offset_s'],
                prompt_tokens=row['native_token_timing']['actual_prompt_tokens'],
                output_sha256=row['completion_token_ids_sha256'])
    assert len(rows) == 4000
    return rows

parent, candidate = projection(old), projection(new)
assert parent.keys() == candidate.keys()
changed = []
for rid, row in candidate.items():
    previous = parent[rid]
    for key in row:
        if key == 'output_sha256':
            continue
        if key == 'arrival_s':
            assert abs(row[key]-previous[key]) < 1e-9
        else:
            assert row[key] == previous[key], (rid, key)
    if row['output_sha256'] != previous['output_sha256']:
        changed.append(rid)
save(RAW/'reference_contract_projection.json', list(parent.values()))

configs = [ROOT/'configs/ieee_tc'/name for name in (
    '20261017_d624_7b_device_domain_full_w0.yaml',
    '20261017_d636_7b_min2_full_w0.yaml')]
normalized = []
for path in configs:
    value = yaml.safe_load(path.read_text())
    for section, key in (('experiment', 'output_dir'), ('storage', 'nvme_cache_dir'),
                         ('storage', 'host_cache_dir')):
        del value[section][key]
    normalized.append(value)

def differences(left, right, prefix=()):
    assert type(left) == type(right), prefix
    if isinstance(left, dict):
        assert left.keys() == right.keys(), prefix
        return [change for key in left for change in differences(left[key], right[key], prefix+(key,))]
    return [] if left == right else [dict(path=list(prefix), reference=left, candidate=right)]

changes = differences(*normalized)
assert len(changes) == 1 and changes[0]['path'][-1] == 'min_instances'
assert changes[0]['reference'] == 1 and changes[0]['candidate'] == 2
old_binding, binding = read(old_path.parent/'qualification.json'), read(RAW/'qualification.json')
code_refs = []
for relative in ('scripts/run_all_experiments.py', 'faaslora/coordination/autoscaler.py',
                 'faaslora/cpu_frontend.py', 'faaslora/memory/residency_manager.py'):
    path = ROOT/relative
    a, b = old_binding['refs'][str(path)], binding['refs'][str(path)]
    assert b == p.digest(path)
    code_refs.append(dict(path=str(path), reference_sha256=a, candidate_sha256=b, equal=a == b))
assert [row['path'] for row in code_refs if not row['equal']] == [str(ROOT/'scripts/run_all_experiments.py')]
minimum = read(RAW/'minimum_two_evidence.json')
assert minimum['passed'] and minimum['initial_activations'] == 2
fallback = read(RAW/'receipt_audit.json')
assert not fallback['differences'] and not fallback['unresolved']
baseline_path = ROOT/'paper_results/ieee_tc/main_comparison/d593_complete_7b/metrics.csv'
assert p.digest(baseline_path) == '0e591949eaeb99e9255fbe2d6480a3070bb75b658ae3f5584daf2174cb66212f'
baselines = [row for row in csv.DictReader(baseline_path.read_text().splitlines())
             if row['workload'] == 'W0' and row['system'] != 'PrimeLoRA']
assert {r['system'] for r in baselines} == {'vLLM', 'S-LoRA', 'ServerlessLLM', 'HydraServe', 'Loquetier'}
comparison = dict(passed=True, reference_run='D624', candidate_run='D636', workload='W0',
    reference_audit=dict(path=str(old_path), sha256=p.digest(old_path)),
    candidate_audit=dict(path=str(RAW/'actual_qualification.json'), sha256=p.digest(RAW/'actual_qualification.json')),
    old_stats=old['stats'], new_stats=new['stats'],
    old_joint_count=old['common_threshold_joint_count'], new_joint_count=new['common_threshold_joint_count'],
    joint_percentage_point_delta=(new['common_threshold_joint_count']-old['common_threshold_joint_count'])/40,
    relative_improvement_lower_better={key:(old['stats'][key]-new['stats'][key])/old['stats'][key]
        for key in ('mean_ttft_ms', 'p95_ttft_ms', 'mean_tpot_ms', 'p95_tpot_ms', 'mean_e2e_ms', 'physical_gpu_seconds')},
    matched_native_contract_count=len(candidate), same_backend_output_hash_changes=len(changed),
    same_backend_changed_output_request_ids=changed,
    same_backend_numerical_difference_cause='unknown; no arithmetic equivalence or nondeterminism cause inferred',
    normalized_config_differences=changes, production_code_refs=code_refs,
    configuration_refs={str(path):p.digest(path) for path in configs},
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    stage_means_ms={'reference':old['stage_means_ms'], 'candidate':new['stage_means_ms']},
    window_gpu_seconds={'reference':old['window_gpu_seconds'], 'candidate':new['window_gpu_seconds']},
    joint95_observed=new['common_threshold_joint_count'] >= 3800,
    gpu_seconds_per_offered=new['stats']['physical_gpu_seconds']/4000,
    gpu_seconds_per_correct=None, independent_numerical_correctness='unknown', ranking_eligible=False,
    minimum_two_evidence=minimum, fallback_audit=fallback,
    whole_cache_prestate_equivalence_proved=False, single_run_variation_not_separated=True,
    causal_single_mechanism_performance_attribution=False,
    cross_version_W1_W2_reuse_qualified=False,
    all_published_W0_baselines=baselines,
    baseline_source=dict(path=str(baseline_path), sha256=p.digest(baseline_path)),
    conclusion='Complete known-workload W0 observation. Input/native generation contracts match D624, but the model minimum and held-fallback construction differ. Retain all output-hash differences and unknown numerical correctness; no isolated causal attribution, same-version W1/W2 splice, final G1/G2 qualification or optimality claim.')
save(RAW/'comparison_d624.json', comparison)
print(json.dumps(dict(passed=True, matched=len(candidate), changed_outputs=len(changed),
    joint_percentage_point_delta=comparison['joint_percentage_point_delta'],
    improvements=comparison['relative_improvement_lower_better'])))
