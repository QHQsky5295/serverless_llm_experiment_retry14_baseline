"""Reuse D624 W0 lifecycle audit and D633 minimum-two evidence checks."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d624_20261017/analyze.py')
assert hashlib.sha256(source.read_bytes()).hexdigest() == '306d0afcbdf89e49958ed065c709469be9523ebc0b56e982000cdc993491b01b'
code = source.read_text()
assert code.count('7b_device_domain_full_w0') == 2
assert code.count('d624_audit') == 1
code = code.replace('7b_device_domain_full_w0', '7b_min2_full_w0')
code = code.replace('d624_audit', 'd636_audit')
anchor = "assert initial['control_start_at']<=initial['first_ready_at']"
assert code.count(anchor) == 1
code = code.replace(anchor, anchor + '''
assert len(initial['devices']) == len(set(initial['devices'])) == 2
assert len(initial['ready_events']) == 2
initial_activations = [row for row in activations if row['category'] == 'initial']
assert len(initial_activations) == 2
assert all(row['state'] == 'runtime_ready' for row in initial_activations)
assert all(2 <= row['target_instances'] <= 3 for row in control)
assert all(2 <= row['ready_instances'] + row['pending_instances'] <= 3 for row in control)
scale_in = [row for row in control if row['action'] == 'scale_down']
assert all(row['ready_instances'] > 2 and row['pending_instances'] == 0
           and row['target_instances'] >= 2 for row in scale_in)
with (RAW/'minimum_two_evidence.json').open('x') as stream:
    json.dump(dict(passed=True,initial_devices=initial['devices'],
        initial_activations=len(initial_activations),initial_ready_events=len(initial['ready_events']),
        control_samples=len(control),configured_min_instances=2,configured_max_instances=3,
        min_ready_plus_pending=min(row['ready_instances']+row['pending_instances'] for row in control),
        min_target=min(row['target_instances'] for row in control),
        scale_in_decisions=len(scale_in),physical_holding_independently_measured=True),stream,indent=2)
''')
exec(compile(code, str(source), 'exec'))
