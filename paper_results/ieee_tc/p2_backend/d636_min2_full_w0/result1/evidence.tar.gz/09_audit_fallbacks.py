"""Reuse D635's field-wise receipt audit for the completed D636 run."""
import hashlib
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d635_20261017/analyze.py')
assert hashlib.sha256(source.read_bytes()).hexdigest() == '825b2c594cc63072c1fd24d6592b8e6166b4a23d1af3de211e50645b1ee2ec1a'
code = source.read_text()
for old, new in (
    ("PREVIOUS = RAW.parent/'d634_20261017'", 'PREVIOUS = RAW'),
    ("save('analysis_identity.json', identity)", "save('publication_identity.json', identity)"),
    ("failure = json.loads((PREVIOUS/'failure_analysis.json').read_text())", "failure = json.loads((PREVIOUS/'actual_qualification.json').read_text())\nassert failure['passed'] and failure['fixed_workload_complete4000']"),
    ("source_failure_sha256=p.digest(PREVIOUS/'failure_analysis.json')", "source_audit_sha256=p.digest(PREVIOUS/'actual_qualification.json')"),
    ("print(json.dumps(dict(counts=dict(counts), difference_count=len(differences),", "assert not differences and not unresolved\nprint(json.dumps(dict(counts=dict(counts), difference_count=len(differences),"),
):
    assert code.count(old) == 1, old
    code = code.replace(old, new)
exec(compile(code, str(source), 'exec'))
