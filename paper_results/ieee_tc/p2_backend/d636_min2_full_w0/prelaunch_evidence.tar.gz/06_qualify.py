"""Reuse D634 full-W0 qualification with D635's tested receipt repair."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d634_20261017/qualify.py')
code=source.read_text().replace('d634','d636').replace('D634','D636')
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='1ef5e5f58d4db141395e8a7acac812779c4af35f'",
        "assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='15aa23e2283ba5f469937b5c4aaab447ddbe7b49'")
replace("parent=RAW.parent/'d633_20261017'", "parent=RAW.parent/'d634_20261017'")
replace("previous=RAW.parent/'d631_20261017'", "previous=RAW.parent/'d635_20261017'")
start=code.index('# Reuse completed');end=code.index('gate=p.preflight',start)
code=code[:start]+'''# Only the held-confirmation construction changed since the failed run.
changed={production,ROOT/'tests/test_ieee_tc_transfer_pressure.py'}
for path,sha in {**old['refs'],**old['preserved']}.items():
    if Path(path) not in changed|{shell}:assert p.digest(Path(path))==sha,path
reg=read(previous/'qualification2_receipt.json')
assert reg['returncode']==0 and reg['returncodes']==[0,0,0]
test_sources=reg['sources']
for path,sha in test_sources.items():assert p.digest(Path(path))==sha,path
assert p.digest(previous/'qualification2.log')==reg['log_sha256']
import re
assert list(map(int,re.findall(r'Ran (\\d+) tests?',(previous/'qualification2.log').read_text())))==[180,144,215]
assert old['control_tests_run']==0 and old['reused_control_tests']==32
assert old['three_replica_checks']['lower_bound']==2 and old['three_replica_checks']['upper_bound']==3
phases=('qualification','backup','start','analysis','publication')
for base,closed_phases in ((parent,phases),(previous,('analysis','qualification','analysis2','start','qualification2','backup'))):
    for phase in closed_phases:
        closed=read(base/(phase+'_closure.json'))
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists()
local=read(parent/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
assert read(parent/'remote_stop.json')['all_owned_units_inactive']
auditpath=ROOT/'paper_results/ieee_tc/p2_backend/d634_min2_full_w0/failure1/summary.json'
failed=read(parent/'failure_analysis.json')
assert failed['passed'] and not failed['full_performance_complete'] and failed['n_terminal']==774
assert read(previous/'backup_receipt.json')['head']=='15aa23e2283ba5f469937b5c4aaab447ddbe7b49'
''' + code[end:]
replace("ROOT/'configs/ieee_tc/20261017_d633_7b_min2_full_w1.yaml'", "ROOT/'configs/ieee_tc/20261017_d634_7b_min2_full_w0.yaml'")
start=code.index('refs=[*helpers');end=code.index("subprocess.run(['git','diff','--check']",start)
code=code[:start]+'''refs=[*helpers,*paths,parent/'qualification.json',auditpath,oldw0path,buildpath,
    parent/'failure_analysis.json',parent/'local_cleanup.json',parent/'remote_stop.json',
    previous/'qualification2_receipt.json',previous/'qualification2.log',previous/'receipt_audit.json',
    previous/'backup_receipt.json',previous/'backup_closure.json',
    RAW.parent/'d624_20261017/qualify.py',RAW.parent/'d550_20261015/close.py',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
refs += [parent/(phase+'_closure.json') for phase in phases]
refs += [Path(path) for path in old['refs'] if Path(path) not in changed|{shell}]
refs += list(map(Path,test_sources))
''' + code[end:]
replace('reused_cpu_regression_tests=458','reused_cpu_regression_tests=539')
replace('reused_regression=458','reused_regression=539')
replace('configuration_changes={},', "configuration_changes={},correctness_repair_commit='15aa23e2283ba5f469937b5c4aaab447ddbe7b49',")
ast.parse(code)
exec(compile(code,str(source),'exec'))
