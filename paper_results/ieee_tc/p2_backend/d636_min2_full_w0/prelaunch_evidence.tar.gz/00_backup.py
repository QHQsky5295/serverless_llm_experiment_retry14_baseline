"""Reuse D634 explicit prelaunch checkpoint for the same model point after D635."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d634_20261017/backup.py')
code=source.read_text().replace('d634','d636').replace('D634','D636')
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("previous=read(RAW.parent/'d633_20261017/publication3_receipt.json')", "previous=read(RAW.parent/'d635_20261017/backup_receipt.json')")
code=code.replace('==458','==539').replace('reused_cpu_regression_tests=458','reused_cpu_regression_tests=539').replace('candidate_regression=458','candidate_regression=539')
replace('no_production_code_change_since_d631=True','no_production_code_change_since_d635=True')
replace("paths=['docs/ieee_tc/D633_MINIMUM_TWO_REPLICA_FULL_W1.md','docs/ieee_tc/D636_MINIMUM_TWO_REPLICA_FULL_W0.md'", "paths=['docs/ieee_tc/D636_PINNED_FALLBACK_FULL_W0.md'")
replace('tc: bind unchanged minimum-two replica point to full W0 (D636)', 'tc: qualify full W0 after held-fallback correctness repair (D636)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
