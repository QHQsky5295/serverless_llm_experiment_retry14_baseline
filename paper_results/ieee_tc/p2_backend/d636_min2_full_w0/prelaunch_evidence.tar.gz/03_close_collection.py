"""Reuse exact-owned closure for this run's actual collection receipt."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d629_20261017/close_collection.py')
exec(compile(source.read_text(), str(source), 'exec'))
