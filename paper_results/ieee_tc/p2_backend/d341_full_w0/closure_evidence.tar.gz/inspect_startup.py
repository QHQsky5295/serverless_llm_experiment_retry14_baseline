"""Reuse D337 retained-log startup inspection with D340 native witnesses."""
import gc
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from statistics import mean

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.plot_d290_diagnostic import audit_run
from scripts.ieee_tc.analyze_d298_smoke import prebuild_policy_witness
raw = Path(__file__).resolve().parent
out = ROOT/'paper_results/ieee_tc/p2_backend/d341_full_w0'
run = raw/'7b_full_w0'
receipt = json.loads((raw/'offline_execution_receipt.json').read_text())
old = receipt['identity']
assert receipt['pass_all'] and p.scope_still_owned(old)
assert not p.owned_pids(Path(old['path']))
resources = {k:(Path(old['path'])/k).read_text() for k in
    ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
subprocess.run(['systemctl','--user','stop',old['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',old['unit'],
    '-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'analysis_cleanup.json').open('x') as f:
    json.dump(dict(identity=old,resources=resources,inactive=True),f,indent=2)
unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])
assert (group/'memory.max').read_text().strip() == str(4*1024**3)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
source = next(run.glob('experiment_results*.json'))
assert p.digest(source) == '9f87d2e10ac42d08717d40a7fbafe725c16916eb4e7d34aa70cee177fd39b664'
_, evidence, requests = audit_run(source)
assert len(requests) == 4000
pid_replicas = {}
for row in requests:
    pid = row['gpu_reference_evidence']['receipt']['worker_pid']
    pid_replicas.setdefault(pid,set()).add(row['instance_id'])
assert all(len(v) == 1 for v in pid_replicas.values())
del requests
gc.collect()
physical = run/'launch.launch/physical_deployment'
deployment = json.loads((physical/'deployment.json').read_text())
query = 'fromstream(2|truncate_stream(inputs | select(.[0][:2] == ["mechanism_events","_ieee_activations"])))'
rows = json.loads(subprocess.check_output(['jq','-cn','--stream',query,str(physical/'main_outcome.json')]))
activations = {}
for a in rows:
    assert a['activation_id'] == a['target_replica'] and a['activation_id'] not in activations
    assert a['clock_id'] == deployment['clock_id'] and a['engine_ready_at'] >= a['trigger_at']
    assert a['category'] in ('initial','natural_scaleout','controlled')
    activations[a['activation_id']] = a
service = run/'launch.launch/service.log'
archives = list(dict.fromkeys(re.findall(r'preserved dedicated worker workdir: (.+)', service.read_text())))
assert archives
sources = [source, service, physical/'deployment.json', physical/'main_outcome.json',
    ROOT/'scripts/ieee_tc/analyze_d298_smoke.py', Path(__file__)]
by_pid, duplicates = {}, []
for archive in archives:
    directory = Path(archive)
    log = directory/'worker.log'
    body = log.read_text()
    core = re.findall(r'EngineCore pid=(\d+)\) INFO .* Initializing a V1 LLM engine',body)
    assert len(core) == 1
    pid = int(core[0])
    witness = prebuild_policy_witness(body)
    replica = next(iter(pid_replicas[pid])) if pid in pid_replicas else None
    a = activations[replica] if replica is not None else None
    def one(pattern):
        matches = re.findall(pattern,body)
        assert len(matches) == 1, (log,pattern,len(matches))
        return float(matches[0])
    item = dict(worker_pid=pid,replica=replica,category=a['category'] if a else None,
        activation_s=a['engine_ready_at']-a['trigger_at'] if a else None,
        prebuild_witness=witness,
        weight_load_s=one(r'Loading weights took ([0-9.]+) seconds'),
        model_load_s=one(r'Model loading took [0-9.]+ GiB memory and ([0-9.]+) seconds'),
        init_profile_cache_warmup_s=one(r'init engine \(profile, create kv cache, warmup model\) took ([0-9.]+) s'),
        compile_s=one(r'torch.compile took ([0-9.]+) s in total'),
        graph_capture_passes=len(re.findall(r'Graph capturing finished in',body)),
        aot_cache_loaded='Directly load AOT compilation from path' in body,
        checkpoint_prefetch='Prefetching checkpoint files into page cache finished' in body,
        inference_jit_notices=re.findall(r'Triton kernel JIT compilation during inference: ([^.\n]+)',body))
    sources.extend([log,directory/'process.json',directory/'ready.json',directory/'payload.json'])
    if pid in by_pid:
        assert item == {k:v for k,v in by_pid[pid].items() if k != 'source_log'}
        duplicates.append(str(log))
    else:
        by_pid[pid] = dict(item,source_log=str(log))
assert set(pid_replicas) <= set(by_pid)
bound = {r['replica'] for r in by_pid.values() if r['replica'] is not None}
summary = dict(kind='d341_retained_startup_witness_v1',workers=list(by_pid.values()),
    activation_count=len(activations),unbound_activation_ids=sorted(set(activations)-bound),
    served_worker_count=len(pid_replicas),duplicate_archives_checked=duplicates,
    ranges={key:dict(count=len(values),min=min(values),mean=mean(values),max=max(values))
        for key in ('activation_s','weight_load_s','model_load_s','init_profile_cache_warmup_s','compile_s')
        for values in [[r[key] for r in by_pid.values() if r[key] is not None]]},
    n_correct=None,formal_qualification=False,no_figures=True,
    caveats=['Log durations are rounded/nested; do not add model/weight/compile/init times.',
        'Activation durations use one controller clock and actual ready events.',
        'One development replay; activation populations and closed-loop trajectories can differ.',
        'An unbound unused worker does not receive a fabricated replica or activation duration.',
        'Native witness proves mechanism activation, not causal end-to-end speedup.'])
with (out/'startup_logs.json').open('x') as f:
    json.dump(summary,f,indent=2,allow_nan=False)
with (out/'startup_manifest.json').open('x') as f:
    json.dump(dict(sources=[dict(path=str(x),sha256=p.digest(x)) for x in dict.fromkeys(sources)],
        output_sha256=p.digest(out/'startup_logs.json')),f,indent=2)
with (raw/'startup_receipt.json').open('x') as f:
    json.dump(dict(identity=identity,resources={k:(group/k).read_text() for k in
        ('memory.peak','memory.events','memory.swap.current','cgroup.events')},pass_all=True),f,indent=2)
print(json.dumps(dict(ranges=summary['ranges'],workers=len(by_pid),
    unbound_activation_ids=summary['unbound_activation_ids'])),flush=True)
