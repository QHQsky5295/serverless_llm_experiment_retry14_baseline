"""Bounded offline D341 analysis using the existing complete-W0 procedure."""
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

raw = Path(__file__).resolve().parent
run = raw/'7b_full_w0'
physical = run/'launch.launch/physical_deployment'
unit = Path(Path('/proc/self/cgroup').read_text().strip().split('::')[1]).name
identity = p.scope_identity(unit)
group = Path(identity['path'])
def sample():
    return {k:(group/k).read_text().strip() for k in ['memory.peak','memory.events',
        'memory.swap.current','memory.high','memory.max','memory.swap.max','cgroup.events']}
before = sample()
assert before['memory.high'] == str(3*1024**3) and before['memory.max'] == str(4*1024**3)
assert before['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed = p.scope_identity('primelora-tc-aux-84ab5dc7b35f4ebf96a0dd74a5c341c1.scope')
assert closed['invocation_id'] == 'd717aed1b00941578f67d2994169dc95'
cg = Path(closed['path'])
assert not p.owned_pids(cg) and p.scope_still_owned(closed)
resources = {k:(cg/k).read_text() for k in ['memory.peak','memory.events','memory.swap.current','cgroup.events']}
subprocess.run(['systemctl','--user','stop',closed['unit']],check=True)
assert subprocess.check_output(['systemctl','--user','show',closed['unit'],'-p','ActiveState','--value'],text=True).strip() == 'inactive'
with (raw/'collection_scope_cleanup.json').open('x') as f:
    json.dump(dict(identity=closed,resources=resources,inactive=True),f,indent=2)
launch = json.loads((run/'launch.json').read_text())
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
summary = json.loads((physical/'summary.json').read_text())
terminals = [json.loads(line) for line in (physical/'request_terminals.jsonl').read_text().splitlines()]
assert summary['n_plan'] == summary['n_terminal'] == summary['n_native_contract_complete'] == len(terminals) == 4000
assert len({r['request_id'] for r in terminals}) == 4000
assert all(r['success'] and r['native_contract_matched'] for r in terminals)
assert summary['measurement_complete'] and not summary['open_lease_ids'] and summary['n_correct'] is None
source = next(run.glob('experiment_results*.json'))
assert p.digest(source) == '9f87d2e10ac42d08717d40a7fbafe725c16916eb4e7d34aa70cee177fd39b664'
evidence = [source,run/'launch.json',physical/'summary.json',physical/'request_terminals.jsonl']
evidence += [raw/name for name in ['remote_transfers.jsonl','remote_monitor.log','remote_stop.json','local_cleanup.json']]
receipt = dict(kind='d341_complete_native_w0_closure_v1',
    source_commit='eea5cd2c4b4267b53d7e392d0882ac2110e33ecb',n_plan=4000,n_terminal=4000,
    n_native_contract_complete=4000,n_failed_from_terminal_journal=0,n_correct=None,
    formal_qualification=False,physical_gpu_seconds_total=summary['gpu_seconds'],
    launch_pass=True,native_gpu_context_release_confirmed=True,service_path_removed=True,
    remote_cleanup=json.loads((raw/'remote_stop.json').read_text()),
    evidence={x.name:dict(path=str(x),sha256=p.digest(x)) for x in evidence},
    caveat='Complete native-contract development replay; not arithmetic or formal G1/G2 qualification.')
with (raw/'completion_receipt.json').open('x') as f:
    json.dump(receipt,f,indent=2,allow_nan=False)
python = '/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python'
commands = [
    [python,'-m','unittest','tests.test_ieee_tc_timing_bound',
     'tests.test_ieee_tc_launch.MainOutcomeRetention','tests.test_ieee_tc_decode_overlap','-q'],
    [python,'-m','scripts.ieee_tc.analyze_d297_full','--campaign','d341'],
    [python,'-m','scripts.ieee_tc.check_d299_full_context','--campaign','d341'],
]
returncodes = []
try:
    with (raw/'audit1.log').open('x') as log:
        for command in commands:
            print(json.dumps(dict(command=command)),file=log,flush=True)
            completed = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
            returncodes.append(completed.returncode)
            completed.check_returncode()
finally:
    with (raw/'offline_execution_receipt.json').open('x') as f:
        json.dump(dict(identity=identity,before=before,after=sample(),commands=commands,
            returncodes=returncodes,pass_all=len(returncodes)==len(commands) and not any(returncodes)),f,indent=2)
print(json.dumps(dict(returncodes=returncodes,receipt=str(raw/'offline_execution_receipt.json'))))
