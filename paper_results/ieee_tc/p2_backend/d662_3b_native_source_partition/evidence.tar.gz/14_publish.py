"""Publish corrected receipt provenance using the sealed D612 checked procedure."""
import ast
import hashlib
from pathlib import Path
import sys
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d612_20261017/publish.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'a1bcd9f18e9f483fd171b8be75f6169848f0c7f00135fda2b17ff47625028cf9'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old,new)
replace('d612_w2_quality_resource_diagnosis', 'd662_3b_native_source_partition')
replace('f72091155cd3bb258651fc461db11b9113c72faf', '24a149d821e069c5d24707599af3ef687b1a281b')
replace("diagnosis=read(RAW/'diagnosis.json')", """assert p.digest(RAW/'diagnosis2.json')=='73a5ddb48cc30ca5cab1d9903549885ff57dda88157cc2d151b1778836266477'
diagnosis=read(RAW/'diagnosis2.json')
wrong=diagnosis['source_refs'].pop()
expected_script_sha='f53da33350ae35ade2a0566a2bb3caad405ff773adcba6d02f8d891d52f3207c'
assert wrong['sha256']==expected_script_sha
assert wrong['path'].endswith('/experiment_results_full_vllm_dedicated_a500_r4000_c8_tc_ieee_full_d660_3b_full_w0.json')
assert any(r['path']==wrong['path'] and r['sha256']=='d26e59fe78ef4ba4000837b07d9d62ba3a282a923d9f9a962f8a619256557c76' for r in diagnosis['source_refs'])
assert p.digest(RAW/'diagnose.py')==expected_script_sha
diagnosis['source_refs'].append(dict(path=str(RAW/'diagnose.py'),sha256=expected_script_sha))
diagnosis['source_refs'].append(dict(path=str(RAW/'diagnosis2.json'),sha256=p.digest(RAW/'diagnosis2.json')))
diagnosis['provenance_correction']=dict(previous_entry=wrong,
    corrected_path=str(RAW/'diagnose.py'),statistics_unchanged=True,
    cause='exec namespace rebound source variable to D660 data path before script-reference append')
for filename,sha in diagnosis['output_sha256'].items():assert p.digest(RAW/filename)==sha
save(RAW/'diagnosis_canonical.json',diagnosis)""")
replace("for name in ('analysis',):", "for name in ('analysis','analysis2'):")
replace("assert read(RAW/'analysis_receipt.json')['diagnosis_sha256']==p.digest(RAW/'diagnosis.json')", """assert read(RAW/'analysis_receipt.json')['diagnosis_sha256']==p.digest(RAW/'diagnosis.json')
assert read(RAW/'analysis2_receipt.json')['diagnosis_sha256']==p.digest(RAW/'diagnosis2.json')""")
replace("assert sum(x['n'] for x in diagnosis['matched_transitions'].values())==8000//2",
        "assert sum(g['all']['n'] for g in diagnosis['groups'].values())==4000")
replace("assert diagnosis['runs']['D607']['all']['joint']==3762",
        "assert sum(g['all']['joint'] for g in diagnosis['groups'].values())==3575")
replace("assert diagnosis['runs']['D611']['all']['joint']==3819", """assert diagnosis['groups']['host::native']['all']['chains_valid']==1441
assert diagnosis['groups']['gpu::native']['all']['chains_valid']==1875
assert not any(g['all']['errors'] for g in diagnosis['groups'].values())""")
replace('D612_W2_QUALITY_RESOURCE_DIAGNOSIS.md', 'D662_3B_NATIVE_SOURCE_PATH_PARTITION.md')
replace("files += [doc,RAW.parent/'d550_20261015/close.py',RAW.parent/'d607_20261017/publish_result.py']", """files += [doc,RAW.parent/'d660_20261018/close.py',RAW.parent/'d612_20261017/publish.py',
    RAW.parent/'d661_20261018/publication_closure.json',RAW/'analysis1.log',RAW/'analysis2.log']""")
replace('assert len(data)<8*1024*1024', 'assert len(data)<16*1024*1024')
replace('d612_reused_parent_closed_log_diagnosis_v1', 'd662_retained_native_source_path_partition_v2')
replace('tc: preserve post-SLO resource gap diagnosis without another replay (D612)',
        'tc: isolate 3B native HOST and GPU source-path waiting from retained receipts (D662)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('Sealed D612 publication adaptation AST passed; no write/commit.')
elif not sys.argv[1:]:
    exec(compile(code,str(source),'exec'))
else:
    raise SystemExit('expected no arguments or --check-only')
