#!/usr/bin/env bash
set -euo pipefail
phase=$1
identity=$2
case "$phase" in red|green|regression|verify) ;; *) exit 2;; esac
[[ "$identity" =~ ^[a-f0-9]{32}$ ]]
date -Is
unit="primelora-d146-${phase}-20261001.scope"
test "$(systemctl --user show "$unit" -p InvocationID --value)" = "$identity"
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = "/user.slice/user-1001.slice/user@1001.service/app.slice/$unit"
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
