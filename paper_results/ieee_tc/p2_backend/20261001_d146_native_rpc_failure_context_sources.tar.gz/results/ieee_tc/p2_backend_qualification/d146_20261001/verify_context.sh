#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d146_20261001
unit=primelora-d146-verify-20261001.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/verify_scope.txt"
export PYTHONPATH="$PWD" PYTHONDONTWRITEBYTECODE=1
exec /usr/bin/time -v -o "$raw/verify_time.txt" /usr/bin/python3 "$raw/verify_context.py" > "$raw/verify.log" 2>&1
