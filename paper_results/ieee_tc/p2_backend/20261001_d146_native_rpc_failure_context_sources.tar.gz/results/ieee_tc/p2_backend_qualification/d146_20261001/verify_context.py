"""D144's source/test/cleanup/protected/bundle checks, reused for D146."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d146_20261001'
out = root/'paper_results/ieee_tc/p2_backend'
parent = 'd0cfbf31dc70b9e50c21cab8e38e8644ef47c101'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == parent
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
changed = {'scripts/run_all_experiments.py', 'tests/test_ieee_tc_native_retirement.py'}
sources = json.loads((root/'results/ieee_tc/p2_backend_qualification/d145_20261001/prelaunch_verification.json').read_text())['source_sha256']
for name, sha in sources.items():
    path = root/name
    if path in {root/p for p in changed}:
        relative = path.relative_to(root)
        assert hashlib.sha256(subprocess.check_output(['git','show',f'{parent}:{relative}'])).hexdigest() == sha, name
    else:
        assert digest(path) == sha, name
for phase in ('green','regression'):
    subprocess.run(['sha256sum','-c',str(raw/f'{phase}_sources.sha256')],check=True)
for line in (raw/'red_sources.sha256').read_text().splitlines():
    sha, name = line.split(maxsplit=1)
    observed = (hashlib.sha256(subprocess.check_output(['git','show',f'{parent}:{name}'])).hexdigest()
                if name == 'scripts/run_all_experiments.py' else digest(root/name))
    assert observed == sha, name
assert 'FAILED (errors=8)' in (raw/'red.log').read_text()
assert "has no attribute 'native_rpc_failure'" in (raw/'red.log').read_text()
assert 'Ran 6 tests in 0.031s\n\nOK\n' in (raw/'green.log').read_text()
assert 'Ran 508 tests in 22.810s\n\nOK\n' in (raw/'regression.log').read_text()
cleanup = {}
for phase in ('red','green','regression'):
    unit = f'primelora-d146-{phase}-20261001.scope'
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() == 'inactive'
    events = {r.split()[0]:int(r.split()[1]) for r in (raw/f'{phase}_cleanup.txt').read_text().splitlines()
              if r.startswith(('low ','high ','max ','oom ','oom_kill ','oom_group_kill '))}
    assert len(events) == 6 and not any(events.values()), phase
    assert re.search(r'InvocationID=[a-f0-9]{32}', (raw/f'{phase}_scope.txt').read_text())
    assert f'Exit status: {1 if phase == "red" else 0}' in (raw/f'{phase}_time.txt').read_text()
    cleanup[phase] = events
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
files = [root/name for name in sorted(changed)]
files += [root/'docs/ieee_tc/D146_NATIVE_RPC_FAILURE_CONTEXT.md']
files += [raw/name for name in ('run_tests.sh','cleanup_test.sh','verify_context.py','verify_context.sh')]
for phase in ('red','green','regression'):
    files += [raw/f'{phase}{suffix}' for suffix in ('.log','_time.txt','_scope.txt','_cleanup.txt','_sources.sha256')]
prior = out/'20261001_d145_7b_full_w0_full1.json'
assert digest(prior) == '8a75bdc7f4600094f31ce92201acb6a13d9b8c3760d60665af2eb1414be7733f'
secret = (Path.home()/'.config/primelora-tc-d75/artifact.token').read_bytes().strip()
assert secret
for path in files:
    assert path.stat().st_size < 4*1024**2, path
    payload = path.read_bytes()
    assert secret not in payload, path
    assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in payload.splitlines()), path
    if path.suffix == '.py': compile(payload,str(path),'exec')
    if path.suffix == '.sh': subprocess.run(['bash','-n',str(path)],check=True)
result = dict(kind='d146_native_rpc_failure_context_qualification_v1',parent_commit=parent,
    decision='keep_failure_observability_no_performance_claim', targeted_tests=6,
    targeted_seconds=.031, regression_tests=508, regression_seconds=22.810,
    regression_command_seconds=31.22, regression_peak_rss_kib=1081892,
    cuda_executed=False,formal_performance_result=False,performance_gain_established=False,
    retry_or_timeout_changed=False,equations_changed=False,ownership_guards_changed=False,
    old_failure_cause_resolved=False, prior_evidence=dict(path=str(prior),sha256=digest(prior)),
    protected=protected, prelaunch_sources_verified=len(sources), cleanup_events=cleanup,
    source_refs=[dict(path=str(p),sha256=digest(p)) for p in files])
curated = out/'20261001_d146_native_rpc_failure_context.json'
with curated.open('x') as stream: json.dump(result,stream,indent=2,allow_nan=False)
files.append(curated)
bundle = out/'20261001_d146_native_rpc_failure_context_sources.tar.gz'
with bundle.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as archive:
        for path in files: archive.add(path,arcname=str(path.relative_to(root)),recursive=False)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(files)
    for member,path in zip(archive.getmembers(),files):
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == digest(path)
with (out/'20261001_d146_native_rpc_failure_context_sources.sha256').open('x') as stream:
    stream.write(f'{digest(bundle)}  {bundle.relative_to(root)}\n')
print(json.dumps(dict(curated_sha256=digest(curated),bundle_sha256=digest(bundle),
    bundle_bytes=bundle.stat().st_size,members=len(files),protected=147,regression_tests=508)))
