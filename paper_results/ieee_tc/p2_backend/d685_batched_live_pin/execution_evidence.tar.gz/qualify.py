"""Bounded CPU regression and tiny diagnostic library build; no serving edits."""
import ast, json, os, subprocess, sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save('qualification_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT,RAW],64*p.MIB)
save('resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
previous=RAW.parent/'d684_20261018'
closed=json.loads((previous/'publication_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
assert json.loads((previous/'remote_stop.json').read_text())['all_owned_units_inactive']
preserved={ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
 ROOT/'faaslora/memory/gpu_monitor.py':'213cc94b070a1b3e0b0b1da9decdc5d0ffe0724c36aa57a892619a5c6d6eeb32'}
for path,sha in preserved.items():assert p.digest(path)==sha
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
tests=['tests.test_ieee_tc_pin_batch_witness','tests.test_ieee_tc_preflight.LivePinQueryQualification']
with (RAW/'tests.log').open('x') as log:
    done=subprocess.run([sys.executable,'-B','-m','unittest',*tests,'-v'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
save('test_receipt.json',dict(returncode=done.returncode,log_sha256=p.digest(RAW/'tests.log')))
assert done.returncode==0
cuda=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/nvidia/cu13')
source=ROOT/'scripts/ieee_tc/native_pin_batch.cpp'
library=RAW/'native_pin_batch.so'
assert not library.exists()
command=['/usr/bin/c++','-shared','-fPIC','-O2','-std=c++17','-Wall','-Wextra','-Werror',
 '-I'+str(cuda/'include'),str(source),str(cuda/'lib/libcudart.so.13'),
 '-Wl,-rpath,'+str(cuda/'lib'),'-o',str(library)]
with (RAW/'build.log').open('x') as log:
    done=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=60)
save('build_receipt.json',dict(command=command,returncode=done.returncode,log_sha256=p.digest(RAW/'build.log')))
assert done.returncode==0
paths=[ROOT/'scripts/ieee_tc_preflight.py',ROOT/'scripts/ieee_tc/host_pin_batch_witness.py',source,
 ROOT/'tests/test_ieee_tc_pin_batch_witness.py',library,Path('/usr/bin/c++'),
 cuda/'include/cuda_runtime_api.h',cuda/'lib/libcudart.so.13',*preserved]
for path in RAW.glob('*.py'):ast.parse(path.read_text())
save('qualification.json',dict(passed=True,identity=identity,source_sha256={str(path):p.digest(path) for path in paths},
 protected=protected,preserved={str(path):sha for path,sha in preserved.items()},plan_sha256=p.check_plan(),
 production_modified=False,model_loaded=False))
print(json.dumps(dict(passed=True,library_bytes=library.stat().st_size)))
