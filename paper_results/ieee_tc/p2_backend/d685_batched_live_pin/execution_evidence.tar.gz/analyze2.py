"""Correct the analysis assumption, not the measured data; preserve failed v1."""
from pathlib import Path
source=Path(__file__).resolve().parent/'analyze.py'
text=source.read_text()
old="assert summary['candidate_faster_pairs']<10 and summary['paired_ratio_median']>1"
assert text.count(old)==1
text=text.replace(old,"summary['interpretation'] = '19/20 pairs faster but one unexplained long pause; no production acceptance'")
text=text.replace("'analysis_identity.json'", "'analysis2_identity.json'")
text=text.replace('full-inventory batched candidate slower; no prefix/full workload authorized',
                  'modest median gain with unexplained large pause and worse total time; no workload authorized')
exec(compile(text,str(source),'exec'))
