"""Resolve launch-local evidence paths; first pre-stage attempt retained."""
from pathlib import Path
source=Path(__file__).resolve().parent/'publish.py'
text=source.read_text()
old="for path,sha in launch['evidence_sha256'].items():assert p.digest(Path(path))==sha,path"
assert text.count(old)==1
text=text.replace(old,"for path,sha in launch['evidence_sha256'].items():assert p.digest(RAW/'native_launch.launch'/path)==sha,path")
text=text.replace("'publication_identity.json'", "'publication2_identity.json'")
text=text.replace("'publication_receipt.json'", "'publication2_receipt.json'")
exec(compile(text,str(source),'exec'))
