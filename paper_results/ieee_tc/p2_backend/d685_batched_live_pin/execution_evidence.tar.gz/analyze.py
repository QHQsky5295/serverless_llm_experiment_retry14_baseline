"""Seal the single preregistered microtest, including unfavorable observations."""
import json, os, statistics, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d685_batched_live_pin'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
qualification=read(RAW/'qualification.json')
for path,sha in qualification['source_sha256'].items():assert p.digest(Path(path))==sha,path
for phase in ('qualification','start'):
    closure=read(RAW/(phase+'_closure.json'))
    assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()
launch=read(RAW/'native_launch.json')
assert launch['pass'] and launch['service_path_removed']
result=read(RAW/'native_pin.json')
assert result['pass'] and result['stage']=='complete'
assert result['kind']=='native_batched_live_pin_query_d685_v1'
assert len(result['cases'])==9 and len(result['inventory_equality'])==4
assert all(row['native']==row['direct']==row['expected'] for row in result['cases'])
assert all(row['equal'] for row in result['inventory_equality'])
rows=result['measurements'];assert len(rows)==40
groups={key:[row for row in rows if row['variant']==key] for key in ('native','direct')}
assert all(len(group)==20 and {row['index'] for row in group}==set(range(20)) for group in groups.values())
paired={key:{row['index']:row['wall_ns'] for row in group} for key,group in groups.items()}
ratios=[paired['direct'][i]/paired['native'][i] for i in range(20)]
summary=dict(passed=True,kind='d685_batched_pin_single_microqualification',
 semantics_passed=True,performance_candidate_accepted=False,production_modified=False,
 reason='full-inventory batched candidate slower; no prefix/full workload authorized',
 measurements_per_variant=20,ci=False,formal_performance=False,
 wall_ms={key:dict(mean=statistics.mean(row['wall_ns'] for row in group)/1e6,
     median=statistics.median(row['wall_ns'] for row in group)/1e6,
     min=min(row['wall_ns'] for row in group)/1e6,max=max(row['wall_ns'] for row in group)/1e6)
     for key,group in groups.items()},
 paired_ratio_median=statistics.median(ratios),candidate_faster_pairs=sum(r<1 for r in ratios),
 source_sha256=p.digest(RAW/'native_pin.json'),plan_sha256=p.check_plan(),
 production_sha256=p.digest(ROOT/'faaslora/memory/gpu_monitor.py'),
 correctness_scope='tiny actual native tensors, not full model numerical correctness',
 latest_full_3b=dict(run='D682',joint_slo=.9235,native_bound_count=4000,n_correct=None,
 physical_gpu_seconds=15896.253912474262,ranking_eligible=False))
assert summary['candidate_faster_pairs']<10 and summary['paired_ratio_median']>1
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'summary.json',summary)
save(OUT/'native_pin.json',result)
save(OUT/'qualification.json',qualification)
save(OUT/'manifest.json',dict(sources={str(path):p.digest(path) for path in [RAW/'native_pin.json',
 RAW/'native_launch.json',RAW/'qualification.json',RAW/'tests.log',RAW/'build_receipt.json',
 ROOT/'docs/ieee_tc/D462_LIVE_PIN_QUERY_QUALIFICATION.md',
 ROOT/'paper_results/ieee_tc/p2_backend/d684_3b_control_prefix1/completion/operation_detail1/inventory_summary.json']},
 no_production_change=True,no_remote_operations=True,no_new_artifacts_or_trace=True))
print(json.dumps(summary,indent=2))
