"""D124 paired ready-callback method, now testing pure CPU placement only.

Reuse the existing four-adapter owned-planning fixture; do not generate weights,
traces, remote deliveries or synthetic large physical snapshots. This is NOT a
500-adapter performance result. Production Full must include worker startup.
"""
import asyncio
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from tests.test_ieee_tc_planning_cpu import PlanningCPU
from faaslora.preloading.planning_cpu import run_planning_cpu
from faaslora.preloading.preloading_planner import copy_ieee_preparation_plan


async def main():
    fixture = PlanningCPU()
    args, runner, _ = await asyncio.to_thread(fixture.inputs)
    received = {k: v for k, v in args.items() if k != 'demand'}
    stack = runner._stack
    expected = stack.plan_ieee_owned_preparation(**received)
    selected = stack.preloading_planner.validate_ieee_execution_plan(expected)
    rows = []

    async def measure(case, method, trial):
        loop = asyncio.get_running_loop()
        callback = loop.create_future()
        start = time.perf_counter_ns()
        loop.call_soon(lambda: callback.set_result(time.perf_counter_ns()))
        if case == 'owned_epoch':
            if method == 'inline':
                value = stack.plan_ieee_owned_preparation(**received)
            else:
                value = await stack.plan_ieee_owned_preparation_async(**received)
            end = time.perf_counter_ns()
            assert value == expected
        else:
            if method == 'inline':
                plan = copy_ieee_preparation_plan(expected)
                value = (plan, stack.preloading_planner.validate_ieee_execution_plan(plan))
            else:
                value = await run_planning_cpu(stack, 'validate_execution', {'plan': expected})
            end = time.perf_counter_ns()
            assert value == (expected, selected)
        responded = await callback
        rows.append(dict(case=case, method=method, trial=trial,
            elapsed_ms=(end-start)/1e6, ready_callback_delay_ms=(responded-start)/1e6,
            callback_before_result=responded < end, exact_value_equal=True))

    try:
        await measure('owned_epoch', 'spawn_cold', -1)
        for case in ('owned_epoch', 'validate_execution'):
            for trial in range(3):
                order = ['inline', 'spawn_warm'] if trial % 2 == 0 else ['spawn_warm', 'inline']
                for method in order:
                    await measure(case, method, trial)
        summary = []
        for case in ('owned_epoch', 'validate_execution'):
            groups = {m: [r for r in rows if r['case'] == case and r['method'] == m]
                      for m in ('inline', 'spawn_warm')}
            for metric in ('elapsed_ms', 'ready_callback_delay_ms'):
                means = {m: statistics.mean(r[metric] for r in group) for m, group in groups.items()}
                summary.append(dict(case=case, metric=metric, **means,
                    relative_reduction=(means['inline']-means['spawn_warm'])/means['inline']))
        result = dict(kind='d128_pure_planning_cpu_component_v1', samples=rows, summary=summary,
            worker_events=stack._ieee_planning_cpu.events, adapter_count=4,
            source_snapshot_id=expected['source_snapshot_id'], plan_sha256=expected['plan_sha256'],
            formal_performance_result=False, full_candidate_accepted=False,
            limitations=['Four-adapter controlled fixture, not complete 500-adapter workload.',
                'Warm component times do not exclude cold process startup from production lifecycle.',
                'Three local trials are not independent workload seeds or system-level confidence intervals.',
                'Execution-time physical owners/checks are unchanged; later state may supersede a plan.'],
            source_refs=[dict(path=str(ROOT/p), sha256=hashlib.sha256((ROOT/p).read_bytes()).hexdigest())
                for p in ('faaslora/preloading/planning_cpu.py','faaslora/preloading/preloading_planner.py',
                          'faaslora/experiment/experiment_stack.py','scripts/run_all_experiments.py',
                          'tests/test_ieee_tc_planning_cpu.py','tests/test_ieee_tc_transfer_pressure.py')])
        with (Path(__file__).parent/'planning_cpu_probe.json').open('x') as stream:
            json.dump(result, stream, indent=2, allow_nan=False)
        print(json.dumps(dict(summary=summary, cold=rows[0]), indent=2))
    finally:
        worker = getattr(stack, '_ieee_planning_cpu', None)
        if worker is not None:
            await worker.close()
        await asyncio.to_thread(fixture.doCleanups)


if __name__ == '__main__':
    asyncio.run(main())
