"""Seal already-completed D328 data; no inference, figures or result recomputation."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/p2_backend/d328_current_path'
group = p.cg_path()
identity = p.scope_identity(group.name)
assert group == Path(identity['path'])
assert set(os.sched_getaffinity(0)) == {2, 3, 26, 27}
for name, value in {'memory.high': 3*1024**3, 'memory.max': 4*1024**3,
                    'memory.swap.max': 0}.items():
    assert int((group/name).read_text()) == value
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
                                   '--format=csv,noheader'], text=True).strip()
read = lambda path: json.loads(path.read_text())
refs = {}
def check_refs(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            path = Path(value['path'])
            assert p.digest(path) == value['sha256'], str(path)
            refs[str(path)] = value['sha256']
        for child in value.values():
            check_refs(child)
    elif isinstance(value, list):
        for child in value:
            check_refs(child)

files = sorted((OUT/'analysis1').rglob('*'))
files = [f for f in files if f.is_file()]
for path in files:
    if path.suffix == '.json':
        check_refs(read(path))
native = read(OUT/'analysis1/native_audit.json')
for field in ('source', 'physical_source'):
    e = native['evidence']
    key = 'source_sha256' if field == 'source' else 'physical_sha256'
    assert p.digest(Path(e[field])) == e[key]
    refs[e[field]] = e[key]
assert native['terminal_success'] == 1000 and native['terminal_failure'] == 0
assert native['numerical_n_correct'] is None and not native['formal_qualification']
assert abs(sum(native['window_gpu_seconds'].values()) - native['stats']['physical_gpu_seconds']) < 1e-6
cpu = read(RAW/'prefix1_cpu_samples.json')
check_refs(cpu)
cores = [r for r in cpu['processes'] if r['role_evidence'] == ['gpu_core']]
summary = []
for row in cores:
    count = row['main_phase_counts'].get('request_window', 0)
    top = row['request_window_nearest_project']
    # Preserve the recorded row shape as evidence; no CPU-time percentage claim.
    summary.append(dict(pid=row['pid'], business_samples=count, nearest=top))
assert len(cores) == 6
for path in (RAW/'analyze_prefix.py', RAW/'collect_prefix1_cpu.py', RAW/'curate_callers.py', Path(__file__)):
    ast.parse(path.read_text())
    refs[str(path)] = p.digest(path)
old = ROOT/'results/ieee_tc/p2_backend_qualification/d200_20261003/collect_prefix1_cpu.py'
assert (RAW/'collect_prefix1_cpu.py').read_text() == old.read_text().replace('D200', 'D328').replace('d200', 'd328')
protected = p.verify_seal(ROOT/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert protected['entry_count'] == 147 and protected['changed'] == [str(known)]
assert p.digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
locks = {
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'): '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md': '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'configs/generated/lora_manifest_1000.json': '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'}
for path, sha in locks.items():
    assert p.digest(path) == sha
    refs[str(path)] = sha
suite = unittest.defaultTestLoader.loadTestsFromNames([
    'tests.test_ieee_tc_control_timeline',
    'tests.test_ieee_tc_launch.LengthCandidateConfiguration.test_d328_observation_changes_only_exclusive_paths'])
result = unittest.TextTestRunner(verbosity=1).run(suite)
assert result.wasSuccessful()
for name in ('local_cleanup.json', 'remote_stop.json', 'analysis_resources.json', 'caller_resources.json', 'test_receipt.json'):
    refs[str(RAW/name)] = p.digest(RAW/name)
for path in (ROOT/'docs/ieee_tc/D328_CURRENT_PATH_DIAGNOSTIC.md',
             ROOT/'docs/ieee_tc/EXECUTION_STATUS.md',
             ROOT/'scripts/analyze_control_path_overhead.py',
             ROOT/'scripts/ieee_tc/plot_d290_diagnostic.py'):
    refs[str(path)] = p.digest(path)
payload = dict(kind='d328_completion_verification_v1', tests=result.testsRun, passed=True,
    identity=identity, native_contract_count=1000, numerical_n_correct=None,
    formal_qualification=False, figures_generated=False, source_refs=[dict(path=k, sha256=v) for k,v in sorted(refs.items())],
    outputs=[dict(path=str(f.relative_to(ROOT)), sha256=p.digest(f)) for f in files],
    protected=protected, core_business_samples=summary)
with (OUT/'completion_verification.json').open('x') as f:
    json.dump(payload, f, indent=2, allow_nan=False)
print(json.dumps(dict(tests=result.testsRun, source_refs=len(refs), outputs=len(files), identity=identity)))
