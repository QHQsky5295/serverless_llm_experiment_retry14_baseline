"""Close D470's owned failed pre-runtime launch, retaining its actual failure."""
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
save(RAW/'collection_identity.json',p.scope_identity(p.cg_path().name))
run=RAW/'7b_cpu_frontend_validation_100'
launch=read(run/'launch.json')
assert not launch['pass'] and launch['service_returncode']==1
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
rows=[]
for identity in (read(RAW/'launch_gate.json')['identity'],read(RAW/'service_aux_identity.json')):
    assert p.scope_still_owned(identity)
    group=Path(identity['path'])
    members={str(path):path.read_text().split() for path in group.rglob('cgroup.procs')}
    assert members and all(not pids for pids in members.values())
    rows.append(dict(identity=identity,actual_recursive_procs_empty=True,
        resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
    assert p.scope_still_owned(identity)
    subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
    assert not group.exists()
units=['primelora-artifact-tc-3b.service','primelora-artifact-tc-7b.service',
       'primelora-artifact-monitor-d470-cpuprep100.service']
identities={}
unit=None
for line in (RAW/'remote_start.log').read_text().splitlines():
    if line.startswith('Id='):unit=line[3:]
    elif line.startswith('InvocationID=') and unit in units:identities[unit]=line.split('=',1)[1]
assert set(identities)==set(units) and all(len(v)==32 for v in identities.values())
script='''set -euo pipefail
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d470-cpuprep100.service)
ids=("$1" "$2" "$3")
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
done
systemctl --user stop "${units[2]}" "${units[0]}" "${units[1]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
  systemctl --user show "$unit" -p Id -p ActiveState -p MainPID -p Result
done
test -z "$(ss -ltnH '( sport = :18080 or sport = :18081 )')"
'''
out=subprocess.run(['ssh','-o','BatchMode=yes','primelora-artifact-174','bash','-s','--',
                    *[identities[u] for u in units]],input=script,text=True,capture_output=True)
with (RAW/'failed_remote_stop.log').open('x') as f:f.write(out.stdout+out.stderr)
assert out.returncode==0 and out.stdout.count('ActiveState=inactive')==3
remote_path='/home/lab14/primelora_remote/tc/d470_20261012_cpuprep100/remote_monitor.log'
sha=subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','sha256sum',remote_path],text=True).split()[0]
subprocess.run(['scp','-q','-o','BatchMode=yes','primelora-artifact-174:'+remote_path,str(RAW/'remote_monitor.log')],check=True)
assert p.digest(RAW/'remote_monitor.log')==sha
log=(run/'launch.launch/service.log').read_text()
assert 'service profile model/configuration/context mismatch' in log
allocations=run/'launch.launch/physical_allocations'
assert not allocations.exists() or not list(allocations.glob('*.jsonl'))
result=dict(passed=True,qualification_passed=False,performance_result=False,
    failure='pre-runtime service profile model/configuration/context mismatch',
    actual_cpu_preparation_launched=False,actual_gpu_allocation_launched=False,
    launch_sha256=p.digest(run/'launch.json'),service_log_sha256=p.digest(run/'launch.launch/service.log'),
    auxiliary_closures=rows,remote_all_owned_inactive=True,remote_monitor_sha256=sha,
    source_commit=read(RAW/'launch_gate.json')['head'])
save(RAW/'failed_qualification_closure.json',result)
print(json.dumps(result))
