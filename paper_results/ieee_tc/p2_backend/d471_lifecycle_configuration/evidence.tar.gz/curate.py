"""D469 curation using existing preflight digests/seal and D468 archive contract."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import time
import urllib.request
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d471_lifecycle_configuration'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
final=read(RAW/'cpu2_result.json')
assert final['passed'] and final['tests']==571 and not(final['errors'] or final['failures'] or final['skipped'])
for ref in final['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256']
for name in ('cpu1','cpu2'):
    close=read(RAW/(name+'_closure.json'))
    assert close['actual_recursive_procs_empty'] and not Path(close['identity']['path']).exists()
config=ROOT/'configs/ieee_tc/20261012_d471_7b_cpu_frontend_validation_100.yaml'
parent_config=ROOT/'configs/ieee_tc/20261012_d464_7b_host_queue_validation_100.yaml'
current=yaml.safe_load(config.read_text().replace('d471','d464').replace('cpu_frontend','host_queue'))
# Restore only the option key changed by the mechanical path-name projection.
assert current['resource_coordination'].pop('ieee_host_queue_policy')=='fixed_uuid_host_queue_v1'
assert current==yaml.safe_load(parent_config.read_text())
subprocess.run(['bash','-n',str(ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh')],check=True)
old=read(ROOT/'paper_results/ieee_tc/p2_backend/d468_cpu_lifecycle_v2/manifest.json')
preserved={path:sha for path,sha in old['preserved'].items()
           if path!=str(ROOT/'scripts/run_all_experiments.py')}
for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
primary=[]
for name,relative in [('core_manager.py','vllm/v1/engine/utils.py'),('cuda_platform.py','vllm/platforms/cuda.py')]:
    url='https://raw.githubusercontent.com/vllm-project/vllm/v0.30.0/'+relative
    with urllib.request.urlopen(url,timeout=30) as response:data=response.read()
    path=RAW/name
    with path.open('xb') as f:f.write(data)
    primary.append(dict(path=str(path),url=url,sha256=p.digest(path),fetched_wall_s=time.time()))
save(RAW/'primary_sources.json',dict(refs=primary,web_tool='429; public official raw fetch'))
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
OUT.mkdir(exist_ok=False)
paths=[RAW/(name+suffix) for name in ('cpu1','cpu2') for suffix in
       ('_tests.txt','_result.json','_closure.json','_identity.json')]
paths += [RAW/name for name in ('check.py','curate.py','primary_sources.json','core_manager.py','cuda_platform.py')]
for name in ('cpu1_sources','cpu2_sources'):paths+=sorted((RAW/name).iterdir())
failure=RAW.with_name('d470_20261012')
paths += [failure/name for name in ('failed_qualification_closure.json','collection_closure.json','launch_gate.json','remote_start.log','failed_remote_stop.log','remote_monitor.log','close_failed.py','7b_cpu_frontend_validation_100/launch.json','7b_cpu_frontend_validation_100/launch.launch/service.log')]
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as archive:
    for path in paths:
        name=str(path.relative_to(RAW)) if path.is_relative_to(RAW) else 'd470_failure/'+path.name
        members[name]=dict(path=str(path),sha256=p.digest(path),bytes=path.stat().st_size)
        archive.add(path,arcname=name,recursive=False)
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as archive:
    assert set(archive.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==ref['sha256']
for name in ('cpu2_result.json','cpu2_closure.json','primary_sources.json'):
    with (OUT/name).open('xb') as f:f.write((RAW/name).read_bytes())
refs=final['source_refs']+[dict(path=str(path),sha256=p.digest(path)) for path in (
    config,ROOT/'tests/test_ieee_tc_launch.py',ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    ROOT/'docs/ieee_tc/D470_D471_CPU_PREPARATION_CONFIGURATION.md')]
manifest=dict(passed=True,kind='lifecycle_configuration_identity_d471',
    parent='68aef590521a3bc3acb0e33a15554871f0715554',native_qualified=False,
    production_runner_integrated=True,performance_result=False,final_cpu_tests=571,
    protected=protected,preserved=preserved,source_refs=refs,
    outputs={path.name:p.digest(path) for path in OUT.iterdir()},archive_members=members,
    configuration_check=dict(passed=True,only_policy_and_unique_paths=True,
        config=str(config),config_sha256=p.digest(config),parent_sha256=p.digest(parent_config)),
    next='D471 original100 native qualification then one new-key full W0; no repeated import microtest.')
save(OUT/'manifest.json',manifest)
save(RAW/'curation_receipt.json',dict(passed=True,manifest_sha256=p.digest(OUT/'manifest.json'),members=len(members)))
print(json.dumps(dict(passed=True,manifest_sha256=p.digest(OUT/'manifest.json'),members=len(members))))
