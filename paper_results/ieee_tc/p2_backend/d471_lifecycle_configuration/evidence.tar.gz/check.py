"""Reuse D469/D468 CPU regression with an exclusive D471 evidence root."""
from pathlib import Path
import sys
old=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d469_20261012/check.py')
namespace=dict(__file__=__file__,__name__='d471_regression')
exec(compile(old.read_text(),str(old),'exec'),namespace)
if __name__=='__main__':
    namespace['namespace'][sys.argv[1]](sys.argv[2])
