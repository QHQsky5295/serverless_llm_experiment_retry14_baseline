"""D595 explicit-path backup method for closed storage/component evidence."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
STORAGE=RAW.parent.parent/'storage_maintenance/d604_20261017'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='161fa069e004ed54622dbc5922f72ee56f624f02'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/qhq/serverless_llm_baselines',text=True).strip()=='80e08b4c6e7c2874b1b237500a00811ec06cd8c5'
for directory,name in ((STORAGE,'storage'),(RAW,'component'),(RAW,'component2')):
    closed=read(directory/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
result=read(RAW/'component_result2.json')
assert result['passed'] and result['production_source_unchanged'] and not result['formal_performance']
assert p.digest(ROOT/'faaslora/memory/residency_manager.py')==result['old_source_sha256']
assert read(STORAGE/'receipt.json')['passed']
assert p.digest(STORAGE/'storage_result.json')==read(STORAGE/'receipt.json')['result_sha256']
preserved=read(STORAGE/'prechecks.json')['preserved']
for path,sha in preserved.items():assert p.digest(Path(path))==sha
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def secret_check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
groups=[(STORAGE,ROOT/'paper_results/ieee_tc/storage/d604_closed_w2_evidence',
    ['compress.py','close.py','storage_identity.json','prechecks.json','tests.log',
     'storage_result.json','receipt.json','storage_closure.json']),
    (RAW,ROOT/'paper_results/ieee_tc/p2_backend/d605_inventory_component',
    ['compare_inventory.py','compare_inventory2.py','close.py','close2.py','publish.py',
     'component_identity.json','component_closure.json','attempt1_failure.json',
     'component2_identity.json','component2_closure.json','component2.log','component_result2.json'])]
names=['scripts/ieee_tc/compress_closed_main_outcomes.py','tests/test_ieee_tc_closed_outcome_archive.py',
       'docs/ieee_tc/D604_CLOSED_EVIDENCE_STORAGE.md','docs/ieee_tc/D605_FRESH_INVENTORY_COMPONENT_STUDY.md',
       'docs/ieee_tc/EXECUTION_STATUS.md']
for directory,out,members in groups:
    out.mkdir(parents=True,exist_ok=False)
    paths=[directory/name for name in members]
    paths.append(RAW.parent.parent/'storage_maintenance/d592_20261017/close.py')
    entries=[]
    with tarfile.open(out/'evidence.tar.gz','x:gz') as bundle:
        for index,path in enumerate(paths):
            data=path.read_bytes();secret_check(data)
            arcname=f'{index:02d}_{path.name}'
            bundle.add(path,arcname=arcname,recursive=False)
            entries.append(dict(path=str(path),archive_member=arcname,sha256=hashlib.sha256(data).hexdigest()))
    with tarfile.open(out/'evidence.tar.gz') as bundle:
        for row in entries:
            assert hashlib.sha256(bundle.extractfile(row['archive_member']).read()).hexdigest()==row['sha256']
    summary=dict(passed=True,entries=entries,archive_sha256=p.digest(out/'evidence.tar.gz'),
        protected=protected,preserved=preserved,production_serving_change=False,gpu_experiment=False)
    if directory==STORAGE:
        summary.update(storage=read(STORAGE/'storage_result.json'),tests=14)
    else:
        summary.update(component=result,first_attempt=read(RAW/'attempt1_failure.json'),
            decision='not_adopted_no_gpu_validation',
            caveat='Closed metadata-tree/tiny-fixture component observations, not adapter payload serving results.')
    save(out/'summary.json',summary)
    with (out/'result.sha256').open('x') as stream:
        for name in ('summary.json','evidence.tar.gz'):stream.write(p.digest(out/name)+'  '+name+'\n')
    subprocess.run(['sha256sum','-c','result.sha256'],cwd=out,check=True,stdout=subprocess.DEVNULL)
    names += [str((out/name).relative_to(ROOT)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names:secret_check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(names)
for name in names:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: preserve closed W2 evidence and bounded fresh-inventory prototype outcome (D604-D605)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,identity=identity,head=head,remote=remote,files=names))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
