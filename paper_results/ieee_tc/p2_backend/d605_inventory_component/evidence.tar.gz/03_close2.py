"""Use D592 exact-owned recursive-empty close for the second component attempt."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d592_20261017/close.py')
code=source.read_text().replace("('cleanup', 'storage', 'curation', 'publication')", "('component2',)")
exec(compile(code,str(source),'exec'))
