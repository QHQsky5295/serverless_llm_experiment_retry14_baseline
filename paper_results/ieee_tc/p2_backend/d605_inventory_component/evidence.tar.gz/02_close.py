"""Actual identity and recursive-empty close, adapted from D592."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d592_20261017/close.py')
code=source.read_text().replace("('cleanup', 'storage', 'curation', 'publication')",
                              "('component', 'publication')")
exec(compile(code,str(source),'exec'))
