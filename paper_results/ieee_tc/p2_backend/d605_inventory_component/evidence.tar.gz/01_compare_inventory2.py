"""Same prototype; explicit ordinary-file metadata-tree component boundary."""
import contextlib
from pathlib import Path
raw=Path(__file__).resolve().parent
source=raw/'compare_inventory.py'
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("'component_identity.json'", "'component2_identity.json'")
replace("'component_result.json'", "'component_result2.json'")
replace("pool = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')",
        "pool = Path('/tmp/tc-d557-7bv/remote_artifacts')")
replace("real_pool=str(pool),pool_inventory_output_sha256=", 
        "real_pool=str(pool),tree_semantics='closed_vllm_transfer_metadata_not_adapter_payload',\n    full_500_adapter_inventory_test=False,pool_inventory_output_sha256=")
replace("assert pool.resolve()==pool and pool.is_dir()", """assert pool.resolve()==pool and pool.is_dir()
prior=json.loads((RAW/'component_closure.json').read_text())
assert prior['passed'] and prior['actual_recursive_procs_empty'] and prior['path_gone']
assert not Path(prior['identity']['path']).exists()
campaign=RAW.parent.parent/'vllm_qualification/d557_20261016'
closed=json.loads((campaign/'publication_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
launch=json.loads((campaign/'launch7b.json').read_text())
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not Path(launch['service_identity']['path']).exists()
""")
with (raw/'component2.log').open('x') as log:
    with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        exec(compile(code,str(source),'exec'))
