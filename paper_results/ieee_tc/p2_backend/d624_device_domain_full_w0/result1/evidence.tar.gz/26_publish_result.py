"""Reuse the sealed D621 publisher, replacing only D624 identity and analysis.

No online implementation, source result, metric threshold or historic publisher
is edited.  The exact source and this adapter are included in the evidence tar.
"""
import ast
import hashlib
from pathlib import Path
import sys

RAW = Path(__file__).resolve().parent
SOURCE = RAW.parent / 'd621_20261017/publish_result.py'
data = SOURCE.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'e3541b4f4a813ac1167fb5bf7cea179c42750746f3124134a024f644859067f1'
code = data.decode()

def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d621_device_domain_full_w2/result1'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d624_device_domain_full_w0/result1'")
replace("assert git('rev-parse','HEAD')=='c2289327aeb3dc6cd086dfce2455ab2fb99924e7'",
        "assert git('rev-parse','HEAD')=='75ccb3a4ff3664ec42d7a90984629c470218518b'")
begin = code.index("old_path=RAW.parent/'d615_20261017/actual_qualification.json'")
end = code.index("cap=read(RAW/'realized_replica_cap.json')", begin)
code = code[:begin] + '''old_path=RAW.parent/'d619_20261017/actual_qualification.json'
cross_path=RAW.parent/'d621_20261017/actual_qualification.json'
reference_path=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft/resident_references.json'
references=read(reference_path)
observations=[]
configuration_files=[]
import copy
import yaml
normalised=[]
for run_id,profile,path,config_name in (
    ('D624','W0',RAW/'actual_qualification.json','20261017_d624_7b_device_domain_full_w0.yaml'),
    ('D619','W1',old_path,'20261017_d619_7b_device_domain_full_w1.yaml'),
    ('D621','W2',cross_path,'20261017_d621_7b_device_domain_full_w2.yaml')):
    record=read(path)
    assert record['passed'] and record['protocol_bound_count']==4000
    assert record['native_tokens']==458224 and record['stats']['n_correct'] is None
    assert record['workload_identity']['profile']==profile
    assert record['workload_identity']['source_sha256']==audit['workload_identity']['source_sha256']
    qualification=read(path.parent/'qualification.json')
    for relative in ('scripts/run_all_experiments.py','faaslora/coordination/autoscaler.py',
                     'faaslora/memory/residency_manager.py','faaslora/cpu_frontend.py'):
        key=str(ROOT/relative)
        assert qualification['refs'][key]==binding['refs'][key]==p.digest(ROOT/relative)
    config_path=ROOT/'configs/ieee_tc'/config_name
    cfg=yaml.safe_load(config_path.read_text())
    normalised.append(copy.deepcopy(cfg))
    configuration_files.append(config_path)
    reference=references[profile] if profile in ('W1','W2') else None
    if reference is not None:
        assert reference['reference_frozen'] and reference['budget_fraction']==0.75
    observations.append(dict(run_id=run_id,workload=profile,
        source_audit_path=str(path),source_audit_sha256=p.digest(path),
        configuration_path=str(config_path),configuration_sha256=p.digest(config_path),
        stats=record['stats'],joint_count=record['common_threshold_joint_count'],
        joint_fraction=record['common_threshold_joint_count']/4000,
        joint95_observed=record['common_threshold_joint_count']>=3800,
        gpu_seconds_per_offered=record['stats']['physical_gpu_seconds']/4000,
        gpu_seconds_per_correct=None,resource_reference=reference,
        U_over_B=(record['stats']['physical_gpu_seconds']/reference['B_gpu_seconds'] if reference else None),
        budget_feasible_observed=(record['stats']['physical_gpu_seconds']<=reference['B_gpu_seconds'] if reference else None),
        raw_n_correct=None,ranking_eligible=False))
# These are the only run-local path differences allowed by pre-launch qualification.
def remove_run_paths(value):
    del value['experiment']['output_dir']
    del value['storage']['nvme_cache_dir']
    del value['storage']['host_cache_dir']
    return value
assert remove_run_paths(normalised[0])==remove_run_paths(normalised[1])==remove_run_paths(normalised[2])
comparison=dict(kind='same_version_same_model_point_cross_workload_observation_v1',
    observations=observations,source_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    resource_reference=dict(path=str(reference_path),sha256=p.digest(reference_path)),
    all_workload_joint95_observed=all(row['joint95_observed'] for row in observations),
    all_workload_native_contract_complete=True,independent_numerical_correctness='unknown',
    final_G1_G2_qualified=False,ranking_eligible=False,
    whole_cache_prestate_equivalence_proved=False,single_run_variation_not_separated=True,
    causal_single_mechanism_performance_attribution=False,
    conclusion='W0/W1/W2 are now complete under the same production implementation and model working point. W0 has %d/4000 observed joint-SLO passes; W2 remains below the frozen 95%% requirement. Native contract completion is not independent numerical proof. No same-key replay, cross-scene splicing, global optimum or final G1/G2 claim.' % audit['common_threshold_joint_count'])
''' + code[end:]
replace("run=RAW/'7b_device_domain_full_w2'", "run=RAW/'7b_device_domain_full_w0'")
replace("ROOT/'docs/ieee_tc/D621_DEVICE_DOMAIN_FULL_W2.md',",
        "ROOT/'docs/ieee_tc/D624_DEVICE_DOMAIN_FULL_W0.md',\n    ROOT/'docs/ieee_tc/NUMERICAL_REPRODUCIBILITY_BOUNDARY_20261017.md',\n    RAW.parent/'d621_20261017/publish_result.py',cross_path,*configuration_files,")
replace("names=['docs/ieee_tc/D621_DEVICE_DOMAIN_FULL_W2.md','docs/ieee_tc/EXECUTION_STATUS.md']",
        "names=['docs/ieee_tc/D624_DEVICE_DOMAIN_FULL_W0.md','docs/ieee_tc/EXECUTION_STATUS.md',\n       'docs/ieee_tc/NUMERICAL_REPRODUCIBILITY_BOUNDARY_20261017.md']")
replace("tc: retain W2 joint-SLO shortfall and complete lifecycle evidence (D621)",
        "tc: complete same-point W0 and retain cross-workload feasibility limits (D624)")
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D621 source SHA and D624 adaptation/AST checks passed; no publication performed.')
elif not sys.argv[1:]:
    exec(compile(code, str(SOURCE), 'exec'), dict(__file__=__file__, __name__='d624_publication'))
else:
    raise SystemExit('expected no arguments or --check-only')
