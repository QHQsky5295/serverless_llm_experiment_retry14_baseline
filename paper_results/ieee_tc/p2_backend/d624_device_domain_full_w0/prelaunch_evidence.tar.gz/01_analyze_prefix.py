"""D624 data-only qualification, reusing the existing common analyzer."""
import ijson
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts.ieee_tc.plot_d290_diagnostic import audit_run,binding_checks,sha256
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

run=RAW/'7b_device_domain_full_w0'
source=next(run.glob('experiment_results*.json'))
stats,evidence,requests=audit_run(source)
assert len(requests)==4000
outcome_path=run/'launch.launch/physical_deployment/main_outcome.json'
def selected(prefix):
    with outcome_path.open('rb') as handle:
        return next(ijson.items(handle,prefix,use_float=True))
outcome={key:selected(key) for key in ('run_completed','error','cleanup_errors','measurement_errors','launch_contract','remote_transfers')}
outcome['mechanism_events']={'_ieee_activations':selected('mechanism_events._ieee_activations')}
with outcome_path.open('rb') as handle:
    host_reasons=Counter(row['trigger_reason'] for row in ijson.items(handle,'mechanism_events._ieee_native_host_preparations.item',use_float=True))
# Stream each existing plan rather than materializing the whole outcome.
gpu_counts=Counter()
gpu_attempt_states=Counter()
with outcome_path.open('rb') as handle:
    for row in ijson.items(handle,'mechanism_events._ieee_gpu_preparation_plans.item',use_float=True):
        gpu_counts['plans']+=1
        for attempt in row['attempts']:
            gpu_counts['attempts']+=1
            gpu_attempt_states[attempt['state']]+=1
            receipt=attempt.get('receipt')
            if receipt is not None:
                gpu_counts['receipts']+=1
                gpu_counts['acquired']+=receipt.get('acquired') is True
                gpu_counts['deferred']+=receipt.get('acquired') is False

launch=json.loads((run/'launch.json').read_text())
assert launch['pass'] and launch['service_returncode']==launch['watchdog_returncode']==0
assert launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
assert outcome['run_completed'] and not outcome['error']
assert not outcome['cleanup_errors'] and not outcome['measurement_errors']
plan=FrozenReplayPlan.load(outcome['launch_contract']['input_plan']['source_path'],count=4000,profile='W0')
assert plan.identity()==outcome['launch_contract']['input_plan']
assert plan.identity()==launch['external_replay']['plan']
assert plan.identity()==json.loads((RAW/'qualification.json').read_text())['prime_plan']
from scripts.analyze_control_path_overhead import partition_retained_request_stages
from scripts.ieee_tc.check_d299_full_context import closed_physical_integral
from scripts.ieee_tc.plot_d290_diagnostic import percentile
from statistics import fmean
physical=json.loads((run/'launch.launch/physical_deployment/summary.json').read_text())
assert closed_physical_integral(physical,expected_count=4000)==stats['physical_gpu_seconds']
assert abs(sum(physical['window_gpu_seconds'].values())-stats['physical_gpu_seconds'])<1e-6
stages=[partition_retained_request_stages(r,
    arrival_start_s=launch['external_replay']['replay_t0_s'],
    clock_id=launch['external_replay']['clock_id']) for r in requests]
assert max(r['max_identity_error_ms'] for r in stages)<=1.0
stage_summary={key:fmean(r['stages_ms'][key] for r in stages) for key in stages[0]['stages_ms']}
stats['mean_e2e_ms']=fmean(r['e2e_ms'] for r in stages)
assert abs(sum(stage_summary.values())-stats['mean_e2e_ms'])<1e-6
entries={e.request_id:e for e in plan.entries}
assert set(entries)=={r['request_id'] for r in requests}
index_path=ROOT/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
index=json.loads(index_path.read_text())
expected={a['id']:hashlib.sha256(json.dumps(sorted(a['files'],key=lambda f:f['path']),
    sort_keys=True,separators=(',',':')).encode()).hexdigest() for a in index['artifacts']}
for row in requests:
    entry=entries[row['request_id']]
    original=json.loads(entry.source_json)
    assert row['adapter_id']==original['adapter_id']
    assert math.isclose(row['scheduled_arrival_offset_s'],entry.offset_s,abs_tol=1e-9)
    assert row['source_expected_output_tokens']==original['expected_output_tokens']
    assert row['completion_tokens']==min(original['expected_output_tokens'],256)
    assert all(binding_checks(row,expected[row['adapter_id']]).values())
journal=RAW/'remote_transfers.jsonl'
server_rows=[json.loads(line) for line in journal.read_text().splitlines()]
server={r['transfer_id']:r for r in server_rows}
transfers=outcome['remote_transfers']
assert len(server)==len(server_rows)==len(transfers)
assert set(server)=={r['http_transfer_id'] for r in transfers}
clock=json.loads((RAW/'remote_health.json').read_text())['7b']['clock_id']
for row in transfers:
    peer=server[row['http_transfer_id']]
    assert row['state']=='published' and row['content_verified'] and row['published_archive_verified']
    assert row['artifact_id']==peer['artifact_id']
    assert row['remote_archive_sha256']==peer['archive_sha256']
    assert row['transferred_bytes']==peer['archive_bytes']==peer['bytes_read']==peer['bytes_written']
    assert peer['clock_id']==clock and peer['outcome']=='sent'
    assert not row['remote_pack_performed'] and not peer['pack_performed'] and not peer['temporary_created']
resources=[r for line in (run/'launch.launch/watchdog.jsonl').read_text().splitlines()
    if (r:=json.loads(line))['event']=='resource_sample']
assert resources and not any(r['decision']['abort_reasons'] for r in resources)
assert all(r['service']['memory.high']==72*p.GIB and r['service']['memory.max']==80*p.GIB and r['service']['memory.swap.max']==2*p.GIB for r in resources)
slo_path=ROOT/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json'
assert sha256(slo_path)=='2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3'
slo=json.loads(slo_path.read_text())
good=0
ttft_good=0
tpot_good=0
joint_by_id={}
for row in requests:
    length=row['native_token_timing']['actual_prompt_tokens']
    groups=[g for g in slo['groups'] if (g['lower_exclusive'] is None or length>g['lower_exclusive'])
        and (g['upper_inclusive'] is None or length<=g['upper_inclusive'])]
    assert len(groups)==1
    g=groups[0]
    t=row['overall_ttft_ms']<=g['ttft_ms']
    d=row['completion_tokens']==1 or row['tpot_ms']<=g['tpot_ms']
    ttft_good+=t
    tpot_good+=d
    good+=t and d
    joint_by_id[row['request_id']]=bool(t and d)
ordered={r['request_id']:r for r in requests}
phases=[]
for i in range(8):
    ids=[e.request_id for e in plan.entries[i*500:(i+1)*500]]
    phases.append(dict(phase=i,count=len(ids),joint=sum(joint_by_id[r] for r in ids),
        p95_ttft_ms=percentile([ordered[r]['overall_ttft_ms'] for r in ids],.95)))
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
activations=outcome['mechanism_events']['_ieee_activations']
refs=[source,outcome_path,run/'launch.json',journal,RAW/'remote_monitor.log',RAW/'remote_stop.json',
    RAW/'local_cleanup.json',RAW/'completion_receipt.json',RAW/'remote_health.json',
    run/'launch.launch/watchdog.jsonl',slo_path,index_path,Path(__file__)]
print(json.dumps(dict(kind='d624_actual_initial_control_full4000_qualification_v1',passed=True,
    gpu_preparation=dict(gpu_counts),gpu_attempt_states=dict(gpu_attempt_states),
    stats=stats,evidence=evidence,protocol_bound_count=4000,numerical_correctness_qualified=False,
    fixed_workload_complete4000=True,ranking_eligible=False,replicates=1,confidence_interval=None,
    host_queue_trigger_reasons=dict(host_reasons),
    native_tokens=sum(r['completion_tokens'] for r in requests),
    dispatch_tiers=dict(Counter(r['readiness_tier_before_dispatch'] for r in requests)),
    activation_categories=dict(Counter(r['category'] for r in activations)),
    activation_state_counts={category:dict(Counter(r['state'] for r in activations if r['category']==category))
        for category in sorted({r['category'] for r in activations})},
    initial_activation_s=[r['engine_ready_at']-r['trigger_at'] for r in activations if r['category']=='initial'],
    common_threshold_joint_count=good,common_threshold_ttft_count=ttft_good,
    common_threshold_tpot_count=tpot_good,source_order_phases=phases,
    workload_identity=plan.identity(),window_gpu_seconds=physical['window_gpu_seconds'],
    stage_means_ms=stage_summary,max_e2e_identity_error_ms=max(r['max_identity_error_ms'] for r in stages),
    remote_transfers=len(transfers),
    remote_wire_bytes=sum(r['transferred_bytes'] for r in transfers),request_time_pack_count=0,
    resources=dict(samples=len(resources),peak_bytes=max(r['service']['memory.peak'] for r in resources),
        max_swap_bytes=max(r['service']['memory.swap.current'] for r in resources),
        events={k:max(r['service']['memory.events'][k] for r in resources) for k in ('high','max','oom','oom_kill')}),
    protected=protected,refs=[dict(path=str(f),sha256=sha256(f)) for f in refs],
    scope=p.scope_identity(p.cg_path().name)),indent=2))
