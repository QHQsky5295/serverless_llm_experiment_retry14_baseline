"""Bind D618 repaired source and unchanged D619 model point to the full existing W0."""
import ast, copy, json, os, subprocess, sys
from pathlib import Path
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan
def read(path):return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'qualification_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='f11d44663ac5c1d5f1c59cd9cac4e23ea4439677'
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
production=ROOT/'scripts/run_all_experiments.py'
parent=RAW.parent/'d619_20261017'
previous=RAW.parent/'d618_20261017'
old=read(parent/'qualification.json')
assert old['passed'] and old['count']==4000
assert old['three_replica_checks']['passed'] and old['three_replica_checks']['case_count']==192
native=read(previous/'native_reuse.json')
assert native['passed'] and native['single_semantic_change_verified']
assert native['configuration_unchanged'] and native['native_mechanism_reuse_only']
assert native['device_uuid_count']==4 and native['cpu_preparation']['legal_devices']==[0,1,2,3]
assert native['candidate_source_sha256']==p.digest(production)
assert old['refs'][str(production)]==native['candidate_source_sha256']
# Production is unchanged from completed D619; only the campaign shell identity differs.
for path,sha in {**old['refs'],**old['preserved']}.items():
    if Path(path) not in (shell,production):assert p.digest(Path(path))==sha,path
test_sources={}
for phase,count in (('focused',60),('regression',464)):
    reg=read(previous/(phase+'_receipt.json'))
    assert reg['passed'] and reg['returncode']==0
    for path,sha in reg['sources'].items():
        assert p.digest(Path(path))==sha,path
        test_sources[path]=sha
    log=previous/(phase+'.log')
    assert p.digest(log)==reg['log_sha256']
    import re
    assert sum(map(int,re.findall(r'Ran (\d+) tests?',log.read_text())))==count
for phase in ('before','before2','storage','focused','regression','native_reuse','publication'):
    closed=read(previous/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
for phase in ('qualification','backup','start','analysis','analysis2','publication'):
    closed=read(parent/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
local=read(parent/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
stop=(parent/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive')==stop.count('MainPID=0')==3
auditpath=ROOT/'paper_results/ieee_tc/p2_backend/d618_cpu_device_domain/qualification1/summary.json'
audit=read(auditpath)
assert audit['passed'] and audit['total_cpu_tests']==524 and not audit['full_performance_complete']
assert read(previous/'publication_receipt.json')['head']=='610388a44c0c270b27668f8822fdea1a5128bf96'
completed=read(parent/'actual_qualification.json')
domain=read(parent/'device_domain_evidence.json')
assert completed['passed'] and completed['protocol_bound_count']==4000
assert domain['passed'] and domain['legal_devices']==[0,1,2,3]
assert domain['four_device_physical_overlap_seconds']>0
assert domain['activated_records']==5 and domain['all_processes_exited_zero']
assert read(ROOT/'paper_results/ieee_tc/p2_backend/d619_device_domain_full_w1/result1/summary.json')['audit']==completed
storage=RAW.parent.parent/'storage_maintenance/d622_20261017'
for phase in ('storage','publication'):
    closed=read(storage/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
latest=RAW.parent/'d623_20261017'
for phase in ('analysis','publication'):
    closed=read(latest/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
gate=p.preflight([ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
paths=[ROOT/'configs/ieee_tc/20261017_d619_7b_device_domain_full_w1.yaml',
       ROOT/'configs/ieee_tc/20261017_d624_7b_device_domain_full_w0.yaml']
configs=[yaml.safe_load(path.read_text()) for path in paths]
normalized=copy.deepcopy(configs)
for row in normalized:
    row['experiment'].pop('output_dir')
    row['storage'].pop('nvme_cache_dir');row['storage'].pop('host_cache_dir')
assert normalized[0]==normalized[1], 'no W0-specific model or policy tuning'
assert configs[1]['resource_coordination']['max_instances']==3
assert configs[1]['resource_coordination']['min_instances']==1
assert configs[1]['model']['visible_device_ids']==configs[1]['hardware']['gpu_device_ids']==[0,1,2,3]
for path in (Path(configs[1]['experiment']['output_dir']),Path(configs[1]['storage']['nvme_cache_dir']),Path(configs[1]['storage']['host_cache_dir'])):
    assert not path.exists(),path
body=shell.read_text();start=body.index('  d624)\n');end=body.index('    ;;\n',start)+len('    ;;\n')
branch=body[start:end]
assert paths[1].name in branch and 'PREFIX_COUNT=\n' in branch and 'SCENARIO=tc_ieee_full\n' in branch
native_block="if [[ \"${1:-d293}\" == d624 ]]; then\n  export FAASLORA_TC_NATIVE_TOOLCHAIN_CONTRACT=\"$ROOT/configs/ieee_tc/native_toolchain_cuda130_v1.json\"\n  export FAASLORA_TC_NATIVE_TOOLCHAIN_SHA256=328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c\nfi\n"
assert body.count(native_block)==1
restored=(body[:start]+body[end:]).replace(native_block,'',1)
assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
observer_line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd328' in line)
assert 'd624' not in observer_line
w1line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd533' in line)
w2line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd554' in line)
assert 'd624' not in w1line and 'd624' not in w2line
oldw0path=RAW.parent/'d529_20261014/7b_full_w0/launch.json'
oldw0=read(oldw0path)['external_replay']['plan']
plan=FrozenReplayPlan.load(oldw0['source_path'],profile='W0')
assert plan.identity()==oldw0 and len(plan.entries)==plan.source_count==4000
assert plan.identity()['source_sha256']=='efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
assert plan.identity()['view_sha256']=='a5331be2e2204483f18206825d9aaa18cbaa259fe0babfc303f989055819430d'
assert 'adapter_map' not in plan.identity()
assert FrozenReplayPlan.from_launch_context(dict(plan=plan.identity(),tiny_witness=False,replay_scope='full_source_v1'))==plan
from scripts.run_all_experiments import ScenarioRunner, _prepare_scenario_runtime_model_config, _normalize_runtime_concurrency_cap
full=configs[1];scenario=next(row for row in full['scenarios'] if row['name']=='tc_ieee_full')
coord=dict(full['resource_coordination'],**scenario.get('resource_coordination',{}))
runner=ScenarioRunner.__new__(ScenarioRunner)
runner.model_cfg=_prepare_scenario_runtime_model_config(_normalize_runtime_concurrency_cap(full['model']),full['workload'],coord)
runner.coord_cfg=coord;runner._initial_runtime_pending=True
runner._service_profiles=runner._load_ieee_service_profiles();runner._load_ieee_preparation_profiles()
buildpath=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=read(buildpath);assert build['passed'] and build['actual_closure']['passed'] and build['actual_closure']['path_gone']
assert not Path(build['actual_closure']['identity']['path']).exists()
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256'],path
helpers=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),shell])
for path in helpers:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    else:subprocess.run(['bash','-n',str(path)],check=True)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
refs=[*helpers,*paths,parent/'qualification.json',parent/'analysis2_closure.json',
      parent/'publication_closure.json',parent/'local_cleanup.json',parent/'remote_stop.log',
      auditpath,oldw0path,buildpath,previous/'native_reuse.json',
      previous/'focused_receipt.json',previous/'regression_receipt.json',
      previous/'focused.log',previous/'regression.log',previous/'publication_receipt.json',
      RAW.parent/'d550_20261015/close.py',ROOT/'docs/ieee_tc/D618_CPU_PREPARATION_DEVICE_DOMAIN.md']
refs += [previous/(phase+'_closure.json') for phase in
         ('before','before2','storage','focused','regression','native_reuse','publication')]
refs += [Path(path) for path in old['refs'] if Path(path)!=shell]
refs += list(map(Path,test_sources))
refs += [parent/'actual_qualification.json',parent/'device_domain_evidence.json',storage/'storage_closure.json',storage/'publication_closure.json',storage/'storage_result.json', oldw0path]
refs += [latest/'analysis_closure.json',latest/'publication_closure.json',latest/'publication_receipt.json']
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
import torch
assert not torch.cuda.is_initialized()
save(RAW/'qualification.json',dict(passed=True,scope=identity,protected=protected,preserved=old['preserved'],
    prime_plan=plan.identity(),source_count=4000,count=4000,configuration_changes={},
    same_model_working_point_as_d615=True,unchanged_other_model_control_settings=True,
    three_replica_checks=old['three_replica_checks'],control_tests_run=0,reused_control_tests=21,
    reused_cpu_regression_tests=464,reused_focused_tests=60,reused_input_tests=386,
    native_mechanism_reuse_only=True,device_domain_fix_sha256=p.digest(production),
    exact_profiles_loaded=True,observer=None,ordinary_full_replay=True,ranking_eligible=False,
    preflight=gate,refs={str(path):p.digest(path) for path in refs},
    resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True,count=4000,profile='W0',same_model_working_point_as_d615=True,
    view_sha256=plan.identity()['view_sha256'],new_tests=0,reused_regression=464,reused_focused=60,
    reused_control_tests=21,reused_config_checks=192,exact_profiles_loaded=True)))
