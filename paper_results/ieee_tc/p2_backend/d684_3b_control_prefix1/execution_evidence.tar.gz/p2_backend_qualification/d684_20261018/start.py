"""Reuse D536 exact-owned launch gates for prequalified D684 Full W0."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
QUAL=RAW
BINDING=QUAL/'qualification.json'
ENV=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def run(command,**kwargs):return subprocess.run(command,check=True,**kwargs)
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()

assert RAW.name=='d684_20261018'
assert not any((RAW/name).exists() for name in ('3b_full_w0_prefix1','start_receipt.json'))
assert not Path('/dev/shm/tc-d684-3b-w0-prefix1').exists()
identity=p.scope_identity(p.cg_path().name)
save(RAW/'start_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
backup=json.loads((QUAL/'backup_receipt.json').read_text())
head=git(ROOT,'rev-parse','HEAD')
assert backup['passed'] and head==backup['head']
assert git(ROOT,'ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]==head
basehead=git(BASE,'rev-parse','HEAD')
assert basehead=='e16af33aaf41f02a62ecdce59f6f3227813244c3'
assert git(BASE,'ls-remote','origin','refs/heads/main').split()[0]==basehead
closed=json.loads((QUAL/'backup_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
for repo,paths in ((ROOT,['faaslora','scripts','configs/ieee_tc','tests']),
                   (BASE,['scripts/prepare_ieee_tc_serverless_stack.py','scripts/replay_vllm_engine_trace.py',
                          'scripts/ieee_tc_serverless_measurement.py','configs/ieee_tc'])):
    assert not git(repo,'diff','--name-only','HEAD','--',*paths)
binding=json.loads(BINDING.read_text())
assert binding['passed'] and binding['reused_cpu_tests']==527 and binding['reused_native_method_tests']==72 and binding['no_gpu_run']
for path,sha in binding['refs'].items():assert p.digest(Path(path))==sha,path
for path,sha in backup['preserved'].items():assert p.digest(Path(path))==sha,path
build_path=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=json.loads(build_path.read_text())
assert build['passed'] and build['actual_closure']['passed'] and build['actual_closure']['path_gone']
assert not Path(build['actual_closure']['identity']['path']).exists()
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256'],path
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate=p.preflight([ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
session='tc-d684-3b-w0-prefix1'
assert subprocess.run(['tmux','has-session','-t',session],stderr=subprocess.DEVNULL).returncode!=0
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
prepared=json.loads((ROOT/'paper_results/ieee_tc/p2_backend/d684_3b_control_prefix1/preparation.json').read_text())
assert prepared['passed'] and prepared['profile_loader_passed']
assert prepared['source_plan']['count']==1000 and prepared['source_plan']['profile']=='W0'
for ref in [*prepared['sources'],prepared['configuration']]:assert p.digest(Path(ref['path']))==ref['sha256']
assert p.digest(Path(prepared['source_plan']['source_path']))==prepared['source_plan']['source_sha256']
save(RAW/'launch_gate.json',dict(passed=True,head=head,baseline_head=basehead,
    qualification_sha256=p.digest(BINDING),gate=gate,protected=protected,scope=identity,
    helpers=[dict(path=str(x),sha256=p.digest(x),content=x.read_text())
             for x in sorted([*RAW.glob('*.py'),*RAW.glob('*.sh')])]))
# Record actual model-cache metadata, without warmup or a whole-cache scan.
cache=Path('/home/qhq/.cache/vllm/torch_compile_cache')
metadata=sorted(cache.glob('*/rank_0_0/backbone/cache_key_factors.json'))
assert len(metadata)<=2048
save(RAW/'model_cache_metadata_before.json',dict(scope='direct rank_0_0/backbone metadata only',
    no_model_prewarm=True,whole_cache_prestate_proved=False,
    entries=[dict(path=str(path),sha256=p.digest(path),mtime_ns=path.stat().st_mtime_ns,
        factors=json.loads(path.read_text())) for path in metadata]))
run(['bash',str(RAW/'start_remote.sh')])
run([sys.executable,str(RAW/'check_remote_health_stdlib.py')],cwd=ROOT)
run(['tmux','new-session','-d','-s',session,'-c',str(ROOT),
     'bash scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh d684'])
receipt=RAW/'3b_full_w0_prefix1/launch.launch/exec_receipt.json'
deadline=time.monotonic()+210
while True:
    if receipt.exists():
        try:
            launched=json.loads(receipt.read_text())
            break
        except json.JSONDecodeError:
            pass  # The same launcher is still writing; never restart it.
    if time.monotonic()>deadline:
        raise TimeoutError('observation timeout only; inspect the same tmux, never restart')
    time.sleep(.1)
captured=p.scope_identity(Path(launched['auxiliary_path']).name)
save(RAW/'service_aux_identity.json',captured)
save(RAW/'start_receipt.json',dict(launched=True,head=head,baseline_head=basehead,
    tmux=session,starter_identity=identity,launcher_identity=captured))
print(json.dumps(dict(launched=True,tmux=session,head=head,baseline_head=basehead)))
