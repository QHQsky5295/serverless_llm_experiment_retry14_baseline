"""Reuse D351 operation aggregation; add exact observed inventory call summaries."""
import ast
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d351_20261008/summarize_operations.py')
source_bytes=source.read_bytes()
assert hashlib.sha256(source_bytes).hexdigest()=='f73f728f2b980e1112a7ddc471197a94959b623284681912360c2a966a0c9708'
code=source_bytes.decode()
code=code.replace("BASE=ROOT/'paper_results/ieee_tc/p2_backend/d351_core_timing'",
    "BASE=ROOT/'paper_results/ieee_tc/p2_backend/d684_3b_control_prefix1/completion'")
a=code.index('closures=[]');b=code.index('manifest=json.loads',a)
code=code[:a]+"""with (RAW/'operations_identity.json').open('x') as f:json.dump(identity,f,indent=2)
closed=json.loads((RAW/'analysis_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
"""+code[b:]
code=code.replace("BASE/'analysis1/manifest.json'","BASE/'analysis_manifest.json'")
code=code.replace("BASE/'analysis1'/name","BASE/name")
code=code.replace("BASE/'analysis1/core_timing/","BASE/'core_timing/")
code=code.replace('d351_control_operation_aggregation_v1','d684_control_operation_aggregation_v1')
code=code.replace("assert gate['preflight_pass'],gate['issues']",
    "assert not any('host_memory_below_stop' in v or 'filesystem_below_stop' in v for v in gate['issues']),gate['issues']")
ast.parse(code)
exec(compile(code,str(source),'exec'))

with (BASE/'core_timing/host_inventory.csv').open() as f:
    observed=list(csv.DictReader(f))
completion=json.loads((BASE/'completion.json').read_text())
assert completion['passed'] and len(observed)==completion['inventory_observations'] and len(observed)>0
groups=collections.defaultdict(list)
for row in observed:groups[row['boundary'],row['scope'],row['label'],row['state']].append(row)
def stats(items):
    wall=sorted(float(r['wall_ms']) for r in items)
    cpu=math.fsum(float(r['thread_cpu_ms']) for r in items)
    total=math.fsum(wall)
    parents={}
    for row in items:
        key=(row['process'],row['parent'])
        value=float(row['parent_wall_ms'])
        assert key not in parents or parents[key]==value
        parents[key]=value
    return dict(count=len(items),total_wall_ms=total,total_cpu_ms=cpu,
        mean_wall_ms=total/len(items),p50_ms=wall[math.ceil(.5*len(items))-1],
        p95_ms=wall[math.ceil(.95*len(items))-1],max_ms=wall[-1],
        cpu_over_wall=cpu/total if total else None,
        unique_parents=len(parents),parent_wall_ms=math.fsum(parents.values()))
inventory_rows=[dict(boundary=k[0],scope=k[1],label=k[2],state=k[3],**stats(items))
    for k,items in sorted(groups.items())]
by_size=collections.defaultdict(list)
for row in observed:
    if row['boundary']=='host_inventory' and row['outcome']=='returned':
        by_size[row['scope'],int(row['adapter_count'])].append(row)
size_rows=[dict(scope=k[0],adapter_count=k[1],**stats(items)) for k,items in sorted(by_size.items())]
for name,records in [('host_inventory_groups.csv',inventory_rows),('host_inventory_by_size.csv',size_rows)]:
    with (out/name).open('x') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
summary['inventory_summary']=[dict(boundary=boundary,**stats([r for r in observed if r['boundary']==boundary]))
    for boundary in ('host_inventory','host_allocator_stats')]
summary['inventory_groups']=inventory_rows
summary['inventory_by_size']=size_rows
summary['caveats'] += ['Inventory and allocator totals are nested in original client/root totals, never additive to them.',
    'Parent totals are deduplicated within each group only; do not sum parent totals across groups.',
    'Per-request intersections may overlap across requests, and are associations, not attributable speedup.']
summary['sources'].append(dict(path=str(BASE/'core_timing/host_inventory.csv'),sha256=p.digest(BASE/'core_timing/host_inventory.csv')))
with (out/'inventory_summary.json').open('x') as f:json.dump(summary,f,indent=2,allow_nan=False)
print(json.dumps(dict(inventory_summary=summary['inventory_summary'],
    top_work_inventory=sorted([r for r in inventory_rows if r['state']=='work'],key=lambda r:-r['total_wall_ms'])[:10])))
