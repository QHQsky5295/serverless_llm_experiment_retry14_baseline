"""Bounded CPU qualification; reuse indexing and native warm test suite."""
import ast, json, os, subprocess, sys, unittest
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(name,obj):
    with (RAW/name).open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);save('qualification_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT,RAW],64*1024*1024);save('qualification_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
prior=RAW.parent/'d645_20261017'
closure=read(prior/'backup_closure.json')
assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()
assert read(prior/'backup_receipt.json')['head']=='31475e6fa50458ec6478d1a9636869f425e5efa7'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=ROOT/'paper_results/ieee_tc/p2_backend/d645_3b_profiles',check=True,stdout=subprocess.DEVNULL)
from tests import test_ieee_tc_warm_reference as module
with (RAW/'tests.log').open('x') as f:
    result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
assert result.wasSuccessful()
helper=ROOT/'scripts/ieee_tc/prepare_d298_capacity.py'
runner=ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh'
ast.parse(helper.read_text());subprocess.run(['bash','-n',str(runner)],check=True)
from scripts.ieee_tc.prepare_d298_capacity import prepare_3b_warm_inputs
from contextlib import redirect_stdout
with (RAW/'prepare.log').open('x') as log:
    with redirect_stdout(log):prepare_3b_warm_inputs()
inputs=read(ROOT/'paper_results/ieee_tc/p2_backend/d646_3b_warm_inputs/prepare.json')
assert inputs['passed'] and inputs['current_tokenizer_checked_requests']==4000
import torch
assert not torch.cuda.is_initialized()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
save('qualification.json',dict(passed=True,tests=result.testsRun,inputs=inputs,protected=protected,
    no_cuda_initialized=True,helper_sha256=p.digest(helper),runner_sha256=p.digest(runner)))
print(json.dumps(dict(passed=True,tests=result.testsRun,groups=len(inputs['groups']),
    probe_batches=inputs['probe_batches'],measure_batches=inputs['measure_batches'])))
