"""D346: unchanged C14 Full contract after the completed D345 prefix."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
import yaml
from types import SimpleNamespace
from scripts import ieee_tc_preflight as p
from scripts.run_all_experiments import (ScenarioRunner,
    _prepare_scenario_runtime_model_config, _prepare_dedicated_subprocess_model_cfg)

root = p.ROOT
smoke=json.loads((root/'paper_results/ieee_tc/p2_backend/d345_capacity_validation/smoke1/audit.json').read_text())
assert smoke['stats']['completed']==100 and smoke['no_figures']
assert smoke['full_qualified'] is False and smoke['n_correct'] is None
assert sum(smoke['tier_counts'].values())==100 and smoke['remote']['pack_performed'] is False
assert json.loads((root/'results/ieee_tc/p2_backend_qualification/d345_20261008/remote_stop.json').read_text())['all_owned_units_inactive']
out = Path(__file__).resolve().parent
config = root/'configs/ieee_tc/20261008_d346_7b_full_w0.yaml'
previous = root/'configs/ieee_tc/20261008_d345_7b_capacity_validation_100.yaml'
c, old = (yaml.safe_load(x.read_text()) for x in (config, previous))
expected = copy.deepcopy(old)
paths = [('experiment','output_dir'), ('storage','nvme_cache_dir'), ('storage','host_cache_dir')]
for section, field in paths:
    assert not Path(c[section][field]).exists()
    expected[section][field] = c[section][field]
assert c == expected and c['workload']['total_requests'] == 4000
assert c['experiment']['output_dir'] == str(out/'7b_full_w0')
assert c['storage']['nvme_cache_dir'] == str(out/'7b_nvme_w0')
assert c['storage']['host_cache_dir'] == '/dev/shm/tc-d346-7b-w0'
configured = _prepare_scenario_runtime_model_config(c['model'], c['workload'], c['resource_coordination'])
child, assembly = _prepare_dedicated_subprocess_model_cfg(configured, device_id=0, runtime_gpu_ids=[0])
contract = root/'paper_results/ieee_tc/p2_backend/d344_capacity_profiles/development_contract.json'
assert child == json.loads(contract.read_text())['model_config']
bound = ScenarioRunner.__new__(ScenarioRunner)
bound.model_cfg, bound.engine = child, SimpleNamespace(model_cfg=child)
bound.coord_cfg = c['resource_coordination']
bound._service_profiles = bound._load_ieee_service_profiles()
assert len(bound._service_profiles.profiles) == 200
assert len(bound._load_ieee_preparation_profiles().profiles) == 24
seal = p.verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
known = Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py')
assert seal['changed'] == [str(known)] and seal['entry_count'] == 147
assert p.digest(known) == '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.check_plan() == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
assert p.digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(root/'configs/generated/lora_manifest_1000.json') == '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert set(os.sched_getaffinity(0)) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
# /dev/shm is a bounded HOST tier, not persistent scratch subject to 150 GiB.
preflight = p.preflight([root], 32*p.GIB)
assert preflight['preflight_pass'], preflight['issues']
refs = [config, previous, contract, Path(__file__),
    root/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh', root/'scripts/run_all_experiments.py',
    root/'faaslora/scheduling/vllm_ieee_frontend.py',
    root/'faaslora/scheduling/vllm_ieee_scheduler.py', root/'faaslora/scheduling/resource_coordinator.py',
    root/'paper_results/ieee_tc/p2_backend/d345_capacity_validation/smoke1/audit.json']
receipt = dict(kind='d346_prelaunch_binding_v1', passed=True, source_head_before_checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    configuration_only_exclusive_paths=True, service_classes=200, preparation_classes=24,
    model_config=child, assembly=assembly, protection=seal, preflight=preflight,
    source_references=[dict(path=str(x),sha256=p.digest(x)) for x in refs],
    base_requests=4000, diagnostic_prefix_count=None, numerical_n_correct=None,
    formal_qualification=False, observer='none', no_figures=True)
with (out/'prelaunch_binding.json').open('x') as f:
    json.dump(receipt, f, indent=2, allow_nan=False)
print(json.dumps(dict(passed=True, classes=[200,24], protection_changed=seal['changed'],
    disk_free=preflight['filesystems'][0]['free_bytes'], mem_available=preflight['memory']['MemAvailable'])))

group=p.cg_path()
print(json.dumps(dict(scope=p.scope_identity(group.name), resources={k:(group/k).read_text().strip() for k in ['memory.peak','memory.events','memory.swap.current']})),flush=True)
