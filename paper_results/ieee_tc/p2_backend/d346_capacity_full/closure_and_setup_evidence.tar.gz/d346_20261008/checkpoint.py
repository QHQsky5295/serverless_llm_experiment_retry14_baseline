"""Seal completed D345 evidence and unchanged D346 full replay setup."""
import ast,hashlib,json,subprocess,sys,tarfile
from pathlib import Path
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent;smoke=raw.parent/'d345_20261008'
out=p.ROOT/'paper_results/ieee_tc/p2_backend/d346_capacity_full'
out.mkdir(exist_ok=False)
smoke_out=p.ROOT/'paper_results/ieee_tc/p2_backend/d345_capacity_validation/smoke1'
audit=json.loads((smoke_out/'audit.json').read_text())
assert audit['stats']['completed']==100 and audit['n_correct'] is None
for ref in audit['raw_evidence']:assert p.digest(Path(ref['path']))==ref['sha256']
offline=json.loads((smoke/'offline_execution_receipt.json').read_text());assert offline['pass_all']
assert json.loads((smoke/'remote_stop.json').read_text())['all_owned_units_inactive']
identities=[p.scope_identity('primelora-tc-aux-34500000000000000000000000000005.scope'),
    offline['identity'],p.scope_identity('primelora-tc-aux-34600000000000000000000000000001.scope')]
assert identities[-1]['invocation_id']=='742db79942f442659763ab6e758f89da'
cleanup=[]
for identity in identities:
    group=Path(identity['path']);assert p.scope_still_owned(identity) and not p.owned_pids(group)
    resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current','cgroup.events')}
    assert resources['memory.swap.current']=='0'
    assert all(int(line.split()[1])==0 for line in resources['memory.events'].splitlines())
    stopped=p.stop_scope_identity(identity);assert stopped['released'] and not stopped['hard_kill']
    assert not group.exists()
    cleanup.append(dict(identity=identity,resources=resources,cleanup=stopped))
binding=json.loads((raw/'prelaunch_binding.json').read_text());assert binding['passed']
for ref in binding['source_references']:assert p.digest(Path(ref['path']))==ref['sha256']
for path in [p.ROOT/'scripts/ieee_tc/analyze_d298_smoke.py',*raw.glob('*.py')]:ast.parse(path.read_text())
for path in [p.ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',*raw.glob('*.sh')]:
    subprocess.run(['bash','-n',str(path)],check=True)
refs=sorted(x for x in smoke.iterdir() if x.is_file())+sorted(x for x in raw.iterdir() if x.is_file())
run=smoke/'7b_capacity_validation_100'
refs += [run/'launch.json',run/'launcher.log',run/'launch.launch/service.log',
    run/'launch.launch/watchdog.jsonl',run/'launch.launch/physical_deployment/summary.json',
    run/'launch.launch/physical_deployment/physical_resource_summary.json']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip();assert token
for path in refs:assert token not in path.read_bytes(),path
archive=out/'closure_and_setup_evidence.tar.gz'
with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz') as tar:
    for path in refs:tar.add(path,arcname=str(path.relative_to(raw.parent)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(refs)
    for path in refs:
        assert hashlib.sha256(tar.extractfile(str(path.relative_to(raw.parent))).read()).hexdigest()==p.digest(path)
def save(name,value):
    with (out/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
save('cleanup.json',cleanup);save('prelaunch_binding.json',binding)
save('checkpoint.json',dict(passed=True,smoke_execution_commit='2ab680ef1b70c2604a0149cf4043704b6ec801e6',
    smoke_source=audit['evidence'],smoke_audit_sha256=p.digest(smoke_out/'audit.json'),
    source_plan_sha256=p.check_plan(),metric_protocol_sha256=p.digest(p.ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    archive_sha256=p.digest(archive),archive_bytes=archive.stat().st_size,
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in refs],
    numerical_n_correct=None,common_slo_qualified=False,full4000_launched=False,no_figures=True))
for folder,name in [(out,'outputs.sha256'),(smoke_out,'outputs.sha256')]:
    with (folder/name).open('x') as f:
        for path in sorted(folder.iterdir()):
            if path.name!=name:f.write(p.digest(path)+'  '+path.name+'\n')
print(json.dumps(dict(passed=True,closed_scopes=len(cleanup),archive_bytes=archive.stat().st_size,
    identity=p.scope_identity(p.cg_path().name))),flush=True)
