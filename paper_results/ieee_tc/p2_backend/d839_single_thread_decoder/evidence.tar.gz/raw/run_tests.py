"""Reuse D595's bounded checks for the HTTP decoder and actual owner paths."""
from pathlib import Path
import hashlib

template = Path(__file__).resolve().parent.parent/'d595_20261017/run_tests.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == '6122f9c1de2901777c99a3037f17719ccb5b53f9d85ec46539bd908244ea8022'
code = template.read_text()
start = code.index('paths=[ROOT/name')
end = code.index('\nrefs=', start)
code = code[:start] + '''installation_path = RAW.parent/'d838_20261025/installation.json'
installation = json.loads(installation_path.read_text())
assert installation['passed'] and installation['version'] == '1.8.0'
for row in installation['files']:
    assert p.digest(Path(row['path'])) == row['sha256']
import importlib.util
assert importlib.util.find_spec('isal') is None, 'base environment must remain unchanged'
os.environ['PYTHONPATH'] = installation['target'] + os.pathsep + str(ROOT)
save(RAW/(phase+'_dependency.json'), dict(installation=installation,
    source_path=str(installation_path), source_sha256=p.digest(installation_path),
    child_pythonpath=os.environ['PYTHONPATH']))
paths=[ROOT/name for name in ('faaslora/storage/http_artifact_store.py', 'pyproject.toml',
    'tests/test_http_artifact_store.py', 'tests/test_ieee_tc_request_lifecycle.py',
    'tests/test_ieee_tc_gzip_decoder.py')]
for path in paths:
    if path.suffix == '.py': compile(path.read_text(), str(path), 'exec')
''' + code[end:]
start = code.index('tests=(')
end = code.index('\ncommand=', start)
code = code[:start] + '''tests=(['tests.test_ieee_tc_gzip_decoder'] if phase=='focused' else [
    'tests.test_http_artifact_store.AtomicArtifactPublication',
    'tests.test_ieee_tc_request_lifecycle.ConfirmedFilePublication'])''' + code[end:]
code = code.replace("assert receipt['passed']", "assert receipt['passed']\nassert 'skipped=' not in (RAW/(phase+'.log')).read_text()")
exec(compile(code, str(template), 'exec'), globals())
