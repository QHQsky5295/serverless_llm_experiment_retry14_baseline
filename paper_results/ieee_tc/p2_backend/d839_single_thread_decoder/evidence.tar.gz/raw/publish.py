"""Reuse D828 bounded evidence packaging for the two decoder test paths."""
import hashlib
from pathlib import Path

template = Path(__file__).resolve().parent.parent/'d828_20261025/publish.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == '4690fe8a595eb36dd993059f162477ba21b7cb8ca6e5bfebb664d53a32683624'
source = template.read_text()
start = source.index("summary = read(OUT/'summary.json')")
end = source.index('\nclosed = []', start)
source = source[:start] + source[end:]
for old, new in (
    ('d828_post_file_owner_turn', 'd839_single_thread_decoder'),
    ("for phase in ('analysis', 'focused', 'regression'):", "for phase in ('focused', 'regression'):"),
    ('d827_workspace_retirement/closure.json', 'd838_compatible_decoder/closure.json'),
    ("('d827_20261025', 'publish.py'), ('d824_20261025', 'backup.py')",
     "('d828_20261025', 'publish.py'), ('d824_20261025', 'backup.py')"),
    ('distinct_regression_tests=370, focused_tests_included=57', 'test_executions=144, candidate_tests=75, standard_tests=69'),
    ("decision='One admitted owner anchor candidate CPU-qualified; complete unchanged 3B W2 next.'",
     "decision='Explicit single-thread ISA-L decoder passed targeted checks; one complete 3B W2 next. No performance claim yet.'"),
    ('D828_POST_FILE_OWNER_TURN_20261025.md', 'D839_SINGLE_THREAD_DECODER_INTEGRATION_20261025.md'),
    ('distinct_tests=370', 'test_executions=144'),
):
    assert old in source, old
    source = source.replace(old, new)
marker = "save(OUT/'closure.json', closure)"
extra = '''
for phase, count in [('focused',75), ('regression',69)]:
    log = (RAW/(phase+'.log')).read_text()
    assert f'Ran {count} tests' in log and '\\nOK\\n' in log and 'skipped=' not in log
installation = RAW.parent/'d838_20261025/installation.json'
dependency = read(installation)
assert dependency['passed'] and dependency['version'] == '1.8.0'
for row in dependency['files']:
    assert p.digest(Path(row['path'])) == row['sha256']
closure.update(dependency=ref(installation), dependency_files=dependency['files'],
    dependency_target=dependency['target'], decoder='isal', decoder_version='1.8.0')
'''
source = source.replace(marker, extra+'\n'+marker)
out = Path('/home/qhq/serverless_llm_experiment_retry14_baseline/paper_results/ieee_tc/p2_backend/d839_single_thread_decoder')
out.mkdir(parents=True, exist_ok=False)
exec(compile(source, str(template), 'exec'), globals())
