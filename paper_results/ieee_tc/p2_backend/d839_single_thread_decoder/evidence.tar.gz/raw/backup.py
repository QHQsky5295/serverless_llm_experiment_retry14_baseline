"""Reuse explicit-path backup for the tested decoder integration only."""
from pathlib import Path
import hashlib

template = Path(__file__).resolve().parent.parent/'d824_20261025/backup.py'
assert hashlib.sha256(template.read_bytes()).hexdigest() == 'ee84b28423f93cea5a6764c529174b4531ad1bcf7c38ee4e1d37c95bc0b951c8'
source = template.read_text()
for old, new in (
    ('d824_current_ingress_pending', 'd839_single_thread_decoder'),
    ('107185c45f49a891c0b391b1140b7d765e83daea', '362b17c95578a43c0ef927a62bee7c615993c963'),
    ("OUT/'final_manifest.json'", "OUT/'manifest.json'"),
    ('D824_CURRENT_INGRESS_AND_CONTROL_20261025.md', 'D839_SINGLE_THREAD_DECODER_INTEGRATION_20261025.md'),
    ("files = [ROOT/", "files = [*[Path(path) for path in closure['production_sources']], ROOT/"),
    ('len(set(paths)) == 20', 'len(set(paths)) == 10'),
    ('backup/d824-current-ingress-control-20261025', 'backup/d839-single-thread-decoder-20261025'),
    ('tc: preserve current 3B ingress and actual scaling-trigger diagnosis (D824)',
     'tc: integrate explicit single-thread decoder with targeted checks (D839)'),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'), globals())
