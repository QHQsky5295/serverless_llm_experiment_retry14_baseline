#!/usr/bin/env bash
# D161: reuse D139 RPC audit on the sealed D160 projection; no new inference.
set -euo pipefail
set -o noclobber
cd /home/qhq/serverless_llm_experiment_retry14_baseline
raw=results/ieee_tc/p2_backend_qualification/d161_20261002
unit=primelora-d161-rpc-audit1-20261002.scope
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/rpc_scope1.txt"
export PYTHONUNBUFFERED=1
python=/home/qhq/anaconda3/envs/LLM_vllm0102/bin/python
source=results/ieee_tc/p2_backend_qualification/d160_20261002
deployment=$source/7b_full_w0_full1/launch.launch/physical_deployment
/usr/bin/time -v -o "$raw/7b_time1.txt" "$python" scripts/analyze_control_path_overhead.py \
  --rpc-breakdown --input "$source/full_full1_request_projection.json" \
  --deployment "$deployment/deployment.json" --terminals "$deployment/request_terminals.jsonl" \
  --sealed-summary paper_results/ieee_tc/p2_backend/20261002_d160_7b_full_w0_full1.json \
  --sealed-sha256 67db3cf4b7a3f7a26d6cbd8f355b398945439f855fc9e1cd0254104fbdc9d777 \
  --output paper_results/ieee_tc/p2_backend/20261002_d161_rpc_7b > "$raw/7b_rpc1.log"
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
cat "/sys/fs/cgroup$cg/memory.events"
date -Is
