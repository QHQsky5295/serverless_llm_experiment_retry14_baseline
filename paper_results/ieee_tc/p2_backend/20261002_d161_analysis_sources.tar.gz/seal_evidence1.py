"""Small D161 evidence seal/package, adapted from D160; no serving replay."""
import ast
import hashlib
import json
import math
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from scripts.ieee_tc_preflight import digest, verify_seal

root = Path.cwd()
raw = root/'results/ieee_tc/p2_backend_qualification/d161_20261002'
out = root/'paper_results/ieee_tc/p2_backend'
verification_path = out/'20261002_d161_evidence_verification.json'
assert not verification_path.exists()
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == '0c8085098ab25edb17b17362cee5a78cc84009a029196147b6f614fc26f998b7'
protocol = root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'
assert digest(protocol) == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert not subprocess.check_output(['git','diff','--name-only','11a5432ecac7ca6214417ffc471c834b6edeb3e3','--','faaslora','scripts','tests','configs/ieee_tc'],text=True).strip()
assert not subprocess.check_output(['git','diff','a494c90c017e5307ff59f1d9ff7c4dde214d6bbf','HEAD','--','faaslora/utils/logger.py','faaslora/__init__.py'],text=True).strip()
refs = {}
curated = []
for dirname in ('20261002_d161_rpc_7b','20261002_d161_selected_sources'):
    directory = out/dirname
    summary = json.loads((directory/'summary.json').read_text())
    assert summary['new_experiment'] is False and summary['formal_performance_result'] is False
    for ref in summary['source_refs']:
        p = Path(ref['path']).resolve()
        assert p.stat().st_size < 64*1024**2
        if str(p) in refs:
            assert refs[str(p)] == ref['sha256']
        else:
            assert digest(p) == ref['sha256'], str(p)
            refs[str(p)] = ref['sha256']
    curated.extend(sorted(directory.iterdir()))
grouped = json.loads((out/'20261002_d161_selected_sources/summary.json').read_text())
full = json.loads((out/'20261002_d160_7b_full_w0_full1.json').read_text())
assert sum(grouped['population'].values()) == 4000
for field, full_field in [('ttft_s','overall_ttft_ms'), ('tpot_s','tpot_ms')]:
    rows = [r for r in grouped['metrics'] if r['field'] == field]
    assert sum(r['count'] for r in rows) == 4000
    mean = math.fsum(r['mean']*r['count'] for r in rows)/4000
    assert abs(mean*1000-full['conditional_success_latency_ms'][full_field]['mean']) < 1e-6
rpc = json.loads((out/'20261002_d161_rpc_7b/summary.json').read_text())
assert rpc['complete_field_coverage'] and rpc['population']['native_success'] == 4000
closures = []
for suffix, expected, receipt in (
    ('rpc-audit1','95b35c5c2da245a089cb9564023684bc','rpc_scope1.txt'),
    ('source-audit1','8243061947c14fc296adfaa6354decb2','source_scope1.txt')):
    unit = f'primelora-d161-{suffix}-20261002.scope'
    assert f'InvocationID={expected}' in (raw/receipt).read_text()
    def prop(name):
        return subprocess.check_output(['systemctl','--user','show',unit,'-p',name,'--value'],text=True).strip()
    assert prop('ActiveState') == 'inactive' and not prop('InvocationID') and not prop('ControlGroup')
    assert not Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service/app.slice',unit).exists()
    closures.append(dict(unit=unit, actual_invocation_id=expected, inactive=True,
        cgroup_absent=True, final_counters='zero observed in completed tool output; removed scope cannot be reread'))
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
for p in raw.glob('*.py'):
    ast.parse(p.read_text(), filename=str(p))
for p in raw.glob('*.sh'):
    subprocess.run(['bash','-n',str(p)],check=True)
curated.append(root/'docs/ieee_tc/D161_RETAINED_CONTROL_DIAGNOSIS.md')
result = dict(kind='d161_retained_control_evidence_verification_v1',
    verified_at=datetime.now(timezone.utc).isoformat(), checks_pass=True,
    formal_performance_result=False, new_inference=False, serving_source_commit='11a5432ecac7ca6214417ffc471c834b6edeb3e3',
    source_refs=[dict(path=p,sha256=sha) for p,sha in sorted(refs.items())],
    curated_refs=[dict(path=str(p.resolve()),sha256=digest(p)) for p in curated],
    weighted_group_reconciliation_pass=True, protected=protected, closures=closures,
    next='One current cap4 prefix diagnostic using unchanged python_frames_v1; not yet launched')
with verification_path.open('x') as f:
    json.dump(result,f,indent=2,allow_nan=False)
# Reuse D160 small-file-only evidence packaging; no projection or dataset.
members = sorted(p for p in raw.iterdir() if p.is_file() and p.stat().st_size < 64*1024
                 and p.suffix in {'.py','.sh','.log','.txt'} and p.name not in ('seal1.log',))
hashes = {p.name:digest(p) for p in members}
bundle = out/'20261002_d161_analysis_sources.tar.gz'
assert not bundle.exists()
with tarfile.open(bundle,'x:gz') as archive:
    for p in members:
        archive.add(p,arcname=p.name,recursive=False)
with tarfile.open(bundle,'r:gz') as archive:
    assert set(archive.getnames()) == set(hashes)
    for name,expected in hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
with (out/'20261002_d161_analysis_sources.sha256').open('x') as f:
    f.write(digest(bundle)+'  '+bundle.name+'\n')
with (out/'20261002_d161_analysis_sources_members.json').open('x') as f:
    json.dump(dict(bundle=bundle.name,member_sha256=hashes,member_checks_pass=True),f,indent=2)
print(json.dumps(dict(verification_sha256=digest(verification_path),
    bundle_sha256=digest(bundle), bundle_bytes=bundle.stat().st_size,
    members=len(members), protected=protected, source_refs=len(refs))))
