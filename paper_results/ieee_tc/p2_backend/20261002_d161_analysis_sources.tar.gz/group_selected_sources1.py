"""D161 conditional diagnosis; reuse D160 verified projection/timeline and CSV writer.

These are endogenous source groups, not causal tier contrasts or new timings.
"""
import csv
import hashlib
import json
import math
from pathlib import Path

from scripts.analyze_control_path_overhead import write_csv

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = ROOT / 'results/ieee_tc/p2_backend_qualification/d161_20261002'
PROJECTION = ROOT / 'results/ieee_tc/p2_backend_qualification/d160_20261002/full_full1_request_projection.json'
TIMELINE = ROOT / 'paper_results/ieee_tc/p2_backend/20261002_d160_control_occupancy/request_occupancy.csv'
SUMMARY = ROOT / 'paper_results/ieee_tc/p2_backend/20261002_d160_7b_full_w0_full1.json'
VERIFICATION = ROOT / 'paper_results/ieee_tc/p2_backend/20261002_d160_evidence_verification.json'
OUTPUT = ROOT / 'paper_results/ieee_tc/p2_backend/20261002_d161_selected_sources'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def stats(values):
    if not values or any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in values):
        raise ValueError('missing or invalid stage observation')
    ordered = sorted(values)
    return dict(count=len(values), mean=math.fsum(values)/len(values),
                p50=ordered[math.ceil(.5*len(values))-1],
                p95=ordered[math.ceil(.95*len(values))-1], max=ordered[-1])


def main():
    assert not OUTPUT.exists()
    assert digest(SUMMARY) == '67db3cf4b7a3f7a26d6cbd8f355b398945439f855fc9e1cd0254104fbdc9d777'
    assert digest(VERIFICATION) == '133aac17696c52e0a71c0e38f427a06c0181cc79230400d9c0ff697fb208f03c'
    assert PROJECTION.stat().st_size < 64*1024**2
    assert digest(PROJECTION) == '9ea2d9c097bd16b0b75cdb3b272f2bf36833a4b999d17434d1dd46153cf5d6fb'
    # D160 verification pins its curated timeline; independently inspect its
    # published shape and use exact path+SHA entry rather than guessing a field.
    verification = json.loads(VERIFICATION.read_text())
    entries = []
    stack = [verification]
    while stack:
        node = stack.pop()
        if isinstance(node, dict):
            if 'path' in node and 'sha256' in node:
                entries.append(node)
            stack.extend(node.values())
        elif isinstance(node, list):
            stack.extend(node)
    matches = [e for e in entries if (ROOT / e['path']).resolve() == TIMELINE.resolve()]
    assert matches and all(e['sha256'] == digest(TIMELINE) for e in matches)
    rows = json.loads(PROJECTION.read_text())['requests']
    with TIMELINE.open(newline='') as handle:
        timelines = list(csv.DictReader(handle))
    by_id = {r['request_id']: r for r in timelines}
    assert len(rows) == len(timelines) == len(by_id) == 4000
    assert {r['request_id'] for r in rows} == set(by_id)
    timeline_fields = ('arrival_to_gate_s', 'gate_to_source_admission_s',
        'source_to_native_dispatch_s', 'native_dispatch_to_last_token_s',
        'last_token_to_controller_completion_s', 'controller_completion_to_terminal_s')
    groups = {}
    observations = []
    for row in rows:
        assert row['success'] is True and row['output_contract_match'] is True
        evidence = row['retained_reference_evidence']
        assert evidence['confirmed_dispatch_snapshot'] is True
        source = evidence['source_admission']['source']
        tier = row['readiness_tier_before_dispatch']
        assert tier in ('gpu', 'host', 'nvme', 'remote') and source['tier'] == tier
        assert type(source['native']) is bool
        label = tier + ('_native' if source['native'] else '_file')
        timeline = by_id[row['request_id']]
        assert timeline['instance_id'] == row['instance_id'] and timeline['success'] == 'True'
        values = {name: float(timeline[name]) for name in timeline_fields}
        values.update(ttft_s=row['overall_ttft_ms']/1000,
                      tpot_s=row['tpot_ms']/1000,
                      routing_observation_s=row['routing_decision_us']/1e6,
                      lora_io_s=row['lora_io_ms']/1000)
        assert abs(values['source_to_native_dispatch_s'] - row['native_token_timing']['admission_to_engine_dispatch_ms']/1000) < 1e-6
        groups.setdefault(label, []).append(values)
        observations.append(dict(request_id=row['request_id'], source=label, **values))
    metrics = [dict(source=label, field=field, unit='s', **stats([r[field] for r in group]))
               for label, group in sorted(groups.items()) for field in group[0]]
    OUTPUT.mkdir()
    write_csv(metrics, OUTPUT/'metrics.csv')
    write_csv(observations, OUTPUT/'request_stages.csv')
    result = dict(kind='conditional_selected_source_stage_audit_v1', new_experiment=False,
        formal_performance_result=False, quantile='Type-1', native_completed=4000,
        population={label:len(group) for label,group in sorted(groups.items())}, metrics=metrics,
        source_refs=[dict(path=str(path.resolve()), sha256=digest(path))
                     for path in (PROJECTION,TIMELINE,SUMMARY,VERIFICATION,Path(__file__))],
        caveats=['Source groups are selected by this execution, not common randomized causal groups.',
                 'Generation count/recorded identity does not prove numerical adapter correctness or common SLO.',
                 'Routing and lora_io timers overlap timeline stages; do not add their means/percentiles.',
                 'lora_io and routing spans include awaits and controller scheduling, not isolated disk/network/CPU service.',
                 'No direct per-operation source RPC/CPU duration is retained; no bottleneck function is proven.'])
    with (OUTPUT/'summary.json').open('x') as handle:
        json.dump(result, handle, indent=2, allow_nan=False)
    print(json.dumps(result['population'], sort_keys=True))


if __name__ == '__main__':
    assert stats([3.,1.,2.]) == dict(count=3,mean=2.,p50=2.,p95=3.,max=3.)
    for invalid in ([], [float('nan')], [-1.], [True]):
        try:
            stats(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError('invalid statistics input accepted')
    main()
