"""Exact-owned closure extended only for push resumption and pre-launch retry."""
import hashlib
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d668_20261018/close.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='2275f5fb7959fb2df7bf13a67cce7f4ebcd226a232ca9d6ecb5ec00d013ca68a'
code=data.decode()
assert code.count("'qualification','qualification2'")==1
code=code.replace("'qualification','qualification2'", "'backup_retry','start2','qualification','qualification2'")
exec(compile(code,str(source),'exec'))
