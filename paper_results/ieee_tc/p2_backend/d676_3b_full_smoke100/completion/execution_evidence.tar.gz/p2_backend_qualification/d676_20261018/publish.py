"""Reuse D659 publication guards; retain D676 prelaunch and rejected-start evidence."""
import ast
import hashlib
from pathlib import Path
import sys

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d659_20261018/publish.py')
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'e34668af9152224ab85f37d21c097362dc66222c8c4fd6e7daa525cc4c159bfb'
code = data.decode()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)

replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d659_3b_full_smoke100'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d676_3b_full_smoke100/completion'")
replace("expected_head='8a30f65fbeeeb8b79e83ad40c4d388a6a080b525'",
        "expected_head='4d5c011b8ce9eea45ee9bf39fe685e9b2d2dbed6'")
replace("assert audit['passed'] and audit['protocol_bound_count']==100",
        "assert audit['passed'] and audit['protocol_bound_count']==100\nassert audit['host_transaction']['passed']\nassert audit['proactive_host_transaction']['passed']\nassert audit['proactive_host_transaction']['storage_counts']['same_transaction_proactive_host_activation_v1']>0")
replace("for phase in ('start','analysis'):",
        "for phase in ('start','start2','analysis'):")
start = code.index("previous=RAW.parent/'d658_20261018'")
end = code.index("save(OUT/'manifest.json'", start)
code = code[:start] + '''prelaunch=OUT.parent
assert p.digest(prelaunch/'result.sha256')=='11b83eadf47e76a5e24e478fc8663f719de7700c6f9adfe31f59ffa456a8daf9'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=prelaunch,check=True,stdout=subprocess.DEVNULL)
for phase in ('qualification','backup','backup_retry','start2'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert read(RAW/'start_receipt.json')['starter_identity']==read(RAW/'start2_identity.json')
members += [RAW/name for name in (
    'backup_identity.json','backup_receipt.json','backup_closure.json',
    'resume_backup.py','backup_retry_identity.json','backup_retry_receipt.json','backup_retry_closure.json',
    'close_management.py','start2.py','start2_identity.json','start2_closure.json',
    'collect_closure2.py','run_analysis2.py')]
''' + code[end:]
replace("kind='d659_3b_prefix100_seal_v1'", "kind='d676_3b_proactive_host_transaction_prefix100_seal_v1'")
replace("n_native_bound=100,joint_slo_count=audit['common_threshold_joint_count'],",
        "n_native_bound=100,joint_slo_count=audit['common_threshold_joint_count'],\n    host_transaction=audit['host_transaction'],\n    proactive_host_transaction=audit['proactive_host_transaction'],\n    rejected_start_before_gpu_preserved=True,backup_same_commit_retry_preserved=True,\n    immutable_prelaunch_manifest_sha256=p.digest(prelaunch/'result.sha256'),\n    reused_publication_helper=dict(path=str(source),sha256=hashlib.sha256(data).hexdigest()),")
replace('docs/ieee_tc/D659_3B_FULL_PREFIX_QUALIFICATION.md',
        'docs/ieee_tc/D676_3B_HOST_TRANSACTION_NATIVE_QUALIFICATION.md')
replace('tc: seal current 3B Full native prefix qualification and SLO limits (D659)',
        'tc: seal proactive HOST transaction native qualification and startup history (D676)')
ast.parse(code)
if sys.argv[1:] == ['--check-only']:
    print('D676 completion publication adaptation parsed; no writes.')
elif not sys.argv[1:]:
    exec(compile(code, str(source), 'exec'))
else:
    raise SystemExit('expected no args or --check-only')
