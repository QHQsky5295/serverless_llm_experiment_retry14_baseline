"""Use the actual-starter collector; all analytical checks remain unchanged."""
from pathlib import Path
source=Path(__file__).with_name('run_analysis.py')
code=source.read_text()
assert code.count("raw/'collect_closure.py'")==1
code=code.replace("raw/'collect_closure.py'","raw/'collect_closure2.py'")
exec(compile(code,str(source),'exec'))
