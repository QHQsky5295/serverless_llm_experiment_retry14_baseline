"""Retry only the existing commit push after TLS failure; never recommit/repackage."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/p2_backend/d676_3b_full_smoke100'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(name,obj):
    with (RAW/name).open('x') as f:json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save('backup_retry_identity.json',identity)
assert os.sched_getaffinity(0)=={2,3,26,27}
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert not (RAW/'backup_receipt.json').exists()
assert not (RAW/'remote_start.log').exists() and not (RAW/'3b_full_smoke100').exists()
for phase in ('qualification','backup','start'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='4d5c011b8ce9eea45ee9bf39fe685e9b2d2dbed6'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
names=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',head],cwd=ROOT,text=True).splitlines()
assert len(names)==8 and 'configs/generated/lora_manifest_1000.json' not in names
for name in names:assert subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
for path,sha in read(RAW/'qualification.json')['refs'].items():assert p.digest(Path(path))==sha
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
preserved=read(RAW.parent/'d675_20261018/qualification3_receipt.json')['preserved']
for path,sha in preserved.items():assert p.digest(Path(path))==sha
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass']
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert remote==head
record=dict(passed=True,head=head,remote=remote,identity=read(RAW/'backup_identity.json'),
    retry_identity=identity,files=names,preserved=preserved,protected=protected,
    retry_scope='same existing commit push only',prior_error='git push TLS handshake failure; no GPU or remote start')
save('backup_receipt.json',record)
save('backup_retry_receipt.json',record)
print(json.dumps(dict(passed=True,head=head,remote_equal=True,files=len(names))))
