"""Bind collection to the actual second starter, retaining the prelaunch rejection."""
from pathlib import Path
source=Path(__file__).with_name('collect_closure.py')
code=source.read_text()
assert code.count("raw/'start_closure.json'")==1
code=code.replace("raw/'start_closure.json'","raw/'start2_closure.json'")
exec(compile(code,str(source),'exec'))
