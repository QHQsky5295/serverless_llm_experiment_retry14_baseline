"""Original launch was rejected before remote/GPU start; preserve its identity."""
import json
from pathlib import Path
RAW=Path(__file__).resolve().parent
assert not (RAW/'remote_start.log').exists() and not (RAW/'3b_full_smoke100').exists()
for name in ('start','backup_retry'):
    closed=json.loads((RAW/(name+'_closure.json')).read_text())
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
source=RAW/'start.py'
code=source.read_text()
assert code.count("save(RAW/'start_identity.json',identity)")==1
code=code.replace("save(RAW/'start_identity.json',identity)","save(RAW/'start2_identity.json',identity)")
exec(compile(code,str(source),'exec'))
