"""Reuse D660 prelaunch checkpoint for same-configuration D676 prefix."""
import ast
import hashlib
from pathlib import Path
import sys
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d660_20261018/backup.py')
data=source.read_bytes()
assert hashlib.sha256(data).hexdigest()=='6839c566c03aebe258a0580d2d021a701e424c9402447d871d34d2d1d8e5af04'
code=data.decode()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d660_3b_full_w0'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d676_3b_full_smoke100'")
replace('9fe8ffc78ce338b80c5836d1bd4d5a82511b5d48','4989dbf33bd47a283efa32c752a7fc15beec7430')
replace("preparation['count']==4000","preparation['count']==100")
replace("qualification['count']==4000 and qualification['reused_cpu_tests']==6",
        "qualification['count']==100 and qualification['reused_cpu_tests']==697")
replace("same_configuration_as_d659_except_population_and_paths","same_configuration_as_d659_except_paths")
replace("files=['prelaunch.json']","files=['prelaunch.json','preparation.json']")
replace("previous=RAW.parent/'d659_20261018'","previous=RAW.parent/'d675_20261018'")
replace("closed=read(previous/'publication_closure.json')","closed=read(previous/'backup_closure.json')")
replace("('publication_identity.json','publication_receipt.json','publication_closure.json')",
        "('backup_identity.json','backup_receipt.json','backup_closure.json')")
replace('D660_3B_FULL_W0.md','D676_3B_HOST_TRANSACTION_NATIVE_QUALIFICATION.md')
replace('20261018_d660_3b_full_w0.yaml','20261018_d676_3b_full_smoke100.yaml')
replace('tc: freeze unchanged 3B Full configuration for complete W0 replay (D660)',
        'tc: freeze native HOST transaction qualification with unchanged 3B setup (D676)')
ast.parse(code)
if sys.argv[1:]==['--check-only']:print('D676 prelaunch adaptation parsed; no writes.')
elif not sys.argv[1:]:exec(compile(code,str(source),'exec'))
else:raise SystemExit('expected no args or --check-only')
