"""Reuse full W2 analyzer, retain its strict output, expose new lifecycle evidence."""
import contextlib
import io
import ijson
import json
from pathlib import Path
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
# The parent post-release collector owns and records the shared analysis scope.
source=RAW/'analyze_prefix.py'
out=io.StringIO()
with contextlib.redirect_stdout(out):
    exec(compile(source.read_text(),str(source),'exec'),dict(__file__=str(source),__name__='d615_audit'))
result=json.loads(out.getvalue())
with (RAW/'actual_qualification.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
with (RAW/'7b_three_replica_full_w2/launch.launch/physical_deployment/main_outcome.json').open('rb') as handle:
    cpu_preparation=next(ijson.items(handle,'cpu_frontend_preparation',use_float=True))
with (RAW/'cpu_preparation_evidence.json').open('x') as f:
    json.dump(cpu_preparation,f,indent=2,allow_nan=False)
outcome = RAW/'7b_three_replica_full_w2/launch.launch/physical_deployment/main_outcome.json'
def selected(prefix):
    with outcome.open('rb') as stream:
        return next(ijson.items(stream,prefix,use_float=True))
initial = selected('mechanism_events._ieee_initial_deployment')
control = selected('mechanism_events._ieee_control_events')
activations = selected('mechanism_events._ieee_activations')
assert control and all(row['ready_instances']+row['pending_instances']<=3 for row in control)
assert all(row['target_instances']<=3 for row in control)
with (RAW/'realized_replica_cap.json').open('x') as f:
    json.dump(dict(passed=True,samples=len(control),configured_max_instances=3,
        max_ready_plus_pending=max(row['ready_instances']+row['pending_instances'] for row in control),
        max_target=max(row['target_instances'] for row in control),
        physical_holding_is_independently_measured=True),f,indent=2,allow_nan=False)
assert initial['control_policy']=='observed_arrivals_v1' and initial['state']=='serving'
assert not initial['failures']
assert initial['control_start_at']<=initial['first_ready_at']
early = [row for row in control if row['observed_at']<initial['first_ready_at']]
scheduled = [row for row in early if row['outcome']=='activation_scheduled']
early_natural = [row for row in activations if row['category']=='natural_scaleout'
                 and row['trigger_at']<initial['first_ready_at']]
mechanism = dict(initial=initial,early_control=early,early_scheduled=scheduled,
    early_natural_activations=early_natural,
    native_early_control_triggered=bool(scheduled and early_natural),
    no_forced_delay_or_cache_reset=True,performance_benefit_proved=False,
    caveat='Natural initial readiness may precede business arrivals; absence of early scale-out is not a trigger proof.')
with (RAW/'initial_control_evidence.json').open('x') as f:
    json.dump(mechanism,f,indent=2,allow_nan=False)
print(json.dumps(dict(passed=result['passed'],stats=result['stats'],
    joint=result['common_threshold_joint_count'],tokens=result['native_tokens'],
    activation=result['activation_state_counts'],resources=result['resources'],
    cpu_preparation_count=len(cpu_preparation['records'])),indent=2))
