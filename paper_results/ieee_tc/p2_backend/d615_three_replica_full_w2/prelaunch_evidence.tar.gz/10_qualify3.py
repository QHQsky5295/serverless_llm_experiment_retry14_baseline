"""D615 attempt3: reuse the established bounded CPU-test interpreter; same serving configuration."""

def main():
    import ast, copy, io, json, os, subprocess, sys, unittest
    from pathlib import Path
    import yaml
    ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
    RAW=Path(__file__).resolve().parent
    sys.path.insert(0,str(ROOT))
    from scripts import ieee_tc_preflight as p
    from faaslora.datasets.workload_generator import FrozenReplayPlan
    from faaslora.coordination.autoscaler import IEEEReplicaControl, ScalingAction
    def read(path):return json.loads(path.read_text())
    def save(path,obj):
        with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
    identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
    save(RAW/'qualification3_identity.json',identity)
    assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
    assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
    assert (cg/'memory.swap.max').read_text().strip()=='0'
    assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='2fa8c026663f7ace1ac187847d7e6a4320a715bf'
    previous=RAW.parent/'d610_20261017'
    for name in ('focused_receipt.json','regression_receipt.json'):
        reg=read(previous/name);assert reg['passed'] and reg['returncode']==0
        for path,sha in reg['sources'].items():assert p.digest(Path(path))==sha,path
    for phase in ('focused','regression','publication','component3'):
        closed=read(previous/(phase+'_closure.json'))
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists()
    assert read(previous/'component_result3.json')['passed']
    storage_view=RAW.parent.parent/'storage_maintenance/d613_20261017/storage_result.json'
    assert storage_view.is_file()
    for phase in ('storage','publication'):
        maintenance=read(storage_view.parent/(phase+'_closure.json'))
        assert maintenance['passed'] and maintenance['actual_recursive_procs_empty'] and maintenance['path_gone']
        assert not Path(maintenance['identity']['path']).exists()
    parent=RAW.parent/'d611_20261017'
    for phase in ('analysis','publication'):
        closed=read(parent/(phase+'_closure.json'))
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists()
    assert read(parent/'actual_qualification.json')['passed']
    gate=p.preflight([ROOT],32*p.GIB)
    assert gate['preflight_pass'],gate['issues']
    old=read(RAW.parent/'d550_20261015/qualification.json')
    for path,sha in old['preserved'].items():assert p.digest(Path(path))==sha,path
    w2=read(parent/'qualification.json')['prime_plan']
    plan=FrozenReplayPlan.load(w2['source_path'],profile='W2',adapter_map=w2['adapter_map'],adapter_map_sha256=w2['adapter_map_sha256'])
    assert plan.identity()==w2 and len(plan.entries)==4000
    assert FrozenReplayPlan.from_launch_context(dict(plan=w2,tiny_witness=False))==plan
    paths=[ROOT/'configs/ieee_tc/20261017_d611_7b_inventory_extent_full_w2.yaml',
           ROOT/'configs/ieee_tc/20261017_d615_7b_three_replica_full_w2.yaml']
    configs=[yaml.safe_load(path.read_text()) for path in paths]
    normalized=copy.deepcopy(configs)
    for row in normalized:
        row['experiment'].pop('output_dir')
        row['storage'].pop('nvme_cache_dir');row['storage'].pop('host_cache_dir')
    assert normalized[0]['resource_coordination']['max_instances']==4
    assert normalized[1]['resource_coordination']['max_instances']==3
    normalized[1]['resource_coordination']['max_instances']=4
    assert normalized[0]==normalized[1], 'unregistered model/policy/configuration difference'
    assert configs[1]['model']['visible_device_ids']==configs[1]['hardware']['gpu_device_ids']==[0,1,2,3]
    assert configs[1]['resource_coordination']['min_instances']==1
    for path in (Path(configs[1]['experiment']['output_dir']),Path(configs[1]['storage']['nvme_cache_dir']),Path(configs[1]['storage']['host_cache_dir'])):
        assert not path.exists(),path
    shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
    body=shell.read_text();start=body.index('  d615)\n');end=body.index('    ;;\n',start)+len('    ;;\n')
    branch=body[start:end]
    assert paths[1].name in branch and 'PREFIX_COUNT=\n' in branch
    restored=(body[:start]+body[end:]).replace(' || "${1:-d293}" == d615','')
    assert restored==subprocess.check_output(['git','show','HEAD:'+str(shell.relative_to(ROOT))],cwd=ROOT,text=True)
    helpers=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),shell])
    for path in helpers:
        if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
        else:subprocess.run(['bash','-n',str(path)],check=True)
    observer_line=next(line for line in body.splitlines() if line.startswith('if [[') and 'd328' in line)
    assert 'd615' not in observer_line
    
    # Use the actual new model configuration, not a rewritten controller or trace.
    cfg=configs[1]['resource_coordination']
    def controller():
        return IEEEReplicaControl(cfg['ieee_scaling'],interval_s=cfg['scale_eval_interval_s'],
            min_instances=cfg['min_instances'],max_instances=cfg['max_instances'])
    cases=[]
    for ready in range(4):
        for pending in range(4-ready):
            capacity=ready*configs[1]['model']['runtime_concurrency_cap']
            for active in sorted({0,capacity}):
                for queue in (0,8,9):
                    for ttft in (None,100.,5000.,5001.):
                        ctrl=controller()
                        if ttft is not None:ctrl.observe_ttft('observed',ttft,observed_at=0.)
                        row=ctrl.evaluate(now=0.,queue_depth=queue,active_requests=active,
                            ready_capacity=capacity,ready_instances=ready,pending_instances=pending)
                        expected_saturation=active/capacity if capacity else 0.
                        ratios=[queue/8,expected_saturation/.5]
                        if ttft is not None:ratios.append(ttft/5000.)
                        score=max(ratios);total=ready+pending
                        up=score>1 and total<3
                        assert row['score']==score and row['active_saturation']==expected_saturation
                        assert row['action']==(ScalingAction.SCALE_UP if up else ScalingAction.NO_ACTION)
                        assert row['target_instances']==total+int(up)<=3
                        cases.append(dict(ready=ready,pending=pending,active=active,queue=queue,
                            ttft_ms=ttft,target=row['target_instances'],score=score))
    ctrl=controller();ctrl.observe_ttft('fast',100.,observed_at=0.)
    def low(now,ready,pending=0):
        return ctrl.evaluate(now=now,queue_depth=0,active_requests=0,ready_capacity=14*ready,
            ready_instances=ready,pending_instances=pending)
    assert low(0.,3)['action']==ScalingAction.NO_ACTION
    assert low(36.,3)['action']==ScalingAction.NO_ACTION
    assert low(38.,3)['action']==ScalingAction.SCALE_DOWN
    ctrl=controller();ctrl.observe_ttft('fast',100.,observed_at=0.)
    assert low(0.,2,1)['action']==ScalingAction.NO_ACTION and ctrl.low_since is None
    assert low(38.,2,1)['action']==ScalingAction.NO_ACTION and ctrl.low_since is None
    ctrl=controller();ctrl.observe_ttft('fast',100.,observed_at=0.)
    assert low(0.,1)['action']==ScalingAction.NO_ACTION
    assert low(38.,1)['action']==ScalingAction.NO_ACTION
    control_checks=dict(passed=True,case_count=len(cases),cases=cases,
        actual_model_configuration=True,unchanged_max_score=True,pending_not_ready=True,
        upper_bound=3,lower_bound=1,unchanged_cooldown_s=38.)
    save(RAW/'three_replica_checks3.json',control_checks)
    test_names=['tests.test_ieee_tc_launch.'+name for name in
        ('IEEEControlContract','IEEEActualControl','IEEEInitialObservedControl')]
    suite=unittest.defaultTestLoader.loadTestsFromNames(test_names)
    with (RAW/'control_tests3.log').open('x') as stream:
        tested=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    assert tested.wasSuccessful() and not tested.skipped
    save(RAW/'control_tests3.json',dict(passed=True,names=test_names,tests_run=tested.testsRun,
        failures=len(tested.failures),errors=len(tested.errors),skipped=len(tested.skipped)))
    buildpath=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
    build=read(buildpath);assert build['passed'] and build['actual_closure']['path_gone']
    for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256']
    protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
    assert protected['pass'] and protected['entry_count']==147
    refs=[*helpers,*paths,previous/'focused_receipt.json',previous/'regression_receipt.json',
          previous/'component_result3.json',previous/'component3_closure.json',buildpath,storage_view,
          storage_view.parent/'storage_closure.json',storage_view.parent/'publication_closure.json',
          parent/'actual_qualification.json',parent/'analysis_closure.json',parent/'publication_closure.json',
          RAW/'three_replica_checks3.json',RAW/'control_tests3.json',RAW/'control_tests3.log',
          ROOT/'docs/ieee_tc/D614_RESOURCE_WORKING_POINT_AUDIT.md',
          ROOT/'faaslora/coordination/autoscaler.py',ROOT/'tests/test_ieee_tc_launch.py',
          RAW.parent/'d550_20261015/close.py',ROOT/'faaslora/datasets/workload_generator.py',
          ROOT/'faaslora/scheduling/resource_coordinator.py',ROOT/'scripts/run_all_experiments.py',
          ROOT/'faaslora/utils/logger.py',ROOT/'faaslora/memory/residency_manager.py',
          ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json',
          ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
    for key in ('ieee_service_profile','ieee_preparation_profile'):
        ref=configs[1]['resource_coordination'][key];path=Path(ref['path'])
        assert p.digest(path)==ref['sha256'];refs.append(path)
    subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
    import torch
    assert not torch.cuda.is_initialized()
    save(RAW/'qualification.json',dict(passed=True,scope=identity,protected=protected,preserved=old['preserved'],
        prime_plan=plan.identity(),source_count=4000,count=4000,
        configuration_changes={'resource_coordination.max_instances':{'before':4,'after':3}},
        unchanged_other_model_control_settings=True,three_replica_checks=control_checks,
        control_tests_run=tested.testsRun,reused_cpu_regression_tests=406,reused_focused_tests=16,reused_input_tests=386,
        observer=None,ordinary_full_replay=True,ranking_eligible=False,preflight=gate,
        refs={str(path):p.digest(path) for path in refs},
        resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
    print(json.dumps(dict(passed=True,count=4000,profile='W2',config_change='max_instances:4->3',
        control_cases=len(cases),control_tests=tested.testsRun,reused_tests=406,reused_focused_tests=16,observer=None)))

if __name__ == "__main__":
    main()
