"""Reuse exact-owned closure, adding only the third qualification identity."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')
body=source.read_text()
old="('qualification','qualification2','backup','start','analysis','analysis2','publication','publication2')"
assert body.count(old)==1
body=body.replace(old,"('qualification','qualification2','qualification3','backup','start','analysis','analysis2','publication','publication2')")
exec(compile(body,str(source),'exec'))
