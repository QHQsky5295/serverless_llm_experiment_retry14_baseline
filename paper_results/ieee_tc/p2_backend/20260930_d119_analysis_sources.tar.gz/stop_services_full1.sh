#!/usr/bin/env bash
set -euo pipefail
# Existing D110 exact-identity cleanup, adapted to D119. Execute remotely ONLY
# after local main exit and GPU cleanup; never while inference is running.
date -Is
units=(primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service primelora-artifact-monitor-d119full1.service)
ids=(66f077b5f202402486ee49278f17b87d 22d08ca215294f89a5c71b99c3ec47ce 051781bade274046b281880a87330673)
pids=(4088714 4088716 4088719)
for i in 0 1 2; do
  test "$(systemctl --user show "${units[$i]}" -p ActiveState --value)" = active
  test "$(systemctl --user show "${units[$i]}" -p InvocationID --value)" = "${ids[$i]}"
  test "$(systemctl --user show "${units[$i]}" -p MainPID --value)" = "${pids[$i]}"
done
systemctl --user stop "${units[0]}" "${units[1]}"
systemctl --user stop "${units[2]}"
for unit in "${units[@]}"; do
  test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
  test "$(systemctl --user show "$unit" -p MainPID --value)" = 0
done
systemctl --user show "${units[@]}" -p Id -p ActiveState -p MainPID -p Result
