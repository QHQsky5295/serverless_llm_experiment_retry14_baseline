"""Reuse D118 source/resource checks with D92's already assembled 7B contract."""
import json
from pathlib import Path
import subprocess
import time
import yaml
from scripts.ieee_tc_preflight import verify_seal, digest, preflight
from faaslora.runtime_configuration import resolve_facade_lora_capacity

root = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
raw = root/'results/ieee_tc/p2_backend_qualification/d119_20260930'
previous = root/'results/ieee_tc/p2_backend_qualification/d118_20260930'
expected_commit = 'b4c194b54a277cfd991cfe8f58c3ac63140be12e'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected_commit
dirty = subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(dirty) <= {'configs/generated/lora_manifest_1000.json','docs/ieee_tc/EXECUTION_STATUS.md'}, dirty
assert digest(Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')) == 'fe6c05b008c01b89316b7953d73fc7ad9e3b4763e35bd63d3c46594049310c5c'
assert digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
old_path = root/'results/ieee_tc/p2_backend_qualification/d92_20260928/7b_main_config_attempt1.yaml'
old = yaml.safe_load(old_path.read_text())
new = yaml.safe_load((raw/'7b_main_config_full1.yaml').read_text())
for config in (old,new):
    del config['experiment']['output_dir']
    del config['storage']['nvme_cache_dir']
    del config['storage']['host_cache_dir']
assert old == new, '7B configuration changed beyond three fresh owned paths'
assert not (raw/'7b_full_w0_full1/launch.json').exists()
assert not (raw/'7b_nvme_full1/tc_ieee_full').exists()
assert not Path('/dev/shm/tc-d119-7b-full1/tc_ieee_full').exists()
before = json.loads((previous/'prelaunch_verification.json').read_text())
refs = dict(before['source_sha256'])
for name, expected in refs.items():
    path = Path(name) if name.startswith('/') else root/name
    assert digest(path) == expected, name
full = root/'paper_results/ieee_tc/p2_backend/20260930_d118_3b_full_w0_full11.json'
assert digest(full) == 'ff39d2b0fbb952f6bf1d0601115eff9888895b13d0a9b6c2d062c2fbef376eaf'
done = json.loads(full.read_text())
assert done['execution_completed'] and done['launcher_cleanup_pass'] and done['native_contract_completion_pass']
manifest_path = root/'paper_results/ieee_tc/p2_backend/d89_7b_initialization/manifest.json'
manifest = json.loads(manifest_path.read_text())
contract_path = root/manifest['contract']['path']
assert digest(contract_path) == manifest['contract']['sha256']
contract = json.loads(contract_path.read_text())
# D92 parent source is retained; child resolution occurs in the existing runner.
model = resolve_facade_lora_capacity(new['model'])
assert model['max_cpu_loras'] == 24 and model['runtime_concurrency_cap'] == 2
assembly_path = root/'results/ieee_tc/p2_backend_qualification/d92_20260928/main_assembly.json'
assembly = json.loads(assembly_path.read_text())
record, = [r for r in assembly['records'] if r['model'] == '7b']
assert record['pass'] and record['one_runtime_capacity'] == 2 and record['four_runtime_capacity'] == 8
assert digest(old_path) == record['config']['sha256']
trace = Path(record['trace']['source_path'])
subset = Path(record['subset']['path'])
assert digest(trace) == record['trace']['source_sha256']
assert digest(subset) == record['subset']['sha256']
for binding in manifest['bindings'].values():
    path = Path(binding['path'])
    assert digest(path) == binding['sha256']
    refs[str(path)] = binding['sha256']
content = Path(new['model']['artifact_content_manifest_path'])
assert digest(content) == 'e85cce3c3611da15530f9e663549231d3493282c85913344fe41c2a67044260c'
for path in [raw/name for name in ('7b_main_config_full1.yaml','run_7b_full_w0_full1.sh',
    'activate_services_full1.sh','check_health.sh','verify_full1_prelaunch.py')]+[
    full,manifest_path,contract_path,assembly_path,old_path,trace,subset,content]:
    refs[str(path)] = digest(path)
protected = verify_seal(root/'paper_results/ieee_tc/safety/20260925_execution_start_protected.json')
assert protected['pass'] and protected['entry_count'] == 147
resources = preflight([root,raw],32*1024**3)
assert resources['preflight_pass'], resources['issues']
receipt = dict(kind='d119_7b_full_prelaunch_v1',time_unix=time.time(),
    run='d119_7b_full_w0_full1',evidence_commit=expected_commit,
    runtime_source_commit=expected_commit,source_change='none_since_D118',
    same_configuration_except_owned_paths=True,diagnostic_instrumentation=False,
    formal_performance_result=False,source_sha256=refs,protected=protected,
    resource_preflight=resources,trace=record['trace'],subset=record['subset'],
    metric_protocol_sha256=digest(root/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    comparison='First canonical 7B Full development replay; no CI or formal SLO claim.',
    pending_metric_reconciliation='Controller completion vs outer terminal: preserve both, no relabeling.',
    reused_initialization='D88/D89; D92 7B parent config, no new profiles/data/cache',
    native_generation_qualification_is_not_numerical_adapter_qualification=True)
with (raw/'prelaunch_verification.json').open('x') as h:
    json.dump(receipt,h,indent=2,allow_nan=False)
print(json.dumps(dict(output=str(raw/'prelaunch_verification.json'),sha256=digest(raw/'prelaunch_verification.json'),
    protected=147,source_refs=len(refs),same_config=True,resource_pass=True,formal=False)))
