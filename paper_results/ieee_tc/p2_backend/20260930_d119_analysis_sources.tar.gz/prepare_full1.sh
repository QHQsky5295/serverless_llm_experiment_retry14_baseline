#!/usr/bin/env bash
set -euo pipefail
set -o noclobber
MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline
cd "$MAIN"
raw=results/ieee_tc/p2_backend_qualification/d119_20260930
unit=primelora-d119-prelaunch-20260930.scope
test "$(systemctl --user show "$unit" -p MemoryHigh --value)" = 3221225472
test "$(systemctl --user show "$unit" -p MemoryMax --value)" = 4294967296
test "$(systemctl --user show "$unit" -p MemorySwapMax --value)" = 0
test "$(awk '/Cpus_allowed_list/{print $2}' /proc/self/status)" = '2-3,26-27'
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
systemctl --user show "$unit" -p InvocationID -p ControlGroup -p TasksCurrent -p MemoryHigh -p MemoryMax -p MemorySwapMax > "$raw/prelaunch_scope.txt"
PYTHONPATH="$MAIN" /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python "$raw/verify_full1_prelaunch.py" > "$raw/prelaunch.log" 2>&1
cat /sys/class/net/eno1np0/speed /sys/class/net/eno1np0/duplex > "$raw/local_nic.txt"
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 primelora-artifact-174 'date -Is; cat /sys/class/net/eno1/speed /sys/class/net/eno1/duplex; free -b; df -B1 /home/lab14/primelora_remote/tc/d80_20260927; systemctl --user show primelora-artifact-tc-3b.service primelora-artifact-tc-7b.service -p Id -p ActiveState -p MainPID' > "$raw/remote_prelaunch.txt" 2>&1
ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=8 primelora-artifact-174 bash -s < "$raw/activate_services_full1.sh" > "$raw/remote_activation.txt" 2>&1
