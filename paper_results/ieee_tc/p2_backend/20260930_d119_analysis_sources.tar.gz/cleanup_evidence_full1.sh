#!/usr/bin/env bash
set -euo pipefail
# Reuse D115 exact-identity / empty-domain cleanup; only D119 identities differ.
date -Is
test "$(systemctl --user show primelora-tc-svc-000a149ae35346edac1e54ffb0f0895e.scope -p ActiveState --value)" = inactive
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
unit=primelora-d119-full1-evidence-20260930.scope
test "$(systemctl --user show "$unit" -p InvocationID --value)" = 1746d3a5319544e381037ab7f1c09a23
test "$(systemctl --user show "$unit" -p TasksCurrent --value)" = 0
cg=$(systemctl --user show "$unit" -p ControlGroup --value)
test "$cg" = /user.slice/user-1001.slice/user@1001.service/app.slice/primelora-d119-full1-evidence-20260930.scope
test -d "/sys/fs/cgroup$cg"
test -z "$(cat "/sys/fs/cgroup$cg/cgroup.procs")"
rg -q '^populated 0$' "/sys/fs/cgroup$cg/cgroup.events"
cat "/sys/fs/cgroup$cg/memory.events"
systemctl --user stop "$unit"
test "$(systemctl --user show "$unit" -p ActiveState --value)" = inactive
systemctl --user show "$unit" -p ActiveState -p InvocationID -p TasksCurrent
