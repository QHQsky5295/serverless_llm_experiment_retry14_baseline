"""Close exact-owned launcher and retain the pre-request 3B failure evidence."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save('analysis_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
run=read(RAW/'source1.json');launch=read(RAW/'source1_launch.json')
assert run['pass'] is False and run['stage']=='engine_initialization' and run['requests']==[]
assert run['remote_transfers']==[] and run['profile_workspaces_removed'] is True
assert launch['pass'] is False and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
launcher=read(RAW/'launcher_identity.json')
assert p.scope_still_owned(launcher) and launcher['path']==launch['auxiliary']['path']
group=Path(launcher['path'])
members={str(path):path.read_text().split() for path in group.rglob('cgroup.procs')}
assert members and all(not value for value in members.values())
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(launcher)
subprocess.run(['systemctl','--user','stop',launcher['unit']],check=True)
assert not group.exists()
save('local_cleanup.json',dict(passed=True,identity=launcher,actual_recursive_procs_empty=True,
    path_gone=True,resources=resources,service_path_removed=True,native_gpu_context_release_confirmed=True))
remote_stop=(RAW/'remote_stop.log').read_text()
assert remote_stop.count('ActiveState=inactive')==3 and remote_stop.count('MainPID=0')==3
remote='/home/lab14/primelora_remote/tc/d641_20261017/remote_monitor.log'
remote_sha=subprocess.check_output(['ssh','-o','BatchMode=yes','primelora-artifact-174','sha256sum',remote],text=True).split()[0]
assert not (RAW/'remote_monitor.log').exists()
subprocess.run(['scp','-q','-o','BatchMode=yes','primelora-artifact-174:'+remote,str(RAW/'remote_monitor.log')],check=True)
assert p.digest(RAW/'remote_monitor.log')==remote_sha
save('remote_stop.json',dict(passed=True,all_owned_units_inactive=True,download_hash_matches=True,
    remote_monitor_sha256=remote_sha,transfer_requests_observed=0,remote_transfer_log_for_clock_not_created=True))
worker=Path('/tmp/faaslora_worker_hvb5tw5p')
process=read(worker/'process.json');assert process['pid']==4067415
assert not Path('/proc/4067415').exists() and not Path('/proc/4067951').exists()
copied={}
for name in ('worker.log','payload.json','process.json'):
    destination=RAW/('failed_worker_'+name)
    assert not destination.exists()
    source=worker/name
    sha=p.digest(source)
    shutil.copy2(source,destination)
    assert p.digest(destination)==sha and p.digest(source)==sha
    copied[name]=dict(source=str(source),copy=str(destination),sha256=sha)
events=[json.loads(line) for line in (RAW/'source1_launch.launch/physical_allocations/04c8e469fe8d4ab6a14c2bada724f2b3.jsonl').read_text().splitlines()]
assert [e['event'] for e in events]==['acquire','worker_spawn','release_deferred']
assert events[-1]['reason']=='native_worker_lifetime_unqualified'
watch=[]
for line in (RAW/'source1_launch.launch/watchdog.jsonl').open():
    item=json.loads(line)
    if item.get('event')=='resource_sample':watch.append(item)
assert watch
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
record=dict(kind='d641_3b_pre_request_startup_failure_v1',passed=True,experiment_pass=False,
    source_execution_commit=(RAW/'source_commit.txt').read_text().strip(),
    request_cases_planned=368,requests_started=0,requests_completed=0,
    error=run['error'],error_type=run['error_type'],traceback=run['traceback'],
    startup_timeout_default_s=180,spawn_to_release_deferred_s=events[-1]['at']-events[1]['at'],
    known_main_runner_startup_limit_s=600,
    startup_ready_not_observed=True,underlying_initialization_delay_cause='not established',
    release_error_masks_startup_failure=True,physical_lifecycle_qualified=False,
    main_performance_point=False,full_profile_eligible=False,n_correct=None,
    memory_events={key:max(r['service']['memory.events'][key] for r in watch) for key in ('high','max','oom','oom_kill')},
    service_memory_peak=max(r['service']['memory.peak'] for r in watch),
    min_host_available_bytes=min(r['host']['available_bytes'] for r in watch),
    service_swap_peak=max(r['service']['memory.swap.current'] for r in watch),
    watchdog_abort_reasons=[r['decision']['abort_reasons'] for r in watch if r['decision']['abort_reasons']],
    protected=protected,worker_evidence=copied,scope=identity,
    evidence={name:p.digest(RAW/name) for name in ('source1.json','source1_launch.json','remote_monitor.log',
        'local_cleanup.json','remote_stop.json','launch_gate.json','start_closure.json')},
    next='Align source launcher with the existing current native-toolchain and bounded startup contract, test offline, then a new attempt. No runtime/rank change, no request timeout or SLO change, no blind identical retry.')
save('failure_audit.json',record)
print(json.dumps({k:record[k] for k in ('passed','experiment_pass','requests_completed',
    'spawn_to_release_deferred_s','service_memory_peak','memory_events','min_host_available_bytes')}))
