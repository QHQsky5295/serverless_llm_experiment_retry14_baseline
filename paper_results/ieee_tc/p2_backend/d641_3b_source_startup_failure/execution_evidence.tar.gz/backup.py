"""Save the bounded pre-request failure, without relabeling qualification."""
import ast
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d595_20261017/backup.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/p2_backend/d595_parallel_pressure_barrier'",
        "OUT=ROOT/'paper_results/ieee_tc/p2_backend/d641_3b_source_startup_failure'")
replace("=='023ae0079e0b2ffa537a81bda7855e8a4b8ede95'",
        "=='02f438519d2cca90aa2b710466900dac1daca2a6'")
begin=code.index('reg=read(RAW/');end=code.index('preserved={',begin)
code=code[:begin]+'''audit=read(RAW/'failure_audit.json')
assert audit['passed'] and not audit['experiment_pass'] and audit['requests_completed']==0
for name,sha in audit['evidence'].items():assert p.digest(RAW/name)==sha
for phase in ('start','analysis'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
local=read(RAW/'local_cleanup.json');assert local['passed'] and local['path_gone']
assert not Path(local['identity']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
gate=p.preflight([ROOT],32*1024*1024);assert gate['preflight_pass'],gate['issues']
save(RAW/'backup_gate.json',gate)
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
''' +code[end:]
begin=code.index('members=[RAW/name');end=code.index('\nfor path in members:',begin)
code=code[:begin]+'''members=[RAW/name for name in ('start.py','remote_control.py','close.py','collect_failure.py','backup.py',
    'start_identity.json','start_receipt.json','start_closure.json','launch_gate.json','preflight.json',
    'analysis_identity.json','analysis_closure.json','failure_audit.json','source1.json','source1_launch.json',
    'source_commit.txt','source1_launcher.log','remote_start.log','remote_health.json','remote_stop.log','remote_stop.json',
    'remote_start_procedure.json','remote_stop_procedure.json','remote_monitor.log','local_cleanup.json',
    'failed_worker_worker.log','failed_worker_payload.json','failed_worker_process.json','launcher_identity.json','backup_gate.json')]
members += [ROOT/'docs/ieee_tc/D641_3B_SOURCE_STARTUP_FAILURE.md']
assert len({path.name for path in members})==len(members)
for path in members:
    if path.suffix=='.py':ast.parse(path.read_text())
''' +code[end:]
begin=code.index('test_counts={');end=code.index("save(OUT/'qualification.json'",begin)
code=code[:begin]+'''test_counts={'planned_native_cases':368,'completed_native_cases':0}
record=dict(passed=True,experiment_pass=False,production_candidate=False,native_gpu_validation=False,
    full_performance_run=False,parent_commit='02f438519d2cca90aa2b710466900dac1daca2a6',
    audit=audit,protected=protected,preserved={str(k):v for k,v in preserved.items()},
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    archive_members={path.name:dict(path=str(path),sha256=p.digest(path)) for path in members},
    caveat='Failure archival passed, experiment failed before requests. No Full, SLO or physical owner qualification.')
''' +code[end:]
replace("names=['faaslora/scheduling/resource_coordinator.py','tests/test_ieee_tc_transfer_pressure.py',\n    'docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D595_PARALLEL_PRESSURE_BARRIERS.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D641_3B_SOURCE_STARTUP_FAILURE.md']")
replace('Overlap independent native pressure acknowledgements with all-settled barriers (D595)',
        'tc: preserve pre-request 3B source startup failure and exact resource closure (D641)')
ast.parse(code)
exec(compile(code,str(source),'exec'))
