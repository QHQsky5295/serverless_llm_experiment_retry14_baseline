"""Launch one current 3B native source qualification with the existing runner."""
import ast
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(name,obj):
    with (RAW/name).open('x') as f:json.dump(obj,f,indent=2)
identity=p.scope_identity(p.cg_path().name)
save('start_identity.json',identity)
cg=Path(identity['path'])
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote=='02f438519d2cca90aa2b710466900dac1daca2a6'
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc'],cwd=ROOT,text=True).strip()
previous=RAW.parent/'d640_20261017'
backup=read(previous/'backup_receipt.json');assert backup['passed'] and backup['head']==head
closed=read(previous/'backup_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
prepared=ROOT/'paper_results/ieee_tc/p2_backend/d640_3b_migration'
subprocess.run(['sha256sum','-c','result.sha256'],cwd=prepared,check=True,stdout=subprocess.DEVNULL)
audit=read(prepared/'qualification.json');assert audit['passed'] and audit['inputs']['passed']
for path,sha in audit['audit']['refs'].items():assert p.digest(Path(path))==sha
assert p.digest(ROOT/'scripts/ieee_tc/run_d298_capacity_source.sh')==audit['inputs']['runner_sha256']
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate=p.preflight([ROOT,RAW],8*p.GIB)
save('preflight.json',gate)
assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert not (RAW/'source1.json').exists() and not (RAW/'source1_launch.json').exists()
assert subprocess.run(['tmux','has-session','-t','tc-d641-source'],stderr=subprocess.DEVNULL).returncode!=0
for name in ('start.py','remote_control.py','close.py'):ast.parse((RAW/name).read_text())
save('launch_gate.json',dict(passed=True,head=head,remote=remote,preflight=gate,protected=protected,
    input_qualification=audit['inputs'],prepared_manifest_sha256=p.digest(prepared/'qualification.json'),
    scripts={name:p.digest(RAW/name) for name in ('start.py','remote_control.py','close.py')},scope=identity))
subprocess.run([sys.executable,str(RAW/'remote_control.py'),'start'],check=True)
subprocess.run([sys.executable,str(RAW/'remote_control.py'),'health'],check=True,stdout=subprocess.DEVNULL)
# Parent has CUDA hidden for management; the already-gated native launcher must see GPUs.
subprocess.run(['tmux','new-session','-d','-s','tc-d641-source','-c',str(ROOT),
    'env -u CUDA_VISIBLE_DEVICES bash scripts/ieee_tc/run_d298_capacity_source.sh d641'],check=True)
deadline=time.monotonic()+40
while time.monotonic()<deadline:
    log=RAW/'source1_launcher.log'
    matches=re.findall(r'Running scope as unit: (primelora-tc-aux-[0-9a-f]{32}\.scope)',log.read_text() if log.exists() else '')
    if matches:
        assert len(matches)==1
        launcher=p.scope_identity(matches[0]);assert p.scope_still_owned(launcher)
        save('launcher_identity.json',launcher)
        break
    time.sleep(.5)
else:raise RuntimeError('launcher identity not yet captured; inspect without restart')
save('start_receipt.json',dict(launched=True,head=head,tmux='tc-d641-source',scope=identity,launcher=launcher))
print(json.dumps(dict(launched=True,head=head,tmux='tc-d641-source',launcher=launcher)))
