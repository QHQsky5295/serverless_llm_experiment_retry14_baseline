"""Reuse D636 frozen service controls; only campaign/model receipt paths differ."""
import json
from pathlib import Path
import subprocess
import sys
import hashlib
RAW=Path(__file__).resolve().parent
SOURCE=RAW.parent/'d636_20261017'
mode=sys.argv[1]
assert mode in ('start','health','stop')
if mode=='health':
    source=SOURCE/'check_remote_health_stdlib.py'
    exec(compile(source.read_text(),str(source),'exec'))
else:
    source=SOURCE/(mode+'_remote.sh')
    code=source.read_text()
    assert 'd636_20261017' in code and 'd636-min2w0' in code
    code=code.replace('d636_20261017','d641_20261017').replace('d636-min2w0','d641-source')
    if mode=='stop':
        for old,new in (('7b_min2_full_w0/launch.json','source1_launch.json'),
            ('."7b".clock_id','."3b".clock_id'),
            ('d80_20260927/7b/transfers-','d80_20260927/3b/transfers-')):
            assert code.count(old)==1
            code=code.replace(old,new)
    with (RAW/('remote_'+mode+'_procedure.json')).open('x') as f:
        json.dump(dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            executed_sha256=hashlib.sha256(code.encode()).hexdigest(),
            substitutions='campaign d636->d641; source-only launch receipt and 3B transfer identity for stop'),f,indent=2)
    subprocess.run(['/bin/bash'],input=code,text=True,check=True)
