"""Reuse D542 startup witness and D589 W2 input join for D591; no policy changes."""
import json
import os
from pathlib import Path
import re
import sys

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats

def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,allow_nan=False)
scope=p.scope_identity(p.cg_path().name)
save(RAW/'cross_identity.json',scope)
group=Path(scope['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
current=read(RAW/'audit_full4000_w2.json')
prior_root=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d557_20261016')
prior=read(prior_root/'audit_full4000_w2.json')
assert current['measurement_complete'] and current['workload_passed']
assert prior['measurement_complete'] and prior['workload_passed']
assert current['source_plan']==prior['source_plan']
assert current['source_plan']['profile']=='W2'
assert current['common_slo']['freeze_sha256']==prior['common_slo']['freeze_sha256']
def contracts(path):
    out={}
    for line in path.open():
        row=json.loads(line)
        if row['event']=='request_contract':
            assert row['request_id'] not in out
            out[row['request_id']]=row
    assert len(out)==4000
    return out
paths=[RAW/'launch7b.launch/replay.jsonl',prior_root/'launch7b.launch/replay.jsonl']
a,b=map(contracts,paths)
assert a.keys()==b.keys()
fields=('adapter_id','artifact_content_sha256','artifact_manifest_sha256',
        'canonical_prompt_sha256','canonical_prompt_tokens','native_prompt_token_ids_sha256',
        'source_item_sha256','target_tokens','tc_adapter_rotation')
for rid in a:
    for key in fields: assert a[rid][key]==b[rid][key],(rid,key)
# D589 complete W2 input witness, preserving native S-LoRA adapter-path binding.
def selected(path):
    rows={}
    for line in path.open():
        row=json.loads(line)
        if row['event'] in ('request_created','http_raw_response','http_response','http_request_failed'):
            group=rows.setdefault(row['event'],{})
            assert row['request_id'] not in group
            group[row['request_id']]=row
    return rows
now,reference=map(selected,paths)
business=read(RAW/'launch7b.launch/exec_receipt.json')['external_replay']['replay_t0_s']
ref_business=read(prior_root/'launch7b.launch/exec_receipt.json')['external_replay']['replay_t0_s']
for selected_rows in (now,reference):
    assert not selected_rows.get('http_request_failed')
    for event in ('request_created','http_raw_response','http_response'):
        assert selected_rows[event].keys()==a.keys()
arrival_error=max(abs((now['request_created'][rid]['planned_arrival_s']-business)-
    (reference['request_created'][rid]['planned_arrival_s']-ref_business)) for rid in a)
assert arrival_error<=1e-8
stages={key:[] for key in ('native_register_to_scheduled_ms','native_scheduled_to_first_ms','native_decode_ms')}
for rid in a:
    obs=now['http_raw_response'][rid]['body']['metrics']['ieee_tc']
    ref=reference['http_raw_response'][rid]['body']['metrics']['ieee_tc']
    assert obs['native_prompt_token_ids']==ref['native_prompt_token_ids'],rid
    assert Path(obs['native_adapter_path']).name==ref['native_lora_name']==a[rid]['adapter_id'],rid
    assert len(obs['completion_token_ids'])==len(ref['completion_token_ids'])==a[rid]['target_tokens'],rid
    registered=obs['native_rpc_registered_monotonic_s']
    scheduled=obs['native_scheduled_monotonic_s']
    first=obs['native_first_token_monotonic_s']
    last=obs['native_last_token_monotonic_s']
    assert registered<=scheduled<=first<=last
    stages['native_register_to_scheduled_ms'].append(1000*(scheduled-registered))
    stages['native_scheduled_to_first_ms'].append(1000*(first-scheduled))
    stages['native_decode_ms'].append(1000*(last-first))
save(RAW/'cross_contract.json',dict(passed=True,schema='d591_full4000_w2_input_witness_v1',
    scope=scope,request_count=4000,source_plan=current['source_plan'],
    compared_fields=['request_id',*fields,'relative_planned_arrival_s','native_prompt_token_ids',
                     'native_adapter_binding','native_output_count'],
    arrival_max_error_s=arrival_error,reference_system='vLLM',reference_run='D557',
    generation_contract='fixed_length_greedy_v1',input_join_only=True,
    independent_numerical_correctness=False,output_token_equality_required=False,
    initial_state_contract_identical=False,reference_frozen=False,performance_ranking_eligible=False,
    limitations=['Same complete W2 offered inputs and native prompt/adapter/target work.',
        'Cross-backend output-token equality is not a numerical oracle and is not required.',
        'Native versions, full-pool preparation, startup and compilation cache history differ.',
        'One known-source development observation; not an independent holdout or cross-scenario optimum.'],
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in
          (*paths,RAW/'audit_full4000_w2.json',prior_root/'audit_full4000_w2.json',Path(__file__))]))
qual=read(RAW/'model7b/model_qualification.json')
cfg=read(RAW/'model7b/worker_config.json')
ready_paths=sorted((RAW/'model7b/worker_receipts').glob('*.json'))
ready_rows=sorted((read(x) for x in ready_paths),key=lambda r:r['index'])
assert len(ready_rows)==4 and all(r['adapter_count']==500 and r['tp']==1 for r in ready_rows)
preparation_path=RAW/'model7b/slora_full_pool_preparation.json'
preparation=read(preparation_path)
assert len(preparation)==500
notice=cfg['deployment_notice_s']
business=read(RAW/'launch7b.launch/exec_receipt.json')['external_replay']['replay_t0_s']
allocations={i:row for i,row in enumerate(qual['physical_allocations'])}
workers=[]
for row in ready_rows:
    events=allocations[row['index']]['events']
    acquire=[e['at'] for e in events if e['event']=='acquire']
    assert len(acquire)==1
    workers.append(dict(index=row['index'],native_ready_s=row['at'],
        notice_to_ready_s=row['at']-notice,business_to_ready_s=row['at']-business,
        acquire_s=acquire[0],acquire_to_ready_s=row['at']-acquire[0],
        adapter_count=row['adapter_count'],tp=row['tp']))
save(RAW/'startup_diagnostic.json',dict(scope=scope,
    deployment_notice_s=notice,business_start_s=business,
    full_pool_prepare_start_s=min(r['tc_artifact_resolve_started_s'] for r in preparation.values()),
    full_pool_prepare_end_s=max(r['tc_artifact_resolve_completed_s'] for r in preparation.values()),
    full_pool_count=len(preparation),worker_startup=cfg['worker_startup'],
    worker_ready=workers,
    phase_joint=[r['common_slo']['joint_good'] for r in current['source_order_diagnostics']],
    queue_mean_fraction_of_ttft=current['conditional_metrics']['router_queue_ms']['mean']/current['conditional_metrics']['ttft_ms']['mean'],
    native_stages_ms={key:timing_stats(values) for key,values in stages.items()},
    causal_attribution_complete=False,
    limitations=['Sequential startup is a disclosed frozen deployment adaptation, not a uniquely intrinsic S-LoRA inference cost.',
        'No subtraction of deployment or queue spans from user latency; no partial request selection.'],
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in
          (*ready_paths,preparation_path,RAW/'model7b/worker_config.json',RAW/'model7b/model_qualification.json')]))
print(json.dumps(dict(passed=True,request_count=4000,arrival_max_error_s=arrival_error,
    worker_ready=workers,native_stages_ms={key:timing_stats(values) for key,values in stages.items()},scope=scope)))
