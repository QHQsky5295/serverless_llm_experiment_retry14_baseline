"""Reuse D542 explicit-path result publication and archive/source guards."""
import ast, hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=MAIN/'paper_results/ieee_tc/main_comparison/d591_slora_w2/result1'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,row):
    with path.open('x') as f:json.dump(row,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'result_publication_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0' and os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
record=read(OUT/'manifest.json');audit=read(OUT/'audit.json')
assert record['passed'] and record['reference_frozen'] is False and not record['performance_ranking_eligible']
assert audit['measurement_complete'] and audit['workload_passed']
assert audit['native_revalidated_requests']==4000 and audit['counts']['N_failed']==0
assert 0<=audit['common_slo']['joint_good']<=4000 and audit['n_correct'] is None
assert record['reused_native_tests']==51 and record['reused_offline_analysis_tests']==60
assert p.digest(Path(record['analysis_receipt_path']))==record['analysis_receipt_sha256']
for ref in record['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256']
for path,sha in record['preserved'].items():assert p.digest(Path(path))==sha
for name,sha in record['outputs'].items():assert p.digest(OUT/name)==sha
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(record['archive_members'])
    for name,ref in record['archive_members'].items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==ref['sha256']
for name in ('analysis','cross','result'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip()=='d33d73e3da4b92b0479c01c9e2e20acf68ea561f'
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members=[RAW/name for name in ('publish_result.py','result_closure.json','analysis_closure.json','analysis_closure.json',
    'remote_health.json','evidence_copy_receipt.json','remote_stop.log',
    'cross_closure.json','close_postprocess.py')]
members=list(dict.fromkeys(members))
with tarfile.open(OUT/'publication_evidence.tar.gz','x:gz') as bundle:
    for path in members:
        data=path.read_bytes();check(data);assert len(data)<8*1024*1024
        if path.suffix=='.py':ast.parse(data)
        bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(OUT/'publication_evidence.tar.gz') as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
outputs=('audit.json','cross_contract.json','startup_diagnostic.json','manifest.json',
    'evidence.tar.gz','publication_evidence.tar.gz')
with (OUT/'result.sha256').open('x') as f:
    for name in outputs:f.write(p.digest(OUT/name)+'  '+name+'\n')
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D591_SLORA_W2_RESULT.md']
names += [str((OUT/n).relative_to(MAIN)) for n in (*outputs,'result.sha256')]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=MAIN,text=True).strip()
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','diff','--check'],cwd=MAIN,check=True)
for name in names:check((MAIN/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=MAIN,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=MAIN,text=True).splitlines()
assert set(staged)==set(names) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged:assert subprocess.check_output(['git','show',':'+name],cwd=MAIN)==(MAIN/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=MAIN,check=True)
subprocess.run(['git','commit','-m','tc: seal unchanged-policy S-LoRA W2 observation and startup evidence (D591)'],cwd=MAIN,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=MAIN,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=MAIN,text=True).split()[0]
assert head==remote
save(RAW/'result_publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity,protected=protected))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)),flush=True)
