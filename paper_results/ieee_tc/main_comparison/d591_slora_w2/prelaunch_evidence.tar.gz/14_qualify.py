"""Refresh only the S-LoRA measurement-view identity; reuse native qualified code."""
import ast, json, os, re, subprocess, sys
from types import SimpleNamespace
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.audit_d402_serverlessllm_path import validate_population
from prepare_ieee_tc_serverless_stack import prepare_slora_measurement_view, load_http_replay_plan
from replay_vllm_engine_trace import validate_native_service_config, verify_slora_source_view
def read(x):return json.loads(x.read_text())
def save(x,v):
    with x.open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);g=Path(identity['path'])
save(RAW/'qualification_identity.json',identity)
assert (g/'memory.high').read_text().strip()==str(3*p.GIB)
assert (g/'memory.max').read_text().strip()==str(4*p.GIB)
assert (g/'memory.swap.max').read_text().strip()=='0' and os.sched_getaffinity(0)=={2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
previous=RAW.parent/'d542_20261015'
assert read(previous/'audit_full4000_w1.json')['workload_passed']
assert read(previous/'result_publication_closure.json')['path_gone']
oldcommit='bde215460acb9e850efa479a89bda6fc39a2bd7d'
def nodes(source):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
ast_checks={}
for relative,prefixes,extra in (
 ('scripts/ieee_tc_serverless_measurement.py',('slora_','_slora_'),()),
 ('scripts/prepare_ieee_tc_serverless_stack.py',('slora_',),('prepare_slora_measurement_view',)),
 ('scripts/replay_vllm_engine_trace.py',('slora_',),('validate_slora_service_config','verify_slora_source_view'))):
    old=nodes(subprocess.check_output(['git','show',oldcommit+':'+relative],cwd=BASE,text=True))
    current=nodes((BASE/relative).read_text())
    selected=[n for n in old if n.startswith(prefixes) or n in extra]
    assert selected
    for name in selected:
        equal=old[name]==current.get(name);ast_checks[relative+':'+name]=equal
        assert equal,name
cfgpath=previous/'native_7b.json';cfg=read(cfgpath)
oldmanifest=read(Path(cfg['source_view'])/'measurement_manifest.json')
view=RAW/'source_view'
newmanifest=prepare_slora_measurement_view(BASE/'repos/S-LoRA',view,MAIN,
    host_layout=cfg['host_layout'],worker_lifecycle=True)
assert newmanifest['measured_sha256']==oldmanifest['measured_sha256']
assert newmanifest['original_sha256']==oldmanifest['original_sha256']
newcfg=dict(cfg,source_view=str(view),source_view_manifest_sha256=p.digest(view/'measurement_manifest.json'))
assert {k for k in cfg if cfg[k]!=newcfg[k]}=={'source_view','source_view_manifest_sha256'}
save(RAW/'native_7b.json',newcfg)
http=read(RAW/'http_7b_4000.json')
validate_native_service_config(newcfg,http);verify_slora_source_view(dict(newcfg,main_repo=str(MAIN)))
plan=load_http_replay_plan(http)
assert plan.identity()['view_sha256']=='5734bd88587c75dacc0d5c7534ad5b4d5d2a67aa0980f9b203dd87135d3adce7'
reference=RAW.parent.parent/'vllm_qualification/d557_20261016'
assert plan.identity()==read(reference/'input_identity.json')['plan']
allowed={'trace','request_view','replay_profile','adapter_map','adapter_map_sha256','experiment_role'}
assert {k:v for k,v in http.items() if k not in allowed}=={k:v for k,v in read(previous/'http_7b_4000.json').items() if k not in allowed}
rows=[json.loads(e.source_json) for e in plan.entries]
assert len(rows)==4000 and len({r['adapter_id'] for r in rows})==497
assert sum(min(r['expected_output_tokens'],256) for r in rows)==458224
contracts={e.request_id:dict(source_item_sha256=e.source_sha256,
    adapter_id=json.loads(e.source_json)['adapter_id'],
    target_tokens=min(json.loads(e.source_json)['expected_output_tokens'],256),
    tc_adapter_rotation=json.loads(e.source_json)['tc_adapter_rotation']) for e in plan.entries}
assert validate_population(http,dict(plan=plan.identity()),contracts,
    SimpleNamespace(load_http_replay_plan=load_http_replay_plan),'full4000_w2')==4000
command=[sys.executable,'-B','-m','unittest','tests.test_ieee_tc_slora_measurement','tests.test_ieee_tc_slora_service','-v']
with (RAW/'cpu_contract_tests.log').open('x') as log:
    result=subprocess.run(command,cwd=BASE,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
tests=int(re.search(r'Ran (\d+) tests',(RAW/'cpu_contract_tests.log').read_text())[1])
analysis_command=['/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python','-B','-m','unittest','tests.test_tc_serverless_qualification_population','-v']
with (RAW/'analysis_tests.log').open('x') as log:
    analysis_result=subprocess.run(analysis_command,cwd=MAIN,stdout=log,stderr=subprocess.STDOUT)
assert analysis_result.returncode==0
analysis_tests=int(re.search(r'Ran (\d+) tests',(RAW/'analysis_tests.log').read_text())[1])
sources=[cfgpath,previous/'audit_full4000_w1.json',previous/'result_publication_closure.json',
    reference/'input_identity.json',BASE/'scripts/prepare_ieee_tc_serverless_stack.py',
    BASE/'scripts/replay_vllm_engine_trace.py',BASE/'scripts/ieee_tc_serverless_measurement.py',
    BASE/'tests/test_ieee_tc_slora_measurement.py',BASE/'tests/test_ieee_tc_slora_service.py',
    MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',MAIN/'tests/test_tc_serverless_qualification_population.py',
    view/'measurement_manifest.json',
    *sorted(RAW.glob('*.py')),*sorted(RAW.glob('*.sh')),RAW/'http_7b_4000.json',RAW/'native_7b.json',
    RAW/'cpu_contract_tests.log',RAW/'analysis_tests.log']
for path in sources:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
save(RAW/'qualification_final.json',dict(passed=True,contract_checks_passed=True,tests_returncode=result.returncode,command=command,
    native_tests=tests,analysis_tests=analysis_tests,analysis_returncode=analysis_result.returncode,
    actual_unique_adapters=497,target_tokens=458224,
    identity=identity,ast_equal=ast_checks,native_source_unchanged=True,native_config_values_unchanged=True,
    measured_source_sha256_equal=True,new_source_view=str(view),source_view_sha256=p.digest(view/'measurement_manifest.json'),
    native_config_sha256=p.digest(RAW/'native_7b.json'),input_identity=plan.identity(),
    preparation_reason='Shared helper identity refreshed after unrelated Loquetier/HydraServe support changes;16 native S-LoRA functions and generated sources remain byte/AST identical. Only existing W2 input view replaces W1.',
    no_gpu_run=True,no_performance_tuning=True,source_plan_sha256=p.check_plan(),
    refs={str(x):p.digest(x) for x in sources}))
assert result.returncode==0
print(json.dumps(dict(passed=True,ast_checks=len(ast_checks),same_measured_source=True,view=str(view))))
