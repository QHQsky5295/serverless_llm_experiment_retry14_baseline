"""D810: reuse D593 sealed aggregation; retain partial/missing 3B observations."""
import csv
import hashlib
import io
import json
from pathlib import Path

template = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d593_20261017/analyze.py')
# Reuse resource/protected-data checks, focused projection tests and sealed()
# unchanged. No model service, workload generation or new performance run.
prefix = template.read_text().split("slo = P/")[0]
prefix = prefix.replace('d593_complete_7b', 'd810_available_3b')
exec(compile(prefix, str(template), 'exec'), globals())
from scripts.ieee_tc.check_d299_full_context import matched_relative_observation

slo = P/'protocols/20261017_3b_slo_d648_frozen.json'
slo_sha = p.digest(slo)
assert slo_sha == 'd15123570c4a8d830515ca942d1db553c6717ffc1a40ade5c1546d35e2bed9d8'
sealed(slo)
registry = sealed(ROOT/'docs/ieee_tc/BASELINE_PUBLICATION_REGISTRY_20261014.json')
references = sealed(P/'main_comparison/d657_3b_references/resident_references.json')
specs = []
for run,w in [('D653','W0'),('D654','W1'),('D656','W2')]:
    specs.append(('vLLM',run,w,'native_audit',f'vllm/{run.lower()}_3b_full_{w.lower()}/audit.json'))
for run,w in [('D764','W0'),('D765','W1'),('D766','W2')]:
    specs.append(('ServerlessLLM',run,w,'native_audit',f'baseline_audit/{run.lower()}_shared_tokenizer_full_{w.lower()}/audit.json'))
for run,w,slug in [('D771','W0','full_w0'),('D772','W1','w1'),('D773','W2','w2')]:
    specs.append(('S-LoRA',run,w,'native_audit',f'baseline_audit/{run.lower()}_slora_3b_{slug}_binding/gpu_full4000/audit_full4000.json'))
for run,w in [('D800','W0'),('D801','W1'),('D802','W2')]:
    specs.append(('Loquetier',run,w,'native_audit',f'baseline_audit/{run.lower()}_loquetier_3b_{w.lower()}_result/audit_full4000.json'))
for run,w,slug in [('D807','W0','full_w0'),('D808','W1','w1'),('D809','W2','w2')]:
    specs.append(('HydraServe',run,w,'hydra_evaluation',f'baseline_audit/{run.lower()}_hydraserve_3b_{slug}/full_{w.lower()}_evaluation.json'))
for run,w in [('D794','W1'),('D795','W2')]:
    specs.append(('dLoRA',run,w,'terminal_native_failure_audit',f'baseline_audit/{run.lower()}_dlora_cancellation_corrected_full_{w.lower()}/audit_full4000_{w.lower()}.json'))
specs.append(('PrimeLoRA','D752','W0','prime_w0_audit',
              'p2_backend/d752_3b_dense_alias_validation_full_w0/completion/full4000.json'))

rows, registration, identities = [], [], {}
for name,run,w,kind,relative in specs:
    path = P/relative
    source = sealed(path)
    original_source = source
    if kind == 'prime_w0_audit':
        closed = sealed(path.parent/'closed_outcome.json')
        assert closed['passed'] and closed['all_allocations_released']
        assert closed['native_metric_audit']['sha256'] == p.digest(path)
        launch_ref = next(r for r in source['source_refs'] if r['path'].endswith('/launch.json'))
        launch_path = Path(launch_ref['path'])
        assert p.digest(launch_path) == launch_ref['sha256']
        source_refs[str(launch_path)] = launch_ref['sha256']
        launch = json.loads(launch_path.read_text())
        request_path = path.parent/'stages/requests.csv'
        request_data = request_path.read_bytes()
        assert request_data == subprocess.check_output(['git','-C',str(ROOT),'show',head+':'+str(request_path.relative_to(ROOT))])
        source_refs[str(request_path)] = hashlib.sha256(request_data).hexdigest()
        requests = list(csv.DictReader(io.StringIO(request_data.decode())))
        assert len(requests) == len({r['request_id'] for r in requests}) == 4000
        assert sum(r['joint_pass']=='True' for r in requests) == source['counts']['joint_pass']
        source = dict(audit=source, native_output_token_total=sum(int(r['output_tokens']) for r in requests),
                      source_plan=launch['external_replay']['plan'])
    row = sealed_matrix_row(source, source_kind=kind, system=name, run=run, workload=w, slo_sha=slo_sha)
    row['source_ref'] = dict(path=str(path), sha256=source_refs[str(path)], source_kind=kind)
    if kind == 'hydra_evaluation':
        preparation = sealed(path.parent/'prepare_result.json')
        row['source_plan'] = preparation['plan_identity']
        delivery = sealed(path.parent/'delivery_numerical_audit.json')
        row['numerical_evidence_scope'] = delivery
    elif kind == 'prime_w0_audit':
        row['numerical_evidence_scope'] = original_source['note']
    else:
        row['numerical_evidence_scope'] = original_source['limitations']
    plan = row['source_plan']
    assert plan['count'] == 4000 and plan['profile'] == w
    key = (plan['source_sha256'],plan['view_sha256'])
    assert key[0] == '4ea5d026da3820301e753ad6b03ea776e25a5c3f01921933bd124598eb26018d'
    if w in identities: assert identities[w] == key
    identities[w] = key
    if name != 'PrimeLoRA':
        assert registry['systems'][name]['published'] and registry['systems'][name]['role']=='external_baseline'
    row.update(status='completed_observation' if row['workload_complete'] else 'terminal_failure_diagnostic',
               independent_holdout=False, formal_g1_eligible=False, formal_g2_eligible=False,
               n_correct=None)
    registration.append(dict(system=name,run=run,workload=w,source_kind=kind,
                             path=str(path),sha256=source_refs[str(path)]))
    rows.append(row)

groups = {w:{r['system']:r for r in rows if r['workload']==w} for w in ('W0','W1','W2')}
names = ('PrimeLoRA','vLLM','S-LoRA','ServerlessLLM','HydraServe','Loquetier','dLoRA')
assert len(rows)==18 and all(len(g)==6 for g in groups.values())
missing = {'W0':{'dLoRA':'not_in_approved_scope'},
           'W1':{'PrimeLoRA':'current_version_not_run'},
           'W2':{'PrimeLoRA':'current_version_not_run'}}
sensitivity, differences = {}, {}
for w,cohort in groups.items():
    assert set(cohort)|set(missing[w]) == set(names) and not set(cohort)&set(missing[w])
    ref = references[w]; resident = cohort['vLLM']
    assert ref['reference_frozen'] and ref['source_run']==resident['run']
    assert ref['source_audit_sha256']==resident['source_ref']['sha256']
    assert ref['U_ref_gpu_seconds']==resident['physical_gpu_seconds']
    assert ref['Q_ref_p95_ttft_ms']==resident['metrics']['ttft_ms']['p95_type1']
    for r in cohort.values():
        r['ratio_to_resident_75pct_budget']=r['physical_gpu_seconds']/ref['B_gpu_seconds']
        r['budget_within_75pct']=r['physical_gpu_seconds']<=ref['B_gpu_seconds']
        r['observed_g2_constraints']=(r['observed_protocol_feasible'] and r['budget_within_75pct'])
    differences[w] = ({name:matched_relative_observation(cohort['PrimeLoRA'],r)
                       for name,r in cohort.items() if name!='PrimeLoRA'} if 'PrimeLoRA' in cohort else None)
    sensitivity[w]=[]
    for q in (.9,.95,.99):
        eligible=sorted((name for name,r in cohort.items()
            if r['workload_complete'] and r['counts']['joint_pass']>=q*4000),
            key=lambda name:(cohort[name]['physical_gpu_seconds'],name))
        sensitivity[w].append(dict(attainment=q,observed_resource_order=eligible,
            budget_slices=[dict(fraction=rho,observed_feasible_names=[name for name in eligible
                if cohort[name]['physical_gpu_seconds']<=rho*ref['U_ref_gpu_seconds']]) for rho in (.5,.75,1.)]))
report=dict(schema='sealed_available_3b_matrix_v1',results=groups,missing=missing,references=references,
    PrimeLoRA_relative_observations=differences,fixed_configuration_sensitivity=sensitivity,
    new_gpu_runs=0,performance_runs_per_key=1,confidence_interval=None,formal_m1_m2_complete=False,
    independent_numerical_qualification=False,independent_holdout=False,
    current_plan_sha256=p.check_plan(),source_checkpoint=head,common_slo_sha256=slo_sha,
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_amendment_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    common_workload_identities={w:dict(source_sha256=k[0],view_sha256=k[1]) for w,k in identities.items()},
    source_refs=[dict(path=path,sha256=sha) for path,sha in source_refs.items()],
    caveats=['Reuse of sealed audits; no new independent full numerical qualification.',
      'PrimeLoRA D752 W0 only; W1/W2 not measured for this version, never imputed.',
      'dLoRA restricted to W1/W2; failures retained in offered denominator and conditional latency samples.',
      'Source42 known workload, one observation per key, no independent holdout or CI.',
      'HydraServe pp1 only; no pipeline/consolidation performance claim.',
      'Baseline necessary adaptations and native versions retained; no performance search or global-optimum claim.',
      'Numerical resource references are frozen; independent numerical proof remains explicitly unknown.',
      'Sensitivity classifies existing points; it is not an optimized Pareto frontier.'])
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'source_registration.json',registration)
save(OUT/'comparison.json',report)
with (OUT/'metrics.csv').open('x',newline='') as stream:
    writer=csv.writer(stream,lineterminator='\n')
    writer.writerow(['workload','system','run','status','offered','binding_valid','failed','joint_good','joint_slo',
        'gpu_seconds','gpu_seconds_per_offered','mean_ttft_ms','p95_ttft_ms','mean_tpot_ms','p95_tpot_ms',
        'mean_e2e_ms','ratio_to_75pct_budget','observed_latency_feasible','independent_numerical_proof'])
    for w in ('W0','W1','W2'):
        for name in names:
            if name in missing[w]:
                writer.writerow([w,name,'',missing[w][name]]+['']*15)
                continue
            r=groups[w][name]; m=r['metrics']
            writer.writerow([w,name,r['run'],r['status'],4000,r['n_binding_valid'],r['n_failed'],r['counts']['joint_pass'],
                r['joint_slo'],r['physical_gpu_seconds'],r['gpu_seconds_per_offered_request'],m['ttft_ms']['mean'],
                m['ttft_ms']['p95_type1'],m['tpot_ms']['mean'],m['tpot_ms']['p95_type1'],m['e2e_ms']['mean'],
                r['ratio_to_resident_75pct_budget'],r['observed_protocol_feasible'],False])
for path,sha in source_refs.items(): assert p.digest(Path(path))==sha
for path,sha in preserved.items(): assert p.digest(path)==sha
protected=p.verify_seal(seal)
assert protected['pass'] and protected['entry_count']==147
save(OUT/'manifest.json',dict(passed=True,new_gpu_runs=0,production_changed=False,identity=identity,
    resources=resources(),protected=protected,preserved={str(k):v for k,v in preserved.items()},
    source_checkpoint=head,tests=tests.testsRun,source_refs=report['source_refs'],
    analysis_sources=[dict(path=str(f),sha256=p.digest(f)) for f in (Path(__file__),template,
        ROOT/'scripts/ieee_tc/check_d299_full_context.py',ROOT/'tests/test_ieee_tc_sealed_matrix.py')],
    outputs={name:p.digest(OUT/name) for name in ('comparison.json','metrics.csv','source_registration.json')}))
save(RAW/'analysis_receipt.json',dict(passed=True,scope=identity,resources=resources(),rows=len(rows),tests=tests.testsRun))
print(json.dumps(dict(passed=True,rows=len(rows),tests=tests.testsRun,resources=resources())))
