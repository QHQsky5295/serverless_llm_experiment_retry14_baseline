"""D810 adapts D593 publication to a non-force backup ref; no baseline changes."""
from pathlib import Path
template=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d593_20261017/publish.py')
code=template.read_text()
code=code.replace('d593_complete_7b','d810_available_3b')
code=code.replace('79fdd4115b7a94d4173ba2434a81597a54bcf098','2bc234e7c72f63920f287a173a44d3b462c9277e')
code=code.replace("closure=read(RAW/'analysis_closure.json')", "closure=read(RAW/'resume_closure.json')")
code=code.replace("archive=OUT/'execution_evidence.tar.gz'", """
members += [RAW/name for name in ('resume.py','resume_identity.json','resume_closure.json',
    'initial_import_failure.json','finalization_failure.json')]
d809=RAW.parent.parent/'hydraserve_qualification/d809_20261024'
members += [d809/name for name in ('publication_receipt.json','publication_closure.json',
    'storage_receipt.json','storage_closure.json','cache_cleanup_before.json',
    'cache_cleanup_after.json','retained_cache_metadata.json','reclaim.py','close_storage.py')]
def archive_name(path):
    return path.name if path.parent==RAW else 'd809_post/'+path.name
archive=OUT/'execution_evidence.tar.gz'
""")
code=code.replace('arcname=path.name','arcname=archive_name(path)')
code=code.replace('bundle.extractfile(path.name)','bundle.extractfile(archive_name(path))')
code=code.replace('docs/ieee_tc/D593_COMPLETE_7B_COMPARISON.md','docs/ieee_tc/D810_AVAILABLE_3B_COMPARISON_20261024.md')
code=code.replace("names += [str((OUT/name).relative_to(ROOT))", "names += ['docs/ieee_tc/D809_HYDRASERVE_3B_W2_20261024.md']\nnames += [str((OUT/name).relative_to(ROOT))")
code=code.replace('tc: retain complete sealed 7B W0-W2 baseline matrix and constraints (D593)',
                  'tc: retain available 3B matrix, failures and PrimeLoRA gaps (D810)')
code=code.replace("'retry14_continuous_queue_v2'],cwd=ROOT,check=True)",
                  "'HEAD:refs/heads/backup/d810-available-3b-20261024'],cwd=ROOT,check=True)")
code=code.replace("'refs/heads/retry14_continuous_queue_v2'", "'refs/heads/backup/d810-available-3b-20261024'")
exec(compile(code,str(template),'exec'),globals())
