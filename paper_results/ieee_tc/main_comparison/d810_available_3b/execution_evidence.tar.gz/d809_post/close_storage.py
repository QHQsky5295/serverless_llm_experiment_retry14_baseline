from pathlib import Path
original = Path(__file__).resolve().parent.parent/'d805_20261024/close_storage.py'
exec(compile(original.read_text(), str(original), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__))})
