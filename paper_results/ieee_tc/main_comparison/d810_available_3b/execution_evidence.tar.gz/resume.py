"""Finalize unchanged D810 comparison after a manifest-only variable collision."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d810_available_3b'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'resume_identity.json',identity)
group=Path(identity['path'])
def resources():
    return {k:(group/k).read_text().strip() for k in
        ('memory.high','memory.max','memory.swap.max','memory.peak','memory.events','memory.swap.current')}
limits=resources()
assert limits['memory.high']==str(3*p.GIB) and limits['memory.max']==str(4*p.GIB) and limits['memory.swap.max']=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert read(RAW/'analysis_closure.json')['path_gone']
report=read(OUT/'comparison.json')
head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
assert report['source_checkpoint']==head and report['current_plan_sha256']==p.check_plan()
for ref in report['source_refs']: assert p.digest(Path(ref['path']))==ref['sha256']
assert sum(len(g) for g in report['results'].values())==18
assert report['missing']=={'W0':{'dLoRA':'not_in_approved_scope'},'W1':{'PrimeLoRA':'current_version_not_run'},'W2':{'PrimeLoRA':'current_version_not_run'}}
tests=read(RAW/'tests.json');assert tests['passed'] and tests['count']==22
preserved={
 ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
 BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
 BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items(): assert p.digest(path)==sha
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
save(OUT/'manifest.json',dict(passed=True,new_gpu_runs=0,production_changed=False,identity=identity,
    resources=resources(),protected=protected,preserved={str(k):v for k,v in preserved.items()},
    source_checkpoint=head,tests=22,source_refs=report['source_refs'],
    analysis_sources=[dict(path=str(f),sha256=p.digest(f)) for f in (Path(__file__),RAW/'analyze.py',
        RAW.parent/'d593_20261017/analyze.py',ROOT/'scripts/ieee_tc/check_d299_full_context.py',
        ROOT/'tests/test_ieee_tc_sealed_matrix.py')],
    outputs={name:p.digest(OUT/name) for name in ('comparison.json','metrics.csv','source_registration.json')},
    finalization_repair=read(RAW/'finalization_failure.json')))
save(RAW/'analysis_receipt.json',dict(passed=True,scope=identity,resources=resources(),rows=18,tests=22,
    mode='finalize_existing_three_files_without_reaggregation'))
print(json.dumps(dict(passed=True,rows=18,tests=22,resources=resources())))
