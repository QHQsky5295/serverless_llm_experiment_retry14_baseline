"""D810 uses D593's exact-scope, recursive-empty close unchanged."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d593_20261017/close.py')
code = source.read_text().replace("('analysis', 'publication')", "('analysis', 'resume', 'publication')")
exec(compile(code, str(source), 'exec'), globals())
