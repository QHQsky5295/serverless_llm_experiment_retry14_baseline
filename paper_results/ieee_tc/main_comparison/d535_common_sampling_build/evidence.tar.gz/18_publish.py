"""Reuse D534 explicit checkpoint checks; seal build evidence without rerunning it."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream: json.dump(value,stream,indent=2,allow_nan=False)
def git(repo,*args): return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
identity = p.scope_identity(p.cg_path().name)
save(RAW/'publication_identity.json',identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed = read(RAW/'build_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
verification_closed = read(RAW/'verification_closure.json')
assert verification_closed['passed'] and verification_closed['actual_recursive_procs_empty'] and verification_closed['path_gone']
assert not Path(verification_closed['identity']['path']).exists()
finalization_closed = read(RAW/'finalization_closure.json')
assert finalization_closed['passed'] and finalization_closed['actual_recursive_procs_empty'] and finalization_closed['path_gone']
assert not Path(finalization_closed['identity']['path']).exists()
result = read(RAW/'verified_result.json')
assert result['passed'] and not result['performance_result']
assert result['helper_sha256'] == p.digest(RAW/'build_sampling.py')
records = {mode:read(RAW/(mode+'_native.json')) for mode in ('build','primelora','vllm')}
for field in ('receipt','files','source_sha256','dependency_sha256','ninja_sha256'):
    assert records['build'][field] == records['primelora'][field] == records['vllm'][field],field
for row in records.values():
    assert row['passed'] and row['loaded'] and not row['cuda_initialized'] and not row['model_loaded']
    assert row['dry_run']['stdout'].strip() == 'ninja: no work to do.'
for field in ('source_sha256','dependency_sha256'):
    for path,sha in records['build'][field].items(): assert p.digest(Path(path)) == sha,path
for path,row in {**records['build']['files'],**result['legacy_before']}.items():
    assert p.digest(Path(path)) == row['sha256'],path
for path,sha in result['user_before'].items(): assert p.digest(Path(path)) == sha,path
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
assert git(ROOT,'rev-parse','HEAD') == '877cfc300c58680455aa05a8ee7cba03b1567490'
assert git(BASE,'rev-parse','HEAD') == 'bde215460acb9e850efa479a89bda6fc39a2bd7d'
assert git(BASE,'ls-remote','origin','refs/heads/main').split()[0] == git(BASE,'rev-parse','HEAD')
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not token or token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
OUT.mkdir(parents=True,exist_ok=False)
compact_records = {'build': records['build']}
for mode in ('primelora','vllm'):
    compact_records[mode] = {key:value for key,value in records[mode].items()
        if key not in ('dependency_text','dependency_sha256')}
    compact_records[mode]['identical_dependencies_to'] = 'entrypoints.build'
    compact_records[mode]['raw_record_sha256'] = p.digest(RAW/(mode+'_native.json'))
save(OUT/'build.json',dict(passed=True,performance_result=False,result=result,
    actual_closure=closed,verification_closure=verification_closed,
    finalization_closure=finalization_closed,entrypoints=compact_records,
    retained_harness_failure=read(RAW/'build_result.json'),
    limitations=['no model or kernel execution','not a performance or numerical correctness result',
                 'memory.high events during isolated software build retained'],
    protected=protected))
files = sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log')])
members = {}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes(); assert len(data)<2*1024*1024; clean(data)
        name=f'{i:02d}_{path.name}'
        info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o600; info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames()) == set(members)
    for name,ref in members.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'manifest.json',dict(passed=True,preparation_only=True,no_inference_started=True,
    main_source_commit=git(ROOT,'rev-parse','HEAD'),baseline_source_commit=git(BASE,'rev-parse','HEAD'),
    build_sha256=p.digest(OUT/'build.json'),archive_sha256=p.digest(OUT/'evidence.tar.gz'),archive_members=members,
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),plan_sha256=p.check_plan()))
paths=['docs/ieee_tc/D535_COMMON_SAMPLING_BUILD.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(ROOT)) for name in ('build.json','manifest.json','evidence.tar.gz')]
assert git(ROOT,'branch','--show-current') == 'retry14_continuous_queue_v2'
assert not git(ROOT,'diff','--cached','--name-only')
for name in paths:
    data=(ROOT/name).read_bytes(); assert len(data)<2*1024*1024
    if not name.endswith('.tar.gz'): clean(data)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(git(ROOT,'diff','--cached','--name-only').splitlines()) == set(paths)
for name in paths:
    assert hashlib.sha256(subprocess.check_output(['git','show',':'+name],cwd=ROOT)).hexdigest()==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: qualify shared native sampling software without model prewarming (D535)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git(ROOT,'rev-parse','HEAD')
assert git(ROOT,'ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]==head
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote_equal=True,files=paths,
    baseline_head=git(BASE,'rev-parse','HEAD'),baseline_changed=False,scope=identity))
print(json.dumps(dict(passed=True,head=head,files=paths)))
