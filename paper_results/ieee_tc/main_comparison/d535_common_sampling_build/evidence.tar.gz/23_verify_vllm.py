"""Complete only the failed D535 parent-entry probe, without another build.

The original orchestrator pre-bound an environment before asking the vLLM
parent helper to create its child environment. The real launcher starts the
parent unbound. Retain that harness failure and invoke the unchanged probe
with the actual parent boundary, as D534 did. No production source changes.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
ENV=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts import ieee_tc_native_toolchain as tc
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'verification_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
old=read(RAW/'build_result.json')
closed=read(RAW/'build_closure.json')
assert not old['passed'] and old['steps']==[{'mode':'build','returncode':0},
    {'mode':'primelora','returncode':0},{'mode':'vllm','returncode':1}]
assert closed['passed'] and not Path(closed['identity']['path']).exists()
assert 'bound native toolchain environment was changed' in (RAW/'vllm.log').read_text()
gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
native=read(RAW/'build_native.json')
for path,row in native['files'].items():assert p.digest(Path(path))==row['sha256'],path
# Unbound parent, then actual native_worker_environment binds its child.
env=dict(HOME='/home/qhq',PATH=str(ENV/'bin')+':/usr/bin:/bin',CUDA_VISIBLE_DEVICES='',
    PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
    PYTHONPATH=str(ROOT),**{tc.CONTRACT_ENV:str(ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json'),
    tc.SHA_ENV:'328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c'})
assert tc.BOUND_ENV not in env
with (RAW/'vllm_verify.log').open('x') as log:
    completed=subprocess.run([str(ENV/'bin/python'),'-B',str(RAW/'build_sampling.py'),'--child','vllm'],
        cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
save(RAW/'verification_process.json',dict(returncode=completed.returncode,scope=identity,
    unbound_parent=True,build_called=False,original_harness_failure_retained=True))
completed.check_returncode()
records={mode:read(RAW/(mode+'_native.json')) for mode in ('build','primelora','vllm')}
for field in ('receipt','files','source_sha256','dependency_sha256','ninja_sha256'):
    assert records['build'][field]==records['primelora'][field]==records['vllm'][field],field
for field in ('source_sha256','dependency_sha256'):
    for path,sha in native[field].items():assert p.digest(Path(path))==sha,path
for path,row in {**native['files'],**old['legacy_before']}.items():assert p.digest(Path(path))==row['sha256'],path
for path,sha in old['user_before'].items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
result=dict(old,passed=True,legacy_unchanged=True,protected_unchanged=True,user_unchanged=True,
    original_failed_result_sha256=p.digest(RAW/'build_result.json'),
    verification_helper_sha256=p.digest(__file__),verification_scope=identity,
    qualification_boundary='unbound parent creates bound child; unchanged original native entry',
    common_binary_sha256=next(row['sha256'] for path,row in native['files'].items() if path.endswith('/sampling.so')))
save(RAW/'verified_result.json',result)
print(json.dumps(dict(passed=True,common_binary_sha256=result['common_binary_sha256'],
    build_repeated=False,entrypoints_no_work=True)))
