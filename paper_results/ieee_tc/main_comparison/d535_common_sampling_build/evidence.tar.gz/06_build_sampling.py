"""D535: one common software build, reusing D485 guards and native FlashInfer.

No model, adapter, workload, CUDA execution, dependency install or legacy edit.
Child modes only build the generic sampling module or inspect/load that binary.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
ENV = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925')
CFG = ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json'
CONTRACT_SHA = '328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c'
NINJA_SHA = '458aaa5a094c7158005abd944e1dc40898f2d7445e550847ccc295c2c6eb9a5b'
NATIVE = BASE/'configs/ieee_tc/vllm_7b_resident_native_compiler_v2.json'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(BASE/'scripts'))
from scripts import ieee_tc_native_toolchain as tc

def save(name, value):
    with (RAW/name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def files(root):
    return {str(path):dict(bytes=path.stat().st_size, sha256=tc.digest(path))
            for path in sorted(root.rglob('*')) if path.is_file()}

if len(sys.argv) == 3 and sys.argv[1] == '--child':
    mode = sys.argv[2]
    assert mode in ('build', 'primelora', 'vllm')
    if mode == 'primelora':
        from scripts import run_all_experiments as runner
        receipt = runner._native_build_receipt
    elif mode == 'vllm':
        from replay_vllm_engine_trace import native_worker_environment
        env, native = native_worker_environment(json.loads(NATIVE.read_text()), '', os.environ)
        os.environ.update(env)
        receipt = native['compiler_contract']
    else:
        env, receipt = tc.bind_native_toolchain(os.environ, python=sys.executable)
        os.environ.update(env)
    assert receipt is not None and receipt['contract_sha256'] == CONTRACT_SHA
    import torch
    from flashinfer.jit import core, cpp_ext, sampling
    assert not torch.cuda.is_initialized() and os.environ['CUDA_VISIBLE_DEVICES'] == ''
    spec = sampling.gen_sampling_module()
    text = cpp_ext.generate_ninja_build_for_op(spec.name, spec.sources, spec.extra_cflags,
        spec.extra_cuda_cflags, spec.extra_ldflags, spec.extra_include_dirs,
        spec.needs_device_linking)
    assert hashlib.sha256(text.encode()).hexdigest() == NINJA_SHA
    sources = [*spec.sources, Path(core.__file__), Path(cpp_ext.__file__), Path(sampling.__file__)]
    source_before = {str(path):tc.digest(path) for path in sources}
    started = time.monotonic()
    before = files(spec.build_dir)
    if mode == 'build':
        assert not before, 'new namespace unexpectedly has build outputs'
        save('native_build_inputs.json', dict(receipt=receipt, sources=source_before,
            ninja_sha256=NINJA_SHA, ninja_text=text, build_dir=str(spec.build_dir)))
        spec.build(verbose=True, need_lock=True)
    else:
        assert spec.ninja_path.read_text() == text, 'actual entry would rewrite build description'
    assert spec.jit_library_path.is_file()
    dry = subprocess.run([str(ENV/'bin/ninja'), '-n', '-f', str(spec.ninja_path)],
        cwd=spec.build_dir, text=True, capture_output=True, check=True, timeout=30)
    assert dry.stdout.strip() == 'ninja: no work to do.', dry.stdout + dry.stderr
    module = spec.load()
    assert module is not None and not torch.cuda.is_initialized()
    after = files(spec.build_dir)
    if mode != 'build':
        assert before == after, 'verification changed compiled artifacts'
    assert all(tc.digest(path) == sha for path, sha in source_before.items())
    deps = subprocess.run([str(ENV/'bin/ninja'), '-f', str(spec.ninja_path), '-t', 'deps'],
        cwd=spec.build_dir, text=True, capture_output=True, check=True, timeout=30)
    headers = {}
    for line in deps.stdout.splitlines():
        if line.startswith('    '):
            path = Path(line.strip())
            if not path.is_absolute(): path = spec.build_dir/path
            assert path.is_file(), path
            headers[str(path)] = tc.digest(path)
    assert headers, 'native dependency record missing'
    save(mode+'_native.json', dict(passed=True, receipt=receipt, elapsed_s=time.monotonic()-started,
        ninja_sha256=NINJA_SHA, dry_run=dict(stdout=dry.stdout, stderr=dry.stderr),
        loaded=True, cuda_initialized=False, model_loaded=False, files=after,
        source_sha256=source_before, dependency_sha256=headers, dependency_text=deps.stdout))
    raise SystemExit

from scripts import ieee_tc_preflight as p
identity = p.scope_identity(p.cg_path().name)
save('build_identity.json', identity)
group = Path(identity['path'])
limits = p.cgroup_snapshot(group)
assert all(limits[k] == v for k,v in {'memory.high':3*p.GIB,'memory.max':4*p.GIB,'memory.swap.max':0}.items())
assert os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate = p.preflight([RAW, ROOT], predicted_growth=p.GIB)
save('build_preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
protected_path = RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json'
protected = p.verify_seal(protected_path)
assert protected['pass'] and protected['entry_count'] == 147
qualified = ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain/qualification.json'
assert json.loads(qualified.read_text())['passed']
legacy = Path('/home/qhq/.cache/flashinfer/0.6.18.post1/86/cached_ops/sampling')
legacy_before = files(legacy)
user_paths = [ROOT/'configs/generated/lora_manifest_1000.json', BASE/'scripts/replay_openai_trace.py',
              BASE/'scripts/run_serverlessllm_relayserve_continuation.sh']
user_before = {str(path):tc.digest(path) for path in user_paths}
env = dict(HOME='/home/qhq',PATH=str(ENV/'bin')+':/usr/bin:/bin', CUDA_VISIBLE_DEVICES='',
    PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
    PYTHONPATH=str(ROOT), **{tc.CONTRACT_ENV:str(CFG),tc.SHA_ENV:CONTRACT_SHA})
env, receipt = tc.bind_native_toolchain(env, python=str(ENV/'bin/python'))
started = time.monotonic()
result = dict(passed=False, performance_result=False, scope=identity, steps=[],
    qualification_source_sha256=tc.digest(qualified), helper_sha256=tc.digest(__file__),
    protected=protected, user_before=user_before, legacy_before=legacy_before, receipt=receipt)
proc = None
try:
    for mode in ('build', 'primelora', 'vllm'):
        with (RAW/(mode+'.log')).open('x') as log:
            proc = subprocess.Popen([str(ENV/'bin/python'),'-B',str(__file__),'--child',mode],
                cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            owner = p.gpu_process_identity(proc.pid)
            assert owner and Path(owner['cgroup']).is_relative_to(group)
            save(mode+'_worker.json',owner)
            while proc.poll() is None:
                assert p.host_sample()['available_bytes'] >= 16*p.GIB
                assert shutil.disk_usage(RAW).free >= 100*p.GIB
                if time.monotonic()-started > 900: raise TimeoutError('bounded generic software build')
                time.sleep(1)
            result['steps'].append(dict(mode=mode,returncode=proc.returncode))
            assert proc.returncode == 0, mode
    records = {mode:json.loads((RAW/(mode+'_native.json')).read_text())
               for mode in ('build','primelora','vllm')}
    for field in ('receipt','files','source_sha256','dependency_sha256','ninja_sha256'):
        assert records['build'][field] == records['primelora'][field] == records['vllm'][field], field
    assert files(legacy) == legacy_before
    assert all(tc.digest(path) == sha for path,sha in user_before.items())
    assert p.verify_seal(protected_path)['pass']
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    result.update(passed=True, legacy_unchanged=True, protected_unchanged=True, user_unchanged=True,
        common_binary_sha256=records['build']['files'][str(Path(records['build']['receipt']['environment']['FLASHINFER_WORKSPACE_BASE'])/'.cache/flashinfer/0.6.18.post1/86/cached_ops/sampling/sampling.so')]['sha256'])
except Exception as exc:
    result.update(error_type=type(exc).__name__,error=str(exc))
finally:
    if proc is not None and proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try: proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            proc.wait(timeout=5)
    result.update(elapsed_s=time.monotonic()-started,scope_after=p.cgroup_snapshot(group))
    save('build_result.json',result)
    print(json.dumps({k:result[k] for k in ('passed','steps','elapsed_s')},allow_nan=False),flush=True)
sys.exit(0 if result['passed'] else 1)
