"""Seal completed build/load checks; do not repeat their execution.

verify_vllm.py completed all native checks, then its final p.digest(__file__)
used a string where the existing preflight API requires Path. Preserve its
source and process receipt; this offline finalizer only records the evidence.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(name):return json.loads((RAW/name).read_text())
def save(name,value):
    with (RAW/name).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save('finalization_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for name in ('build','verification'):
    closed=read(name+'_closure.json')
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert read('verification_process.json')['returncode']==0
old=read('build_result.json')
assert not old['passed'] and old['steps']==[{'mode':'build','returncode':0},
    {'mode':'primelora','returncode':0},{'mode':'vllm','returncode':1}]
records={mode:read(mode+'_native.json') for mode in ('build','primelora','vllm')}
for record in records.values():
    assert record['passed'] and record['loaded'] and not record['cuda_initialized']
    assert record['dry_run']['stdout'].strip()=='ninja: no work to do.'
for field in ('receipt','files','source_sha256','dependency_sha256','ninja_sha256'):
    assert records['build'][field]==records['primelora'][field]==records['vllm'][field],field
native=records['build']
for field in ('source_sha256','dependency_sha256'):
    for path,sha in native[field].items():assert p.digest(Path(path))==sha,path
for path,row in {**native['files'],**old['legacy_before']}.items():assert p.digest(Path(path))==row['sha256'],path
for path,sha in old['user_before'].items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
result=dict(old,passed=True,legacy_unchanged=True,protected_unchanged=True,user_unchanged=True,
    original_failed_result_sha256=p.digest(RAW/'build_result.json'),
    verification_helper_sha256=p.digest(RAW/'verify_vllm.py'),
    finalization_helper_sha256=p.digest(Path(__file__)),finalization_scope=identity,
    retained_harness_failures=['bound child environment incorrectly passed to parent environment builder',
        'all native checks complete; offline verifier final digest used str instead of Path'],
    qualification_boundary='unbound parent creates bound child; unchanged original native entry',
    common_binary_sha256=next(row['sha256'] for path,row in native['files'].items() if path.endswith('/sampling.so')))
save('verified_result.json',result)
print(json.dumps(dict(passed=True,common_binary_sha256=result['common_binary_sha256'],
    build_repeated=False,native_checks_repeated=False,dependencies=len(native['dependency_sha256']))))
