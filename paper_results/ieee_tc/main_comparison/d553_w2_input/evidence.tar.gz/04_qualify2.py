"""Same D553 checks, with the required multiprocessing main-module guard.

The first incomplete attempt and tested sources are retained. This changes
only the CPU qualification driver, not production behavior or test assertions.
"""
if __name__ == '__main__':
    from hashlib import sha256
    import json
    from pathlib import Path
    RAW=Path(__file__).resolve().parent
    original=RAW/'qualify.py'
    raw=original.read_bytes()
    assert sha256(raw).hexdigest()=='ea03990d4d3464336463f0ce6461472fe3f8e686f2d20bb210442ad995b194c0'
    failure=json.loads((RAW/'qualification_failure.json').read_text())
    for name,expected in failure['sources'].items():
        assert sha256(Path(name).read_bytes()).hexdigest()==expected,name
    closed=json.loads((RAW/'qualification_failure_closure.json').read_text())
    assert closed['path_gone'] and not Path(closed['identity']['path']).exists()
    source=raw.decode()
    for old,new in (('qualification_identity.json','qualification2_identity.json'),
                    ("RAW/'http_7b_4000.json'","RAW/'http_7b_4000_v2.json'"),
                    ('tests.log','tests2.log'),('qualification.json','qualification2.json')):
        source=source.replace(old,new)
    exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'qualify2.py')})
