"""Reuse D537's environment-split CPU qualification, without dependency changes."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'contract_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
previous=read(RAW/'qualification3.json')
assert not previous['passed'] and (previous['tests'],previous['failures'],previous['errors'],previous['skipped'])==(386,2,8,0)
assert read(RAW/'qualification3_closure.json')['path_gone']
for name,sha in {**previous['refs'],**previous['preserved']}.items():assert p.digest(Path(name))==sha,name
log=(RAW/'tests3.log').read_text()
failed={match[1] for match in re.findall(r'^(ERROR|FAIL): \S+ \(([^)]+)\)',log,re.M)}
prefix='tests.test_ieee_tc_preflight.ProtocolGates.'
guard_tests=[prefix+name for name in ('test_scope_identity_change_never_signals',
    'test_tiny_gate_cannot_be_used_to_launch_an_unbounded_model',
    'test_launch_cannot_start_model_before_auxiliary_limits_exist',
    'test_live_install_prevents_overlapping_model_launch')]
analysis_tests=['tests.test_tc_serverless_qualification_population.ElasticLocalityMatchedTests.'+name
    for name in ('test_extension_cannot_drop_prior_rows',
                 'test_streamed_controller_loader_requires_explicit_complete_scenario')]
assert failed==set(guard_tests+analysis_tests),failed
assert "ModuleNotFoundError: No module named 'ijson'" in log
assert 'pidfd_send_signal' in log
receipts=[]
for name,python,tests in (
    ('system_guard','/usr/bin/python3',guard_tests),
    ('analysis','/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python',analysis_tests)):
    command=[python,'-B','-m','unittest',*tests,'-v']
    target=RAW/(name+'_tests.log')
    with target.open('x') as stream:
        result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
    body=target.read_text()
    assert result.returncode==0 and re.search(r'Ran '+str(len(tests))+r' tests in [0-9.]+s\s+OK\n',body),body
    receipts.append(dict(name=name,command=command,tests=len(tests),returncode=0,
                         log=str(target),log_sha256=p.digest(target)))
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
record=dict(previous,passed=True,failures=0,errors=0,skipped=0,
    identity=identity,tests=386,primary_suite_passed_methods=380,environment_only_rechecks=6,
    initial_suite_receipt=str(RAW/'qualification3.json'),initial_suite_sha256=p.digest(RAW/'qualification3.json'),
    initial_failures_retained=True,dependency_or_production_changes=False,
    explanation='Four watchdog tests require system Python PID handles; two offline parser tests require existing analysis ijson. Main 380 methods and full4000 input audit reused unchanged.',
    environment_rechecks=receipts,protected=protected)
record['refs']=dict(previous['refs'],**{str(path):p.digest(path) for path in
    [Path(__file__),RAW/'tests3.log',RAW/'qualification3.json',RAW/'system_guard_tests.log',RAW/'analysis_tests.log']})
save(RAW/'qualification_final.json',record)
print(json.dumps(dict(passed=True,tests=386,reused_passed=380,rechecked=6,
    input_view=record['http_plan']['view_sha256'],native_execution_qualified=False)))
