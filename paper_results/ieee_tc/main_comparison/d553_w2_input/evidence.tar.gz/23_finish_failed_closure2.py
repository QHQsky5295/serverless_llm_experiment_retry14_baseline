"""Record completion of the already requested second failed CPU-scope stop."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW/'finish_failed_closure.py'
source=original.read_text().replace('qualification_failure.json','qualification2_failure.json')
source=source.replace('qualification_failure_closure.json','qualification2_failure_closure.json')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'finish_failed_closure2.py')})
