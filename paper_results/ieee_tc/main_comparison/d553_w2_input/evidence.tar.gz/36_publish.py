"""Reuse D531 two-repository explicit-path publication and integrity checks."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d531_20261015/backup.py'
raw=original.read_bytes()
assert sha256(raw).hexdigest()=='a4d4a812c4185358541980005a7e30847618b0d1ce8746b09827f9ffe25e4d03'
source=raw.decode()

def replace(old,new):
    global source
    assert source.count(old)==1,(old,source.count(old))
    source=source.replace(old,new)

replace('main_comparison/d531_w1_input','main_comparison/d553_w2_input')
replace("RAW/'backup_identity.json'","RAW/'publication_identity.json'")
replace("RAW/'backup_receipt.json'","RAW/'publication_receipt.json'")
replace("qualification=read(OUT/'qualification.json')", """qualification=read(RAW/'qualification_final.json')
assert qualification['passed'] and qualification['failures']==0 and qualification['errors']==0
assert qualification['skipped']==0
assert qualification['tests']==386 and qualification['primary_suite_passed_methods']==380
assert qualification['environment_only_rechecks']==6
assert 'Ran 386 tests' in (RAW/'tests3.log').read_text()
assert 'FAILED (failures=2, errors=8)' in (RAW/'tests3.log').read_text()
for row in qualification['environment_rechecks']:
    assert p.digest(Path(row['log']))==row['log_sha256']
    assert re.search(r'Ran '+str(row['tests'])+r' tests in [0-9.]+s\\s+OK\\n',Path(row['log']).read_text())
failed=read(RAW/'qualification_failure.json')
assert not failed['passed'] and failed['kind']=='cpu_test_driver_spawn_failure'
for path,sha in failed['sources'].items():assert p.digest(Path(path))==sha,path
failed2=read(RAW/'qualification2_failure.json')
assert not failed2['passed'] and failed2['kind']=='cpu_test_environment_import_pressure'
for path,sha in failed2['sources'].items():assert p.digest(Path(path))==sha,path
for phase in ('audit','qualification_failure','qualification2_failure','qualification3'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'qualification.json',qualification)
save(OUT/'audit.json',read(RAW/'audit.json'))
save(OUT/'failure.json',failed)
save(OUT/'failure2.json',failed2)
""")
replace("assert qualification['passed'] and qualification['tests']==103", "assert qualification['passed'] and qualification['tests']>103")
replace("RAW/'qualification_closure.json'","RAW/'contract_closure.json'")
replace('a8b7a9849a4f66a58d9694a32de149228b68f251','ad3c8c0dc59c6d600e62e77cb596683ec9f2fd2c')
replace('09baa9379bdc3518f18f408d2cad3763c2754554','bde215460acb9e850efa479a89bda6fc39a2bd7d')
replace("    assert not token or token not in data", """    assert not token or token not in data
    if data.startswith(b'\\x1f\\x8b'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as nested:
            for member in nested.getmembers():
                assert member.isfile() and member.size<2*1024*1024
                clean(nested.extractfile(member).read())""")
start=source.index("files=[RAW/name for name in")
end=source.index('members={}',start)
source=source[:start]+"""files=[RAW/name for name in ('audit_map.py','audit_identity.json','audit_closure.json',
    'qualify.py','qualify2.py','qualify3.py','tests.log','tests2.log','tests3.log','qualification_identity.json',
    'qualification2_identity.json','qualification3_identity.json','qualification3_closure.json','qualification3.json',
    'qualification_failed_sources.tar.gz','qualification2_failed_sources.tar.gz',
    'qualification2_failed_sources_attempt2.tar.gz',
    'qualification_failure_closure.json','qualification2_failure_closure.json',
    'close_failed_qualification.py','close_failed_qualification2.py','close_failed_qualification2b.py',
    'finish_failed_closure.py','finish_failed_closure2.py',
    'http_7b_4000.json','http_7b_4000_v2.json','http_7b_4000_v3.json',
    'finalize_qualification.py','contract_identity.json','contract_closure.json',
    'system_guard_tests.log','analysis_tests.log',
    'close.py','close2.py','close3.py','close_contract.py','publish.py')]
files.append(Path('"""+str(original)+"""'))
"""+source[end:]
replace('docs/ieee_tc/D531_W1_REPLAY_VIEW.md','docs/ieee_tc/D553_W2_REPLAY_VIEW.md')
replace('tc: qualify explicit shared W1 arrival view without baseline policy changes (D531)',
        'tc: bind approved W2 adapter view without changing baseline policies (D553)')
replace('dict(passed=True,tests=103,baseline_checkpoint=baseline,',
        "dict(passed=True,tests=qualification['tests'],baseline_checkpoint=baseline,")
start=source.index("paths=['scripts/ieee_tc/audit_d402_serverlessllm_path.py'")
end=source.index('main=publish(ROOT,paths',start)
source=source[:start]+"""paths=['faaslora/datasets/workload_generator.py','scripts/ieee_tc_preflight.py',
    'scripts/run_all_experiments.py','scripts/ieee_tc/audit_d402_serverlessllm_path.py',
    'tests/test_ieee_tc_external_replay.py','tests/test_ieee_tc_preflight.py',
    'tests/test_tc_serverless_qualification_population.py',
    'docs/ieee_tc/D553_W2_INPUT_QUALIFICATION.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'paper_results/ieee_tc/inputs/20261015_7b_w2_adapter_map_v1.json']
paths += [str((OUT/name).relative_to(ROOT)) for name in
          ('qualification.json','audit.json','failure.json','failure2.json','manifest.json','evidence.tar.gz')]
"""+source[end:]
replace('tc: qualify exact W1 input and profile bindings before common reference (D531)',
        'tc: qualify source-rank-preserving W2 input across native and HTTP replay (D553)')
replace('main=main,baseline=baseline,tests=103','main=main,baseline=baseline,tests=qualification[\'tests\']')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py')})
