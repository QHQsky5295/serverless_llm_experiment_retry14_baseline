"""Preserve and stop only the identity-pinned failed D553 CPU test scope."""
import json
from pathlib import Path
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=json.loads((RAW/'qualification_identity.json').read_text())
assert identity['invocation_id']=='272edb5935bf4dd195d448c3431007f1'
assert p.scope_still_owned(identity)
group=Path(identity['path'])
members={str(path):path.read_text().split() for path in group.rglob('cgroup.procs')}
for values in members.values():
    for pid in values:
        if Path('/proc',pid).exists():assert Path('/proc',pid).stat().st_uid==1001
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}
sources=[ROOT/name for name in ('faaslora/datasets/workload_generator.py','scripts/ieee_tc_preflight.py',
    'scripts/run_all_experiments.py','scripts/ieee_tc/audit_d402_serverlessllm_path.py',
    'tests/test_ieee_tc_external_replay.py','tests/test_ieee_tc_preflight.py',
    'tests/test_ieee_tc_launch.py','tests/test_tc_serverless_qualification_population.py')]
sources += [BASE/name for name in ('scripts/prepare_ieee_tc_serverless_stack.py',
                                 'tests/test_ieee_tc_serverless_measurement.py')]
with tarfile.open(RAW/'qualification_failed_sources.tar.gz','x:gz') as archive:
    for i,path in enumerate(sources):archive.add(path,arcname=f'{i:02d}_{path.name}',recursive=False)
record=dict(passed=False,kind='cpu_test_driver_spawn_failure',identity=identity,
    reason='qualify.py has unguarded module execution; spawned test workers re-enter exclusive receipt creation and raise FileExistsError; suite incomplete',
    no_gpu_or_performance_run=True,production_modified_for_retry=False,
    observed_resources_before_stop=resources,members_before_stop=members,
    sources={str(path):p.digest(path) for path in sources+[RAW/'qualify.py',RAW/'tests.log',RAW/'http_7b_4000.json',RAW/'qualification_failed_sources.tar.gz']})
with (RAW/'qualification_failure.json').open('x') as f:json.dump(record,f,indent=2)
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True,timeout=20)
assert not group.exists()
with (RAW/'qualification_failure_closure.json').open('x') as f:
    json.dump(dict(passed=True,identity=identity,path_gone=True,failed_owned_scope_stopped=True,
        resources_before_stop=resources,not_a_normal_empty_closure=True),f,indent=2)
print(json.dumps(dict(failed_scope_closed=True,resources_before_stop=resources)))
