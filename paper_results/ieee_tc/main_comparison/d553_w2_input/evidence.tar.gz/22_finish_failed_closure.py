"""Record actual completion of the already requested D553 failed-test stop."""
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
failed=json.loads((RAW/'qualification_failure.json').read_text())
identity=failed['identity']
group=Path(identity['path'])
assert not group.exists(), 'existing stop still in progress; do not start another task'
status=subprocess.check_output(['systemctl','--user','show',identity['unit'],
    '-p','ActiveState','-p','SubState','-p','InvocationID','-p','ControlGroup'],text=True)
assert 'ActiveState=active' not in status and 'ActiveState=deactivating' not in status
with (RAW/'qualification_failure_closure.json').open('x') as stream:
    json.dump(dict(passed=True,identity=identity,path_gone=True,failed_owned_scope_stopped=True,
        resources_before_stop=failed['observed_resources_before_stop'],
        normal_empty_closure=False,stop_wait_timeout_s=20,actual_final_status=status),stream,indent=2)
print(status)
