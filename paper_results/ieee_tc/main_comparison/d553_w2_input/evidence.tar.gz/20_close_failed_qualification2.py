"""Reuse pinned failed-scope preservation for the native-env CPU import stall."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW/'close_failed_qualification.py'
raw=original.read_bytes()
assert sha256(raw).hexdigest()=='6e36e5b64a687ec563f126b6ec451b4638c021e4af27fa955cb5c104a29253e1'
source=raw.decode().replace('qualification','qualification2').replace('qualify.py','qualify2.py').replace('tests.log','tests2.log')
source=source.replace('272edb5935bf4dd195d448c3431007f1','3f8762928bfd4f91a254d3c56d94778f')
source=source.replace('cpu_test_driver_spawn_failure','cpu_test_environment_import_pressure')
source=source.replace('qualify2.py has unguarded module execution; spawned test workers re-enter exclusive receipt creation and raise FileExistsError; suite incomplete',
    'native vLLM0300 interpreter imported humming NVRTC/launcher helpers in multiprocessing children; bounded CPU suite stalled under memory.high reclaim; no OOM; use existing D549 qualified CPU wrapper environment')
source=source.replace("subprocess.run(['systemctl','--user','stop',identity['unit']],check=True,timeout=20)",
    """subprocess.run(['systemctl','--user','kill','--kill-who=all','--signal=KILL',identity['unit']],check=True,timeout=10)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True,timeout=20)""")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'close_failed_qualification2.py')})
