"""Use D549's qualified CPU wrapper interpreter, retaining both failed drivers."""
if __name__ == '__main__':
    from hashlib import sha256
    import json
    from pathlib import Path
    import sys
    RAW=Path(__file__).resolve().parent
    assert sys.executable=='/home/qhq/anaconda3/envs/sllm_vllm0102_newserverless_20260518/bin/python'
    original=RAW/'qualify.py'
    raw=original.read_bytes()
    assert sha256(raw).hexdigest()=='ea03990d4d3464336463f0ce6461472fe3f8e686f2d20bb210442ad995b194c0'
    for phase in ('qualification','qualification2'):
        failure=json.loads((RAW/(phase+'_failure.json')).read_text())
        for name,expected in failure['sources'].items():
            assert sha256(Path(name).read_bytes()).hexdigest()==expected,name
        closed=json.loads((RAW/(phase+'_failure_closure.json')).read_text())
        assert closed['path_gone'] and not Path(closed['identity']['path']).exists()
    source=raw.decode()
    for old,new in (('qualification_identity.json','qualification3_identity.json'),
                    ("RAW/'http_7b_4000.json'","RAW/'http_7b_4000_v3.json'"),
                    ('tests.log','tests3.log'),('qualification.json','qualification3.json')):
        source=source.replace(old,new)
    exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'qualify3.py')})
