"""Reuse exact-owned recursive-empty analysis scope closure."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d530_20261015/close.py').read_text()
source=source.replace("('analysis','curation','backup')", "('analysis','context','curation','backup')")
exec(compile(source,str(RAW/'close_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'close.py')})
