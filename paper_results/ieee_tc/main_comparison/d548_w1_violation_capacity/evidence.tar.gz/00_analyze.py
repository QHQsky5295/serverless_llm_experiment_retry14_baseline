"""D530 retained-stage/control analysis adapted to D533 W1 and frozen SLO groups.

No inference, counterfactual latency, policy search or changes to sealed data.
"""
import json, math, os, subprocess, sys
from collections import Counter
from pathlib import Path
import ijson
import yaml
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import partition_retained_request_stages
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats
from scripts.ieee_tc.check_d299_full_context import closed_physical_integral
from faaslora.datasets.workload_generator import FrozenReplayPlan
def read(path):return json.loads(path.read_text())
def save(name,row):
    with (RAW/name).open('x') as f:json.dump(row,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);save('analysis_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
sealed=read(ROOT/'paper_results/ieee_tc/main_comparison/d533_full_w1/result1/audit.json')
pinned={r['path']:r['sha256'] for r in sealed['refs']};refs=[]
def checked(path):
    path=Path(path);digest=p.digest(path)
    if str(path) in pinned:assert digest==pinned[str(path)],path
    refs.append(dict(path=str(path),sha256=digest));return path
source=checked(next(path for path in pinned if '/experiment_results' in path))
run=source.parent;launch=read(checked(run/'launch.json'))
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
plan=FrozenReplayPlan.load(launch['external_replay']['plan']['source_path'],count=4000,profile='W1')
assert plan.identity()==launch['external_replay']['plan']==sealed['workload_identity']
start=launch['external_replay']['replay_t0_s'];clock=launch['external_replay']['clock_id']
order={e.request_id:i for i,e in enumerate(plan.entries)}
slo=read(checked(ROOT/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json'))
outcome=checked(run/'launch.launch/physical_deployment/main_outcome.json')
def selected(prefix):
    with outcome.open('rb') as f:return next(ijson.items(f,prefix,use_float=True))
activations=selected('mechanism_events._ieee_activations')
initial=[a for a in activations if a['category']=='initial'];assert len(initial)==1
initial_ready=initial[0]['engine_ready_at']
rows=[]
with source.open('rb') as f:
    for request in ijson.items(f,'detailed_results.tc_ieee_full.requests.item',use_float=True):
        row=partition_retained_request_stages(request,arrival_start_s=start,clock_id=clock)
        length=request['native_token_timing']['actual_prompt_tokens']
        matches=[g for g in slo['groups'] if (g['lower_exclusive'] is None or length>g['lower_exclusive'])
                 and (g['upper_inclusive'] is None or length<=g['upper_inclusive'])]
        assert len(matches)==1;g=matches[0]
        ttft_ok=row['ttft_ms']<=g['ttft_ms']
        tpot_ok=request['completion_tokens']==1 or request['tpot_ms']<=g['tpot_ms']
        index=order[request['request_id']];entry=plan.entries[index]
        assert request['scheduled_arrival_offset_s']==entry.offset_s
        row.update(source_order=index,phase=index//500,arrival_offset_s=entry.offset_s,
            arrived_before_initial_ready=start+entry.offset_s<initial_ready,
            ttft_pass=ttft_ok,tpot_pass=tpot_ok,joint_pass=ttft_ok and tpot_ok,
            tpot_ms=request['tpot_ms'],prompt_tokens=length,output_tokens=request['completion_tokens'],
            adapter_id=request['adapter_id'],instance_id=request['instance_id'],
            dispatch_tier=request['readiness_tier_before_dispatch'],
            ttft_limit_ms=g['ttft_ms'],tpot_limit_ms=g['tpot_ms'])
        rows.append(row)
assert len(rows)==len({r['request_id'] for r in rows})==4000
rows.sort(key=lambda r:r['source_order'])
assert sum(r['joint_pass'] for r in rows)==sealed['common_threshold_joint_count']==3749
assert sum(r['ttft_pass'] for r in rows)==3788 and sum(r['tpot_pass'] for r in rows)==3950
def summary(rs):
    return dict(count=len(rs),joint_good=sum(r['joint_pass'] for r in rs),
        ttft_good=sum(r['ttft_pass'] for r in rs),tpot_good=sum(r['tpot_pass'] for r in rs),
        stages_ms={k:timing_stats([r['stages_ms'][k] for r in rs]) for k in rows[0]['stages_ms']},
        ttft_ms=timing_stats([r['ttft_ms'] for r in rs]),tpot_ms=timing_stats([r['tpot_ms'] for r in rs]),
        output_tokens=timing_stats([r['output_tokens'] for r in rs]),
        dispatch_tiers=dict(Counter(r['dispatch_tier'] for r in rs)))
whole=summary(rows)
assert all(abs(v['mean']-sealed['stage_means_ms'][k])<1e-6 for k,v in whole['stages_ms'].items())
groups={name:summary([r for r in rows if predicate(r)]) for name,predicate in {
    'all':lambda r:True,'joint_failed':lambda r:not r['joint_pass'],
    'ttft_only_failed':lambda r:not r['ttft_pass'] and r['tpot_pass'],
    'tpot_only_failed':lambda r:r['ttft_pass'] and not r['tpot_pass'],
    'both_failed':lambda r:not r['ttft_pass'] and not r['tpot_pass'],
    'arrived_before_initial_ready':lambda r:r['arrived_before_initial_ready'],
    'failed_before_initial_ready':lambda r:r['arrived_before_initial_ready'] and not r['joint_pass'],
    'failed_after_initial_ready':lambda r:not r['arrived_before_initial_ready'] and not r['joint_pass'],
    'failed_first1000':lambda r:r['source_order']<1000 and not r['joint_pass'],
    'failed_later3000':lambda r:r['source_order']>=1000 and not r['joint_pass']}.items()}
with outcome.open('rb') as f:controls=list(ijson.items(f,'mechanism_events._ieee_control_events.item',use_float=True))
cfg_path=ROOT/'configs/ieee_tc/20261015_d533_7b_full_w1.yaml'
cfg=yaml.safe_load(checked(cfg_path).read_text())['resource_coordination']['ieee_scaling']
duration=plan.entries[-1].offset_s;end=start+duration
controls=[r for r in controls if start<=r['observed_at']<=end]
assert controls and all(a['observed_at']<b['observed_at'] for a,b in zip(controls,controls[1:]))
physical=read(checked(run/'launch.launch/physical_deployment/summary.json'))
total=closed_physical_integral(physical);assert total==sealed['stats']['physical_gpu_seconds']
edges=Counter({start:0,end:0})
for intervals in physical['device_intervals'].values():
    for left,right in intervals:
        left,right=max(left,start),min(right,end)
        if left<right:edges[left]+=1;edges[right]-=1
occupied=Counter();active=0;stamps=sorted(edges)
for i,t in enumerate(stamps[:-1]):
    active+=edges[t];assert 0<=active<=4
    occupied[active]+=stamps[i+1]-t
assert abs(sum(occupied.values())-duration)<1e-6
assert abs(sum(k*v for k,v in occupied.items())-physical['window_gpu_seconds']['arrival'])<1e-6
for name,data in [('requests.jsonl',rows),('controls.jsonl',controls)]:
    with (RAW/name).open('x') as f:
        for row in data:f.write(json.dumps(row,allow_nan=False)+'\n')
    checked(RAW/name)
for path in (Path(__file__),ROOT/'scripts/analyze_control_path_overhead.py',
    ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',ROOT/'scripts/ieee_tc/check_d299_full_context.py',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')):checked(path)
result=dict(passed=True,kind='d548_d533_retained_w1_violation_stage_control_v1',new_gpu_run=False,
    causal_attribution_established=False,numerical_correctness_qualified=False,groups=groups,
    phases={str(i):summary([r for r in rows if r['phase']==i]) for i in range(8)},
    activations=activations,initial_ready_after_business_s=initial_ready-start,
    controller_settings=cfg,control=dict(count=len(controls),actions=dict(Counter(r['action'] for r in controls)),
    outcomes=dict(Counter(r['outcome'] for r in controls)),first_samples=controls[:20]),
    physical_gpu_seconds=total,window_gpu_seconds=physical['window_gpu_seconds'],
    arrival_duration_s=duration,arrival_occupancy_wall_seconds=dict(sorted(occupied.items())),
    arrival_mean_physical_gpus=physical['window_gpu_seconds']['arrival']/duration,
    max_identity_error_ms=max(r['max_identity_error_ms'] for r in rows),source_refs=refs,scope=identity,
    caveats=['Violation-conditioned stages are descriptive, not causal or removable overhead.',
             'Stage means add; percentiles and nested spans do not.',
             'No CPU/GPU execution, rerun, SLO relaxation or initial-cache change.'])
save('summary.json',result)
print(json.dumps(dict(passed=True,group_counts={k:{j:v[j] for j in ('count','joint_good','ttft_good','tpot_good')} for k,v in groups.items()},
    failed_stage_means={k:v['mean'] for k,v in groups['joint_failed']['stages_ms'].items()},
    initial_ready_after_business_s=initial_ready-start,arrival_mean_physical_gpus=result['arrival_mean_physical_gpus'],
    physical_occupancy=result['arrival_occupancy_wall_seconds']),indent=2))
