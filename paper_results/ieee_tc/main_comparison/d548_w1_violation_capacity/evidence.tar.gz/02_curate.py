"""D530 bounded curation reused for the two D548 retained-evidence projections."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d530_20261015/curate.py'
source=template.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('d530_metadata_stage_gap','d548_w1_violation_capacity')
replace("summary['current']['count']==4000", "summary['groups']['all']['count']==4000")
replace("for ref in summary['source_refs']:assert", "context=read(RAW/'context.json')\nassert context['passed'] and context['context']['samples']==1036\nfor ref in summary['source_refs']+context['source_refs']:assert")
replace("tests=('tests.test_ieee_tc_control_timeline',)", "context_close=read(RAW/'context_closure.json')\nassert context_close['passed'] and context_close['actual_recursive_procs_empty'] and not Path(context_close['identity']['path']).exists()\ntests=('tests.test_ieee_tc_control_timeline',)")
replace('b26378b348ee3705b6b69f567c61aa0084a4f653','d7d3f7188e4daaa076f16efaa2dff8a271bf8ffa')
replace("files += [ROOT/'scripts/analyze_control_path_overhead.py'", "files += [RAW/name for name in ('analyze_context.py','context_identity.json','context_closure.json','context.log','gate_requests.json','capacity_samples.json')]\nfiles += [Path('"+str(template)+"'),ROOT/'scripts/run_all_experiments.py',ROOT/'faaslora/coordination/autoscaler.py']\nfiles += [ROOT/'scripts/analyze_control_path_overhead.py'")
replace("test_sources={str(ROOT/", "with (OUT/'context.json').open('xb') as stream:stream.write((RAW/'context.json').read_bytes())\ntest_sources={str(ROOT/")
replace("source_refs=summary['source_refs']", "source_refs=summary['source_refs']+context['source_refs']")
replace("('summary.json','evidence.tar.gz')", "('summary.json','context.json','evidence.tar.gz')")
exec(compile(source,str(RAW/'curate_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py')})
