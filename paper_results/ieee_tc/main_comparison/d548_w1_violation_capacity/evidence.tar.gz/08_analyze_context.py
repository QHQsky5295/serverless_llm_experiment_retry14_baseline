"""Reuse D466 exact retained gate/capacity context on D548's sealed D533 source."""
import json, os, subprocess, sys
from pathlib import Path
import ijson
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import (
    summarize_dispatch_gate_intervals, summarize_dispatch_capacity_context)
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats
def read(path):return json.loads(path.read_text())
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);save('context_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
summary=read(RAW/'summary.json')
sealed=read(ROOT/'paper_results/ieee_tc/main_comparison/d533_full_w1/result1/audit.json')
pinned={r['path']:r['sha256'] for r in sealed['refs']+summary['source_refs']};refs=[]
def checked(path):
    path=Path(path);digest=p.digest(path)
    if str(path) in pinned:assert digest==pinned[str(path)],path
    refs.append(dict(path=str(path),sha256=digest));return path
source=checked(next(path for path in pinned if '/experiment_results' in path))
physical=source.parent/'launch.launch/physical_deployment'
deployment=read(checked(physical/'deployment.json'))
with checked(physical/'request_terminals.jsonl').open() as f:terminals=[json.loads(line) for line in f]
fields=('request_id','instance_id','success','scheduled_arrival_offset_s',
    'arrival_released_offset_s','admission_start_offset_s','dispatch_window_wait_ms',
    'runtime_slot_wait_ms','admitted_offset_s','arrival_release_lateness_ms',
    'dispatch_admission_wait_ms','native_token_timing')
with source.open('rb') as f:
    requests=[{k:r[k] for k in fields} for r in ijson.items(f,'detailed_results.tc_ieee_full.requests.item',use_float=True)]
with checked(RAW/'requests.jsonl').open() as f:old={r['request_id']:r for r in map(json.loads,f)}
requests.sort(key=lambda r:old[r['request_id']]['source_order'])
assert len(requests)==4000
split=summarize_dispatch_gate_intervals(requests,deployment,terminals,summary['activations'])
rows=split.pop('rows')
for row in rows:
    prior=old[row['request_id']]
    row.update({k:prior[k] for k in ('source_order','phase','ttft_pass','tpot_pass','joint_pass','ttft_ms')})
    assert abs(row['acquire_to_resume_ms']-prior['stages_ms']['acquire_to_resume_ms'])<1e-6
start=deployment['arrival_start_s']
with checked(RAW/'controls.jsonl').open() as f:controls=list(map(json.loads,f))
mapped=[dict(offset_s=e['observed_at']-start,queue=e['queue_depth'],
    active=e['active_requests'],capacity=e['ready_capacity'],pending=e['pending_instances'],
    action=e['action'],outcome=e['outcome'],p95_ttft_ms=e['p95_ttft_ms'],all_low=e['all_low']) for e in controls]
context=summarize_dispatch_capacity_context(rows,mapped);samples=context.pop('rows')
phases=[]
for phase in range(8):
    rr=[r for r in rows if r['phase']==phase];left=rr[0]['arrival_offset_s'];right=rr[-1]['arrival_offset_s']
    cc=[s for s in samples if left<=s['offset_s']<=right]
    waiting=[s for s in cc if s['acquire_not_yet_resumed']>0]
    phases.append(dict(phase=phase,first_arrival_s=left,last_arrival_s=right,
        count=len(rr),joint_misses=sum(not r['joint_pass'] for r in rr),
        gate_wait_ms=timing_stats([r['acquire_to_resume_ms'] for r in rr]),
        startup_overlap_ms=timing_stats([r['acquire_to_resume_startup_overlap_ms'] for r in rr]),
        control_samples=len(cc),waiting_samples=len(waiting),
        definitely_full_samples=sum(s['capacity_covered_by_definite_owners'] for s in waiting),
        peak_wait_sample=max(cc,key=lambda s:s['acquire_not_yet_resumed']) if cc else None))
activations=[dict(a,trigger_offset_s=a['trigger_at']-start,
    engine_ready_offset_s=a['engine_ready_at']-start) for a in summary['activations']]
for name,value in [('gate_requests.json',rows),('capacity_samples.json',samples)]:
    save(name,value);checked(RAW/name)
for path in (Path(__file__),RAW/'summary.json',ROOT/'scripts/analyze_control_path_overhead.py'):
    checked(path)
result=dict(passed=True,kind='d548_retained_w1_capacity_context_v1',
    new_gpu_run=False,causal_attribution_established=False,split=split,context=context,phases=phases,
    activations=activations,control_actions=[s for s in samples if s['action']!='no_action'],
    peak_wait_sample=max(samples,key=lambda s:s['acquire_not_yet_resumed']),
    longest_wait=max(rows,key=lambda r:r['acquire_to_resume_ms']),source_refs=refs,scope=identity)
save('context.json',result)
print(json.dumps({k:result[k] for k in ('passed','context','phases','control_actions','longest_wait')},indent=2))
