"""Reuse D544's full-W1 input join, with D510 HydraServe native witnesses.

Offline only. This does not rerun inference or infer numerical LoRA correctness.
"""
from collections import Counter
import json
import os
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats
def read(path):return json.loads(path.read_text())
def save(path,row):
    with path.open('x') as f:json.dump(row,f,indent=2,allow_nan=False)
def events(path):return [json.loads(line) for line in path.open()]
def index(data,event):
    selected=[r for r in data if r['event']==event]
    keyed={r['request_id']:r for r in selected}
    assert len(keyed)==len(selected)
    return keyed
scope=p.scope_identity(p.cg_path().name);save(RAW/'cross_identity.json',scope)
group=Path(scope['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed=read(RAW/'audit_identity_closure.json')
assert closed['actual_recursive_empty'] and not Path(closed['identity']['path']).exists()
audit=read(RAW/'full_w1_evaluation.json');prereg=read(RAW/'preregistration.json')
assert audit['full_audit_pass'] and audit['n_v1_contract_complete']==4000 and audit['n_failed']==0
assert audit['raw_n_correct_preserved'] is None
prior=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d536_20261015')
paths=[RAW/'launch_gate.launch/replay.jsonl',prior/'launch7b.launch/replay.jsonl']
rows,prior_rows=map(events,paths)
contracts,reference=index(rows,'request_contract'),index(prior_rows,'request_contract')
assert len(contracts)==4000 and contracts.keys()==reference.keys()
fields=('adapter_id','artifact_content_sha256','artifact_manifest_sha256','canonical_prompt_sha256',
    'canonical_prompt_tokens','native_prompt_token_ids_sha256','source_item_sha256','target_tokens')
for rid in contracts:
    for key in fields:assert contracts[rid][key]==reference[rid][key],(rid,key)
prior_audit=read(prior/'audit_full4000_w1.json')
assert prereg['plan_identity']==prior_audit['source_plan']
assert prereg['references']['slo_eval']['sha256']==prior_audit['common_slo']['freeze_sha256']
created=index(rows,'request_created');ref_created=index(prior_rows,'request_created')
business=read(RAW/'launch_gate.launch/exec_receipt.json')['external_replay']['replay_t0_s']
ref_business=read(prior/'launch7b.launch/exec_receipt.json')['external_replay']['replay_t0_s']
arrival_error=max(abs((created[r]['planned_arrival_s']-business)-(ref_created[r]['planned_arrival_s']-ref_business)) for r in contracts)
assert arrival_error<=1e-8
witness=MAIN/'paper_results/ieee_tc/main_comparison/d544_loquetier_w1/result1/cross_contract.json'
old=read(witness);assert old['passed'] and old['request_count']==4000
assert any(r['path']==str(paths[1]) and r['sha256']==p.digest(paths[1]) for r in old['refs'])
comparison=old['comparison']
assert set(comparison)=={'PrimeLoRA','vLLM','S-LoRA','ServerlessLLM','Loquetier'}
comparison['HydraServe']=dict(joint=audit['joint_slo'],gpu_seconds=audit['physical_gpu_seconds'],
    p95_ttft_ms=audit['metrics']['ttft_ms']['p95'],failed=0,latency_sample_count=4000,
    performance_ranking_eligible=False)
delta={name:dict(joint_difference_pp=100*(comparison['PrimeLoRA']['joint']-r['joint']),
    gpu_seconds_relative_reduction=(r['gpu_seconds']-comparison['PrimeLoRA']['gpu_seconds'])/r['gpu_seconds'],
    p95_ttft_relative_reduction=(r['p95_ttft_ms']-comparison['PrimeLoRA']['p95_ttft_ms'])/r['p95_ttft_ms'])
    for name,r in comparison.items() if name!='PrimeLoRA'}
refs=[dict(path=str(x),sha256=p.digest(x)) for x in (*paths,witness,RAW/'full_w1_evaluation.json',Path(__file__))]
save(RAW/'cross_contract.json',dict(passed=True,schema='d546_w1_six_system_input_witness_v1',scope=scope,
    request_count=4000,compared_fields=['request_id',*fields,'relative_planned_arrival_s'],arrival_max_error_s=arrival_error,
    source_plan=prereg['plan_identity'],comparison=comparison,prime_observed_differences=delta,
    input_join_only=True,reference_frozen=False,all_below_joint_95=all(r['joint']<.95 for r in comparison.values()),
    independent_numerical_correctness=False,initial_state_contract_identical=False,
    limitations=['Loquetier latency is conditional on3844 responses; failed156 stay in4000 SLO denominator.',
        'No feasible G1/G2 ranking or failure-censored latency superiority inferred.',
        'Native versions/static sharding/slot capacity/cache histories differ; input equality is not state equality.'],refs=refs))
metrics={r['request_id']:r for r in read(RAW/'request_metrics.json')}
slo={r['request_id']:r for r in read(RAW/'full_w1_slo_rows.json')}
assert metrics.keys()==slo.keys()==contracts.keys()
phase=[]
for k in range(8):
    ids=[rid for rid,r in created.items() if k*500<=r['index']<(k+1)*500]
    assert len(ids)==500
    phase.append(dict(phase=k+1,n=500,ttft_good=sum(slo[r]['ttft_pass'] for r in ids),
        tpot_good=sum(slo[r]['tpot_pass'] for r in ids),joint_good=sum(slo[r]['joint_pass'] for r in ids),
        metrics={field:timing_stats([metrics[r][field] for r in ids]) for field in
            ('ttft_ms','tpot_ms','dispatch_wait_after_submit_ms','service_ttft_ms','decode_ms')}))
native_paths=sorted((RAW/'platform').glob('d546-w*.native-request.json'))
native=[read(x) for x in native_paths]
assert native and all(x['env']['PP_SIZE']==x['env']['DEST_PP_SIZE']=='1' and x['env']['BATCH_SIZE']=='8' for x in native)
allocation=events(RAW/'physical/container_allocations.jsonl')
acquire=[r for r in allocation if r['event']=='acquire'];release=[r for r in allocation if r['event']=='release']
assert len(acquire)==len(release)==len(native)
record=dict(passed=True,scope=scope,phase=phase,event_counts=dict(Counter(r['event'] for r in rows)),
    native_worker_count=len(native),all_pp1=True,batch_size=8,pipeline_consolidation_observed=False,
    allocation_event_counts=dict(Counter(r['event'] for r in allocation)),
    physical=read(RAW/'physical/summary.json'),causal_attribution_complete=False,
    stage_note=audit['stage_note'],
    ttft_failure_count=sum(not r['ttft_pass'] for r in slo.values()),
    tpot_failure_count=sum(not r['tpot_pass'] for r in slo.values()),
    both_failure_count=sum(not r['ttft_pass'] and not r['tpot_pass'] for r in slo.values()),
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in (*native_paths,RAW/'physical/container_allocations.jsonl',RAW/'request_metrics.json',RAW/'full_w1_slo_rows.json')])
save(RAW/'phase_native_diagnostic.json',record)
print(json.dumps(dict(passed=True,comparison=comparison,prime_observed_differences=delta,
    phase=[{k:r[k] for k in ('phase','n','ttft_good','tpot_good','joint_good')} for r in phase],
    native_worker_count=len(native),both_failure_count=record['both_failure_count'])))
