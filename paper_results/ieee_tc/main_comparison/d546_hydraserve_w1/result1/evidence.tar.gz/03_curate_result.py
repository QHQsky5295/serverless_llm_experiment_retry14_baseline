"""D544 bounded curation/archive recipe adapted to the D546 strict audit."""
import ast, hashlib, io, json, os, re, subprocess, sys, tarfile
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=MAIN/'paper_results/ieee_tc/main_comparison/d546_hydraserve_w1/result1'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,row):
    with path.open('x') as f:json.dump(row,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);save(RAW/'result_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
audit=read(RAW/'full_w1_evaluation.json');cross=read(RAW/'cross_contract.json')
diagnosis=read(RAW/'phase_native_diagnostic.json')
assert audit['full_audit_pass'] and audit['n_v1_contract_complete']==4000 and audit['n_failed']==0
assert audit['native_output_tokens']==458224 and audit['raw_n_correct_preserved'] is None
assert audit['n_joint']==1811 and not audit['observed_w1_g1_feasible']
assert cross['passed'] and cross['request_count']==4000 and len(cross['comparison'])==6
assert diagnosis['passed'] and diagnosis['native_worker_count']==21 and diagnosis['all_pp1']
assert read(RAW/'closure.json')['actual_recursive_empty'] and read(RAW/'remote_stop.json')['all_owned_units_inactive']
for name in ('audit_identity','cross_identity'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['actual_recursive_empty'] and not Path(closed['identity']['path']).exists()
prelaunch=read(OUT.parent/'prelaunch.json')
assert prelaunch['passed'] and prelaunch['reused_qualification']['tests']==16
for path,sha in prelaunch['source_sha256'].items():assert p.digest(Path(path))==sha,path
assert 'Ran 16 tests' in (RAW/'cpu_contract_tests.log').read_text()
refs=dict(audit['source_sha256']);refs.update(read(RAW/'http_audit.json')['source_sha256'])
refs.update({r['path']:r['sha256'] for r in cross['refs']+diagnosis['refs']})
for path,sha in refs.items():assert p.digest(Path(path))==sha,path
preserved={str(MAIN/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
subprocess.run(['git','diff','--exit-code','b4c2ab12f7423f202d21752e9524136f4f411645','--',
    'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=MAIN,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()=='bde215460acb9e850efa479a89bda6fc39a2bd7d'
OUT.mkdir(parents=True,exist_ok=False)
files=[RAW/name for name in ('audit.py','run_audit.py','cross_contract.py','curate_result.py','close_cpu.py',
    'close_audit.py','collect_remote.py','stop_remote.sh','preregistration.json','source_manifest.json',
    'launch_gate.json','result.json','closure.json','remote_stop.json','remote_stop.log',
    'audit_identity_closure.json','cross_identity_closure.json','audit.log','cross.log',
    'http_audit.json','full_w1_slo_rows.json','request_metrics.json','native_scheduler_after_requests.json',
    'generation_result.json','external_terminal_summary.json','native_admission_capacity.json',
    'remote_health.json','remote_transfers.jsonl','prepare_result.json','cpu_contract_tests.log')]
files += [RAW/'physical/container_allocations.jsonl',RAW/'physical/summary.json',
    RAW.parent/'d503_20261013/audit.py',MAIN/'docs/ieee_tc/D546_HYDRASERVE_W1_RESULT.md']
files += sorted((RAW/'platform').glob('d546-w*.native-request.json'))
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
members={};archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<32*1024*1024
        assert token and token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
        if path.suffix=='.py':ast.parse(data)
        name=f'{i:02d}_{path.name}'
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o600;member.mtime=0
        tar.addfile(member,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(archive) as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
assert archive.stat().st_size<2*1024*1024
for dest,source in (('audit.json','full_w1_evaluation.json'),('cross_contract.json','cross_contract.json'),
                    ('phase_native_diagnostic.json','phase_native_diagnostic.json')):
    with (OUT/dest).open('xb') as f:f.write((RAW/source).read_bytes())
save(OUT/'manifest.json',dict(passed=True,scope=identity,new_gpu_run=False,serving_changed=False,
    reference_frozen=False,performance_ranking_eligible=False,reused_native_tests=16,
    reason='D546 complete W1 native-binding observation; independent numerical qualification remains unknown',
    execution_main_commit='b4c2ab12f7423f202d21752e9524136f4f411645',
    execution_baseline_commit='bde215460acb9e850efa479a89bda6fc39a2bd7d',
    metric_protocol_sha256=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_protocol_sha256=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    protected=protected,preserved=preserved,source_refs=refs,archive_members=members,
    outputs={n:p.digest(OUT/n) for n in ('audit.json','cross_contract.json','phase_native_diagnostic.json','evidence.tar.gz')}))
print(json.dumps(dict(passed=True,archive_bytes=archive.stat().st_size,scope=identity)))
