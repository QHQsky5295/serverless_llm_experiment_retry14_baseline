"""Preserve the no-GPU, pre-import failure and close its exact empty scope."""
import json, subprocess, sys
from pathlib import Path
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
identity=p.scope_identity('primelora-tc-aux-d5460000000000000000000000000001.scope')
assert p.scope_still_owned(identity)
group=Path(identity['path'])
assert not any(f.read_text().split() for f in (group/'cgroup.procs',*group.rglob('cgroup.procs')))
for name,data in [('reuse_import_failure_identity.json',identity),('reuse_import_failure.json',dict(
    error_type='ImportError',error='baseline scripts package shadowed main namespace before identity save',
    no_gpu_run=True,failed_source='inspect_reuse.py',source_sha256=p.digest(RAW/'inspect_reuse.py'),
    remedy='import main preflight before adding baseline package to sys.path'))]:
    with (RAW/name).open('x') as f:json.dump(data,f,indent=2)
subprocess.run(['/usr/bin/python3','-B',str(RAW/'close_cpu.py'),'reuse_import_failure_identity.json'],check=True)
