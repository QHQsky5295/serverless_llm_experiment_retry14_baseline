"""Reuse the D544 explicit-path, checked prelaunch publication procedure."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
OLD=RAW.parent.parent/'loquetier_qualification/d544_20261015/backup.py'
source=OLD.read_text().replace('D544','D546').replace('d544','d546')
source=source.replace('d546_loquetier_w1','d546_hydraserve_w1')
source=source.replace('D546_LOQUETIER_W1','D546_HYDRASERVE_W1')
source=source.replace('d543_20261015','d545_20261015')
source=source.replace("binding_path=RAW/'qualification.json'","binding_path=RAW/'prepare_result.json'")
source=source.replace("'Ran 39 tests'","'Ran 16 tests'")
source=source.replace("assert len(binding['ast_equal'])==24 and all(binding['ast_equal'].values())",
    "assert binding['native_runtime_files_equal']==15 and binding['d510_overlays_equal']")
source=source.replace("binding['refs'].items()","binding['source_sha256'].items()")
start=source.index("for name in ('reuse','qualification'):")
end=source.index('protected=p.verify_seal',start)
source=source[:start]+'''for name in ('reuse','prepare'):
    closed=read(RAW/(name+'_identity_closure.json'))
    assert closed['actual_recursive_empty'] and not Path(closed['identity']['path']).exists()
for path,record in read(RAW/'source_manifest.json').items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
'''+source[end:]
start=source.index('files=sorted(')
end=source.index("token=Path(",start)
source=source[:start]+'''files=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),*RAW.glob('*.json'),*RAW.glob('*.log')])
files=[x for x in files if x.name!='pull-auth.json']
files += sorted((RAW/'overlays').glob('*'))
files += sorted((RAW/'executed_sources').glob('*'))
files += [RAW/'metadata/partition.json']
assert all(x.is_file() and not x.is_symlink() for x in files)
for path in files:
    if path.suffix=='.py':
        text=path.read_text()
        if path.name.endswith('native_body.py'):text='if True:\\n'+text
        ast.parse(text,filename=str(path))
    if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
'''+source[end:]
source=source.replace('tests=39','tests=16').replace('qualified_tests=39','qualified_tests=16')
source=source.replace('unchanged Loquetier W1 native configuration','unchanged HydraServe W1 native configuration')
exec(compile(source,str(RAW/'backup_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'backup.py')})
