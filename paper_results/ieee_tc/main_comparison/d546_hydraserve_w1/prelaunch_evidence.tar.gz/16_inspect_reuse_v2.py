"""Repair only the audit import namespace; preserve the pre-import failure."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'inspect_reuse.py').read_text()
old="sys.path[:0]=[str(MAIN),str(BASE),str(BASE/'scripts')]\nfrom scripts import ieee_tc_preflight as p"
new="sys.path.insert(0,str(MAIN))\nfrom scripts import ieee_tc_preflight as p\nsys.path[:0]=[str(BASE),str(BASE/'scripts')]"
assert source.count(old)==1
exec(compile(source.replace(old,new),str(RAW/'inspect_reuse.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'inspect_reuse.py')})
