    import asyncio
    from hashlib import sha256
    import importlib.util
    from HydraServe_project.runtime.isolated_platform import ContainerRecipe,IsolatedPodmanPlatform
    from HydraServe_project.runtime.platform_port import render_overlays as render_platform,SOURCE_DIR

    BASE=Path('/home/qhq/serverless_llm_baselines')
    ENV=BASE/'installs/hydraserve_native_d484_20261013'
    PYBASE=Path('/home/qhq/anaconda3/envs/hydraserve_py_20260520')
    CUDA=Path('/home/qhq/anaconda3/envs/slinfer_official_20260612')
    NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
    MODEL=Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf')
    NCCL=RAW.parent/'d486_20261013/private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1'
    FAST=RAW.parent/'d485_20261013/build_fastload/lib/libst_pybinding.so'
    assert sha256(NCCL.read_bytes()).hexdigest()=='005503b62b9fe466b6b2f60ba2ad1daa4571196ffcb82a3d77a3c775bfcd5ac8'
    assert sha256(FAST.read_bytes()).hexdigest()=='f11b31a82f654d7c8950d85e05461d31b5cc45469720deb1e784d47022571e44'
    for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
        assert sha256(Path(path).read_bytes()).hexdigest()==record['sha256']
    helper_spec=importlib.util.spec_from_file_location('native_resource_helper',BASE/'tests/test_ieee_tc_hydraserve_platform_port.py')
    helper=importlib.util.module_from_spec(helper_spec);helper_spec.loader.exec_module(helper)
    nv=CUDA/'lib/python3.11/site-packages/nvidia'
    libraries=[ENV/'lib/python3.10/site-packages/torch/lib',PYBASE/'lib',
               *[d/'lib' for d in sorted(nv.iterdir()) if (d/'lib').is_dir()],CUDA/'lib']
    readonly=[ENV,PYBASE,CUDA,MODEL,NCCL,BASE/'HydraServe_project']
    # Common remote downloader runs in the service, never the replay client.
    support_spec=importlib.util.spec_from_file_location('tc_prepare_shared',BASE/'scripts/prepare_ieee_tc_serverless_stack.py')
    support=importlib.util.module_from_spec(support_spec);support_spec.loader.exec_module(support)
    cfg=json.loads((RAW/'remote_input_config.json').read_text())
    remote_config,remote_paths=support.prepare_remote_artifacts(cfg,RAW,str(group).removeprefix('/sys/fs/cgroup'))
    measure_spec=importlib.util.spec_from_file_location('tc_remote_shared',BASE/'scripts/ieee_tc_serverless_measurement.py')
    measure=importlib.util.module_from_spec(measure_spec);measure_spec.loader.exec_module(measure)
    from HydraServe_project.runtime.remote_artifacts import NativeArtifactViews
    views=NativeArtifactViews(measure.PublishedArtifactResolver(remote_config),RAW/'adapter_views')
    assert len(remote_paths)==500 and not list((Path(remote_config['cache_dir'])/'objects').iterdir())
    readonly += [views.root,Path(remote_config['cache_dir'])/'objects']
    mounts=[(str(x),str(x)) for x in readonly]
    mounts += [(str(RAW/"lora_registry.json"),"/hydra-loras.json")]
    mounts += [(str(RAW/'overlays'),'/hydra-overlay'),(str(RAW/'metadata'),'/mnt/model-cache'),
               (str(FAST),'/vllm-workspace/libst_pybinding.so')]
    worker_env=dict(LD_LIBRARY_PATH=':'.join(map(str,libraries)),PYTHONPATH=str(BASE),
        PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTHONUNBUFFERED='1',
        HOME='/tmp',CUDA_CACHE_PATH='/tmp/cuda-cache',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        VLLM_NO_USAGE_STATS='1',VLLM_NCCL_SO_PATH=str(NCCL),
        HYDRASERVE_OVERLAY_ROOT='/hydra-overlay',
        HYDRASERVE_OVERLAY_SHA256=sha256((RAW/'overlays/manifest.json').read_bytes()).hexdigest(),
        HYDRASERVE_PARTITION_MANIFEST='/mnt/model-cache/partition.json',
        HYDRASERVE_PARTITION_SHA256=sha256((RAW/'metadata/partition.json').read_bytes()).hexdigest(),
        HYDRASERVE_NATIVE_ENTRY='scripts/image/app.py',
        HYDRASERVE_EXEC_JSON=json.dumps([str(ENV/'bin/python'),'-B',
            str(BASE/'HydraServe_project/runtime/native_overlay_entry.py')]))
    worker_env.update(HYDRASERVE_LORA_REGISTRY="/hydra-loras.json",
        HYDRASERVE_LORA_REGISTRY_SHA256=sha256((RAW/"lora_registry.json").read_bytes()).hexdigest())
    uuids=subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).splitlines()
    assert len(uuids)==4
    recipe=ContainerRecipe(image_id=image['Id'],native_images=('registry.us-east-1.aliyuncs.com/kubernetes-fc/modelscope-vllm:v1',),
        entrypoint=(str(ENV/'bin/python'),'-B','/hydra-entry.py'),readonly_mounts=tuple(mounts),
        environment=worker_env,memory_bytes=80*p.GIB,swap_bytes=2*p.GIB)
    platform=IsolatedPodmanPlatform(campaign='d546',output=RAW/'platform',parent=group,
        parent_invocation=identity['invocation_id'],parent_inode=identity['inode'],
        parent_limits={'memory.high':str(72*p.GIB),'memory.max':str(80*p.GIB),'memory.swap.max':str(2*p.GIB)},
        cpu_ids=list(range(4,24))+list(range(28,48)),podman_base=base,podman_environment=env,
        process_identity=p.gpu_process_identity,node=socket.gethostname(),gpu_uuids=uuids,
        gpu_gb=24,network_gbps=1,host_gb=80,storage_address='127.77.49.10',recipe=recipe,
        gate_script=BASE/'HydraServe_project/runtime/container_entry.py')

    from faaslora.clock import local_monotonic_clock_id
    from HydraServe_project.runtime.http_contract import NativeHTTPAdapter
    from HydraServe_project.runtime.physical_lifecycle import NativeWorkerLedger
    context=json.loads(Path(os.environ['FAASLORA_TC_LAUNCH_RECEIPT']).read_text())['external_replay']
    http_cfg=json.loads((RAW/'http_7b_4000.json').read_text())
    plan=support.load_http_replay_plan(http_cfg)
    assert plan.identity()==context['plan'] and context['clock_id']==local_monotonic_clock_id()
    api=p.load_nvml_binding(Path(os.environ['FAASLORA_TC_NVML_BINDING']),os.environ['FAASLORA_TC_NVML_SHA256'])
    ledger=NativeWorkerLedger(root=RAW/'physical',context=context,census=p.NativeGPUCensus(api),
        service_path=group,process_identity=p.gpu_process_identity)
    platform.lifecycle_observer=ledger
    registry={r['adapter_id']:r for r in json.loads((RAW/'lora_registry.json').read_text())}
    http=NativeHTTPAdapter(public_model=http_cfg['model'],native_model='llama2_7b/0',registry=registry,
        views=views,platform=platform,clock_id=context['clock_id'],journal=RAW/'http_service.jsonl')
    terminal_rows=[]

    async def listen(address,port,worker,health=False):
        start=time.monotonic()
        while True:
            try:
                reader,writer=await asyncio.wait_for(asyncio.open_connection(address,port),2)
                if health:
                    writer.write(bytes(8));await writer.drain()
                    data=await asyncio.wait_for(reader.read(100),5)
                    assert data==b'initialization finished',data
                writer.close();await writer.wait_closed()
                return time.monotonic()-start
            except ConnectionRefusedError:
                if time.monotonic()-start>1800:raise
                # Probe actual PID cheaply; no recurring container CLI in loading path.
                current=p.gpu_process_identity(worker.owner['pid'])
                if not current or current['start_ticks']!=worker.owner['start_ticks']:
                    raise RuntimeError('native component exited before listening: '+worker.name)
                await asyncio.sleep(.25)

    async def post(url,payload):
        def send():
            request=urllib.request.Request(url,json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
            start=time.monotonic()
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=1800) as response:
                value=json.loads(response.read())
                save('native_init_response.json',dict(status=response.status,response=value,elapsed_s=time.monotonic()-start))
                assert response.status==200
        await asyncio.to_thread(send)

    async def work():
        try:
            await http.start(8453)
            # Existing checkpoint payload is <13GiB. Native local_server touches
            # whole integer-GiB pool; all bytes are charged to the common parent.
            index=json.loads((MODEL/'model.safetensors.index.json').read_text())
            file_bytes=sum((MODEL/x).stat().st_size for x in set(index['weight_map'].values()))
            shm_gib=(file_bytes+p.GIB-1)//p.GIB
            save('shm_capacity.json',dict(existing_shard_bytes=file_bytes,shm_gib=shm_gib,
                native_pool_bytes=shm_gib*p.GIB,private_tmpfs_bytes=shm_gib*p.GIB+256*p.MIB))
            await platform.start_storage(dict(SHM_SIZE=str(shm_gib),USE_CACHE='0',SLOW_EXPR='0',
                REMOTE_SERVER_ADDR='127.77.49.11',NUM_REMOTE_SERVER='1',
                HYDRASERVE_NATIVE_ENTRY='scripts/kubernetes/vllm/storage_server/local_server.py'),
                shm_bytes=shm_gib*p.GIB+256*p.MIB)
            storage_wait=await listen('127.77.49.10',6666,platform.storage,True)
            print('native private storage initialized',flush=True)
            await platform.start_provider('provider','127.77.49.11',dict(
                MODELSCOPE_CACHE='/mnt/model-cache',HYDRASERVE_LOCAL_MODEL_ID='llama2_7b',
                HYDRASERVE_HF_SHARDS='1',LOCAL_SERVER='0',ENABLE_PARA='0',CPU_ENV='1',
                HYDRASERVE_NATIVE_ENTRY='scripts/kubernetes/vllm/storage_server/remote_server.py'))
            provider_wait=await listen('127.77.49.11',8888,platform.providers['provider'],True)
            print('native CPU provider initialized',flush=True)
            save('provider_ready.json',dict(storage_wait_s=storage_wait,provider_wait_s=provider_wait))
            witness=importlib.util.spec_from_file_location('d546_scheduler_witness',RAW/'request_witness.py')
            module=importlib.util.module_from_spec(witness);witness.loader.exec_module(module)
            generation,terminal_rows[:]=await module.qualify(platform,RAW,views,http,context)
            assert generation['passed']
            result.update(passed=True,actual_cpu_provider=True,actual_private_storage=True,
                native_app_init=True,shared_memory_fastload=True,physical_nodes=1,gpu_started=True,
                native_generation_qualified=True,full_scheduler_path_exercised=True,
                actual_native_idle_release=True,request_lora_qualified=False,performance_result=False,
                remote_delivery_qualified=True,qualification_scope='4000 existing W1 requests via common HTTP open-loop, native Scheduler and real-remote; development observation, not independent numerical qualification')
        finally:
            await platform.close()
            physical=ledger.finalize(arrival_end_s=context['replay_t0_s']+max(e.offset_s for e in plan.entries),
                last_terminal_s=max((r['client_completed_s'] for r in terminal_rows),default=None)
                    if len(terminal_rows)==len(plan.entries) else None,
                n_plan=len(plan.entries),n_terminal=len(terminal_rows))
            result['physical_measurement_complete']=physical['measurement_complete']
            result['physical_native_contexts_qualified']=physical['native_contexts_qualified']

    asyncio.run(asyncio.wait_for(work(),max(e.offset_s for e in plan.entries)+1800+120))
