"""Resume publication after a directory-only archive enumeration rejection.

The first backup exited before staging or writing the output archive. Preserve
its source and closure. Enumerate exact overlay manifest files, not directories.
"""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'backup.py').read_text()
old="files += sorted((RAW/'overlays').glob('*'))"
new="files += [RAW/'overlays/manifest.json'] + [RAW/'overlays'/name for name in sorted(read(RAW/'overlays/manifest.json'))]"
assert source.count(old)==1
source=source.replace(old,new)
old="exec(compile(source,str(RAW/'backup_reused.py'),'exec'),"
new="source=source.replace(\"RAW/'backup_identity.json'\",\"RAW/'backup_finish_identity.json'\")\n"+old
assert source.count(old)==1
exec(compile(source.replace(old,new),str(RAW/'backup.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'backup.py')})
