"""Audit D510 native reuse and common measurement changes; no GPU or service."""
import ast
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d510_20261013'
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path[:0]=[str(MAIN),str(BASE),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p

def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2)
def nodes(source):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}

identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save('reuse_identity.json',identity)
assert os.sched_getaffinity(0)=={2,3,26,27}
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((OLD/'remote_stop.json').read_text())['all_owned_units_inactive']
for mode in ('baseline','main'):
    assert json.loads((OLD/f'result_backup_{mode}_receipt.json').read_text())['passed']
    assert json.loads((OLD/f'result_backup_{mode}_identity_closure.json').read_text())['actual_recursive_empty']
manifest=json.loads((OLD/'source_manifest.json').read_text())
comparisons=[];changed=[];native=[]
for path,record in manifest.items():
    assert digest(record['snapshot'])==record['sha256'],path
    row=dict(path=path,old_sha256=record['sha256'],current_sha256=digest(path))
    row['same']=row['old_sha256']==row['current_sha256']
    comparisons.append(row)
    if not row['same']:
        before=nodes(Path(record['snapshot']).read_text());after=nodes(Path(path).read_text())
        row['changed_top_level_nodes']=sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k))
        changed.append(row)
    if str(BASE/'HydraServe_project/runtime') in path:
        assert row['same'],path
        native.append(path)
assert native
from HydraServe_project.runtime.native_delivery import render_overlays
from HydraServe_project.runtime.controller_runtime import render_controller_sources
NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
overlays=render_overlays(NATIVE,request_contract=True,shm_control=True,lora_admission_capacity=True)
overlays.update(render_controller_sources(NATIVE,control_observations=True,cancellation_ownership=True))
overlay_sha={k:sha256(v).hexdigest() for k,v in overlays.items()}
assert overlay_sha==json.loads((OLD/'overlays/manifest.json').read_text())
from prepare_ieee_tc_serverless_stack import load_http_replay_plan, validate_http_lifecycle_contract
cfg=json.loads((OLD/'http_7b_4000.json').read_text())
cfg.update(request_view='trace_w1_v1',replay_profile='W1',experiment_role='native_hydraserve_full_w1_single_observation')
plan=load_http_replay_plan(cfg);validate_http_lifecycle_contract(cfg)
assert plan.identity()['view_sha256']=='103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
result=dict(passed=True,review_required_for_changed_common_sources=True,
    comparisons=comparisons,changed=changed,native_runtime_files_equal=len(native),
    overlay_sha256=overlay_sha,overlays_equal=True,proposed_plan=plan.identity(),
    no_native_policy_change=True,no_gpu_run=True,plan_sha256=p.check_plan())
save('reuse_inspection.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ('comparisons','overlay_sha256')}))
