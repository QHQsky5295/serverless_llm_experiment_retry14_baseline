#!/bin/bash
set -euo pipefail
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d546_20261015
MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline
# Prerequisite success is mandatory, not an asynchronous assumption.
jq -e '.preflight_pass' "$RAW/prelaunch_gate.json" >/dev/null
jq -e 'has("3b") and has("7b")' "$RAW/remote_health.json" >/dev/null
export FAASLORA_TC_NVML_BINDING=/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py
export FAASLORA_TC_NVML_SHA256=4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea
export NO_PROXY="*" no_proxy="*" USE_TORCH=0 USE_TF=0
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1
export PRIME_REMOTE_TOKEN="$(< /home/qhq/.config/primelora-tc-d75/artifact.token)"
exec systemd-run --user --scope --unit=primelora-tc-aux-d5460000000000000000000000000009 \
 -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 -p AllowedCPUs=2,3,26,27 \
 taskset -c 2,3,26,27 /usr/bin/python3 -B "$MAIN/scripts/ieee_tc_preflight.py" \
 gated-launch --output "$RAW/launch_gate.json" --predicted-growth-gib 20 --http-replay-config "$RAW/http_7b_4000.json" \
 --exec /home/qhq/serverless_llm_baselines/installs/hydraserve_native_d484_20261013/bin/python -B "$RAW/probe.py" >"$RAW/launch.log" 2>&1
