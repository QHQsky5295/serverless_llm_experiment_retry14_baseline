"""Reuse qualified D510 native recipe for the complete common W1 arrival view.

Only campaign paths, explicit W1 input identity, and current shared measurement
sources change. No native scheduling, startup, loading or timeout tuning.
"""
import ast
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d510_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path[:0]=[str(BASE),str(BASE/'scripts')]
from HydraServe_project.runtime.native_delivery import replace_one
from prepare_ieee_tc_serverless_stack import load_http_replay_plan,validate_http_lifecycle_contract

def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def put(name,value):
    with (RAW/name).open('x') as f:f.write(value)
def save(name,value):put(name,json.dumps(value,indent=2))
def retag(source):return source.replace('d510_20261013','d546_20261015').replace('d510','d546')

identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save('prepare_identity.json',identity)
assert os.sched_getaffinity(0)=={2,3,26,27}
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
reuse=json.loads((RAW/'reuse_inspection.json').read_text())
closed=json.loads((RAW/'reuse_identity_closure.json').read_text())
assert closed['actual_recursive_empty'] and not Path(closed['identity']['path']).exists()
assert reuse['passed'] and reuse['native_runtime_files_equal']==15 and reuse['overlays_equal']
expected={str(MAIN/'faaslora/metrics/metrics_collector.py'):
    'f5edf08ae9d29352fd3b0aaa2ca5f66e30928a8980c78a40e82654aca4637147',
    str(BASE/'scripts/prepare_ieee_tc_serverless_stack.py'):
    '05826dbf8ad6d421c5d5def1c09b5801e4414dba248e7868587ec0b2b37b1919'}
assert {r['path']:r['current_sha256'] for r in reuse['changed']}==expected
for record in reuse['comparisons']:assert digest(record['path'])==record['current_sha256']
cfg=json.loads((OLD/'http_7b_4000.json').read_text())
cfg.update(request_view='trace_w1_v1',replay_profile='W1',
           experiment_role='native_hydraserve_full_w1_single_observation')
plan=load_http_replay_plan(cfg);validate_http_lifecycle_contract(cfg)
assert plan.identity()==reuse['proposed_plan']
assert digest(cfg['pool_index'])==cfg['pool_index_sha256']
save('http_7b_4000.json',cfg)
for name in ('remote_input_config.json','model_registration.json','input_qualification.json',
             'online_sources.json','official_main.py','official_scheduler.py',
             'official_engine.py','official_ModelInfo.py'):
    put(name,(OLD/name).read_text())
for name in ('close_pause.py','close_audit.py','collect_remote.py','start_remote.sh',
             'run_and_close.sh','prelaunch.py','launch.sh','run_audit.py'):
    source=retag((OLD/name).read_text())
    if name=='launch.sh':
        source=replace_one(source,'-p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0',
                          '-p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 -p AllowedCPUs=2,3,26,27')
    put(name,source)
source=retag((OLD/'remote_prelaunch.py').read_text())
source=replace_one(source,"for mode in ('baseline','main'):\n    assert json.loads((RAW/f'backup_{mode}_receipt.json').read_text())['passed']",
    "assert json.loads((RAW/'backup_receipt.json').read_text())['passed']")
put('remote_prelaunch.py',source)
put('native_body.py',retag((OLD/'native_body.py').read_text()).replace('4000 existing W0 requests','4000 existing W1 requests'))
put('request_witness.py',(OLD/'request_witness.py').read_text().replace('full4000 W0','full4000 W1'))
pool=json.loads(Path(cfg['pool_index']).read_text())['artifacts'];assert len(pool)==500
save('lora_registry.json',[dict(adapter_id=aid,adapter_index=i,
    adapter_path=str(RAW/'adapter_views'/aid)) for i,aid in enumerate(sorted(x['id'] for x in pool),1)])
prereg=json.loads((OLD/'preregistration.json').read_text())
for key,ref in prereg['references'].items():
    if key=='plan':
        assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
        ref['sha256']=p.check_plan()
    else:assert digest(ref['path'])==ref['sha256']
prereg.update(campaign='d546_20261015',workload='W1',plan_identity=plan.identity(),
    interpretation='one full W1 known-trace development binding/accounting observation; independent numerical qualification remains unknown',
    reuse_from=str(OLD),reuse_audit_sha256=digest(RAW/'reuse_inspection.json'),
    full_config_source=str(OLD/'http_7b_4000.json'),full_config_sha256=digest(OLD/'http_7b_4000.json'),
    adaptation_change='unchanged D510 native implementation; shared D531 W1 arrival view and D541 kernel-exit measurement repair',
    source_heads={label:subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
                  for label,root in [('baseline',BASE),('main',MAIN)]})
save('preregistration.json',prereg)
template=retag((OLD/'executed_prepare.py').read_text())
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
assert json.loads((RAW/'overlays/manifest.json').read_text())==json.loads((OLD/'overlays/manifest.json').read_text())
audit=(OLD/'audit.py').read_text()
audit=replace_one(audit,digest(OLD/'preregistration.json'),digest(RAW/'preregistration.json'))
audit=audit.replace('full-W0','full-W1').replace('full_w0','full_w1').replace('observed_w0_g1_feasible','observed_w1_g1_feasible')
put('audit.py',audit)
for path in RAW.glob('*.py'):
    if path.name=='native_body.py':continue
    ast.parse(path.read_text(),filename=str(path))
for path in RAW.glob('*.sh'):subprocess.run(['bash','-n',str(path)],check=True)
command=[sys.executable,'-B','-m','unittest',
    'tests.test_ieee_tc_serverless_measurement.W1ReplayViewTests',
    'tests.test_ieee_tc_hydraserve_http_contract',
    'tests.test_ieee_tc_hydraserve_physical_lifecycle','-v']
with (RAW/'cpu_contract_tests.log').open('x') as log:
    test=subprocess.run(command,cwd=BASE,stdout=log,stderr=subprocess.STDOUT)
save('prepare_result.json',dict(passed=test.returncode==0,tests_returncode=test.returncode,command=command,
    preregistration_sha256=digest(RAW/'preregistration.json'),d510_overlays_equal=True,
    native_runtime_files_equal=15,reviewed_common_changes=reuse['changed'],
    n_plan=4000,prepared_not_launched=True,performance_result=False,
    source_sha256={str(path):digest(path) for path in (RAW/'prepare.py',RAW/'inspect_reuse.py',
        RAW/'inspect_reuse_v2.py',RAW/'reuse_inspection.json',RAW/'cpu_contract_tests.log',
        RAW/'source_manifest.json',RAW/'audit.py',RAW/'preregistration.json')}))
assert test.returncode==0
print(json.dumps(json.loads((RAW/'prepare_result.json').read_text())))
