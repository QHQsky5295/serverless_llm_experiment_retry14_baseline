"""Main guard preserves the existing wrapper multiprocessing contract."""
if __name__ == "__main__":
    """D655: reuse D553's CPU-only full W2 input audit with the existing 3B tokenizer."""
    import importlib.util
    import json
    import os
    from pathlib import Path
    import subprocess
    import sys
    import unittest
    from types import SimpleNamespace
    
    ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
    BASE=Path('/home/qhq/serverless_llm_baselines')
    RAW=Path(__file__).resolve().parent
    RESULTS=RAW.parent.parent
    sys.path.insert(0,str(ROOT))
    sys.path.insert(0,str(BASE/'scripts'))
    from scripts import ieee_tc_preflight as p
    import prepare_ieee_tc_serverless_stack as http
    from faaslora.datasets.workload_generator import FrozenReplayPlan, prepare_frozen_http_request
    from scripts.ieee_tc.audit_d402_serverlessllm_path import validate_population
    
    def save(path,value):
        with path.open('x') as stream:
            json.dump(value,stream,indent=2,allow_nan=False)
    
    identity=p.scope_identity(p.cg_path().name)
    save(RAW/'qualification_identity.json',identity)
    group=Path(identity['path'])
    assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
    assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip()=='0'
    assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    gate=p.preflight([ROOT],p.GIB)
    assert gate['preflight_pass'],gate['issues']
    audit=json.loads((RAW/'audit.json').read_text())
    assert audit['passed'] and json.loads((RAW/'analysis_closure.json').read_text())['path_gone']
    map_path=Path(audit['manifest']['path'])
    assert p.digest(map_path)==audit['manifest']['sha256']
    mapping=json.loads(map_path.read_text())
    old_cfg_path=RESULTS/'vllm_qualification/d653_20261018/http_3b_4000.json'
    old_cfg=json.loads(old_cfg_path.read_text())
    assert p.digest(Path(old_cfg['trace']))==mapping['source_sha256']
    cfg=dict(old_cfg,trace=mapping['source_path'],request_view='trace_w2_v1',replay_profile='W2',
        adapter_map=str(map_path),adapter_map_sha256=p.digest(map_path),
        experiment_role='full_w2_input_qualification_only')
    save(RAW/'http_3b_4000.json',cfg)
    plan=http.load_http_replay_plan(cfg)
    w0=FrozenReplayPlan.load(cfg['trace'])
    context=dict(plan=plan.identity(),tiny_witness=False,replay_scope='full_source_v1')
    assert FrozenReplayPlan.from_launch_context(context)==plan
    assert len(plan.entries)==plan.source_count==4000
    from scripts.run_all_experiments import _load_shared_trace_requests
    _,traces,metadata=_load_shared_trace_requests(cfg['trace'],
        allowed_adapter_ids=mapping['adapter_order'],external_replay=SimpleNamespace(plan=plan,context=context))
    assert metadata['replay_plan']==plan.identity()
    from transformers import AutoTokenizer
    tokenizer=AutoTokenizer.from_pretrained(cfg['backbone'],local_files_only=True)
    contracts={}
    for ordinal,(old,entry,trace) in enumerate(zip(w0.entries,plan.entries,traces)):
        assert (old.request_id,old.offset_s)==(entry.request_id,entry.offset_s)
        a,b=[prepare_frozen_http_request(e,tokenizer,cfg['model']) for e in (old,entry)]
        for key in ('canonical_prompt_sha256','native_prompt_token_ids_sha256','target_tokens'):
            assert a[key]==b[key],(entry.request_id,key)
        row=json.loads(entry.source_json)
        assert trace.adapter_id==b['adapter_id']==mapping['rows'][ordinal]['adapter_id']
        assert trace.chat_messages==row['body']['messages']
        assert trace.expected_output_tokens==json.loads(old.source_json)['expected_output_tokens']
        assert b['body']['lora_adapter_name']==trace.adapter_id
        # Reverse only the explicit adapter/domain/provenance transform.
        annotation=row.pop('tc_adapter_rotation')
        row['adapter_id']=row['body']['lora_adapter_name']=annotation['original_adapter_id']
        row['adapter_domain']=annotation['original_adapter_domain']
        assert row==json.loads(old.source_json)
        contracts[entry.request_id]=b
    assert validate_population(cfg,dict(plan=plan.identity()),contracts,http,'full4000_w2')==4000
    for population in ('full4000','full4000_w1'):
        try: validate_population(cfg,dict(plan=plan.identity()),contracts,http,population)
        except ValueError: pass
        else: raise AssertionError('W2 accepted under another population')
    
    from replay_vllm_engine_trace import validate_native_service_config
    from scripts.ieee_tc.audit_d402_serverlessllm_path import validate_metric_model
    native_config=BASE/'configs/ieee_tc/vllm_3b_resident_native_compiler_v1.json'
    http.validate_http_lifecycle_contract(cfg)
    validate_native_service_config(json.loads(native_config.read_text()),cfg)
    slo=ROOT/'paper_results/ieee_tc/protocols/20261017_3b_slo_d648_frozen.json'
    assert validate_metric_model(cfg,'3b',ROOT,json.loads(slo.read_text()))=='llama32_3b_main_modelscope'
    prior=RESULTS/'vllm_qualification/d649_20261018/qualification.json'
    binding=json.loads(prior.read_text())
    assert binding['passed'] and binding['tests']==89 and binding['no_gpu_run']
    for path,sha in {**binding['refs'],**binding['preserved']}.items():
        assert p.digest(Path(path))==sha,path
    loader=unittest.defaultTestLoader
    suite=loader.loadTestsFromNames([
        'tests.test_ieee_tc_external_replay.FrozenRotationViews',
        'tests.test_tc_serverless_qualification_population.QualificationPopulationTests.test_full_w2_requires_map_and_per_request_rotation_provenance'])
    test_path=BASE/'tests/test_ieee_tc_vllm_service.py'
    with (RAW/'tests.log').open('x') as log:
        tests=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    import torch
    assert not torch.cuda.is_initialized()
    protected=p.verify_seal(RESULTS/'slora_qualification/d435_20261011/protected_before.json')
    assert protected['pass'] and protected['entry_count']==147
    preserved={ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
        BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
        BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
    for path,sha in preserved.items():assert p.digest(path)==sha
    for repo in (ROOT,BASE):subprocess.run(['git','diff','--check'],cwd=repo,check=True)
    refs=[prior,native_config,slo,BASE/'scripts/replay_vllm_engine_trace.py',Path(__file__),map_path,old_cfg_path,RAW/'http_3b_4000.json',test_path,
        ROOT/'faaslora/datasets/workload_generator.py',ROOT/'scripts/ieee_tc_preflight.py',
        ROOT/'scripts/run_all_experiments.py',ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',
        ROOT/'tests/test_ieee_tc_external_replay.py',ROOT/'tests/test_ieee_tc_launch.py',
        ROOT/'tests/test_ieee_tc_preflight.py',ROOT/'tests/test_tc_serverless_qualification_population.py',
        BASE/'scripts/prepare_ieee_tc_serverless_stack.py',
        ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
    record=dict(reused_service_tests=89,reused_service_qualification=str(prior),passed=tests.wasSuccessful() and not tests.skipped,tests=tests.testsRun,
        failures=len(tests.failures),errors=len(tests.errors),skipped=len(tests.skipped),
        identity=identity,gate=gate,protected=protected,preserved={str(k):v for k,v in preserved.items()},
        http_plan=plan.identity(),prime_plan=metadata['replay_plan'],requests=4000,
        unique_adapter_ids=len({r['adapter_id'] for r in contracts.values()}),
        target_tokens=sum(r['target_tokens'] for r in contracts.values()),
        original_arrivals_prompts_targets_unchanged=True,all_native_prompt_token_ids_equal=True,
        integrated_service_adapter_binding_equal=True,new_trace_or_weights_generated=False,
        gpu_run_started=False,native_execution_qualified=False,numerical_correctness_qualified=False,
        refs={str(path):p.digest(path) for path in refs})
    save(RAW/'qualification.json',record)
    print(json.dumps({key:record[key] for key in ('passed','tests','failures','errors','skipped',
        'requests','unique_adapter_ids','target_tokens','http_plan')},indent=2))
    assert record['passed']
