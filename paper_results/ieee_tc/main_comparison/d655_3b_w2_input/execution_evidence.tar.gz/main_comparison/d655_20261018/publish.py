"""D655 input curation: reuse D654 explicit-path integrity and backup checks."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OUT = MAIN/'paper_results/ieee_tc/main_comparison/d655_3b_w2_input'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'publication_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
audit = read(RAW/'audit.json')
qual = read(RAW/'qualification.json')
assert audit['passed'] and qual['passed'] and qual['tests'] == 7
assert not qual['failures'] and not qual['errors'] and not qual['skipped']
assert qual['requests'] == 4000 and qual['unique_adapter_ids'] == 497 and qual['target_tokens'] == 458224
assert qual['http_plan'] == qual['prime_plan']
assert qual['original_arrivals_prompts_targets_unchanged'] and qual['all_native_prompt_token_ids_equal']
assert not qual['gpu_run_started'] and not qual['numerical_correctness_qualified']
assert 'Ran 7 tests' in (RAW/'tests.log').read_text() and (RAW/'tests.log').read_text().rstrip().endswith('OK')
for path, sha in {**qual['refs'], **qual['preserved']}.items():
    assert p.digest(Path(path)) == sha, path
for ref in audit['refs']:
    assert p.digest(Path(ref['path'])) == ref['sha256']
for phase in ('analysis', 'qualification'):
    closed = read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
prior = RAW.parent.parent/'vllm_qualification/d654_20261018'
assert read(prior/'cache_cleanup_after.json')['removed']
for phase in ('publication','qualification'):
    closed = read(prior/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
parents = {MAIN: '82e9c4d3c1a49e8d354f05dd0a7b8eae4ecaf1fc', BASE: 'e16af33aaf41f02a62ecdce59f6f3227813244c3'}
for repo, head in parents.items():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == head
assert not OUT.exists()
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}', data)
files = [RAW/name for name in ('audit_map.py','qualify.py','close.py','publish.py','tests.log',
    'analysis_identity.json','analysis_closure.json','qualification_identity.json','qualification_closure.json',
    'http_3b_4000.json','publication_identity.json')]
files += [prior/name for name in ('reclaim_objects.py','cache_cleanup_before.json','cache_cleanup_after.json',
    'qualification_closure.json','publication_identity.json','publication_closure.json','publication_receipt.json')]
OUT.mkdir(parents=True, exist_ok=False)
members = {}
with tarfile.open(OUT/'execution_evidence.tar.gz', 'x:gz') as bundle:
    for path in files:
        data = path.read_bytes()
        check(data)
        member_cap = 8*1024*1024
        assert len(data) < member_cap, str(path)
        if path.suffix == '.py':
            ast.parse(data)
        name = str(path.relative_to(RAW.parent.parent))
        info = tarfile.TarInfo(name)
        info.size = len(data); info.mode = 0o600; info.mtime = 0
        bundle.addfile(info, io.BytesIO(data))
        members[name] = dict(path=str(path), sha256=p.digest(path), bytes=len(data))
with tarfile.open(OUT/'execution_evidence.tar.gz') as bundle:
    assert set(bundle.getnames()) == set(members)
    for name, ref in members.items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == ref['sha256']
assert (OUT/'execution_evidence.tar.gz').stat().st_size < 16*1024*1024
with (OUT/'audit.json').open('xb') as f:
    f.write((RAW/'audit.json').read_bytes())
with (OUT/'qualification.json').open('xb') as f:
    f.write((RAW/'qualification.json').read_bytes())
save(OUT/'manifest.json', dict(passed=True, identity=identity,
    execution_main_commit=parents[MAIN], execution_baseline_commit=parents[BASE],
    role='3b_w2_shared_input_qualification_only', no_service_change=True, no_gpu_run=True,
    reused_service_tests=qual['reused_service_tests'], affected_tests=qual['tests'],
    metric_protocol_sha256=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_protocol_sha256=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    plan_sha256=p.check_plan(), preserved=qual['preserved'], protected=protected,
    source_refs=qual['refs'], adapter_map=audit['manifest'], archive_members=members,
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='Only input qualification, not GPU performance or independent numerical correctness; original known source42/development41 retained.'))
outputs = ['audit.json', 'qualification.json', 'manifest.json', 'execution_evidence.tar.gz']
with (OUT/'result.sha256').open('x') as f:
    for name in outputs:
        f.write(p.digest(OUT/name)+'  '+name+'\n')
names = ['docs/ieee_tc/D655_3B_W2_INPUT_QUALIFICATION.md', 'docs/ieee_tc/D654_3B_NATIVE_RESIDENT_W1.md',
    'docs/ieee_tc/EXECUTION_STATUS.md','paper_results/ieee_tc/inputs/20261018_3b_w2_adapter_map_v1.json']
names += [str((OUT/name).relative_to(MAIN)) for name in outputs+['result.sha256']]
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=MAIN, text=True).strip()
subprocess.run(['sha256sum', '-c', 'result.sha256'], cwd=OUT, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=MAIN, check=True)
for name in names:
    check((MAIN/name).read_bytes())
subprocess.run(['git', 'add', '--', *names], cwd=MAIN, check=True)
assert set(subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=MAIN, text=True).splitlines()) == set(names)
assert 'configs/generated/lora_manifest_1000.json' not in names
for name in names:
    assert subprocess.check_output(['git', 'show', ':'+name], cwd=MAIN) == (MAIN/name).read_bytes()
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=MAIN, check=True)
subprocess.run(['git', 'commit', '-m', 'tc: qualify existing 3B W2 input without regenerating workloads (D655)'], cwd=MAIN, check=True)
subprocess.run(['git', 'push', 'faaslora_origin', 'retry14_continuous_queue_v2'], cwd=MAIN, check=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=MAIN, text=True).strip()
remote = subprocess.check_output(['git', 'ls-remote', 'faaslora_origin', 'refs/heads/retry14_continuous_queue_v2'], cwd=MAIN, text=True).split()[0]
assert head == remote
save(RAW/'publication_receipt.json', dict(passed=True, head=head, remote=remote, files=names,
    identity=identity, protected=protected, baseline_commit=parents[BASE]))
print(json.dumps(dict(passed=True, head=head, files=len(names), remote_equal=True)))
