"""D655: reuse D553 immutable W2 adapter-index derivation for the existing 3B trace."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from collections import Counter

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/inputs/20261018_3b_w2_adapter_map_v1.json'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan, _hotset_rotation_stride

def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,ensure_ascii=False,allow_nan=False)

identity=p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate=p.preflight([ROOT],p.GIB)
assert gate['preflight_pass'],gate['issues']
source=Path(json.loads((RAW.parent.parent/'vllm_qualification/d649_20261018/qualification.json').read_text())['views']['4000']['plan']['source_path'])
assert p.digest(source)=='4ea5d026da3820301e753ad6b03ea776e25a5c3f01921933bd124598eb26018d'
data=json.loads(source.read_text())
plan=FrozenReplayPlan.load(source,profile='W0')
assert len(plan.entries)==plan.source_count==4000
assert data['selected_num_adapters']==500 and data['sampling_seed']==42
adapters=data['selected_adapters']
ids=[row['id'] for row in adapters]
assert len(ids)==len(set(ids))==500
positions={aid:i for i,aid in enumerate(ids)}
assert all(row['manifest_index']==i for i,row in enumerate(adapters))
pool=ROOT/'paper_results/ieee_tc/inputs/20260927_3b_remote_content_index.json'
assert p.digest(pool)=='bd1826c58f00ea30dee1d3829dc11727a975127db701a1eee6c6c86b4a38f275'
assert set(ids)=={row['id'] for row in json.loads(pool.read_text())['artifacts']}
assert _hotset_rotation_stride(48,rotation_mode='legacy',overlap_fraction=.75)==12
rows=[]
old_counts,new_counts,ranks=Counter(),Counter(),Counter()
for ordinal,entry in enumerate(plan.entries):
    row=json.loads(entry.source_json)
    assert row==data['requests'][ordinal]
    old=row['adapter_id']
    assert row['body']['lora_adapter_name']==old
    source_start=(ordinal//500*12)%500
    rank=(positions[old]-source_start)%500
    assert 0<=rank<48,(ordinal,old,rank)
    target_start=(ordinal//100*12)%500
    new=ids[(target_start+rank)%500]
    # Independent ordered-window witness of the same rank-preserving transform.
    window=(ids[target_start:]+ids[:target_start])[:48]
    assert window[rank]==new
    rows.append(dict(request_id=entry.request_id,source_item_sha256=entry.source_sha256,
        original_adapter_id=old,adapter_id=new,local_rank=rank))
    old_counts[old]+=1;new_counts[new]+=1;ranks[rank]+=1
assert sum(ranks.values())==4000 and len(old_counts)==132
manifest=dict(schema='rank_preserving_hotset_rotation_v1',model='llama32_3b',
    source_path=str(source),source_sha256=plan.source_sha256,
    source_w0_view_sha256=plan.identity()['view_sha256'],source_count=4000,
    pool_index=str(pool),pool_index_sha256=p.digest(pool),
    adapter_order=ids,source_rotation_requests=500,target_rotation_requests=100,
    active_adapter_cap=48,rotation_stride=12,adjacent_hotset_overlap_fraction=.75,
    derivation='local_rank=(source_adapter_index-12*floor(ordinal/500)) mod 500; target_index=(local_rank+12*floor(ordinal/100)) mod 500',
    rows=rows,scope='frozen adapter index only; existing arrivals/prompts/token targets are never regenerated')
save(OUT,manifest)
assert json.loads(OUT.read_text())==manifest
for row,entry in zip(manifest['rows'],plan.entries):
    assert row['source_item_sha256']==entry.source_sha256
assert p.digest(source)==manifest['source_sha256']
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
refs=[source,pool,Path(__file__),ROOT/'faaslora/datasets/dataset_loader.py',
    ROOT/'faaslora/datasets/workload_generator.py',ROOT/'configs/experiments.yaml',
    BASE/'scripts/export_shared_faaslora_trace.py']
result=dict(passed=True,kind='w2_rank_inversion_input_audit_v1',identity=identity,
    source_unchanged=True,new_trace_generated=False,new_weights_generated=False,
    performance_or_native_qualification=False,production_w2_implemented=True,
    count=4000,original_unique=len(old_counts),w2_unique=len(new_counts),
    changed_adapter_requests=sum(r['adapter_id']!=r['original_adapter_id'] for r in rows),
    target_tokens=sum(min(json.loads(e.source_json)['expected_output_tokens'],256) for e in plan.entries),
    local_rank_histogram=dict(sorted(ranks.items())),all_source_ranks_inside_original_window=True,
    window_size=48,stride=12,overlap_fraction=.75,source_rotation_requests=500,target_rotation_requests=100,
    manifest=dict(path=str(OUT),sha256=p.digest(OUT),bytes=OUT.stat().st_size),
    protected=protected,preflight=gate,refs=[dict(path=str(x),sha256=p.digest(x)) for x in refs])
save(RAW/'audit.json',result)
print(json.dumps({key:result[key] for key in ('passed','count','original_unique','w2_unique','changed_adapter_requests','target_tokens','manifest')},indent=2))
