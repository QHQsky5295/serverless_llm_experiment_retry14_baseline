"""Reuse D594 explicit-path, source-SHA, secrets and protected-artifact backup."""
from pathlib import Path
source=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/publish.py')
code=source.read_text()
def replace(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)
replace("OUT=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft'", "OUT=ROOT/'paper_results/ieee_tc/main_comparison/d600_parallel_pressure_diagnosis'")
replace("expected_head='a7da3b32f28def306a04dd98e5dddec91c63c87c'", "expected_head='1b57a4500552ea4592ae15de439984f9ccde9444'")
replace("('analysis','remote_diagnosis','pressure_diagnosis')", "('analysis','remote_diagnosis','pressure_diagnosis','trajectory','lifecycle')")
replace("token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()", """
storage=RAW.parent.parent/'storage_maintenance/d599_20261017'
closure=read(storage/'storage_closure.json')
assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()
receipt=read(storage/'receipt.json'); result=read(storage/'storage_result.json')
assert receipt['passed'] and result['source_archive_round_trip_verified']
assert p.digest(storage/'storage_result.json')==receipt['result_sha256']
for row in result['entries']:
    assert not Path(row['source']).exists()
    assert p.digest(Path(row['archive']))==row['archive_sha256']
    assert row['source_sha256']==row['first_roundtrip_sha256']==row['second_roundtrip_sha256']
storage_out=ROOT/'paper_results/ieee_tc/storage/d599_closed_d598'
storage_out.mkdir(parents=True,exist_ok=False)
save(storage_out/'summary.json',dict(passed=True,result=result,closure=closure,receipt=receipt))
members += [storage/x for x in ('compress.py','close.py','prechecks.json','storage_identity.json','storage_result.json','receipt.json','storage_closure.json')]
base=source.parent
members += [base/x for x in ('analyze.py','remote_diagnosis.py','pressure_diagnosis.py','close.py','publish.py')]
members += [storage.parent/'d596_20261017/compress.py',storage.parent/'d592_20261017/close.py']
def arcname(path):
    return path.name if path.parent==RAW else path.parent.name+'/'+path.name
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
""")
replace('arcname=path.name,recursive=False', 'arcname=arcname(path),recursive=False')
replace('bundle.extractfile(path.name).read()', 'bundle.extractfile(arcname(path)).read()')
replace("names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D594_REFERENCE_AND_REMOTE_PREPARATION.md']", "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D600_PARALLEL_PRESSURE_DIAGNOSIS.md','docs/ieee_tc/D599_CLOSED_OUTCOME_STORAGE.md',str((storage_out/'summary.json').relative_to(ROOT))]")
replace('tc: freeze known 7B reference values and localize remote preparation waits (D594)', 'tc: preserve W2 local benefit versus system regression and closed-log compression (D599-D600)')
exec(compile(code,str(source),'exec'))
