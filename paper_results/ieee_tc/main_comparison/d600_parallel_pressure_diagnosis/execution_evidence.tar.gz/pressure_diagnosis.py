"""Reuse D594 barrier decomposition; overlapping RPC sums are not critical paths."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/pressure_diagnosis.py')
code = source.read_text()
for old,new in [
    ("OUT=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft'", "OUT=ROOT/'paper_results/ieee_tc/main_comparison/d600_parallel_pressure_diagnosis'"),
    ("[('D551','W1'),('D554','W2')]", "[('D554','W2'),('D598','W2')]"),
    ('results[w]=dict(', 'results[run]=dict('),
    ("'RPC sums are nested inside pressure start/finish; not additive with the enclosing phase.'", "'RPC sums overlap across D598 owners and are nested; never an additive critical-path decomposition or causal gain.'"),
]:
    assert code.count(old)==1,old
    code=code.replace(old,new)
exec(compile(code,str(source),'exec'))
