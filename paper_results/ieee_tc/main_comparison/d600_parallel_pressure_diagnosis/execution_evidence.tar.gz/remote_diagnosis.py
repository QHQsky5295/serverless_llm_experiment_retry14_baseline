"""Reuse the strict D594 bilateral transfer join; two actual W2 runs, not repeats."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/remote_diagnosis.py')
code = source.read_text()
for old,new in [
    ("OUT=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft'", "OUT=ROOT/'paper_results/ieee_tc/main_comparison/d600_parallel_pressure_diagnosis'"),
    ("[('D551','W1'),('D554','W2')]", "[('D554','W2'),('D598','W2')]"),
    ('summaries[w]=dict(', 'summaries[run]=dict('),
]:
    assert code.count(old)==1,old
    code=code.replace(old,new)
exec(compile(code,str(source),'exec'))
