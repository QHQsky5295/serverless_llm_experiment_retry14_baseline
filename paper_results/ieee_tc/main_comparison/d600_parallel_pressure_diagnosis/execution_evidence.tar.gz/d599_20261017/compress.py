"""Reuse D596's bounded, verified compressor for D598 only; no old target list."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/storage_maintenance/d596_20261017/compress.py')
code = source.read_text()
old = "targets = ['d533_20261015/7b_full_w1', 'd512_20261014/7b_full_w0_prefix1',\n           'd519_20261014/7b_full_w0_prefix1']"
assert code.count(old) == 1
code = code.replace(old, "targets = ['d598_20261017/7b_parallel_pressure_full_w2']")
exec(compile(code, str(source), 'exec'))
