"""Stream retained client receipts; join remote IDs without cross-clock subtraction."""
import csv, json, math, os, subprocess, sys
from collections import Counter
from pathlib import Path
from statistics import fmean
import ijson
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d594_reference_and_ttft'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.analyze_d297_full import retained_preparation_row
def read(path): return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f: json.dump(obj,f,indent=2,allow_nan=False)
def describe(xs):
    xs=sorted(xs)
    assert all(type(v) in (int,float) and math.isfinite(v) for v in xs)
    return dict(n=len(xs),mean=fmean(xs) if xs else None,
        p95_type1=xs[math.ceil(.95*len(xs))-1] if xs else None,max=xs[-1] if xs else None)
identity=p.scope_identity(p.cg_path().name); cg=Path(identity['path'])
save(RAW/'remote_diagnosis_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],8*1024*1024);save(RAW/'remote_diagnosis_resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
old=read(OUT/'manifest.json');sources={r['path']:r['sha256'] for r in old['source_refs']}
stage_path=OUT/'request_stages.csv'
assert p.digest(stage_path)==old['outputs']['request_stages.csv']
with stage_path.open() as f: stages={(r['run'],r['request_id']):r for r in csv.DictReader(f)}
all_rows=[]; summaries={}
spans=[('admission_to_download_start_ms','admitted','loading_started_monotonic_s'),
    ('request_to_headers_ms','loading_started_monotonic_s','headers_received_monotonic_s'),
    ('reserve_receive_write_ms','headers_received_monotonic_s','body_received_monotonic_s'),
    ('body_to_extract_start_ms','body_received_monotonic_s','extraction_started_monotonic_s'),
    ('extract_verify_ms','extraction_started_monotonic_s','extraction_completed_monotonic_s'),
    ('extract_to_publication_ms','extraction_completed_monotonic_s','published_monotonic_s'),
    ('publication_to_download_return_ms','published_monotonic_s','client_completed_monotonic_s'),
    ('download_return_to_native_load_ms','client_completed_monotonic_s','native_start'),
    ('native_load_ms','native_start','acquired'),('acquired_to_engine_ms','acquired','dispatch')]
for run,w in [('D551','W1'),('D554','W2')]:
    source=next(Path(k) for k in sources if f'/{run.lower()}_' in k and '/experiment_results_' in k)
    assert p.digest(source)==sources[str(source)]
    journal=source.parent.parent/'remote_transfers.jsonl'
    sources[str(journal)]=p.digest(journal)
    with journal.open() as f: servers=[json.loads(line) for line in f]
    server={r['transfer_id']:r for r in servers}
    assert len(server)==len(servers)
    assert len({r['clock_id'] for r in servers})==1
    assert all(r['outcome']=='sent' and r['delivery_mode']=='prepublished_gzip_v1'
        and r['pack_performed'] is False for r in servers)
    counts=Counter();rows=[];examples={}
    with source.open('rb') as f:
        for r in ijson.items(f,'detailed_results.tc_ieee_full.requests.item',use_float=True):
            counts['requests']+=1
            prep=retained_preparation_row(r); e=r['gpu_reference_evidence']
            if prep['tier']=='remote': counts['selected_remote']+=1
            remote=e.get('remote_preparation')
            if remote is None: continue
            counts['has_owned_remote_receipt']+=1
            assert remote['state']=='published' and remote['content_verified'] is True
            assert remote['artifact_id']==r['adapter_id']
            s=server[remote['http_transfer_id']]
            assert s['artifact_id']==r['adapter_id'] and s['bytes_written']==remote['transferred_bytes']
            assert s['archive_sha256']==remote['remote_archive_sha256']
            assert remote['loading_clock_id']==e['receipt']['clock_id']==e['source_admission']['clock_id']
            if not prep['native_load_invoked']:
                counts['owned_remote_but_native_reused']+=1
                continue
            st=stages[(run,r['request_id'])]
            times=dict(remote,admitted=e['source_admission']['admitted_monotonic_s'],
                native_start=e['receipt']['native_load_started_monotonic_s'],
                acquired=e['receipt']['acquired_monotonic_s'],dispatch=r['native_token_timing']['native_dispatch_monotonic_s'])
            row=dict(run=run,workload=w,request_id=r['request_id'],adapter_id=r['adapter_id'],
                source_index=int(st['source_index']),source_quarter=int(st['source_quarter']),
                tier=prep['tier'],joint=st['joint']=='True',transfer_id=remote['http_transfer_id'],
                wire_bytes=remote['transferred_bytes'],materialized_bytes=remote['payload_bytes_verified'])
            for key,a,b in spans:
                assert all(type(times[k]) in (int,float) and math.isfinite(times[k]) for k in (a,b))
                assert times[a]<=times[b],(key,times[a],times[b])
                row[key]=1000*(times[b]-times[a])
            row['admission_to_engine_ms']=prep['admission_to_engine_ms']
            assert abs(sum(row[k] for k,_,_ in spans)-row['admission_to_engine_ms'])<.001
            row['server_handler_ms']=(s['handler_completed_ns']-s['handler_started_ns'])/1e6
            row['server_send_ms']=(s['send_completed_ns']-s['send_started_ns'])/1e6
            row['server_read_ms']=s['object_read_wall_ns']/1e6
            row['server_socket_write_ms']=s['socket_write_wall_ns']/1e6
            examples.setdefault('remote_receipt_keys',sorted(remote))
            examples.setdefault('native_rpc_timing_example',prep['final_rpc_timing'])
            rows.append(row)
    assert counts['requests']==4000
    assert len({r['transfer_id'] for r in rows})==len(rows)
    cohorts=[('all','all',rows)]
    cohorts += [('quarter',str(i),[r for r in rows if r['source_quarter']==i]) for i in range(1,5)]
    cohorts += [('joint',str(v),[r for r in rows if r['joint']==v]) for v in (False,True)]
    groups=[dict(group=kind,label=label,n=len(rs),joint=sum(r['joint'] for r in rs),
        metrics={k:describe(r[k] for r in rs) for k in [s[0] for s in spans]+[
            'admission_to_engine_ms','wire_bytes','materialized_bytes','server_handler_ms',
            'server_send_ms','server_read_ms','server_socket_write_ms']}) for kind,label,rs in cohorts]
    summaries[w]=dict(run=run,counts=dict(counts),groups=groups,examples=examples,
        server_all_transfers=dict(n=len(servers),wire_bytes=sum(s['bytes_written'] for s in servers),
            handler_ms=describe((s['handler_completed_ns']-s['handler_started_ns'])/1e6 for s in servers)),
        observed_request_transfer_ids=len(rows),server_only_or_other_reasons=len(servers)-len(rows))
    assert p.digest(source)==sources[str(source)] and p.digest(journal)==sources[str(journal)]
    all_rows+=rows
save(OUT/'remote_diagnosis.json',dict(passed=True,results=summaries,
    selected_population='Owned remote transfer plus invoked final native load; shared/reused sources excluded with counts, not zeros.',
    additive_client_stages=[s[0] for s in spans],cross_host_subtraction=False,causal_intervention=False,
    caveats=['Server spans are nested/descriptive and must not be added to client timeline.',
        'Receive interval includes local reservation, reading, hashing and writing; not pure wire latency.',
        'Admission-to-download and return-to-native gaps are not instrumented internally in these receipts.',
        'No stage has been subtracted from actual end-to-end performance.']))
with (OUT/'remote_stages.csv').open('x',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(all_rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(all_rows)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
resources={k:(cg/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
sources[str(RAW/'remote_diagnosis.py')]=p.digest(RAW/'remote_diagnosis.py')
save(RAW/'remote_diagnosis_receipt.json',dict(passed=True,rows=len(all_rows),identity=identity,resources=resources,
    source_refs=[dict(path=k,sha256=v) for k,v in sources.items()],protected=protected,
    outputs={name:p.digest(OUT/name) for name in ('remote_diagnosis.json','remote_stages.csv')}))
print(json.dumps(dict(passed=True,rows=len(all_rows),resources=resources,
    overview={w:dict(counts=v['counts'],means={k:stat['mean'] for k,stat in v['groups'][0]['metrics'].items()}) for w,v in summaries.items()})))
