"""Reuse D554 streaming stages/D360 preparation receipts and D424 physical gate.

Offline diagnostics and reference review only; no new inference or tuning.
"""
import csv, hashlib, json, math, os, subprocess, sys
from collections import Counter
from pathlib import Path
from statistics import fmean
import ijson
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
P=ROOT/'paper_results/ieee_tc'
OUT=P/'main_comparison/d594_reference_and_ttft'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import partition_retained_request_stages
from scripts.ieee_tc.analyze_d297_full import retained_preparation_row
from scripts.ieee_tc.check_d299_full_context import closed_physical_integral
def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'analysis_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate=p.preflight([ROOT],16*1024*1024);save(RAW/'resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
matrix_path=P/'main_comparison/d593_complete_7b/comparison.json'
matrix=read(matrix_path);sources={str(matrix_path):p.digest(matrix_path)}
def checked(path,sha=None):
    digest=p.digest(path)
    if sha is not None: assert digest==sha,path
    sources[str(path)]=digest
    return read(path)
for ref in matrix['source_refs']: checked(Path(ref['path']),ref['sha256'])
slo_path=P/'protocols/20261010_7b_slo_d394_frozen.json'
slo=checked(slo_path,matrix['common_slo_sha256'])
for name in ('METRIC_PROTOCOL_FROZEN_V1.md','METRIC_PROTOCOL_SINGLE_RUN_V2.md'):
    path=ROOT/'docs/ieee_tc'/name;sources[str(path)]=p.digest(path)
references={}
for w,run in [('W1','d536'),('W2','d557')]:
    audit_path=P/f'main_comparison/{run}_vllm_{w.lower()}/result1/audit.json'
    audit=read(audit_path)
    refs={r['path']:r['sha256'] for r in audit['raw_sources']}
    physical_path=next(Path(k) for k in refs if k.endswith('/physical/summary.json'))
    physical=checked(physical_path,refs[str(physical_path)])
    u=closed_physical_integral(physical)
    assert len(physical['device_intervals'])==4 and u==audit['physical_gpu_seconds']
    worker_path=next(Path(k) for k in refs if k.endswith('/worker_config.json'))
    config=checked(worker_path,refs[str(worker_path)])
    assert len(set(config['gpu_ids']))==4 and config['version']=='0.30.0'
    assert audit['backend_ready_receipts']==4 and audit['common_slo']['binding_valid']==4000
    assert audit['measurement_complete'] and audit['workload_passed']
    assert audit['n_correct'] is None and audit['independent_lora_numerical_correctness'] is False
    row=matrix['results'][w]['vLLM']
    assert audit['source_plan']['view_sha256']==matrix['common_workload_identities'][w]['view_sha256']
    prereg=ROOT/f'docs/ieee_tc/{run.upper()}_VLLM_{w}_REFERENCE.md'
    sources[str(prereg)]=p.digest(prereg)
    references[w]=dict(kind='single_run_resident_reference_v2',reference_id=f'7b_{w}_vllm0300_{run.upper()}',
        model='llama2_7b',workload=w,reference_frozen=True,source_run=run.upper(),
        U_ref_gpu_seconds=u,Q_ref_p95_ttft_ms=row['metrics']['ttft_ms']['p95_type1'],
        budget_fraction=.75,B_gpu_seconds=.75*u,n_protocol_valid=4000,raw_n_correct=None,
        independent_numerical_proof=False,reused_development_observation=True,independent_holdout=False,
        formal_independent_correctness_qualified=False,source_audit_sha256=p.digest(audit_path),
        slo_eval_sha256=p.digest(slo_path),warm_reference_sha256=slo['calibration']['sha256'],
        metric_protocol_sha256=matrix['metric_protocol_sha256'],single_run_amendment_sha256=matrix['single_run_amendment_sha256'],
        qualification='Retained native/content/input/lifecycle audit plus freshly verified closed four-device integral. Not HTTP success alone.',
        reference_slo_requirement=False,source_observed_joint_slo=row['joint_slo'],
        preregistration_document=dict(path=str(prereg),sha256=p.digest(prereg)),
        cache_boundary='Compiler disk cache retained; actual model JIT included. Whole underlying kernel-cache equivalence not proved.',
        scope='Numerical resource normalization of known complete development observation, not baseline optimum, causal attribution, or final G2 achievement.')
    assert references[w]['B_gpu_seconds']==matrix['references'][w]['B_gpu_seconds']

def describe(values):
    xs=sorted(values)
    assert all(type(v) in (int,float) and math.isfinite(v) for v in xs)
    return dict(n=len(xs),mean=fmean(xs) if xs else None,
        p95_type1=xs[math.ceil(.95*len(xs))-1] if xs else None,max=xs[-1] if xs else None)
diagnostics={};all_rows=[]
for run,w,suffix in [('d551','W1','result2'),('d554','W2','result1')]:
    retained=read(P/f'main_comparison/{run}_initial_control_full_{w.lower()}/{suffix}/summary.json')['actual_audit']
    source=Path(retained['evidence']['source'])
    assert p.digest(source)==retained['evidence']['source_sha256']
    sources[str(source)]=retained['evidence']['source_sha256']
    launch_path=source.parent/'launch.json'
    expected=next(r['sha256'] for r in retained['refs'] if r['path']==str(launch_path))
    launch=checked(launch_path,expected)
    assert launch['pass'] and launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
    rows=[];rpc_examples={}
    with source.open('rb') as stream:
        for request in ijson.items(stream,'detailed_results.tc_ieee_full.requests.item',use_float=True):
            stage=partition_retained_request_stages(request,
                arrival_start_s=launch['external_replay']['replay_t0_s'],clock_id=launch['external_replay']['clock_id'])
            prep=retained_preparation_row(request)
            length=request['native_token_timing']['actual_prompt_tokens']
            gs=[g for g in slo['groups'] if (g['lower_exclusive'] is None or length>g['lower_exclusive'])
                and (g['upper_inclusive'] is None or length<=g['upper_inclusive'])]
            assert len(gs)==1
            goodt=request['overall_ttft_ms']<=gs[0]['ttft_ms']
            goodp=request['tpot_ms']<=gs[0]['tpot_ms']
            row=dict(run=run.upper(),workload=w,request_id=request['request_id'],adapter_id=request['adapter_id'],
                arrival_offset_s=request['scheduled_arrival_offset_s'],tier=prep['tier'],
                ttft_ms=request['overall_ttft_ms'],tpot_ms=request['tpot_ms'],joint=bool(goodt and goodp),
                ttft_good=bool(goodt),tpot_good=bool(goodp),native_load_invoked=prep['native_load_invoked'],
                stale_rechecks=prep['stale_rechecks'],last_conflict_reason=prep['last_conflict_reason'],
                preparation_reason=prep['preparation_reason'],nested_routing_ms=stage['nested_routing_ms'],
                nested_control_total_ms=request['control_path_total_us']/1000,
                admission_to_acquired_ms=prep['admission_to_acquired_ms'],
                executable_to_engine_ms=prep['executable_to_engine_ms'],
                before_final_load_ms=prep['before_final_load_ms'],final_native_load_ms=prep['final_native_load_ms'],
                max_identity_error_ms=stage['max_identity_error_ms'],**stage['stages_ms'])
            sources_view=request['gpu_reference_evidence']['routing_snapshot']['sources']
            row['selected_snapshot_replicas']=len(sources_view)
            row['has_full_authoritative_read']=any(e['source_collection']['full_authoritative_read_replica_count']>0 for e in sources_view.values())
            row['has_full_fallback']=any(e['source_collection']['full_fallback_replica_count']>0 for e in sources_view.values())
            if prep['final_rpc_timing'] is not None:
                rpc_examples.setdefault(prep['tier'],prep['final_rpc_timing'])
            assert abs(prep['admission_to_engine_ms']-stage['stages_ms']['admission_to_engine_dispatch_ms'])<.001
            rows.append(row)
    assert len(rows)==len({r['request_id'] for r in rows})==len({r['arrival_offset_s'] for r in rows})==4000
    rows.sort(key=lambda r:r['arrival_offset_s'])
    for i,row in enumerate(rows): row.update(source_index=i,source_quarter=i//1000+1,source_phase=i//100+1)
    assert sum(r['joint'] for r in rows)==retained['common_threshold_joint_count']
    for key,value in retained['stage_means_ms'].items():
        assert abs(fmean(r[key] for r in rows)-value)<1e-6,key
    cohorts=[('all','all',rows)]
    cohorts += [('quarter',str(q),[r for r in rows if r['source_quarter']==q]) for q in range(1,5)]
    cohorts += [('tier',t,[r for r in rows if r['tier']==t]) for t in ('gpu','host','nvme','remote')]
    cohorts += [('joint',str(g),[r for r in rows if r['joint']==g]) for g in (False,True)]
    cohorts += [('quarter_tier',str(q)+'_'+t,[r for r in rows if r['source_quarter']==q and r['tier']==t])
                for q in range(1,5) for t in ('gpu','host','nvme','remote')]
    measures=list(retained['stage_means_ms'])+['ttft_ms','tpot_ms','nested_routing_ms','nested_control_total_ms',
        'admission_to_acquired_ms','executable_to_engine_ms','before_final_load_ms','final_native_load_ms','stale_rechecks']
    groups=[]
    for kind,label,rs in cohorts:
        groups.append(dict(group=kind,label=label,n=len(rs),joint=sum(r['joint'] for r in rs),
            ttft_bad=sum(not r['ttft_good'] for r in rs),tpot_bad=sum(not r['tpot_good'] for r in rs),
            loaded=sum(r['native_load_invoked'] for r in rs),
            with_full_read=sum(r['has_full_authoritative_read'] for r in rs),
            with_full_fallback=sum(r['has_full_fallback'] for r in rs),
            metrics={k:describe(r[k] for r in rs if r[k] is not None) for k in measures}))
    diagnostics[w]=dict(run=run.upper(),groups=groups,rpc_timing_examples=rpc_examples,
        last_conflict_counts=dict(Counter(r['last_conflict_reason'] for r in rows)),
        preparation_reason_counts=dict(Counter(r['preparation_reason'] for r in rows)),
        max_identity_error_ms=max(r['max_identity_error_ms'] for r in rows),
        numerical_correctness_unknown=True,isolated_causal_claim=False,
        caveats=['Source quarters are descriptive within one run, not independent repeats.',
            'Routing/control timings are nested, not additive TTFT phases.',
            'Tier/load/violation cohorts depend on actual system decisions, not matched causal interventions.',
            'Source snapshot counters are replicated/cumulative; not added as RPC event counts.',
            'Final conflict/load receipts do not enumerate every intermediate retry.'])
    all_rows += rows
    assert p.digest(source)==sources[str(source)]

OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'resident_references.json',references)
save(OUT/'ttft_diagnosis.json',diagnostics)
with (OUT/'request_stages.csv').open('x',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(all_rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(all_rows)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
for name in ('analyze.py',): sources[str(RAW/name)]=p.digest(RAW/name)
for name in ('scripts/analyze_control_path_overhead.py','scripts/ieee_tc/analyze_d297_full.py','scripts/ieee_tc/check_d299_full_context.py'):
    sources[str(ROOT/name)]=p.digest(ROOT/name)
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
save(OUT/'manifest.json',dict(passed=True,new_gpu_run=False,production_changed=False,
    source_refs=[dict(path=k,sha256=v) for k,v in sources.items()],protected=protected,identity=identity,resources=resources,
    outputs={name:p.digest(OUT/name) for name in ('resident_references.json','ttft_diagnosis.json','request_stages.csv')},
    validation='Existing strict stage/preparation helpers; full count/SLO/mean-stage identities rechecked, no new qualification run.'))
save(RAW/'analysis_receipt.json',dict(passed=True,rows=len(all_rows),identity=identity,resources=resources))
print(json.dumps(dict(passed=True,rows=len(all_rows),resources=resources)))
