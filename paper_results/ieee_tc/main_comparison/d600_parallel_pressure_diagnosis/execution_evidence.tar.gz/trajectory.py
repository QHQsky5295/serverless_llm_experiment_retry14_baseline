"""Bounded offline activation/lifecycle and matched-row audit; no inference."""
import csv, gzip, json, math, os, subprocess, sys
from pathlib import Path
from statistics import fmean
import ijson
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d600_parallel_pressure_diagnosis'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.analyze_d297_full import partition_activation_readiness
def read(path): return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f: json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name); cg=Path(identity['path'])
save(RAW/'trajectory_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],8*1024*1024);save(RAW/'trajectory_resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
manifest=read(OUT/'manifest.json'); refs={x['path']:x['sha256'] for x in manifest['source_refs']}
sources={}
with (OUT/'request_stages.csv').open() as f: stages=list(csv.DictReader(f))
assert p.digest(OUT/'request_stages.csv')==manifest['outputs']['request_stages.csv']
results={}; request_maps={}
for name in ('D554','D598'):
    source=next(Path(k) for k in refs if f'/{name.lower()}_' in k and '/experiment_results_' in k)
    assert p.digest(source)==refs[str(source)]
    launch=read(source.parent/'launch.json');t0=launch['external_replay']['replay_t0_s']
    clock=launch['external_replay']['clock_id']
    physical_path=source.parent/'launch.launch/physical_deployment/physical_resource_summary.json'
    physical=read(physical_path); sources[str(physical_path)]=p.digest(physical_path)
    compressed=source.parent/'launch.launch/physical_deployment/main_outcome.json.gz'
    receipt_path=source.parent/'compression_receipt.json';receipt=read(receipt_path)
    assert receipt['first_roundtrip_sha256']==receipt['second_roundtrip_sha256']==receipt['source_sha256']
    assert p.digest(compressed)==receipt['archive_sha256']
    sources[str(compressed)]=receipt['archive_sha256'];sources[str(receipt_path)]=p.digest(receipt_path)
    with gzip.open(compressed,'rb') as f:
        activations=next(ijson.items(f,'mechanism_events._ieee_activations',use_float=True))
    with source.open('rb') as f:
        requests=[dict(request_id=r['request_id'],instance_id=r['instance_id'],
            adapter_id=r['adapter_id'],offset=r['scheduled_arrival_offset_s'],
            prompt_hash=r['native_token_timing']['prompt_token_ids_sha256'] if 'prompt_token_ids_sha256' in r['native_token_timing'] else None,
            dispatch=r['native_token_timing']['native_dispatch_monotonic_s'],
            first=r['native_token_timing']['native_first_token_monotonic_s'],
            last=r['native_token_timing']['native_last_token_monotonic_s'])
            for r in ijson.items(f,'detailed_results.tc_ieee_full.requests.item',use_float=True)]
    ready,unready=partition_activation_readiness(activations,requests,clock_id=clock)
    ar=[]
    for a in ready:
        own=[r for r in requests if r['instance_id']==a['activation_id']]
        first=min(own,key=lambda r:r['dispatch']) if own else None
        ar.append(dict(activation_id=a['activation_id'],category=a['category'],
            trigger_offset_s=a['trigger_at']-t0,ready_offset_s=a['engine_ready_at']-t0,
            engine_activation_s=a['engine_ready_at']-a['trigger_at'],requests=len(own),
            first_dispatch_offset_s=first['dispatch']-t0 if first else None,
            first_request_ttft_ms=1000*(first['first']-t0-first['offset']) if first else None))
    rows=[r for r in stages if r['run']==name]
    request_maps[name]={r['request_id']:r for r in rows}
    quarters=[dict(quarter=q,n=sum(int(r['source_quarter'])==q for r in rows),
        joint=sum(r['joint']=='True' for r in rows if int(r['source_quarter'])==q),
        stages_ms={k:fmean(float(r[k]) for r in rows if int(r['source_quarter'])==q)
        for k in ('arrival_release_ms','release_to_acquire_ms','runtime_slot_wait_ms','admission_to_engine_dispatch_ms','ttft_ms')})
        for q in range(1,5)]
    results[name]=dict(activations=ar,unready=unready,quarters=quarters,
        physical_gpu_seconds=physical['physical_gpu_seconds_total'],allocation_journals=physical['allocation_journals'])
    assert p.digest(source)==refs[str(source)]
assert set(request_maps['D554'])==set(request_maps['D598'])
changes=[]
for rid,a in request_maps['D554'].items():
    b=request_maps['D598'][rid]
    assert all(a[k]==b[k] for k in ('adapter_id','arrival_offset_s','source_index'))
    changes.append(dict(request_id=rid,same_tier=a['tier']==b['tier'],old_tier=a['tier'],new_tier=b['tier'],
        old_joint=a['joint']=='True',new_joint=b['joint']=='True',
        deltas_ms={k:float(b[k])-float(a[k]) for k in ('arrival_release_ms','release_to_acquire_ms','runtime_slot_wait_ms','admission_to_engine_dispatch_ms','ttft_ms')}))
cohorts=[]
for label,rows in [('all',changes),('same_tier',[r for r in changes if r['same_tier']]),
                   ('changed_tier',[r for r in changes if not r['same_tier']])]:
    cohorts.append(dict(cohort=label,n=len(rows),good_to_bad=sum(r['old_joint'] and not r['new_joint'] for r in rows),
        bad_to_good=sum(not r['old_joint'] and r['new_joint'] for r in rows),
        mean_delta_ms={k:fmean(r['deltas_ms'][k] for r in rows) for k in rows[0]['deltas_ms']}))
save(OUT/'trajectory.json',dict(passed=True,results=results,matched=cohorts,
    caveat='Single different-code closed-loop runs; actual cohorts/activation differ. No causal decomposition, repeated-run CI, or counterfactual subtraction.'))
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
sources[str(RAW/'trajectory.py')]=p.digest(RAW/'trajectory.py')
resources={k:(cg/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
save(RAW/'trajectory_receipt.json',dict(passed=True,identity=identity,resources=resources,protected=protected,
    sources=sources,outputs={'trajectory.json':p.digest(OUT/'trajectory.json')}))
print(json.dumps(dict(passed=True,resources=resources,results={k:{x:y for x,y in v.items() if x!='allocation_journals'} for k,v in results.items()},matched=cohorts)))
