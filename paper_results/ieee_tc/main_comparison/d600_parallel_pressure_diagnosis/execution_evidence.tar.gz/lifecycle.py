"""Reuse physical-union validation and decompose the already measured U difference."""
import json, os, subprocess, sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d600_parallel_pressure_diagnosis'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.check_d299_full_context import closed_physical_integral
def read(path): return json.loads(path.read_text())
def save(path,obj):
    with path.open('x') as f: json.dump(obj,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);cg=Path(identity['path'])
save(RAW/'lifecycle_identity.json',identity)
assert (cg/'memory.high').read_text().strip()==str(3*p.GIB)
assert (cg/'memory.max').read_text().strip()==str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([ROOT],1024*1024);save(RAW/'lifecycle_resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
trajectory=read(OUT/'trajectory.json');results={};refs={}
for name,data in trajectory['results'].items():
    jpath=Path(data['allocation_journals'][0]['path'])
    run=jpath.parent.parent.parent
    summary_path=run/'launch.launch/physical_deployment/summary.json'
    physical_path=summary_path.with_name('physical_resource_summary.json')
    physical=read(physical_path);summary=read(summary_path)
    assert p.digest(summary_path)==physical['summary_sha256']
    u=closed_physical_integral(summary)
    assert abs(u-data['physical_gpu_seconds'])<1e-6
    deployment_path=summary_path.with_name('deployment.json');deployment=read(deployment_path)
    t0=deployment['arrival_start_s'];end=deployment['arrival_end_s']
    intervals=[(a-t0,b-t0) for v in summary['device_intervals'].values() for a,b in v]
    events=[]
    for a,b in intervals:events.extend([(a,1),(b,-1)])
    boundaries=sorted({0.,end-t0,*[t for t,d in events]})
    held_seconds={str(n):0. for n in range(5)}
    for a,b in zip(boundaries,boundaries[1:]):
        left=max(0.,a);right=min(end-t0,b)
        if right<=left: continue
        count=sum(x<=left<y for x,y in intervals)
        held_seconds[str(count)]+=right-left
    observed=sum(int(n)*s for n,s in held_seconds.items())
    assert abs(observed-summary['window_gpu_seconds']['arrival'])<1e-6
    results[name]=dict(U=u,physical_lease_intervals=len(intervals),
        intervals_relative_to_arrival_s=sorted(intervals),arrival_duration_s=end-t0,
        arrival_seconds_at_each_held_gpu_count=held_seconds,windows=summary['window_gpu_seconds'])
    for path in (summary_path,physical_path,deployment_path):refs[str(path)]=p.digest(path)
    for r in data['allocation_journals']:
        assert p.digest(Path(r['path']))==r['sha256'];refs[r['path']]=r['sha256']
delta={k:results['D598']['windows'][k]-results['D554']['windows'][k] for k in results['D554']['windows']}
assert abs(sum(delta.values())-(results['D598']['U']-results['D554']['U']))<1e-6
save(OUT/'lifecycle.json',dict(passed=True,results=results,delta_windows=delta,
    caveat='Exact descriptive physical occupancy. Fewer activation epochs do not imply lower GPU time. No cause assigned to changed online scale decisions.'))
resources={k:(cg/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
save(RAW/'lifecycle_receipt.json',dict(passed=True,identity=identity,resources=resources,sources=refs,
    outputs={'lifecycle.json':p.digest(OUT/'lifecycle.json')}))
print(json.dumps(dict(passed=True,results=results,delta=delta,resources=resources)))
