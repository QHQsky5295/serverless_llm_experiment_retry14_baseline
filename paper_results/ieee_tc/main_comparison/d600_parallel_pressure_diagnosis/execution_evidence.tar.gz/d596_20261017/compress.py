"""D596: reuse the closed-outcome compressor for three explicitly reviewed runs."""
import json, os, subprocess, sys
from pathlib import Path
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc import compress_closed_main_outcomes as c

def save(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'storage_identity.json', identity)
cg = Path(identity['path'])
assert (cg/'memory.high').read_text().strip() == str(3*p.GIB)
assert (cg/'memory.max').read_text().strip() == str(4*p.GIB)
assert (cg/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
seal = c.RAW_ROOT.parent/'slora_qualification/d435_20261011/protected_before.json'
assert p.verify_seal(seal)['pass']
dirt = {
    ROOT/'configs/generated/lora_manifest_1000.json': '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'): '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'): '337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499',
}
for path, sha in dirt.items(): assert p.digest(path) == sha
targets = ['d533_20261015/7b_full_w1', 'd512_20261014/7b_full_w0_prefix1',
           'd519_20261014/7b_full_w0_prefix1']
checks = []
for name in targets:
    run = c.RAW_ROOT/name
    launch = json.loads((run/'launch.json').read_text())
    c.require_closed_launch(launch)
    assert not Path(launch['service_identity']['path']).exists()
    assert not Path(launch['auxiliary']['path']).exists()
    source, receipt = c.evidence_paths(run)
    assert source.resolve() == source.absolute()
    assert not receipt.exists() and not source.with_suffix('.json.gz').exists()
    c.no_active(source)
    checks.append(dict(run=name, launch_sha256=p.digest(run/'launch.json'),
        source_sha256=p.digest(source), source_bytes=source.stat().st_size,
        actual_service_and_auxiliary_paths_gone=True, no_active_source=True))
save(RAW/'prechecks.json',dict(passed=True, checks=checks,
    compressor_sha256=p.digest(Path(c.__file__)), driver_sha256=p.digest(Path(__file__)),
    preserved={str(path):sha for path,sha in dirt.items()}))
c.TARGETS = [dict(run=row['run'],audit_sha=row['source_sha256']) for row in checks]
c.OUT = RAW/'storage_result.json'
assert c.main() == 0
assert p.verify_seal(seal)['pass']
for path, sha in dirt.items(): assert p.digest(path) == sha
save(RAW/'receipt.json', dict(passed=True, reused_compressor=True,
    result_sha256=p.digest(c.OUT), protected=p.verify_seal(seal),
    resources={key:(cg/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}))
