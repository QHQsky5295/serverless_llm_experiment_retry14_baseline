"""Reuse exact-owned, recursively-empty D594 closure."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/close.py')
code=source.read_text().replace("'pressure_diagnosis')", "'pressure_diagnosis', 'trajectory', 'lifecycle')")
exec(compile(code,str(source),'exec'))
