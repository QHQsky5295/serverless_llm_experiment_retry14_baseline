"""D600: reuse D594's strict streaming stages for D554/D598, both W2."""
from pathlib import Path

source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d594_20261017/analyze.py')
code = source.read_text()
def replace(old, new):
    global code
    assert code.count(old) == 1, old
    code = code.replace(old, new)
replace("OUT=P/'main_comparison/d594_reference_and_ttft'", "OUT=P/'main_comparison/d600_parallel_pressure_diagnosis'")
start = code.index('references={}\n')
end = code.index('\ndef describe(values):', start)
code = code[:start] + "references=checked(P/'main_comparison/d594_reference_and_ttft/resident_references.json')\n" + code[end:]
replace("[('d551','W1','result2'),('d554','W2','result1')]", "[('d554','W2','result1'),('d598','W2','result1')]")
replace("retained=read(P/f'main_comparison/{run}_initial_control_full_{w.lower()}/{suffix}/summary.json')['actual_audit']",
        "retained=(read(P/'p2_backend/d598_parallel_pressure_full_w2/result1/summary.json')['audit'] if run=='d598' else read(P/f'main_comparison/{run}_initial_control_full_{w.lower()}/{suffix}/summary.json')['actual_audit'])")
replace('diagnostics[w]=dict(', 'diagnostics[run.upper()]=dict(')
exec(compile(code, str(source), 'exec'))
