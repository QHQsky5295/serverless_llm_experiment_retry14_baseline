"""Reuse D530 bounded curation for D557; no repeated tests or GPU execution."""
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d557_vllm_w2/result1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'result_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
summary=read(RAW/'audit_full4000_w2.json')
assert summary['measurement_complete'] and summary['workload_passed']
assert summary['native_revalidated_requests']==4000 and summary['actual_native_output_tokens']==458224
assert summary['source_plan']['profile']=='W2' and summary['n_correct'] is None
assert summary['counts']['N_failed']==0 and 0<=summary['common_slo']['joint_good']<=4000
assert all(summary[k]==0 for k in ('max_e2e_recomputation_error_ms','max_tpot_recomputation_error_ms','max_native_recompute_error_ms'))
for ref in summary['raw_sources']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
binding_path=RAW/'qualification.json'
binding=read(binding_path)
assert binding['passed'] and binding['reused_lifecycle_tests']==53 and binding['reused_w2_tests']==386
for path,sha in binding['refs'].items():assert p.digest(Path(path))==sha,path
cross=read(RAW/'cross_contract.json')
assert cross['passed'] and cross['request_count']==4000
cross_close=read(RAW/'contract_closure.json')
assert cross_close['passed'] and cross_close['path_gone'] and not Path(cross_close['identity']['path']).exists()
preserved={str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
           str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
           str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
subprocess.run(['git','diff','--exit-code','271e5948e355c601417251b4d73e0e3e11fd3b00','--',
                'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=ROOT,check=True)
OUT.mkdir(parents=True,exist_ok=False)
files=[RAW/name for name in ('close_launch.py','stop_remote.sh','preserve_evidence.py',
       'run_analysis.py','cross_contract.py','close.py','curate_result.py','launch7b.json','local_cleanup.json',
       'analysis_identity.json','analysis_receipt.json','analysis_closure.json','contract_closure.json',
       'remote_stop.log','evidence_copy_receipt.json','http_7b_4000.json','qualification.json',
       'native_cache_prefix_identity.json')]
files += sorted((RAW/'model7b/worker_receipts').glob('*.json'))
files += sorted((RAW/'model7b').glob('worker_*.log'))
files += [
          ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',
          ROOT/'docs/ieee_tc/D557_VLLM_W2_RESULT.md']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
members={}
archive=OUT/'evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes()
        assert len(data)<32*1024*1024
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
        name=f'{i:02d}_{path.name}'
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o600;member.mtime=0
        tar.addfile(member,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
assert archive.stat().st_size<2*1024*1024
for name,source in (('audit.json','audit_full4000_w2.json'),('cross_contract.json','cross_contract.json'),('startup_diagnostic.json','startup_diagnostic.json')):
    with (OUT/name).open('xb') as stream:stream.write((RAW/source).read_bytes())
save(OUT/'manifest.json',dict(passed=True,scope=identity,new_gpu_run=False,production_changed=False,
     reference_frozen=False,reason='vLLM W2 complete observation; safe storage maintenance and authorized Loquetier optimization next',
     reused_tests=dict(count=439,w2=386,lifecycle=53,path=str(binding_path),sha256=p.digest(binding_path)),
     execution_main_commit='271e5948e355c601417251b4d73e0e3e11fd3b00',
     execution_baseline_commit='aff60bb210c6d1fb9ce94534c5ef37521976bc0a',
     metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
     single_run_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
     protected=protected,preserved=preserved,source_refs=summary['raw_sources'],archive_members=members,
     outputs={name:p.digest(OUT/name) for name in ('audit.json','cross_contract.json','startup_diagnostic.json','evidence.tar.gz')}))
print(json.dumps(dict(passed=True,reused_tests=439,archive_bytes=archive.stat().st_size,scope=identity)))
