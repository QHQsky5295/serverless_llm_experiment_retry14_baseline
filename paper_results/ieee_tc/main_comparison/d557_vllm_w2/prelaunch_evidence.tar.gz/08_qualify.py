"""Reuse qualified D536 native policy, D541 lifecycle fix, and D553 W2 inputs."""
import ast, json, os, subprocess, sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d536_20261015'
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from prepare_ieee_tc_serverless_stack import load_http_replay_plan, validate_http_lifecycle_contract
from replay_vllm_engine_trace import validate_native_service_config
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'qualification_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate=p.preflight([MAIN],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
assert not Path('/tmp/tc-d557-7bv').exists()
q553path=RAW.parent.parent/'main_comparison/d553_20261015/qualification_final.json'
assert p.digest(q553path)=='1e5f62dac7b1cb9e94f9b37a8b56e232a58069ac47513e36441751921a5fdeb1'
q553=read(q553path);assert q553['passed'] and q553['tests']==386
q554path=RAW.parent.parent/'p2_backend_qualification/d554_20261015/qualification.json'
q554=read(q554path);assert q554['passed'] and q554['new_tests']==4
superseded={}
for path,sha in q553['refs'].items():
    current=p.digest(Path(path))
    if current!=sha:
        assert path==str(MAIN/'tests/test_ieee_tc_launch.py')
        assert current==q554['refs'][path]
        superseded[path]=dict(old=sha,current=current,qualified_by=str(q554path))
for path,sha in q553['preserved'].items():assert p.digest(Path(path))==sha
q541path=RAW.parent.parent/'resource_measurement/d541_20261015/after2_receipt.json'
q541=read(q541path);assert q541['passed'] and q541['returncode']==0
for path,sha in q541['sources'].items():assert p.digest(Path(path))==sha
assert 'Ran 53 tests' in (q541path.parent/'after2.log').read_text()
build_path=MAIN/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=read(build_path)
assert build['passed'] and build['actual_closure']['passed'] and build['actual_closure']['path_gone']
assert not Path(build['actual_closure']['identity']['path']).exists()
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256']
native_config=BASE/'configs/ieee_tc/vllm_7b_resident_native_compiler_v2.json'
native_unchanged=[]
for relative in ('scripts/replay_vllm_engine_trace.py','scripts/ieee_tc_serverless_measurement.py',
                 'configs/ieee_tc/vllm_7b_resident_native_compiler_v2.json'):
    previous=subprocess.check_output(['git','show','bde215460acb9e850efa479a89bda6fc39a2bd7d:'+relative],cwd=BASE)
    assert (BASE/relative).read_bytes()==previous,relative
    native_unchanged.append(relative)
cfg=read(RAW/'http_7b_4000.json')
qualified_cfg=read(q553path.parent/'http_7b_4000_v3.json')
assert cfg==dict(qualified_cfg,experiment_role='full_w2_resident_reference_candidate')
validate_http_lifecycle_contract(cfg)
validate_native_service_config(read(native_config),cfg)
plan=load_http_replay_plan(cfg,trace=cfg['trace'])
assert plan.identity()==q553['http_plan']
rows=[json.loads(entry.source_json) for entry in plan.entries]
assert len(rows)==4000 and len({x['adapter_id'] for x in rows})==497
assert sum(min(x['expected_output_tokens'],256) for x in rows)==458224
prior_runner=(OLD/'run7b.sh').read_text().replace('d536_20261015','d557_20261016').replace('d536','d557')
prior_runner=prior_runner.replace('--predicted-growth-gib 8','--predicted-growth-gib 32')
assert (RAW/'run7b.sh').read_text().rstrip()==prior_runner.rstrip()
for path in [*RAW.glob('*.py'),*RAW.glob('*.sh')]:
    if path.suffix=='.py':ast.parse(path.read_text())
    else:subprocess.run(['bash','-n',str(path)],check=True)
refs=[Path(x) for x in q553['refs']]
refs += [Path(x) for x in q541['sources']]
refs += [BASE/x for x in native_unchanged]
refs += [RAW/'http_7b_4000.json',q553path,q554path,q541path,build_path,*RAW.glob('*.py'),*RAW.glob('*.sh')]
save(RAW/'qualification.json',dict(passed=True,scope=identity,gate=gate,
    reused_w2_tests=386,reused_lifecycle_tests=53,new_input_checks=2,
    native_files_byte_identical_to_D536=native_unchanged,superseded_test_source=superseded,
    plan=plan.identity(),actual_unique_adapters=497,target_tokens=458224,
    numerical_correctness_qualified=False,no_performance_run=True,no_policy_change=True,
    refs={str(x):p.digest(x) for x in refs},preserved=q553['preserved']))
print(json.dumps(dict(passed=True,reused_w2_tests=386,reused_lifecycle_tests=53,
    new_input_checks=2,actual_unique_adapters=497,target_tokens=458224)))
