"""Correct only the historical test filename; retain the original failed driver."""
from hashlib import sha256
import json
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW/'qualify.py'
data=original.read_bytes()
assert sha256(data).hexdigest()=='f04e5139ade5926521151aae9333d62a6e40a397b364f1352524f33e05d61ba8'
closed=json.loads((RAW/'qualification_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
source=data.decode()
old="assert path==str(MAIN/'tests/test_ieee_tc_launch.py')"
assert source.count(old)==1
source=source.replace(old,"assert path==str(MAIN/'tests/test_ieee_tc_preflight.py')")
source=source.replace('qualification_identity.json','qualification2_identity.json')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'qualify2.py')})
