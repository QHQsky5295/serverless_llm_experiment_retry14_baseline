"""Adapt D533's immutable input witness to D537; bounded offline evidence only."""
import json
import os
from pathlib import Path
import re
import sys

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,allow_nan=False)
scope=p.scope_identity(p.cg_path().name)
save(RAW/'cross_identity.json',scope)
group=Path(scope['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
current=read(RAW/'audit_full4000_w1.json')
prior_root=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d536_20261015')
prior=read(prior_root/'audit_full4000_w1.json')
assert current['source_plan']==prior['source_plan']
assert current['common_slo']['freeze_sha256']==prior['common_slo']['freeze_sha256']
def contracts(path):
    out={}
    for line in path.open():
        row=json.loads(line)
        if row['event']=='request_contract':
            assert row['request_id'] not in out
            out[row['request_id']]=row
    assert len(out)==4000
    return out
paths=[RAW/'launch7b_repaired.launch/replay.jsonl',prior_root/'launch7b.launch/replay.jsonl']
a,b=map(contracts,paths)
assert a.keys()==b.keys()
fields=('adapter_id','artifact_content_sha256','artifact_manifest_sha256',
        'canonical_prompt_sha256','canonical_prompt_tokens','native_prompt_token_ids_sha256',
        'source_item_sha256','target_tokens')
for rid in a:
    for key in fields: assert a[rid][key]==b[rid][key],(rid,key)
prime_path=ROOT/'paper_results/ieee_tc/main_comparison/d533_full_w1/result1/cross_contract.json'
prime=read(prime_path)
assert prime['passed'] and prime['request_count']==4000
assert any(r['path']==str(paths[1]) and r['sha256']==p.digest(paths[1]) for r in prime['refs'])
# Extract exact log evidence; do not reinterpret wall-clock fragments as monotonic events.
markers=('Starting instance ', 'Using cache directory:', 'torch.compile takes',
         'torch.compile took', 'init engine (', 'Model loading took',
         'Directly load AOT compilation', 'Loading compiled graph',
         'Dynamo bytecode transform time:', 'Ray startup', 'instance is ready')
log_refs=[]
log_evidence={}
for label,base in (('D537_W1',RAW),('D414_W0',Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/serverless_qualification/d414_20261011'))):
    path=base/'model7b_repaired/serve.log'
    rows=[]
    for number,line in enumerate(path.open(errors='replace'),1):
        if any(marker in line for marker in markers):
            rows.append(dict(line=number,text=re.sub(r'\x1b\[[0-9;]*m','',line.rstrip())))
    log_evidence[label]=rows
    log_refs.append(path)
qual=read(RAW/'model7b_repaired/model_qualification.json')
comparison={
    'PrimeLoRA':prime['comparison']['PrimeLoRA'],
    'vLLM':prime['comparison']['vLLM'],
    'ServerlessLLM':dict(joint=current['common_slo']['joint_attainment'],
        gpu_seconds=current['physical_gpu_seconds'],p95_ttft_ms=current['conditional_metrics']['ttft_ms']['p95_type1'])}
changes={}
for name in ('vLLM','ServerlessLLM'):
    x,y=comparison['PrimeLoRA'],comparison[name]
    changes[name]=dict(lower_better_change_percent={k:100*(y[k]-x[k])/y[k] for k in ('gpu_seconds','p95_ttft_ms')},joint_difference_pp=100*(x['joint']-y['joint']))
save(RAW/'cross_contract.json',dict(passed=True,schema='d537_w1_input_witness_v1',scope=scope,
    request_count=4000,compared_fields=['request_id',*fields],source_plan=current['source_plan'],
    comparison=comparison,changes=changes,all_below_joint_95=True,
    independent_numerical_correctness=False,reference_frozen=False,
    generation_contract='fixed_length_greedy_v1',input_join_only=True,
    initial_state_contract_identical=False,
    limitations=['Transitive input join via sealed D533-to-D536 witness; not numeric output equality.',
        'Native versions, LoRA slot/rank settings and compilation histories differ explicitly.',
        'No proof that all queue delay is caused by startup, compilation or one native mechanism.',
        'All three observed W1 points are below the frozen 95% joint requirement.'],
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in (*paths,prime_path,RAW/'audit_full4000_w1.json',Path(__file__))]))
save(RAW/'startup_diagnostic.json',dict(scope=scope,log_evidence=log_evidence,
    startup_events=[json.loads(line) for line in (RAW/'model7b_repaired/startup_events.jsonl').open()],
    backend_ready_receipts=qual['backend_ready_receipts'],
    counts=dict(native_ready_receipts=current['backend_ready_receipts']),
    phase_joint=[r['common_slo']['joint_good'] for r in current['source_order_diagnostics']],
    queue_mean_fraction_of_ttft=current['conditional_metrics']['router_queue_ms']['mean']/current['conditional_metrics']['ttft_ms']['mean'],
    causal_attribution_complete=False,
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in (*log_refs,RAW/'model7b_repaired/startup_events.jsonl')]))
print(json.dumps(dict(passed=True,comparison=comparison,changes=changes,scope=scope)))
