"""Close CPU qualification using the existing analysis environment, not a serving change."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d414_20261011'
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
import prepare_ieee_tc_serverless_stack as s
def save(path,value):
    with path.open('x') as out:json.dump(value,out,indent=2,allow_nan=False)
def read(path):return json.loads(path.read_text())
identity=p.scope_identity(p.cg_path().name)
save(RAW/'contract_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
log=(RAW/'tests.log').read_text()
assert 'Ran 114 tests' in log and 'FAILED (errors=6)' in log
assert log.count("ModuleNotFoundError: No module named 'ijson'")==6
spec=importlib.util.spec_from_file_location('d537_analysis_tests',MAIN/'tests/test_tc_serverless_qualification_population.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
suite=unittest.TestSuite(module.ElasticLocalityMatchedTests(name) for name in (
    'test_extension_cannot_drop_prior_rows','test_streamed_controller_loader_requires_explicit_complete_scenario'))
with (RAW/'analysis_environment_tests.log').open('x') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
assert result.wasSuccessful() and result.testsRun==2
cfg=read(RAW/'http_7b_4000.json');old=read(OLD/'http_7b_4000.json')
assert cfg==dict(old,request_view='trace_w1_v1',replay_profile='W1')
view=read(RAW/'source_repaired/measurement_manifest.json')
oldview=read(OLD/'source_repaired/measurement_manifest.json')
for key in ('original_sha256','measured_sha256','shared_source_sha256'):assert view[key]==oldview[key]
for path,digest in view['measured_sha256'].items():assert p.digest(RAW/'source_repaired'/path)==digest
assert p.digest(Path(view['helper_path']))==view['helper_sha256']
plan=s.load_http_replay_plan(cfg)
assert plan.identity()['view_sha256']=='103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
gate=p.preflight([MAIN],32*p.GIB);assert gate['preflight_pass'],gate['issues']
installer=Path('/home/qhq/relayserve_serverless_llm/scripts/relayserve_v4_3_apply_serverlessllm_vllm_store_overlay.py')
refs=[Path(s.__file__),BASE/'scripts/ieee_tc_serverless_measurement.py',
    MAIN/'faaslora/datasets/workload_generator.py',MAIN/'scripts/ieee_tc_preflight.py',
    MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',installer,
    Path(cfg['trace']),Path(cfg['pool_index']),RAW/'http_7b_4000.json',
    RAW/'source_repaired/measurement_manifest.json',RAW/'overlay_preflight.json',
    RAW/'native_compile_cache_before.json',RAW/'tests.log',RAW/'analysis_environment_tests.log',
    RAW/'qualify.py',RAW/'qualify_v2.py']
save(RAW/'qualification.json',dict(passed=True,scope=identity,gate=gate,tests=114,
    tests_in_native_environment_passed=112,analysis_only_methods_rechecked=2,
    initial_6_subcase_errors='analysis ijson absent in native serving environment; no dependency installed',
    preserved_native_source=view,plan=plan.identity(),no_performance_run=True,
    reviewed_shared_changes=['optional v030 identity copied only when present',
        'v0102 hook factoring preserves snapshot_output and v1 marker',
        'new HTTP consumer branches preserve native v0102 behavior',
        'already-qualified common W1 arrival view'],
    changes=['request_view','replay_profile'],actual_unique_adapters=132,target_tokens=458224,
    refs={str(x):p.digest(x) for x in refs}))
print(json.dumps(dict(passed=True,tests=114,plan=plan.identity())))
