"""Reuse D414 ServerlessLLM entry with D531's already-qualified W1 view."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d414_20261011'
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
import prepare_ieee_tc_serverless_stack as s

def save(path,value):
    with path.open('x') as out:json.dump(value,out,indent=2,allow_nan=False)
def read(path):return json.loads(path.read_text())
def nodes(text):
    return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(text).body
            if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
identity=p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([MAIN],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
assert not Path('/tmp/tc-d537-7br').exists()
cfg=read(RAW/'http_7b_4000.json'); old=read(OLD/'http_7b_4000.json')
expected=dict(old,request_view='trace_w1_v1',replay_profile='W1')
assert cfg==expected
s.validate_http_lifecycle_contract(cfg)
plan=s.load_http_replay_plan(cfg)
assert plan.identity()['view_sha256']=='103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
rows=[json.loads(e.source_json) for e in plan.entries]
assert len(rows)==4000 and len({r['adapter_id'] for r in rows})==132
assert sum(min(r['expected_output_tokens'],256) for r in rows)==458224
assert p.digest(Path(cfg['pool_index']))==cfg['pool_index_sha256']

# Prove unchanged native source transformations, loader/scaler and service setup.
unchanged={}
commit='35dda117faecee5375c146a2c23b16fc2562d82a'
for relative,names in {
    'scripts/prepare_ieee_tc_serverless_stack.py':[
        'measurement_sources','scheduler_queue_source','native_model_config',
        'prepare','qualify_model','_qualify_model','prepare_remote_artifacts'],
    'scripts/ieee_tc_serverless_measurement.py':[
        'record_backend_ready','published_artifact_client','PublishedArtifactResolver',
        'PreReadyHTTPIngress','stamp','snapshot_output','snapshot_collector',
        'install_v1_snapshot','_install_snapshot_hooks','NativeRequestObservation'],
}.items():
    before=nodes(subprocess.check_output(['git','show',commit+':'+relative],cwd=BASE,text=True))
    after=nodes((BASE/relative).read_text())
    for name in names:assert before[name]==after[name],(relative,name)
    unchanged[relative]=names
view=s.prepare_measurement_view(BASE/'vendor_new_baselines/ServerlessLLM_new_main_20260518',
    RAW/'source_repaired','repaired',MAIN,'request_identity_v1')
oldview=read(OLD/'source_repaired/measurement_manifest.json')
for key in ('original_sha256','measured_sha256','shared_source_sha256'):
    assert view[key]==oldview[key],key
installer=Path('/home/qhq/relayserve_serverless_llm/scripts/relayserve_v4_3_apply_serverlessllm_vllm_store_overlay.py')
assert p.digest(installer)=='da6a14276f92186457c44c215d45d1ca9d18f7bbea9cdec6665737743f9c5978'
spec=importlib.util.spec_from_file_location('d537_loader',installer)
loader=importlib.util.module_from_spec(spec);spec.loader.exec_module(loader)
_,overlay=loader.build_overlay(loader.DEFAULT_VLLM_ROOT,loader.DEFAULT_OFFICIAL_PATCH)
save(RAW/'overlay_preflight.json',overlay)
checkpoint=BASE/'models/vllm/tc-native-llama2-7b-fp16-20260927/rank_0/tensor.data_0'
assert checkpoint.is_file()

# Only the legacy native prefix is sealed: no global caches, model conversion or GPU warmup.
cache=Path(read(OLD/'native_compile_cache_before.json')['root'])
entries=[]
for path in sorted(cache.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        entries.append([str(path.relative_to(cache)),path.stat().st_size,p.digest(path)])
assert entries
save(RAW/'native_compile_cache_before.json',dict(root=str(cache),entries=entries,
    files=len(entries),bytes=sum(x[1] for x in entries),
    policy='retained disk compilation cache, no GPU/HOST/KV prewarm; all startup charged',
    whole_lower_level_cache_identity_proved=False))

# Shared HTTP validator now contains other backend branches; exercise the retained
# ServerlessLLM native observation and actual W1 population once, CPU-only.
suite=unittest.TestSuite()
suite.addTests(unittest.defaultTestLoader.discover(str(BASE/'tests'),pattern='test_ieee_tc_serverless_measurement.py'))
suite.addTests(unittest.defaultTestLoader.discover(str(MAIN/'tests'),pattern='test_tc_serverless_qualification_population.py',top_level_dir=str(MAIN)))
with (RAW/'tests.log').open('x') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
assert result.wasSuccessful(),(len(result.failures),len(result.errors))
refs=[Path(s.__file__),BASE/'scripts/ieee_tc_serverless_measurement.py',
    MAIN/'faaslora/datasets/workload_generator.py',MAIN/'scripts/ieee_tc_preflight.py',
    MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',installer,
    Path(cfg['trace']),Path(cfg['pool_index']),RAW/'http_7b_4000.json',
    RAW/'source_repaired/measurement_manifest.json']
save(RAW/'qualification.json',dict(passed=True,scope=identity,gate=gate,tests=result.testsRun,
    preserved_native_nodes=unchanged,source_view=view,plan=plan.identity(),
    old_http_sha256=p.digest(OLD/'http_7b_4000.json'),changes=['request_view','replay_profile'],
    actual_unique_adapters=132,target_tokens=458224,no_performance_run=True,
    checkpoint_reused=str(checkpoint),refs={str(x):p.digest(x) for x in refs}))
print(json.dumps(dict(passed=True,tests=result.testsRun,view=plan.identity())))
