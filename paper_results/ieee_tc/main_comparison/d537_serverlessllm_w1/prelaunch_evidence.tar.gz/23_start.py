"""Reuse exact-owned gates for the unchanged D414 ServerlessLLM entry and W1."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
BINDING=RAW/'qualification.json'
ENV=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def run(command,**kwargs):return subprocess.run(command,check=True,**kwargs)
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()

assert RAW.name=='d537_20261015'
assert not any((RAW/name).exists() for name in ('launch7b_repaired.json','launch7b_repaired.launch','model7b_repaired','input_identity.json'))
assert not Path('/tmp/tc-d537-7br').exists()
identity=p.scope_identity(p.cg_path().name)
save(RAW/'start_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
backup=json.loads((RAW/'backup_receipt.json').read_text())
head=git(ROOT,'rev-parse','HEAD')
assert backup['passed'] and head==backup['head']
assert git(ROOT,'ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]==head
basehead=git(BASE,'rev-parse','HEAD')
assert basehead=='bde215460acb9e850efa479a89bda6fc39a2bd7d'
assert git(BASE,'ls-remote','origin','refs/heads/main').split()[0]==basehead
closed=json.loads((RAW/'backup_closure.json').read_text())
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
for repo,paths in ((ROOT,['faaslora','scripts','configs/ieee_tc','tests']),
                   (BASE,['scripts/prepare_ieee_tc_serverless_stack.py','scripts/replay_vllm_engine_trace.py',
                          'scripts/ieee_tc_serverless_measurement.py','configs/ieee_tc'])):
    assert not git(repo,'diff','--name-only','HEAD','--',*paths)
binding=json.loads(BINDING.read_text())
assert binding['passed'] and binding['tests']==114 and binding['plan']['profile']=='W1'

for path,sha in binding['refs'].items():assert p.digest(Path(path))==sha,path
for name in ('qualification','review','contract'):
    closure=json.loads((RAW/(name+'_closure.json')).read_text())
    assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate=p.preflight([ROOT],32*p.GIB)
assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
session='tc-d537-serverlessllm-w1'
assert subprocess.run(['tmux','has-session','-t',session],stderr=subprocess.DEVNULL).returncode!=0
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
prepared=json.loads((ROOT/'paper_results/ieee_tc/main_comparison/d537_serverlessllm_w1/prelaunch.json').read_text())
for path,sha in prepared['source_sha256'].items():assert p.digest(Path(path))==sha,path
save(RAW/'launch_gate.json',dict(passed=True,head=head,baseline_head=basehead,
    qualification_sha256=p.digest(BINDING),gate=gate,protected=protected,scope=identity,
    helpers=[dict(path=str(x),sha256=p.digest(x),content=x.read_text())
             for x in sorted([*RAW.glob('*.py'),*RAW.glob('*.sh')])]))
save(RAW/'input_identity.json',dict(plan=binding['plan'],actual_unique_adapters=132,
    target_tokens=458224,performance_ranking_eligible=False,formal_run=False,
    main_execution_commit=head,baseline_execution_commit=basehead,
    generation_contract='fixed_length_greedy_v1',native_configuration_reused='D414'))
# Same official loader-only overlay, with this execution's own backup/receipt.
installer='/home/qhq/relayserve_serverless_llm/scripts/relayserve_v4_3_apply_serverlessllm_vllm_store_overlay.py'
with (RAW/'overlay_install.log').open('x') as stream:
    run([sys.executable,installer,'--action','install','--backup-root',str(RAW/'overlay7b_repaired/backups'),
        '--receipt',str(RAW/'overlay7b_repaired/install.json')],stdout=stream,stderr=subprocess.STDOUT)
installed=json.loads((RAW/'overlay7b_repaired/install.json').read_text())
expected=json.loads((RAW/'overlay_preflight.json').read_text())
assert installed['status']=='INSTALLED' and installed['members']==expected['members']
run(['bash',str(RAW/'start_remote.sh')])
run([sys.executable,str(RAW/'check_remote_health_stdlib.py')],cwd=ROOT)
run(['tmux','new-session','-d','-s',session,'-c',str(BASE),
     f"bash {RAW}/run7b_repaired.sh > {RAW}/runner.log 2>&1"])
receipt=RAW/'launch7b_repaired.launch/exec_receipt.json'
deadline=time.monotonic()+210
while not receipt.exists():
    if time.monotonic()>deadline:
        raise TimeoutError('observation timeout only; inspect the same tmux, never restart')
    time.sleep(.1)
launched=json.loads(receipt.read_text())
captured=p.scope_identity(Path(launched['auxiliary_path']).name)
save(RAW/'service_aux_identity.json',captured)
save(RAW/'start_receipt.json',dict(launched=True,head=head,baseline_head=basehead,
    tmux=session,starter_identity=identity,launcher_identity=captured))
print(json.dumps(dict(launched=True,tmux=session,head=head,baseline_head=basehead)))
