"""D466: reuse exact dispatch split and sampled-capacity primitives; no replay."""
import gzip
import hashlib
import json
import math
import os
import subprocess
import sys
from pathlib import Path
import ijson

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import (
    summarize_dispatch_gate_intervals, summarize_dispatch_capacity_context)
from scripts.ieee_tc.analyze_d297_full import partition_activation_readiness
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats
from faaslora.datasets.workload_generator import FrozenReplayPlan

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
write(RAW/'context_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*1024**3)
assert (group/'memory.max').read_text().strip() == str(4*1024**3)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
assert os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize >= 150*1024**3
with (RAW/'context_tests.log').open('x') as f:
    test = subprocess.run([sys.executable, '-B', '-m', 'unittest',
        'tests.test_ieee_tc_control_timeline', '-q'], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
write(RAW/'context_tests_result.json', dict(returncode=test.returncode))
test.check_returncode()

refs = []
def checked(path, expected=None):
    path = Path(path)
    digest = p.digest(path)
    assert expected is None or digest == expected, path
    refs.append(dict(path=str(path), sha256=digest))
    return path

slo = read(checked(ROOT/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json',
    '2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3'))
reports, input_maps = {}, []
for name, digest in (
    ('d458', '8d65bf7a9113909451d72a822098e1e464e27d031a7b0ea71357bf30fd52205c'),
    ('d465', 'cb83dc960641a164be351680c8d69a54873491186eb1825b48afc0407393dd91')):
    comparison = read(checked(ROOT/f'paper_results/ieee_tc/p2_backend/{name}_full_w0/matched_comparison.json'))
    seal = {r['path']: r['sha256'] for r in comparison['refs']}
    sources = [Path(x) for x in seal if f'{name}_20261012/7b_full_w0/experiment_results' in x]
    assert len(sources) == 1
    source = checked(sources[0], digest)
    assert seal[str(source)] == digest
    run = source.parent
    physical = run/'launch.launch/physical_deployment'
    launch = read(checked(run/'launch.json', seal[str(run/'launch.json')]))
    deployment = read(checked(physical/'deployment.json'))
    plan = FrozenReplayPlan.load(launch['external_replay']['plan']['source_path'])
    assert plan.identity() == launch['external_replay']['plan'] == deployment['plan']
    order = {e.request_id: i for i, e in enumerate(plan.entries)}
    fields = ('request_id', 'instance_id', 'adapter_id', 'success', 'scheduled_arrival_offset_s',
        'arrival_released_offset_s', 'admission_start_offset_s', 'dispatch_window_wait_ms',
        'runtime_slot_wait_ms', 'admitted_offset_s', 'arrival_release_lateness_ms',
        'dispatch_admission_wait_ms', 'native_token_timing', 'overall_ttft_ms', 'tpot_ms',
        'source_expected_output_tokens', 'requested_completion_tokens', 'canonical_prompt_sha256',
        'generation_contract', 'completion_token_source')
    requests = []
    with source.open('rb') as f:
        for r in ijson.items(f, 'detailed_results.tc_ieee_full.requests.item', use_float=True):
            requests.append({k: r[k] for k in fields})
    assert len(requests) == len({r['request_id'] for r in requests}) == 4000
    requests.sort(key=lambda r: order[r['request_id']])
    assert [r['request_id'] for r in requests] == [e.request_id for e in plan.entries]
    input_fields = ('request_id', 'adapter_id', 'scheduled_arrival_offset_s',
        'source_expected_output_tokens', 'requested_completion_tokens', 'canonical_prompt_sha256',
        'generation_contract', 'completion_token_source')
    input_maps.append([tuple(r[k] for k in input_fields) for r in requests])
    terminal_path = checked(physical/'request_terminals.jsonl', seal[str(physical/'request_terminals.jsonl')])
    with terminal_path.open() as f:
        terminals = [json.loads(line) for line in f]
    compression = read(checked(run/'compression_receipt.json'))
    outcome = checked(compression['archive'], compression['archive_sha256'])
    assert compression['source_sha256'] == seal[str(physical/'main_outcome.json')]
    h = hashlib.sha256()
    with gzip.open(outcome, 'rb') as f:
        for chunk in iter(lambda: f.read(1024**2), b''):
            h.update(chunk)
    assert h.hexdigest() == compression['source_sha256']
    extracted = {}
    for key in ('_ieee_activations', '_ieee_control_events'):
        with gzip.open(outcome, 'rb') as f:
            values = list(ijson.items(f, 'mechanism_events.'+key, use_float=True))
        assert len(values) == 1 and isinstance(values[0], list)
        extracted[key] = values[0]
    activations = extracted['_ieee_activations']
    ready, unready = partition_activation_readiness(activations, requests, clock_id=deployment['clock_id'])
    split = summarize_dispatch_gate_intervals(requests, deployment, terminals, ready)
    rows = split.pop('rows')
    for i, (row, r) in enumerate(zip(rows, requests)):
        assert row['request_id'] == r['request_id']
        tokens = r['native_token_timing']['actual_prompt_tokens']
        thresholds = [g for g in slo['groups'] if
            (g['lower_exclusive'] is None or tokens > g['lower_exclusive']) and
            (g['upper_inclusive'] is None or tokens <= g['upper_inclusive'])]
        assert len(thresholds) == 1
        g = thresholds[0]
        row.update(phase=i//500, trace_index=i, ttft_ms=r['overall_ttft_ms'], tpot_ms=r['tpot_ms'],
            ttft_pass=r['overall_ttft_ms'] <= g['ttft_ms'], tpot_pass=r['tpot_ms'] <= g['tpot_ms'])
    assert sum(r['ttft_pass'] and r['tpot_pass'] for r in rows) == comparison['candidate']['counts']['joint_pass']
    start = deployment['arrival_start_s']
    controls = [dict(offset_s=e['observed_at']-start, queue=e['queue_depth'],
        active=e['active_requests'], capacity=e['ready_capacity'], pending=e['pending_instances'],
        action=e['action'], outcome=e['outcome'], p95_ttft_ms=e['p95_ttft_ms'],
        all_low=e['all_low']) for e in extracted['_ieee_control_events']]
    context = summarize_dispatch_capacity_context(rows, controls)
    samples = context.pop('rows')
    def phase_summary(phase):
        rr = [r for r in rows if r['phase'] == phase]
        left, right = rr[0]['arrival_offset_s'], rr[-1]['arrival_offset_s']
        cc = [s for s in samples if left <= s['offset_s'] <= right]
        waiting = [s for s in cc if s['acquire_not_yet_resumed'] > 0]
        return dict(phase=phase, count=len(rr), first_arrival_s=left, last_arrival_s=right,
            ttft_misses=sum(not r['ttft_pass'] for r in rr), tpot_misses=sum(not r['tpot_pass'] for r in rr),
            joint_misses=sum(not(r['ttft_pass'] and r['tpot_pass']) for r in rr),
            metrics={key: timing_stats([r[key] for r in rr]) for key in ('pre_acquire_ms',
                'acquire_to_resume_ms', 'dispatch_window_wait_ms', 'runtime_slot_wait_ms',
                'acquire_to_resume_startup_overlap_ms', 'ttft_ms')},
            control_samples=len(cc), waiting_samples=len(waiting),
            waiting_samples_capacity_definitely_covered=sum(s['capacity_covered_by_definite_owners'] for s in waiting),
            peak_wait_sample=max(cc, key=lambda s:s['acquire_not_yet_resumed']) if cc else None)
    activation_offsets = [dict(a, trigger_offset_s=a['trigger_at']-start,
        engine_ready_offset_s=a['engine_ready_at']-start if 'engine_ready_at' in a else None,
        startup_s=a['engine_ready_at']-a['trigger_at'] if 'engine_ready_at' in a else None) for a in activations]
    reports[name] = dict(source_sha256=digest, split=split, context=context,
        phases=[phase_summary(i) for i in range(8)],
        activation_counts=dict(all=len(activations), ready=len(ready), unready=len(unready)),
        peak_wait_sample=max(samples, key=lambda s:s['acquire_not_yet_resumed']),
        longest_wait=max(rows, key=lambda r:r['acquire_to_resume_ms']))
    for filename, content in (('gate_requests', rows), ('capacity_samples', samples),
        ('activations', activation_offsets), ('control_events', extracted['_ieee_control_events'])):
        write(RAW/(name+'_'+filename+'.json'), content)
        checked(RAW/(name+'_'+filename+'.json'))
    print(json.dumps(dict(run=name, context=context, peak=reports[name]['peak_wait_sample'],
        phases=[dict(phase=x['phase'], mean_gate_wait_ms=x['metrics']['acquire_to_resume_ms']['mean'],
            joint_misses=x['joint_misses'], waiting_samples=x['waiting_samples'],
            definitely_full=x['waiting_samples_capacity_definitely_covered']) for x in reports[name]['phases']]),
        indent=2), flush=True)
assert input_maps[0] == input_maps[1]
for path in (Path(__file__), ROOT/'scripts/analyze_control_path_overhead.py',
    ROOT/'scripts/ieee_tc/analyze_d297_full.py', ROOT/'tests/test_ieee_tc_control_timeline.py'):
    checked(path)
protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
write(RAW/'context.json', dict(kind='d466_retained_capacity_context_v1', passed=True,
    reports=reports, matched_inputs=True, source_refs=refs, scope=identity, protected=protected,
    no_new_performance_run=True, no_figures=True, causal_attribution_established=False))
