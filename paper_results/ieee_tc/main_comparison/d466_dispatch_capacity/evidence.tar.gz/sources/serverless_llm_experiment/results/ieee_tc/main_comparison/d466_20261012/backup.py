"""Task-only D466 checkpoint with source, bundle, smoke and secret checks."""
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d466_dispatch_capacity'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def write(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2)
identity=p.scope_identity(p.cg_path().name);write(RAW/'backup_identity.json',identity)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='9ff330d1293a67012671bd798eff4cfb76bc889a'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()=='71c52cf6f7331dc2a171ec83db5f1011eaf6d5a6'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closure=read(RAW/'curation_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
manifest=read(OUT/'manifest.json');assert manifest['passed']
for name,sha in manifest['outputs'].items():assert p.digest(OUT/name)==sha,name
for name,sha in {**manifest['source_refs'],**manifest['preserved']}.items():assert p.digest(Path(name))==sha,name
assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
assert (OUT/'context_tests.log').read_text().splitlines()[-1]=='OK' and manifest['smoke_tests']==40
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
    assert not token or token not in data
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(manifest['archive_members'])
    for name,ref in manifest['archive_members'].items():
        data=tar.extractfile(name).read();assert hashlib.sha256(data).hexdigest()==ref['sha256']
        clean(data)
with (OUT/'curation_closure.json').open('xb') as f:f.write((RAW/'curation_closure.json').read_bytes())
paths=['docs/ieee_tc/D466_RETAINED_DISPATCH_CAPACITY.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str(path.relative_to(ROOT)) for path in sorted(OUT.iterdir())]
assert len(paths)==11 and not any('lora_manifest_1000.json' in name for name in paths)
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in paths:
    data=(ROOT/name).read_bytes();assert len(data)<8*1024*1024
    if not name.endswith('.tar.gz'):clean(data)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines())==set(paths)
hashes={}
for name in paths:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    hashes[name]=hashlib.sha256(data).hexdigest();assert hashes[name]==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
write(RAW/'staged_check.json',dict(passed=True,files=hashes,archive_members_checked=len(manifest['archive_members'])))
subprocess.run(['git','commit','-m','tc: localize retained dispatch capacity regression without replay (D466)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
receipt=dict(passed=True,head=head,remote=remote,files=len(paths),scope=identity,
    smoke_tests=40,manifest_sha256=p.digest(OUT/'manifest.json'))
write(RAW/'backup_receipt.json',receipt);print(json.dumps(receipt))
