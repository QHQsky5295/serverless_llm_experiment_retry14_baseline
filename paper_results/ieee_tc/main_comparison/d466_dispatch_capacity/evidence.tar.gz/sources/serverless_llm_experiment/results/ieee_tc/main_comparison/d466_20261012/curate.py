"""Preserve D466 compact derivations and exact sources without touching old runs."""
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d466_dispatch_capacity'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def write(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
write(RAW/'curation_identity.json',identity)
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize>=150*1024**3
checks={}
for name in ('stages.json','context.json'):
    report=read(RAW/name);assert report['passed'] and report['protected']['pass']
    for ref in report['source_refs']:
        path=Path(ref['path']);assert p.digest(path)==ref['sha256'],path
        checks[str(path)]=ref['sha256']
for name in ('analysis','context'):
    closure=read(RAW/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty']
    assert not Path(closure['identity']['path']).exists()
smoke=(RAW/'context_tests.log').read_text()
assert 'Ran 40 tests' in smoke and smoke.splitlines()[-1]=='OK'
assert read(RAW/'context_tests_result.json')['returncode']==0
expected={
    '/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md':'f851e6da5237cb706f5a167dd1180984d5d02694fa6568f1720e0e5aada0b1f5',
    str(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'):'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    str(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'):'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'}
for path,sha in expected.items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
OUT.mkdir(parents=True,exist_ok=False)
names=('stages.json','context.json','analysis_closure.json','context_closure.json',
    'context_tests.log','context_tests_result.json')
for name in names:
    data=(RAW/name).read_bytes()
    with (OUT/name).open('xb') as f:f.write(data)
    assert p.digest(OUT/name)==p.digest(RAW/name)
source_paths=[RAW/name for name in ('analyze_stages.py','analyze_context.py','close.py','curate.py','backup.py')]
source_paths += [ROOT/name for name in ('scripts/analyze_control_path_overhead.py',
    'scripts/ieee_tc/analyze_d297_full.py','scripts/ieee_tc/audit_d402_serverlessllm_path.py',
    'scripts/ieee_tc_preflight.py','tests/test_ieee_tc_control_timeline.py',
    'scripts/run_all_experiments.py','scripts/dedicated_engine_worker.py',
    'faaslora/coordination/autoscaler.py')]
projections=[RAW/'requests.jsonl',RAW/'retained_schema.json']
projections += [RAW/(run+'_'+name+'.json') for run in ('d458','d465') for name in
    ('gate_requests','capacity_samples','activations','control_events')]
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for path in source_paths+projections:
        data=path.read_bytes()
        name=('sources/' if path in source_paths else 'projections/')+str(path).removeprefix('/home/qhq/')
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644
        tar.addfile(entry,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest())
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']==p.digest(Path(ref['path']))
write(OUT/'manifest.json',dict(kind='d466_delivery_manifest_v1',passed=True,scope=identity,
    source_refs_verified=len(checks),source_refs=checks,preserved=expected,protected=protected,
    archive_members=members,outputs={path.name:p.digest(path) for path in OUT.iterdir()},
    smoke_tests=40,production_changed=False,new_performance_run=False,no_figures=True))
print(json.dumps(dict(passed=True,source_refs=len(checks),archive_members=len(members),
    archive_bytes=(OUT/'evidence.tar.gz').stat().st_size,protected=147,scope=identity)))
