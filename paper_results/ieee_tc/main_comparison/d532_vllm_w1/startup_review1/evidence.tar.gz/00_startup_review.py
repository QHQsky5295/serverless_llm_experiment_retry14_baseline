"""Bounded, read-only D423/D532 startup review; reuse D532 curation guards.

No model, build, replay, shared-cache edit, or performance rerun. Native build
descriptions are rendered in memory only, with GPUs hidden and scratch logging.
"""
import ast
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
from datetime import datetime, timezone

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OLD = RAW.parent/'d423_20261011'
ENV = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925')
CACHE = Path('/home/qhq/.cache/flashinfer/0.6.18.post1/86/cached_ops/sampling')
OUT = ROOT/'paper_results/ieee_tc/main_comparison/d532_vllm_w1/startup_review1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def render():
    # Import logging must not touch the shared FlashInfer workspace. The native
    # generator's output path is restored only for in-memory text comparison.
    import torch
    from flashinfer.jit import env as jit_env
    from flashinfer.jit.cpp_ext import generate_ninja_build_for_op
    from flashinfer.jit.sampling import gen_sampling_module
    assert not torch.cuda.is_initialized()
    jit_env.FLASHINFER_JIT_DIR = CACHE.parent
    spec = gen_sampling_module()
    text = generate_ninja_build_for_op(spec.name, spec.sources, spec.extra_cflags,
        spec.extra_cuda_cflags, spec.extra_ldflags, spec.extra_include_dirs,
        spec.needs_device_linking)
    assert not torch.cuda.is_initialized()
    print(json.dumps(dict(text=text, sha256=sha(text.encode()), bytes=len(text.encode()),
                         cuda_initialized=False, build_called=False)))

if len(sys.argv) == 2 and sys.argv[1] == '--render':
    render()
    raise SystemExit

sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
identity = p.scope_identity(p.cg_path().name)
save(RAW/'review_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
assert read(RAW/'local_cleanup.json')['passed']
assert (RAW/'remote_stop.log').read_text().count('ActiveState=inactive') == 3
assert not OUT.exists()
OUT.mkdir(parents=True)

refs = {}
def source(path):
    data = path.read_bytes()
    refs[str(path)] = dict(sha256=sha(data), bytes=len(data))
    return data

freezes = [json.loads(source(root/'native_cache_prefix_identity.json')) for root in (OLD, RAW)]
entries = [{row[0]:row[1:] for row in freeze['entries']} for freeze in freezes]
changed = [dict(path=key, old=entries[0][key], new=entries[1][key])
           for key in sorted(entries[0].keys() & entries[1].keys())
           if entries[0][key] != entries[1][key]]
assert len(changed) == 7 and all(Path(row['path']).parent == CACHE for row in changed)
assert entries[0].keys() == entries[1].keys()
build_bytes = source(CACHE/'build.ninja')
log_bytes = source(CACHE/'.ninja_log')
prefix_checks = []
for freeze in entries:
    length, digest = freeze[str(CACHE/'.ninja_log')]
    assert sha(log_bytes[:length]) == digest
    prefix_checks.append(dict(bytes=length, sha256=digest, matched=True))
added_lines = log_bytes[prefix_checks[1]['bytes']:].decode().splitlines()
ninja_events = []
for line in added_lines:
    start, end, mtime_ns, output, command_hash = line.split('\t')
    ninja_events.append(dict(start_ms=int(start), end_ms=int(end),
        output_mtime_ns=int(mtime_ns), output_mtime_utc=datetime.fromtimestamp(
            int(mtime_ns)/1e9, timezone.utc).isoformat(), output=output,
        command_hash=command_hash))
assert len(ninja_events) == 4

rendered = {}
for label, overrides in (
    ('vllm_default', {}),
    ('primelora_explicit', {'CUDA_HOME':'/usr/local/cuda-13.0',
                          'FLASHINFER_NVCC':'/usr/local/cuda-13.0/bin/nvcc'})):
    # Allowlist avoids copying private tokens into child diagnostics or outputs.
    env = dict(HOME='/home/qhq', PATH=str(ENV/'bin')+':/usr/local/cuda/bin:/usr/bin:/bin',
        CUDA_VISIBLE_DEVICES='', FLASHINFER_CUDA_ARCH_LIST='8.6',
        FLASHINFER_WORKSPACE_BASE=str(RAW/('render_'+label)), MAX_JOBS='2',
        PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', **overrides)
    result = subprocess.run([str(ENV/'bin/python'), '-B', str(Path(__file__)), '--render'],
        env=env, capture_output=True, text=True, timeout=45)
    save(RAW/('render_'+label+'.json'), dict(returncode=result.returncode,
         stdout=result.stdout, stderr=result.stderr, env=env))
    result.check_returncode()
    rendered[label] = json.loads(result.stdout)

renderer_comparison = dict(
    current_build_matches_default=rendered['vllm_default']['sha256'] == sha(build_bytes),
    pre_d532_build_matches_explicit=rendered['primelora_explicit']['sha256'] == entries[1][str(CACHE/'build.ninja')][1],
    default_matches_d423=rendered['vllm_default']['sha256'] == entries[0][str(CACHE/'build.ninja')][1],
    diff=list(difflib.unified_diff(rendered['vllm_default']['text'].splitlines(),
              rendered['primelora_explicit']['text'].splitlines(), lineterm='')))

ready = {}
logs = {}
for root in (OLD, RAW):
    deployment = json.loads(source(root/'model7b/physical/deployment.json'))
    ready[root.name] = []
    for path in sorted((root/'model7b/worker_receipts').glob('*.json')):
        row = json.loads(source(path))
        ready[root.name].append(dict(index=row['index'],ready_after_notice_s=
            row['at']-deployment['deployment_notice_s'],engine_args=row['engine_args']))
    logs[root.name] = {}
    for path in sorted((root/'model7b').glob('worker_*.log')):
        text = source(path).decode()
        logs[root.name][path.name] = [line for line in text.splitlines() if any(
            word in line for word in ('Directly load AOT','torch.compile took',
            'JIT kernel warmup','Graph capturing finished','init engine'))]
    source(root/'model7b/native_toolchain.json')
assert read(OLD/'model7b/native_toolchain.json') == read(RAW/'model7b/native_toolchain.json')
assert all(row['engine_args'] == ready[OLD.name][0]['engine_args']
           for rows in ready.values() for row in rows)

runner = 'scripts/replay_vllm_engine_trace.py'
trees = []
for commit in ('e646f9106c8fd6fd15f54b69041bd54234fa47e1',
               'b540d7664bf4f8522b3b2694348d889e902034c6'):
    data = subprocess.check_output(['git','show',commit+':'+runner],cwd=BASE)
    trees.append({node.name:ast.dump(node,include_attributes=False)
        for node in ast.parse(data).body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))})
native_same = {name:trees[0][name] == trees[1][name] for name in
               ('native_worker_environment','_native_worker','NativeVLLMRequestHandler')}
assert all(native_same.values())

resource_observations = {}
for root in (OLD, RAW):
    notice = read(root/'model7b/physical/deployment.json')['deployment_notice_s']
    records = []
    with (root/'launch7b.launch/watchdog.jsonl').open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get('event') != 'resource_sample':
                continue
            t = row['monotonic']-notice
            if t > 145:
                break
            if 36 <= t <= 137:
                cpu = dict(x.split() for x in row['service']['cpu.stat'].splitlines())
                records.append(dict(after_notice_s=t,cpu_usage_usec=int(cpu['usage_usec']),
                    gpu_util=[d['gpu_utilization_percent'] for d in row['gpu']['devices']],
                    memory_events=row['service']['memory.events'],
                    swap=row['service']['memory.swap.current']))
    resource_observations[root.name] = dict(samples=len(records), first=records[0],last=records[-1],
        all_zero_gpu_util=sum(all(v==0 for v in r['gpu_util']) for r in records),
        cpu_seconds_delta=(records[-1]['cpu_usage_usec']-records[0]['cpu_usage_usec'])/1e6,
        caveat='Samples are not kernel spans; CPU usage does not independently locate the wait.')

for rel in ('vllm/v1/worker/gpu_worker.py','vllm/v1/worker/gpu/warmup.py',
            'flashinfer/jit/core.py','flashinfer/jit/cpp_ext.py','flashinfer/jit/env.py'):
    source(ENV/'lib/python3.12/site-packages'/rel)
source(ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh')
source(Path(__file__))
shared_after = {str(CACHE/name):p.digest(CACHE/name) for name in ('build.ninja','.ninja_log')}
assert all(digest == refs[path]['sha256'] for path,digest in shared_after.items())
report = dict(passed=True, new_gpu_run=False, serving_modified=False, shared_cache_modified=False,
    native_configuration_and_toolchain_equal=True,native_functions_ast_equal=native_same,
    cache_changed=changed,ninja_log_frozen_prefixes=prefix_checks,ninja_appended_events=ninja_events,
    renderer_comparison=renderer_comparison,rendered=rendered,
    ready=ready,worker_log_boundaries=logs,resource_observations=resource_observations,
    compiler_realpaths={path:str(Path(path).resolve()) for path in
        ('/usr/local/cuda','/usr/local/cuda/bin/nvcc','/usr/local/cuda-13.0/bin/nvcc')},
    limitation='No warmup call span or complete historical environment snapshot; do not subtract compile time from latency or declare all poor performance explained.',
    source_refs=refs,identity=identity,
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')})
save(OUT/'review.json',report)
members={}
with tarfile.open(OUT/'evidence.tar.gz','w:gz') as archive:
    paths=[Path(__file__),CACHE/'build.ninja',CACHE/'.ninja_log',
           RAW/'render_vllm_default.json',RAW/'render_primelora_explicit.json']
    for index,path in enumerate(paths):
        data=path.read_bytes()
        name=f'{index:02d}_{path.name}'
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o600
        archive.addfile(member,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=sha(data))
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as archive:
    assert all(sha(archive.extractfile(name).read())==ref['sha256'] for name,ref in members.items())
save(OUT/'manifest.json',dict(members=members,outputs={name:p.digest(OUT/name)
    for name in ('review.json','evidence.tar.gz')}))
print(json.dumps(dict(passed=True,renderer_comparison=renderer_comparison,
    ninja_appended_events=ninja_events,resources=report['resources'])),flush=True)
