"""Follow the actual PrimeLoRA CC initialization omitted by the first probe."""
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
ENV=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925')
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d532_vllm_w1/startup_review1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path,obj):
    with path.open('x') as stream:json.dump(obj,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'contract_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
review=json.loads((OUT/'review.json').read_text())
assert json.loads((RAW/'review_closure.json').read_text())['path_gone']
env=dict(HOME='/home/qhq',PATH=str(ENV/'bin')+':/usr/local/cuda/bin:/usr/bin:/bin',
    CUDA_VISIBLE_DEVICES='',FLASHINFER_CUDA_ARCH_LIST='8.6',
    FLASHINFER_WORKSPACE_BASE=str(RAW/'render_primelora_actual_cc'),MAX_JOBS='2',
    PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',CC='/usr/bin/gcc',
    CUDA_HOME='/usr/local/cuda-13.0',FLASHINFER_NVCC='/usr/local/cuda-13.0/bin/nvcc')
result=subprocess.run([str(ENV/'bin/python'),'-B',str(RAW/'startup_review.py'),'--render'],
    env=env,capture_output=True,text=True,timeout=45)
save(RAW/'render_primelora_actual_cc.json',dict(returncode=result.returncode,
    stdout=result.stdout,stderr=result.stderr,env=env))
result.check_returncode()
rendered=json.loads(result.stdout)
freeze=json.loads((RAW/'native_cache_prefix_identity.json').read_text())
expected=next(row[1:] for row in freeze['entries'] if row[0].endswith('/sampling/build.ninja'))
assert [rendered['bytes'],rendered['sha256']]==expected
default=review['rendered']['vllm_default']['text']
assert rendered['cuda_initialized'] is False and rendered['build_called'] is False
assert Path('/usr/local/cuda/bin/nvcc').resolve()==Path(env['FLASHINFER_NVCC']).resolve()
source=ROOT/'scripts/run_all_experiments.py'
old_source=subprocess.check_output(['git','show',
    'db44e8f068eb30c69466f32ad3d147ffbc45f9e2:scripts/run_all_experiments.py'],cwd=ROOT,text=True)
block='if "CC" not in os.environ:\n    for _gcc in ("/usr/bin/gcc", "/usr/local/bin/gcc"):\n        if os.path.exists(_gcc):\n            os.environ["CC"] = _gcc\n            break'
assert block in source.read_text() and block in old_source
record=dict(passed=True,kind='native_CPU_only_in_memory_build_description',
    scope=identity,rendered=rendered,environment=env,pre_d532_exact_SHA_match=True,
    first_probe_omission='PrimeLoRA import sets CC=/usr/bin/gcc when absent; no historical environment was fabricated',
    actual_historical_runner_CC_block_unchanged=True,
    diff=list(difflib.unified_diff(default.splitlines(),rendered['text'].splitlines(),lineterm='')),
    source_sha256={str(path):p.digest(path) for path in
      (Path(__file__),RAW/'startup_review.py',source,ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh')},
    no_gpu_or_build=True,no_serving_or_shared_cache_edits=True,
    limitations='Exact build description recovered, not every historical environment variable or parent process; cannot subtract compilation from request metrics.',
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')})
save(OUT/'compiler_binding.json',record)
print(json.dumps({key:record[key] for key in ('passed','pre_d532_exact_SHA_match','diff','resources')}))
