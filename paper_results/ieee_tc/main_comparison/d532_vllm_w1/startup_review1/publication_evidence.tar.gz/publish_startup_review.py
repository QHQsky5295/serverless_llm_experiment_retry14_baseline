"""Reuse D532 explicit-path publication guard for the bounded startup review."""
import ast, hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d532_vllm_w1/startup_review1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'review_backup_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
review=read(OUT/'review.json');binding=read(OUT/'compiler_binding.json');record=read(OUT/'manifest.json')
assert review['passed'] and binding['passed'] and binding['pre_d532_exact_SHA_match']
assert all(review['native_functions_ast_equal'].values())
for path,ref in review['source_refs'].items():assert p.digest(Path(path))==ref['sha256'],path
for path,digest in binding['source_sha256'].items():assert p.digest(Path(path))==digest,path
for name,digest in record['outputs'].items():assert p.digest(OUT/name)==digest
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(record['members'])
    for name,ref in record['members'].items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==ref['sha256']
for name in ('review','contract'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='1fbeb90a3d28e099aacfdd0dcf747b195f56e799'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()=='b540d7664bf4f8522b3b2694348d889e902034c6'
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
preserved={
    str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,digest in preserved.items():assert p.digest(Path(path))==digest,path
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members=[RAW/name for name in ('publish_startup_review.py','compiler_binding_review.py',
    'close.py','review_closure.json','contract_closure.json','render_primelora_actual_cc.json')]
archive=OUT/'publication_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in members:
        data=path.read_bytes();check(data)
        assert len(data)<8*1024*1024
        if path.suffix=='.py':ast.parse(data)
        bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
with (OUT/'review.sha256').open('x') as f:
    for name in ('review.json','compiler_binding.json','manifest.json','evidence.tar.gz','publication_evidence.tar.gz'):
        f.write(p.digest(OUT/name)+'  '+name+'\n')
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D532_STARTUP_CACHE_REVIEW.md']
names += [str((OUT/name).relative_to(ROOT)) for name in
          ('review.json','compiler_binding.json','manifest.json','evidence.tar.gz','publication_evidence.tar.gz','review.sha256')]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['sha256sum','-c','review.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(names) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: identify shared sampling cache rebuild in W1 startup (D532)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'review_backup_receipt.json',dict(passed=True,head=head,remote=remote,files=names,
    identity=identity,protected=protected,preserved=preserved,performance_rerun=False))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)),flush=True)
