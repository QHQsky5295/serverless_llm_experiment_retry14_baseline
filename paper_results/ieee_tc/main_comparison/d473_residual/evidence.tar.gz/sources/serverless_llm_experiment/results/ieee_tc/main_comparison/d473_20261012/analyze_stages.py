"""Reuse the D455 stage primitive for D472; previously sealed rows are reused."""
import hashlib
import json
import math
import subprocess
import sys
from collections import Counter
from pathlib import Path
import ijson
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import partition_retained_request_stages
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats
from faaslora.datasets.workload_generator import FrozenReplayPlan
def read(path):return json.loads(path.read_text())
def write(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
write(RAW/'analysis_identity.json',identity)
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
comparison_path=ROOT/'paper_results/ieee_tc/p2_backend/d472_full_w0/matched_comparison.json'
comparison=read(comparison_path)
sealed={r['path']:r['sha256'] for r in comparison['refs']}
refs=[]
def checked(path,expected=None):
    path=Path(path);digest=p.digest(path)
    assert expected is None or digest==expected,path
    refs.append(dict(path=str(path),sha256=digest))
    return path
checked(comparison_path)
sources=[Path(r['path']) for r in comparison['refs']
    if 'd472_20261012/7b_full_w0/experiment_results' in r['path']]
assert len(sources)==1
source=checked(sources[0],sealed[str(sources[0])])
assert p.digest(source)=='ea976d22dc103faeac78e030ddfd4afbbe3ea1d342a58855155fdc9d29c9c737'
launch=read(checked(source.parent/'launch.json',sealed[str(source.parent/'launch.json')]))
plan=FrozenReplayPlan.load(launch['external_replay']['plan']['source_path'])
assert plan.identity()==launch['external_replay']['plan']
order={e.request_id:i for i,e in enumerate(plan.entries)}
rows=[]
with source.open('rb') as f:
    for request in ijson.items(f,'detailed_results.tc_ieee_full.requests.item',use_float=True):
        row=partition_retained_request_stages(request,
            arrival_start_s=launch['external_replay']['replay_t0_s'],
            clock_id=launch['external_replay']['clock_id'])
        e=request['gpu_reference_evidence'];receipt=e['receipt']
        row.update(source_order=order[request['request_id']],phase=order[request['request_id']]//500,
            adapter_id=request['adapter_id'],instance_id=request['instance_id'],
            dispatch_tier=request['readiness_tier_before_dispatch'],
            native_load_invoked=receipt['native_load_invoked'],
            prior_routing_attempts=len(e['prior_routing_attempts']),
            nested_ms={**{k:request[k] for k in ('lora_io_ms','dispatch_admission_wait_ms',
                'service_ttft_ms','parent_rpc_overhead_ms')},
                'native_load_and_acquire_ms':receipt['load_and_acquire_ms'],
                'routing_ms':row['nested_routing_ms']})
        rows.append(row)
        if len(rows)==1:
            write(RAW/'retained_schema.json',dict(request_keys=sorted(request),
                evidence_keys=sorted(e),routing_snapshot=e['routing_snapshot'],
                receipt_keys=sorted(receipt),prior_attempts=e['prior_routing_attempts']))
assert len(rows)==len({r['request_id'] for r in rows})==4000
rows.sort(key=lambda r:r['source_order'])
assert [r['request_id'] for r in rows]==[e.request_id for e in plan.entries]
def summarize(group):
    if not group:return dict(count=0,stages_ms={},nested_ms={})
    return dict(count=len(group),
        stages_ms={key:timing_stats([r['stages_ms'][key] for r in group]) for key in group[0]['stages_ms']},
        nested_ms={key:timing_stats([r['nested_ms'][key] for r in group]) for key in group[0]['nested_ms']},
        ttft_ms=timing_stats([r['ttft_ms'] for r in group]),
        e2e_ms=timing_stats([r['e2e_ms'] for r in group]),
        dispatch_tiers=dict(Counter(r['dispatch_tier'] for r in group)),
        native_load_invoked=sum(r['native_load_invoked'] is True for r in group),
        prior_routing_attempts=sum(r['prior_routing_attempts'] for r in group))
all_summary=summarize(rows)
for metric in ('ttft_ms','e2e_ms'):
    for key in ('mean','p95_type1'):
        assert abs(all_summary[metric][key]-comparison['candidate']['metrics'][metric][key])<1e-6
assert abs(math.fsum(x['mean'] for x in all_summary['stages_ms'].values())-all_summary['e2e_ms']['mean'])<1e-6
oldpath=checked(ROOT/'paper_results/ieee_tc/main_comparison/d459_d458_diagnosis/stages.json')
old=read(oldpath)
prior_path=checked(ROOT/'paper_results/ieee_tc/main_comparison/d466_dispatch_capacity/stages.json')
prior=read(prior_path)
old['reports']['PrimeLoRA_D465']={'all':prior['current']}
for authority in ('METRIC_PROTOCOL_FROZEN_V1.md','METRIC_PROTOCOL_SINGLE_RUN_V2.md'):
    checked(ROOT/'docs/ieee_tc'/authority)
checked('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')
with (RAW/'requests.jsonl').open('x') as f:
    for row in rows:f.write(json.dumps(row,allow_nan=False)+'\n')
report=dict(kind='d473_d472_retained_stage_analysis_v1',passed=True,
    current=all_summary,
    phases={str(i):summarize([r for r in rows if r['phase']==i]) for i in range(8)},
    by_tier={tier:summarize([r for r in rows if r['dispatch_tier']==tier]) for tier in ('gpu','host','nvme','remote')},
    previous={name:value['all'] for name,value in old['reports'].items()},
    differences_mean_ms={name:{key:all_summary['stages_ms'][key]['mean']-value['all']['stages_ms'][key]['mean']
        for key in all_summary['stages_ms']} for name,value in old['reports'].items()},
    max_identity_error_ms=max(r['max_identity_error_ms'] for r in rows),
    causal_attribution_established=False,new_gpu_run=False,
    caveats=['Stage means add to E2E; stage percentiles do not.',
        'Routing and loading are nested, not additional additive latency.',
        'Conditioning on each system dispatch tier does not hold populations constant.',
        'No isolated causal or speedup conclusion from the single observed run.'],
    scope=identity)
for path in (Path(__file__),ROOT/'scripts/analyze_control_path_overhead.py',
    ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',RAW/'requests.jsonl',RAW/'retained_schema.json'):
    checked(path)
report['source_refs']=refs
report['protected']=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert report['protected']['pass']
write(RAW/'stages.json',report)
print(json.dumps(dict(passed=True,stages={k:v['mean'] for k,v in all_summary['stages_ms'].items()},
    nested={k:v['mean'] for k,v in all_summary['nested_ms'].items()},
    difference_vs_d458=report['differences_mean_ms']['PrimeLoRA_D458'],scope=identity),indent=2))

