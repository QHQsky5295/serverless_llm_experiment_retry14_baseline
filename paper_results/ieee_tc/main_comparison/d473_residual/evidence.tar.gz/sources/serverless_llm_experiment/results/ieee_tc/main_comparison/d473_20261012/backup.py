"""D473 explicit evidence checkpoint; preserve user files and all old outcomes."""
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d473_residual'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def write(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name);write(RAW/'backup_identity.json',identity)
assert git('rev-parse','HEAD')=='4a997092a7797e61028ea08579b852e78dd447c6'
assert git('branch','--show-current')=='retry14_continuous_queue_v2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()=='71c52cf6f7331dc2a171ec83db5f1011eaf6d5a6'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for name in ('analysis','storage','context','curation'):
    closure=read(RAW/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
manifest=read(OUT/'manifest.json');assert manifest['passed'] and manifest['smoke_tests']==116
for name,sha in manifest['outputs'].items():assert p.digest(OUT/name)==sha,name
for name,sha in {**manifest['source_refs'],**manifest['preserved']}.items():assert p.digest(Path(name))==sha,name
assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
assert 'Ran 110 tests' in (OUT/'context_tests.txt').read_text() and '\nOK\n' in (OUT/'context_tests.txt').read_text()
assert 'Ran 6 tests' in (OUT/'archive_tests.txt').read_text() and '\nOK\n' in (OUT/'archive_tests.txt').read_text()
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
    assert not token or token not in data
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(manifest['archive_members'])
    for name,ref in manifest['archive_members'].items():
        data=tar.extractfile(name).read();assert hashlib.sha256(data).hexdigest()==ref['sha256']
        assert p.digest(Path(ref['path']))==ref['sha256']
        clean(data)
paths=['docs/ieee_tc/D473_RETAINED_RESIDUAL_DIAGNOSIS.md','docs/ieee_tc/EXECUTION_STATUS.md',
    'scripts/ieee_tc/compress_closed_main_outcomes.py','tests/test_ieee_tc_closed_outcome_archive.py',
    'paper_results/ieee_tc/storage/20261012_d473_closed_failures_lossless.json']
paths += [str((OUT/name).relative_to(ROOT)) for name in sorted([*manifest['outputs'],'manifest.json'])]
assert len(paths)==18 and not any('lora_manifest_1000.json' in name for name in paths)
assert not git('diff','--cached','--name-only')
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in paths:
    data=(ROOT/name).read_bytes();assert len(data)<8*1024*1024
    if not name.endswith('.tar.gz'):clean(data)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
hashes={}
for name in paths:
    data=subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    hashes[name]=hashlib.sha256(data).hexdigest();assert hashes[name]==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
write(RAW/'staged_check.json',dict(passed=True,files=hashes,archive_members_checked=len(manifest['archive_members']),
    source=dict(path=str(Path(__file__)),sha256=p.digest(Path(__file__)),content=Path(__file__).read_text())))
subprocess.run(['git','commit','-m','tc: preserve post-CPU-preparation residual diagnosis and closed failures (D473)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD');remote=git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head==remote
receipt=dict(passed=True,head=head,remote=remote,files=len(paths),scope=identity,
    smoke_tests=116,manifest_sha256=p.digest(OUT/'manifest.json'))
write(RAW/'backup_receipt.json',receipt);print(json.dumps(receipt))
