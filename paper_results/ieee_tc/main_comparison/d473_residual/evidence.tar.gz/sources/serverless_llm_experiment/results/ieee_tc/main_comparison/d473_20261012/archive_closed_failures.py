"""Recover space with existing lossless storage utility; failures stay failures."""
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
DATA=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2)
save('storage_identity.json',p.scope_identity(p.cg_path().name))
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
with (RAW/'archive_tests.log').open('x') as f:
    subprocess.run([sys.executable,'-B','-m','unittest','tests.test_ieee_tc_closed_outcome_archive','-v'],
        cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,check=True)
seal=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')
assert p.verify_seal(seal)['pass']
runs=('d93_20260928/3b_full_w0_attempt2','d311_20261007/7b_full_w0')
sources=[]
for run in runs:
    launch_path=DATA/run/'launch.json'
    launch=json.loads(launch_path.read_text())
    assert launch['pass'] is False and launch['service_path_removed'] is True
    assert launch['native_gpu_context_release_confirmed'] is True
    assert not Path(launch['service_identity']['path']).exists()
    source=DATA/run/'launch.launch/physical_deployment/main_outcome.json'
    sources.append(dict(path=str(source),sha256=p.digest(source),launch_path=str(launch_path),
        launch_sha256=p.digest(launch_path),original_launch_pass=False))
save('archive_input_check.json',dict(passed=True,sources=sources))
command=[sys.executable,str(ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py'),
    '--allow-closed-failure','--receipt',str(ROOT/'paper_results/ieee_tc/storage/20261012_d473_closed_failures_lossless.json')]
for run in runs:command.extend(('--closed-run',run))
subprocess.run(command,check=True)
assert p.verify_seal(seal)['pass']
for row in sources:assert p.digest(Path(row['launch_path']))==row['launch_sha256']
save('archive_check.json',dict(passed=True,failed_launches_unchanged=True,
    script_sha256=p.digest(ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py'),
    test_sha256=p.digest(RAW/'archive_tests.log'),protected=p.verify_seal(seal)))
