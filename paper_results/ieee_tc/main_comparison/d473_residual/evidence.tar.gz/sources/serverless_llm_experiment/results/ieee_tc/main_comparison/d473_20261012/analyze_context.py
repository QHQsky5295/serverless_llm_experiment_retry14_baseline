"""D473: apply the existing D460 owner/decode primitives only to new D472."""
import gzip
import json
import os
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
import ijson
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.analyze_d297_full import (partition_activation_readiness,
    decode_overlap_summary,native_load_overlap_summary,prefill_overlap_summary,
    proactive_load_overlap_summary)
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats
def read(path):return json.loads(path.read_text())
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save('context_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*1024**3)
assert (group/'memory.max').read_text().strip()==str(4*1024**3)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
with (RAW/'context_tests.log').open('x') as log:
    test=subprocess.run([sys.executable,'-B','-m','unittest','tests.test_ieee_tc_decode_overlap',
        'tests.test_ieee_tc_control_timeline','-q'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
save('context_tests_result.json',dict(returncode=test.returncode));test.check_returncode()
refs=[]
def checked(path,expected=None):
    path=Path(path);sha=p.digest(path)
    assert expected is None or sha==expected,path
    refs.append(dict(path=str(path),sha256=sha));return path
stage=read(checked(RAW/'stages.json'))
comparison=read(checked(ROOT/'paper_results/ieee_tc/p2_backend/d472_full_w0/matched_comparison.json'))
pinned={r['path']:r['sha256'] for r in comparison['refs']}
sources=[Path(x) for x in pinned if 'd472_20261012/7b_full_w0/experiment_results' in x]
assert len(sources)==1
source=checked(sources[0],'ea976d22dc103faeac78e030ddfd4afbbe3ea1d342a58855155fdc9d29c9c737')
run=source.parent
launch=read(checked(run/'launch.json',pinned[str(run/'launch.json')]))
start=launch['external_replay']['replay_t0_s'];clock=launch['external_replay']['clock_id']
requests=[];host_checks=[]
with source.open('rb') as f:
    for r in ijson.items(f,'detailed_results.tc_ieee_full.requests.item',use_float=True):
        receipt=r['gpu_reference_evidence']['receipt']
        row={k:r[k] for k in ('request_id','instance_id','success','completion_tokens',
            'readiness_tier_before_dispatch','tpot_ms','native_token_timing','adapter_id')}
        row['gpu_reference_evidence']=dict(receipt=receipt)
        requests.append(row)
        if 'host_allocation' in receipt:
            host_checks.append(dict(request_id=r['request_id'],gpu_hit=receipt['gpu_confirmed_before_acquisition'],
                host_allocation=receipt['host_allocation']))
assert len(requests)==len({r['request_id'] for r in requests})==4000
compression=read(checked(run/'compression_receipt.json'))
archive=checked(compression['archive'])
from scripts.ieee_tc.compress_closed_main_outcomes import decompressed_digest
assert decompressed_digest(archive)=='c3bbc14d7620adfb735789f2162741fb05391e820d80e71ce5f40e60a6913c9a'
events={}
for key in ('_ieee_activations','_ieee_gpu_preparation_plans','_ieee_native_host_preparations'):
    events[key]=[]
    with gzip.open(archive,'rb') as f:
        for row in ijson.items(f,'mechanism_events.'+key+'.item',use_float=True):
            if key!='_ieee_activations':
                row={k:row[k] for k in ('plan_id','target_replica','trigger_reason','attempts','owner_id') if k in row}
                attempts=[]
                for a in row['attempts']:
                    item={k:a[k] for k in ('attempt_id','state')}
                    if 'receipt' in a:
                        fields=('owner_id','worker_pid','worker_rank','clock_id','acquired','held','lease_id',
                            'native_load_invoked','acquired_monotonic_s','completion_fence_ms',
                            'native_load_started_monotonic_s','native_load_completed_monotonic_s',
                            'load_started_monotonic_s','load_completed_monotonic_s')
                        item['receipt']={k:a['receipt'][k] for k in fields if k in a['receipt']}
                    attempts.append(item)
                row['attempts']=attempts
            events[key].append(row)
slo=read(checked(ROOT/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json',
    '2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3'))
thresholds=[dict(g,tpot_s=g['tpot_ms']/1000) for g in slo['groups']]
ready,unready=partition_activation_readiness(events['_ieee_activations'],requests,clock_id=clock)
decode=decode_overlap_summary(requests,ready,clock_id=clock,arrival_start=start,thresholds=thresholds)
native=native_load_overlap_summary(requests,decode.pop('requests'),clock_id=clock)
prefill=prefill_overlap_summary(requests,native['requests'],clock_id=clock)
proactive=proactive_load_overlap_summary(native.pop('requests'),events['_ieee_gpu_preparation_plans'],
    events['_ieee_native_host_preparations'],events['_ieee_activations'],clock_id=clock)
rows=proactive.pop('requests');pmap={r['request_id']:r for r in prefill.pop('requests')}
for r in rows:
    for k,v in pmap[r['request_id']].items():
        assert k not in r or r[k]==v
        r[k]=v
physical=read(checked(run/'launch.launch/physical_deployment/summary.json'))
pid_gpus=defaultdict(set);pid_starts=defaultdict(set)
for entry in physical['allocation_journals']:
    assert entry['released'] is True
    journal=checked(entry['path'],entry['sha256'])
    for line in journal.read_text().splitlines():
        event=json.loads(line);assert event['clock_id']==clock
        for device in event.get('census',{}).get('devices',[]):
            for proc in device['processes']:
                if proc['kind']=='compute' and proc['service_member']:
                    pid_gpus[proc['pid']].add(device['gpu_uuid'])
                    pid_starts[proc['pid']].add(proc['identity']['start_ticks'])
for owner,record in proactive['native_owners'].items():
    pid=record['worker_pid'];assert len(pid_gpus[pid])==len(pid_starts[pid])==1
    record.update(gpu_uuid=next(iter(pid_gpus[pid])),start_ticks=next(iter(pid_starts[pid])))
for r in rows:r['gpu_uuid']=proactive['native_owners'][r['owner']]['gpu_uuid']
def stats(rs):
    return dict(count=len(rs),tpot_ms=timing_stats([r['tpot_ms'] for r in rs]) if rs else None,
        mean_other_native_requests=sum(r['mean_other_native_requests'] for r in rs)/len(rs) if rs else None,
        tpot_misses=sum(r['timing_tpot_miss'] for r in rs),
        mean_decode_ms=sum(r['decode_s']*1000 for r in rs)/len(rs) if rs else None)
all_stats=stats(rows)
assert abs(all_stats['mean_decode_ms']-stage['current']['stages_ms']['native_decode_ms']['mean'])<1e-6
assert all_stats['tpot_misses']==45
flags=('startup_overlap','load_overlap','prefill_overlap','proactive_any_load_overlap')
current=dict(all=all_stats,counts={k:sum(r[k] for r in rows) for k in (*flags,'timing_tpot_miss')},
    decode=decode,native=native,prefill=prefill,proactive=proactive,ready_activations=len(ready),
    unready_activations=unready,
    groups={k:{str(v):stats([r for r in rows if bool(r[k])==v]) for v in (False,True)} for k in flags})
old=read(checked(ROOT/'paper_results/ieee_tc/main_comparison/d460_owner_decode/summary.json'))
for name,values in (('native_requests.jsonl',rows),('host_checks.jsonl',host_checks)):
    with (RAW/name).open('x') as f:
        for row in values:f.write(json.dumps(row,allow_nan=False)+'\n')
    checked(RAW/name)
for path in (Path(__file__),ROOT/'scripts/ieee_tc/analyze_d297_full.py',ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py'):
    checked(path)
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
save('context.json',dict(kind='d473_retained_owner_decode_v1',passed=True,current=current,
    previous=old['reports'],source_refs=refs,protected=protected,scope=identity,
    new_gpu_run=False,causal_attribution_established=False,
    caveats=['Native occupancy is not kernel batch size or GPU utilization.',
        'Overlap groups differ between runs and are not causal counterfactuals.',
        'D394 frozen thresholds override legacy D170 label in reused primitive.',
        'No performance replays, latency subtraction or independent numerical proof.']))
print(json.dumps(dict(passed=True,all=all_stats,counts=current['counts'],groups=current['groups']),indent=2))
