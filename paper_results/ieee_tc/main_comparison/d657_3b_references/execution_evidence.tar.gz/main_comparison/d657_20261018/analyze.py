"""D657: reuse D594/D424 gates to freeze 3B numerical references, not correctness.

No serving changes, GPU run, new workload, or reconstructed request measurements.
"""
import copy
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
RESULTS = RAW.parent.parent
P = MAIN/'paper_results/ieee_tc'
OUT = P/'main_comparison/d657_3b_references'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.check_d299_full_context import closed_physical_integral

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()

identity = p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
plan_sha = p.check_plan()
assert plan_sha == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([MAIN], 16*1024*1024)
save(RAW/'resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
assert not OUT.exists()
sources = {}

def checked(path, expected=None, parse=True):
    path = Path(path)
    digest = p.digest(path)
    if expected is not None:
        assert digest == expected, str(path)
    if str(path) in sources:
        assert sources[str(path)] == digest, str(path)
    sources[str(path)] = digest
    return read(path) if parse else digest

metric_sha = checked(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
    '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22', False)
v2_sha = checked(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
    '193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d', False)
slo_path = P/'protocols/20261017_3b_slo_d648_frozen.json'
slo = checked(slo_path, 'd15123570c4a8d830515ca942d1db553c6717ffc1a40ade5c1546d35e2bed9d8')
assert slo['model'] == 'llama32_3b_main_modelscope'
assert slo['planned_count'] == 4000 and slo['minimum_joint_count'] == 3800
checked(MAIN/slo['calibration']['path'], slo['calibration']['sha256'])
checked(MAIN/slo['calibration']['audit_path'], slo['calibration']['audit_sha256'])
pool_path = P/'inputs/20260927_3b_remote_content_index.json'
pool_sha = checked(pool_path, 'bd1826c58f00ea30dee1d3829dc11727a975127db701a1eee6c6c86b4a38f275', False)
rows = []
references = {}
provenance = {}
preserved = {}
engine_args = None
negative_tests = 0
cases = [
    ('W0', 'd653', 'fa94e223f86cb108d0e808eea6b9e345463d9601e528c330545290af07132eb2', '0d998f48a006d638dda9b8d714f667fe3a87f4d2c88044ce19a816b308494a37'),
    ('W1', 'd654', 'e2ece3bb5486d0d458573e7746285969418f7ac89a11aacb846f356823616cda', '8a7fa829c4902a761efcf58c765580cbdb5e0f367e3c2245ea43417409e9494f'),
    ('W2', 'd656', 'beb3de7a04dac838e09032e6b71a08c6d65f0d3f5bd6b4954b68cdb30f06a339', '5558de43ede0e2cf49c7478dcfb94640e7a8516406f53766fabfdf524bf91174'),
]
for workload, run, audit_sha, view_sha in cases:
    source_raw = RESULTS/f'vllm_qualification/{run}_20261018'
    curated = P/f'vllm/{run}_3b_full_{workload.lower()}'
    audit = checked(curated/'audit.json', audit_sha)
    manifest = checked(curated/'manifest.json')
    assert manifest['passed'] and manifest['resource_reference_candidate']
    assert manifest['resource_reference_frozen'] is False
    assert manifest['metric_protocol_sha256'] == metric_sha
    assert manifest['single_run_protocol_sha256'] == v2_sha
    checked(curated/'execution_evidence.tar.gz', manifest['archive_sha256'], False)
    for path, sha in manifest['preserved'].items():
        checked(path, sha, False)
        preserved[path] = sha
    for ref in audit['raw_sources']:
        checked(ref['path'], ref['sha256'], False)
    physical = checked(source_raw/'model3b/physical/summary.json')
    u = closed_physical_integral(physical)
    assert len(physical['device_intervals']) == 4
    assert abs(u-audit['physical_gpu_seconds']) < 1e-6
    assert physical['window_gpu_seconds'] == audit['physical_window_gpu_seconds']
    if not negative_tests:
        for field, value in [('measurement_complete', False), ('open_lease_ids', ['unreleased']),
                             ('n_terminal', 3999), ('gpu_seconds_observed', u+1)]:
            bad = copy.deepcopy(physical)
            bad[field] = value
            try:
                closed_physical_integral(bad)
            except ValueError:
                negative_tests += 1
            else:
                raise AssertionError('invalid physical ledger accepted: '+field)
    config = checked(source_raw/'model3b/worker_config.json')
    http_path = source_raw/'http_3b_4000.json'
    http = checked(http_path)
    launch = checked(source_raw/'launch3b.json')
    input_identity = checked(source_raw/'input_identity.json')
    assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
    assert launch['service_returncode'] == launch['watchdog_returncode'] == 0
    assert config['gpu_ids'] == [0, 1, 2, 3] and config['version'] == '0.30.0'
    assert config['routing'] == 'round_robin' and config['engine_args']['tensor_parallel_size'] == 1
    if engine_args is None:
        engine_args = config['engine_args']
    assert config['engine_args'] == engine_args
    for path, sha in config['source_sha256'].items():
        checked(path, sha, False)
    with (source_raw/'launch3b.launch/replay.jsonl').open() as stream:
        hello = json.loads(next(stream))
    assert hello['event'] == 'replay_ready'
    for path, sha in hello['shared_source_sha256'].items():
        checked(MAIN/path, sha, False)
    assert http['generation_contract'] == config['generation_contract'] == 'fixed_length_greedy_v1'
    assert http['renderer'] == 'role_lines_v1' and http['formal_run'] is False
    assert http['source_trace_seed'] == 42 and http['development_identity'] == 41
    assert http['pool_index_sha256'] == pool_sha
    assert audit['source_plan']['view_sha256'] == view_sha
    assert audit['source_plan'] == input_identity['plan']
    assert audit['source_plan']['profile'] == workload
    checked(audit['source_plan']['source_path'], audit['source_plan']['source_sha256'], False)
    assert audit['source_plan']['source_sha256'] == '4ea5d026da3820301e753ad6b03ea776e25a5c3f01921933bd124598eb26018d'
    if workload == 'W2':
        checked(http['adapter_map'], http['adapter_map_sha256'])
    assert audit['measurement_complete'] and audit['workload_passed']
    assert audit['backend_ready_receipts'] == 4 and audit['native_revalidated_requests'] == 4000
    assert audit['actual_native_output_tokens'] == 458224
    assert audit['model_key'] == '3b' and audit['counts'] == dict(N_plan=4000, N_arrived=4000,
        N_terminal=4000, N_response=4000, N_failed=0, N_submitted=4000)
    assert audit['common_slo']['binding_valid'] == 4000
    assert audit['common_slo']['freeze_sha256'] == sources[str(slo_path)]
    assert audit['n_correct'] is None and audit['independent_lora_numerical_correctness'] is False
    assert audit['formal_performance_qualified'] is False and audit['complete_system_qualified'] is False
    assert audit['request_time_pack_count'] == 0 and audit['remote_qualified']
    assert all(audit[k] <= 1 for k in ('max_e2e_recomputation_error_ms',
        'max_tpot_recomputation_error_ms', 'max_native_recompute_error_ms'))
    q = audit['conditional_metrics']['ttft_ms']['p95_type1']
    assert math.isfinite(q) and q > 0
    prereg = MAIN/f'docs/ieee_tc/{run.upper()}_3B_NATIVE_RESIDENT_{workload}.md'
    prereg_sha = checked(prereg, parse=False)
    context = launch['external_replay']
    assert context['config_sha256'] == sources[str(http_path)]
    assert abs(context['replay_t0_s']-context['deployment_notice_s']-60) < 1e-6
    runtime = dict(role='qualification_development', request_timeout_s=1800,
        timeout_origin='planned_arrival', ingress_timeout_s=1800, ingress_timeout_origin='ingress_accept',
        preparation_lead_s=60, online_slo_thresholds=None,
        http_config_sha256=sources[str(http_path)], native_worker_config_sha256=sources[str(source_raw/'model3b/worker_config.json')],
        source_proof='replay_frozen_http default plus PreReadyHTTPIngress default; both SHA-bound by native/replay receipts')
    generation = dict(contract='fixed_length_greedy_v1', temperature=0, top_p=1,
        ignore_eos=True, stop=[], stop_token_ids=[], target_rule='min(source_expected_output_tokens,256)',
        renderer='role_lines_v1', source_view_sha256=view_sha, pool_index_sha256=pool_sha,
        observed_native_output_tokens=458224, cross_system_matched_input_proof=False)
    execution = dict(run_id=run.upper(), model='llama32_3b_main_modelscope', workload=workload,
        execution_main_commit=manifest['execution_main_commit'], execution_baseline_commit=manifest['execution_baseline_commit'],
        input_identity_sha256=sources[str(source_raw/'input_identity.json')],
        launch_sha256=sources[str(source_raw/'launch3b.json')], generation_hash=canonical(generation),
        slo_runtime_hash=canonical(runtime), toolchain_sha256=sources[str(source_raw/'model3b/native_toolchain.json')])
    reference = dict(kind='single_run_resident_reference_v2', reference_id=f'3b_{workload}_vllm0300_{run.upper()}',
        model='llama32_3b_main_modelscope', workload=workload, reference_frozen=True,
        source_run=run.upper(), U_ref_gpu_seconds=u, Q_ref_p95_ttft_ms=q,
        budget_fraction=.75, B_gpu_seconds=.75*u, n_protocol_valid=4000, raw_n_correct=None,
        independent_numerical_proof=False, reused_development_observation=True, independent_holdout=False,
        formal_independent_correctness_qualified=False, source_audit_sha256=audit_sha,
        slo_eval_sha256=sources[str(slo_path)], warm_reference_sha256=slo['calibration']['sha256'],
        metric_protocol_sha256=metric_sha, single_run_amendment_sha256=v2_sha,
        qualification='Retained full native/content/input/timing audit and newly checked closed four-device integral; not HTTP success alone.',
        reference_slo_requirement=False, source_observed_joint_slo=audit['common_slo']['joint_attainment'],
        preregistration_document=dict(path=str(prereg), sha256=prereg_sha),
        cache_boundary='Compiler disk cache retained; actual JIT counted; whole lower kernel-cache equivalence not proved.',
        scope='Frozen numerical resource normalization, not independent numerical correctness, system optimum, or final G1/G2 achievement.')
    references[workload] = reference
    provenance[workload] = dict(kind='resident_reference_provenance_companion_v1',
        resource_reference_sha=canonical(reference), resource_reference_hash_encoding='canonical JSON record',
        slo_runtime_definition=runtime, slo_runtime_hash=canonical(runtime), slo_eval_hash=sources[str(slo_path)],
        warm_reference_sha=slo['calibration']['sha256'], metric_protocol_sha256=metric_sha,
        single_run_amendment_sha256=v2_sha, generation_definition=generation, generation_hash=canonical(generation),
        execution_definition=execution, execution_key=canonical(execution), execution_key_derived_after_run=True,
        original_preregistration_and_raw_flags_unchanged=True, not_a_new_performance_execution=True)
    rows.append(dict(workload=workload, source_run=run.upper(), native_binding_valid=4000,
        independent_numerical_proof=False, joint_good=audit['common_slo']['joint_good'],
        joint_slo=audit['common_slo']['joint_attainment'], U_ref_gpu_seconds=u,
        B_gpu_seconds=.75*u, Q_ref_p95_ttft_ms=q, gpu_seconds_per_binding_valid_request=u/4000,
        mean_ttft_ms=audit['conditional_metrics']['ttft_ms']['mean'],
        p95_tpot_ms=audit['conditional_metrics']['tpot_ms']['p95_type1'],
        actual_adapter_ids=audit['offered_unique_adapters'], remote_fetches=audit['remote_transfers'],
        remote_wire_bytes=audit['remote_wire_bytes']))

assert negative_tests == 4 and set(references) == {'W0', 'W1', 'W2'}
checked(Path(__file__), parse=False)
checked(MAIN/'scripts/ieee_tc/check_d299_full_context.py', parse=False)
checked(RESULTS/'main_comparison/d594_20261017/analyze.py', parse=False)
checked(P/'main_comparison/d424_7b_w0/reference_provenance.json', parse=False)
protected = p.verify_seal(RESULTS/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
analysis_definition = dict(operation='freeze_3b_complete_resident_references',
    source_refs=sources, metric_protocol_sha256=metric_sha, single_run_amendment_sha256=v2_sha,
    plan_sha256=plan_sha, budget_fraction=.75, no_new_measurements=True)
analysis_key = canonical(analysis_definition)
for row in provenance.values():
    row['analysis_key'] = analysis_key
OUT.mkdir(parents=True, exist_ok=False)
save(OUT/'resident_references.json', references)
save(OUT/'reference_provenance.json', provenance)
with (OUT/'summary.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
resources = {k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
save(OUT/'manifest.json', dict(passed=True, new_gpu_run=False, production_changed=False,
    identity=identity, resources=resources, protected=protected, preserved=preserved,
    analysis_definition=analysis_definition, analysis_key=analysis_key,
    source_refs=[dict(path=k, sha256=v) for k,v in sources.items()],
    outputs={n:p.digest(OUT/n) for n in ('resident_references.json','reference_provenance.json','summary.csv')},
    complete_references=3, reused_service_tests=89, reused_w2_input_tests=7,
    physical_rejection_checks=negative_tests,
    caveat='Single known-development observations. Native/content/measurement gates do not provide independent numerical correctness. No confidence intervals or system ranking.'))
save(RAW/'analysis_receipt.json', dict(passed=True, references=3, identity=identity,
    resources=resources, negative_tests=negative_tests, manifest_sha256=p.digest(OUT/'manifest.json')))
print(json.dumps(dict(passed=True, rows=rows, resources=resources)))
