"""Use affected-path qualification, preserving historical global flags.

First offline attempt incorrectly required the raw global remote_qualified flag.
The existing strict analyzer deliberately leaves that flag false and separately
qualifies the measured remote path. No performance data or thresholds change.
"""
from pathlib import Path
source = Path(__file__).with_name('analyze.py')
text = source.read_text()
old = "assert audit['request_time_pack_count'] == 0 and audit['remote_qualified']"
new = ("assert audit['request_time_pack_count'] == 0 and audit['remote_affected_path_qualified']\n"
       "    assert audit['remote_qualified'] is False")
assert text.count(old) == 1
text = text.replace(old, new)
for name in ('analysis_identity', 'analysis_receipt', 'resource_gate'):
    text = text.replace(name+'.json', name+'2.json' if name == 'resource_gate' else name.replace('analysis_', 'analysis2_')+'.json')
text = text.replace("checked(Path(__file__), parse=False)",
                    "checked(Path(__file__), parse=False)\nchecked(RAW/'analyze.py', parse=False)")
exec(compile(text, str(source), 'exec'))
