"""Reuse exact-owned recursive-empty closure."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')
text = source.read_text()
old = "'analysis','analysis2','publication','publication2'"
assert text.count(old) == 1
text = text.replace(old, "'analysis','analysis2','analysis3','publication','publication2'")
exec(compile(text, str(source), 'exec'))
