"""D657 final offline entry: bind config at replay-ready, where it is emitted.

The launcher terminal summary intentionally contains time/plan only. Bind its
time/plan to the replay-ready config SHA and saved input SHA, not an invented key.
Previous offline attempts are retained; no inference is repeated.
"""
from pathlib import Path
source = Path(__file__).with_name('analyze.py')
text = source.read_text()
replacements = {
    "assert audit['request_time_pack_count'] == 0 and audit['remote_qualified']":
        "assert audit['request_time_pack_count'] == 0 and audit['remote_affected_path_qualified']\n    assert audit['remote_qualified'] is False",
    "assert context['config_sha256'] == sources[str(http_path)]":
        "assert hello['config_sha256'] == input_identity['http_sha256'] == sources[str(http_path)]\n    assert context['plan'] == hello['plan'] == audit['source_plan']",
    "checked(Path(__file__), parse=False)":
        "checked(Path(__file__), parse=False)\nchecked(RAW/'analyze.py', parse=False)",
    "analysis_identity.json": "analysis3_identity.json",
    "analysis_receipt.json": "analysis3_receipt.json",
    "resource_gate.json": "resource_gate3.json",
}
for old, new in replacements.items():
    assert text.count(old) == 1, old
    text = text.replace(old, new)
exec(compile(text, str(source), 'exec'))
