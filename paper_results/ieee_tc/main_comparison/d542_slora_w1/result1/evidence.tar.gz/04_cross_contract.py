"""Reuse D537 input witness for the D542 measurement-repair observation."""
import json
import os
from pathlib import Path
import re
import sys

ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,allow_nan=False)
scope=p.scope_identity(p.cg_path().name)
save(RAW/'cross_identity.json',scope)
group=Path(scope['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
current=read(RAW/'audit_full4000_w1.json')
prior_root=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d536_20261015')
prior=read(prior_root/'audit_full4000_w1.json')
assert current['source_plan']==prior['source_plan']
assert current['common_slo']['freeze_sha256']==prior['common_slo']['freeze_sha256']
def contracts(path):
    out={}
    for line in path.open():
        row=json.loads(line)
        if row['event']=='request_contract':
            assert row['request_id'] not in out
            out[row['request_id']]=row
    assert len(out)==4000
    return out
paths=[RAW/'launch7b.launch/replay.jsonl',prior_root/'launch7b.launch/replay.jsonl']
a,b=map(contracts,paths)
assert a.keys()==b.keys()
fields=('adapter_id','artifact_content_sha256','artifact_manifest_sha256',
        'canonical_prompt_sha256','canonical_prompt_tokens','native_prompt_token_ids_sha256',
        'source_item_sha256','target_tokens')
for rid in a:
    for key in fields: assert a[rid][key]==b[rid][key],(rid,key)
prime_path=ROOT/'paper_results/ieee_tc/main_comparison/d533_full_w1/result1/cross_contract.json'
prime=read(prime_path)
assert prime['passed'] and prime['request_count']==4000
assert any(r['path']==str(paths[1]) and r['sha256']==p.digest(paths[1]) for r in prime['refs'])
serverless_path=ROOT/'paper_results/ieee_tc/main_comparison/d537_serverlessllm_w1/result1/cross_contract.json'
serverless=read(serverless_path)
assert serverless['passed'] and serverless['request_count']==4000
assert any(r['path']==str(paths[1]) and r['sha256']==p.digest(paths[1]) for r in serverless['refs'])
qual=read(RAW/'model7b/model_qualification.json')
cfg=read(RAW/'model7b/worker_config.json')
ready_paths=sorted((RAW/'model7b/worker_receipts').glob('*.json'))
ready_rows=sorted((read(x) for x in ready_paths),key=lambda r:r['index'])
assert len(ready_rows)==4 and all(r['adapter_count']==500 and r['tp']==1 for r in ready_rows)
preparation_path=RAW/'model7b/slora_full_pool_preparation.json'
preparation=read(preparation_path)
assert len(preparation)==500
comparison={
    'PrimeLoRA':prime['comparison']['PrimeLoRA'],
    'vLLM':prime['comparison']['vLLM'],
    'ServerlessLLM':serverless['comparison']['ServerlessLLM'],
    'S-LoRA':dict(joint=current['common_slo']['joint_attainment'],
        gpu_seconds=current['physical_gpu_seconds'],p95_ttft_ms=current['conditional_metrics']['ttft_ms']['p95_type1'])}
changes={}
for name in ('vLLM','ServerlessLLM','S-LoRA'):
    x,y=comparison['PrimeLoRA'],comparison[name]
    changes[name]=dict(lower_better_change_percent={k:100*(y[k]-x[k])/y[k] for k in ('gpu_seconds','p95_ttft_ms')},joint_difference_pp=100*(x['joint']-y['joint']))
save(RAW/'cross_contract.json',dict(passed=True,schema='d542_w1_input_witness_v1',scope=scope,
    request_count=4000,compared_fields=['request_id',*fields],source_plan=current['source_plan'],
    comparison=comparison,changes=changes,all_below_joint_95=all(row['joint']<.95 for row in comparison.values()),
    independent_numerical_correctness=False,reference_frozen=False,
    generation_contract='fixed_length_greedy_v1',input_join_only=True,
    initial_state_contract_identical=False,
    limitations=['Transitive input join via sealed D533-to-D536 witness; not numeric output equality.',
        'Native versions, LoRA slot/rank settings and compilation histories differ explicitly.',
        'No proof that all queue delay is caused by startup, compilation or one native mechanism.',
        'No per-configuration optimality or G1/G2 feasibility is inferred solely from relative changes.'],
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in (*paths,prime_path,serverless_path,RAW/'audit_full4000_w1.json',Path(__file__))]))
notice=cfg['deployment_notice_s']
business=read(RAW/'launch7b.launch/exec_receipt.json')['external_replay']['replay_t0_s']
allocations={i:row for i,row in enumerate(qual['physical_allocations'])}
workers=[]
for row in ready_rows:
    events=allocations[row['index']]['events']
    acquire=[e['at'] for e in events if e['event']=='acquire']
    assert len(acquire)==1
    workers.append(dict(index=row['index'],native_ready_s=row['at'],
        notice_to_ready_s=row['at']-notice,business_to_ready_s=row['at']-business,
        acquire_s=acquire[0],acquire_to_ready_s=row['at']-acquire[0],
        adapter_count=row['adapter_count'],tp=row['tp']))
save(RAW/'startup_diagnostic.json',dict(scope=scope,
    deployment_notice_s=notice,business_start_s=business,
    full_pool_prepare_start_s=min(r['tc_artifact_resolve_started_s'] for r in preparation.values()),
    full_pool_prepare_end_s=max(r['tc_artifact_resolve_completed_s'] for r in preparation.values()),
    full_pool_count=len(preparation),worker_startup=cfg['worker_startup'],
    worker_ready=workers,
    phase_joint=[r['common_slo']['joint_good'] for r in current['source_order_diagnostics']],
    queue_mean_fraction_of_ttft=current['conditional_metrics']['router_queue_ms']['mean']/current['conditional_metrics']['ttft_ms']['mean'],
    causal_attribution_complete=False,
    limitations=['Sequential startup is a disclosed frozen deployment adaptation, not a uniquely intrinsic S-LoRA inference cost.',
        'No subtraction of deployment or queue spans from user latency; no partial request selection.'],
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in
          (*ready_paths,preparation_path,RAW/'model7b/worker_config.json',RAW/'model7b/model_qualification.json')]))
print(json.dumps(dict(passed=True,comparison=comparison,changes=changes,scope=scope)))
