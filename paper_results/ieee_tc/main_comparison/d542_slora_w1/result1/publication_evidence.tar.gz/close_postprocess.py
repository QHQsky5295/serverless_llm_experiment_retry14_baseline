"""Reuse D539 exact-identity recursive-empty closure."""
import json, subprocess, sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
name=sys.argv[1];assert name in ('cross','result','result_publication')
identity=json.loads((RAW/(name+'_identity.json')).read_text())
assert p.scope_still_owned(identity)
group=Path(identity['path'])
members={str(x):x.read_text().split() for x in group.rglob('cgroup.procs')}
assert members and all(not v for v in members.values())
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert not group.exists()
with (RAW/(name+'_closure.json')).open('x') as f:
    json.dump(dict(passed=True,identity=identity,actual_recursive_procs_empty=True,path_gone=True,
        resources=resources,source_sha256=p.digest(Path(__file__))),f,indent=2)
print(json.dumps(dict(passed=True,name=name,resources=resources)))
