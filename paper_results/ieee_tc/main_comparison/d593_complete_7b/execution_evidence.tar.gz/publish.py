"""Reuse D592 exact-path/checksum/secret/protected publication guards."""
import hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d593_complete_7b'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path): return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f: json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='79fdd4115b7a94d4173ba2434a81597a54bcf098'
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['path_gone'] and not Path(closure['identity']['path']).exists()
record=read(OUT/'manifest.json')
assert record['passed'] and record['new_gpu_runs']==0 and not record['production_changed']
for path,sha in record['preserved'].items(): assert p.digest(Path(path))==sha
for name,sha in record['outputs'].items(): assert p.digest(OUT/name)==sha
for ref in record['analysis_sources']: assert p.digest(Path(ref['path']))==ref['sha256']
for ref in record['source_refs']: assert p.digest(Path(ref['path']))==ref['sha256']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members=[RAW/name for name in ('analyze.py','close.py','publish.py','analysis_identity.json','analysis_receipt.json',
    'analysis_closure.json','resource_gate.json','tests.json','tests.log')]
archive=OUT/'execution_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in members:
        data=path.read_bytes();check(data);bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    for path in members: assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
files=list(record['outputs'])+['manifest.json','execution_evidence.tar.gz']
with (OUT/'result.sha256').open('x') as stream:
    for name in files: stream.write(p.digest(OUT/name)+'  '+name+'\n')
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D593_COMPLETE_7B_COMPARISON.md',
       'scripts/ieee_tc/check_d299_full_context.py','tests/test_ieee_tc_sealed_matrix.py']
names += [str((OUT/name).relative_to(ROOT)) for name in files+['result.sha256']]
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names: check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(names) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged: assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: retain complete sealed 7B W0-W2 baseline matrix and constraints (D593)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity,protected=protected))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)))
