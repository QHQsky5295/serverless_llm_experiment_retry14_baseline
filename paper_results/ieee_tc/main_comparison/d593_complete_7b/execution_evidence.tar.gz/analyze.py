"""D593 reuses D513 bounded sealed-observation aggregation; no inference."""
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/main_comparison/d593_complete_7b'
P = ROOT/'paper_results/ieee_tc'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.check_d299_full_context import sealed_matrix_row, sealed_matrix_view

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

identity = p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json', identity)
group = Path(identity['path'])
def resources():
    return {k: (group/k).read_text().strip() for k in
        ('memory.high', 'memory.max', 'memory.swap.max', 'memory.peak', 'memory.events', 'memory.swap.current')}
limits = resources()
assert limits['memory.high'] == str(3*p.GIB) and limits['memory.max'] == str(4*p.GIB)
assert limits['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([ROOT], 16*1024*1024)
save(RAW/'resource_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
preserved = {
 ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
 BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
 BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path, sha in preserved.items(): assert p.digest(path) == sha
seal = RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json'
assert p.verify_seal(seal)['pass']
with (RAW/'tests.log').open('x') as stream:
    tests = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromNames([
            'tests.test_ieee_tc_sealed_matrix', 'tests.test_ieee_tc_published_baseline_view']))
save(RAW/'tests.json', dict(passed=tests.wasSuccessful(), count=tests.testsRun,
     errors=len(tests.errors), failures=len(tests.failures)))
assert tests.wasSuccessful()

head = subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'], text=True).strip()
source_refs = {}
def sealed(path):
    data = path.read_bytes()
    committed = subprocess.check_output(['git','-C',str(ROOT),'show',head+':'+str(path.relative_to(ROOT))])
    assert data == committed, f'unsealed curated source: {path}'
    source_refs[str(path)] = hashlib.sha256(data).hexdigest()
    return json.loads(data)

slo = P/'protocols/20261010_7b_slo_d394_frozen.json'
slo_sha = p.digest(slo)
assert slo_sha == '2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3'
sealed(slo)
registry = sealed(ROOT/'docs/ieee_tc/BASELINE_PUBLICATION_REGISTRY_20261014.json')
old = P/'main_comparison/d513_published_7b_w0/comparison.json'
specs = [(name,run,'W0','published_w0',old) for name,run in
         [('PrimeLoRA','D476'),('vLLM','D423'),('ServerlessLLM','D414'),('S-LoRA','D435')]]
for run,w in [('D551','W1'),('D554','W2')]:
    suffix = 'result2' if w == 'W1' else 'result1'
    specs.append(('PrimeLoRA',run,w,'prime_summary',P/f'main_comparison/{run.lower()}_initial_control_full_{w.lower()}/{suffix}/summary.json'))
for system,slug,points in [('vLLM','vllm',[('D536','W1'),('D557','W2')]),
                         ('ServerlessLLM','serverlessllm',[('D537','W1'),('D555','W2')]),
                         ('S-LoRA','slora',[('D542','W1'),('D591','W2')])]:
    for run,w in points:
        specs.append((system,run,w,'native_audit',P/f'main_comparison/{run.lower()}_{slug}_{w.lower()}/result1/audit.json'))
for run,w in [('D585','W0'),('D587','W1'),('D589','W2')]:
    specs.append(('Loquetier',run,w,'native_audit',P/f'loquetier/{run.lower()}_capacity_full_{w.lower()}/result1/audit.json'))
for run,w in [('D576','W0'),('D579','W1'),('D582','W2')]:
    specs.append(('HydraServe',run,w,'hydra_evaluation',P/f'hydraserve/{run.lower()}_lifecycle_full_{w.lower()}_result/full_{w.lower()}_evaluation.json'))

rows, registration, identities = [], [], {}
for name,run,w,kind,path in specs:
    source = sealed(path)
    row = sealed_matrix_row(source, source_kind=kind, system=name, run=run, workload=w, slo_sha=slo_sha)
    row['source_ref'] = dict(path=str(path), sha256=source_refs[str(path)], source_kind=kind)
    if row['source_plan'] is not None:
        plan = row['source_plan']
        key = (plan['source_sha256'], plan['view_sha256'])
        if w in identities: assert identities[w] == key
        identities[w] = key
    # Reuse the already completed input-join receipts rather than replaying raw
    # logs. HydraServe W0/W1 use their verified old/new contract-preserving joins.
    if kind == 'native_audit' and not (name == 'vLLM' and w == 'W1'):
        join_path = path.parent/'cross_contract.json'
        join = sealed(join_path)
        assert join['passed'] is True and join['request_count'] == 4000
        assert join['source_plan']['view_sha256'] == row['source_plan']['view_sha256']
    elif kind == 'prime_summary':
        assert source['cross_contract']['passed'] is True and source['cross_contract']['request_count'] == 4000
    elif kind == 'hydra_evaluation':
        jname = {'W0':'old_new_w0_comparison_v2.json','W1':'old_new_w1_comparison.json','W2':'cross_contract.json'}[w]
        join = sealed(path.parent/jname)
        assert join['passed'] is True
        assert (join['request_count'] if w == 'W2' else join['n']) == 4000
    registration.append(dict(system=name, run=run, workload=w, source_kind=kind,
                             path=str(path), sha256=source_refs[str(path)]))
    rows.append(row)

references = {}
existing = sealed(P/'main_comparison/d424_7b_w0/resident_reference.json')
for w,run in [('W0','D423'),('W1','D536'),('W2','D557')]:
    row = next(r for r in rows if r['workload']==w and r['system']=='vLLM')
    references[w] = dict(workload=w, source_run=run, reference_frozen=(w=='W0'),
        U_ref_gpu_seconds=row['physical_gpu_seconds'], Q_ref_p95_ttft_ms=row['metrics']['ttft_ms']['p95_type1'],
        B_gpu_seconds=.75*row['physical_gpu_seconds'], independent_numerical_proof=False,
        status='existing_frozen_development_reference' if w=='W0' else 'registered_complete_reference_candidate_review_pending')
assert references['W0']['U_ref_gpu_seconds'] == existing['U_ref_gpu_seconds']
assert references['W0']['B_gpu_seconds'] == existing['B_gpu_seconds']
report = sealed_matrix_view(rows, registry, references)
report.update(current_plan_sha256=p.check_plan(), source_checkpoint=head, common_slo_sha256=slo_sha,
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_amendment_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    common_workload_identities={w:dict(source_sha256=k[0],view_sha256=k[1]) for w,k in identities.items()},
    source_refs=[dict(path=path,sha256=sha) for path,sha in source_refs.items()])
OUT.mkdir(parents=True, exist_ok=False)
save(OUT/'source_registration.json', registration)
save(OUT/'comparison.json', report)
with (OUT/'metrics.csv').open('x',newline='') as stream:
    writer = csv.writer(stream, lineterminator='\n')
    writer.writerow(['workload','system','run','binding_valid','joint_good','joint_slo','gpu_seconds',
        'gpu_seconds_per_binding_valid','mean_ttft_ms','p95_ttft_ms','mean_tpot_ms','p95_tpot_ms','mean_e2e_ms',
        'ratio_to_resident_candidate_75pct_budget','reference_frozen','independent_numerical_proof'])
    for w in ('W0','W1','W2'):
        for name in ('PrimeLoRA','vLLM','S-LoRA','ServerlessLLM','HydraServe','Loquetier'):
            r=report['results'][w][name];m=r['metrics']
            writer.writerow([w,name,r['run'],4000,r['counts']['joint_pass'],r['joint_slo'],r['physical_gpu_seconds'],
                r['gpu_seconds_per_protocol_valid_request'],m['ttft_ms']['mean'],m['ttft_ms']['p95_type1'],
                m['tpot_ms']['mean'],m['tpot_ms']['p95_type1'],m['e2e_ms']['mean'],
                r['physical_gpu_seconds']/references[w]['B_gpu_seconds'],references[w]['reference_frozen'],False])
for path,sha in source_refs.items(): assert p.digest(Path(path)) == sha
for path,sha in preserved.items(): assert p.digest(path) == sha
protected = p.verify_seal(seal)
assert protected['pass'] and protected['entry_count']==147
manifest = dict(passed=True,new_gpu_runs=0,production_changed=False,identity=identity,resources=resources(),
    protected=protected,preserved={str(k):v for k,v in preserved.items()},source_checkpoint=head,
    tests=tests.testsRun,source_refs=report['source_refs'],
    analysis_sources=[dict(path=str(f),sha256=p.digest(f)) for f in (Path(__file__),
        ROOT/'scripts/ieee_tc/check_d299_full_context.py',ROOT/'tests/test_ieee_tc_sealed_matrix.py')],
    outputs={name:p.digest(OUT/name) for name in ('comparison.json','metrics.csv','source_registration.json')})
save(OUT/'manifest.json',manifest)
save(RAW/'analysis_receipt.json',dict(passed=True,scope=identity,resources=resources(),rows=len(rows),tests=tests.testsRun))
print(json.dumps(dict(passed=True,rows=len(rows),tests=tests.testsRun,resources=resources())))
