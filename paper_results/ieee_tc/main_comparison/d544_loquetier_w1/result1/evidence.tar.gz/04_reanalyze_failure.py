"""D544 offline failure-schema repair; do not rerun serving or collection."""
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path, row):
    with path.open('x') as f: json.dump(row,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'analysis2_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed=json.loads((RAW/'analysis_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
analyzer=MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py'
tests=MAIN/'tests/test_tc_serverless_qualification_population.py'
commands=[('analysis2_tests.log',[sys.executable,'-m','unittest','discover','-s','tests',
    '-p',tests.name,'-v']),
    ('analysis2.log',[sys.executable,str(analyzer),'--root',str(RAW),'--baseline',str(BASE),
        '--main',str(MAIN),'--scheduler-contract','loquetier_static_shards_v1',
        '--population','full4000_w1','--outcome','complete_with_failures',
        '--slo-freeze',str(MAIN/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json'),
        '--output',str(RAW/'audit_full4000_w1.json')])]
results=[]
try:
    for name, command in commands:
        with (RAW/name).open('x') as log:
            completed=subprocess.run(command,cwd=MAIN,stdout=log,stderr=subprocess.STDOUT,
                env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(BASE/'scripts')))
        results.append(dict(log=name,command=command,returncode=completed.returncode))
        completed.check_returncode()
finally:
    record=dict(passed=len(results)==len(commands) and all(r['returncode']==0 for r in results),
        identity=identity,commands=results,
        source_sha256={str(x):p.digest(x) for x in (Path(__file__),analyzer,tests)},
        resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')})
    save(RAW/'analysis2_receipt.json',record)
print(json.dumps(record))
