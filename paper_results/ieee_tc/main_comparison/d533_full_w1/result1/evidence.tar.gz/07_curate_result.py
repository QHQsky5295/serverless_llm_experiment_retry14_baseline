"""Reuse D530 bounded curation for D533; no repeated tests or GPU execution."""
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d533_full_w1/result1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'result_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
summary=read(RAW/'actual_qualification.json')
assert summary['passed'] and summary['fixed_workload_complete4000']
assert summary['protocol_bound_count']==4000 and summary['native_tokens']==458224
assert summary['workload_identity']['profile']=='W1' and summary['stats']['n_correct'] is None
assert 0<=summary['common_threshold_joint_count']<=4000
assert summary['max_e2e_identity_error_ms']<=1
assert summary['evidence']['max_native_ttft_error_ms']<=1 and summary['evidence']['max_native_tpot_error_ms']<=1
joined=read(RAW/'cross_contract.json')
assert joined['passed'] and joined['request_count']==4000
for ref in summary['refs']+joined['refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
# Correct only the cache-path projection from already preserved literal log lines.
# The original intermediate JSON and failed parser source remain immutable.
before=read(RAW/'model_cache_metadata_before.json')
for worker in joined['initial_state']['workers']:
    paths=[line.split('Using cache directory: ',1)[1].split(' for ',1)[0]
        for line in worker['log_evidence'] if 'Using cache directory: ' in line]
    worker['cache_paths']=paths
    worker['cache_metadata_present_before']={path:any(row['path']==path+'/cache_key_factors.json'
        for row in before['entries']) for path in paths}
assert sum(len(w['cache_paths']) for w in joined['initial_state']['workers'])==1
assert joined['initial_state']['workers'][0]['cache_metadata_present_before']=={
    '/home/qhq/.cache/vllm/torch_compile_cache/3a5577e355/rank_0_0/backbone':False}
joined['projection_correction']=dict(source=str(RAW/'cross_contract.json'),
    sha256=p.digest(RAW/'cross_contract.json'),reason='overescaped regex in intermediate cache-directory projection; restore exact saved log literal, no metric or input change')
for name in ('contract','review'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and not Path(closed['identity']['path']).exists()
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
binding_path=ROOT/'paper_results/ieee_tc/main_comparison/d531_w1_input/qualification.json'
binding=read(binding_path)
assert binding['passed'] and binding['tests']==103
compiler_path=ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain/qualification.json'
compiler=read(compiler_path)
assert compiler['passed'] and compiler['test_count']==16
for path,sha in {**compiler['refs'],**compiler['preserved']}.items():assert p.digest(Path(path))==sha,path
for path,sha in {**binding['refs'],**binding['preserved']}.items():
    current=p.digest(Path(path))
    assert current==sha or (path in compiler['refs'] and current==compiler['refs'][path]),path
build_path=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=read(build_path)
assert build['passed'] and build['actual_closure']['passed']
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256'],path
preserved={str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
           str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
           str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
subprocess.run(['git','diff','--exit-code','fc4161a1088efe1b49d853dbbc8effe9a525c431','--',
                'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=ROOT,check=True)
OUT.mkdir(parents=True,exist_ok=False)
files=[RAW/name for name in ('close_launch.py','stop_remote.sh','collect_closure.py',
       'run_analysis.py','analyze.py','analyze_prefix.py','close.py','curate_result.py',
       'cross_contract.py','cross_contract_v2.py','contract1_failure.json',
       'cross_contract.json','local_cleanup.json','analysis_identity.json','analysis_receipt.json',
       'analysis_closure.json','contract_closure.json','review_closure.json','remote_stop.log',
       'remote_stop.json','collection_receipt.json','completion_receipt.json',
       'cpu_preparation_evidence.json','reference_candidate.json','model_cache_metadata_before.json')]
files += [Path(w['worker_root'])/'worker.log' for w in joined['initial_state']['workers']]
files += [RAW/'7b_full_w1/launch.json',RAW/'7b_full_w1/launch.launch/physical_deployment/summary.json',
          ROOT/'scripts/ieee_tc/plot_d290_diagnostic.py',
          ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'docs/ieee_tc/D533_FULL_W1_RESULT.md']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
members={}
archive=OUT/'evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes()
        assert len(data)<32*1024*1024
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
        name=f'{i:02d}_{path.name}'
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o600;member.mtime=0
        tar.addfile(member,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
assert archive.stat().st_size<2*1024*1024
with (OUT/'audit.json').open('xb') as stream:stream.write((RAW/'actual_qualification.json').read_bytes())
save(OUT/'cross_contract.json',joined)
save(OUT/'manifest.json',dict(passed=True,scope=identity,new_gpu_run=False,production_changed=False,
     reference_frozen=False,reason='full model graph startup reviewed; whole lower-level cache prestate and independent numerical proof remain unestablished',
     reused_tests=dict(count=103,path=str(binding_path),sha256=p.digest(binding_path)),
     compiler_qualification_sha256=p.digest(compiler_path),common_build_sha256=p.digest(build_path),
     execution_main_commit='fc4161a1088efe1b49d853dbbc8effe9a525c431',
     execution_baseline_commit='bde215460acb9e850efa479a89bda6fc39a2bd7d',
     metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
     single_run_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
     protected=protected,preserved=preserved,source_refs=summary['refs']+joined['refs'],archive_members=members,
     outputs={name:p.digest(OUT/name) for name in ('audit.json','cross_contract.json','evidence.tar.gz')}))
print(json.dumps(dict(passed=True,reused_tests=103,archive_bytes=archive.stat().st_size,scope=identity)))
