"""Reuse full4000 analyzer, retain its strict output, expose new lifecycle evidence."""
import contextlib
import io
import ijson
import json
from pathlib import Path
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
# The parent post-release collector owns and records the shared analysis scope.
source=RAW/'analyze_prefix.py'
out=io.StringIO()
with contextlib.redirect_stdout(out):
    exec(compile(source.read_text(),str(source),'exec'),dict(__file__=str(source),__name__='d533_audit'))
result=json.loads(out.getvalue())
with (RAW/'actual_qualification.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
with (RAW/'7b_full_w1/launch.launch/physical_deployment/main_outcome.json').open('rb') as handle:
    cpu_preparation=next(ijson.items(handle,'cpu_frontend_preparation',use_float=True))
with (RAW/'cpu_preparation_evidence.json').open('x') as f:
    json.dump(cpu_preparation,f,indent=2,allow_nan=False)
print(json.dumps(dict(passed=result['passed'],stats=result['stats'],
    joint=result['common_threshold_joint_count'],tokens=result['native_tokens'],
    activation=result['activation_state_counts'],resources=result['resources'],
    cpu_preparation_count=len(cpu_preparation['records'])),indent=2))
