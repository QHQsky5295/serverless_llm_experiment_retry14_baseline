"""Independent existing-baseline input witness; no performance or output equality claim."""
import json
import sys
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.ieee_tc.plot_d290_diagnostic import load, sha256
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

scope=p.scope_identity(p.cg_path().name)
with (RAW/'contract_identity.json').open('x') as f:json.dump(scope,f,indent=2)
group=Path(scope['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
closed=json.loads((RAW/'analysis_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
run = RAW/'7b_full_w1'
source = next(run.glob('experiment_results*.json'))
_, scenario = load(source)
requests = {r['request_id']:r for r in scenario['requests']}
context = json.loads((run/'launch.launch/exec_receipt.json').read_text())['external_replay']
plan = FrozenReplayPlan.from_launch_context(context)
entries = {e.request_id:e for e in plan.entries}
prior = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d536_20261015/launch7b.launch/replay.jsonl')
contracts = {}
for line in prior.open():
    event = json.loads(line)
    if event['event'] == 'request_contract':
        assert event['request_id'] not in contracts
        contracts[event['request_id']] = event
assert len(contracts) == 4000 and len(requests) == 4000
baseline_path=ROOT/'paper_results/ieee_tc/main_comparison/d536_vllm_w1/result1/audit.json'
baseline=json.loads(baseline_path.read_text())
for key in ('source_sha256','view_sha256','count','source_count','profile','rate_scale'):
    assert plan.identity()[key]==baseline['source_plan'][key],key
assert requests.keys() == entries.keys() and requests.keys() <= contracts.keys()
for rid, row in requests.items():
    ref = contracts[rid]
    entry = entries[rid]
    assert row['adapter_id'] == ref['adapter_id']
    assert row['requested_completion_tokens'] == row['completion_tokens'] == ref['target_tokens']
    assert row['canonical_prompt_sha256'] == ref['canonical_prompt_sha256']
    assert row['canonical_prompt_tokens'] == ref['canonical_prompt_tokens']
    assert row['native_token_timing']['native_prompt_token_ids_sha256'] == ref['native_prompt_token_ids_sha256']
    assert entry.source_sha256 == ref['source_item_sha256']
    assert row['generation_contract'] == 'fixed_length_greedy_v1'
    assert row['output_contract_match'] is True

frozen = {
    Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'):'d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md':'5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md':'193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    Path('/home/qhq/serverless_llm_baselines/scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    Path('/home/qhq/serverless_llm_baselines/scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499',
}
for path, digest in frozen.items():
    assert sha256(path) == digest, path
# Inspect exact owned worker logs; no broad cache scan or inference.
prep=json.loads((RAW/'cpu_preparation_evidence.json').read_text())
before=json.loads((RAW/'model_cache_metadata_before.json').read_text())
import re
workers=[]
log_refs=[]
toolchain=json.loads((run/'launch.launch/service.log').read_text().split('TC_NATIVE_TOOLCHAIN_RECEIPT ',1)[1].splitlines()[0])
for record in prep['records']:
    worker=Path(record['worker_root'])
    log=worker/'worker.log'
    text=log.read_text()
    receipts=[json.loads(line.split('TC_NATIVE_TOOLCHAIN_RECEIPT ',1)[1]) for line in text.splitlines() if line.startswith('TC_NATIVE_TOOLCHAIN_RECEIPT ')]
    assert receipts and all(r==toolchain for r in receipts)
    prefixes=re.findall(r'Using cache directory: (\\S+) for',text)
    important=[line for line in text.splitlines() if any(marker in line for marker in (
        'Using cache directory:', 'Compiling a graph for', 'torch.compile took',
        'saved AOT compiled function', 'Directly load AOT compilation',
        'init engine (profile,', 'Triton kernel JIT compilation during inference:'))]
    workers.append(dict(worker_root=str(worker),state=record['state'],
        log_sha256=sha256(log),cache_paths=prefixes,log_evidence=important,
        cache_metadata_present_before={path:any(row['path']==path+'/cache_key_factors.json' for row in before['entries']) for path in prefixes}))
    log_refs.append(log)
baseline_worker=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/vllm_qualification/d536_20261015/model7b/worker_0.log')
baseline_log=baseline_worker.read_text()
baseline_receipts=[json.loads(line.split('TC_NATIVE_TOOLCHAIN_RECEIPT ',1)[1]) for line in baseline_log.splitlines() if line.startswith('TC_NATIVE_TOOLCHAIN_RECEIPT ')]
assert baseline_receipts and all(row==toolchain for row in baseline_receipts)
initial_state=dict(common_compiler_receipt_equal=True,workers=workers,
    baseline_worker0_log_sha256=sha256(baseline_worker),
    baseline_worker0_log_evidence=[line for line in baseline_log.splitlines() if any(marker in line for marker in (
        'Using cache directory:', 'Compiling a graph for', 'torch.compile took',
        'saved AOT compiled function','init engine (profile,','Triton kernel JIT compilation during inference:'))],
    whole_cache_prestate_proved=False,
    limitation='Both initial model graphs compiled in measured startup; lower-level kernel cache sharing is not excluded. Different native LoRA configurations remain explicit.')
candidate=json.loads((RAW/'reference_candidate.json').read_text())
assert candidate['values']['U']==baseline['physical_gpu_seconds']
actual=json.loads((RAW/'actual_qualification.json').read_text())
comparison=dict(PrimeLoRA=dict(joint=actual['common_threshold_joint_count']/4000,
    gpu_seconds=actual['stats']['physical_gpu_seconds'],p95_ttft_ms=actual['stats']['p95_ttft_ms']),
    vLLM=dict(joint=baseline['common_slo']['joint_attainment'],gpu_seconds=baseline['physical_gpu_seconds'],
    p95_ttft_ms=baseline['conditional_metrics']['ttft_ms']['p95_type1']))
comparison['lower_better_change_percent']={k:100*(comparison['vLLM'][k]-comparison['PrimeLoRA'][k])/comparison['vLLM'][k] for k in ('gpu_seconds','p95_ttft_ms')}
comparison['joint_difference_pp']=100*(comparison['PrimeLoRA']['joint']-comparison['vLLM']['joint'])
comparison['reference_frozen']=False
comparison['budget_candidate']=candidate['values']['budget']
comparison['PrimeLoRA_budget_ratio']=actual['stats']['physical_gpu_seconds']/candidate['values']['budget']
comparison['both_below_95_percent']=comparison['PrimeLoRA']['joint']<.95 and comparison['vLLM']['joint']<.95
result=dict(kind='d533_existing_original4000_input_witness_v1',passed=True,
    initial_state=initial_state,comparison= comparison,
    numerical_difference_cause='unknown; input binding is not independent numerical proof',
    request_count=len(requests),compared_fields=['request_id','adapter_id','target_tokens',
        'canonical_prompt_sha256','canonical_prompt_tokens','native_prompt_token_ids_sha256',
        'source_item_sha256'],
    generation_contract='fixed_length_greedy_v1',output_token_equality_required=False,
    numerical_correctness_qualified=False,performance_comparison=False,
    scope=p.scope_identity(p.cg_path().name),
    refs=[dict(path=str(path),sha256=sha256(path)) for path in (source,prior,baseline_path,baseline_worker,RAW/'model_cache_metadata_before.json',RAW/'reference_candidate.json',Path(__file__),*log_refs,*frozen)])
with (RAW/'cross_contract.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
print(json.dumps(dict(passed=True,request_count=4000,comparison=comparison,scope=scope)))
