"""Bounded read-only D536 cache-factor and phase review; no GPU/import/build."""
import json, os, subprocess, sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
CACHE=Path('/home/qhq/.cache/vllm/torch_compile_cache')
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'review_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert read(RAW/'publication_receipt.json')['passed']
assert read(RAW/'publication_closure.json')['path_gone']
oldpath=CACHE/'1618ac661c/rank_0_0/backbone/cache_key_factors.json'
newpath=CACHE/'6d1961d6a9/rank_0_0/backbone/cache_key_factors.json'
old,new=read(oldpath),read(newpath)
paths=sorted(CACHE.glob('*/rank_0_0/backbone/cache_key_factors.json'))
assert len(paths)<=2048
matching=[]
for path in paths:
    assert path.stat().st_size<128*1024
    factors=read(path)
    if factors['env']==new['env'] and factors['compiler_hash']==new['compiler_hash']:
        matching.append(dict(path=str(path),sha256=p.digest(path),mtime_ns=path.stat().st_mtime_ns,
            config_hash=factors['config_hash'],code_hash=factors['code_hash']))
summary=read(RAW/'audit_full4000_w1.json')
phases=[dict(phase=i+1,indices=row['source_indices_inclusive'],
    joint_good=row['common_slo']['joint_good'],offered=row['common_slo']['offered'],
    p95_ttft_ms=row['metrics']['ttft_ms']['p95_type1'])
    for i,row in enumerate(summary['source_order_diagnostics'])]
assert len(phases)==8 and sum(row['joint_good'] for row in phases)==summary['common_slo']['joint_good']
envdiff={k:dict(old=old['env'].get(k),new=new['env'].get(k))
    for k in sorted(set(old['env'])|set(new['env'])) if old['env'].get(k)!=new['env'].get(k)}
native=Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925/lib/python3.12/site-packages/vllm')
sourcepaths=[native/name for name in ('compilation/backends.py','compilation/caching.py',
    'compilation/decorators.py','compilation/compiler_interface.py','config/lora.py','config/vllm.py')]
config=ROOT/'configs/ieee_tc/20261015_d533_7b_full_w1.yaml'
assert 'max_loras: 14' in config.read_text() and 'max_lora_rank: 16' in config.read_text()
receipt=read(next((RAW/'model7b/worker_receipts').glob('*.json')))
assert receipt['engine_args']['max_loras']==4 and receipt['engine_args']['max_lora_rank']==64
result=dict(passed=True,identity=identity,new_gpu_run=False,production_or_cache_changed=False,
    scope='bounded direct rank_0_0/backbone metadata census; not a whole-cache prestate proof',
    inspected_metadata_count=len(paths),same_environment_compiler_metadata=matching,
    previous_vs_current=dict(code_equal=old['code_hash']==new['code_hash'],
        config_equal=old['config_hash']==new['config_hash'],
        compiler_hashes=[old['compiler_hash'],new['compiler_hash']],environment_differences=envdiff),
    phases=phases,reference_frozen=False,
    reference_values_predeclared=dict(U=summary['physical_gpu_seconds'],
        Q=summary['conditional_metrics']['ttft_ms']['p95_type1'],budget=.75*summary['physical_gpu_seconds']),
    limitations=['Census after D536 cannot prove every file absent before D536.',
        'Different LoRA graph configuration prevents treating D536 full-graph cache as identical to D533.',
        'Shared lower-level kernel cache transfer is not excluded by graph-key difference.',
        'Do not attribute all SLO failures to startup; preserve all eight phase slices.',
        'No benchmark restart, prewarm, cache deletion, threshold or serving change.'],
    refs={str(path):p.digest(path) for path in [Path(__file__),oldpath,newpath,config,
        RAW/'audit_full4000_w1.json',*sourcepaths]})
save(RAW/'initial_state_review.json',result)
print(json.dumps(dict(passed=True,metadata_count=len(paths),same_environment_compiler_metadata=matching,
    environment_differences=envdiff,phases=phases,reference_frozen=False)))
