"""D513: reuse bounded offline comparison/protection workflow, no inference."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/main_comparison/d513_published_7b_w0'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.check_d299_full_context import export_published_w0

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

identity = p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json', identity)
group = Path(identity['path'])
def resources():
    return {key: (group/key).read_text().strip() for key in
        ('memory.high', 'memory.max', 'memory.swap.max', 'memory.peak', 'memory.events', 'memory.swap.current')}
limits = resources()
assert limits['memory.high'] == str(3*p.GIB) and limits['memory.max'] == str(4*p.GIB)
assert limits['memory.swap.max'] == '0' and os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([ROOT], p.GIB)
assert gate['preflight_pass'], gate['issues']
source = ROOT/'paper_results/ieee_tc/main_comparison/d510_7b_w0/comparison.json'
registry = ROOT/'docs/ieee_tc/BASELINE_PUBLICATION_REGISTRY_20261014.json'
preserved = {
    source: 'd8f1f1ab7acc698d0653cefde4afa135e69a906b014bd4b0dfd3a55a5b856288',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md': '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md': '193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    ROOT/'configs/generated/lora_manifest_1000.json': '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    BASE/'scripts/replay_openai_trace.py': '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    BASE/'scripts/run_serverlessllm_relayserve_continuation.sh': '337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path, digest in preserved.items():
    assert p.digest(path) == digest, path
seal = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')
before = p.verify_seal(seal)
assert before['pass'] and before['entry_count'] == 147
tests = ('tests.test_ieee_tc_published_baseline_view', 'tests.test_tc_serverless_qualification_population',
         'tests.test_ieee_tc_full_control_analysis')
with (RAW/'tests1.log').open('x') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromNames(tests))
save(RAW/'tests1_receipt.json', dict(passed=result.wasSuccessful(), count=result.testsRun,
    errors=len(result.errors), failures=len(result.failures), resources=resources(), identity=identity))
assert result.wasSuccessful()
export_published_w0(source, preserved[source], registry, OUT)
view = json.loads((OUT/'comparison.json').read_text())
original = json.loads(source.read_text())
assert all(row == original['results'][name] for name, row in view['results'].items())
assert view['reference'] == original['reference']
assert p.verify_seal(seal)['pass']
for path, digest in preserved.items():
    assert p.digest(path) == digest, path
sources = [source, registry, Path(__file__), ROOT/'scripts/ieee_tc/check_d299_full_context.py',
    ROOT/'scripts/ieee_tc_preflight.py', p.PLAN, p.SNAPSHOT,
    ROOT/'docs/ieee_tc/BASELINE_SCOPE_20261014.md', ROOT/'docs/ieee_tc/SLO_BUDGET_RATIONALE_20261014.md']
sources += [ROOT/(name.replace('.', '/')+'.py') for name in tests]
manifest = dict(passed=True, kind='d513_offline_publication_scope_and_sensitivity',
    new_gpu_runs=0, serving_code_changed=False, old_rows_unchanged=True, tests=result.testsRun,
    protected_entries=147, preserved={str(path): digest for path, digest in preserved.items()},
    outputs={name: p.digest(OUT/name) for name in ('comparison.json', 'mechanism_evidence.json')},
    source_refs=[dict(path=str(path), sha256=p.digest(path)) for path in sources],
    resources=resources(), scope=identity, preflight=gate)
save(OUT/'manifest.json', manifest)
save(RAW/'analysis_receipt.json', dict(passed=True, manifest_sha256=p.digest(OUT/'manifest.json'),
     identity=identity, resources=resources(), new_gpu_runs=0))
print(json.dumps(dict(passed=True, tests=result.testsRun,
    sensitivity=view['fixed_configuration_sensitivity'], resources=resources())))
