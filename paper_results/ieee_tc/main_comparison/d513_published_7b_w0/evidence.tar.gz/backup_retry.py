"""Reuse D512 explicit tested checkpoint workflow for D513; no serving changes."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/main_comparison/d513_published_7b_w0'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
def save(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2, allow_nan=False)
def read(path): return json.loads(path.read_text())
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

identity = p.scope_identity(p.cg_path().name)
save(RAW/'backup_retry_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
assert git('rev-parse', 'HEAD') == 'e8b88dca93bece05e7749eb0f8218fb61ce75db5'
assert git('branch', '--show-current') == 'retry14_continuous_queue_v2'
assert not git('diff', '--cached', '--name-only')
assert not git('diff', 'db44e8f068eb30c69466f32ad3d147ffbc45f9e2', '--', 'faaslora', 'scripts/run_all_experiments.py')
manifest = read(OUT/'manifest.json')
assert manifest['passed'] and manifest['tests'] == 101 and manifest['new_gpu_runs'] == 0
for name, digest in manifest['outputs'].items(): assert p.digest(OUT/name) == digest, name
for ref in manifest['source_refs']: assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
for path, digest in manifest['preserved'].items(): assert p.digest(Path(path)) == digest, path
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
closure = read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
with (RAW/'preflight_tests_retry.log').open('x') as stream:
    completed = subprocess.run(['/usr/bin/python3', '-B', '-m', 'unittest',
        'tests.test_ieee_tc_preflight', '-q'], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
match = re.search(r'Ran (\d+) tests in [\d.]+s\s+OK', (RAW/'preflight_tests_retry.log').read_text())
save(RAW/'preflight_tests_retry_receipt.json', dict(passed=completed.returncode == 0,
    count=int(match[1]) if match else None, interpreter='/usr/bin/python3'))
assert completed.returncode == 0 and match
test_count = int(match[1])
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not token or token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}', data)
archive = OUT/'evidence.tar.gz'
members = {}
with archive.open('xb') as dest:
    with tarfile.open(fileobj=dest, mode='w:gz') as tar:
        for name in ('analyze.py', 'close.py', 'close_retry.py', 'backup.py', 'backup_retry.py', 'analysis_identity.json',
                'analysis_receipt.json', 'analysis_closure.json', 'tests1.log',
                'tests1_receipt.json', 'preflight_tests.log', 'preflight_tests_receipt.json',
                'backup_closure.json', 'preflight_tests_retry.log', 'preflight_tests_retry_receipt.json'):
            path = RAW/name
            data = path.read_bytes()
            assert len(data) < 2*1024*1024
            clean(data)
            members[name] = dict(path=str(path), sha256=hashlib.sha256(data).hexdigest())
            tar.add(path, arcname=name, recursive=False)
for _ in range(2):
    with tarfile.open(archive, 'r:gz') as tar:
        assert set(tar.getnames()) == set(members)
        for name, ref in members.items():
            data = tar.extractfile(name).read()
            assert hashlib.sha256(data).hexdigest() == ref['sha256']
            clean(data)
save(OUT/'delivery.json', dict(passed=True, archive_sha256=p.digest(archive),
    archive_bytes=archive.stat().st_size, archive_members=members,
    analysis_manifest_sha256=p.digest(OUT/'manifest.json'), preflight_tests=test_count,
    source_head=git('rev-parse','HEAD'), no_new_gpu_runs=True))
paths = ['AGENTS.md', 'docs/ieee_tc/BASELINE_SCOPE_20261014.md',
    'docs/ieee_tc/SLO_BUDGET_RATIONALE_20261014.md',
    'docs/ieee_tc/BASELINE_PUBLICATION_REGISTRY_20261014.json',
    'docs/ieee_tc/BASELINE_PUBLICATIONS_AND_OPTIMALITY_20261014.md',
    'docs/ieee_tc/D513_PUBLISHED_BASELINE_AND_THRESHOLD_RESULT.md',
    'docs/ieee_tc/EXECUTION_STATUS.md', 'docs/ieee_tc/PLAN_APPROVED_20261014_PUBLISHED_BASELINES.md',
    'scripts/ieee_tc/check_d299_full_context.py', 'scripts/ieee_tc_preflight.py',
    'tests/test_ieee_tc_published_baseline_view.py', 'tests/test_ieee_tc_preflight.py',
    'docs/ieee_tc/CONTRIBUTION_METRIC_MAP_20261014.md']
paths += [str((OUT/name).relative_to(ROOT)) for name in
          ('comparison.json','mechanism_evidence.json','manifest.json','evidence.tar.gz','delivery.json')]
for name in paths:
    data = (ROOT/name).read_bytes()
    assert len(data) < 2*1024*1024
    if not name.endswith('.tar.gz'): clean(data)
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=ROOT, check=True)
assert set(git('diff','--cached','--name-only').splitlines()) == set(paths)
assert not any('lora_manifest_1000.json' in name for name in paths)
for name in paths:
    data = subprocess.check_output(['git','show',':'+name], cwd=ROOT)
    assert hashlib.sha256(data).hexdigest() == p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'], cwd=ROOT, check=True)
save(RAW/'retry_staged_check.json', dict(passed=True, files={name:p.digest(ROOT/name) for name in paths}))
subprocess.run(['git','commit','-m','tc: separate published baselines and document SLO budget sensitivity (D513)'], cwd=ROOT, check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'], cwd=ROOT, check=True)
head = git('rev-parse','HEAD')
remote = git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head == remote
receipt = dict(passed=True, head=head, remote=remote, scope=identity, files=paths,
    tests=101, preflight_tests=test_count, manifest_sha256=p.digest(OUT/'manifest.json'))
save(RAW/'backup_retry_receipt.json', receipt)
print(json.dumps(receipt))
