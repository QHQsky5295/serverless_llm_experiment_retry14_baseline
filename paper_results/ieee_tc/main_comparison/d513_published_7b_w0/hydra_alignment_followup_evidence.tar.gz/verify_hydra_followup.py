"""Reuse D513 bounded source/test/explicit-backup workflow; no serving run."""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import unittest

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/main_comparison/d513_published_7b_w0'
DOC = ROOT/'docs/ieee_tc/D513_HYDRASERVE_ALIGNMENT_FOLLOWUP.md'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.check_d299_full_context import published_w0_view

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')
def read(path): return json.loads(path.read_text())
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

identity = p.scope_identity(p.cg_path().name)
save(RAW/'hydra_followup_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
assert git('rev-parse','HEAD') == '7502bcfaecc298ad5d867d840d2e86c499e15e9d'
assert git('branch','--show-current') == 'retry14_continuous_queue_v2'
assert not git('diff','--cached','--name-only')
assert not git('diff','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([ROOT], 1_048_576)
assert gate['preflight_pass'], gate['issues']
manifest = read(OUT/'manifest.json')
preserved = dict(manifest['preserved'])
preserved.update({str(OUT/name): digest for name,digest in manifest['outputs'].items()})
frozen_path = ROOT/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json'
preserved[str(frozen_path)] = '2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3'
hydra_path = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d510_20261013/full_w0_evaluation.json')
preserved[str(hydra_path)] = 'c96cb9ba4a0a0be8bf89e4ad82c665033d3d56400b5bb858985f511ebf143b2e'
for path, digest in preserved.items(): assert p.digest(Path(path)) == digest, path
seal = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')
assert p.verify_seal(seal)['pass']
frozen = read(frozen_path)
calibration = frozen['calibration']
for path_key, hash_key in [('path','sha256'), ('audit_path','audit_sha256')]:
    path = ROOT/calibration[path_key]
    assert p.digest(path) == calibration[hash_key]
    preserved[str(path)] = calibration[hash_key]
warm = read(ROOT/calibration['path'])
audit = read(ROOT/calibration['audit_path'])
assert audit['passed'] and audit['measured'] == warm['measurement_requests'] == 1536
assert warm['batch_size'] == 8 and warm['measurement_rounds'] == 3
assert warm['contract']['prefix_caching'] is False and warm['contract']['native_pass'] == 1536
assert frozen['thresholds_common_to_all_systems'] and frozen['minimum_joint_count'] == 3800
text = DOC.read_text()
thresholds = []
for measured, fixed in zip(warm['groups'], frozen['groups'], strict=True):
    values = []
    for metric, multiplier in [('ttft',5),('tpot',2)]:
        mean = sum(row[metric] for row in measured['round_means_ms']) / 3
        assert math.isclose(mean, measured['equal_weight_mean_ms'][metric], rel_tol=1e-14)
        threshold = mean * multiplier
        assert math.isclose(threshold, fixed[metric+'_ms'], rel_tol=1e-14)
        assert f'{mean:.6f}' in text and f'{threshold:.6f}' in text
        values.append({'metric':metric,'warm_ms':mean,'threshold_ms':threshold,'multiplier':multiplier})
    thresholds.append(values)
view = read(OUT/'comparison.json')
original = read(ROOT/'paper_results/ieee_tc/main_comparison/d510_7b_w0/comparison.json')
registry = read(ROOT/'docs/ieee_tc/BASELINE_PUBLICATION_REGISTRY_20261014.json')
recomputed, _ = published_w0_view(original, registry)
assert recomputed['results'] == view['results']
assert set(view['results']) == {'PrimeLoRA','ServerlessLLM','vLLM','S-LoRA','Loquetier','HydraServe'}
hydra = read(hydra_path)
assert hydra['full_audit_pass'] and hydra['tpot_conditional_denominator'] == 4000
table = []
for name, row in view['results'].items():
    counts = row['counts']
    n = counts['N'] if 'N' in counts else counts['n']
    assert n == 4000 and row['raw_n_correct'] is None and not row['independent_numerical_proof']
    tpot_metric = row['metrics']['tpot_ms']
    assert (tpot_metric['n'] if 'n' in tpot_metric else tpot_metric['count']) == n
    if name == 'HydraServe':
        at, ap = hydra['ttft_attainment'], hydra['tpot_conditional_attainment']
        assert row['physical_gpu_seconds'] == hydra['physical_gpu_seconds']
        assert counts['joint_pass'] == hydra['n_joint']
    else:
        at, ap = counts['ttft_pass']/n, counts['tpot_pass']/n
    joint = counts['joint_pass']/n
    assert joint == row['joint_slo'] and joint <= min(at, ap)
    resource = row['physical_gpu_seconds']/n
    assert math.isclose(resource,row['gpu_seconds_per_protocol_valid_request'],rel_tol=1e-14)
    p95 = row['metrics']['ttft_ms']['p95_type1']/1000
    line = f'| {name} | {100*at:.3f} | {100*ap:.3f} | {100*joint:.3f} | {resource:.6f} | {p95:.6f} |'
    assert line in text, line
    table.append(dict(system=name,native_contract_count=n,ttft_attainment=at,
        tpot_attainment=ap,tpot_denominator=n,joint_attainment=joint,
        gpu_s_per_native_contract_request=resource,p95_ttft_s=p95,raw_n_correct=None))
prime = view['results']['PrimeLoRA']
deltas = {}
for name in ('ServerlessLLM','vLLM'):
    baseline = view['results'][name]
    reduction = 100*(baseline['physical_gpu_seconds']-prime['physical_gpu_seconds'])/baseline['physical_gpu_seconds']
    difference = 100*(prime['joint_slo']-baseline['joint_slo'])
    assert f'{reduction:.4f}%' in text and f'{abs(difference):.3f}' in text
    deltas[name] = dict(resource_reduction_percent=reduction,joint_difference_pp=difference)
with (RAW/'hydra_followup_tests.log').open('x') as stream:
    tests = unittest.TextTestRunner(stream=stream,verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromName('tests.test_ieee_tc_published_baseline_view'))
assert tests.wasSuccessful() and tests.testsRun == 9 and not tests.skipped
assert p.verify_seal(seal)['pass']
for path, digest in preserved.items(): assert p.digest(Path(path)) == digest, path
report = dict(passed=True,kind='d513_hydraserve_alignment_followup',new_gpu_runs=0,
    metric_changes=False,online_changes=False,whole_goal_complete=False,
    source_refs=preserved,doc_sha256=p.digest(DOC),thresholds=thresholds,table=table,
    deltas=deltas,tests=9,protected_entries=147,scope=identity,
    verification_scope='sealed small-file references, arithmetic and report mapping; not a repeated raw audit or numerical proof',
    preflight=gate)
save(OUT/'hydra_alignment_followup.json',report)
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not token or token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
archive = OUT/'hydra_alignment_followup_evidence.tar.gz'
members = {}
with archive.open('xb') as dest:
    with tarfile.open(fileobj=dest,mode='w:gz') as tar:
        for path in (Path(__file__),RAW/'close_hydra_followup.py',RAW/'hydra_followup_tests.log',RAW/'hydra_followup_identity.json'):
            data = path.read_bytes()
            clean(data)
            members[path.name] = hashlib.sha256(data).hexdigest()
            tar.add(path,arcname=path.name,recursive=False)
for _ in range(2):
    with tarfile.open(archive,'r:gz') as tar:
        assert set(tar.getnames()) == set(members)
        for name,digest in members.items():
            data = tar.extractfile(name).read()
            assert hashlib.sha256(data).hexdigest() == digest
            clean(data)
save(OUT/'hydra_alignment_followup_delivery.json',dict(passed=True,
    archive_sha256=p.digest(archive),members=members,report_sha256=p.digest(OUT/'hydra_alignment_followup.json')))
paths = ['docs/ieee_tc/EXECUTION_STATUS.md',str(DOC.relative_to(ROOT))]
paths += [str((OUT/name).relative_to(ROOT)) for name in ('hydra_alignment_followup.json',
    'hydra_alignment_followup_evidence.tar.gz','hydra_alignment_followup_delivery.json')]
for name in paths:
    data = (ROOT/name).read_bytes()
    assert len(data) < 2*1024*1024
    if not name.endswith('.tar.gz'): clean(data)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines()) == set(paths)
assert not any('lora_manifest_1000' in name for name in paths)
for name in paths:
    staged = subprocess.check_output(['git','show',':'+name],cwd=ROOT)
    assert hashlib.sha256(staged).hexdigest() == p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','docs: clarify HydraServe 5/2 SLO alignment with verified W0 data'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head = git('rev-parse','HEAD')
remote = git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]
assert head == remote
save(RAW/'hydra_followup_backup_receipt.json',dict(passed=True,head=head,remote=remote,
    files=paths,scope=identity,report_sha256=p.digest(OUT/'hydra_alignment_followup.json')))
print(json.dumps(dict(passed=True,head=head,tests=9,table=table)))
