"""Reuse D537 native qualification and D553 W2; verify only new input wiring."""
import ast
import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d537_20261015'
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
import prepare_ieee_tc_serverless_stack as s

def save(path,value):
    with path.open('x') as out:json.dump(value,out,indent=2,allow_nan=False)
def read(path):return json.loads(path.read_text())
def nodes(text):
    return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(text).body
            if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}

def main():
    identity=p.scope_identity(p.cg_path().name)
    save(RAW/'qualification_identity.json',identity)
    group=Path(identity['path'])
    assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
    assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
    assert (group/'memory.swap.max').read_text().strip()=='0'
    assert os.sched_getaffinity(0)=={2,3,26,27}
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    gate=p.preflight([MAIN],32*p.GIB)
    assert gate['preflight_pass'],gate['issues']
    assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
    assert not Path('/tmp/tc-d555-7br').exists()

    q537=read(OLD/'qualification.json')
    assert q537['passed'] and q537['tests']==114
    q553path=RAW.parent.parent/'main_comparison/d553_20261015/qualification_final.json'
    assert p.digest(q553path)=='1e5f62dac7b1cb9e94f9b37a8b56e232a58069ac47513e36441751921a5fdeb1'
    q553=read(q553path)
    assert q553['passed'] and q553['tests']==386 and q553['requests']==4000
    q554path=RAW.parent.parent/'p2_backend_qualification/d554_20261015/qualification.json'
    q554=read(q554path)
    assert q554['passed'] and q554['reused_input_tests']==386 and q554['new_tests']==4
    # D554's tested wrapper delta updates one test SHA; no serving change since it.
    for path,sha in q554['refs'].items():assert p.digest(Path(path))==sha,path

    cfg=read(RAW/'http_7b_4000.json');old=read(OLD/'http_7b_4000.json')
    expected=dict(old,trace=q553['http_plan']['source_path'],request_view='trace_w2_v1',
        replay_profile='W2',adapter_map=q553['http_plan']['adapter_map'],
        adapter_map_sha256=q553['http_plan']['adapter_map_sha256'])
    assert cfg==expected
    s.validate_http_lifecycle_contract(cfg)
    plan=s.load_http_replay_plan(cfg,trace=cfg['trace'])
    assert plan.identity()==q553['http_plan']
    rows=[json.loads(e.source_json) for e in plan.entries]
    assert len(rows)==4000 and len({r['adapter_id'] for r in rows})==497
    assert sum(min(r['expected_output_tokens'],256) for r in rows)==458224
    assert p.digest(Path(cfg['pool_index']))==cfg['pool_index_sha256']
    checks=['full_W2_identity_and_population','service_publisher_same_trace']
    for label,delta in [('missing_map',{'adapter_map':None}),
                        ('wrong_map_sha',{'adapter_map_sha256':'0'*64}),
                        ('wrong_profile',{'replay_profile':'W1'}),
                        ('partial_W2',{'request_count':100})]:
        bad=copy.deepcopy(cfg);bad.update(delta)
        try:s.load_http_replay_plan(bad)
        except (ValueError,TypeError):checks.append(label+'_rejected')
        else:raise AssertionError(label+' accepted')

    commit='bde215460acb9e850efa479a89bda6fc39a2bd7d'
    unchanged={}
    for relative,allowed in {
        'scripts/prepare_ieee_tc_serverless_stack.py':{'qualified_http_population','load_http_replay_plan'},
        'scripts/ieee_tc_serverless_measurement.py':set(),
    }.items():
        before=nodes(subprocess.check_output(['git','show',commit+':'+relative],cwd=BASE,text=True))
        after=nodes((BASE/relative).read_text())
        assert before.keys()==after.keys(),relative
        changed={name for name in before if before[name]!=after[name]}
        assert changed==allowed,(relative,changed)
        unchanged[relative]=sorted(before.keys()-allowed)
    assert p.digest(BASE/'scripts/ieee_tc_serverless_measurement.py')==q537['refs'][str(BASE/'scripts/ieee_tc_serverless_measurement.py')]
    view=s.prepare_measurement_view(BASE/'vendor_new_baselines/ServerlessLLM_new_main_20260518',
        RAW/'source_repaired','repaired',MAIN,'request_identity_v1')
    oldview=read(OLD/'source_repaired/measurement_manifest.json')
    for key in ('original_sha256','measured_sha256','shared_source_sha256'):
        assert view[key]==oldview[key],key
    # Runner policy is byte-identical after explicit campaign/input substitutions.
    before=(OLD/'run7b_repaired.sh').read_text().replace('d537','d555')
    before='\n'.join('TRACE='+cfg['trace'] if line.startswith('TRACE=') else line
                     for line in before.splitlines())+'\n'
    assert (RAW/'run7b_repaired.sh').read_text()==before
    installer=Path('/home/qhq/relayserve_serverless_llm/scripts/relayserve_v4_3_apply_serverlessllm_vllm_store_overlay.py')
    assert p.digest(installer)=='da6a14276f92186457c44c215d45d1ca9d18f7bbea9cdec6665737743f9c5978'
    spec=importlib.util.spec_from_file_location('d555_loader',installer)
    loader=importlib.util.module_from_spec(spec);spec.loader.exec_module(loader)
    _,overlay=loader.build_overlay(loader.DEFAULT_VLLM_ROOT,loader.DEFAULT_OFFICIAL_PATCH)
    assert overlay['members']==read(OLD/'overlay_preflight.json')['members']
    save(RAW/'overlay_preflight.json',overlay)
    checkpoint=BASE/'models/vllm/tc-native-llama2-7b-fp16-20260927/rank_0/tensor.data_0'
    assert checkpoint.is_file()
    cache=Path(read(OLD/'native_compile_cache_before.json')['root'])
    entries=[]
    for path in sorted(cache.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            entries.append([str(path.relative_to(cache)),path.stat().st_size,p.digest(path)])
    assert entries
    save(RAW/'native_compile_cache_before.json',dict(root=str(cache),entries=entries,
        files=len(entries),bytes=sum(x[1] for x in entries),
        policy='retained disk compilation cache, no GPU/HOST/KV prewarm; all startup charged',
        whole_lower_level_cache_identity_proved=False))
    for path in [*RAW.glob('*.py'),*RAW.glob('*.sh')]:
        if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
        else:subprocess.run(['bash','-n',str(path)],check=True)
    preserved={
        str(MAIN/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
        str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
        str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
    for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
    refs=[Path(s.__file__),BASE/'scripts/ieee_tc_serverless_measurement.py',
        MAIN/'faaslora/datasets/workload_generator.py',MAIN/'scripts/ieee_tc_preflight.py',
        MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',installer,
        Path(cfg['trace']),Path(cfg['pool_index']),Path(cfg['adapter_map']),RAW/'http_7b_4000.json',
        RAW/'source_repaired/measurement_manifest.json',RAW/'overlay_preflight.json',
        RAW/'native_compile_cache_before.json',OLD/'qualification.json',q553path,q554path,
        *RAW.glob('*.py'),*RAW.glob('*.sh')]
    save(RAW/'qualification.json',dict(passed=True,scope=identity,gate=gate,
        reused_native_tests=114,reused_w2_tests=386,new_input_checks=checks,
        preserved_native_nodes=unchanged,preserved_native_source=view,plan=plan.identity(),
        actual_unique_adapters=497,target_tokens=458224,checkpoint_reused=str(checkpoint),
        changes=['trace_path_same_SHA','request_view','replay_profile','adapter_map','adapter_map_sha256'],
        numerical_correctness_qualified=False,no_performance_run=True,no_policy_change=True,
        refs={str(x):p.digest(x) for x in refs},preserved=preserved))
    print(json.dumps(dict(passed=True,reused_native_tests=114,reused_w2_tests=386,
        new_input_checks=len(checks),plan=plan.identity())),flush=True)

if __name__=='__main__':main()
