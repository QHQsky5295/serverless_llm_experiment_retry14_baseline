"""Reuse D537/D554 streaming input witnesses for this closed W2 observation."""
import ijson
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
PRIME = RAW.parent.parent/'p2_backend_qualification/d554_20261015'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

def read(path): return json.loads(path.read_text())
def save(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2, allow_nan=False)

def requests(path):
    with path.open('rb') as stream:
        names = []
        for prefix, event, value in ijson.parse(stream, use_float=True):
            if prefix == 'detailed_results' and event == 'map_key':
                names.append(value)
                break
    assert len(names) == 1
    with path.open('rb') as stream:
        yield from ijson.items(stream, 'detailed_results.'+names[0]+'.requests.item', use_float=True)

scope = p.scope_identity(p.cg_path().name)
save(RAW/'cross_identity.json', scope)
group = Path(scope['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
closed = read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
current = read(RAW/'audit_full4000_w2.json')
prime_path = PRIME/'cross_contract.json'
prime = read(prime_path)
assert prime['passed'] and prime['request_count'] == 4000
assert current['source_plan'] == prime['source_plan']
assert current['source_plan']['profile'] == 'W2'
for ref in prime['refs']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
context = read(RAW/'launch7b_repaired.launch/exec_receipt.json')['external_replay']
plan = FrozenReplayPlan.from_launch_context(context)
assert plan.identity() == current['source_plan']
entries = {entry.request_id:entry for entry in plan.entries}
replay = RAW/'launch7b_repaired.launch/replay.jsonl'
contracts = {}
for line in replay.open():
    row = json.loads(line)
    if row['event'] == 'request_contract':
        assert row['request_id'] not in contracts
        contracts[row['request_id']] = row
assert contracts.keys() == entries.keys() and len(contracts) == 4000
sources = list((PRIME/'7b_initial_control_full_w2').glob('experiment_results*.json'))
assert len(sources) == 1
seen = set()
for row in requests(sources[0]):
    rid = row['request_id']
    assert rid not in seen
    seen.add(rid)
    ref, entry = contracts[rid], entries[rid]
    assert row['adapter_id'] == ref['adapter_id'] == json.loads(entry.source_json)['adapter_id']
    assert row['requested_completion_tokens'] == row['completion_tokens'] == ref['target_tokens']
    assert row['canonical_prompt_sha256'] == ref['canonical_prompt_sha256']
    assert row['canonical_prompt_tokens'] == ref['canonical_prompt_tokens']
    assert row['native_token_timing']['native_prompt_token_ids_sha256'] == ref['native_prompt_token_ids_sha256']
    assert abs(row['scheduled_arrival_offset_s'] - entry.offset_s) <= 1e-9
    assert row['generation_contract'] == 'fixed_length_greedy_v1' and row['output_contract_match'] is True
assert seen == contracts.keys()
comparison = dict(
    PrimeLoRA=dict(joint=prime['observation']['joint_rate'], gpu_seconds=prime['observation']['gpu_seconds'], p95_ttft_ms=prime['observation']['p95_ttft_ms']),
    ServerlessLLM=dict(joint=current['common_slo']['joint_attainment'], gpu_seconds=current['physical_gpu_seconds'], p95_ttft_ms=current['conditional_metrics']['ttft_ms']['p95_type1']))
x, y = comparison['PrimeLoRA'], comparison['ServerlessLLM']
changes = dict(lower_better_change_percent={key:100*(y[key]-x[key])/y[key] for key in ('gpu_seconds','p95_ttft_ms')}, joint_difference_pp=100*(x['joint']-y['joint']))
save(RAW/'cross_contract.json', dict(passed=True, schema='d555_w2_input_witness_v1', scope=scope,
    request_count=4000, compared_fields=['request_id','adapter_id','target_tokens','canonical_prompt_sha256','canonical_prompt_tokens','native_prompt_token_ids_sha256','scheduled_arrival_offset_s'],
    source_plan=current['source_plan'], comparison=comparison, changes=changes,
    reference_frozen=False, independent_numerical_correctness='unknown', input_join_only=True,
    initial_state_contract_identical=False,
    limitations=['Single known-workload observations; no repeated-run inference.',
        'Native versions and compilation histories differ; input identity is not numerical proof.',
        'PrimeLoRA W2 is below 95%; no G1/G2 closure or global optimum claim.'],
    refs=[dict(path=str(path),sha256=p.digest(path)) for path in (replay,sources[0],prime_path,RAW/'audit_full4000_w2.json',Path(__file__))]))
markers = ('Starting instance ', 'Using cache directory:', 'torch.compile takes', 'torch.compile took',
    'init engine (', 'Model loading took', 'Directly load AOT compilation', 'Loading compiled graph',
    'Dynamo bytecode transform time:', 'instance is ready')
log = RAW/'model7b_repaired/serve.log'
rows = [dict(line=i,text=re.sub(r'\x1b\[[0-9;]*m','',line.rstrip()))
        for i,line in enumerate(log.open(errors='replace'),1) if any(marker in line for marker in markers)]
qual = read(RAW/'model7b_repaired/model_qualification.json')
save(RAW/'startup_diagnostic.json',dict(scope=scope,log_evidence=rows,
    startup_events=[json.loads(line) for line in (RAW/'model7b_repaired/startup_events.jsonl').open()],
    backend_ready_receipts=qual['backend_ready_receipts'], counts=dict(native_ready_receipts=current['backend_ready_receipts']),
    source_order_joint=[row['common_slo']['joint_good'] for row in current['source_order_diagnostics']],
    queue_mean_fraction_of_ttft=current['conditional_metrics']['router_queue_ms']['mean']/current['conditional_metrics']['ttft_ms']['mean'],
    causal_attribution_complete=False,refs=[dict(path=str(path),sha256=p.digest(path)) for path in (log,RAW/'model7b_repaired/startup_events.jsonl')]))
print(json.dumps(dict(passed=True,comparison=comparison,changes=changes,scope=scope)))
