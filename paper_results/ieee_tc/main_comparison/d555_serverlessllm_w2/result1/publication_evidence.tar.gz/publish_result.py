"""Reuse exact-path Git/archive guard; publish outcome including evidence gaps."""
import ast, hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d555_serverlessllm_w2/result1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'result_publication_identity.json',identity)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0' and os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
record=read(OUT/'manifest.json');audit=read(OUT/'audit.json')
assert record['passed'] and record['reference_frozen'] is False
assert audit['measurement_complete'] and audit['native_revalidated_requests']==4000
assert 0<=audit['common_slo']['joint_good']<=4000 and audit['n_correct'] is None
assert record['reused_tests']['count']==114
assert p.digest(Path(record['reused_tests']['path']))==record['reused_tests']['sha256']
for ref in record['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256']
for path,sha in record['preserved'].items():assert p.digest(Path(path))==sha
for name,sha in record['outputs'].items():assert p.digest(OUT/name)==sha
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames())==set(record['archive_members'])
    for name,ref in record['archive_members'].items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==ref['sha256']
for name in ('analysis','cross','result'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='0e2f41fdde9748e8ec30227e422637423f756752'
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
members=[RAW/name for name in ('publish_result.py','result_closure.json','analysis_closure.json',
    'remote_health.json','evidence_copy_receipt.json','remote_stop.log','cross_closure.json','close.py')]
archive=OUT/'publication_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in members:
        data=path.read_bytes();check(data)
        assert len(data)<8*1024*1024
        if path.suffix=='.py':ast.parse(data)
        bundle.add(path,arcname=path.name,recursive=False)
with tarfile.open(archive) as bundle:
    for path in members:assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest()==p.digest(path)
with (OUT/'result.sha256').open('x') as f:
    for name in ('audit.json','cross_contract.json','startup_diagnostic.json','manifest.json','evidence.tar.gz','publication_evidence.tar.gz'):
        f.write(p.digest(OUT/name)+'  '+name+'\n')
names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D555_SERVERLESSLLM_W2_RESULT.md']
names += [str((OUT/name).relative_to(ROOT)) for name in ('audit.json','cross_contract.json','startup_diagnostic.json','manifest.json','evidence.tar.gz','publication_evidence.tar.gz','result.sha256')]
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).strip()
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True,stdout=subprocess.DEVNULL)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
for name in names:check((ROOT/name).read_bytes())
subprocess.run(['git','add','--',*names],cwd=ROOT,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
assert set(staged)==set(names) and 'configs/generated/lora_manifest_1000.json' not in staged
for name in staged:assert subprocess.check_output(['git','show',':'+name],cwd=ROOT)==(ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: seal ServerlessLLM W2 result and pause for RelayServe migration (D555)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
remote=subprocess.check_output(['git','ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2'],cwd=ROOT,text=True).split()[0]
assert head==remote
save(RAW/'result_publication_receipt.json',dict(passed=True,head=head,remote=remote,files=names,identity=identity,protected=protected))
print(json.dumps(dict(passed=True,head=head,files=len(names),remote_equal=True)),flush=True)

