"""Qualify and package the retained D511 analysis without copying raw datasets."""
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d511_resource_gap'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'curation_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
summary=read(RAW/'summary.json')
assert summary['passed'] and summary['current']['count']==4000 and summary['max_identity_error_ms']==0
for ref in summary['source_refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
tests=('tests.test_ieee_tc_control_timeline','tests.test_ieee_tc_decode_overlap',
       'tests.test_ieee_tc_core_timing','tests.test_ieee_tc_core_timing_analysis')
with (RAW/'tests.log').open('x') as stream:
    proc=subprocess.run([sys.executable,'-B','-m','unittest',*tests,'-q'],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
proc.check_returncode()
match=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK',(RAW/'tests.log').read_text())
assert match and int(match[1])>100
preserved={str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
           str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
           str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
subprocess.run(['git','diff','--exit-code','db44e8f068eb30c69466f32ad3d147ffbc45f9e2','--',
                'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=ROOT,check=True)
OUT.mkdir(parents=True,exist_ok=False)
files=[RAW/name for name in ('analyze.py','close.py','curate.py','analysis_identity.json',
       'analysis_closure.json','requests.jsonl','controls.jsonl','tests.log')]
files += [ROOT/'scripts/analyze_control_path_overhead.py',ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',
          ROOT/'scripts/ieee_tc/check_d299_full_context.py']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
members={}
archive=OUT/'evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes()
        assert len(data)<32*1024*1024
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
        name=f'{i:02d}_{path.name}'
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o600;member.mtime=0
        tar.addfile(member,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
assert archive.stat().st_size<2*1024*1024
with (OUT/'summary.json').open('xb') as stream:stream.write((RAW/'summary.json').read_bytes())
test_sources={str(ROOT/(module.replace('.','/')+'.py')):p.digest(ROOT/(module.replace('.','/')+'.py')) for module in tests}
save(OUT/'manifest.json',dict(passed=True,scope=identity,new_gpu_run=False,production_changed=False,
     tests=dict(count=int(match[1]),seconds=float(match[2]),sources=test_sources),protected=protected,
     preserved=preserved,source_refs=summary['source_refs'],archive_members=members,
     outputs={name:p.digest(OUT/name) for name in ('summary.json','evidence.tar.gz')}))
print(json.dumps(dict(passed=True,tests=int(match[1]),archive_bytes=archive.stat().st_size,scope=identity)))
