"""D511 retained D476 analysis; reuse D473 stages and D454 control projection.

No performance replay, policy simulation, or mutation of sealed measurements.
"""
import gzip
import hashlib
import json
import math
import os
import subprocess
import sys
from collections import Counter
from pathlib import Path
from statistics import fmean

import ijson
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from scripts.analyze_control_path_overhead import partition_retained_request_stages
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats
from scripts.ieee_tc.check_d299_full_context import closed_physical_integral
from faaslora.datasets.workload_generator import FrozenReplayPlan

def read(path):
    return json.loads(path.read_text())

def save(name, value):
    with (RAW / name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save('analysis_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*1024**3)
assert (group/'memory.max').read_text().strip() == str(4*1024**3)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
refs = []

def checked(path, expected=None):
    path = Path(path)
    digest = p.digest(path)
    assert expected is None or digest == expected, path
    refs.append(dict(path=str(path), sha256=digest))
    return path

comparison = read(checked(ROOT/'paper_results/ieee_tc/p2_backend/d476_full_w0/matched_comparison.json'))
pinned = {r['path']: r['sha256'] for r in comparison['refs']}
sources = [Path(path) for path in pinned if 'd476_20261012/7b_full_w0/experiment_results' in path]
assert len(sources) == 1
source = checked(sources[0], '450631019b24007939276f211683893e80ff938c48b4fad4024bd70ef9f75bd1')
run = source.parent
launch = read(checked(run/'launch.json', pinned[str(run/'launch.json')]))
plan = FrozenReplayPlan.load(launch['external_replay']['plan']['source_path'])
assert plan.identity() == launch['external_replay']['plan']
start = launch['external_replay']['replay_t0_s']
clock = launch['external_replay']['clock_id']
order = {e.request_id: i for i, e in enumerate(plan.entries)}
rows = []
with source.open('rb') as stream:
    for request in ijson.items(stream, 'detailed_results.tc_ieee_full.requests.item', use_float=True):
        row = partition_retained_request_stages(request, arrival_start_s=start, clock_id=clock)
        evidence = request['gpu_reference_evidence']
        receipt = evidence['receipt']
        row.update(source_order=order[request['request_id']], phase=order[request['request_id']]//500,
                   adapter_id=request['adapter_id'], instance_id=request['instance_id'],
                   dispatch_tier=request['readiness_tier_before_dispatch'],
                   native_load_invoked=receipt['native_load_invoked'],
                   prior_routing_attempts=len(evidence['prior_routing_attempts']),
                   nested_ms={**{k: request[k] for k in ('lora_io_ms','dispatch_admission_wait_ms',
                              'service_ttft_ms','parent_rpc_overhead_ms')},
                              'native_load_and_acquire_ms': receipt['load_and_acquire_ms'],
                              'routing_ms': row['nested_routing_ms']})
        rows.append(row)
assert len(rows) == len({r['request_id'] for r in rows}) == 4000
rows.sort(key=lambda r: r['source_order'])
assert [r['request_id'] for r in rows] == [e.request_id for e in plan.entries]

def summarize(rs):
    return dict(count=len(rs),
                stages_ms={k: timing_stats([r['stages_ms'][k] for r in rs]) for k in rs[0]['stages_ms']},
                nested_ms={k: timing_stats([r['nested_ms'][k] for r in rs]) for k in rs[0]['nested_ms']},
                ttft_ms=timing_stats([r['ttft_ms'] for r in rs]),
                e2e_ms=timing_stats([r['e2e_ms'] for r in rs]))

current = summarize(rows)
for metric in ('ttft_ms','e2e_ms'):
    for stat in ('mean','p95_type1'):
        assert abs(current[metric][stat]-comparison['candidate']['metrics'][metric][stat]) < 1e-6
assert abs(math.fsum(s['mean'] for s in current['stages_ms'].values())-current['e2e_ms']['mean']) < 1e-6
old_stage = read(checked(ROOT/'paper_results/ieee_tc/main_comparison/d473_residual/stages.json'))
previous = {**old_stage['previous'], 'PrimeLoRA_D472': old_stage['current']}
physical = read(checked(run/'launch.launch/physical_deployment/summary.json',
                        pinned[str(run/'launch.launch/physical_deployment/summary.json')]))
total = closed_physical_integral(physical)
assert total == comparison['candidate']['physical_gpu_seconds']
config_path = ROOT/'configs/ieee_tc/20261012_d476_7b_full_w0.yaml'
cfg = yaml.safe_load(checked(config_path, pinned[str(config_path)]).read_text())['resource_coordination']['ieee_scaling']
old_control = read(checked(ROOT/'paper_results/ieee_tc/main_comparison/d454_7b_w0/control_diagnosis.json'))
assert cfg == old_control['controller_settings']
compression = read(checked(run/'compression_receipt.json'))
archive = checked(compression['archive'], compression['archive_sha256'])
digest = hashlib.sha256()
with gzip.open(archive, 'rb') as stream:
    for block in iter(lambda: stream.read(1024*1024), b''):
        digest.update(block)
assert digest.hexdigest() == pinned[compression['source']] == compression['source_sha256']
with gzip.open(archive, 'rb') as stream:
    events = list(ijson.items(stream, 'mechanism_events._ieee_control_events.item', use_float=True))
duration = plan.entries[-1].offset_s
end = start + duration
events = [r for r in events if start <= r['observed_at'] <= end]
assert events and all(a['observed_at'] < b['observed_at'] for a,b in zip(events,events[1:]))
reasons = Counter()
for event in events:
    flags = dict(queue_not_low=event['queue_depth'] >= cfg['queue_lower'],
                 active_not_low=event['active_saturation'] >= cfg['active_lower'],
                 ttft_not_low=event['p95_ttft_ms'] is None or event['p95_ttft_ms'] >= cfg['ttft_lower_ms'])
    assert event['all_low'] == (not any(flags.values()))
    if event['ready_instances'] > 1:
        reasons.update(dict(eligible_ready_gt1=1, all_low=int(event['all_low']),
                       pending=int(event['pending_instances']>0), **{k:int(v) for k,v in flags.items()}))
edges = Counter({start:0, end:0})
for intervals in physical['device_intervals'].values():
    for a,b in intervals:
        a,b=max(a,start),min(b,end)
        if a<b:
            edges[a]+=1
            edges[b]-=1
occupancy=Counter()
active=0
stamps=sorted(edges)
for i,t in enumerate(stamps[:-1]):
    active+=edges[t]
    assert 0<=active<=4
    occupancy[active]+=stamps[i+1]-t
assert abs(sum(occupancy.values())-duration)<1e-6
assert abs(sum(k*v for k,v in occupancy.items())-physical['window_gpu_seconds']['arrival'])<1e-6
control=dict(control_samples=len(events),control_actions=dict(Counter(r['action'] for r in events)),
             control_outcomes=dict(Counter(r['outcome'] for r in events)),
             scalein_blocker_sample_counts=dict(reasons),
             sample_means={k:fmean(r[k] for r in events) for k in
                           ('queue_depth','active_requests','active_saturation','ready_instances','pending_instances')},
             physical_gpu_seconds=total,window_gpu_seconds=physical['window_gpu_seconds'],
             arrival_duration_s=duration,arrival_occupancy_wall_seconds=dict(sorted(occupancy.items())),
             arrival_mean_physical_gpus=physical['window_gpu_seconds']['arrival']/duration)
other=old_control['reports']['ElasticLocality']
delta={k:control['window_gpu_seconds'][k]-other['window_gpu_seconds'][k] for k in control['window_gpu_seconds']}
assert abs(sum(delta.values())-(total-other['physical_gpu_seconds']))<1e-6
for name, values in [('requests.jsonl',rows),('controls.jsonl',events)]:
    with (RAW/name).open('x') as stream:
        for row in values:stream.write(json.dumps(row,allow_nan=False)+'\n')
    checked(RAW/name)
for path in (Path(__file__), ROOT/'scripts/analyze_control_path_overhead.py',
             ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',ROOT/'scripts/ieee_tc/check_d299_full_context.py',
             ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
             Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md')):
    checked(path)
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
result=dict(kind='d511_retained_d476_stage_control_v1',passed=True,current=current,previous=previous,
            phases={str(i):summarize([r for r in rows if r['phase']==i]) for i in range(8)},
            control=control,previous_control=old_control['reports'],
            physical_window_delta_vs_ElasticLocality=delta,controller_settings=cfg,
            stage_mean_delta_vs_ElasticLocality={k:v['mean']-previous['ElasticLocality']['stages_ms'][k]['mean']
                                                for k,v in current['stages_ms'].items()},
            max_identity_error_ms=max(r['max_identity_error_ms'] for r in rows),
            source_refs=refs,protected=protected,scope=identity,new_gpu_run=False,
            causal_attribution_established=False,
            caveats=['Stage means add; percentiles and nested spans do not.',
                     'Control sample blockers overlap and are not elapsed time.',
                     'Physical interval union is occupancy, not utilization.',
                     'Closed-loop difference is not isolated causal evidence.'])
save('summary.json',result)
print(json.dumps(dict(passed=True,stage_means={k:v['mean'] for k,v in current['stages_ms'].items()},
                     stage_delta=result['stage_mean_delta_vs_ElasticLocality'],control=control,window_delta=delta),indent=2))
