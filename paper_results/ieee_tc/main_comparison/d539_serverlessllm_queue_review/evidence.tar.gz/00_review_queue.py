"""Reuse existing journal analysis; inspect D537 native epochs, not new inference."""
import ast, collections, json, math, os, re, shutil, subprocess, sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
CURRENT=RAW.parent/'d537_20261015'
OLD=RAW.parent/'d414_20261011'
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from summarize_serverlessllm_replay import audit_tc_http_journal
def read(x):return json.loads(x.read_text())
def save(x,row):
    with x.open('x') as f:json.dump(row,f,indent=2,allow_nan=False)
def stats(xs):
    xs=sorted(xs)
    return dict(n=len(xs),min=min(xs),median=xs[math.ceil(.5*len(xs))-1],p95=xs[math.ceil(.95*len(xs))-1],max=max(xs),mean=sum(xs)/len(xs)) if xs else dict(n=0)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'review_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0' and os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closed=read(CURRENT/'result_publication_closure.json')
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
save(RAW/'sources_before.json',dict(main_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip(),
    baseline_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip(),
    plan_sha=p.check_plan(),slo_sha=p.digest(MAIN/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json')))
results={};refs=[];evidence=RAW/'worker_evidence';evidence.mkdir(exist_ok=False)
for label,root in (('D537_W1',CURRENT),('D414_W0',OLD)):
    replay=root/'launch7b_repaired.launch/replay.jsonl'
    summary=audit_tc_http_journal(replay)
    assert summary['counts']['N_plan']==summary['counts']['N_response']==4000
    rows={r['request_id']:r for r in summary['diagnostic_rows']}
    context=read(root/'launch7b_repaired.launch/exec_receipt.json')['external_replay']
    t0=context['replay_t0_s'];notice=context['deployment_notice_s']
    assert abs(t0-notice-60)<1e-8
    indexed={};epochs={};conditions=collections.defaultdict(list)
    for line in replay.open():
        event=json.loads(line)
        if event['event']=='request_created':indexed[event['request_id']]=event['index']
        if event['event']!='http_raw_response':continue
        m=event['body']['metrics'];o=m['ieee_tc'];c=o['control_observation'];rid=event['request_id']
        receipt=root/'model7b_repaired/worker_receipts'/(c['tc_worker_receipt_id']+'.json')
        assert p.digest(receipt)==c['tc_worker_receipt_sha256']
        r=read(receipt);assert r['clock_id']==o['native_clock_id']==context['clock_id']
        key=m['instance_id']
        epoch=dict(instance=key,receipt=str(receipt),receipt_sha256=p.digest(receipt),pid=r['pid'],
            backend_ready_since_business_s=r['at']-t0,backend_ready_since_notice_s=r['at']-notice,
            created_wall_s=m['instance_created_at'],router_ready_wall_s=m['instance_ready_at'],
            router_created_to_ready_s=m['instance_ready_at']-m['instance_created_at'])
        if key in epochs:
            assert epochs[key]['identity']==epoch
        else:epochs[key]=dict(identity=epoch,request_ids=[])
        epochs[key]['request_ids'].append(rid)
        row=rows[rid]
        row['ready_at_enqueue']=c['ready_instances_at_enqueue']
        row['ingress_wait_ms']=1000*(c['tc_ingress_forwarded_s']-c['tc_ingress_received_s'])
        row['adapter_resolve_ms']=1000*(c['tc_artifact_resolve_completed_s']-c['tc_artifact_resolve_started_s'])
        row['instance']=key
        conditions[c['ready_instances_at_enqueue']].append(row)
    ordered=sorted(rows.values(),key=lambda x:indexed[x['request_id']])
    phase=[]
    for lo in range(0,4000,500):
        part=ordered[lo:lo+500]
        phase.append(dict(indices=[lo,lo+499],ready_at_enqueue_counts=dict(collections.Counter(r['ready_at_enqueue'] for r in part)),
            metrics={k:stats([r[k] for r in part]) for k in ('ttft_ms','router_queue_ms','ingress_wait_ms','adapter_resolve_ms')}))
    out=[]
    logdir=Path('/tmp/tc-d537-7br/ray_tmp/ray/session_latest/logs') if label=='D537_W1' else root/'ray_evidence'
    for item in sorted(epochs.values(),key=lambda x:x['identity']['backend_ready_since_business_s']):
        e=item['identity'];out.append(dict(**e,served=len(item['request_ids'])))
        if label!='D537_W1':continue
        found=list(logdir.glob('worker-*-'+str(e['pid'])+'.out'))
        assert len(found)==1,(e['pid'],found)
        log=found[0];data=log.read_text(errors='replace')
        markers=('Dynamo bytecode transform time:','Directly load the compiled graph(s)',
                 'torch.compile takes','init engine (','Model loading took','Resolved architecture:',
                 'Initializing a V1 LLM engine','Starting to load model','Automatically detected platform')
        selected=[re.sub(r'\x1b\[[0-9;]*m','',line) for line in data.splitlines() if any(m in line for m in markers)]
        out[-1]['log_evidence']=selected
        out[-1]['compiled_graph_cache_hit']='Directly load the compiled graph(s)' in data
        shutil.copy2(log,evidence/log.name)
        err=log.with_suffix('.err')
        if err.exists():shutil.copy2(err,evidence/err.name)
        refs.append(log)
    results[label]=dict(epochs=out,epoch_count=len(out),phases=phase,
        by_ready_count={k:dict(n=len(v),ttft_ms=stats([r['ttft_ms'] for r in v]),router_queue_ms=stats([r['router_queue_ms'] for r in v])) for k,v in conditions.items()},
        request_metrics={k:stats([r[k] for r in ordered]) for k in ('ttft_ms','router_queue_ms','ingress_wait_ms','adapter_resolve_ms')},
        same_host_wall_durations_only=True,epoch_first_requests_not_relabelled=True)
    refs += [replay,root/'launch7b_repaired.launch/exec_receipt.json']
# Preserve upstream scaling semantics; only read source, no policy changes.
router=CURRENT/'source_repaired/sllm/routers/roundrobin_router.py'
oldrouter=OLD/'source_repaired/sllm/routers/roundrobin_router.py'
assert p.digest(router)==p.digest(oldrouter)
upstream=subprocess.check_output(['git','show','9f50241baa5386e06a9321c51f19a9ef5f964c2b:sllm/routers/roundrobin_router.py'],cwd=BASE/'repos/ServerlessLLM',text=True)
def functions(text):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=functions(router.read_text()),functions(upstream)
core=('auto_scaler','_auto_scaler_loop','_stop_instance','_finish_instance')
equal={name:a[name]==b[name] for name in core}
assert all(equal.values()),equal
save(RAW/'review.json',dict(passed=True,schema='d539_native_startup_queue_review_v1',identity=identity,
    observations=results,upstream_core_ast_equal=equal,upstream_commit='9f50241baa5386e06a9321c51f19a9ef5f964c2b',
    changed_serving_code=False,new_performance_run=False,causal_attribution_complete=False,
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in (Path(__file__),router,oldrouter,*refs)],
    limitations=['Queue/ready group membership is system-induced, not a randomized counterfactual.',
        'Stored instance wall durations and native monotonic ready offsets are not mixed into one timeline.',
        'Cache-hit evidence excludes the claim that those model graphs were all recompiled; it does not identify all startup overhead.',
        'Epochs count logical instances, not physical GPU allocation.']))
print(json.dumps(dict(passed=True,core_ast_equal=equal,observations={k:dict(epoch_count=v['epoch_count'],first_four=[e['backend_ready_since_business_s'] for e in v['epochs'][:4]],request_metrics=v['request_metrics'],by_ready_count=v['by_ready_count']) for k,v in results.items()})))
