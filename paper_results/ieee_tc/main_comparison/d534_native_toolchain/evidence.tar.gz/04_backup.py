"""Reuse explicit checkpoint checks for D534; preserve both repos' user dirt."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
identity=p.scope_identity(p.cg_path().name)
save(RAW/'backup_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
qualification=read(OUT/'qualification.json')
assert qualification['passed'] and qualification['test_count']==16
for path,sha in {**qualification['refs'],**qualification['preserved']}.items():
    assert p.digest(Path(path))==sha,path
assert p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')['pass']
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and not Path(closed['identity']['path']).exists()
assert git(ROOT,'rev-parse','HEAD')=='7f25b2bd82e5c1933109189883e10d5d662e4b2a'
assert git(BASE,'rev-parse','HEAD')=='b540d7664bf4f8522b3b2694348d889e902034c6'
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not token or token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
def publish(repo,paths,branch,remote,message):
    assert git(repo,'branch','--show-current')==branch
    assert not git(repo,'diff','--cached','--name-only')
    for name in paths:
        data=(repo/name).read_bytes();assert len(data)<2*1024*1024
        if not name.endswith('.tar.gz'):clean(data)
    subprocess.run(['git','diff','--check'],cwd=repo,check=True)
    subprocess.run(['git','add','--',*paths],cwd=repo,check=True)
    assert set(git(repo,'diff','--cached','--name-only').splitlines())==set(paths)
    assert not any(name in paths for name in ('configs/generated/lora_manifest_1000.json',
        'scripts/replay_openai_trace.py','scripts/run_serverlessllm_relayserve_continuation.sh'))
    for name in paths:
        assert hashlib.sha256(subprocess.check_output(['git','show',':'+name],cwd=repo)).hexdigest()==p.digest(repo/name)
    subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
    subprocess.run(['git','commit','-m',message],cwd=repo,check=True)
    subprocess.run(['git','push',remote,branch],cwd=repo,check=True)
    head=git(repo,'rev-parse','HEAD')
    assert git(repo,'ls-remote',remote,'refs/heads/'+branch).split()[0]==head
    return dict(head=head,remote_equal=True,files=paths)

# Archive only small source/receipts; no duplicate source trace or model assets.
files=[RAW/name for name in ('qualify.py','qualify2.py','finish.py','close.py','backup.py',
    'tests_serverless_llm_experiment_retry14_baseline.json',
    'tests_serverless_llm_baselines.json','tests2_serverless_llm_baselines.json',
    'render_primelora.json','render_vllm.json','qualification_identity.json',
    'qualification_closure.json','qualification2_identity.json','qualification2_closure.json',
    'analysis_identity.json','analysis_closure.json')]
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<2*1024*1024;clean(data)
        name=f'{i:02d}_{path.name}'
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
baseline=publish(BASE,['scripts/replay_vllm_engine_trace.py',
    'tests/test_ieee_tc_vllm_service.py','configs/ieee_tc/vllm_7b_resident_native_compiler_v2.json',
    'docs/ieee_tc/D534_COMMON_NATIVE_TOOLCHAIN.md'],
    'main','origin','tc: bind explicit shared native compiler identity for new campaigns (D534)')
save(RAW/'baseline_backup_receipt.json',baseline)
save(OUT/'manifest.json',dict(passed=True,tests=16,baseline_checkpoint=baseline,
    qualification_sha256=p.digest(OUT/'qualification.json'),archive_sha256=p.digest(OUT/'evidence.tar.gz'),
    archive_members=members,preparation_only=True,no_inference_started=True))
paths=['scripts/ieee_tc_native_toolchain.py','scripts/run_all_experiments.py',
    'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh',
    'configs/ieee_tc/native_toolchain_cuda130_v1.json','tests/test_tc_native_toolchain.py',
    'docs/ieee_tc/D534_COMMON_NATIVE_TOOLCHAIN.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(ROOT)) for name in ('qualification.json','manifest.json','evidence.tar.gz')]
main=publish(ROOT,paths,'retry14_continuous_queue_v2','faaslora_origin',
             'tc: isolate shared native build identity without policy changes (D534)')
save(RAW/'backup_receipt.json',dict(passed=True,scope=identity,main=main,baseline=baseline,tests=16))
print(json.dumps(dict(passed=True,main=main,baseline=baseline)))
