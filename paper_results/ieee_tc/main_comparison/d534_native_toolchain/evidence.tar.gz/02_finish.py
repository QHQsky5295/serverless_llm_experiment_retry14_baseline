"""Seal completed D534 CPU checks; no test/probe repetition.

qualify2 finished both native renderers, then its shell-text delimiter matched
the 'fi' in 'configs'. Validate the actual delimited shell block here, retaining
both earlier harness failures and all already completed test/probe outputs.
"""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain'
CFG=ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json'
NATIVE=BASE/'configs/ieee_tc/vllm_7b_resident_native_compiler_v2.json'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
closures={name:read(RAW/(name+'_closure.json')) for name in ('qualification','qualification2')}
assert all(row['passed'] and row['actual_recursive_procs_empty'] and row['path_gone'] for row in closures.values())
tests=[]
for name in ('tests_serverless_llm_experiment_retry14_baseline.json','tests2_serverless_llm_baselines.json'):
    row=read(RAW/name)
    assert row['returncode']==0 and '\nOK' in row['stderr'] and 'skipped=' not in row['stderr']
    count=int(re.search(r'Ran (\d+) tests? in',row['stderr']).group(1))
    tests.append(dict(source=str(RAW/name),sha256=p.digest(RAW/name),count=count,reused=True))
rendered={}
for name in ('primelora','vllm'):
    row=read(RAW/('render_'+name+'.json'))
    assert row['returncode']==0
    lines=[line.removeprefix('D534_RENDER ') for line in row['stdout'].splitlines() if line.startswith('D534_RENDER ')]
    assert len(lines)==1
    rendered[name]=json.loads(lines[0])
assert rendered['primelora']==rendered['vllm']
assert not rendered['vllm']['cuda_initialized'] and not rendered['vllm']['build_called']
assert not any(path.is_file() for path in Path(rendered['vllm']['jit_dir']).rglob('*'))
review=read(ROOT/'paper_results/ieee_tc/main_comparison/d532_vllm_w1/startup_review1/review.json')
cache_refs={key:val for key,val in review['source_refs'].items() if '/cached_ops/sampling/' in key}
assert len(cache_refs)==2
for path,row in cache_refs.items():assert p.digest(Path(path))==row['sha256']
old=read(BASE/'configs/ieee_tc/vllm_7b_resident_native_v1.json')
new=read(NATIVE)
assert {k:v for k,v in new.items() if k!='native_compiler_contract'}==old
shell=ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
block=shell.read_text().split('if [[ "${1:-d293}" == d533 ]]; then')[1].split('\nfi\n')[0]
assert p.digest(CFG) in block and CFG.name in block and 'FAASLORA_TC_REPLAY_PROFILE=W1' in block
subprocess.run(['bash','-n',str(shell)],check=True)
for repo in (ROOT,BASE):subprocess.run(['git','diff','--check'],cwd=repo,check=True)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
preserved={ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(path)==sha
sources=[Path(__file__),RAW/'qualify.py',RAW/'qualify2.py',CFG,NATIVE,shell,
    ROOT/'scripts/ieee_tc_native_toolchain.py',ROOT/'scripts/run_all_experiments.py',
    ROOT/'tests/test_tc_native_toolchain.py',BASE/'scripts/replay_vllm_engine_trace.py',
    BASE/'tests/test_ieee_tc_vllm_service.py']
record=dict(passed=True,scope=identity,tests=tests,test_count=sum(row['count'] for row in tests),
    rendered=rendered,closures=closures,protected=protected,
    retained_failures=['test package namespace collision before baseline tests',
        'shell text parser split fi inside configs after successful native renderers'],
    no_kernel_build=True,no_gpu_run=True,legacy_build_description_and_ninja_log_unchanged=cache_refs,
    serving_config_unchanged_except_explicit_compiler_contract=True,
    refs={str(path):p.digest(path) for path in sources},preserved={str(k):v for k,v in preserved.items()},
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')})
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'qualification.json',record)
print(json.dumps({key:record[key] for key in ('passed','test_count','no_kernel_build','no_gpu_run','resources')}))
