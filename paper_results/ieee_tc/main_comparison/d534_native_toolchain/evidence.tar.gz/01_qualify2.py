"""D534 shared-toolchain CPU qualification; no kernel build or inference."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain'
ENV = Path('/home/qhq/.venvs/primelora_vllm0300_tc_20260925')
CFG = ROOT/'configs/ieee_tc/native_toolchain_cuda130_v1.json'
NATIVE = BASE/'configs/ieee_tc/vllm_7b_resident_native_compiler_v2.json'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(BASE/'scripts'))
from scripts import ieee_tc_native_toolchain as tc

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

if len(sys.argv) == 2 and sys.argv[1] == '--baseline-tests':
    import importlib.util
    import unittest
    modules = {}
    for name in ('test_ieee_tc_vllm_measurement', 'test_ieee_tc_vllm_service'):
        spec = importlib.util.spec_from_file_location('tests.'+name, BASE/'tests'/(name+'.py'))
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        modules[name] = module
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(modules['test_ieee_tc_vllm_service'].ContractTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)

if len(sys.argv) == 3 and sys.argv[1] == '--render':
    if sys.argv[2] == 'primelora':
        # Actual parent/worker entry performs its opt-in binding before torch.
        from scripts import run_all_experiments as runner
        receipt = runner._native_build_receipt
        assert receipt is not None
    else:
        from replay_vllm_engine_trace import native_worker_environment
        cfg = json.loads(NATIVE.read_text())
        env, native_receipt = native_worker_environment(cfg, '', os.environ)
        os.environ.update(env)
        receipt = native_receipt['compiler_contract']
    import torch
    from flashinfer.jit import env as jit_env
    from flashinfer.jit.cpp_ext import generate_ninja_build_for_op
    from flashinfer.jit.sampling import gen_sampling_module
    assert not torch.cuda.is_initialized()
    spec = gen_sampling_module()
    text = generate_ninja_build_for_op(spec.name, spec.sources, spec.extra_cflags,
        spec.extra_cuda_cflags, spec.extra_ldflags, spec.extra_include_dirs,
        spec.needs_device_linking)
    assert not torch.cuda.is_initialized()
    print('D534_RENDER ' + json.dumps(dict(receipt=receipt, text=text,
        sha256=hashlib.sha256(text.encode()).hexdigest(), bytes=len(text.encode()),
        jit_dir=str(jit_env.FLASHINFER_JIT_DIR), cuda_initialized=False, build_called=False)))
    raise SystemExit

from scripts import ieee_tc_preflight as p
identity = p.scope_identity(p.cg_path().name)
save(RAW/'qualification2_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate = p.preflight([ROOT], p.GIB)
assert gate['preflight_pass'], gate['issues']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
preserved = {ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path, sha in preserved.items(): assert p.digest(path) == sha
cache = Path('/home/qhq/.cache/flashinfer/0.6.18.post1/86/cached_ops/sampling')
cache_before = {str(path):p.digest(path) for path in cache.iterdir() if path.is_file()}
base_env = dict(HOME='/home/qhq',PATH=str(ENV/'bin')+':/usr/bin:/bin',
    CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
    HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONPATH=str(ROOT))
retained = json.loads((RAW/'tests_serverless_llm_experiment_retry14_baseline.json').read_text())
assert retained['returncode'] == 0 and 'Ran 8 tests' in retained['stderr'] and '\nOK' in retained['stderr']
tests = [dict(suite='tests.test_tc_native_toolchain',count=8,passed=True,reused=True)]
for repo, name in ((BASE,'tests.test_ieee_tc_vllm_service.ContractTests'),):
    completed = subprocess.run([str(ENV/'bin/python'),'-B',str(__file__),'--baseline-tests'],
        cwd=repo,env=base_env,capture_output=True,text=True,timeout=90)
    save(RAW/('tests2_'+repo.name+'.json'),dict(returncode=completed.returncode,
        stdout=completed.stdout,stderr=completed.stderr))
    completed.check_returncode()
    match = re.search(r'Ran (\d+) tests? in', completed.stderr)
    assert match and '\nOK' in completed.stderr and 'skipped=' not in completed.stderr
    tests.append(dict(suite=name,count=int(match.group(1)),passed=True))
rendered = {}
for mode in ('primelora','vllm'):
    env = dict(base_env, **{tc.CONTRACT_ENV:str(CFG),tc.SHA_ENV:p.digest(CFG)})
    completed = subprocess.run([str(ENV/'bin/python'),'-B',str(__file__),'--render',mode],
        cwd=ROOT,env=env,capture_output=True,text=True,timeout=90)
    save(RAW/('render_'+mode+'.json'),dict(returncode=completed.returncode,
        stdout=completed.stdout,stderr=completed.stderr))
    completed.check_returncode()
    lines = [line.removeprefix('D534_RENDER ') for line in completed.stdout.splitlines()
             if line.startswith('D534_RENDER ')]
    assert len(lines) == 1
    rendered[mode] = json.loads(lines[0])
assert rendered['primelora'] == rendered['vllm']
assert {str(path):p.digest(path) for path in cache.iterdir() if path.is_file()} == cache_before
new_dir = Path(rendered['vllm']['jit_dir'])
assert not any(path.is_file() for path in new_dir.rglob('*'))
old = json.loads((BASE/'configs/ieee_tc/vllm_7b_resident_native_v1.json').read_text())
new = json.loads(NATIVE.read_text())
assert {k:v for k,v in new.items() if k != 'native_compiler_contract'} == old
shell = ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
block = shell.read_text().split('if [[ "${1:-d293}" == d533 ]]; then')[1].split('fi')[0]
assert p.digest(CFG) in block and CFG.name in block
subprocess.run(['bash','-n',str(shell)],check=True)
for repo in (ROOT,BASE):subprocess.run(['git','diff','--check'],cwd=repo,check=True)
sources = [Path(__file__),CFG,NATIVE,ROOT/'scripts/ieee_tc_native_toolchain.py',
    ROOT/'scripts/run_all_experiments.py',ROOT/'tests/test_tc_native_toolchain.py',shell,
    BASE/'scripts/replay_vllm_engine_trace.py',BASE/'tests/test_ieee_tc_vllm_service.py']
record = dict(passed=True,scope=identity,gate=gate,protected=protected,
    preserved={str(k):v for k,v in preserved.items()},tests=tests,
    test_count=sum(row['count'] for row in tests),rendered=rendered,
    legacy_sampling_cache_unchanged=True,no_kernel_build=True,no_gpu_run=True,
    serving_config_unchanged_except_explicit_compiler_contract=True,
    refs={str(path):p.digest(path) for path in sources},
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')})
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'qualification.json',record)
print(json.dumps({key:record[key] for key in ('passed','test_count','no_kernel_build','no_gpu_run','resources')}))
