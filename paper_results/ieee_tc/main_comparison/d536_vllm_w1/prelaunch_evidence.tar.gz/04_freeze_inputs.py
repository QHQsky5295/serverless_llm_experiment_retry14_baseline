"""Reuse D419 input/cache sealing for the complete approved 4000-request W1 view."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path[:0] = [str(MAIN), str(BASE/'scripts')]
from prepare_ieee_tc_serverless_stack import load_http_replay_plan
from replay_vllm_engine_trace import _exclusive_json, _sha, validate_native_service_config

http = json.loads((ROOT/'http_7b_4000.json').read_text())
cfg_path = BASE/'configs/ieee_tc/vllm_7b_resident_native_compiler_v2.json'
cfg = json.loads(cfg_path.read_text())
validate_native_service_config(cfg, http)
plan = load_http_replay_plan(http)
assert plan.identity()['view_sha256'] == '103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
assert _sha(http['pool_index']) == http['pool_index_sha256']
rows = [json.loads(e.source_json) for e in plan.entries]
assert len(rows) == 4000
assert len({r['adapter_id'] for r in rows}) == 132
assert sum(min(r['expected_output_tokens'], 256) for r in rows) == 458224
assert {r['adapter_id'] for r in rows} <= {r['id'] for r in json.loads(Path(http['pool_index']).read_text())['artifacts']}
_exclusive_json(ROOT/'input_identity.json', dict(plan=plan.identity(),
    actual_unique_adapters=132, target_tokens=458224,
    performance_ranking_eligible=False, resident_reference_candidate=True,
    pending_complete_contract_audit=True, source_trace_and_pool_unmodified=True,
    http_sha256=_sha(ROOT/'http_7b_4000.json'), config_sha256=_sha(cfg_path),
    main_execution_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip(),
    baseline_execution_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()))
roots = [Path('/home/qhq/.cache/vllm/torch_compile_cache/1618ac661c'),
    Path('/home/qhq/.cache/vllm/torch_compile_cache/torch_aot_compile/5aa16d450e99426f10d34b8dad9ac841c1d5db1cbc22aebc833790f64ad77928'),
    Path('/home/qhq/.cache/primelora_tc_native/328b202599d90b9e037ebad53bc7696a9997be2f0f412aaaeda2c1a0cc9c5b1c/.cache/flashinfer/0.6.18.post1/86')]
items = []
for root in roots:
    assert root.is_dir(), str(root)
    for p in sorted(root.rglob('*')):
        if p.is_file():
            items.append([str(p), p.stat().st_size, _sha(p)])
_exclusive_json(ROOT/'native_cache_prefix_identity.json', dict(
    scope='D417/D419 actual compiler prefixes and D535 common compiler-SHA SM86 FlashInfer; not a whole-root seal',
    prior_whole_root_receipt=str(ROOT.parent/'d417_20261011/native_compile_cache_before.json'),
    files=len(items), bytes=sum(r[1] for r in items), entries=items,
    aggregate_sha256=hashlib.sha256(json.dumps(items,separators=(',',':')).encode()).hexdigest(),
    engine_or_gpu_preloaded=False))
print(json.dumps(dict(input=plan.identity(),cache_files=len(items),cache_bytes=sum(r[1] for r in items))))

