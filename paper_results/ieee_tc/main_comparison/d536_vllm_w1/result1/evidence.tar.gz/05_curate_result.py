"""Reuse D530 bounded curation for D536; no repeated tests or GPU execution."""
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d536_vllm_w1/result1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'result_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
summary=read(RAW/'audit_full4000_w1.json')
assert summary['measurement_complete'] and summary['workload_passed']
assert summary['native_revalidated_requests']==4000 and summary['actual_native_output_tokens']==458224
assert summary['source_plan']['profile']=='W1' and summary['n_correct'] is None
assert summary['counts']['N_failed']==0 and 0<=summary['common_slo']['joint_good']<=4000
assert all(summary[k]==0 for k in ('max_e2e_recomputation_error_ms','max_tpot_recomputation_error_ms','max_native_recompute_error_ms'))
for ref in summary['raw_sources']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
closure=read(RAW/'analysis_closure.json')
assert closure['passed'] and closure['actual_recursive_procs_empty'] and not Path(closure['identity']['path']).exists()
binding_path=ROOT/'paper_results/ieee_tc/main_comparison/d531_w1_input/qualification.json'
binding=read(binding_path)
assert binding['passed'] and binding['tests']==103
compiler_path=ROOT/'paper_results/ieee_tc/main_comparison/d534_native_toolchain/qualification.json'
compiler=read(compiler_path)
assert compiler['passed'] and compiler['test_count']==16
for path,sha in {**compiler['refs'],**compiler['preserved']}.items():assert p.digest(Path(path))==sha,path
for path,sha in {**binding['refs'],**binding['preserved']}.items():
    current=p.digest(Path(path))
    assert current==sha or (path in compiler['refs'] and current==compiler['refs'][path]),path
build_path=ROOT/'paper_results/ieee_tc/main_comparison/d535_common_sampling_build/build.json'
build=read(build_path)
assert build['passed'] and build['actual_closure']['passed']
for path,row in build['entrypoints']['build']['files'].items():assert p.digest(Path(path))==row['sha256'],path
preserved={str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
           str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
           str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'] and protected['entry_count']==147
subprocess.run(['git','diff','--exit-code','fea6a1be08f2663c3a89fe5680cfa704f644515e','--',
                'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=ROOT,check=True)
OUT.mkdir(parents=True,exist_ok=False)
files=[RAW/name for name in ('close_launch.py','stop_remote.sh','preserve_evidence.py',
       'run_analysis.py','close.py','curate_result.py','launch7b.json','local_cleanup.json',
       'analysis_identity.json','analysis_receipt.json','analysis_closure.json',
       'remote_stop.log','evidence_copy_receipt.json','http_7b_4000.json','input_identity.json',
       'native_cache_prefix_identity.json')]
files += sorted((RAW/'model7b').glob('worker_*.log'))
files += sorted((RAW/'model7b/worker_receipts').glob('*.json'))
files += [RAW/'model7b/physical/deployment.json',
          ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',
          ROOT/'docs/ieee_tc/D536_VLLM_W1_RESULT.md']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
members={}
archive=OUT/'evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes()
        assert len(data)<32*1024*1024
        assert not token or token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
        name=f'{i:02d}_{path.name}'
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o600;member.mtime=0
        tar.addfile(member,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
assert archive.stat().st_size<2*1024*1024
with (OUT/'audit.json').open('xb') as stream:stream.write((RAW/'audit_full4000_w1.json').read_bytes())
save(OUT/'manifest.json',dict(passed=True,scope=identity,new_gpu_run=False,production_changed=False,
     reference_frozen=False,reason='bounded model compilation initial-state review pending before W1 reference freeze',
     reused_tests=dict(count=103,path=str(binding_path),sha256=p.digest(binding_path)),
     compiler_qualification_sha256=p.digest(compiler_path),common_build_sha256=p.digest(build_path),
     execution_main_commit='fea6a1be08f2663c3a89fe5680cfa704f644515e',
     execution_baseline_commit='bde215460acb9e850efa479a89bda6fc39a2bd7d',
     metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
     single_run_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
     protected=protected,preserved=preserved,source_refs=summary['raw_sources'],archive_members=members,
     outputs={name:p.digest(OUT/name) for name in ('audit.json','evidence.tar.gz')}))
print(json.dumps(dict(passed=True,reused_tests=103,archive_bytes=archive.stat().st_size,scope=identity)))
