"""Reuse explicit-source/checksum/secret guards for D541 tested common repair."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=MAIN/'paper_results/ieee_tc/p2_backend/d550_initial_control_native100/result1'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=MAIN,text=True).strip()
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'publication2_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD')=='3efeaf976e72238724b65a87268079b03132bc2e'
assert git('branch','--show-current')=='retry14_continuous_queue_v2' and not git('diff','--cached','--name-only')
changed=set(git('diff','--name-only','--','faaslora','tests','scripts','configs/ieee_tc').splitlines())
assert changed=={'scripts/ieee_tc/check_d299_full_context.py','tests/test_tc_serverless_qualification_population.py'}
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
audit=read(RAW/'actual_qualification.json')
mechanism=read(RAW/'initial_control_evidence.json')
after=read(RAW/'analysis2_receipt.json')
assert audit['passed'] and audit['protocol_bound_count']==100
assert not audit['fixed_workload_complete4000'] and not audit['ranking_eligible']
assert mechanism['native_early_control_triggered'] is True
assert after['passed'] and all(row['returncode']==0 for row in after['commands'])
assert any(line.startswith('Ran 59 tests in ') for line in (RAW/'analysis_population_tests.log').read_text().splitlines())
assert (RAW/'analysis_population_tests.log').read_text().rstrip().splitlines()[-1]=='OK'
for path,sha in after['sources'].items():assert p.digest(Path(path))==sha,path
for phase in ('qualification','qualification2','backup','start','analysis','analysis2','publication'):
    closed=read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
local=read(RAW/'local_cleanup.json')
assert local['passed'] and local['service_path_gone'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists()
assert not Path(local['auxiliary_identity']['path']).exists()
for ref in audit['refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
source=Path(audit['evidence']['source'])
requests=next(iter(read(source)['detailed_results'].values()))['requests']
initial=mechanism['initial']
for row in mechanism['early_control']:
    actual=sum(r['external_arrival_timing']['server_received_s']<=row['observed_at'] for r in requests)
    assert row['queue_depth']==actual,(row['queue_depth'],actual)
    assert row['ready_instances']==row['active_requests']==row['ready_capacity']==0
    assert row['p95_ttft_ms'] is None and row['ttft_sample_count']==0
    assert row['pending_instances']>=1
    assert row['pending_instances']<=4
assert len(mechanism['early_scheduled'])==len(mechanism['early_natural_activations'])==3
assert all(r['external_arrival_timing']['service_dequeued_s']>=initial['first_ready_at'] for r in requests)
run=source.parent
physical=read(run/'launch.launch/physical_deployment/summary.json')
for ref in physical['allocation_journals']:
    assert ref['released'] and p.digest(Path(ref['path']))==ref['sha256']
assert p.digest(Path(physical['request_terminals_path']))==physical['request_terminals_sha256']
assert p.digest(MAIN/'scripts/run_all_experiments.py')=='0e25de8a8d95ce12b1877542ec58c36023a8bf01a435abb14712106a79bbfd31'
causal=dict(passed=True,observed_arrival_samples=len(mechanism['early_control']),
    queue_equals_actual_server_received=True,early_natural_count=3,
    initial_trigger_offset_s=initial['trigger_at']-initial['replay_t0_s'],
    initial_ready_offset_s=initial['first_ready_at']-initial['replay_t0_s'],
    control_start_offset_s=initial['control_start_at']-initial['replay_t0_s'],
    scaleout_offsets_s=[x['observed_at']-initial['replay_t0_s'] for x in mechanism['early_scheduled']],
    scaleout_queues=[x['queue_depth'] for x in mechanism['early_scheduled']],
    source_sha256=p.digest(source),source_trace_sha256=audit['workload_identity']['source_sha256'],
    scope='first100 native functional qualification only',numerical_correctness_qualified=False,
    causal_performance_improvement_proved=False)
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
preserved={str(MAIN/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),*RAW.glob('*.log')])
files += [MAIN/'scripts/ieee_tc/check_d299_full_context.py',MAIN/'tests/test_tc_serverless_qualification_population.py',
          MAIN/'docs/ieee_tc/D550_INITIAL_CONTROL_NATIVE100.md',Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/resource_measurement/d541_20261015/publish.py')]
OUT.mkdir(parents=True,exist_ok=False)
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<4*1024*1024;clean(data)
        if path.suffix=='.py':ast.parse(data)
        name=f'{i:02d}_{path.name}';info=tarfile.TarInfo(name)
        info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'summary.json',dict(passed=True,native_prefix_qualification=True,
    candidate_accepted_for_performance=False,new_full_performance=False,
    baseline_algorithm_changed=False,actual_audit=audit,mechanism=mechanism,causal=causal,
    analysis_receipt=after,tests=59,failed_analysis_retained=read(RAW/'analysis_receipt.json'),
    execution_commit='3efeaf976e72238724b65a87268079b03132bc2e',
    source_sha256={str(MAIN/path):p.digest(MAIN/path) for path in sorted(changed)},
    protected=protected,preserved=preserved,scope=identity,
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz')))
with (OUT/'result.sha256').open('x') as f:
    for name in ('summary.json','evidence.tar.gz'):f.write(p.digest(OUT/name)+'  '+name+'\n')
paths=[*sorted(changed),'docs/ieee_tc/D550_INITIAL_CONTROL_NATIVE100.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(MAIN)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
for name in paths:
    data=(MAIN/name).read_bytes();assert len(data)<2*1024*1024
    if not name.endswith('.tar.gz'):clean(data)
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=MAIN,check=True)
subprocess.run(['git','add','--',*paths],cwd=MAIN,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for name in paths:assert subprocess.check_output(['git','show',':'+name],cwd=MAIN)==(MAIN/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=MAIN,check=True)
subprocess.run(['git','commit','-m','tc: seal initial-control native prefix evidence and explicit population audit (D550)'],cwd=MAIN,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=MAIN,check=True)
head=git('rev-parse','HEAD')
assert git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]==head
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote_equal=True,files=paths,identity=identity))
print(json.dumps(dict(passed=True,head=head,files=len(paths),remote_equal=True)),flush=True)
