"""Reuse D533 input/cache review and D550 actual-arrival check; no inference."""
import gc
import ijson
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def requests(path):
    # Same retained source schema; stream to avoid retaining both full outcomes.
    with path.open('rb') as stream:
        names = []
        for prefix, event, value in ijson.parse(stream, use_float=True):
            if prefix == 'detailed_results' and event == 'map_key':
                names.append(value)
                break
    assert len(names) == 1
    with path.open('rb') as stream:
        yield from ijson.items(stream, 'detailed_results.' + names[0] + '.requests.item', use_float=True)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'review_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
closed = read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
run = RAW/'7b_initial_control_full_w1'
source = next(run.glob('experiment_results*.json'))
audit = read(RAW/'actual_qualification.json')
assert audit['passed'] and audit['protocol_bound_count'] == 4000
context = read(run/'launch.launch/exec_receipt.json')['external_replay']
plan = FrozenReplayPlan.from_launch_context(context)
assert plan.identity() == audit['workload_identity']
entries = {e.request_id:e for e in plan.entries}
prior = RAW.parent.parent/'vllm_qualification/d536_20261015/launch7b.launch/replay.jsonl'
contracts = {}
with prior.open() as stream:
    for line in stream:
        row = json.loads(line)
        if row['event'] == 'request_contract':
            assert row['request_id'] not in contracts
            contracts[row['request_id']] = row
assert len(contracts) == len(entries) == 4000
witness_path = ROOT/'paper_results/ieee_tc/main_comparison/d546_hydraserve_w1/result1/cross_contract.json'
witness = read(witness_path)
assert witness['passed'] and witness['request_count'] == 4000
assert any(r['path'] == str(prior) and r['sha256'] == p.digest(prior) for r in witness['refs'])
for ref in witness['refs']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
for key in ('source_sha256','view_sha256','count','source_count','profile','rate_scale'):
    assert plan.identity()[key] == witness['source_plan'][key], key
projection = {}
arrival_times = []
mechanism = read(RAW/'initial_control_evidence.json')
initial = mechanism['initial']
for row in requests(source):
    rid = row['request_id']
    assert rid not in projection
    ref, entry = contracts[rid], entries[rid]
    assert row['adapter_id'] == ref['adapter_id']
    assert row['requested_completion_tokens'] == row['completion_tokens'] == ref['target_tokens']
    assert row['canonical_prompt_sha256'] == ref['canonical_prompt_sha256']
    assert row['canonical_prompt_tokens'] == ref['canonical_prompt_tokens']
    assert row['native_token_timing']['native_prompt_token_ids_sha256'] == ref['native_prompt_token_ids_sha256']
    assert entry.source_sha256 == ref['source_item_sha256']
    assert row['generation_contract'] == 'fixed_length_greedy_v1' and row['output_contract_match'] is True
    assert abs(row['scheduled_arrival_offset_s'] - entry.offset_s) <= 1e-9
    assert row['external_arrival_timing']['service_dequeued_s'] >= initial['first_ready_at']
    projection[rid] = {key:row[key] for key in ('adapter_id','completion_tokens','canonical_prompt_sha256','completion_token_ids_sha256')}
    arrival_times.append(row['external_arrival_timing']['server_received_s'])
assert projection.keys() == entries.keys() == contracts.keys()
for row in mechanism['early_control']:
    assert row['queue_depth'] == sum(t <= row['observed_at'] for t in arrival_times)
    assert row['ready_instances'] == row['active_requests'] == row['ready_capacity'] == 0
    assert row['p95_ttft_ms'] is None and row['ttft_sample_count'] == 0
    assert 1 <= row['pending_instances'] <= 4
old_audit_path = ROOT/'paper_results/ieee_tc/main_comparison/d533_full_w1/result1/audit.json'
old_audit = read(old_audit_path)
old_source = Path(old_audit['evidence']['source'])
assert any(r['path'] == str(old_source) and r['sha256'] == p.digest(old_source) for r in old_audit['refs'])
changed_outputs = []
old_ids = set()
for row in requests(old_source):
    rid = row['request_id']
    assert rid not in old_ids
    old_ids.add(rid)
    new = projection[rid]
    for key in ('adapter_id','completion_tokens','canonical_prompt_sha256'):
        assert row[key] == new[key], (rid,key)
    if row['completion_token_ids_sha256'] != new['completion_token_ids_sha256']:
        changed_outputs.append(dict(request_id=rid,reference=row['completion_token_ids_sha256'],candidate=new['completion_token_ids_sha256']))
assert old_ids == projection.keys()
del projection, contracts
gc.collect()
before = read(RAW/'model_cache_metadata_before.json')
prep = read(RAW/'cpu_preparation_evidence.json')
toolchain = json.loads((run/'launch.launch/service.log').read_text().split('TC_NATIVE_TOOLCHAIN_RECEIPT ',1)[1].splitlines()[0])
workers = []
logs = []
for record in prep['records']:
    log = Path(record['worker_root'])/'worker.log'
    content = log.read_text()
    receipts = [json.loads(line.split('TC_NATIVE_TOOLCHAIN_RECEIPT ',1)[1]) for line in content.splitlines() if line.startswith('TC_NATIVE_TOOLCHAIN_RECEIPT ')]
    assert receipts and all(r == toolchain for r in receipts)
    important = [line for line in content.splitlines() if any(marker in line for marker in (
        'Using cache directory:', 'Compiling a graph for', 'torch.compile took',
        'saved AOT compiled function', 'Directly load AOT compilation',
        'init engine (profile,', 'Triton kernel JIT compilation during inference:'))]
    paths = [line.split('Using cache directory: ',1)[1].split(' for ',1)[0] for line in important if 'Using cache directory: ' in line]
    workers.append(dict(worker_root=str(log.parent),state=record['state'],log_sha256=p.digest(log),
        cache_paths=paths,log_evidence=important,
        cache_metadata_present_before={path:any(e['path'] == path+'/cache_key_factors.json' for e in before['entries']) for path in paths}))
    logs.append(log)
current = dict(joint=audit['common_threshold_joint_count']/4000,
    gpu_seconds=audit['stats']['physical_gpu_seconds'],p95_ttft_ms=audit['stats']['p95_ttft_ms'])
comparison = dict(witness['comparison'])
previous = comparison['PrimeLoRA']
comparison['PrimeLoRA'] = current
differences = {name:dict(joint_difference_pp=100*(current['joint']-ref['joint']),
    lower_better_change_percent={key:100*(ref[key]-current[key])/ref[key] for key in ('gpu_seconds','p95_ttft_ms')})
    for name,ref in {**witness['comparison'],'PrimeLoRA_D533':previous}.items() if name != 'PrimeLoRA'}
budget = .75*comparison['vLLM']['gpu_seconds']
refs = [source,prior,witness_path,old_audit_path,old_source,RAW/'actual_qualification.json',
    RAW/'initial_control_evidence.json',RAW/'model_cache_metadata_before.json',Path(__file__),*logs]
result = dict(schema='d551_retained_full_w1_input_and_startup_review_v1',passed=True,
    request_count=4000,input_join_only=True,initial_state_contract_identical=False,
    independent_numerical_correctness='unknown',same_backend_output_changes=changed_outputs,
    output_difference_cause='unknown; scheduling or floating-point effects are possibilities, not proven causes',
    source_plan=plan.identity(),comparison=comparison,previous_PrimeLoRA=previous,
    prime_observed_differences=differences,reference_frozen=False,
    reference_candidate=dict(U=comparison['vLLM']['gpu_seconds'],budget=budget,PrimeLoRA_budget_ratio=current['gpu_seconds']/budget),
    initial_state=dict(workers=workers,whole_cache_prestate_proved=False,common_compiler_receipt_equal=True),
    observed_control=dict(queue_equals_actual_server_received=True,samples=len(mechanism['early_control']),
        early_natural_count=len(mechanism['early_natural_activations']),
        initial_trigger_offset_s=initial['trigger_at']-initial['replay_t0_s'],
        initial_ready_offset_s=initial['first_ready_at']-initial['replay_t0_s'],
        notice_to_initial_trigger_s=initial['trigger_at']-context['deployment_notice_s'],
        causal_performance_improvement_proved=False),
    limitations=['Initial AOT cache/startup differs from D533; no isolated early-control performance benefit',
        'Single development observation, no repeated-run uncertainty',
        'Full W0/W2/G2 and independent numerical proof remain open'],
    refs=[dict(path=str(path),sha256=p.digest(path)) for path in refs],scope=identity)
save(RAW/'cross_contract.json',result)
print(json.dumps(dict(passed=True,request_count=4000,output_changes=len(changed_outputs),
    observed_control=result['observed_control'],comparison=comparison,
    differences=differences,reference_candidate=result['reference_candidate']),indent=2))
