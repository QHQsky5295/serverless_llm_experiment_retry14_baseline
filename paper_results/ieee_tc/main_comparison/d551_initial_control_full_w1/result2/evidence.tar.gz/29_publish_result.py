"""Reuse D550 explicit-source curation/publication; seal a full W1 observation."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OUT = ROOT/'paper_results/ieee_tc/main_comparison/d551_initial_control_full_w1/result2'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()

identity = p.scope_identity(p.cg_path().name)
save(RAW/'publication2_identity.json',identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD') == 'a443b352076fb0b238b149380656d52581a392e2'
assert git('branch','--show-current') == 'retry14_continuous_queue_v2'
assert not git('diff','--cached','--name-only')
assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
audit = read(RAW/'actual_qualification.json')
cross = read(RAW/'cross_contract.json')
mechanism = read(RAW/'initial_control_evidence.json')
assert audit['passed'] and audit['fixed_workload_complete4000'] and audit['protocol_bound_count'] == 4000
assert audit['native_tokens'] == 458224 and audit['stats']['n_correct'] is None
assert cross['passed'] and cross['request_count'] == 4000 and not cross['reference_frozen']
assert audit['common_threshold_joint_count'] == 3923
assert audit['common_threshold_ttft_count'] == 3964 and audit['common_threshold_tpot_count'] == 3958
assert len(cross['same_backend_output_changes']) == 147
assert not mechanism['native_early_control_triggered'] and cross['observed_control']['early_natural_count'] == 0
assert cross['observed_control']['queue_equals_actual_server_received']
assert audit['max_e2e_identity_error_ms'] <= 1
assert audit['evidence']['max_native_ttft_error_ms'] <= 1 and audit['evidence']['max_native_tpot_error_ms'] <= 1
for ref in audit['refs'] + cross['refs']:
    assert p.digest(Path(ref['path'])) == ref['sha256'],ref['path']
for name in ('qualification','backup','start','analysis','review','publication'):
    closed = read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
local = read(RAW/'local_cleanup.json')
assert local['passed'] and local['actual_recursive_procs_empty'] and local['auxiliary_path_gone']
assert not Path(local['service_identity']['path']).exists() and not Path(local['auxiliary_identity']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
physical = read(RAW/'7b_initial_control_full_w1/launch.launch/physical_deployment/summary.json')
for ref in physical['allocation_journals']:
    assert ref['released'] and p.digest(Path(ref['path'])) == ref['sha256']
assert p.digest(Path(physical['request_terminals_path'])) == physical['request_terminals_sha256']
tests_path = ROOT/'paper_results/ieee_tc/p2_backend/d550_initial_control_native100/result1/summary.json'
tests = read(tests_path)
assert tests['passed'] and tests['tests'] == 59
for path,sha in tests['source_sha256'].items():
    assert p.digest(Path(path)) == sha,path
assert p.digest(ROOT/'scripts/run_all_experiments.py') == '0e25de8a8d95ce12b1877542ec58c36023a8bf01a435abb14712106a79bbfd31'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == '5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22'
assert p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md') == '193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d'
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
preserved = {
    str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499',
}
for path,sha in preserved.items():
    assert p.digest(Path(path)) == sha,path
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()

def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)

# The full remote monitor is immutable raw evidence, not a curated Git payload.
# Its actual SHA is already verified in audit['refs'] and remote_stop.json.
files = sorted([*RAW.glob('*.py'),*RAW.glob('*.json'),
    *(path for path in RAW.glob('*.log') if path.name != 'remote_monitor.log')])
files += [Path(worker['worker_root'])/'worker.log' for worker in cross['initial_state']['workers']]
files += [ROOT/'docs/ieee_tc/D551_FULL_W1_RESULT.md',tests_path,
    RAW/'7b_initial_control_full_w1/launch.json',
    RAW/'7b_initial_control_full_w1/launch.launch/physical_deployment/summary.json',
    RAW.parent/'d550_20261015/publish.py',RAW.parent/'d533_20261015/cross_contract_v2.py']
OUT.mkdir(parents=True,exist_ok=False)
members = {}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as bundle:
    for i,path in enumerate(files):
        data = path.read_bytes()
        assert len(data) < 8*1024*1024
        clean(data)
        if path.suffix == '.py':
            ast.parse(data)
        name = f'{i:02d}_{path.name}'
        info = tarfile.TarInfo(name)
        info.size,info.mode,info.mtime = len(data),0o600,0
        bundle.addfile(info,io.BytesIO(data))
        members[name] = dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as bundle:
    assert set(bundle.getnames()) == set(members)
    for name,ref in members.items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == ref['sha256']
save(OUT/'summary.json',dict(passed=True,full_w1_observation=True,
    joint_slo_requirement_observed=True,isolated_early_control_gain_proved=False,
    cross_scenario_complete=False,g2_complete=False,independent_numerical_correctness='unknown',
    actual_audit=audit,cross_contract=cross,mechanism=mechanism,
    execution_commit='a443b352076fb0b238b149380656d52581a392e2',
    baseline_commit='bde215460acb9e850efa479a89bda6fc39a2bd7d',
    reused_population_tests=dict(count=59,path=str(tests_path),sha256=p.digest(tests_path)),
    production_changed_after_launch=False,protected=protected,preserved=preserved,scope=identity,
    failed_publication_retained=read(RAW/'publication_attempt1_failure.json'),
    failed_partial_archive_sha256=p.digest(Path(read(RAW/'publication_attempt1_failure.json')['partial_archive_retained'])),
    archive_members=members,archive_sha256=p.digest(OUT/'evidence.tar.gz')))
with (OUT/'result.sha256').open('x') as stream:
    for name in ('summary.json','evidence.tar.gz'):
        stream.write(p.digest(OUT/name)+'  '+name+'\n')
paths = ['docs/ieee_tc/D551_FULL_W1_RESULT.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(ROOT)) for name in ('summary.json','evidence.tar.gz','result.sha256')]
for name in paths:
    data = (ROOT/name).read_bytes()
    assert len(data) < 2*1024*1024
    if not name.endswith('.tar.gz'):
        clean(data)
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines()) == set(paths)
for name in paths:
    assert subprocess.check_output(['git','show',':'+name],cwd=ROOT) == (ROOT/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: seal full W1 SLO observation with untriggered early-control caveat (D551)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head = git('rev-parse','HEAD')
assert git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0] == head
save(RAW/'publication_receipt.json',dict(passed=True,head=head,remote_equal=True,files=paths,identity=identity))
print(json.dumps(dict(passed=True,head=head,files=len(paths),remote_equal=True)),flush=True)
