"""D531: qualify existing W1 input bindings; no inference or replacement trace."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
import yaml

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
RESULTS = RAW.parent.parent
PUB = ROOT/'paper_results/ieee_tc/main_comparison/d531_w1_input'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(BASE/'scripts'))
from scripts import ieee_tc_preflight as p
import prepare_ieee_tc_serverless_stack as http
from faaslora.datasets.workload_generator import FrozenReplayPlan, prepare_frozen_http_request
from scripts.ieee_tc.audit_d402_serverlessllm_path import validate_population

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate = p.preflight([ROOT], p.GIB)
assert gate['preflight_pass'], gate['issues']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
protected = p.verify_seal(RESULTS/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
preserved = {ROOT/'configs/generated/lora_manifest_1000.json':'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    BASE/'scripts/replay_openai_trace.py':'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    BASE/'scripts/run_serverlessllm_relayserve_continuation.sh':'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path, sha in preserved.items(): assert p.digest(path) == sha
cfg_path = RESULTS/'vllm_qualification/d532_20261015/http_7b_4000.json'
old_path = RESULTS/'vllm_qualification/d423_20261011/http_7b_4000.json'
cfg, old = [json.loads(path.read_text()) for path in (cfg_path, old_path)]
left, right = copy.deepcopy(cfg), copy.deepcopy(old)
for row in (left, right):
    row.pop('request_view'); row.pop('experiment_role')
assert left == right
plan = http.load_http_replay_plan(cfg)
w0 = http.load_http_replay_plan(old)
assert len(plan.entries) == plan.source_count == 4000
assert plan.source_sha256 == 'efb903254fcddc320b6765144f4118883d3d057267c5d516ee88927d4504957c'
context = dict(plan=plan.identity(), tiny_witness=False, replay_scope='full_source_v1')
assert FrozenReplayPlan.from_launch_context(context) == plan
source = sorted(json.loads(Path(cfg['trace']).read_text())['requests'],
                key=lambda r:(float(r['arrival_time_s']),str(r['request_id'])))
base = 0.
phases = []
for k in range(8):
    rows, entries = source[k*500:(k+1)*500], plan.entries[k*500:(k+1)*500]
    expected = [base+(float(r['arrival_time_s'])-float(rows[0]['arrival_time_s']))/2 for r in rows]
    assert [entry.offset_s for entry in entries] == expected
    phases.append(dict(phase=k+1, count=500, first_s=expected[0], last_s=expected[-1]))
    base = expected[-1]+30.
from transformers import AutoTokenizer
tokenizer = AutoTokenizer.from_pretrained(cfg['backbone'], local_files_only=True)
contracts = {}
for a,b in zip(w0.entries, plan.entries):
    assert (a.request_id,a.source_json,a.source_sha256) == (b.request_id,b.source_json,b.source_sha256)
    x,y = [prepare_frozen_http_request(e,tokenizer,cfg['model']) for e in (a,b)]
    for key in ('canonical_prompt_sha256','native_prompt_token_ids_sha256','target_tokens','body'):
        assert x[key] == y[key], (a.request_id,key)
    contracts[b.request_id] = y
assert validate_population(cfg,dict(plan=plan.identity()),contracts,http,'full4000_w1') == 4000
try:
    validate_population(cfg,dict(plan=plan.identity()),contracts,http,'full4000')
except ValueError: pass
else: raise AssertionError('W1 accepted as W0')
from replay_vllm_engine_trace import validate_native_service_config
native_path = BASE/'configs/ieee_tc/vllm_7b_resident_native_v1.json'
assert p.digest(native_path) == '361dc7645a8eef8ee304addfaa9e1611093dae1c6678b108970c1adc2e7fe3a5'
assert validate_native_service_config(json.loads(native_path.read_text()),cfg) == 8352

# New Full YAML changes storage/output identities ONLY; exact old profiles load.
full_paths = [ROOT/'configs/ieee_tc/20261012_d476_7b_full_w0.yaml',
              ROOT/'configs/ieee_tc/20261015_d533_7b_full_w1.yaml']
fulls = [yaml.safe_load(path.read_text()) for path in full_paths]
normalized = copy.deepcopy(fulls)
for row in normalized:
    row['experiment'].pop('output_dir')
    row['storage'].pop('nvme_cache_dir'); row['storage'].pop('host_cache_dir')
assert normalized[0] == normalized[1]
assert 'ieee_lora_metadata_policy' not in fulls[1]['model']
from scripts.run_all_experiments import ScenarioRunner, _prepare_scenario_runtime_model_config, _normalize_runtime_concurrency_cap
full = fulls[1]
scenario = next(row for row in full['scenarios'] if row['name']=='tc_ieee_full')
coord = dict(full['resource_coordination'],**scenario.get('resource_coordination',{}))
runner = ScenarioRunner.__new__(ScenarioRunner)
runner.model_cfg = _prepare_scenario_runtime_model_config(_normalize_runtime_concurrency_cap(full['model']),full['workload'],coord)
runner.coord_cfg = coord
runner._initial_runtime_pending = True
runner._service_profiles = runner._load_ieee_service_profiles()
runner._load_ieee_preparation_profiles()
shell = ROOT/'scripts/ieee_tc/run_d293_7b_prefetch_validation_100.sh'
body = shell.read_text()
assert 'export FAASLORA_TC_REPLAY_PROFILE=W1' in body.split('if [[ "${1:-d293}" == d533 ]]; then')[1].split('fi')[0]
assert full_paths[1].name in body.split('  d533)')[1].split(';;')[0]
source_path = next(line.split('=',1)[1] for line in body.splitlines() if line.startswith('export FAASLORA_SHARED_TRACE_PATH='))
prime_plan = FrozenReplayPlan.load(source_path,profile='W1')
assert prime_plan.entries == plan.entries and prime_plan.source_sha256 == plan.source_sha256
assert prime_plan.identity()['view_sha256'] == plan.identity()['view_sha256']
for script in (shell,RESULTS/'vllm_qualification/d532_20261015/run7b.sh'):
    subprocess.run(['bash','-n',str(script)],check=True)
for repo in (ROOT,BASE): subprocess.run(['git','diff','--check'],cwd=repo,check=True)

loader = unittest.defaultTestLoader
suite = loader.loadTestsFromNames(['tests.test_ieee_tc_external_replay','tests.test_tc_serverless_qualification_population'])
test_path = BASE/'tests/test_ieee_tc_serverless_measurement.py'
spec = importlib.util.spec_from_file_location('d531_baseline_tests',test_path)
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
for name in ('W1ReplayViewTests','AdapterCoverageViewTests','IngressContractTests','PhysicalPoolBridgeTests','PreReadyIngressTests'):
    suite.addTests(loader.loadTestsFromTestCase(getattr(module,name)))
with (RAW/'tests.log').open('x') as log:
    tests = unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
import torch
assert not torch.cuda.is_initialized()
refs = [Path(__file__),cfg_path,old_path,native_path,test_path,shell,*full_paths,
    ROOT/'faaslora/datasets/workload_generator.py',BASE/'scripts/prepare_ieee_tc_serverless_stack.py',
    BASE/'scripts/replay_vllm_engine_trace.py',ROOT/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',
    ROOT/'tests/test_tc_serverless_qualification_population.py',ROOT/'tests/test_ieee_tc_external_replay.py',
    ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
record = dict(passed=tests.wasSuccessful() and not tests.skipped,tests=tests.testsRun,
    failures=len(tests.failures),errors=len(tests.errors),skipped=len(tests.skipped),
    scope=identity,gate=gate,protected=protected,preserved={str(k):v for k,v in preserved.items()},
    http_plan=plan.identity(),prime_plan=prime_plan.identity(),phases=phases,
    requests=4000,unique_adapter_ids=len({r['adapter_id'] for r in contracts.values()}),
    target_tokens=sum(r['target_tokens'] for r in contracts.values()),
    all_source_prompt_adapter_target_unchanged=True,full_non_path_config_equal=True,
    exact_full_profiles_loaded=True,native_vllm_config_unchanged=True,
    new_inputs_generated=False,gpu_run_started=False,live_entry_execution_qualified=False,
    numerical_correctness_qualified=False,refs={str(path):p.digest(path) for path in refs})
save(RAW/'qualification.json',record)
assert record['passed']
PUB.mkdir(parents=True,exist_ok=False)
save(PUB/'qualification.json',record)
print(json.dumps({k:record[k] for k in ('passed','tests','requests','target_tokens','phases','gpu_run_started')}))
