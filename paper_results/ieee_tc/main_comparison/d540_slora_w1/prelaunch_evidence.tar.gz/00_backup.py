"""D540 prelaunch checkpoint, reusing D531 source checks and D530 explicit backup."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/main_comparison/d540_slora_w1'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
identity=p.scope_identity(p.cg_path().name)
save(RAW/'backup_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
previous=read(RAW.parent.parent/'serverless_qualification/d539_20261015/publication_receipt.json')
assert previous['passed'] and git('rev-parse','HEAD')==previous['head']
assert git('branch','--show-current')=='retry14_continuous_queue_v2'
assert not git('diff','--cached','--name-only')
binding_path=RAW/'qualification.json'
binding=read(binding_path)
assert binding['passed'] and binding['tests_returncode']==0
assert 'Ran 51 tests' in (RAW/'cpu_contract_tests.log').read_text()
assert len(binding['ast_equal'])==16 and all(binding['ast_equal'].values())
for path,sha in binding['refs'].items():assert p.digest(Path(path))==sha,path
for name in ('reuse','qualification'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
assert not git('diff','--name-only','HEAD','--','scripts','faaslora','tests','configs/ieee_tc')
assert p.digest(ROOT/'configs/generated/lora_manifest_1000.json')=='3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'
assert p.digest(BASE/'scripts/replay_openai_trace.py')=='04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'
assert p.digest(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh')=='337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'
files=sorted([*RAW.glob('*.py'),*RAW.glob('*.sh'),*RAW.glob('*.json'),*RAW.glob('*.log'),RAW/'source_view/measurement_manifest.json'])
files += [RAW/'source_view'/name for name in read(RAW/'source_view/measurement_manifest.json')['measured_sha256']]
for path in files:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert not token or token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
OUT.mkdir(parents=True,exist_ok=False)
members={}
with tarfile.open(OUT/'prelaunch_evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<2*1024*1024;clean(data)
        name=f'{i:02d}_{path.name}'
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'prelaunch_evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
save(OUT/'prelaunch.json',dict(passed=True,reused_qualification=dict(path=str(binding_path),sha256=p.digest(binding_path),tests=51),
    baseline_execution_checkpoint=subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip(),
    source_sha256={str(path):p.digest(path) for path in files},archive_members=members,
    archive_sha256=p.digest(OUT/'prelaunch_evidence.tar.gz'),protected=protected,
    no_serving_change=True,no_new_inputs=True,performance_started=False))
paths=['docs/ieee_tc/D540_SLORA_W1.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(ROOT)) for name in ('prelaunch.json','prelaunch_evidence.tar.gz')]
for name in paths:
    data=(ROOT/name).read_bytes();assert len(data)<2*1024*1024
    if not name.endswith('.tar.gz'):clean(data)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['git','add','--',*paths],cwd=ROOT,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for name in paths:
    assert hashlib.sha256(subprocess.check_output(['git','show',':'+name],cwd=ROOT)).hexdigest()==p.digest(ROOT/name)
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','tc: preregister unchanged S-LoRA W1 native configuration (D540)'],cwd=ROOT,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=ROOT,check=True)
head=git('rev-parse','HEAD')
assert git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]==head
save(RAW/'backup_receipt.json',dict(passed=True,head=head,remote_equal=True,scope=identity,files=paths,
    qualified_tests=51,source_manifest_sha256=p.digest(OUT/'prelaunch.json')))
print(json.dumps(dict(passed=True,head=head,files=paths)))
