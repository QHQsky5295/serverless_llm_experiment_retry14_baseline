"""D540: check retained S-LoRA qualification before the new W1 key; no GPU."""
import json, os, subprocess, sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from prepare_ieee_tc_serverless_stack import load_http_replay_plan
from replay_vllm_engine_trace import validate_native_service_config, verify_slora_source_view
def read(x):return json.loads(x.read_text())
def save(x,v):
    with x.open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);g=Path(identity['path'])
save(RAW/'reuse_identity.json',identity)
assert (g/'memory.high').read_text().strip()==str(3*p.GIB)
assert (g/'memory.max').read_text().strip()==str(4*p.GIB)
assert (g/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
cfgpath=BASE/'configs/ieee_tc/slora_7b_resident_native_v1.json'
cfg=read(cfgpath);assert p.digest(cfgpath)=='2dd3a7415c5b00f0bbcf6ac7b31906da4399285e6df824ba270988015c72ae5d'
old=RAW.parent/'d435_20261011'
http=read(old/'http_7b_4000.json')
http.update(request_view='trace_w1_v1',replay_profile='W1',experiment_role='full_w1_baseline_observation')
validate_native_service_config(cfg,http)
plan=load_http_replay_plan(http)
assert plan.identity()['view_sha256']=='103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
assert len(plan.entries)==4000
rows=[json.loads(e.source_json) for e in plan.entries]
assert len({r['adapter_id'] for r in rows})==132 and sum(min(r['expected_output_tokens'],256) for r in rows)==458224
view=Path(cfg['source_view']);manifest=read(view/'measurement_manifest.json')
differences=[]
for path,expected in ((Path(manifest['helper_path']),manifest['helper_sha256']),
 (BASE/'scripts/prepare_ieee_tc_serverless_stack.py',manifest['source_adapter_sha256'])):
    actual=p.digest(path)
    if actual!=expected:differences.append(dict(path=str(path),expected=expected,actual=actual))
for key,root in (('original_sha256',Path(manifest['native_source'])),('measured_sha256',view),('shared_source_sha256',MAIN)):
    for name,expected in manifest[key].items():
        actual=p.digest(root/name)
        if actual!=expected:differences.append(dict(path=str(root/name),expected=expected,actual=actual))
try:
    verify_slora_source_view(dict(cfg,main_repo=str(MAIN)));source_pass=True;error=None
except ValueError as exc:
    source_pass=False;error=str(exc)
save(RAW/'reuse_inspection.json',dict(passed=True,native_config_unchanged=True,source_view_reusable=source_pass,
    source_error=error,differences=differences,input_identity=plan.identity(),target_tokens=458224,
    actual_unique_adapters=132,identity=identity,no_gpu_run=True,no_runtime_change=True,
    refs={str(x):p.digest(x) for x in (cfgpath,view/'measurement_manifest.json',old/'http_7b_4000.json',Path(__file__))}))
save(RAW/'http_7b_4000.json',http)
print(json.dumps(dict(passed=True,source_view_reusable=source_pass,source_error=error,differences=differences,input_identity=plan.identity())))
