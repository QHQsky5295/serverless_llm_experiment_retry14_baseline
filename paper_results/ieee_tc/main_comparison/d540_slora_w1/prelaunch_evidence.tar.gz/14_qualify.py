"""Refresh only the S-LoRA measurement-view identity; reuse native qualified code."""
import ast, json, os, subprocess, sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from prepare_ieee_tc_serverless_stack import prepare_slora_measurement_view, load_http_replay_plan
from replay_vllm_engine_trace import validate_native_service_config, verify_slora_source_view
def read(x):return json.loads(x.read_text())
def save(x,v):
    with x.open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);g=Path(identity['path'])
save(RAW/'qualification_identity.json',identity)
assert (g/'memory.high').read_text().strip()==str(3*p.GIB)
assert (g/'memory.max').read_text().strip()==str(4*p.GIB)
assert (g/'memory.swap.max').read_text().strip()=='0' and os.sched_getaffinity(0)=={2,3,26,27}
assert os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
prior=read(RAW/'reuse_inspection.json');assert prior['passed'] and len(prior['differences'])==2
assert not Path(read(RAW/'reuse_closure.json')['identity']['path']).exists()
oldcommit='cae13c57c012ea55a8199740f2696b9db732362f'
def nodes(source):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
ast_checks={}
for relative,prefixes,extra in (
 ('scripts/ieee_tc_serverless_measurement.py',('slora_','_slora_'),()),
 ('scripts/prepare_ieee_tc_serverless_stack.py',('slora_',),('prepare_slora_measurement_view',)),
 ('scripts/replay_vllm_engine_trace.py',('slora_',),('validate_slora_service_config','verify_slora_source_view'))):
    old=nodes(subprocess.check_output(['git','show',oldcommit+':'+relative],cwd=BASE,text=True))
    current=nodes((BASE/relative).read_text())
    selected=[n for n in old if n.startswith(prefixes) or n in extra]
    assert selected
    for name in selected:
        equal=old[name]==current.get(name);ast_checks[relative+':'+name]=equal
        assert equal,name
cfgpath=BASE/'configs/ieee_tc/slora_7b_resident_native_v1.json';cfg=read(cfgpath)
oldmanifest=read(Path(cfg['source_view'])/'measurement_manifest.json')
view=RAW/'source_view'
newmanifest=prepare_slora_measurement_view(BASE/'repos/S-LoRA',view,MAIN,
    host_layout=cfg['host_layout'],worker_lifecycle=True)
assert newmanifest['measured_sha256']==oldmanifest['measured_sha256']
assert newmanifest['original_sha256']==oldmanifest['original_sha256']
newcfg=dict(cfg,source_view=str(view),source_view_manifest_sha256=p.digest(view/'measurement_manifest.json'))
assert {k for k in cfg if cfg[k]!=newcfg[k]}=={'source_view','source_view_manifest_sha256'}
save(RAW/'native_7b.json',newcfg)
http=read(RAW/'http_7b_4000.json')
validate_native_service_config(newcfg,http);verify_slora_source_view(dict(newcfg,main_repo=str(MAIN)))
plan=load_http_replay_plan(http)
assert plan.identity()['view_sha256']=='103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
command=[sys.executable,'-B','-m','unittest','tests.test_ieee_tc_slora_measurement','tests.test_ieee_tc_slora_service','-v']
with (RAW/'cpu_contract_tests.log').open('x') as log:
    result=subprocess.run(command,cwd=BASE,stdout=log,stderr=subprocess.STDOUT)
save(RAW/'qualification.json',dict(passed=result.returncode==0,tests_returncode=result.returncode,command=command,
    identity=identity,ast_equal=ast_checks,native_source_unchanged=True,native_config_values_unchanged=True,
    measured_source_sha256_equal=True,new_source_view=str(view),source_view_sha256=p.digest(view/'measurement_manifest.json'),
    native_config_sha256=p.digest(RAW/'native_7b.json'),input_identity=plan.identity(),
    preparation_reason='Common helpers gained other backends and explicit W1; old guarded view no longer matches whole helper SHA. Native S-LoRA functions and generated code unchanged.',
    no_gpu_run=True,no_performance_tuning=True,source_plan_sha256=p.check_plan(),
    refs={str(x):p.digest(x) for x in (Path(__file__),RAW/'inspect_reuse.py',cfgpath,RAW/'http_7b_4000.json',RAW/'cpu_contract_tests.log')}))
assert result.returncode==0
print(json.dumps(dict(passed=True,ast_checks=len(ast_checks),same_measured_source=True,view=str(view))))
