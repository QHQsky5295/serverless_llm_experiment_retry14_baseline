"""Reuse bounded explicit-path curation/publication for an invalid resource run.

Never promotes D540 to success or overwrites its original qualification files.
"""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=MAIN/'paper_results/ieee_tc/main_comparison/d540_slora_w1/failure1'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=MAIN,text=True).strip()
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'publication_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert git('rev-parse','HEAD')=='bcd79b3fa88e54926cb25829e348d6b0841dffd1'
assert not git('diff','--cached','--name-only')
assert not git('diff','--name-only','HEAD','--','faaslora','scripts','tests','configs/ieee_tc')
record=read(RAW/'failure_diagnostic.json')
assert record['performance_ranking_eligible'] is False and record['physical_gpu_seconds'] is None
assert record['request_summary']['counts']['N_response']==4000
assert record['request_summary']['counts']['N_failed']==0
assert record['original_qualification_passed'] is False
for ref in record['refs']:assert p.digest(Path(ref['path']))==ref['sha256']
binding=read(RAW/'qualification.json')
assert binding['passed'] and binding['tests_returncode']==0
assert 'Ran 51 tests' in (RAW/'cpu_contract_tests.log').read_text()
for path,sha in binding['refs'].items():assert p.digest(Path(path))==sha
for name in ('analysis',):
    closure=read(RAW/(name+'_closure.json'))
    assert closure['passed'] and closure['actual_recursive_procs_empty'] and closure['path_gone']
    assert not Path(closure['identity']['path']).exists()
protected=p.verify_seal(RAW.parent/'d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
preserved={str(MAIN/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
files=[RAW/name for name in ('run_failure_analysis.py','publish_failure.py','close.py',
    'close_launch.py','preserve_evidence.py','stop_remote.sh','launch7b.json','local_cleanup.json',
    'analysis_identity.json','analysis_receipt.json','analysis_closure.json','remote_stop.log',
    'evidence_copy_receipt.json','input_identity.json','qualification.json')]
files += [RAW/'launch7b.launch/service.log',RAW/'model7b/physical/summary.json',
    MAIN/'faaslora/metrics/metrics_collector.py',MAIN/'tests/test_ieee_tc_gpu_lifecycle.py',
    MAIN/'docs/ieee_tc/D540_SLORA_W1_RESULT.md']
files += sorted((RAW/'model7b/physical_allocations').glob('*.jsonl'))
files += sorted((RAW/'model7b/worker_receipts').glob('*.json'))
OUT.mkdir(parents=True,exist_ok=False)
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<4*1024*1024;clean(data)
        if path.suffix=='.py':ast.parse(data)
        name=f'{i:02d}_{path.name}'
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
with (OUT/'diagnostic.json').open('xb') as f:f.write((RAW/'failure_diagnostic.json').read_bytes())
save(OUT/'manifest.json',dict(passed=True,experiment_passed=False,performance_ranking_eligible=False,
    reason='Complete request journal, one missing physical allocator release after select FD range error.',
    execution_identity=read(RAW/'input_identity.json'),scope=identity,
    original_status_unchanged=True,reused_cpu_tests=51,qualified_gpu_seconds=None,
    source_refs=record['refs'],archive_members=members,protected=protected,preserved=preserved,
    outputs={name:p.digest(OUT/name) for name in ('diagnostic.json','evidence.tar.gz')}))
with (OUT/'result.sha256').open('x') as f:
    for name in ('diagnostic.json','manifest.json','evidence.tar.gz'):
        f.write(p.digest(OUT/name)+'  '+name+'\n')
paths=['docs/ieee_tc/D540_SLORA_W1_RESULT.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(MAIN)) for name in ('diagnostic.json','manifest.json','evidence.tar.gz','result.sha256')]
for name in paths:
    data=(MAIN/name).read_bytes();assert len(data)<2*1024*1024
    if not name.endswith('.tar.gz'):clean(data)
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
subprocess.run(['git','diff','--check'],cwd=MAIN,check=True)
subprocess.run(['git','add','--',*paths],cwd=MAIN,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
for name in paths:assert subprocess.check_output(['git','show',':'+name],cwd=MAIN)==(MAIN/name).read_bytes()
subprocess.run(['git','diff','--cached','--check'],cwd=MAIN,check=True)
subprocess.run(['git','commit','-m','tc: preserve S-LoRA W1 request results and failed lifecycle evidence (D540)'],cwd=MAIN,check=True)
subprocess.run(['git','push','faaslora_origin','retry14_continuous_queue_v2'],cwd=MAIN,check=True)
head=git('rev-parse','HEAD')
assert git('ls-remote','faaslora_origin','refs/heads/retry14_continuous_queue_v2').split()[0]==head
save(RAW/'publication_receipt.json',dict(passed=True,head=head,files=paths,remote_equal=True,scope=identity))
print(json.dumps(dict(passed=True,experiment_passed=False,head=head,files=len(paths))),flush=True)
