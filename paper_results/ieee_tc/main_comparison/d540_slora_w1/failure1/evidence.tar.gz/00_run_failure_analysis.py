"""Reuse existing D537 collection and request analyzer after D540 teardown failure.

Request diagnostics only: the missing allocator release is not reconstructed.
This is not a full native/remote/resource qualification or a comparative result.
"""
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
sys.path[:0] = [str(MAIN), str(BASE/'scripts'), str(MAIN/'scripts/ieee_tc')]
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'analysis_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
closed = read(RAW/'local_cleanup.json')
assert closed['passed'] and closed['actual_recursive_procs_empty']
assert not Path(closed['service_identity']['path']).exists()
assert not Path(closed['auxiliary_identity']['path']).exists()
stop = (RAW/'remote_stop.log').read_text()
assert stop.count('ActiveState=inactive') == stop.count('MainPID=0') == 3
with (RAW/'collection1.log').open('x') as log:
    subprocess.run([sys.executable, str(RAW/'preserve_evidence.py')],
                   stdout=log, stderr=subprocess.STDOUT, check=True)

from summarize_serverlessllm_replay import audit_tc_http_journal
from audit_d402_serverlessllm_path import frozen_slo_summary, timing_stats
replay = RAW/'launch7b.launch/replay.jsonl'
summary = audit_tc_http_journal(replay)
assert summary['counts']['N_response'] == 4000 and summary['counts']['N_failed'] == 0
assert summary['actual_native_output_tokens'] == 458224 and summary['workload_passed']
qualifier = read(RAW/'model7b/model_qualification.json')
physical = read(RAW/'model7b/physical/summary.json')
assert qualifier['passed'] is False and qualifier['physical_release_errors'] == ['filedescriptor out of range in select()']
assert not physical['measurement_complete'] and physical['gpu_seconds'] is None
assert len(physical['open_lease_ids']) == 1 and physical['n_native_contract_complete'] == 4000
observations = {}
for line in replay.open():
    row = json.loads(line)
    if row['event'] == 'http_raw_response':
        assert row['request_id'] not in observations
        observations[row['request_id']] = row['body']['metrics']['ieee_tc']
assert len(observations) == 4000
freeze_path = MAIN/'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json'
freeze = read(freeze_path)
assert p.digest(freeze_path) == '2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3'
rows = summary.pop('diagnostic_rows')
summary.pop('assignment_gaps_s', None)
summary['conditional_metrics']['tpot_ms'] = timing_stats(
    [r['tpot_ms'] for r in rows if r['status'] == 'http_response' and r['actual_tokens'] > 1])
phase_rows = sorted(rows, key=lambda r: r['planned_arrival_s'])
refs = [Path(__file__), replay, RAW/'model7b/model_qualification.json',
        RAW/'model7b/physical/summary.json', RAW/'launch7b.json', RAW/'local_cleanup.json',
        RAW/'remote_stop.log', RAW/'evidence_copy_receipt.json', freeze_path,
        MAIN/'faaslora/metrics/metrics_collector.py',
        BASE/'scripts/summarize_serverlessllm_replay.py',
        MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py']
result = dict(schema='d540_closed_request_diagnostic_v1', scope=identity,
    display_name='S-LoRA', original_qualification_passed=False,
    original_classification=read(RAW/'launch7b.json')['classification'],
    reuse_class='request_diagnostic_only_resource_incomplete',
    performance_ranking_eligible=False, full_affected_path_qualified=False,
    independent_numerical_correctness=False, n_correct=None,
    physical_gpu_seconds=None, physical_summary=physical,
    common_slo=frozen_slo_summary(rows, observations, freeze['groups']),
    phase_joint=[frozen_slo_summary(phase_rows[i:i+500], observations, freeze['groups'])['joint_good']
                 for i in range(0, 4000, 500)],
    request_summary=summary,
    limitations=['All request metrics are diagnostics, not full native/resource qualification.',
                 'One actual allocator release is missing; no idle timestamp or guessed release inserted.',
                 'The original failed launch and right-censored resource ledger remain unchanged.',
                 'Not a baseline comparison, unseen evaluation or system optimum.'],
    refs=[dict(path=str(path), sha256=p.digest(path)) for path in refs])
save(RAW/'failure_diagnostic.json', result)
save(RAW/'analysis_receipt.json', dict(passed=True, diagnostic_only=True, identity=identity,
    output_sha256=p.digest(RAW/'failure_diagnostic.json'),
    resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}))
print(json.dumps(dict(passed=True, diagnostic_only=True, counts=summary['counts'],
    common_slo=result['common_slo'], metrics=summary['conditional_metrics'],
    phase_joint=result['phase_joint'], physical_gpu_seconds=None)), flush=True)
