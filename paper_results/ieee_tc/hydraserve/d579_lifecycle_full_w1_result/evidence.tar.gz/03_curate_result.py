"""Reuse bounded D539 curation for complete D579 native W1 evidence."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("save(RAW/'curation_identity.json',identity)","save(RAW/'result_identity.json',identity)")
replace("save(RAW/'curation_receipt.json'","save(RAW/'result_receipt.json'")
replace("((RAW,'review'),(CLEAN,'cleanup'))", "tuple((RAW,n) for n in ('prepare','remote_prelaunch','audit','output_comparison'))")
old=source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old,"""review=read(RAW/'full_w1_evaluation.json')
assert review['full_audit_pass'] and review['n_v1_contract_complete']==4000 and review['n_failed']==0
assert review['native_output_tokens']==458224 and review['raw_n_correct_preserved'] is None
assert review['n_joint']==1977 and not review['observed_w1_g1_feasible']
join=read(RAW/'same_backend_output_comparison.json')
assert join['passed_contract_match'] and join['n']==4000
assert join['equal_output_sequences']==3935 and join['changed_sequences']==65
assert read(RAW/'closure.json')['actual_recursive_empty']
assert not Path(read(RAW/'closure.json')['service']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
for path,record in read(RAW/'source_manifest.json').items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
for path,sha in review['source_sha256'].items():assert p.digest(Path(path))==sha,path
comparison=read(RAW/'old_new_w1_comparison.json')
assert comparison['native_worker_count']==19 and comparison['final_scheduler_instance_count']==4
for path,sha in comparison['sources'].items():assert p.digest(Path(path))==sha,path
workers=[read(path) for path in sorted((RAW/'platform').glob('d579-w*.native-request.json'))]
allocations=[json.loads(line) for line in (RAW/'physical/container_allocations.jsonl').read_text().splitlines()]
spawn={e['worker_name']:e for e in allocations if e['event']=='worker_spawn'}
assert len(workers)==len(spawn)==19 and set(spawn)=={w['name'] for w in workers}
assert all(w['env']['PP_SIZE']=='1' and w['env']['BATCH_SIZE']=='8' for w in workers)
""")
old=source[source.index('specs=['):source.index('reports=[]')]
replace(old,"""names=('audit.py','run_audit.py','compare_outputs.py','curate_result.py','close_result.py',
 'preregistration.json','source_manifest.json','reuse_inspection.json','prepare_result.json',
 'prelaunch_gate.json','remote_health.json','result.json','closure.json','remote_stop.json',
 'remote_stop.log','external_terminal_summary.json','http_audit.json','full_w1_evaluation.json',
 'full_w1_slo_rows.json','request_metrics.json','same_backend_output_comparison.json',
 'old_new_w1_comparison.json','native_scheduler_after_requests.json',
 'native_admission_capacity.json','generation_result.json','audit_identity.json','audit_closure.json',
 'output_comparison_identity.json','output_comparison_closure.json','remote_transfers.jsonl')
files=[RAW/n for n in names]
files += [RAW/'physical/container_allocations.jsonl',RAW/'physical/summary.json',
 RAW/'launch_gate.launch/exec_receipt.json',original,RAW.parent/'d503_20261013/audit.py',
 RAW.parent/'d509_20261013/compare_outputs.py',RAW.parent/'d576_20261016/compare_outputs.py',
 RAW.parent/'d570_20261016/close.py',ROOT/'docs/ieee_tc/D579_HYDRASERVE_LIFECYCLE_FULL_W1_RESULT.md']
files += sorted((RAW/'platform').glob('d579-w*.native-request.json'))
files += sorted((RAW/'remote_artifacts/receipts').glob('*.json'))
copies={n:RAW/n for n in ('full_w1_evaluation.json','old_new_w1_comparison.json',
 'same_backend_output_comparison.json','full_w1_slo_rows.json','request_metrics.json',
 'closure.json','remote_stop.json')}
specs=[('hydraserve/d579_lifecycle_full_w1_result',files,copies)]
""")
replace('new_gpu_run=False','new_gpu_run=True')
replace('Executed assertions plus source AST and archive round-trip; no new serving change or repeated GPU tests',
 'One complete known-trace W1 replay; full native input/output/remote/clock/physical audit, all4000 old/new input joins, 65 changed output sequences retained; independent numerical qualification unknown; D573 CPU71 and D574 native100 qualification reused; AST and archive SHA roundtrip')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate_result.py'),'original':original})
