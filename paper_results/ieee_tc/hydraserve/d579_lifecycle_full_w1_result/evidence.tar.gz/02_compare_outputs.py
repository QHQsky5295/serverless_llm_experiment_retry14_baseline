"""Reuse D576 full native input/output comparison for D579 versus D546 W1."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d576_20261016/compare_outputs.py'
assert sha256(original.read_bytes()).hexdigest()=='9dc5d1ceb564cb6c2e51dca1a222ddc63ce5c997187b0ecd6f6ccefe7c88a689'
source=original.read_text().replace('d510_20261013','d546_20261015').replace('full_w0','full_w1').replace('old_new_w0','old_new_w1').replace('D576','D579').replace('D510','D546').replace('W0','W1')
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("workers = json.loads((RAW/'native_scheduler_after_requests.json').read_text())['instances']",
"""final_instances=json.loads((RAW/'native_scheduler_after_requests.json').read_text())['instances']
worker_paths=sorted((RAW/'platform').glob('d579-w*.native-request.json'))
workers=[json.loads(path.read_text()) for path in worker_paths]
allocations=[json.loads(line) for line in (RAW/'physical/container_allocations.jsonl').read_text().splitlines()]
spawn={e['worker_name']:e for e in allocations if e['event']=='worker_spawn'}
assert workers and len(workers)==len(spawn) and set(spawn)=={w['name'] for w in workers}
assert all(w['env']['PP_SIZE']=='1' and w['env']['BATCH_SIZE']=='8' for w in workers)""")
replace("native_worker_count=len(workers), all_pp1=all(i['pp_size']==1 for i in workers),",
"native_worker_count=len(workers), final_scheduler_instance_count=len(final_instances), all_pp1=all(w['env']['PP_SIZE']=='1' for w in workers),")
replace("RAW/'native_scheduler_after_requests.json')})",
"RAW/'native_scheduler_after_requests.json',RAW/'physical/container_allocations.jsonl',*worker_paths)})")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'compare_outputs.py')})
