"""Reuse D509 native input/output join for D576 versus the old full D510 W0."""
import hashlib
import json
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent/'d509_20261013/compare_outputs.py'
source = original.read_text()
def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)
replace("OLD=RAW.parent/'d503_20261013'", "OLD=RAW.parent/'d510_20261013'")
replace("assert json.loads((RAW/'affected_qualification.json').read_text())['passed']",
        "assert json.loads((RAW/'full_w0_evaluation.json').read_text())['full_audit_pass']")
replace('len(contracts)==len(outputs)==100', 'len(contracts)==len(outputs)==4000')
replace('new_run=str(RAW),n=100,', 'new_run=str(RAW),n=4000,')
replace('equal_output_sequences=100-len(changes)', 'equal_output_sequences=4000-len(changes)')
replace('native LoRA capacity and lifecycle adaptation changed; no independent reference, no 4000-request performance extrapolation',
        'D573 platform lifecycle-lock adaptation only; same frozen native policy/config/input; single full known-trace observations, not independent numerical qualification or statistical causal estimate')
scope = {'__name__': '__main__', '__file__': str(RAW/'compare_outputs.py')}
exec(compile(source, str(original), 'exec'), scope)

old_dir = RAW.parent/'d510_20261013'
old = json.loads((old_dir/'full_w0_evaluation.json').read_text())
new = json.loads((RAW/'full_w0_evaluation.json').read_text())
assert old['full_audit_pass'] and new['full_audit_pass']
assert old['native_output_tokens'] == new['native_output_tokens'] == 458224
assert old['references']['slo_eval'] == new['references']['slo_eval']
fields = ['joint_slo', 'ttft_attainment', 'tpot_conditional_attainment',
          'physical_gpu_seconds', 'gpu_seconds_per_v1_contract_request']
rows = []
for name in fields:
    a, b = old[name], new[name]
    high = name.endswith('attainment') or name == 'joint_slo'
    rows.append(dict(metric=name, old=a, new=b, new_minus_old=b-a,
        relative_improvement=(b-a)/a if high else (a-b)/a,
        percentage_point_change=100*(b-a) if high else None))
for name in new['metrics']:
    for stat in ('mean', 'p95'):
        a, b = old['metrics'][name][stat], new['metrics'][name][stat]
        rows.append(dict(metric=name+'.'+stat, old=a, new=b,
            new_minus_old=b-a, relative_improvement=(a-b)/a if a else None))
workers = json.loads((RAW/'native_scheduler_after_requests.json').read_text())['instances']
result = dict(passed=True, n=4000, comparisons=rows,
    native_worker_count=len(workers), all_pp1=all(i['pp_size']==1 for i in workers),
    unchanged_native_policy=True, independent_numerical_qualification=False,
    statistical_or_isolated_causal_claim=False,
    interpretation='Single full W0 observations do not establish a lifecycle-lock performance improvement; preserve both outcomes and continue affected workload matrix without winner selection.',
    sources={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in
        (original, RAW/'compare_outputs.py', RAW/'same_backend_output_comparison.json',
         old_dir/'full_w0_evaluation.json', RAW/'full_w0_evaluation.json',
         RAW/'native_scheduler_after_requests.json')})
with (RAW/'old_new_w0_comparison.json').open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
print(json.dumps(result))
