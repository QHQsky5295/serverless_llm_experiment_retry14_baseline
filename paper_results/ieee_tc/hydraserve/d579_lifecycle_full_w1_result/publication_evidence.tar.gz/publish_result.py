"""Reuse D576 explicit-path result checkpoint for D579 full W1."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d576_20261016/publish_result.py'
source=original.read_text()
for old,new in (
 ('D576','D579'),('d576','d579'),('W0','W1'),('full_w0','full_w1'),
 ('old_new_w0_comparison_v2','old_new_w1_comparison'),
 ('fb03630b9ffa8e3f38a5056e964db585cc8c41a7','5561d2a3e53bb9288f3624adac3b7ed816339429'),
 ("audit['n_joint']==2729","audit['n_joint']==1977"),
 ("['native_worker_count']==35","['native_worker_count']==19")):
    assert old in source,old
    source=source.replace(old,new)
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish_result.py')})
