"""Preserve and close the empty pre-identity publication-wrapper failure only."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
identity=p.scope_identity('primelora-tc-aux-d5790000000000000000000000000010.scope')
group=Path(identity['path'])
assert p.scope_still_owned(identity)
members={str(path):path.read_text().split() for path in group.rglob('cgroup.procs')}
assert members and all(not values for values in members.values())
resources={key:(group/key).read_text().strip() for key in ('memory.peak','memory.events','memory.swap.current')}
assert not (RAW/'result_publication_identity.json').exists()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd='/home/qhq/serverless_llm_experiment_retry14_baseline',text=True).strip()
failure=dict(passed=False,phase='publication_wrapper_expansion_before_identity_or_git',
    error='AssertionError: d576',reason='D576 template contains uppercase D576 but no lowercase d576; optional replacement was incorrectly asserted present',
    source_sha256=p.digest(RAW/'publish_result.py'),identity=identity,
    experiment_or_analysis_repeated=False,performance_data_changed=False)
with (RAW/'publication_attempt1_failure.json').open('x') as f:json.dump(failure,f,indent=2)
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert not group.exists()
with (RAW/'publication_attempt1_closure.json').open('x') as f:
    json.dump(dict(passed=True,identity=identity,actual_recursive_procs_empty=True,path_gone=True,resources=resources),f,indent=2)
print(json.dumps(dict(passed=True,actual_closed=True,resources=resources)))
