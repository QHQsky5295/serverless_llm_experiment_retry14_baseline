"""Correct only the absent lowercase template token; preserve the first failure."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
previous=RAW/'publish_result.py'
source=previous.read_text()
old="('D576','D579'),('d576','d579'),('W0','W1'),"
assert source.count(old)==1
source=source.replace(old,"('D576','D579'),('W0','W1'),")
needle="exec(compile(source,str(original),'exec'),"
assert source.count(needle)==1
source=source.replace(needle,"""source=source.replace("'publish_result.py'", "'publish_result_v2.py'")
assert source.count("]+[original]")==1
source=source.replace("]+[original]", "]+[original,RAW/'publish_result.py',RAW/'publication_attempt1_failure.json',RAW/'publication_attempt1_closure.json',RAW/'close_failed_publication.py']")
exec(compile(source,str(original),'exec'),""")
exec(compile(source,str(previous),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish_result_v2.py')})
