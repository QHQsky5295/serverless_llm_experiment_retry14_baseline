"""Repeat changed CPU implementation, preserving the failed anchor test evidence."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'test_cancellation.py').read_text().replace('cancellation_test','cancellation_test_v2')
exec(compile(source,str(RAW/'test_cancellation.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'test_cancellation_v2.py')})
