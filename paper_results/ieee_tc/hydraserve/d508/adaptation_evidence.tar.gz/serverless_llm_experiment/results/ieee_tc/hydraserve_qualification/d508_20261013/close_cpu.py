"""Reuse exact-identity recursive-empty closure for D508 CPU work."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d507_20261013/close_postrun_cpu.py').read_text().replace('d507','d508')
exec(compile(source,str(RAW/'close_cpu_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'close_cpu.py')})
