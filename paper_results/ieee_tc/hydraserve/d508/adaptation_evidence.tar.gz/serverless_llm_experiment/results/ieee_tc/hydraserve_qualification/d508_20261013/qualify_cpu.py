"""Freeze and exercise D508 adaptations; no GPU or performance claims."""
from hashlib import sha256
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys
import urllib.request

RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime import native_delivery as nd,controller_runtime as cr
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2)
save('cpu_qualification_identity.json',p.scope_identity(p.cg_path().name))
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert json.loads((RAW/'cancellation_test_v2_result.json').read_text())['returncode']==0
sources={}
snap=RAW/'qualified_sources';snap.mkdir(exist_ok=False)
paths=['HydraServe_project/runtime/'+n+'.py' for n in
    ('http_contract','request_contract','native_delivery','controller_runtime')]
paths+=['tests/test_ieee_tc_hydraserve_'+n+'.py' for n in
    ('http_contract','request_contract','native_delivery')]
for name in paths:
    path=BASE/name;data=path.read_bytes();dest=snap/name.replace('/','_')
    with dest.open('xb') as f:f.write(data)
    sources[str(path)]=dict(snapshot=str(dest),sha256=sha256(data).hexdigest())
save('qualified_source_manifest.json',sources)
batch=nd.native_admission_batch(NATIVE)
assert batch==8
overlays=nd.render_overlays(NATIVE,request_contract=True,shm_control=True,lora_admission_capacity=True)
overlays.update(cr.render_controller_sources(NATIVE,control_observations=True,cancellation_ownership=True))
out=RAW/'qualified_overlays';out.mkdir(exist_ok=False)
overlay_manifest={}
for name,data in overlays.items():
    dest=out/name;dest.parent.mkdir(exist_ok=True,parents=True)
    with dest.open('xb') as f:f.write(data)
    overlay_manifest[name]=sha256(data).hexdigest()
save('qualified_overlay_manifest.json',overlay_manifest)
online={}
for filename in ('vllm/worker/worker.py','vllm/executor/gpu_executor.py'):
    url='https://raw.githubusercontent.com/LLMServe/HydraServe/8ae605de354ccfa2e9095514cdb4a9e9c56aa56b/'+filename
    with urllib.request.urlopen(url,timeout=20) as response:data=response.read(2000000)
    assert data==(NATIVE/filename).read_bytes()
    dest=RAW/('official_'+filename.replace('/','_'))
    with dest.open('xb') as f:f.write(data)
    online[filename]=dict(url=url,sha256=sha256(data).hexdigest())
modules=['tests.test_ieee_tc_hydraserve_'+n for n in
    ('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
     'tokenizer_compat','request_contract','native_delivery','isolated_platform','platform_port',
     'stage_binding','worker_binding','layer_identity')]
results={}
for label,python,selected in (
    ('cpu_full',sys.executable,modules),
    ('native_python',str(BASE/'installs/hydraserve_native_d484_20261013/bin/python'),modules[:1]+modules[6:8])):
    with (RAW/(label+'_tests.log')).open('x') as f:
        proc=subprocess.run([python,'-B','-m','unittest',*selected,'-v'],cwd=BASE,
            stdout=f,stderr=subprocess.STDOUT,timeout=40)
    results[label]=dict(returncode=proc.returncode,python=python,modules=selected,
        log_sha256=p.digest(RAW/(label+'_tests.log')))
    if proc.returncode:
        save('cpu_qualification_failure.json',results)
        raise RuntimeError(label+' CPU regression failed; original log retained')
assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
save('cpu_qualification.json',dict(passed=True,gpu_run=False,performance_result=False,
    native_admission_batch=batch,max_loras_formula='native Model.batch_size * current PP_SIZE',
    max_cpu_loras='native default None -> max_loras; no catalog-sized cache',
    startup_memory_scope='LoRA slot tensors allocated in load_model before native free-memory/KV calculation; actual concurrency/memory qualification still required',
    cancellation_scope='single iterator owner joined on cancellation; no instantaneous preemption claim',
    native_policy_changed=False,sources=sources,overlays=overlay_manifest,online_sources=online,tests=results,
    actual_controller_batch_check_required=True,full_replay_completed=False))
print(json.dumps(dict(passed=True,tests=results,gpu_run=False)))
