"""Bounded CPU-only ownership regression; not a GPU/performance experiment."""
import json
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
with (RAW/'cancellation_test_identity.json').open('x') as f:
    json.dump(p.scope_identity(p.cg_path().name),f,indent=2)
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
modules=['tests.test_ieee_tc_hydraserve_'+name for name in
    ('http_contract','request_contract','controller_runtime')]
with (RAW/'cancellation_test.log').open('x') as f:
    result=subprocess.run([sys.executable,'-B','-m','unittest',*modules,'-v'],
        cwd=BASE,stdout=f,stderr=subprocess.STDOUT,timeout=30)
with (RAW/'cancellation_test_result.json').open('x') as f:
    json.dump(dict(returncode=result.returncode,gpu_run=False,modules=modules,
        log_sha256=p.digest(RAW/'cancellation_test.log')),f,indent=2)
print((RAW/'cancellation_test.log').read_text())
raise SystemExit(result.returncode)
