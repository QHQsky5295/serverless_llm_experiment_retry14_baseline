"""Reuse checked explicit-file backup; no raw large logs or user files."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d508').replace('D480','D508')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['HydraServe_project/runtime/http_contract.py',
        'HydraServe_project/runtime/request_contract.py','HydraServe_project/runtime/native_delivery.py',
        'HydraServe_project/runtime/controller_runtime.py',
        'tests/test_ieee_tc_hydraserve_http_contract.py','tests/test_ieee_tc_hydraserve_request_contract.py',
        'tests/test_ieee_tc_hydraserve_native_delivery.py',
        'docs/ieee_tc/D508_HYDRASERVE_ADAPTATION_OWNERSHIP_CAPACITY.md',
        'paper_results/ieee_tc/hydraserve/d508/summary.json',
        'paper_results/ieee_tc/hydraserve/d508/adaptation_evidence.tar.gz']
    remote,branch='origin','main'
    smoke=['tests.test_ieee_tc_hydraserve_'+name for name in
        ('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
         'tokenizer_compat','request_contract','native_delivery','isolated_platform',
         'platform_port','stage_binding','worker_binding','layer_identity')]
'''+source[end:]
source=source.replace('qualify HydraServe native platform injection seam on CPU',
    'fix HydraServe cancellation ownership and derive native LoRA admission capacity')
exec(compile(source,str(template),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'backup.py')})
