"""Read-only D507 adaptation diagnosis; no GPU launch/config search/source mutation."""
import ast
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import urllib.request

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d507_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2)
save('audit_identity.json',p.scope_identity(p.cg_path().name))
assert json.loads((OLD/'failure_backup_baseline_receipt.json').read_text())['passed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert json.loads((OLD/'remote_stop.json').read_text())['all_owned_units_inactive']
official={}
for filename in ('vllm/core/scheduler.py','vllm/engine/arg_utils.py','vllm/config.py',
                 'scripts/kubernetes/vllm/src/scheduler.py'):
    url='https://raw.githubusercontent.com/LLMServe/HydraServe/8ae605de354ccfa2e9095514cdb4a9e9c56aa56b/'+filename
    with urllib.request.urlopen(url,timeout=20) as response:data=response.read(2000000)
    assert data==(NATIVE/filename).read_bytes(),filename
    path=RAW/('official_'+filename.replace('/','_'))
    with path.open('xb') as f:f.write(data)
    official[filename]=dict(url=url,sha256=sha256(data).hexdigest(),snapshot=str(path))
source=(NATIVE/'vllm/engine/arg_utils.py').read_text()
engine=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='EngineArgs')
defaults={n.target.id:ast.literal_eval(n.value) for n in engine.body if isinstance(n,ast.AnnAssign)
          and isinstance(n.target,ast.Name) and n.target.id in ('max_loras','max_cpu_loras','max_num_seqs')}
assert defaults==dict(max_num_seqs=256,max_loras=1,max_cpu_loras=None)
app=ast.parse((OLD/'overlays/scripts/image/app.py').read_text())
sites=[n for n in ast.walk(app) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
       and n.func.id in ('EngineArgs','AsyncEngineArgs') and any(k.arg=='enable_lora' for k in n.keywords)]
assert len(sites)==3
assert all(not any(k.arg in ('max_loras','max_cpu_loras') for k in n.keywords) for n in sites)
config=(NATIVE/'vllm/config.py').read_text()
assert 'self.max_cpu_loras = self.max_loras' in config
sched=(NATIVE/'vllm/core/scheduler.py').read_text()
assert 'len(curr_loras) >= self.lora_config.max_loras' in sched
assert 'leftover_waiting_sequences.appendleft(seq_group)' in sched
controller=(NATIVE/'scripts/kubernetes/vllm/src/scheduler.py').read_text()
assert 'batch_size: int = 8' in controller
failed=json.loads((OLD/'failure_requests.json').read_text())
first_timeout=min(r['client_completed_s'] for r in failed)
intervals={};count=0
with (OLD/'launch_gate.launch/replay.jsonl').open() as f:
    for line in f:
        row=json.loads(line)
        if row['event']!='http_raw_response' or row['client_completed_s']>=first_timeout:continue
        n=row['body']['metrics']['ieee_tc']
        worker=n['worker_proof']['worker_name']
        intervals.setdefault(worker,[]).append((n['native_first_token_monotonic_s'],
            n['native_last_token_monotonic_s'],n['native_adapter_id'],row['request_id']))
        count+=1
assert count==3632
observed={}
for worker,values in intervals.items():
    events=[]
    for start,end,adapter,rid in values:
        assert end>start
        events.extend([(start,1,adapter,rid),(end,0,adapter,rid)])
    active={};peak_distinct=peak_requests=0;cross_adapter_pairs=set()
    for at,kind,adapter,rid in sorted(events):
        if kind==0:
            assert active.pop(rid)==adapter
        else:
            for prior,other in active.items():
                if other!=adapter:cross_adapter_pairs.add(tuple(sorted((prior,rid))))
            active[rid]=adapter
            peak_requests=max(peak_requests,len(active))
            peak_distinct=max(peak_distinct,len(set(active.values())))
    assert not active
    observed[worker]=dict(n=len(values),peak_response_decode_overlap=peak_requests,
                         peak_distinct_adapter_decode_overlap=peak_distinct,
                         cross_adapter_decode_overlap_pairs=len(cross_adapter_pairs))
result=dict(readonly_diagnosis=True,gpu_run=False,native_sources=official,
    previous_baseline_checkpoint=json.loads((OLD/'failure_backup_baseline_receipt.json').read_text())['head'],
    engine_defaults=defaults,lora_enabled_sites=len(sites),sites_override_lora_capacity=False,
    effective_max_loras=1,effective_max_cpu_loras=1,native_controller_batch=8,
    pre_first_timeout_native_responses=count,per_worker_decode_overlap=observed,
    hypothesis='Per-request LoRA adaptation enabled native backend LoRA but inherited a one-adapter batch/cache limit, serializing different adapters beneath an eight-request native controller.',
    not_yet_proved='No intervention run yet; this establishes configured limit and observed overlap, not total speedup attribution.',
    candidate_principle='Derive native LoRA concurrency capacity from original per-instance admission capacity, subject to actual memory qualification; preserve official scheduler and replacement policy; no capacity sweep.',
    cancellation_hypothesis='Iterator next and close need one owner; cancellation cannot concurrently close a running worker-thread generator.',
    references=['https://docs.vllm.ai/en/v0.4.2/models/lora.html',
        'https://docs.python.org/3.10/reference/expressions.html#generator-iterator-methods',
        'https://anyio.readthedocs.io/en/stable/threads.html',
        'https://docs.aiohttp.org/en/stable/web_advanced.html#web-handler-cancellation'],
    sources={str(path):p.digest(path) for path in (Path(__file__),OLD/'failure_aware_evaluation.json',
        OLD/'launch_gate.launch/replay.jsonl',OLD/'overlays/scripts/image/app.py',
        BASE/'HydraServe_project/runtime/http_contract.py',BASE/'HydraServe_project/runtime/native_delivery.py')})
save('adaptation_diagnosis.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ('native_sources','sources','references')}))
