"""D508 CPU qualification checkpoint; reuse D499 archive/roundtrip implementation."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tarfile
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
qualification=json.loads((RAW/'cpu_qualification.json').read_text())
assert qualification['passed'] and not qualification['gpu_run']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for filename in ('audit_identity_closure.json','cancellation_test_identity_closure.json',
    'cancellation_test_v2_identity_closure.json','cpu_qualification_identity_closure.json'):
    assert json.loads((RAW/filename).read_text())['actual_recursive_empty']
for path,record in qualification['sources'].items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
assert 'Ran 100 tests' in (RAW/'cpu_full_tests.log').read_text()
assert 'Ran 36 tests' in (RAW/'native_python_tests.log').read_text()
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'];save(RAW/'protected_verification.json',protected)
paths=[Path(path) for path in qualification['sources']]
paths.append(BASE/'docs/ieee_tc/D508_HYDRASERVE_ADAPTATION_OWNERSHIP_CAPACITY.md')
paths += [x for x in RAW.iterdir() if x.is_file() and not x.is_symlink() and x.name!='curation.log']
for child in ('qualified_sources','qualified_overlays'):
    paths += [x for x in (RAW/child).rglob('*') if x.is_file() and not x.is_symlink()]
template=(RAW.parent/'d499_20261013/checkpoint.py').read_text()
body=template[template.index('paths=sorted(set(paths))'):template.index('summary=dict(')]
body=body.replace("hydraserve/d499'","hydraserve/d508'").replace('generation_release_evidence.tar.gz','adaptation_evidence.tar.gz')
exec(compile(body,'reused_d499_archive_roundtrip','exec'))
summary=dict(checkpoint_verified=True,performance_result=False,gpu_run=False,
    cpu_tests_passed=100,native_python_cpu_tests_passed=36,qualification=qualification,
    diagnosis=json.loads((RAW/'adaptation_diagnosis.json').read_text()),
    protected_verification=protected,source_manifest=manifest,archive_sha256=p.digest(archive),
    archive_bytes=archive.stat().st_size,
    next='New mixed-adapter/native-memory qualification then one full4000 HydraServe, all-baseline comparison, PrimeLoRA optimization')
save(dest/'summary.json',summary)
save(RAW/'curation_result.json',dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size,
    archive_sha256=p.digest(archive),summary_sha256=p.digest(dest/'summary.json')))
print(json.dumps(dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size)))
