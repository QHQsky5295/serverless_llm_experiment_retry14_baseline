"""Reuse D477/D478 bounded containers for a no-model IPC/HTTP witness.

Own loopback listener, private shared IPC, no CNI or host network changes. This
does NOT qualify HydraServe, pipeline source-IP identity, CUDA or LoRA arithmetic.
"""
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
OLD = RAW.parent/'d477_20261012'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path.insert(0, '/home/qhq/serverless_llm_baselines')

def save(name, value):
    with (RAW/name).open('x') as handle:
        json.dump(value, handle, indent=2)

identity = p.scope_identity(p.cg_path().name)
save('probe_identity.json', identity)
group = Path(identity['path'])
assert os.sched_getaffinity(0) == set(range(4,24)) | set(range(28,48))
assert (group/'memory.max').read_text().strip() == str(80*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == str(2*p.GIB)
gate = p.preflight([RAW], predicted_growth=512*p.MIB)
save('preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert json.loads((OLD/'container_affinity_attempt/container_context_closure.json').read_text())['passed']
runtime = Path('/run/user/1001/primelora-hydra-d477-proxy')
store = OLD/'container_proxy_attempt/container_storage'
assert runtime.is_dir() and runtime.stat().st_uid == os.getuid()
assert store.is_dir() and store.stat().st_uid == os.getuid()
(RAW/'empty_hooks').mkdir()
supervisor = group/'supervisor'
supervisor.mkdir()
(supervisor/'cgroup.procs').write_text(str(os.getpid()))
(group/'cgroup.subtree_control').write_text('+memory +pids')
env = {k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','LANG') if k in os.environ}
env.update(CONTAINERS_CONF=str(RAW/'containers.conf'), XDG_RUNTIME_DIR=str(runtime),
           REGISTRY_AUTH_FILE=str(RAW/'pull-auth.json'), CUDA_VISIBLE_DEVICES='')
base = ['podman','--root',str(store),'--runroot',str(runtime/'runroot'),
        '--storage-driver=vfs','--cgroup-manager=cgroupfs','--events-backend=file',
        '--runtime=/usr/bin/nvidia-container-runtime','--hooks-dir',str(RAW/'empty_hooks')]
commands, created, owners = [], [], {}
pause_owner, sentinel = None, None
result = dict(passed=False, kind='native_backbone_delivery_init_qualification',
              native_backend_qualified=False, performance_result=False,
              pipeline_peer_identity_qualified=False, gpu_started=False)

def call(tag, args, check=True, timeout=30):
    started = time.monotonic()
    with (RAW/(tag+'.stdout')).open('x') as out, (RAW/(tag+'.stderr')).open('x') as err:
        run = subprocess.run(base+args, env=env, stdout=out, stderr=err, timeout=timeout)
    commands.append(dict(tag=tag, args=args, returncode=run.returncode,
                         elapsed_s=time.monotonic()-started))
    print(json.dumps(dict(tag=tag, returncode=run.returncode)), flush=True)
    if check:
        assert run.returncode == 0, tag
    return (RAW/(tag+'.stdout')).read_text(), run.returncode

def inspect(name, tag):
    raw, _ = call(tag, ['inspect', name])
    state = json.loads(raw)[0]
    assert state['Config']['Labels']['org.primelora.campaign'] == 'd497'
    return state

def qualify_owner(name, tag):
    state = inspect(name, tag)
    assert state['State']['Running']
    pid = state['State']['Pid']
    owner = p.gpu_process_identity(pid)
    assert owner and owner['uid'] == os.getuid()
    child = Path(owner['cgroup'])
    assert group in child.parents
    assert owner['affinity'] == [2,3,26,27]
    limits = {k:(child/k).read_text().strip() for k in ('memory.max','memory.swap.max','pids.max')}
    assert limits == {'memory.max':str(10*p.GIB),'memory.swap.max':'0','pids.max':'512'}
    namespaces = {k:os.readlink(f'/proc/{pid}/ns/{k}') for k in ('ipc','net')}
    owners[name] = owner
    save(tag+'_ownership.json', dict(identity=owner, limits=limits, namespaces=namespaces))
    return state, namespaces

try:
    info = json.loads(call('info', ['info','--format=json'])[0])
    assert info['store']['graphRoot'] == str(store)
    pausefile = runtime/'libpod/tmp/pause.pid'
    assert pausefile.stat().st_uid == os.getuid()
    pid = int(pausefile.read_text())
    before = p.gpu_process_identity(pid)
    assert before and before['uid'] == os.getuid()
    assert Path(f'/proc/{pid}/comm').read_text().strip() == 'podman pause'
    oldgroup = Path(before['cgroup'])
    assert re.fullmatch(r'podman-pause-[0-9]+\.scope', oldgroup.name)
    oldunit = dict(line.split('=',1) for line in subprocess.check_output([
        'systemctl','--user','show',oldgroup.name,'-p','InvocationID','-p','ControlGroup'],text=True).splitlines())
    assert Path('/sys/fs/cgroup'+oldunit['ControlGroup']) == oldgroup
    assert [row['pid'] for row in p.owned_pids(oldgroup)] == [pid]
    boot = next(int(line.split()[1]) for line in Path('/proc/stat').read_text().splitlines() if line.startswith('btime '))
    assert abs(boot+before['start_ticks']/os.sysconf('SC_CLK_TCK')-pausefile.stat().st_mtime) < 5
    assert p.gpu_process_identity(pid) == before
    (supervisor/'cgroup.procs').write_text(str(pid))
    os.sched_setaffinity(pid, set(range(4,24)) | set(range(28,48)))
    pause_owner = p.gpu_process_identity(pid)
    assert pause_owner['start_ticks'] == before['start_ticks']
    assert Path(pause_owner['cgroup']) == supervisor
    assert not (oldgroup/'cgroup.procs').read_text().split()
    assert subprocess.check_output(['systemctl','--user','show',oldgroup.name,'-p','InvocationID','--value'],text=True).strip() == oldunit['InvocationID']
    subprocess.run(['systemctl','--user','stop',oldgroup.name],check=True)
    save('pause_adoption.json',dict(before=before, after=pause_owner, original=oldunit,
                                  before_container_start=True))
    assert not call('prior_containers',['ps','-aq'])[0].strip()
    image = json.loads(call('image',['image','inspect','docker.io/library/ubuntu:22.04'])[0])[0]
    assert image['Id'] == json.loads((OLD/'container_proxy_attempt/image_identity.json').read_text())['Id']
    save('image_identity.json',{k:image.get(k) for k in ('Id','Digest','Size','Architecture','Os')})

    import asyncio
    from hashlib import sha256
    import importlib.util
    from HydraServe_project.runtime.isolated_platform import ContainerRecipe,IsolatedPodmanPlatform
    from HydraServe_project.runtime.platform_port import render_overlays as render_platform,SOURCE_DIR

    BASE=Path('/home/qhq/serverless_llm_baselines')
    ENV=BASE/'installs/hydraserve_native_d484_20261013'
    PYBASE=Path('/home/qhq/anaconda3/envs/hydraserve_py_20260520')
    CUDA=Path('/home/qhq/anaconda3/envs/slinfer_official_20260612')
    NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
    MODEL=Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf')
    NCCL=RAW.parent/'d486_20261013/private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1'
    FAST=RAW.parent/'d485_20261013/build_fastload/lib/libst_pybinding.so'
    assert sha256(NCCL.read_bytes()).hexdigest()=='005503b62b9fe466b6b2f60ba2ad1daa4571196ffcb82a3d77a3c775bfcd5ac8'
    assert sha256(FAST.read_bytes()).hexdigest()=='f11b31a82f654d7c8950d85e05461d31b5cc45469720deb1e784d47022571e44'
    for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
        assert sha256(Path(path).read_bytes()).hexdigest()==record['sha256']
    helper_spec=importlib.util.spec_from_file_location('native_resource_helper',BASE/'tests/test_ieee_tc_hydraserve_platform_port.py')
    helper=importlib.util.module_from_spec(helper_spec);helper_spec.loader.exec_module(helper)
    nv=CUDA/'lib/python3.11/site-packages/nvidia'
    libraries=[ENV/'lib/python3.10/site-packages/torch/lib',PYBASE/'lib',
               *[d/'lib' for d in sorted(nv.iterdir()) if (d/'lib').is_dir()],CUDA/'lib']
    readonly=[ENV,PYBASE,CUDA,MODEL,NCCL,BASE/'HydraServe_project']
    readonly += [Path(row["adapter_path"]) for row in json.loads((RAW/"lora_registry.json").read_text())]
    mounts=[(str(x),str(x)) for x in readonly]
    mounts += [(str(RAW/"lora_registry.json"),"/hydra-loras.json")]
    mounts += [(str(RAW/'overlays'),'/hydra-overlay'),(str(RAW/'metadata'),'/mnt/model-cache'),
               (str(FAST),'/vllm-workspace/libst_pybinding.so')]
    worker_env=dict(LD_LIBRARY_PATH=':'.join(map(str,libraries)),PYTHONPATH=str(BASE),
        PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTHONUNBUFFERED='1',
        HOME='/tmp',CUDA_CACHE_PATH='/tmp/cuda-cache',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        VLLM_NO_USAGE_STATS='1',VLLM_NCCL_SO_PATH=str(NCCL),
        HYDRASERVE_OVERLAY_ROOT='/hydra-overlay',
        HYDRASERVE_OVERLAY_SHA256=sha256((RAW/'overlays/manifest.json').read_bytes()).hexdigest(),
        HYDRASERVE_PARTITION_MANIFEST='/mnt/model-cache/partition.json',
        HYDRASERVE_PARTITION_SHA256=sha256((RAW/'metadata/partition.json').read_bytes()).hexdigest(),
        HYDRASERVE_NATIVE_ENTRY='scripts/image/app.py',
        HYDRASERVE_EXEC_JSON=json.dumps([str(ENV/'bin/python'),'-B',
            str(BASE/'HydraServe_project/runtime/native_overlay_entry.py')]))
    worker_env.update(HYDRASERVE_LORA_REGISTRY="/hydra-loras.json",
        HYDRASERVE_LORA_REGISTRY_SHA256=sha256((RAW/"lora_registry.json").read_bytes()).hexdigest())
    uuids=subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).splitlines()
    assert len(uuids)==4
    recipe=ContainerRecipe(image_id=image['Id'],native_images=('native-image',),
        entrypoint=(str(ENV/'bin/python'),'-B','/hydra-entry.py'),readonly_mounts=tuple(mounts),
        environment=worker_env,memory_bytes=80*p.GIB,swap_bytes=2*p.GIB,timeout_s=1800)
    platform=IsolatedPodmanPlatform(campaign='d497',output=RAW/'platform',parent=group,
        parent_invocation=identity['invocation_id'],parent_inode=identity['inode'],
        parent_limits={'memory.high':str(72*p.GIB),'memory.max':str(80*p.GIB),'memory.swap.max':str(2*p.GIB)},
        cpu_ids=list(range(4,24))+list(range(28,48)),podman_base=base,podman_environment=env,
        process_identity=p.gpu_process_identity,node=socket.gethostname(),gpu_uuids=uuids,
        gpu_gb=24,network_gbps=1,host_gb=80,storage_address='127.77.49.10',recipe=recipe,
        gate_script=BASE/'HydraServe_project/runtime/container_entry.py')

    async def listen(address,port,worker,health=False):
        start=time.monotonic()
        while True:
            try:
                reader,writer=await asyncio.wait_for(asyncio.open_connection(address,port),2)
                if health:
                    writer.write(bytes(8));await writer.drain()
                    data=await asyncio.wait_for(reader.read(100),5)
                    assert data==b'initialization finished',data
                writer.close();await writer.wait_closed()
                return time.monotonic()-start
            except ConnectionRefusedError:
                if time.monotonic()-start>1800:raise
                # Probe actual PID cheaply; no recurring container CLI in loading path.
                current=p.gpu_process_identity(worker.owner['pid'])
                if not current or current['start_ticks']!=worker.owner['start_ticks']:
                    raise RuntimeError('native component exited before listening: '+worker.name)
                await asyncio.sleep(.25)

    async def post(url,payload):
        def send():
            request=urllib.request.Request(url,json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
            start=time.monotonic()
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=1800) as response:
                value=json.loads(response.read())
                save('native_init_response.json',dict(status=response.status,response=value,elapsed_s=time.monotonic()-start))
                assert response.status==200
        await asyncio.to_thread(send)

    async def work():
        try:
            # Existing checkpoint payload is <13GiB. Native local_server touches
            # whole integer-GiB pool; all bytes are charged to the common parent.
            index=json.loads((MODEL/'model.safetensors.index.json').read_text())
            file_bytes=sum((MODEL/x).stat().st_size for x in set(index['weight_map'].values()))
            shm_gib=(file_bytes+p.GIB-1)//p.GIB
            save('shm_capacity.json',dict(existing_shard_bytes=file_bytes,shm_gib=shm_gib,
                native_pool_bytes=shm_gib*p.GIB,private_tmpfs_bytes=shm_gib*p.GIB+256*p.MIB))
            await platform.start_storage(dict(SHM_SIZE=str(shm_gib),USE_CACHE='0',SLOW_EXPR='0',
                REMOTE_SERVER_ADDR='127.77.49.11',NUM_REMOTE_SERVER='1',
                HYDRASERVE_NATIVE_ENTRY='scripts/kubernetes/vllm/storage_server/local_server.py'),
                shm_bytes=shm_gib*p.GIB+256*p.MIB)
            storage_wait=await listen('127.77.49.10',6666,platform.storage,True)
            print('native private storage initialized',flush=True)
            await platform.start_provider('provider','127.77.49.11',dict(
                MODELSCOPE_CACHE='/mnt/model-cache',HYDRASERVE_LOCAL_MODEL_ID='llama2_7b',
                HYDRASERVE_HF_SHARDS='1',LOCAL_SERVER='0',ENABLE_PARA='0',CPU_ENV='1',
                HYDRASERVE_NATIVE_ENTRY='scripts/kubernetes/vllm/storage_server/remote_server.py'))
            provider_wait=await listen('127.77.49.11',8888,platform.providers['provider'],True)
            print('native CPU provider initialized',flush=True)
            save('provider_ready.json',dict(storage_wait_s=storage_wait,provider_wait_s=provider_wait))
            ns=helper.load_resource(render_platform(NATIVE)[SOURCE_DIR+'/resource_manager.py'],
                                    post_request_util_succ_async=post)
            manager=ns['ResourceManager'](None,None,platform=platform)
            allocation=ns['AllocatedResource'](1,[0],[19],[1])
            usages=manager.claim_allocated_resource(allocation)
            addresses=await manager.create_pods('llama2_7b/0',allocation,usages)
            worker=platform.workers[usages[0].pod_name]
            result['gpu_started']=True
            await listen(addresses[0],8080,worker)
            await manager.initialize_pods(addresses)
            def health():
                opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
                with opener.open('http://'+addresses[0]+':8080/health',timeout=10) as r:
                    assert r.status==200
                with opener.open('http://'+addresses[0]+':8080/v1/models',timeout=10) as r:
                    return json.loads(r.read())
            save('native_model_registry.json',await asyncio.to_thread(health))
            save("generation_worker_identity.json",dict(address=addresses[0],owner=worker.owner,
                entry=json.loads((worker.output/"entry.json").read_text()),
                host_time_namespace=os.readlink("/proc/self/ns/time"),
                worker_time_namespace=os.readlink(f"/proc/{worker.owner['pid']}/ns/time")))
            client_env=dict(os.environ,PYTHONPATH=str(BASE)+":"+str(MAIN),USE_TORCH="0",USE_TF="0",
                CUDA_VISIBLE_DEVICES="",HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",
                NO_PROXY="*",no_proxy="*",PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1")
            with (RAW/"request_witness.log").open("x") as log:
                client=await asyncio.create_subprocess_exec(str(ENV/"bin/python"),"-B",
                    str(RAW/"request_witness.py"),env=client_env,stdout=log,stderr=subprocess.STDOUT)
                code=await client.wait()
            assert code==0,(code,"see request_witness.log")
            generation=json.loads((RAW/"generation_result.json").read_text())
            assert generation["passed"] and len(generation["requests"])==2
            await manager.release_resource(usages)
            assert await platform.worker_deleted(worker.name)
            assert manager.rgpus==[[24]*4]
            result.update(passed=True,actual_cpu_provider=True,actual_private_storage=True,
                native_app_init=True,shared_memory_fastload=True,physical_nodes=1,
                request_lora_qualified=False,native_generation_qualified=True,performance_result=False,
                qualification_scope="two existing nonzero adapter request bindings; not numerical/full-scheduler/remote")
        finally:
            await platform.close()

    asyncio.run(asyncio.wait_for(work(),1720))

except Exception as exc:
    result.update(error_type=type(exc).__name__, error=str(exc))
finally:
    cleanup = []
    for index,name in enumerate(reversed(created)):
        text, code = call('cleanup_inspect_'+str(index),['inspect',name],check=False)
        if code:
            cleanup.append(dict(name=name, exists=False, inspect_returncode=code))
            continue
        state = json.loads(text)[0]
        assert state['Config']['Labels']['org.primelora.campaign'] == 'd497'
        if state['State']['Running']:
            call('stop_'+str(index),['stop','--time=2',name])
        call('remove_'+str(index),['rm',name])
        owner = owners.get(name)
        if owner:
            current = p.gpu_process_identity(owner['pid'])
            assert current is None or current['start_ticks'] != owner['start_ticks']
        cleanup.append(dict(name=name, removed=True))
    if sentinel is not None:
        assert sentinel.stat().st_uid == os.getuid()
        assert sentinel.stat().st_ino == sentinel_inode and sentinel.read_bytes() == payload
        sentinel.unlink()
    if pause_owner is not None:
        current = p.gpu_process_identity(pause_owner['pid'])
        if current is not None:
            assert current == pause_owner
            fd = os.pidfd_open(current['pid'])
            try:
                assert p.gpu_process_identity(current['pid']) == current
                signal.pidfd_send_signal(fd,signal.SIGKILL)
            finally:
                os.close(fd)
    result.update(cleanup=cleanup, disk_free_after=shutil.disk_usage(RAW).free)
    result['gpu_apps_after'] = subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True).strip()
    result['gpu_released'] = not result['gpu_apps_after']
    result['passed'] = result['passed'] and result['gpu_released']
    save('commands.json',commands)
    save('result.json',result)
    print(json.dumps(result),flush=True)
sys.exit(0 if result['passed'] else 1)
