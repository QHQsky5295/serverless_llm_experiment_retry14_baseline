"""D497 exact generation witness with only qualified tokenizer-schema view."""
import json
from pathlib import Path
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d497_20261013'
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((RAW/'tokenizer_equivalence.json').read_text())['passed']
# Existing request script is reused verbatim; paths are relative to __file__.
with (RAW/'request_witness.py').open('x') as f:
    f.write((OLD/'request_witness.py').read_text())
source=(OLD/'prepare.py').read_text().replace('d497','d498')
source=source.replace("pool = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')",
    "pool = RAW/'adapter_views'")
# View symlinks retain original weight paths, which must be available read-only.
source=source.replace(
    "'    readonly += [Path(row[\"adapter_path\"]) for row in json.loads((RAW/\"lora_registry.json\").read_text())]\\n'",
    "'    readonly += [Path(row[\"adapter_path\"]) for row in json.loads((RAW/\"lora_registry.json\").read_text())]\\n'\n"
    "    '    readonly += [Path(row[\"source\"]) for row in json.loads((RAW/\"tokenizer_views.json\").read_text())]\\n'")
assert 'tokenizer_views.json' in source
source=source.replace("(OLD/name).read_text().replace('d495', 'd498')",
    "(OLD/name).read_text().replace('d495', 'd498').replace('0000000000000000000000000003','0000000000000000000000000009')")
with (RAW/'prepare.py').open('x') as f:
    f.write(source)
exec(compile(source,str(RAW/'prepare.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'prepare.py')})
