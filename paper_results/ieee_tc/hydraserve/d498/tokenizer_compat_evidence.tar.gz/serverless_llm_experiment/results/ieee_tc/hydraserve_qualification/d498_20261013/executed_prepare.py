"""Mechanical D493 bootstrap reuse and immutable D494 input overlays."""
from hashlib import sha256
import json
from pathlib import Path
import sys

RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import render_overlays, materialize_metadata
from HydraServe_project.scripts.probe_layer_identity import MODEL,NATIVE

for name in ('containers.conf','pull-auth.json'):
    with (RAW/name).open('xb') as f:f.write((RAW.parent/'d493_20261013'/name).read_bytes())
overlays=render_overlays(NATIVE,request_contract=True)
for name,raw in overlays.items():
    path=RAW/'overlays'/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(raw)
(RAW/'overlays/manifest.json').write_text(json.dumps({n:sha256(v).hexdigest() for n,v in overlays.items()},sort_keys=True))
materialize_metadata(RAW/'metadata','llama2_7b',MODEL,native_root=NATIVE)
source=(RAW.parent/'d493_20261013/executed_probe.py').read_text()
prefix=source[:source.index('    import asyncio\n')]
suffix=source[source.index('except Exception as exc:\n    result.update'):]
prefix=prefix.replace('d493','d498').replace('{2,3,26,27}','set(range(4,24)) | set(range(28,48))')
prefix=prefix.replace('str(4*p.GIB)','str(80*p.GIB)')
prefix=prefix.replace("== '0'","== str(2*p.GIB)",1)
prefix=prefix.replace("native_backend_qualified=False", "native_backend_qualified=False")
prefix=prefix.replace("kind='isolated_shared_ipc_loopback_http_no_model'", "kind='native_backbone_delivery_init_qualification'")
suffix=suffix.replace('d493','d498')
body=(RAW/'native_body.py').read_text()
full=prefix+body+'\n'+suffix
compile(full,'d498_probe','exec')
with (RAW/'probe.py').open('x') as f:f.write(full)
paths=[RAW/'probe.py',RAW/'native_body.py',RAW/'prepare.py',RAW/'request_witness.py',RAW/'lora_registry.json']
paths += list((BASE/'HydraServe_project/runtime').glob('*.py'))
snapshot={}
for index,path in enumerate(paths):
    raw=path.read_bytes();out=RAW/'executed_sources'/f'{index:03d}_{path.name}'
    out.parent.mkdir(exist_ok=True)
    with out.open('xb') as f:f.write(raw)
    snapshot[str(path)]=dict(sha256=sha256(raw).hexdigest(),snapshot=str(out))
(RAW/'source_manifest.json').write_text(json.dumps(snapshot,indent=2))
print(json.dumps({'prepared':True,'overlays':len(overlays),'metadata_copies_weights':False}))
