#!/bin/bash
set -euo pipefail
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d498_20261013
export USE_TORCH=0 USE_TF=0 CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1
systemd-run --user --scope --unit=primelora-tc-aux-d4980000000000000000000000000002 -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 taskset -c 2,3,26,27 /home/qhq/anaconda3/envs/LLM_vllm0102/bin/python -B "$RAW/tokenizer_witness.py" reference >"$RAW/reference.log" 2>&1
systemd-run --user --scope --unit=primelora-tc-aux-d4980000000000000000000000000003 -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 taskset -c 2,3,26,27 /home/qhq/serverless_llm_baselines/installs/hydraserve_native_d484_20261013/bin/python -B "$RAW/tokenizer_witness.py" legacy >"$RAW/legacy.log" 2>&1
