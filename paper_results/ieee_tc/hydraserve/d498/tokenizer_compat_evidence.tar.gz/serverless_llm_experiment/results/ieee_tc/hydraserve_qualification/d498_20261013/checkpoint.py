"""D496 bounded tests/protected-file verification and explicit evidence curation."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import urllib.request
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d497_20261013'
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
assert not json.loads((OLD/'generation_result.json').read_text())['passed']
assert not json.loads((OLD/'req_00000_native_events.json').read_text())['events']
assert json.loads((RAW/'tokenizer_equivalence.json').read_text())['passed']
tests=['tests.test_ieee_tc_hydraserve_'+name for name in ('tokenizer_compat',
    'request_contract','native_delivery','isolated_platform','platform_port',
    'stage_binding','worker_binding','layer_identity')]
with (RAW/'cpu_tests.log').open('x') as f:
    subprocess.run([sys.executable,'-B','-m','unittest',*tests,'-v'],cwd=BASE,
        stdout=f,stderr=subprocess.STDOUT,check=True,timeout=40)
assert 'Ran 63 tests' in (RAW/'cpu_tests.log').read_text()
online=[]
for version in ('0.19.1','0.20.0'):
    url=f'https://raw.githubusercontent.com/huggingface/tokenizers/v{version}/tokenizers/src/models/bpe/serialization.rs'
    with urllib.request.urlopen(url,timeout=20) as response:data=response.read(100000)
    path=RAW/('tokenizers_'+version+'_serialization.rs')
    with path.open('xb') as f:f.write(data)
    online.append(dict(url=url,sha256=sha256(data).hexdigest()))
save(RAW/'online_sources.json',online)
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
save(RAW/'protected_verification.json',protected)
paths=[BASE/name for name in ('HydraServe_project/runtime/tokenizer_compat.py',
    'tests/test_ieee_tc_hydraserve_tokenizer_compat.py','docs/ieee_tc/D498_HYDRASERVE_TOKENIZER_COMPAT.md')]
# These are per-run receipts/source/logs, not a broad tree or input pool archive.
for root in (OLD,RAW):
    paths += [x for x in root.iterdir() if x.is_file() and not x.is_symlink()
              and x.name not in ('pull-auth.json',)]
    for child in ('overlays','executed_sources'):
        paths += [x for x in (root/child).rglob('*') if x.is_file() and not x.is_symlink()]
paths += [x for x in (OLD/'platform').rglob('*') if x.is_file() and not x.is_symlink()]
paths += [OLD/'launch_gate.launch'/x for x in ('watchdog.jsonl','watchdog.stderr','exec_receipt.json','service.log')]
paths=sorted(set(paths))
assert all(x.is_file() and not x.is_symlink() for x in paths)
manifest={str(x):dict(sha256=p.digest(x),bytes=x.stat().st_size) for x in paths}
dest=BASE/'paper_results/ieee_tc/hydraserve/d498';dest.mkdir()
archive=dest/'tokenizer_compat_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as out:
    for path in paths:out.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle.getmembers():
        assert sha256(bundle.extractfile(member).read()).hexdigest()==manifest['/home/qhq/'+member.name]['sha256']
summary=dict(checkpoint_verified=True,performance_result=False,cpu_tests_passed=63,
    d497_gpu_attempt='failed before first output: incompatible tokenizer BPE JSON schema',
    d497_completed_requests=0,d498_gpu_generation_run=False,tokenizer_equivalence_passed=True,
    tokenizer_versions=['0.22.2','0.19.1'],existing_trace_texts_per_adapter=4000,
    existing_adapters=2,all_single_token_decodes_per_adapter=32000,
    weight_bytes_copied=0,protected_verification=protected,source_manifest=manifest,
    archive_sha256=p.digest(archive),next='D498 prepared actual generation witness; no new preparation or input generation')
save(dest/'summary.json',summary)
save(RAW/'curation_result.json',dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size,
    summary_sha256=p.digest(dest/'summary.json'),archive_sha256=p.digest(archive)))
print(json.dumps(dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size,cpu_tests=63)))
