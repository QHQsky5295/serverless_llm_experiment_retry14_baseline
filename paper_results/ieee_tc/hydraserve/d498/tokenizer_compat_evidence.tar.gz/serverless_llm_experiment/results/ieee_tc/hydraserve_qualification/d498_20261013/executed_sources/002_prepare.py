"""Reuse D495 full native loading fixture, add actual D496 request witness."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import urllib.request

RAW = Path(__file__).resolve().parent
OLD = RAW.parent/'d495_20261013'
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0, str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
pool = RAW/'adapter_views'
rows = [dict(adapter_id=aid, adapter_index=i, adapter_path=str(pool/aid))
        for i, aid in enumerate(('finance_lora', 'medical_lora'), 1)]
assert all(Path(row['adapter_path']).is_dir() for row in rows)
with (RAW/'lora_registry.json').open('x') as f:
    json.dump(rows, f, indent=2)
# Primary source recheck before launch. No reliance on a search snippet/cache miss.
url = ('https://raw.githubusercontent.com/LLMServe/HydraServe/'
       '8ae605de354ccfa2e9095514cdb4a9e9c56aa56b/vllm/entrypoints/openai/serving_completion.py')
with urllib.request.urlopen(url, timeout=20) as r:
    data = r.read(100000)
assert sha256(data).hexdigest() == '4be1f3160c82d79c7fdedee3b5b9171db82596dd3a7ddb14b2ffbeeb46b28b29'
with (RAW/'upstream_serving_completion.py').open('xb') as f:
    f.write(data)
body = (OLD/'native_body.py').read_text().replace('d495', 'd498')
body = replace_one(body, '    mounts=[(str(x),str(x)) for x in readonly]\n',
    '    readonly += [Path(row["adapter_path"]) for row in json.loads((RAW/"lora_registry.json").read_text())]\n'
    '    readonly += [Path(row["source"]) for row in json.loads((RAW/"tokenizer_views.json").read_text())]\n'
    '    mounts=[(str(x),str(x)) for x in readonly]\n'
    '    mounts += [(str(RAW/"lora_registry.json"),"/hydra-loras.json")]\n')
body = replace_one(body, '    uuids=subprocess.check_output',
    '    worker_env.update(HYDRASERVE_LORA_REGISTRY="/hydra-loras.json",\n'
    '        HYDRASERVE_LORA_REGISTRY_SHA256=sha256((RAW/"lora_registry.json").read_bytes()).hexdigest())\n'
    '    uuids=subprocess.check_output')
body = replace_one(body, '            await manager.release_resource(usages)\n',
    '            save("generation_worker_identity.json",dict(address=addresses[0],owner=worker.owner,\n'
    '                entry=json.loads((worker.output/"entry.json").read_text()),\n'
    '                host_time_namespace=os.readlink("/proc/self/ns/time"),\n'
    '                worker_time_namespace=os.readlink(f"/proc/{worker.owner[\'pid\']}/ns/time")))\n'
    '            client_env=dict(os.environ,PYTHONPATH=str(BASE)+":"+str(MAIN),USE_TORCH="0",USE_TF="0",\n'
    '                CUDA_VISIBLE_DEVICES="",HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",\n'
    '                NO_PROXY="*",no_proxy="*",PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1")\n'
    '            with (RAW/"request_witness.log").open("x") as log:\n'
    '                client=await asyncio.create_subprocess_exec(str(ENV/"bin/python"),"-B",\n'
    '                    str(RAW/"request_witness.py"),env=client_env,stdout=log,stderr=subprocess.STDOUT)\n'
    '                code=await client.wait()\n'
    '            assert code==0,(code,"see request_witness.log")\n'
    '            generation=json.loads((RAW/"generation_result.json").read_text())\n'
    '            assert generation["passed"] and len(generation["requests"])==2\n'
    '            await manager.release_resource(usages)\n')
body = replace_one(body,
    '                request_lora_qualified=False,native_generation_qualified=False,performance_result=False)',
    '                request_lora_qualified=False,native_generation_qualified=True,performance_result=False,\n'
    '                qualification_scope="two existing nonzero adapter request bindings; not numerical/full-scheduler/remote")')
with (RAW/'native_body.py').open('x') as f:
    f.write(body)
for name in ('launch.sh', 'close_audit.py'):
    with (RAW/name).open('x') as f:
        f.write((OLD/name).read_text().replace('d495', 'd498').replace('0000000000000000000000000003','0000000000000000000000000009'))
template = (RAW.parent/'d494_20261013/prepare.py').read_text().replace('d494', 'd498')
template = replace_one(template, 'overlays=render_overlays(NATIVE)',
                       'overlays=render_overlays(NATIVE,request_contract=True)')
template = replace_one(template,
    "paths=[RAW/'probe.py',RAW/'native_body.py',RAW/'prepare.py']",
    "paths=[RAW/'probe.py',RAW/'native_body.py',RAW/'prepare.py',RAW/'request_witness.py',RAW/'lora_registry.json']")
with (RAW/'executed_prepare.py').open('x') as f:
    f.write(template)
exec(compile(template, str(RAW/'executed_prepare.py'), 'exec'),
     {'__name__':'__main__', '__file__':str(RAW/'executed_prepare.py')})
