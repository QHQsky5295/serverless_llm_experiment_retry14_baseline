"""Close this checkpoint's exact-owned empty preparation scopes only."""
import json
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
RAW=Path(__file__).resolve().parent
records=[]
for number in (1,2,3,4):
    identity=p.scope_identity('primelora-tc-aux-d498'+f'{number:028d}'+'.scope')
    group=Path(identity['path'])
    assert p.scope_still_owned(identity)
    assert not any(x.read_text().split() for x in (group/'cgroup.procs',*group.rglob('cgroup.procs')))
    stats={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
    subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
    assert not group.exists()
    records.append(dict(identity=identity,stats=stats,actual_recursive_empty=True))
with (RAW/'preparation_closure.json').open('x') as f:json.dump(records,f,indent=2)
print(json.dumps(records))
