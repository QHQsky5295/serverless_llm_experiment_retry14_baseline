"""Reuse D480 exact-file/checksum/secrets/tests/protected-user-dirt push gate."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d498').replace('D480','D498')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['HydraServe_project/runtime/tokenizer_compat.py',
        'tests/test_ieee_tc_hydraserve_tokenizer_compat.py',
        'docs/ieee_tc/D498_HYDRASERVE_TOKENIZER_COMPAT.md',
        'paper_results/ieee_tc/hydraserve/d498/summary.json',
        'paper_results/ieee_tc/hydraserve/d498/tokenizer_compat_evidence.tar.gz']
    remote, branch = 'origin','main'
    smoke = ['tests.test_ieee_tc_hydraserve_tokenizer_compat',
             'tests.test_ieee_tc_hydraserve_request_contract',
             'tests.test_ieee_tc_hydraserve_native_delivery',
             'tests.test_ieee_tc_hydraserve_isolated_platform',
             'tests.test_ieee_tc_hydraserve_platform_port',
             'tests.test_ieee_tc_hydraserve_stage_binding',
             'tests.test_ieee_tc_hydraserve_worker_binding',
             'tests.test_ieee_tc_hydraserve_layer_identity']
'''+source[end:]
source=source.replace('qualify HydraServe native platform injection seam on CPU',
    'preserve actual HydraServe request failure and qualify lossless tokenizer compatibility')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup_reused.py')})
