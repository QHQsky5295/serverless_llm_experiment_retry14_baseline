"""Existing tokenizer bytes + all existing trace texts; no GPU/performance run."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path[:0]=[str(BASE),str(MAIN)]
from HydraServe_project.runtime.tokenizer_compat import materialize_metadata_view
from faaslora.datasets.workload_generator import FrozenReplayPlan, render_role_lines
from transformers import AutoTokenizer
import tokenizers
cfg=json.loads(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/http_7b_4000.json').read_text())
plan=FrozenReplayPlan.load(cfg['trace'])
assert plan.source_sha256==cfg['trace_sha256'] and len(plan.entries)==4000
mode=sys.argv[1]
assert mode in ('prepare','reference','legacy')
pool=Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
names=('finance_lora','medical_lora')
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2)
if mode=='prepare':
    save('tokenizer_views.json',[materialize_metadata_view(pool/n,RAW/'adapter_views'/n) for n in names])
    raise SystemExit(0)
expected_version='0.22.2' if mode=='reference' else '0.19.1'
assert tokenizers.__version__==expected_version
records=[]
for name in names:
    root=pool/name if mode=='reference' else RAW/'adapter_views'/name
    tokenizer=AutoTokenizer.from_pretrained(root,local_files_only=True)
    encoded=sha256();decoded=sha256();start=time.monotonic()
    for entry in plan.entries:
        text=render_role_lines(json.loads(entry.source_json)['body']['messages'])
        ids=tokenizer.encode(text)
        encoded.update(json.dumps([entry.request_id,ids],ensure_ascii=False).encode())
        decoded.update(json.dumps([entry.request_id,tokenizer.decode(ids)],ensure_ascii=False).encode())
    vocab=tokenizer.get_vocab()
    singles=sha256()
    for i in range(len(tokenizer)):
        singles.update(json.dumps([i,tokenizer.decode([i])],ensure_ascii=False).encode())
    semantic=dict(adapter_id=name,trace_encode_sha256=encoded.hexdigest(),
        trace_decode_sha256=decoded.hexdigest(),single_token_decode_sha256=singles.hexdigest(),
        vocab_sha256=sha256(json.dumps(vocab,sort_keys=True).encode()).hexdigest(),
        special_tokens_map=tokenizer.special_tokens_map,all_special_ids=tokenizer.all_special_ids,
        bos_token_id=tokenizer.bos_token_id,eos_token_id=tokenizer.eos_token_id,
        tokenizer_length=len(tokenizer),request_count=4000)
    records.append(semantic)
    print(json.dumps(dict(adapter=name,elapsed_s=time.monotonic()-start,mode=mode)),flush=True)
save(mode+'_tokenizer.json',dict(tokenizers_version=tokenizers.__version__,source_trace_sha256=plan.source_sha256,records=records))
if mode=='legacy':
    expected=json.loads((RAW/'reference_tokenizer.json').read_text())
    assert records==expected['records'],'tokenizer semantics differ'
    save('tokenizer_equivalence.json',dict(passed=True,adapters=2,existing_texts_per_adapter=4000,
        all_single_token_decodes_per_adapter=32000,performance_result=False,
        scope='lossless tokenizer metadata compatibility; no generation qualification'))
    print('tokenizer equivalence PASS',flush=True)
