"""Actual native Request/Instance/ChatEngine -> original app GPU generation.

Two existing nonzero adapters; NOT full Scheduler/autoscaling, remote delivery,
100-request smoke, numerical-equivalence proof, or a performance replay.
No synthetic prompt, altered target, new weights, template or backend substitute.
"""
import ast
import asyncio
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import time
import types
import typing

RAW = Path(__file__).resolve().parent
BASE = Path('/home/qhq/serverless_llm_baselines')
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path[:0] = [str(BASE), str(MAIN)]
from HydraServe_project.runtime.request_contract import BoundRequest, FrozenRequest, ENGINE
from faaslora.datasets.workload_generator import FrozenReplayPlan, prepare_frozen_http_request
from transformers import AutoTokenizer

def save(name, value):
    with (RAW/name).open('x') as f:
        json.dump(value, f, indent=2)

registry = json.loads((RAW/'lora_registry.json').read_text())
bindings = {r['adapter_id']: r for r in registry}
cfg = json.loads(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/http_7b_4000.json').read_text())
plan = FrozenReplayPlan.load(cfg['trace'])
assert plan.source_sha256 == cfg['trace_sha256']
tokenizer = AutoTokenizer.from_pretrained(cfg['backbone'], local_files_only=True)
entries = {}
for entry in plan.entries:
    aid = json.loads(entry.source_json)['adapter_id']
    if aid in bindings and aid not in entries:
        entries[aid] = entry
assert set(entries) == set(bindings)
rows = [prepare_frozen_http_request(entries[r['adapter_id']], tokenizer, 'llama2_7b') for r in registry]
save('existing_input_binding.json', dict(source_trace=plan.path, source_sha256=plan.source_sha256,
    selection='first existing request for each of two existing nonzero adapters',
    scope='request_binding_diagnostic_not_performance_replay', rows=rows))
manifest = json.loads((RAW/'overlays/manifest.json').read_text())
def source(path):
    raw = (RAW/'overlays'/path).read_bytes()
    assert sha256(raw).hexdigest() == manifest[path]
    return raw

# Execute the actual original engine and native classes. Platform-only imports
# are omitted because this witness uses an already genuinely initialized worker
# from the original ResourceManager. No scheduler/ResourceManager is faked.
module = types.ModuleType('hydra_request_witness_native')
sys.modules[module.__name__] = module
ns = module.__dict__
exec(compile(source(ENGINE), str(RAW/'overlays'/ENGINE), 'exec'), ns)
path = 'scripts/kubernetes/vllm/src/scheduler.py'
tree = ast.parse(source(path))
tree.body = [n for n in tree.body if not (
    isinstance(n, ast.ImportFrom) and n.module in ('engine', 'resource_manager', 'cache_manager', 'utils'))]
# These names occur only in type annotations of the selected native classes.
ns.update(ResourceUsage=typing.Any, AllocatedResource=typing.Any)
exec(compile(tree, str(RAW/'overlays'/path), 'exec'), ns)
assert 'ResourceManager' not in ns
identity = json.loads((RAW/'generation_worker_identity.json').read_text())
assert identity['host_time_namespace'] == identity['worker_time_namespace']
address = identity['address']
result = dict(passed=False, actual_gpu_generation=True, performance_result=False,
              full_scheduler_qualified=False, remote_delivery_qualified=False, requests=[])

async def main():
    model = ns['Model']('llama2_7b/0', (14, 10000, 100, 1, 1))
    instance = ns['Instance'](model, 1, False, time.time(), [address], [None])
    try:
        for row in rows:
            aid = row['adapter_id']
            c = FrozenRequest(row['request_id'], aid, bindings[aid]['adapter_index'],
                bindings[aid]['adapter_path'], row['prompt'], tuple(row['input_token_ids']), row['target_tokens'])
            b = BoundRequest(c)
            request = ns['Request'](c.request_id, model.model_id, b, True, time.time())
            submitted = time.perf_counter()
            request.allocate_instance(instance)
            try:
                stream = await request.resp_func
                chunks = list(stream)
                completed = time.perf_counter()
            finally:
                save(c.request_id+'_native_events.json', dict(events=b.events, terminal=b.terminal,
                    native_process=b.native_process, native_request_id=b.native_request_id))
            assert b.terminal and len(b.events) > 0
            ids = [i for e in b.events for i in e['delta_token_ids']]
            assert len(ids) == c.target_tokens
            assert b.native_process['pid'] == identity['entry']['pid']
            assert b.native_process['start_ticks'] == identity['owner']['start_ticks']
            assert submitted <= b.events[0]['output_monotonic_s'] <= b.events[-1]['output_monotonic_s'] <= completed
            assert instance.num_reqs == 0 and instance.num_coldstart_reqs == 0
            item = dict(request_id=c.request_id, adapter_id=aid, prompt_sha256=c.prompt_sha256,
                target_tokens=c.target_tokens, actual_tokens=len(ids), output_token_ids=ids,
                submitted_s=submitted, completed_s=completed, native_process=b.native_process,
                first_native_output_s=b.events[0]['output_monotonic_s'],
                last_native_output_s=b.events[-1]['output_monotonic_s'],
                output_text_sha256=sha256(''.join(chunks[:-1]).encode()).hexdigest())
            result['requests'].append(item)
            print(json.dumps(dict(request_id=c.request_id, adapter_id=aid,
                  actual_tokens=len(ids), target_tokens=c.target_tokens)), flush=True)
        result['passed'] = True
    finally:
        instance.chat_engine.client.close()
        await instance.chat_engine.client_async.close()
        save('generation_result.json', result)

asyncio.run(main())
