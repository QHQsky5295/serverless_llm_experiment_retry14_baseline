import json
from pathlib import Path
import subprocess
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
with (HERE/'test_identity.json').open('x') as f:
    json.dump(p.scope_identity(p.cg_path().name),f,indent=2)
tests=['tests.test_ieee_tc_hydraserve_isolated_platform',
       'tests.test_ieee_tc_hydraserve_platform_port',
       'tests.test_ieee_tc_hydraserve_stage_binding',
       'tests.test_ieee_tc_hydraserve_worker_binding',
       'tests.test_ieee_tc_hydraserve_layer_identity']
with (HERE/'tests.log').open('x') as f:
    subprocess.run([sys.executable,'-B','-m','unittest',*tests,'-v'],
        cwd='/home/qhq/serverless_llm_baselines',stdout=f,stderr=subprocess.STDOUT,
        timeout=40,check=True)
