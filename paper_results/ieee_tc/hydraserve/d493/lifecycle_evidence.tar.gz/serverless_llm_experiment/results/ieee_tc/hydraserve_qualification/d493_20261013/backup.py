"""Reuse checked explicit staging/roundtrip/secrets/protected/remote equality."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d493').replace('D480','D493')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['HydraServe_project/runtime/isolated_platform.py',
        'HydraServe_project/runtime/container_entry.py',
        'tests/test_ieee_tc_hydraserve_isolated_platform.py',
        'docs/ieee_tc/D493_HYDRASERVE_CONCRETE_LIFECYCLE.md',
        'paper_results/ieee_tc/hydraserve/d493/summary.json',
        'paper_results/ieee_tc/hydraserve/d493/lifecycle_evidence.tar.gz']
    remote, branch = 'origin','main'
    smoke = ['tests.test_ieee_tc_hydraserve_isolated_platform',
             'tests.test_ieee_tc_hydraserve_platform_port',
             'tests.test_ieee_tc_hydraserve_stage_binding',
             'tests.test_ieee_tc_hydraserve_worker_binding',
             'tests.test_ieee_tc_hydraserve_layer_identity']
'''+source[end:]
source=source.replace("paths = ['docs/ieee_tc/EXECUTION_STATUS.md']", "paths = ['docs/ieee_tc/EXECUTION_STATUS.md', 'docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D491.md']")
source=source.replace('qualify HydraServe native platform injection seam on CPU',
                      'connect actual isolated HydraServe lifecycle and private storage')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup_reused.py')})
