import asyncio
import importlib.util
from HydraServe_project.runtime.isolated_platform import ContainerRecipe, IsolatedPodmanPlatform
from HydraServe_project.runtime.loopback_transport import render_overlays
from HydraServe_project.runtime.platform_port import render_overlays as render_platform, SOURCE_DIR

BASE=Path('/home/qhq/serverless_llm_baselines')
ENV=BASE/'installs/hydraserve_native_d484_20261013'
PYBASE=Path('/home/qhq/anaconda3/envs/hydraserve_py_20260520')
NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
storage=render_overlays(NATIVE)['scripts/kubernetes/vllm/storage_server/local_server.py']
with (RAW/'local_server.py').open('xb') as f:f.write(storage)
spec=importlib.util.spec_from_file_location('qualified_native_port_test',BASE/'tests/test_ieee_tc_hydraserve_platform_port.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
uuids=subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).splitlines()
assert len(uuids)==4
recipe=ContainerRecipe(image_id=image['Id'],native_images=('native-image',),
    entrypoint=(str(ENV/'bin/python'),'-B','/hydra-entry.py'),
    readonly_mounts=((str(ENV),str(ENV)),(str(PYBASE),str(PYBASE)),(str(RAW),'/probe')),
    environment=dict(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',HOME='/tmp',
        PYTHONUNBUFFERED='1',LD_LIBRARY_PATH=str(PYBASE/'lib'),
        HYDRASERVE_EXEC_JSON=json.dumps([str(ENV/'bin/python'),'-B','/probe/lifecycle_worker.py'])),
    memory_bytes=2*p.GIB,swap_bytes=0,timeout_s=180)
platform=IsolatedPodmanPlatform(campaign='d492',output=RAW/'platform',parent=group,
    parent_invocation=identity['invocation_id'],parent_inode=identity['inode'],
    parent_limits={'memory.max':str(4*p.GIB),'memory.swap.max':'0'},
    cpu_ids=[2,3,26,27],podman_base=base,podman_environment=env,
    process_identity=p.gpu_process_identity,node=socket.gethostname(),gpu_uuids=uuids,
    gpu_gb=24,network_gbps=1,host_gb=80,storage_address='127.77.49.10',recipe=recipe,
    gate_script=BASE/'HydraServe_project/runtime/container_entry.py')

async def native_health():
    deadline=time.monotonic()+25
    while True:
        try:
            reader,writer=await asyncio.open_connection('127.77.49.10',6666)
            writer.write(bytes(8));await writer.drain()
            data=await reader.read(100);writer.close();await writer.wait_closed()
            assert data==b'initialization finished'
            return
        except ConnectionRefusedError:
            assert time.monotonic()<deadline
            await asyncio.sleep(.05)

async def post(url,payload):
    def send():
        request=urllib.request.Request(url,json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=35) as r:
            assert r.read()==b'test-only-no-model'
    await asyncio.to_thread(send)

async def work():
    try:
        await platform.start_storage(dict(SHM_SIZE='1',USE_CACHE='0',SLOW_EXPR='0',
            REMOTE_SERVER_ADDR='127.77.49.11',NUM_REMOTE_SERVER='1',
            HYDRASERVE_EXEC_JSON=json.dumps([str(ENV/'bin/python'),'-B','/probe/local_server.py'])),
            shm_bytes=1280*p.MIB)
        await native_health()
        ns=helper.load_resource(render_platform(NATIVE)[SOURCE_DIR+'/resource_manager.py'],
                                post_request_util_succ_async=post)
        manager=ns['ResourceManager'](None,None,platform=platform)
        assert len(manager.node_list)==1 and manager.rgpus==[[24]*4]
        allocations=[]
        for index in range(2):
            allocation=ns['AllocatedResource'](1,[0],[19],[1])
            usages=manager.claim_allocated_resource(allocation)
            addresses=await manager.create_pods('llama2_7b/0',allocation,usages)
            worker=platform.workers[usages[0].pod_name]
            deadline=time.monotonic()+15
            while not (worker.output/'worker_witness.json').exists():
                assert time.monotonic()<deadline
                await asyncio.sleep(.01)
            # Wait for the test HTTP listener, not a fabricated model-ready bit.
            while True:
                try:
                    reader,writer=await asyncio.open_connection(addresses[0],8080)
                    writer.close();await writer.wait_closed();break
                except ConnectionRefusedError:
                    assert time.monotonic()<deadline
                    await asyncio.sleep(.01)
            task=asyncio.create_task(manager.initialize_pods(addresses))
            while not (worker.output/'init_entered.json').exists():
                assert time.monotonic()<deadline
                await asyncio.sleep(.01)
            assert not task.done()
            (worker.output/'release_test_init').touch(exist_ok=False)
            await task
            allocations.append((usages,worker))
        assert [u[0][0].gpu_id for u in allocations]==[0,1]
        for usages,worker in allocations:
            await manager.release_resource(usages)
            assert await platform.worker_deleted(worker.name)
        assert manager.rgpus==[[24]*4]
        reader,writer=await asyncio.open_connection('127.77.49.10',6666)
        writer.write((1).to_bytes(8,'little'));await writer.drain()
        assert await reader.read(100)==b'shared memory deleted'
        writer.close();await writer.wait_closed()
        result.update(passed=True,kind='actual D480 lifecycle and native private storage integration',
            actual_private_storage=True,native_resource_manager=True,native_policy_unchanged=True,
            actual_workers=2,physical_nodes=1,synthetic_http_init=True,
            native_inference_qualified=False,fastload_qualified=False,performance_result=False)
    finally:
        await platform.close()

async def guarded():
    job=asyncio.create_task(work())
    start=time.monotonic()
    with (RAW/'guard.jsonl').open('x') as f:
        while not job.done():
            sample=dict(host=p.host_sample(),resources=p.cgroup_snapshot(group),
                        disk_free=shutil.disk_usage(RAW).free,time_monotonic=time.monotonic())
            f.write(json.dumps(sample)+'\n');f.flush()
            if (sample['host']['available_bytes']<16*p.GIB or sample['disk_free']<100*p.GIB
                    or time.monotonic()-start>170):
                job.cancel()
            await asyncio.sleep(.5)
        await job
asyncio.run(guarded())
