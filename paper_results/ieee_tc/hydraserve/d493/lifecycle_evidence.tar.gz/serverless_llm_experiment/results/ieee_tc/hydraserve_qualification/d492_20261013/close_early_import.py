import json
from pathlib import Path
import subprocess
import sys
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
root=Path(__file__).resolve().parent
identity=p.scope_identity('primelora-tc-aux-d4920000000000000000000000000001.scope')
assert identity['invocation_id']=='f21ceb89e2bb4681a350dcdc49878e50'
group=Path(identity['path'])
entries={str(x):x.read_text().split() for x in group.rglob('cgroup.procs')}
assert entries and not any(entries.values())
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert not group.exists()
with (root/'early_import_closure.json').open('x') as f:
    json.dump(dict(identity=identity,resources=resources,actual_recursive_empty=True,
        failure='test launcher scripts package collision before container creation',
        original_returncode_not_captured=True),f,indent=2)
