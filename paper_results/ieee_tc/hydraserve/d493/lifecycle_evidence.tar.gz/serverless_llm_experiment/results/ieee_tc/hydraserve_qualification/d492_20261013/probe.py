"""Reuse qualified D491 bootstrap/pause/final closure; exercise concrete port."""
from hashlib import sha256
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'d491_20261013'
source=(OLD/'executed_probe.py').read_text()
source=source.replace('d491','d492').replace('D491','D492')
source=source.replace('str(12*p.GIB)','str(4*p.GIB)')
begin=source.index('    ENV = Path(')
end=source.index('\nexcept Exception as exc:',begin)
body=(HERE/'lifecycle_body.py').read_text()
source=source[:begin]+'\n'.join('    '+line if line else '' for line in body.splitlines())+source[end:]
source=source.replace("sys.path.insert(0, str(MAIN))", "sys.path.insert(0, str(MAIN))\nsys.path.insert(0, '/home/qhq/serverless_llm_baselines')")
compile(source,'d492_concrete_platform','exec')
with (HERE/'executed_probe.py').open('x') as f:f.write(source)
exec(compile(source,str(HERE/'executed_probe.py'),'exec'),{'__name__':'__main__','__file__':str(HERE/'executed_probe.py')})
