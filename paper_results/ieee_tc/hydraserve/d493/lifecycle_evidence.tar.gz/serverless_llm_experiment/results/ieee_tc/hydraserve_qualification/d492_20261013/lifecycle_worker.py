"""No-model /init lifecycle test endpoint; explicitly NOT a HydraServe worker.

Actual containers/private IPC/UUID access/native ResourceManager are exercised.
The synthetic /init acknowledgement must never be counted as model readiness.
"""
import json
import os
from pathlib import Path
import socket
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

out=Path('/hydra-output')
objects=list(Path('/dev/shm').glob('psm_*'))
assert len(objects)==1
with objects[0].open('rb') as f:
    assert f.read(64)==bytes(64)
with socket.socket() as s:
    s.bind((os.environ['HYDRASERVE_BIND_IP'],0))
    s.connect((os.environ['STORAGE_IP'],6666))
    s.sendall(bytes(8))
    assert s.recv(100)==b'initialization finished'
with (out/'worker_witness.json').open('x') as f:
    json.dump(dict(native_inference=False,private_storage_bytes=objects[0].stat().st_size,
        visible_gpu_setting=os.environ['NVIDIA_VISIBLE_DEVICES'],
        cuda_device_files=sorted(str(p) for p in Path('/dev').glob('nvidia[0-9]*')),
        env={k:os.environ[k] for k in ('PP_RANK','PP_SIZE','DEST_PP_SIZE','STORAGE_IP')}),f)

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        assert self.path=='/init'
        data=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        assert data['ip_list']==[os.environ['HYDRASERVE_BIND_IP']]
        with (out/'init_entered.json').open('x') as f:
            json.dump(data,f)
        deadline=time.monotonic()+30
        while not (out/'release_test_init').exists():
            assert time.monotonic()<deadline
            time.sleep(.01)
        self.send_response(200);self.end_headers()
        self.wfile.write(b'test-only-no-model')

HTTPServer((os.environ['HYDRASERVE_BIND_IP'],8080),Handler).serve_forever()
