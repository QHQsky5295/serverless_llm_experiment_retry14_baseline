"""Retain executed and revised source identities, actual lifecycle/failure records."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d492_20261013'
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
result=json.loads((RAW/'result.json').read_text())
closures=[json.loads((RAW/name).read_text()) for name in ('probe_closure.json','test_closure.json')]
assert result['passed'] and result['gpu_released'] and not result['performance_result']
assert all(c['actual_recursive_empty'] for c in closures)
assert json.loads((OLD/'early_import_closure.json').read_text())['actual_recursive_empty']
assert 'Ran 38 tests' in (RAW/'tests.log').read_text()
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
files=[OLD/name for name in ('probe.py','executed_probe.py','lifecycle_body.py',
       'lifecycle_worker.py','launch.sh','launch.log','close_early_import.py','early_import_closure.json')]
files += [RAW/name for name in ('probe.py','executed_probe.py','lifecycle_body.py',
       'lifecycle_worker.py','launch.sh','launch.log','probe_identity.json','preflight.json',
       'image_identity.json','pause_adoption.json','result.json','commands.json',
       'guard.jsonl','probe_closure.json','close.py','local_server.py',
       'isolated_platform_executed.py','container_entry_executed.py',
       'test.py','tests.log','test_identity.json','test_closure.json','curate.py','backup.py')]
files += sorted((RAW/'platform').glob('*.command.json'))
files += sorted((RAW/'platform').glob('*.ownership.json'))
files += sorted((RAW/'platform').glob('*.native-request.json'))
# Inspect output carries arbitrary image configuration; exclude. Include native
# storage/worker log commands only, derived from the already owned command record.
for command in sorted((RAW/'platform').glob('*.command.json')):
    args=json.loads(command.read_text())['args']
    if args[0]=='logs':
        stem=command.name.removesuffix('.command.json')
        files.extend([RAW/'platform'/(stem+suffix) for suffix in ('.stdout','.stderr')])
for directory in (RAW/'platform').iterdir():
    if directory.is_dir():
        files += sorted(directory.glob('*.json'))
files += [BASE/name for name in ('HydraServe_project/runtime/isolated_platform.py',
    'HydraServe_project/runtime/container_entry.py','tests/test_ieee_tc_hydraserve_isolated_platform.py',
    'docs/ieee_tc/D493_HYDRASERVE_CONCRETE_LIFECYCLE.md')]
manifest={}
for path in files:
    assert path.is_file() and path.stat().st_size<1024**2,path
    if path.suffix=='.py':compile(path.read_text(),str(path),'exec')
    manifest[str(path)]=dict(sha256=p.digest(path),bytes=path.stat().st_size)
assert len(manifest)==len(files)
dest=BASE/'paper_results/ieee_tc/hydraserve/d493';dest.mkdir()
archive=dest/'lifecycle_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as out:
    for path in files:out.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as source:
    for member in source.getmembers():
        assert sha256(source.extractfile(member).read()).hexdigest()==manifest['/home/qhq/'+member.name]['sha256']
summary=dict(checkpoint_verified=True,performance_result=False,native_inference_qualified=False,
    fastload_qualified=False,concrete_lifecycle_result=result,scope_closures=closures,
    prior_failure=json.loads((OLD/'early_import_closure.json').read_text()),
    protected_verification=protected,tests_count=38,source_manifest=manifest,
    archive_sha256=p.digest(archive),
    post_run_revision='atomic entry publication and bounded CLI cancellation race unit-tested; executed originals retained',
    next='Use concrete lifecycle for real native provider/fastload/app and request contract; not another elementary container/kernel test')
save(dest/'summary.json',summary)
receipt=dict(passed=True,source_count=len(files),archive_sha256=p.digest(archive),summary_sha256=p.digest(dest/'summary.json'))
save(RAW/'curation_result.json',receipt)
print(json.dumps(receipt))
