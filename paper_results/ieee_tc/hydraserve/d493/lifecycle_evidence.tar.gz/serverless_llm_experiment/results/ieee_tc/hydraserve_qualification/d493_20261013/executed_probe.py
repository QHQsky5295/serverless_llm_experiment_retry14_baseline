"""Reuse D477/D478 bounded containers for a no-model IPC/HTTP witness.

Own loopback listener, private shared IPC, no CNI or host network changes. This
does NOT qualify HydraServe, pipeline source-IP identity, CUDA or LoRA arithmetic.
"""
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
OLD = RAW.parent/'d477_20261012'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path.insert(0, '/home/qhq/serverless_llm_baselines')

def save(name, value):
    with (RAW/name).open('x') as handle:
        json.dump(value, handle, indent=2)

identity = p.scope_identity(p.cg_path().name)
save('probe_identity.json', identity)
group = Path(identity['path'])
assert os.sched_getaffinity(0) == {2,3,26,27}
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
gate = p.preflight([RAW], predicted_growth=512*p.MIB)
save('preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert json.loads((OLD/'container_affinity_attempt/container_context_closure.json').read_text())['passed']
runtime = Path('/run/user/1001/primelora-hydra-d477-proxy')
store = OLD/'container_proxy_attempt/container_storage'
assert runtime.is_dir() and runtime.stat().st_uid == os.getuid()
assert store.is_dir() and store.stat().st_uid == os.getuid()
(RAW/'empty_hooks').mkdir()
supervisor = group/'supervisor'
supervisor.mkdir()
(supervisor/'cgroup.procs').write_text(str(os.getpid()))
(group/'cgroup.subtree_control').write_text('+memory +pids')
env = {k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','LANG') if k in os.environ}
env.update(CONTAINERS_CONF=str(RAW/'containers.conf'), XDG_RUNTIME_DIR=str(runtime),
           REGISTRY_AUTH_FILE=str(RAW/'pull-auth.json'), CUDA_VISIBLE_DEVICES='')
base = ['podman','--root',str(store),'--runroot',str(runtime/'runroot'),
        '--storage-driver=vfs','--cgroup-manager=cgroupfs','--events-backend=file',
        '--runtime=/usr/bin/nvidia-container-runtime','--hooks-dir',str(RAW/'empty_hooks')]
commands, created, owners = [], [], {}
pause_owner, sentinel = None, None
result = dict(passed=False, kind='isolated_shared_ipc_loopback_http_no_model',
              native_backend_qualified=False, performance_result=False,
              pipeline_peer_identity_qualified=False, gpu_started=False)

def call(tag, args, check=True, timeout=30):
    started = time.monotonic()
    with (RAW/(tag+'.stdout')).open('x') as out, (RAW/(tag+'.stderr')).open('x') as err:
        run = subprocess.run(base+args, env=env, stdout=out, stderr=err, timeout=timeout)
    commands.append(dict(tag=tag, args=args, returncode=run.returncode,
                         elapsed_s=time.monotonic()-started))
    print(json.dumps(dict(tag=tag, returncode=run.returncode)), flush=True)
    if check:
        assert run.returncode == 0, tag
    return (RAW/(tag+'.stdout')).read_text(), run.returncode

def inspect(name, tag):
    raw, _ = call(tag, ['inspect', name])
    state = json.loads(raw)[0]
    assert state['Config']['Labels']['org.primelora.campaign'] == 'd493'
    return state

def qualify_owner(name, tag):
    state = inspect(name, tag)
    assert state['State']['Running']
    pid = state['State']['Pid']
    owner = p.gpu_process_identity(pid)
    assert owner and owner['uid'] == os.getuid()
    child = Path(owner['cgroup'])
    assert group in child.parents
    assert owner['affinity'] == [2,3,26,27]
    limits = {k:(child/k).read_text().strip() for k in ('memory.max','memory.swap.max','pids.max')}
    assert limits == {'memory.max':str(10*p.GIB),'memory.swap.max':'0','pids.max':'512'}
    namespaces = {k:os.readlink(f'/proc/{pid}/ns/{k}') for k in ('ipc','net')}
    owners[name] = owner
    save(tag+'_ownership.json', dict(identity=owner, limits=limits, namespaces=namespaces))
    return state, namespaces

try:
    info = json.loads(call('info', ['info','--format=json'])[0])
    assert info['store']['graphRoot'] == str(store)
    pausefile = runtime/'libpod/tmp/pause.pid'
    assert pausefile.stat().st_uid == os.getuid()
    pid = int(pausefile.read_text())
    before = p.gpu_process_identity(pid)
    assert before and before['uid'] == os.getuid()
    assert Path(f'/proc/{pid}/comm').read_text().strip() == 'podman pause'
    oldgroup = Path(before['cgroup'])
    assert re.fullmatch(r'podman-pause-[0-9]+\.scope', oldgroup.name)
    oldunit = dict(line.split('=',1) for line in subprocess.check_output([
        'systemctl','--user','show',oldgroup.name,'-p','InvocationID','-p','ControlGroup'],text=True).splitlines())
    assert Path('/sys/fs/cgroup'+oldunit['ControlGroup']) == oldgroup
    assert [row['pid'] for row in p.owned_pids(oldgroup)] == [pid]
    boot = next(int(line.split()[1]) for line in Path('/proc/stat').read_text().splitlines() if line.startswith('btime '))
    assert abs(boot+before['start_ticks']/os.sysconf('SC_CLK_TCK')-pausefile.stat().st_mtime) < 5
    assert p.gpu_process_identity(pid) == before
    (supervisor/'cgroup.procs').write_text(str(pid))
    os.sched_setaffinity(pid, {2,3,26,27})
    pause_owner = p.gpu_process_identity(pid)
    assert pause_owner['start_ticks'] == before['start_ticks']
    assert Path(pause_owner['cgroup']) == supervisor
    assert not (oldgroup/'cgroup.procs').read_text().split()
    assert subprocess.check_output(['systemctl','--user','show',oldgroup.name,'-p','InvocationID','--value'],text=True).strip() == oldunit['InvocationID']
    subprocess.run(['systemctl','--user','stop',oldgroup.name],check=True)
    save('pause_adoption.json',dict(before=before, after=pause_owner, original=oldunit,
                                  before_container_start=True))
    assert not call('prior_containers',['ps','-aq'])[0].strip()
    image = json.loads(call('image',['image','inspect','docker.io/library/ubuntu:22.04'])[0])[0]
    assert image['Id'] == json.loads((OLD/'container_proxy_attempt/image_identity.json').read_text())['Id']
    save('image_identity.json',{k:image.get(k) for k in ('Id','Digest','Size','Architecture','Os')})

    import asyncio
    import importlib.util
    from HydraServe_project.runtime.isolated_platform import ContainerRecipe, IsolatedPodmanPlatform
    from HydraServe_project.runtime.loopback_transport import render_overlays
    from HydraServe_project.runtime.platform_port import render_overlays as render_platform, SOURCE_DIR

    BASE=Path('/home/qhq/serverless_llm_baselines')
    ENV=BASE/'installs/hydraserve_native_d484_20261013'
    PYBASE=Path('/home/qhq/anaconda3/envs/hydraserve_py_20260520')
    NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
    storage=render_overlays(NATIVE)['scripts/kubernetes/vllm/storage_server/local_server.py']
    with (RAW/'local_server.py').open('xb') as f:f.write(storage)
    spec=importlib.util.spec_from_file_location('qualified_native_port_test',BASE/'tests/test_ieee_tc_hydraserve_platform_port.py')
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    uuids=subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).splitlines()
    assert len(uuids)==4
    recipe=ContainerRecipe(image_id=image['Id'],native_images=('native-image',),
        entrypoint=(str(ENV/'bin/python'),'-B','/hydra-entry.py'),
        readonly_mounts=((str(ENV),str(ENV)),(str(PYBASE),str(PYBASE)),(str(RAW),'/probe')),
        environment=dict(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',HOME='/tmp',
            PYTHONUNBUFFERED='1',LD_LIBRARY_PATH=str(PYBASE/'lib'),
            HYDRASERVE_EXEC_JSON=json.dumps([str(ENV/'bin/python'),'-B','/probe/lifecycle_worker.py'])),
        memory_bytes=2*p.GIB,swap_bytes=0,timeout_s=180)
    platform=IsolatedPodmanPlatform(campaign='d493',output=RAW/'platform',parent=group,
        parent_invocation=identity['invocation_id'],parent_inode=identity['inode'],
        parent_limits={'memory.max':str(4*p.GIB),'memory.swap.max':'0'},
        cpu_ids=[2,3,26,27],podman_base=base,podman_environment=env,
        process_identity=p.gpu_process_identity,node=socket.gethostname(),gpu_uuids=uuids,
        gpu_gb=24,network_gbps=1,host_gb=80,storage_address='127.77.49.10',recipe=recipe,
        gate_script=BASE/'HydraServe_project/runtime/container_entry.py')

    async def native_health():
        deadline=time.monotonic()+25
        while True:
            try:
                reader,writer=await asyncio.open_connection('127.77.49.10',6666)
                writer.write(bytes(8));await writer.drain()
                data=await reader.read(100);writer.close();await writer.wait_closed()
                assert data==b'initialization finished'
                return
            except ConnectionRefusedError:
                assert time.monotonic()<deadline
                await asyncio.sleep(.05)

    async def post(url,payload):
        def send():
            request=urllib.request.Request(url,json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=35) as r:
                assert r.read()==b'test-only-no-model'
        await asyncio.to_thread(send)

    async def work():
        try:
            await platform.start_storage(dict(SHM_SIZE='1',USE_CACHE='0',SLOW_EXPR='0',
                REMOTE_SERVER_ADDR='127.77.49.11',NUM_REMOTE_SERVER='1',
                HYDRASERVE_EXEC_JSON=json.dumps([str(ENV/'bin/python'),'-B','/probe/local_server.py'])),
                shm_bytes=1280*p.MIB)
            await native_health()
            ns=helper.load_resource(render_platform(NATIVE)[SOURCE_DIR+'/resource_manager.py'],
                                    post_request_util_succ_async=post)
            manager=ns['ResourceManager'](None,None,platform=platform)
            assert len(manager.node_list)==1 and manager.rgpus==[[24]*4]
            allocations=[]
            for index in range(2):
                allocation=ns['AllocatedResource'](1,[0],[19],[1])
                usages=manager.claim_allocated_resource(allocation)
                addresses=await manager.create_pods('llama2_7b/0',allocation,usages)
                worker=platform.workers[usages[0].pod_name]
                deadline=time.monotonic()+15
                while not (worker.output/'worker_witness.json').exists():
                    assert time.monotonic()<deadline
                    await asyncio.sleep(.01)
                # Wait for the test HTTP listener, not a fabricated model-ready bit.
                while True:
                    try:
                        reader,writer=await asyncio.open_connection(addresses[0],8080)
                        writer.close();await writer.wait_closed();break
                    except ConnectionRefusedError:
                        assert time.monotonic()<deadline
                        await asyncio.sleep(.01)
                task=asyncio.create_task(manager.initialize_pods(addresses))
                while not (worker.output/'init_entered.json').exists():
                    assert time.monotonic()<deadline
                    await asyncio.sleep(.01)
                assert not task.done()
                (worker.output/'release_test_init').touch(exist_ok=False)
                await task
                allocations.append((usages,worker))
            assert [u[0][0].gpu_id for u in allocations]==[0,1]
            for usages,worker in allocations:
                await manager.release_resource(usages)
                assert await platform.worker_deleted(worker.name)
            assert manager.rgpus==[[24]*4]
            reader,writer=await asyncio.open_connection('127.77.49.10',6666)
            writer.write((1).to_bytes(8,'little'));await writer.drain()
            assert await reader.read(100)==b'shared memory deleted'
            writer.close();await writer.wait_closed()
            result.update(passed=True,kind='actual D480 lifecycle and native private storage integration',
                actual_private_storage=True,native_resource_manager=True,native_policy_unchanged=True,
                actual_workers=2,physical_nodes=1,synthetic_http_init=True,
                native_inference_qualified=False,fastload_qualified=False,performance_result=False)
        finally:
            await platform.close()

    async def guarded():
        job=asyncio.create_task(work())
        start=time.monotonic()
        with (RAW/'guard.jsonl').open('x') as f:
            while not job.done():
                sample=dict(host=p.host_sample(),resources=p.cgroup_snapshot(group),
                            disk_free=shutil.disk_usage(RAW).free,time_monotonic=time.monotonic())
                f.write(json.dumps(sample)+'\n');f.flush()
                if (sample['host']['available_bytes']<16*p.GIB or sample['disk_free']<100*p.GIB
                        or time.monotonic()-start>170):
                    job.cancel()
                await asyncio.sleep(.5)
            await job
    asyncio.run(guarded())
except Exception as exc:
    result.update(error_type=type(exc).__name__, error=str(exc))
finally:
    cleanup = []
    for index,name in enumerate(reversed(created)):
        text, code = call('cleanup_inspect_'+str(index),['inspect',name],check=False)
        if code:
            cleanup.append(dict(name=name, exists=False, inspect_returncode=code))
            continue
        state = json.loads(text)[0]
        assert state['Config']['Labels']['org.primelora.campaign'] == 'd493'
        if state['State']['Running']:
            call('stop_'+str(index),['stop','--time=2',name])
        call('remove_'+str(index),['rm',name])
        owner = owners.get(name)
        if owner:
            current = p.gpu_process_identity(owner['pid'])
            assert current is None or current['start_ticks'] != owner['start_ticks']
        cleanup.append(dict(name=name, removed=True))
    if sentinel is not None:
        assert sentinel.stat().st_uid == os.getuid()
        assert sentinel.stat().st_ino == sentinel_inode and sentinel.read_bytes() == payload
        sentinel.unlink()
    if pause_owner is not None:
        current = p.gpu_process_identity(pause_owner['pid'])
        if current is not None:
            assert current == pause_owner
            fd = os.pidfd_open(current['pid'])
            try:
                assert p.gpu_process_identity(current['pid']) == current
                signal.pidfd_send_signal(fd,signal.SIGKILL)
            finally:
                os.close(fd)
    result.update(cleanup=cleanup, disk_free_after=shutil.disk_usage(RAW).free)
    result['gpu_apps_after'] = subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True).strip()
    result['gpu_released'] = not result['gpu_apps_after']
    result['passed'] = result['passed'] and result['gpu_released']
    save('commands.json',commands)
    save('result.json',result)
    print(json.dumps(result),flush=True)
sys.exit(0 if result['passed'] else 1)
