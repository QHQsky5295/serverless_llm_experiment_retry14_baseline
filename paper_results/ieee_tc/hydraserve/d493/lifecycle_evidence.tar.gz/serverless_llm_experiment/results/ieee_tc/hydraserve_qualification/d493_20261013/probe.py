"""Retain D492 launcher failure; resolve scripts before adding baseline path."""
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'d492_20261013'
assert json.loads((OLD/'early_import_closure.json').read_text())['actual_recursive_empty']
for name in ('lifecycle_body.py','lifecycle_worker.py','containers.conf','pull-auth.json'):
    with (HERE/name).open('xb') as f:f.write((OLD/name).read_bytes())
source=(OLD/'executed_probe.py').read_text()
source=source.replace('d492','d493').replace('D492','D493')
source=source.replace("sys.path.insert(0, '/home/qhq/serverless_llm_baselines')\nfrom scripts import ieee_tc_preflight as p", "from scripts import ieee_tc_preflight as p\nsys.path.insert(0, '/home/qhq/serverless_llm_baselines')")
compile(source,'d493_platform','exec')
with (HERE/'executed_probe.py').open('x') as f:f.write(source)
exec(compile(source,str(HERE/'executed_probe.py'),'exec'),{'__name__':'__main__','__file__':str(HERE/'executed_probe.py')})
