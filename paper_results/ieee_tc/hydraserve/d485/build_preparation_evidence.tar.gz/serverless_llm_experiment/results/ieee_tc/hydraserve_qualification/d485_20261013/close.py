"""Reuse exact-identity, actual-empty D481 closure for native build receipts."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d481_20261013/close.py'
source=template.read_text().replace("'backup_main')","'backup_main','build')")
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'close_reused.py')})
