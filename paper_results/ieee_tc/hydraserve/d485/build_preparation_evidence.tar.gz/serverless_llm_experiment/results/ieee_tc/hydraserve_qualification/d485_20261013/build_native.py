"""Bounded official CMake builds using D484's exact isolated dependencies.

No source edits and no model/GPU execution. Reuses the D482/D484 command guard,
preflight and explicit ownership protocol; directly uses the native CMake targets.
"""
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
ENV=BASE/'installs/hydraserve_native_d484_20261013'
CUDA=Path('/home/qhq/anaconda3/envs/slinfer_official_20260612')
NV=CUDA/'lib/python3.11/site-packages/nvidia'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p

def save(name,data):
    with (RAW/name).open('x') as out:
        json.dump(data,out,indent=2)

identity=p.scope_identity(p.cg_path().name)
save('build_identity.json',identity)
limits=p.cgroup_snapshot(Path(identity['path']))
assert all(limits[k]==v for k,v in {'memory.high':3*p.GIB,'memory.max':4*p.GIB,'memory.swap.max':0}.items())
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=NATIVE)
assert json.loads((RAW.parent/'d484_20261013/environment_closure.json').read_text())['passed']
assert json.loads((RAW.parent/'d484_20261013/environment_result.json').read_text())['passed']
gate=p.preflight([RAW,ENV],predicted_growth=8*p.GIB)
save('build_preflight.json',gate)
assert gate['preflight_pass'],gate['issues']
source_paths=['CMakeLists.txt','cmake/utils.cmake','scripts/image/fastload/CMakeLists.txt',
              'scripts/image/fastload/src/CMakeLists.txt','scripts/image/fastload/src/main.cc',
              'scripts/image/fastload/src/pybinding.cc']
sources={name:p.digest(NATIVE/name) for name in source_paths}
tool_paths=['bin/nvcc','bin/nvcc.profile','bin/ptxas','include/cuda.h','include/cuda_runtime.h',
            'nvvm/libdevice/libdevice.10.bc','lib/libcudart.so.12.4.127']
tools={name:p.digest(CUDA/name) for name in tool_paths}
save('build_sources.json',dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=NATIVE,text=True).strip(),
                              sources=sources,readonly_toolchain=tools))
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',CUDA_HOME=str(CUDA),CUDA_PATH=str(CUDA),
         CUDACXX=str(CUDA/'bin/nvcc'),PATH=str(ENV/'bin')+':'+str(CUDA/'bin')+':/usr/bin:/bin',
         PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',MAX_JOBS='1',NVCC_THREADS='1',
         TORCH_CUDA_ARCH_LIST='8.6',VLLM_INSTALL_PUNICA_KERNELS='1',CCACHE_DISABLE='1')
env.pop('PYTHONPATH',None)
env.pop('PYTHONHOME',None)
include_paths=[str(d/'include') for d in sorted(NV.iterdir()) if (d/'include').is_dir()]
library_paths=[str(d/'lib') for d in sorted(NV.iterdir()) if (d/'lib').is_dir()]
env['LD_LIBRARY_PATH']=':'.join([str(ENV/'lib/python3.10/site-packages/torch/lib'),*library_paths,str(CUDA/'lib')])
libs={
    'nvToolsExt':NV/'nvtx/lib/libnvToolsExt.so.1',
    'cublas':NV/'cublas/lib/libcublas.so.12',
    'cublasLt':NV/'cublas/lib/libcublasLt.so.12',
    'curand':NV/'curand/lib/libcurand.so.10',
    'cufft':NV/'cufft/lib/libcufft.so.11',
    'cusparse':NV/'cusparse/lib/libcusparse.so.12',
    'cusolver':NV/'cusolver/lib/libcusolver.so.11',
    'nvrtc':NV/'cuda_nvrtc/lib/libnvrtc.so.12'}
for path in libs.values():
    assert path.is_file(),path
cmake=str(ENV/'bin/cmake')
common=['-G','Ninja','-DCMAKE_BUILD_TYPE=RelWithDebInfo',
        '-DCMAKE_CUDA_ARCHITECTURES=86','-DCUDA_TOOLKIT_ROOT_DIR='+str(CUDA),
        '-DCUDAToolkit_ROOT='+str(CUDA),'-DCMAKE_CUDA_COMPILER='+str(CUDA/'bin/nvcc'),
        '-DCMAKE_INCLUDE_PATH='+';'.join(include_paths),
        '-DCMAKE_LIBRARY_PATH='+';'.join(library_paths),
        '-DCUDNN_INCLUDE_PATH='+str(NV/'cudnn/include'),
        '-DCUDNN_LIBRARY_PATH='+str(NV/'cudnn/lib/libcudnn.so.8')]
common += ['-DCUDA_'+name+'_LIBRARY='+str(path) for name,path in libs.items()]
commands=[
    ('configure_vllm',[cmake,'-S',str(NATIVE),'-B',str(RAW/'build_vllm'),*common,
        '-DVLLM_PYTHON_EXECUTABLE='+str(ENV/'bin/python'),'-DVLLM_TARGET_DEVICE=cuda',
        '-DVLLM_INSTALL_PUNICA_KERNELS=ON','-DNVCC_THREADS=1',
        '-DCMAKE_LIBRARY_OUTPUT_DIRECTORY='+str(RAW/'native_extensions')]),
    ('configure_fastload',[cmake,'-S',str(NATIVE/'scripts/image/fastload'),
        '-B',str(RAW/'build_fastload'),*common,'-DPYTHON_PATH='+str(ENV/'bin/python')]),
    ('build_fastload',[cmake,'--build',str(RAW/'build_fastload'),'--parallel','1']),
    ('build_vllm',[cmake,'--build',str(RAW/'build_vllm'),'--target','default','--parallel','1'])]
save('build_commands.json',dict(commands=commands,library_bindings={k:str(v) for k,v in libs.items()},
                              environment={k:env[k] for k in ('CUDA_HOME','CUDACXX','PATH','LD_LIBRARY_PATH','TORCH_CUDA_ARCH_LIST','MAX_JOBS','NVCC_THREADS')}))
started=time.monotonic()
result=dict(passed=False,performance_result=False,model_started=False,gpu_executed=False,steps=[])
proc=None
try:
    for label,command in commands:
        with (RAW/(label+'.log')).open('x') as log:
            proc=subprocess.Popen(command,cwd=RAW,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            owner=p.gpu_process_identity(proc.pid)
            assert owner and Path(owner['cgroup']).is_relative_to(Path(identity['path']))
            save(label+'_worker.json',owner)
            while proc.poll() is None:
                assert p.host_sample()['available_bytes']>=16*p.GIB
                assert shutil.disk_usage(RAW).free>=100*p.GIB
                if time.monotonic()-started>3600:
                    raise TimeoutError('native_compile_wall_guard')
                time.sleep(1)
            result['steps'].append(dict(label=label,returncode=proc.returncode))
            assert proc.returncode==0,label
    outputs=list((RAW/'native_extensions').glob('*.so'))+[RAW/'build_fastload/lib/libst_pybinding.so']
    assert len(outputs)==4 and all(path.is_file() for path in outputs)
    result['outputs']={str(path):dict(bytes=path.stat().st_size,sha256=p.digest(path)) for path in outputs}
    assert all(p.digest(NATIVE/name)==expected for name,expected in sources.items())
    assert all(p.digest(CUDA/name)==expected for name,expected in tools.items())
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=NATIVE)
    result['passed']=True
except Exception as exc:
    result.update(error_type=type(exc).__name__,error=str(exc))
finally:
    if proc is not None and proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            proc.wait(timeout=5)
    result.update(elapsed_s=time.monotonic()-started,free_bytes=shutil.disk_usage(RAW).free,
                  scope_after=p.cgroup_snapshot(Path(identity['path'])))
    save('build_result.json',result)
    print(json.dumps(result),flush=True)
sys.exit(0 if result['passed'] else 1)
