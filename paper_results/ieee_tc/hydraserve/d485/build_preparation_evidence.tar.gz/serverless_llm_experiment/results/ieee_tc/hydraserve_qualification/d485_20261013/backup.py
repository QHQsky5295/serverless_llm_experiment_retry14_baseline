"""Reuse D480 source/secrets/protected/explicit-path/remote verification."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d485').replace('D480','D485')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index("else:\n    paths =",start)
source=source[:start]+"""    paths = ['docs/ieee_tc/D485_HYDRASERVE_NATIVE_BUILD.md',
        'paper_results/ieee_tc/hydraserve/d485/summary.json',
        'paper_results/ieee_tc/hydraserve/d485/build_preparation_evidence.tar.gz']
    remote, branch = 'origin','main'
    smoke = []
"""+source[end:]
source=source.replace('qualify HydraServe native platform injection seam on CPU',
                      'preserve native fastload build and ongoing official CUDA compilation')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup_reused.py')})
