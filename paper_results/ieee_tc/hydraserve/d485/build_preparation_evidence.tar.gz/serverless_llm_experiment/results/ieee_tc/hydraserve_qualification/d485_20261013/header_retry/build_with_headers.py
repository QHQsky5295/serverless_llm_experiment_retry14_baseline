"""Same official targets, explicit split-wheel headers; reuse completed fastload."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
template=HERE.parent/'build_native.py'
source=template.read_text()
source=source.replace("RAW.parent/'d484_20261013/", "RAW.parent.parent/'d484_20261013/")
marker="commands=[\n"
assert source.count(marker)==1
source=source.replace(marker,"""# pip NVIDIA math headers are outside nvcc's toolkit include directory.
# CMAKE_INCLUDE_PATH only drives find_path, not compiler include flags.
# Do not override toolkit CUDA12.4 runtime headers with wheel CUDA12.1 headers.
math_includes=[NV/name/'include' for name in
               ('cublas','cudnn','cufft','curand','cusolver','cusparse','nvtx')]
assert all(path.is_dir() for path in math_includes)
header_flags=' '.join('-isystem '+str(path) for path in math_includes)
common += ['-DCMAKE_CXX_FLAGS='+header_flags,'-DCMAKE_CUDA_FLAGS='+header_flags]
commands=[
""")
marker="save('build_commands.json',dict(commands=commands,"
assert source.count(marker)==1
source=source.replace(marker,"""assert json.loads((RAW.parent/'build_closure.json').read_text())['passed']
initial=json.loads((RAW.parent/'build_result.json').read_text())
assert not initial['passed'] and initial['steps'][-2]==dict(label='build_fastload',returncode=0)
fastload=RAW.parent/'build_fastload/lib/libst_pybinding.so'
save('reused_fastload.json',dict(path=str(fastload),sha256=p.digest(fastload),bytes=fastload.stat().st_size))
commands=[(label,cmd) for label,cmd in commands if 'fastload' not in label]
save('build_commands.json',dict(commands=commands,""")
source=source.replace("+[RAW/'build_fastload/lib/libst_pybinding.so']", "+[fastload]")
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(HERE/'build_reused.py')})
