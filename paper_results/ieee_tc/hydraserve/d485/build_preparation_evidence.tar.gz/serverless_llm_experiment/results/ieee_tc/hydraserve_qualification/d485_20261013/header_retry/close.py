"""Same actual-empty closure with separate successor records."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
template=HERE.parent.parent/'d481_20261013/close.py'
source=template.read_text().replace("'backup_main')","'backup_main','build')")
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(HERE/'close_reused.py')})
