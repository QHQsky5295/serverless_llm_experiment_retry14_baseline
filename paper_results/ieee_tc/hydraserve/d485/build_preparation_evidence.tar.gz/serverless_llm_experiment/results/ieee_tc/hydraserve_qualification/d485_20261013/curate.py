"""Reuse explicit small-source curation; exclude mutable live build logs."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile
RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as out:
        json.dump(value,out,indent=2)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
initial=json.loads((RAW/'build_result.json').read_text())
closure=json.loads((RAW/'build_closure.json').read_text())
assert not initial['passed'] and closure['passed']
assert initial['steps'][-2]==dict(label='build_fastload',returncode=0)
fastload=json.loads((RAW/'header_retry/reused_fastload.json').read_text())
assert p.digest(Path(fastload['path']))==fastload['sha256']
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
names=['build_native.py','close.py','curate.py','backup.py','build_identity.json',
       'build_preflight.json','build_sources.json','build_commands.json','build_result.json',
       'build_closure.json','configure_vllm.log','configure_fastload.log',
       'build_fastload.log','build_vllm.log',
       'header_retry/build_with_headers.py','header_retry/close.py',
       'header_retry/build_identity.json','header_retry/build_preflight.json',
       'header_retry/build_sources.json','header_retry/build_commands.json',
       'header_retry/configure_vllm.log','header_retry/configure_vllm_worker.json',
       'header_retry/build_vllm_worker.json','header_retry/reused_fastload.json']
for label in ('configure_vllm','configure_fastload','build_fastload','build_vllm'):
    names.append(label+'_worker.json')
files=[RAW/name for name in names]+[BASE/'docs/ieee_tc/D485_HYDRASERVE_NATIVE_BUILD.md']
for path in files:
    if path.suffix=='.py':
        compile(path.read_text(),str(path),'exec')
manifest={str(path):dict(sha256=p.digest(path),bytes=path.stat().st_size) for path in files}
dest=BASE/'paper_results/ieee_tc/hydraserve/d485'
dest.mkdir()
archive=dest/'build_preparation_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in files:
        assert path.stat().st_size<1048576
        bundle.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle.getmembers():
        assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest()==manifest['/home/qhq/'+member.name]['sha256']
live=json.loads((RAW/'header_retry/build_identity.json').read_text())
assert p.scope_still_owned(live) and p.owned_pids(Path(live['path']))
summary=dict(kind='hydraserve_partial_native_compilation_checkpoint',checkpoint_verified=True,
    initial_attempt=initial,initial_closure=closure,fastload=fastload,
    source_manifest=manifest,archive_sha256=p.digest(archive),protected_verification=protected,
    native_backend_qualified=False,numerical_qualified=False,performance_result=False,
    upstream_commit='8ae605de354ccfa2e9095514cdb4a9e9c56aa56b',
    tests_count=0,syntax_checks=True,
    live_work=dict(kind='same_native_compile_with_split_math_headers',scope=live,
                   outcome_file=str(RAW/'header_retry/build_result.json')))
save(dest/'summary.json',summary)
receipt=dict(passed=True,source_count=len(files),archive_sha256=p.digest(archive),
             summary_sha256=p.digest(dest/'summary.json'))
save(RAW/'curation_result.json',receipt)
print(json.dumps(receipt))
