"""Retain initial quote-anchor failure; finish only not-yet-created outputs."""
from pathlib import Path
import json
import sys
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d498_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
for name in ('request_witness.py','lora_registry.json','tokenizer_views.json'):
    assert (RAW/name).read_bytes()==(OLD/name).read_bytes()
for name in ('launch.sh','close_audit.py'):
    assert (RAW/name).read_text()==(OLD/name).read_text().replace('d498','d499')
assert not (RAW/'native_body.py').exists() and not (RAW/'probe.py').exists()
source=(RAW/'prepare.py').read_text()
source=source[source.index("body=(OLD/"):]
source=source.replace('save("native_model_registry.json",await asyncio.to_thread(health))',
    'save(\'native_model_registry.json\',await asyncio.to_thread(health))')
# Correct quoting of the Python string containing the verified native anchor.
source=source.replace("body=replace_one(body,'            save('native_model_registry.json',await asyncio.to_thread(health))\\n',",
    'body=replace_one(body,"            save(\'native_model_registry.json\',await asyncio.to_thread(health))\\n",')
exec(compile(source,str(RAW/'finish_prepare.py'),'exec'),globals())
