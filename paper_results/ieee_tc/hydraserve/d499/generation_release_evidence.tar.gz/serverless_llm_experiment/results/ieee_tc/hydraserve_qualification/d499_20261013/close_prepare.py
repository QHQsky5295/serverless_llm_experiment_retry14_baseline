"""Close only D499's three owned, recursively empty preparation scopes."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
rows=[]
for number in (1,2,6):
    unit=f'primelora-tc-aux-d499{number:028d}.scope'
    identity=p.scope_identity(unit)
    assert p.scope_still_owned(identity)
    group=Path(identity['path'])
    members={str(x):x.read_text().split() for x in (group/'cgroup.procs',*group.rglob('cgroup.procs'))}
    assert not any(members.values()),members
    stats={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
    assert p.scope_still_owned(identity)
    subprocess.run(['systemctl','--user','stop',unit],check=True)
    assert not group.exists()
    rows.append(dict(identity=identity,actual_recursive_empty=True,stats=stats))
with (RAW/'prepare_scope_closure.json').open('x') as f:json.dump(rows,f,indent=2)
print(json.dumps(rows))
