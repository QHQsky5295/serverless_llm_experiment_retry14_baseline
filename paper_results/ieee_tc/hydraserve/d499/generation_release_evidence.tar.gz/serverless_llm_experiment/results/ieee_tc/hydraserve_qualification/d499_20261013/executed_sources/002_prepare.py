"""Reuse D498 real generation; add only owned socket and native release query."""
from pathlib import Path
import json
import sys
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d498_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((OLD/'generation_result.json').read_text())['passed']
for name in ('request_witness.py','lora_registry.json','tokenizer_views.json'):
    with (RAW/name).open('xb') as f:f.write((OLD/name).read_bytes())
for name in ('launch.sh','close_audit.py'):
    with (RAW/name).open('x') as f:f.write((OLD/name).read_text().replace('d498','d499'))
body=(OLD/'native_body.py').read_text().replace('d498','d499')
body=replace_one(body,'            save("native_model_registry.json",await asyncio.to_thread(health))\n',
'''            save("native_model_registry.json",await asyncio.to_thread(health))
            # Original read-only query: 1=known but cleared, 2=never known,3=resident.
            # No clear-cache/free command, sleep injection or pretend-ready endpoint.
            reader,writer=await asyncio.open_connection(platform.storage_address,6666)
            try:
                writer.write((3).to_bytes(8,'little')+b'llama2_7b/0')
                await writer.drain()
                flag=int.from_bytes(await asyncio.wait_for(reader.readexactly(8),5),'little')
            finally:
                writer.close(); await writer.wait_closed()
            before_delete=p.gpu_process_identity(worker.owner['pid'])
            assert before_delete and before_delete['start_ticks']==worker.owner['start_ticks']
            _,storage_log=await platform._call(['logs',platform.storage.container_name])
            release=dict(native_query_flag=flag,worker_still_alive=before_delete,
                observed_before_generation_and_worker_delete=True,
                native_free_buffer_logged='free_buffer: (0, 13476855675)' in storage_log)
            save('native_release_before_delete.json',release)
            assert flag==1 and release['native_free_buffer_logged'],release
''')
with (RAW/'native_body.py').open('x') as f:f.write(body)
template=(OLD/'executed_prepare.py').read_text().replace('d498','d499')
template=replace_one(template,'overlays=render_overlays(NATIVE,request_contract=True)',
    'overlays=render_overlays(NATIVE,request_contract=True,shm_control=True)')
with (RAW/'executed_prepare.py').open('x') as f:f.write(template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
