"""Append-only D498 actual generation + D499 release evidence; reuse prior curation."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import urllib.request
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d498_20261013'
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
generations=[]
for root in (OLD,RAW):
    assert json.loads((root/'closure.json').read_text())['actual_recursive_empty']
    assert json.loads((root/'result.json').read_text())['passed']
    generation=json.loads((root/'generation_result.json').read_text())
    assert generation['passed'] and len(generation['requests'])==2
    assert not generation['performance_result'] and not generation['full_scheduler_qualified']
    for row in generation['requests']:assert row['actual_tokens']==row['target_tokens']
    generations.append(generation)
    for original,record in json.loads((root/'source_manifest.json').read_text()).items():
        # D498 live code may have evolved after its execution. Its captured source has not.
        assert p.digest(Path(record['snapshot']))==record['sha256'],original
release=json.loads((RAW/'native_release_before_delete.json').read_text())
assert release['native_query_flag']==1 and release['native_free_buffer_logged']
assert release['observed_before_generation_and_worker_delete']
comparison=[]
for a,b in zip(*(x['requests'] for x in generations)):
    assert (a['request_id'],a['prompt_sha256'],a['adapter_id'],a['target_tokens']) == (b['request_id'],b['prompt_sha256'],b['adapter_id'],b['target_tokens'])
    comparison.append(dict(request_id=a['request_id'],output_ids_equal=a['output_token_ids']==b['output_token_ids']))
save(RAW/'before_after_output_audit.json',comparison)
tests=['tests.test_ieee_tc_hydraserve_'+name for name in ('shm_control','tokenizer_compat',
    'request_contract','native_delivery','isolated_platform','platform_port',
    'stage_binding','worker_binding','layer_identity')]
with (RAW/'cpu_tests.log').open('x') as f:
    subprocess.run([sys.executable,'-B','-m','unittest',*tests,'-v'],cwd=BASE,
        stdout=f,stderr=subprocess.STDOUT,check=True,timeout=40)
assert 'Ran 70 tests' in (RAW/'cpu_tests.log').read_text()
url='https://raw.githubusercontent.com/LLMServe/HydraServe/8ae605de354ccfa2e9095514cdb4a9e9c56aa56b/scripts/image/app.py'
with urllib.request.urlopen(url,timeout=20) as response:data=response.read(200000)
assert sha256(data).hexdigest()=='cab8bc3195159a51da0c4e8ca332a38b049f65891e49cdcd2534fe984235717f'
with (RAW/'official_app.py').open('xb') as f:f.write(data)
save(RAW/'online_sources.json',dict(official_app=dict(url=url,sha256=sha256(data).hexdigest()),
    python_docs=['https://docs.python.org/3.10/library/asyncio-task.html#asyncio.run',
    'https://docs.python.org/3.10/library/asyncio-eventloop.html#working-with-socket-objects-directly']))
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'];save(RAW/'protected_verification.json',protected)
paths=[BASE/name for name in ('HydraServe_project/runtime/shm_control.py',
    'HydraServe_project/runtime/native_delivery.py','tests/test_ieee_tc_hydraserve_shm_control.py',
    'docs/ieee_tc/D499_HYDRASERVE_GENERATION_AND_RELEASE.md')]
for root in (OLD,RAW):
    paths += [x for x in root.iterdir() if x.is_file() and not x.is_symlink()
              and x.name not in ('pull-auth.json','curation.log')]
    for child in ('overlays','executed_sources','platform'):
        paths += [x for x in (root/child).rglob('*') if x.is_file() and not x.is_symlink()]
    paths += [root/'launch_gate.launch'/x for x in ('watchdog.jsonl','watchdog.stderr','exec_receipt.json','service.log')]
paths=sorted(set(paths))
assert all(x.is_file() and not x.is_symlink() for x in paths)
manifest={str(x):dict(sha256=p.digest(x),bytes=x.stat().st_size) for x in paths}
dest=BASE/'paper_results/ieee_tc/hydraserve/d499';dest.mkdir()
archive=dest/'generation_release_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as out:
    for path in paths:out.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle.getmembers():
        assert sha256(bundle.extractfile(member).read()).hexdigest()==manifest['/home/qhq/'+member.name]['sha256']
summary=dict(checkpoint_verified=True,performance_result=False,cpu_tests_passed=70,
    d498_actual_gpu_generation_passed=True,d499_actual_gpu_generation_passed=True,
    d499_native_shm_released_before_generation_and_delete=True,output_comparison=comparison,
    completed_requests_per_run=2,full_scheduler_qualified=False,remote_delivery_qualified=False,
    numerical_lora_equivalence_qualified=False,pipeline_and_consolidation_qualified=False,
    weight_bytes_copied=0,protected_verification=protected,source_manifest=manifest,
    archive_sha256=p.digest(archive),next='Full native Scheduler and request-driven real-remote LoRA integration; no new model/trace/pool')
save(dest/'summary.json',summary)
save(RAW/'curation_result.json',dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size,
    summary_sha256=p.digest(dest/'summary.json'),archive_sha256=p.digest(archive)))
print(json.dumps(dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size,cpu_tests=70)))
