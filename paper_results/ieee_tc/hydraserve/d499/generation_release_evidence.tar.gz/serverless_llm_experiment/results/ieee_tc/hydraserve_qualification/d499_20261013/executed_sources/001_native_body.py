    import asyncio
    from hashlib import sha256
    import importlib.util
    from HydraServe_project.runtime.isolated_platform import ContainerRecipe,IsolatedPodmanPlatform
    from HydraServe_project.runtime.platform_port import render_overlays as render_platform,SOURCE_DIR

    BASE=Path('/home/qhq/serverless_llm_baselines')
    ENV=BASE/'installs/hydraserve_native_d484_20261013'
    PYBASE=Path('/home/qhq/anaconda3/envs/hydraserve_py_20260520')
    CUDA=Path('/home/qhq/anaconda3/envs/slinfer_official_20260612')
    NATIVE=BASE/'vendor_new_baselines/HydraServe_main_20260520'
    MODEL=Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf')
    NCCL=RAW.parent/'d486_20261013/private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1'
    FAST=RAW.parent/'d485_20261013/build_fastload/lib/libst_pybinding.so'
    assert sha256(NCCL.read_bytes()).hexdigest()=='005503b62b9fe466b6b2f60ba2ad1daa4571196ffcb82a3d77a3c775bfcd5ac8'
    assert sha256(FAST.read_bytes()).hexdigest()=='f11b31a82f654d7c8950d85e05461d31b5cc45469720deb1e784d47022571e44'
    for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
        assert sha256(Path(path).read_bytes()).hexdigest()==record['sha256']
    helper_spec=importlib.util.spec_from_file_location('native_resource_helper',BASE/'tests/test_ieee_tc_hydraserve_platform_port.py')
    helper=importlib.util.module_from_spec(helper_spec);helper_spec.loader.exec_module(helper)
    nv=CUDA/'lib/python3.11/site-packages/nvidia'
    libraries=[ENV/'lib/python3.10/site-packages/torch/lib',PYBASE/'lib',
               *[d/'lib' for d in sorted(nv.iterdir()) if (d/'lib').is_dir()],CUDA/'lib']
    readonly=[ENV,PYBASE,CUDA,MODEL,NCCL,BASE/'HydraServe_project']
    readonly += [Path(row["adapter_path"]) for row in json.loads((RAW/"lora_registry.json").read_text())]
    readonly += [Path(row["source"]) for row in json.loads((RAW/"tokenizer_views.json").read_text())]
    mounts=[(str(x),str(x)) for x in readonly]
    mounts += [(str(RAW/"lora_registry.json"),"/hydra-loras.json")]
    mounts += [(str(RAW/'overlays'),'/hydra-overlay'),(str(RAW/'metadata'),'/mnt/model-cache'),
               (str(FAST),'/vllm-workspace/libst_pybinding.so')]
    worker_env=dict(LD_LIBRARY_PATH=':'.join(map(str,libraries)),PYTHONPATH=str(BASE),
        PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTHONUNBUFFERED='1',
        HOME='/tmp',CUDA_CACHE_PATH='/tmp/cuda-cache',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        VLLM_NO_USAGE_STATS='1',VLLM_NCCL_SO_PATH=str(NCCL),
        HYDRASERVE_OVERLAY_ROOT='/hydra-overlay',
        HYDRASERVE_OVERLAY_SHA256=sha256((RAW/'overlays/manifest.json').read_bytes()).hexdigest(),
        HYDRASERVE_PARTITION_MANIFEST='/mnt/model-cache/partition.json',
        HYDRASERVE_PARTITION_SHA256=sha256((RAW/'metadata/partition.json').read_bytes()).hexdigest(),
        HYDRASERVE_NATIVE_ENTRY='scripts/image/app.py',
        HYDRASERVE_EXEC_JSON=json.dumps([str(ENV/'bin/python'),'-B',
            str(BASE/'HydraServe_project/runtime/native_overlay_entry.py')]))
    worker_env.update(HYDRASERVE_LORA_REGISTRY="/hydra-loras.json",
        HYDRASERVE_LORA_REGISTRY_SHA256=sha256((RAW/"lora_registry.json").read_bytes()).hexdigest())
    uuids=subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).splitlines()
    assert len(uuids)==4
    recipe=ContainerRecipe(image_id=image['Id'],native_images=('native-image',),
        entrypoint=(str(ENV/'bin/python'),'-B','/hydra-entry.py'),readonly_mounts=tuple(mounts),
        environment=worker_env,memory_bytes=80*p.GIB,swap_bytes=2*p.GIB,timeout_s=1800)
    platform=IsolatedPodmanPlatform(campaign='d499',output=RAW/'platform',parent=group,
        parent_invocation=identity['invocation_id'],parent_inode=identity['inode'],
        parent_limits={'memory.high':str(72*p.GIB),'memory.max':str(80*p.GIB),'memory.swap.max':str(2*p.GIB)},
        cpu_ids=list(range(4,24))+list(range(28,48)),podman_base=base,podman_environment=env,
        process_identity=p.gpu_process_identity,node=socket.gethostname(),gpu_uuids=uuids,
        gpu_gb=24,network_gbps=1,host_gb=80,storage_address='127.77.49.10',recipe=recipe,
        gate_script=BASE/'HydraServe_project/runtime/container_entry.py')

    async def listen(address,port,worker,health=False):
        start=time.monotonic()
        while True:
            try:
                reader,writer=await asyncio.wait_for(asyncio.open_connection(address,port),2)
                if health:
                    writer.write(bytes(8));await writer.drain()
                    data=await asyncio.wait_for(reader.read(100),5)
                    assert data==b'initialization finished',data
                writer.close();await writer.wait_closed()
                return time.monotonic()-start
            except ConnectionRefusedError:
                if time.monotonic()-start>1800:raise
                # Probe actual PID cheaply; no recurring container CLI in loading path.
                current=p.gpu_process_identity(worker.owner['pid'])
                if not current or current['start_ticks']!=worker.owner['start_ticks']:
                    raise RuntimeError('native component exited before listening: '+worker.name)
                await asyncio.sleep(.25)

    async def post(url,payload):
        def send():
            request=urllib.request.Request(url,json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
            start=time.monotonic()
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=1800) as response:
                value=json.loads(response.read())
                save('native_init_response.json',dict(status=response.status,response=value,elapsed_s=time.monotonic()-start))
                assert response.status==200
        await asyncio.to_thread(send)

    async def work():
        try:
            # Existing checkpoint payload is <13GiB. Native local_server touches
            # whole integer-GiB pool; all bytes are charged to the common parent.
            index=json.loads((MODEL/'model.safetensors.index.json').read_text())
            file_bytes=sum((MODEL/x).stat().st_size for x in set(index['weight_map'].values()))
            shm_gib=(file_bytes+p.GIB-1)//p.GIB
            save('shm_capacity.json',dict(existing_shard_bytes=file_bytes,shm_gib=shm_gib,
                native_pool_bytes=shm_gib*p.GIB,private_tmpfs_bytes=shm_gib*p.GIB+256*p.MIB))
            await platform.start_storage(dict(SHM_SIZE=str(shm_gib),USE_CACHE='0',SLOW_EXPR='0',
                REMOTE_SERVER_ADDR='127.77.49.11',NUM_REMOTE_SERVER='1',
                HYDRASERVE_NATIVE_ENTRY='scripts/kubernetes/vllm/storage_server/local_server.py'),
                shm_bytes=shm_gib*p.GIB+256*p.MIB)
            storage_wait=await listen('127.77.49.10',6666,platform.storage,True)
            print('native private storage initialized',flush=True)
            await platform.start_provider('provider','127.77.49.11',dict(
                MODELSCOPE_CACHE='/mnt/model-cache',HYDRASERVE_LOCAL_MODEL_ID='llama2_7b',
                HYDRASERVE_HF_SHARDS='1',LOCAL_SERVER='0',ENABLE_PARA='0',CPU_ENV='1',
                HYDRASERVE_NATIVE_ENTRY='scripts/kubernetes/vllm/storage_server/remote_server.py'))
            provider_wait=await listen('127.77.49.11',8888,platform.providers['provider'],True)
            print('native CPU provider initialized',flush=True)
            save('provider_ready.json',dict(storage_wait_s=storage_wait,provider_wait_s=provider_wait))
            ns=helper.load_resource(render_platform(NATIVE)[SOURCE_DIR+'/resource_manager.py'],
                                    post_request_util_succ_async=post)
            manager=ns['ResourceManager'](None,None,platform=platform)
            allocation=ns['AllocatedResource'](1,[0],[19],[1])
            usages=manager.claim_allocated_resource(allocation)
            addresses=await manager.create_pods('llama2_7b/0',allocation,usages)
            worker=platform.workers[usages[0].pod_name]
            result['gpu_started']=True
            await listen(addresses[0],8080,worker)
            await manager.initialize_pods(addresses)
            def health():
                opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
                with opener.open('http://'+addresses[0]+':8080/health',timeout=10) as r:
                    assert r.status==200
                with opener.open('http://'+addresses[0]+':8080/v1/models',timeout=10) as r:
                    return json.loads(r.read())
            save('native_model_registry.json',await asyncio.to_thread(health))
            # Original read-only query: 1=known but cleared, 2=never known,3=resident.
            # No clear-cache/free command, sleep injection or pretend-ready endpoint.
            reader,writer=await asyncio.open_connection(platform.storage_address,6666)
            try:
                writer.write((3).to_bytes(8,'little')+b'llama2_7b/0')
                await writer.drain()
                flag=int.from_bytes(await asyncio.wait_for(reader.readexactly(8),5),'little')
            finally:
                writer.close(); await writer.wait_closed()
            before_delete=p.gpu_process_identity(worker.owner['pid'])
            assert before_delete and before_delete['start_ticks']==worker.owner['start_ticks']
            _,storage_log=await platform._call(['logs',platform.storage.container_name])
            release=dict(native_query_flag=flag,worker_still_alive=before_delete,
                observed_before_generation_and_worker_delete=True,
                native_free_buffer_logged='free_buffer: (0, 13476855675)' in storage_log)
            save('native_release_before_delete.json',release)
            assert flag==1 and release['native_free_buffer_logged'],release
            save("generation_worker_identity.json",dict(address=addresses[0],owner=worker.owner,
                entry=json.loads((worker.output/"entry.json").read_text()),
                host_time_namespace=os.readlink("/proc/self/ns/time"),
                worker_time_namespace=os.readlink(f"/proc/{worker.owner['pid']}/ns/time")))
            client_env=dict(os.environ,PYTHONPATH=str(BASE)+":"+str(MAIN),USE_TORCH="0",USE_TF="0",
                CUDA_VISIBLE_DEVICES="",HF_HUB_OFFLINE="1",TRANSFORMERS_OFFLINE="1",
                NO_PROXY="*",no_proxy="*",PYTHONNOUSERSITE="1",PYTHONDONTWRITEBYTECODE="1")
            with (RAW/"request_witness.log").open("x") as log:
                client=await asyncio.create_subprocess_exec(str(ENV/"bin/python"),"-B",
                    str(RAW/"request_witness.py"),env=client_env,stdout=log,stderr=subprocess.STDOUT)
                code=await client.wait()
            assert code==0,(code,"see request_witness.log")
            generation=json.loads((RAW/"generation_result.json").read_text())
            assert generation["passed"] and len(generation["requests"])==2
            await manager.release_resource(usages)
            assert await platform.worker_deleted(worker.name)
            assert manager.rgpus==[[24]*4]
            result.update(passed=True,actual_cpu_provider=True,actual_private_storage=True,
                native_app_init=True,shared_memory_fastload=True,physical_nodes=1,
                request_lora_qualified=False,native_generation_qualified=True,performance_result=False,
                qualification_scope="two existing nonzero adapter request bindings; not numerical/full-scheduler/remote")
        finally:
            await platform.close()

    asyncio.run(asyncio.wait_for(work(),1720))
