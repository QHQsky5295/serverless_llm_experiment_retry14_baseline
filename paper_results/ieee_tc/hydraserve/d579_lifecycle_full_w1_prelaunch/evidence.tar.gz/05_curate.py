"""Reuse D539 append-only curation for the qualified D579 full-W1 preregistration."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert sha256(original.read_bytes()).hexdigest()=='5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("((RAW,'review'),(CLEAN,'cleanup'))", "((RAW,'prepare'),)")
old=source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old,"""prepared=read(RAW/'prepare_result.json')
assert prepared['passed'] and prepared['prepared_not_launched'] and not prepared['performance_result']
assert prepared['n_plan']==4000 and prepared['full_config_equal'] and prepared['native_overlays_unchanged']
assert prepared['plan_identity']['profile']=='W1'
assert p.digest(RAW/'http_7b_4000.json')==p.digest(RAW.parent/'d546_20261015/http_7b_4000.json')
for path,record in read(RAW/'source_manifest.json').items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
for record in read(RAW/'preregistration.json')['references'].values():
    assert p.digest(Path(record['path']))==record['sha256']
overlays=sorted((RAW/'overlays').rglob('*.py'))
assert len(overlays)==16
for path in overlays:
    assert p.digest(path)==p.digest(RAW.parent/'d574_20261016/overlays'/path.relative_to(RAW/'overlays'))
""")
old=source[source.index('specs=['):source.index('reports=[]')]
replace(old,"""files=sorted(x for x in RAW.iterdir() if x.is_file() and not x.is_symlink()
    and x.suffix in ('.py','.json','.sh') and x.name not in ('pull-auth.json','curation_identity.json'))
for child in ('executed_sources','overlays','metadata'):
    files+=sorted(x for x in (RAW/child).rglob('*') if x.is_file() and not x.is_symlink())
files.append(original)
copies={name:RAW/name for name in ('prepare_result.json','preregistration.json',
    'prepare_resource_gate.json','prepare_closure.json','source_manifest.json')}
specs=[('hydraserve/d579_lifecycle_full_w1_prelaunch',files,copies)]
""")
replace("if path.suffix=='.py':ast.parse(data)", """if path.suffix=='.py':
                if path==RAW/'native_body.py' or (path.parent==RAW/'executed_sources' and path.name.endswith('_native_body.py')):
                    import textwrap
                    ast.parse(textwrap.dedent(data.decode('utf-8')))
                else:ast.parse(data)
            if path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)""")
replace('Executed assertions plus source AST and archive round-trip; no new serving change or repeated GPU tests',
        'D574 native qualification and D576 completed full W0 reused; D579 exact D546 W1 inputs and D574 overlays/source checks; AST/shell syntax and SHA roundtrip; no new GPU run yet')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py'),'original':original})
