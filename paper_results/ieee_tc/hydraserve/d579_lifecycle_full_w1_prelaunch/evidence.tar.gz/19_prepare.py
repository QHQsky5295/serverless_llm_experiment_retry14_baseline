"""Reuse D576 qualified full-run preparation with the original D546 W1 input."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d576_20261016/prepare.py'
source=original.read_text().replace('d576_20261016','d579_20261016').replace('d576','d579')
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("FULL=RAW.parent/'d510_20261013'", "FULL=RAW.parent/'d546_20261015'")
replace("cfg['request_view']=='trace_prefix_v1'", "cfg['request_view']=='trace_w1_v1' and cfg['replay_profile']=='W1'")
replace("workload='W0'", "workload='W1'")
replace("'4000 existing W0 requests'", "'4000 existing W1 requests'")
replace("'full4000 W0'", "'full4000 W1'")
replace('one complete known-trace W0 development observation',
        'one complete known-trace W1 development observation')
replace("audit=audit.replace('full-W1','full-W0').replace('full_w1','full_w0').replace('observed_w1_g1_feasible','observed_w0_g1_feasible')",
        "assert 'full_w1_evaluation.json' in audit")
replace('comparisons=[]', """previous=RAW.parent/'d576_20261016'
assert json.loads((previous/'full_w0_evaluation.json').read_text())['full_audit_pass']
assert json.loads((previous/'cache_cleanup_after.json').read_text())['removed']
for campaign,phases in [('d577_20261016',('cleanup',)),('d578_20261016',('storage','curation','publication'))]:
    for phase in phases:
        closed=json.loads((RAW.parent.parent/'storage_maintenance'/campaign/(phase+'_closure.json')).read_text())
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists()
for path,record in json.loads((previous/'source_manifest.json').read_text()).items():
    if str(previous) not in path:
        assert digest(path)==digest(record['snapshot'])==record['sha256'],path
comparisons=[]""")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'prepare.py')})
