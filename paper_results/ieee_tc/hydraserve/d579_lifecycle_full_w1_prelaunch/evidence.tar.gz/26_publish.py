"""Reuse D539 exact-path publication for the D579 full-W1 preregistration."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert sha256(original.read_bytes()).hexdigest()=='34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('3e759d75b6e69e182d646d87aca5090f5935024f','c1cd00e3d2c2d30fc515a1734c288a40410907b4')
replace("('review','curation')","('prepare','curation')")
replace("names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D579_HYDRASERVE_LIFECYCLE_FULL_W1.md']")
replace("'curation_receipt.json','close.py'","'curation_receipt.json','close_cpu.py'")
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: preregister qualified HydraServe full W1 replay (D579)')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py')})
