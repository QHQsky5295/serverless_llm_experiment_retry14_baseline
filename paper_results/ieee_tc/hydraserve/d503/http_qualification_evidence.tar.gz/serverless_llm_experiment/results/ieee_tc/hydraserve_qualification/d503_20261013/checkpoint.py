"""Reuse append-only D499 archive/protected-asset procedure for actual D503."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d499_20261013/checkpoint.py').read_text()
start=source.index('generations=[]')
end=source.index('protected=p.verify_seal',start)
source=source[:start]+'''assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((RAW/'result.json').read_text())['passed']
generation=json.loads((RAW/'generation_result.json').read_text())
assert generation['passed'] and generation['actual_native_idle_release']
assert generation['counts']['N_response']==100 and generation['counts']['N_failed']==0
audit=json.loads((RAW/'http_audit.json').read_text())
assert audit['passed'] and not audit['performance_result'] and audit['n_correct'] is None
assert audit['n_native_contract_complete']==100 and audit['remote_transfers']==29
assert audit['remote_wire_bytes']==50650865 and not audit['pack_performed']
assert audit['physical']['measurement_complete'] and audit['physical']['native_contexts_qualified']
assert not audit['physical']['open_lease_ids']
assert 'Ran 88 tests' in (RAW/'cpu2.log').read_text() and '\\nOK\\n' in (RAW/'cpu2.log').read_text()
for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
    assert p.digest(Path(record['snapshot']))==record['sha256']
    assert p.digest(Path(path))==record['sha256']
for path,digest in audit['source_sha256'].items():assert p.digest(Path(path))==digest
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
'''+source[end:]
start=source.index('paths=[BASE/name')
end=source.index('paths=sorted(set(paths))',start)
source=source[:start]+'''paths=[BASE/name for name in (
    'HydraServe_project/runtime/http_contract.py','HydraServe_project/runtime/physical_lifecycle.py',
    'HydraServe_project/runtime/request_contract.py','HydraServe_project/runtime/controller_runtime.py',
    'HydraServe_project/runtime/isolated_platform.py','scripts/prepare_ieee_tc_serverless_stack.py',
    'tests/test_ieee_tc_hydraserve_http_contract.py','tests/test_ieee_tc_hydraserve_physical_lifecycle.py',
    'docs/ieee_tc/D503_HYDRASERVE_COMMON_HTTP.md')]
paths += [x for x in RAW.iterdir() if x.is_file() and not x.is_symlink()
          and x.name not in ('pull-auth.json','curation.log')]
for child in ('overlays','executed_sources','platform','physical','remote_artifacts/receipts',
              'remote_artifacts/journals','adapter_views/.receipts'):
    paths += [x for x in (RAW/child).rglob('*') if x.is_file() and not x.is_symlink()]
paths += [RAW/'remote_artifacts/run_contract.json']
paths += [x for x in (RAW/'launch_gate.launch').iterdir() if x.is_file() and not x.is_symlink()]
'''+source[end:]
source=source.replace("hydraserve/d499'", "hydraserve/d503'").replace('generation_release_evidence.tar.gz','http_qualification_evidence.tar.gz')
start=source.index('summary=dict(')
end=source.index("save(dest/'summary.json'",start)
source=source[:start]+'''summary=dict(checkpoint_verified=True,performance_result=False,cpu_tests_passed=88,
    full_native_scheduler_exercised=True,common_http_open_loop_qualified=True,
    n_native_contract_complete=100,n_correct=None,actual_unique_adapters=29,
    actual_native_idle_release=True,http_audit=audit,
    numerical_lora_equivalence_qualified=False,pipeline_and_consolidation_qualified=False,
    allocation_boundary='actual platform reservation before container creation; not earlier native bookkeeping',
    copied_view_weight_bytes=0,protected_verification=protected,source_manifest=manifest,
    archive_sha256=p.digest(archive),next='500-ID functional then1000/4000; numerical qualification open; no new model/trace/pool')
'''+source[end:]
source=source.replace('cpu_tests=70','cpu_tests=88')
exec(compile(source,str(RAW/'checkpoint_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'checkpoint.py')})
