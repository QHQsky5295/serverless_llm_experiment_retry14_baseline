"""Whole existing HydraServe CPU regression + new actual HTTP/pidfd tests."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
names=('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
       'tokenizer_compat','request_contract','native_delivery','isolated_platform',
       'platform_port','stage_binding','worker_binding','layer_identity')
with (RAW/'cpu2.log').open('x') as f:
    subprocess.run([sys.executable,'-B','-m','unittest',*['tests.test_ieee_tc_hydraserve_'+n for n in names],'-v'],
        cwd=BASE,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=60)
print(json.dumps(dict(passed=True)))
