"""Reuse explicit stage/checksum/protection/secrets/test/push gates."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d503').replace('D480','D503')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['HydraServe_project/runtime/http_contract.py',
        'HydraServe_project/runtime/physical_lifecycle.py',
        'HydraServe_project/runtime/request_contract.py',
        'HydraServe_project/runtime/controller_runtime.py',
        'HydraServe_project/runtime/isolated_platform.py',
        'scripts/prepare_ieee_tc_serverless_stack.py',
        'tests/test_ieee_tc_hydraserve_http_contract.py',
        'tests/test_ieee_tc_hydraserve_physical_lifecycle.py',
        'docs/ieee_tc/D503_HYDRASERVE_COMMON_HTTP.md',
        'paper_results/ieee_tc/hydraserve/d503/summary.json',
        'paper_results/ieee_tc/hydraserve/d503/http_qualification_evidence.tar.gz']
    remote, branch = 'origin','main'
    smoke = ['tests.test_ieee_tc_hydraserve_'+name for name in
        ('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
         'tokenizer_compat','request_contract','native_delivery','isolated_platform',
         'platform_port','stage_binding','worker_binding','layer_identity')]
'''+source[end:]
source=source.replace('qualify HydraServe native platform injection seam on CPU',
    'qualify native HydraServe common HTTP 100-request replay and physical accounting')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup_reused.py')})
