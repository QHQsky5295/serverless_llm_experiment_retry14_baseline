"""Extend D502 native recipe with common HTTP publisher and physical union."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import urllib.request
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d502_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
assert json.loads((OLD/'generation_result.json').read_text())['passed']
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
def put(name,data):
    with (RAW/name).open('x') as f:f.write(data)
sources={}
for name in ('main','scheduler','engine','ModelInfo'):
    url='https://raw.githubusercontent.com/LLMServe/HydraServe/8ae605de354ccfa2e9095514cdb4a9e9c56aa56b/scripts/kubernetes/vllm/src/'+name+'.py'
    with urllib.request.urlopen(url,timeout=20) as r:data=r.read(200000)
    assert data==(BASE/'vendor_new_baselines/HydraServe_main_20260520/scripts/kubernetes/vllm/src'/f'{name}.py').read_bytes()
    put('official_'+name+'.py',data.decode())
    sources[name]=dict(url=url,sha256=sha256(data).hexdigest())
put('online_sources.json',json.dumps(sources,indent=2))
for name in ('model_registration.json','close_pause.py','close_audit.py','close_cpu.py','collect_remote.py','start_remote.sh'):
    put(name,(OLD/name).read_text().replace('d502','d503'))
cfg=json.loads((RAW.parent.parent/'serverless_qualification/d409_20261011/http_7b_100.json').read_text())
cfg.update(schema='ieee_tc_hydraserve_http_replay_v1',physical_lifecycle='hydraserve_container_union_v1',
    url='http://127.0.0.1:8453/v1/chat/completions',experiment_role='native_hydraserve_http_qualification')
put('http_7b_100.json',json.dumps(cfg,indent=2))
put('remote_input_config.json',json.dumps({k:cfg[k] for k in
    ('ingress_mode','pool_index','pool_index_sha256','remote_artifacts')},indent=2))
pool=json.loads(Path(cfg['pool_index']).read_text())
registry=[dict(adapter_id=aid,adapter_index=index,adapter_path=str(RAW/'adapter_views'/aid))
    for index,aid in enumerate(sorted(r['id'] for r in pool['artifacts']),1)]
assert len(registry)==500
put('lora_registry.json',json.dumps(registry,indent=2))
launch=(OLD/'launch.sh').read_text().replace('d502','d503')
launch=replace_one(launch,'--predicted-growth-gib 1',
    '--predicted-growth-gib 4 --http-replay-config "$RAW/http_7b_100.json"')
put('launch.sh',launch)
body=(OLD/'native_body.py').read_text().replace('d502','d503')
body=replace_one(body,'    async def listen(address,port,worker,health=False):', '''    from faaslora.clock import local_monotonic_clock_id
    from HydraServe_project.runtime.http_contract import NativeHTTPAdapter
    from HydraServe_project.runtime.physical_lifecycle import NativeWorkerLedger
    context=json.loads(Path(os.environ['FAASLORA_TC_LAUNCH_RECEIPT']).read_text())['external_replay']
    http_cfg=json.loads((RAW/'http_7b_100.json').read_text())
    plan=support.load_http_replay_plan(http_cfg)
    assert plan.identity()==context['plan'] and context['clock_id']==local_monotonic_clock_id()
    api=p.load_nvml_binding(Path(os.environ['FAASLORA_TC_NVML_BINDING']),os.environ['FAASLORA_TC_NVML_SHA256'])
    ledger=NativeWorkerLedger(root=RAW/'physical',context=context,census=p.NativeGPUCensus(api),
        service_path=group,process_identity=p.gpu_process_identity)
    platform.lifecycle_observer=ledger
    registry={r['adapter_id']:r for r in json.loads((RAW/'lora_registry.json').read_text())}
    http=NativeHTTPAdapter(public_model=http_cfg['model'],native_model='llama2_7b/0',registry=registry,
        views=views,platform=platform,clock_id=context['clock_id'],journal=RAW/'http_service.jsonl')
    terminal_rows=[]

    async def listen(address,port,worker,health=False):''')
body=replace_one(body,'    async def work():\n        try:',
    '    async def work():\n        try:\n            await http.start(8453)')
body=replace_one(body,'generation=await module.qualify(platform,RAW,views)',
    'generation,terminal_rows[:]=await module.qualify(platform,RAW,views,http,context)')
body=replace_one(body,'        finally:\n            await platform.close()', '''        finally:
            await platform.close()
            physical=ledger.finalize(arrival_end_s=context['replay_t0_s']+max(e.offset_s for e in plan.entries),
                last_terminal_s=max((r['client_completed_s'] for r in terminal_rows),default=None)
                    if len(terminal_rows)==len(plan.entries) else None,
                n_plan=len(plan.entries),n_terminal=len(terminal_rows))
            result['physical_measurement_complete']=physical['measurement_complete']
            result['physical_native_contexts_qualified']=physical['native_contexts_qualified']''')
body=body.replace('two request-driven real-remote existing LoRAs through native Scheduler; not numerical/full workload/performance',
    '100 existing requests via common HTTP open-loop, native Scheduler and real-remote; not numerical/full4000/performance')
body=replace_one(body,'asyncio.wait_for(work(),1720)',
    'asyncio.wait_for(work(),max(e.offset_s for e in plan.entries)+1800+120)')
put('native_body.py',body)
template=(OLD/'executed_prepare.py').read_text().replace('d502','d503')
template=replace_one(template,'render_controller_sources(NATIVE)',
    'render_controller_sources(NATIVE,control_observations=True)')
template=replace_one(template,"paths=[BASE/'scripts/prepare_ieee_tc_serverless_stack.py',",
    "paths=[RAW/'http_7b_100.json',MAIN/'faaslora/storage/http_artifact_store.py',MAIN/'faaslora/clock.py',MAIN/'faaslora/datasets/workload_generator.py',MAIN/'faaslora/metrics/metrics_collector.py',BASE/'scripts/prepare_ieee_tc_serverless_stack.py',")
# The older generator defines BASE only; MAIN is explicitly bound for snapshots.
template=replace_one(template,"BASE=Path('/home/qhq/serverless_llm_baselines')",
    "BASE=Path('/home/qhq/serverless_llm_baselines')\nMAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')")
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
