"""Reuse D502 fresh resource/content checks, no prefetch."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d502_20261013/prelaunch.py').read_text()
source=source.replace('predicted_growth=p.GIB','predicted_growth=4*p.GIB')
exec(compile(source,str(RAW/'prelaunch_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'prelaunch_reused.py')})
