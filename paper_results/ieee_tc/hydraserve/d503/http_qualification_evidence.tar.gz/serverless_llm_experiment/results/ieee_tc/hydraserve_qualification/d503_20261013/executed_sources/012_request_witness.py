"""Existing common 100-prefix via actual original HydraServe scheduler."""
import asyncio
from hashlib import sha256
import json
from pathlib import Path
import sys
import time
from HydraServe_project.runtime.controller_runtime import native_controller


async def qualify(platform,raw,views,http,context):
    raw=Path(raw)
    def save(name,value):
        with (raw/name).open('x') as f:json.dump(value,f,indent=2)
    result=dict(passed=False,performance_result=False,qualification_only=True,
        native_http_open_loop=True,numerical_lora_qualified=False)
    offset=0
    rows=[]
    terminal=None
    manifest_sha=sha256((raw/'overlays/manifest.json').read_bytes()).hexdigest()
    with native_controller(raw/'overlays',manifest_sha) as native:
        info=tuple(json.loads((raw/'model_registration.json').read_text())['model_info'])
        scheduler=native.Scheduler(None,None,{'test':{'llama2_7b':info}},platform=platform)
        assert scheduler.alg is sys.modules['algs'].ours
        assert scheduler.resource_manager.rgpus==[[24]*4]
        assert not scheduler.models[0].instances and not platform.workers
        http.set_scheduler(scheduler)
        try:
            # Original common publisher remains in auxiliary resource domain.
            # Follow its append-only terminal log; do not drive request arrival.
            with Path(context['result_path']).open() as f:
                while terminal is None:
                    while True:
                        position=f.tell();line=f.readline()
                        if not line.endswith('\n'):
                            f.seek(position);break
                        row=json.loads(line)
                        if row['event'] in ('http_response','http_request_failed','http_request_cancelled'):
                            rows.append(row)
                            print(json.dumps(dict(terminal_count=len(rows),event=row['event'],request_id=row['request_id'])),flush=True)
                        if row['event'] in ('http_replay_complete','http_replay_incomplete'):
                            terminal=row
                    if terminal is None:
                        if http.idle and http.idle.done():await http.idle
                        await asyncio.sleep(.2)
            save('external_terminal_summary.json',dict(terminal=terminal,observed_terminals=len(rows)))
            result.update(counts=terminal,observed_terminals=len(rows),
                native_response_count=sum(r['event']=='http_response' for r in rows))
            # Allow the unmodified 30-second idle retirement; no manual early
            # deletion to lower resource cost after requests finish.
            while any(not w.removed for w in platform.workers.values()):
                if http.idle is None:break
                if http.idle.done():await http.idle
                await asyncio.sleep(.1)
            while scheduler.resource_manager.rgpus != [[24]*4]:await asyncio.sleep(.1)
            result.update(passed=terminal['event']=='http_replay_complete'
                and terminal['N_failed']==0 and terminal['N_response']==100,
                actual_native_idle_release=all(w.removed for w in platform.workers.values()))
            save('native_scheduler_after_requests.json',dict(algorithm=scheduler.alg.__name__,
                original_idle_grace_s=30,resource_gpus=scheduler.resource_manager.rgpus,
                instances=[dict(id=i.id,pp_size=i.pp_size,inited=i.inited,num_reqs=i.num_reqs,
                    will_scale_down=i.will_scale_down) for i in scheduler.models[0].instances],
                native_stats=vars(scheduler.models[0].model_stats)))
        finally:
            await http.close()
            tasks=list(scheduler.tasks)
            for task in tasks:task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)
            for instance in scheduler.models[0].instances:
                if instance.inited:
                    instance.chat_engine.client.close()
                    await instance.chat_engine.client_async.close()
            conn=sys.modules['utils'].conn
            if conn is not None:await conn.close()
            save('generation_result.json',result)
    return result,rows
