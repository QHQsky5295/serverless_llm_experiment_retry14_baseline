"""D507: D506 full-W0 contract, removing only the erroneous container TTL.

D506 remains a sealed launcher-error attempt. No native performance tuning,
new workload, request deadline change, or repeat of elementary qualification.
"""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tarfile

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d506_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
from faaslora.datasets.workload_generator import FrozenReplayPlan

def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def put(name,value):
    with (RAW/name).open('x') as f:f.write(value)
def save(name,value):put(name,json.dumps(value,indent=2))

save('prepare_identity.json',p.scope_identity(p.cg_path().name))
assert json.loads((RAW/'d506_container_cleanup.json').read_text())['passed']
for mode in ('baseline','main'):
    assert json.loads((OLD/f'failure_backup_{mode}_receipt.json').read_text())['passed']
assert digest(OLD/'preregistration.json')=='033911e0ae567ae8c3dd02dc0bf0be65739465ae0acd10113fa3899c06654b24'
changed=[]
for path,record in json.loads((OLD/'source_manifest.json').read_text()).items():
    assert digest(record['snapshot'])==record['sha256'],path
    if digest(path)!=record['sha256']:changed.append(path)
assert changed==[str(BASE/'HydraServe_project/runtime/isolated_platform.py')],changed
assert json.loads((OLD/'container_lifetime_failure.json').read_text())['classification']=='protocol_or_launcher_error'
cfg=json.loads((OLD/'http_7b_4000.json').read_text())
assert cfg['request_count']==4000 and cfg['request_view']=='trace_prefix_v1'
for name in ('http_7b_4000.json','remote_input_config.json','model_registration.json',
             'input_qualification.json','request_witness.py','online_sources.json',
             'official_main.py','official_scheduler.py','official_engine.py','official_ModelInfo.py'):
    put(name,(OLD/name).read_text())
for name in ('close_pause.py','close_audit.py','collect_remote.py','start_remote.sh',
             'run_and_close.sh','prelaunch.py','launch.sh'):
    put(name,(OLD/name).read_text().replace('d506','d507'))
body=(OLD/'native_body.py').read_text().replace('d506','d507')
body=replace_one(body,'swap_bytes=2*p.GIB,timeout_s=1800','swap_bytes=2*p.GIB')
put('native_body.py',body)
pool=json.loads(Path(cfg['pool_index']).read_text())['artifacts']
assert len(pool)==500 and digest(cfg['pool_index'])==cfg['pool_index_sha256']
save('lora_registry.json',[dict(adapter_id=aid,adapter_index=i,
    adapter_path=str(RAW/'adapter_views'/aid)) for i,aid in
    enumerate(sorted(item['id'] for item in pool),1)])
identity=FrozenReplayPlan.load(cfg['trace'],count=4000).identity()
prereg=json.loads((OLD/'preregistration.json').read_text())
assert identity==prereg['plan_identity']
for value in prereg['references'].values():assert digest(value['path'])==value['sha256']
prereg.update(campaign='d507_20261013',
    invalid_predecessor=dict(path=str(OLD),classification='protocol_or_launcher_error',
        evidence_sha256=digest(OLD/'container_lifetime_failure.json')),
    container_lifetime_owner='native controller; bounded campaign and external watchdog on abnormal exit',
    per_container_wall_clock_expiry=False,
    adaptation_change='remove erroneous Podman whole-container 1800s TTL; request/init/CLI guards unchanged',
    no_native_policy_change=True,
    source_heads={label:subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
                  for label,root in [('baseline',BASE),('main',MAIN)]})
save('preregistration.json',prereg)
template=(OLD/'executed_prepare.py').read_text().replace('d506','d507')
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
audit=(OLD/'audit.py').read_text().replace(
    '033911e0ae567ae8c3dd02dc0bf0be65739465ae0acd10113fa3899c06654b24',digest(RAW/'preregistration.json'))
put('audit.py',audit)
compile(audit,str(RAW/'audit.py'),'exec')

# Small append-only supplement preserves native logs omitted from the sealed
# D506 archive, plus the exact correction/launch sources. No old file overwritten.
curated=BASE/'paper_results/ieee_tc/hydraserve/d507'
curated.mkdir(exist_ok=False)
with (curated/'preregistration.json').open('xb') as f:f.write((RAW/'preregistration.json').read_bytes())
paths=sorted(x for x in (RAW/'d506_stopped_containers').iterdir() if x.is_file())
paths += [RAW/name for name in ('capture_d506.py','capture_identity.json','d506_container_cleanup.json',
    'cpu_closure_12.json','prepare.py','prepare_identity.json','native_body.py','launch.sh',
    'run_and_close.sh','prelaunch.py','audit.py','source_manifest.json','preregistration.json')]
paths += sorted((RAW/'executed_sources').iterdir())
records={str(path):dict(sha256=digest(path),bytes=path.stat().st_size) for path in paths}
archive=curated/'lifecycle_correction_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in paths:bundle.add(path,arcname=str(path.relative_to('/home/qhq')),recursive=False)
for _ in range(2):
    with tarfile.open(archive,'r:gz') as bundle:
        assert len(bundle.getmembers())==len(paths)
        for member in bundle.getmembers():
            assert sha256(bundle.extractfile(member).read()).hexdigest()==records['/home/qhq/'+member.name]['sha256']
summary=dict(checkpoint_verified=True,performance_result=False,prepared_not_launched=True,
    predecessor_classification='protocol_or_launcher_error',source_manifest=records,
    archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,
    no_native_policy_or_request_guard_change=True,source_changed=changed,
    tests='source regression separately rerun at backup',k3s_accessed=False)
with (curated/'summary.json').open('x') as f:json.dump(summary,f,indent=2)
save('prepare_result.json',dict(passed=True,preregistration_sha256=digest(RAW/'preregistration.json'),
    archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,files=len(paths)))
print(json.dumps(json.loads((RAW/'prepare_result.json').read_text())))
