"""Reuse D507's exact native log/State capture and pause closure, without deleting containers."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW/'capture_d506.py'
source=original.read_text()
source=source.replace("OLD = RAW.parent / 'd506_20261013'", 'OLD = RAW')
source=source.replace("'capture_identity.json'", "'capture_terminal_identity.json'")
start=source.index("failure = json.loads((OLD/'container_lifetime_failure.json').read_text())")
end=source.index("runtime = Path(",start)
source=source[:start]+'''closure=json.loads((RAW/'closure.json').read_text())
assert closure['actual_recursive_empty'] and not Path(closure['service']['path']).exists()
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
'''+source[end:]
source=source.replace("RAW/'d506_stopped_containers'", "RAW/'terminal_native_containers'")
source=source.replace("== 'd506'", "== 'd507'")
source=source.replace("    assert value['State'] == row['state']\n", '')
start=source.index('pause = None\ntry:')
end=source.index('finally:\n    pausefile',start)
source=source[:start]+'''pause = None
try:
    missing=[]
    releases=[json.loads(line) for line in (RAW/'physical/container_allocations.jsonl').read_text().splitlines() if json.loads(line)['event']=='release']
    released_names={row['container_name'] for row in releases}
    for path in sorted((RAW/'platform').glob('*.ownership.json')):
        owner=json.loads(path.read_text())
        row=dict(container_id=owner['container_id'],name=path.name.removesuffix('.ownership.json'))
        exists=subprocess.run(base+['container','exists',row['container_id']],env=env,capture_output=True,timeout=30).returncode
        if exists==1:
            assert row['name'] in released_names
            missing.append(dict(**row,reason='original native retirement already removed container; release event preserved'))
            continue
        assert exists==0
        state=inspect(row)
        save(out/(row['name']+'.state.json'),dict(name=row['name'],id=state['Id'],state=state['State'],
             labels=state['Config']['Labels'],mounts=state['Mounts'],host_config=state['HostConfig']))
        paths=[out/(row['name']+'.stdout'),out/(row['name']+'.stderr')]
        with paths[0].open('xb') as stdout,paths[1].open('xb') as stderr:
            subprocess.run(base+['logs',row['container_id']],env=env,stdout=stdout,stderr=stderr,timeout=30,check=True)
        records=[dict(path=str(pth),sha256=sha256(pth.read_bytes()).hexdigest(),bytes=pth.stat().st_size) for pth in paths]
        captured.append(dict(name=row['name'],container_id=row['container_id'],state=state['State'],logs=records))
    assert len(captured)==5 and len(missing)==1
    save(out/'captured.json',dict(captured=captured,missing=missing))
'''+source[end:]
source=source.replace("RAW/'d506_container_cleanup.json'", "RAW/'terminal_capture_receipt.json'")
exec(compile(source,str(RAW/'capture_terminal_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'capture_terminal.py')})
