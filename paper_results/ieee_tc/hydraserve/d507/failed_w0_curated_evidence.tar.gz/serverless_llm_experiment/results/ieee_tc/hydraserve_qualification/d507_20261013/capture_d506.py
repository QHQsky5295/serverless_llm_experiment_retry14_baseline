"""Preserve native logs, then remove only the six verified stopped D506 containers.

No GPU launch or cluster access. Any fresh store-specific Podman pause is closed
only after PID/birth/UID/store ownership and its empty scope are verified.
"""
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys

RAW = Path(__file__).resolve().parent
OLD = RAW.parent / 'd506_20261013'
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2)

scope = p.scope_identity(p.cg_path().name)
save(RAW / 'capture_identity.json', scope)
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert (Path(scope['path']) / 'memory.max').read_text().strip() == str(4*p.GIB)
assert (Path(scope['path']) / 'memory.swap.max').read_text().strip() == '0'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
                                    '--format=csv,noheader'], text=True).strip()
failure = json.loads((OLD/'container_lifetime_failure.json').read_text())
assert not Path(failure['service_identity']['path']).exists()
assert json.loads((OLD/'failure_backup_baseline_receipt.json').read_text())['passed']
assert json.loads((OLD/'failure_backup_main_receipt.json').read_text())['passed']
runtime = Path('/run/user/1001/primelora-hydra-d477-proxy')
store = RAW.parent/'d477_20261012/container_proxy_attempt/container_storage'
base = ['podman','--root',str(store),'--runroot',str(runtime/'runroot'),
        '--storage-driver=vfs','--cgroup-manager=cgroupfs','--events-backend=file',
        '--runtime=/usr/bin/nvidia-container-runtime','--hooks-dir',str(OLD/'empty_hooks')]
env = {k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','LANG') if k in os.environ}
env.update(CONTAINERS_CONF=str(OLD/'containers.conf'),XDG_RUNTIME_DIR=str(runtime),
           REGISTRY_AUTH_FILE=str(OLD/'pull-auth.json'))
out = RAW/'d506_stopped_containers'
out.mkdir(exist_ok=False)
captured, removed = [], []

def inspect(row):
    value = json.loads(subprocess.check_output(base+['inspect',row['container_id']],
                       env=env, text=True, timeout=30))[0]
    assert value['Id'] == row['container_id']
    assert value['Config']['Labels']['org.primelora.campaign'] == 'd506'
    assert value['Name'].lstrip('/') == row['name']
    assert value['State'] == row['state']
    assert not value['State']['Running'] and value['State']['Pid'] == 0
    owner = json.loads((OLD/'platform'/(row['name']+'.ownership.json')).read_text())
    assert owner['container_id'] == value['Id']
    assert p.gpu_process_identity(owner['owner']['pid']) != owner['owner']
    assert not Path(owner['owner']['cgroup']).exists()
    return value

pause = None
try:
    for row in failure['container_states']:
        state = inspect(row)
        save(out/(row['name']+'.state.json'), dict(name=row['name'],id=state['Id'],
             state=state['State'],labels=state['Config']['Labels'],
             mounts=state['Mounts'],host_config=state['HostConfig']))
        paths = [out/(row['name']+'.stdout'),out/(row['name']+'.stderr')]
        with paths[0].open('xb') as stdout, paths[1].open('xb') as stderr:
            subprocess.run(base+['logs',row['container_id']],env=env,
                           stdout=stdout,stderr=stderr,timeout=30,check=True)
        records = []
        for path in paths:
            first = sha256(path.read_bytes()).hexdigest()
            assert sha256(path.read_bytes()).hexdigest() == first
            records.append(dict(path=str(path),sha256=first,bytes=path.stat().st_size))
        captured.append(dict(name=row['name'],container_id=row['container_id'],logs=records))
    assert len(captured) == 6
    save(out/'captured.json',captured)
    # Capture every log before deleting even one exact-owned stopped container.
    for row in reversed(failure['container_states']):
        inspect(row)
        result = subprocess.run(base+['rm',row['container_id']],env=env,
                                capture_output=True,text=True,timeout=30,check=True)
        code = subprocess.run(base+['container','exists',row['container_id']],env=env,
                              capture_output=True,timeout=30).returncode
        assert code == 1
        removed.append(dict(name=row['name'],container_id=row['container_id'],
                            stdout=result.stdout,stderr=result.stderr,absent=True))
    save(out/'removed.json',removed)
finally:
    pausefile = runtime/'libpod/tmp/pause.pid'
    if pausefile.exists():
        assert pausefile.stat().st_uid == os.getuid()
        pid = int(pausefile.read_text())
        owner = p.gpu_process_identity(pid)
        if owner is not None:
            assert owner['uid'] == os.getuid()
            assert Path(f'/proc/{pid}/comm').read_text().strip() == 'podman pause'
            group = Path(owner['cgroup'])
            assert re.fullmatch(r'podman-pause-[0-9]+\.scope',group.name)
            unit = dict(line.split('=',1) for line in subprocess.check_output([
                'systemctl','--user','show',group.name,'-p','InvocationID','-p','ControlGroup'],
                text=True).splitlines())
            assert group == Path('/sys/fs/cgroup'+unit['ControlGroup'])
            assert [r['pid'] for r in p.owned_pids(group)] == [pid]
            boot = next(int(s.split()[1]) for s in Path('/proc/stat').read_text().splitlines()
                        if s.startswith('btime '))
            assert abs(boot+owner['start_ticks']/os.sysconf('SC_CLK_TCK')-pausefile.stat().st_mtime) < 5
            fd = os.pidfd_open(pid)
            try:
                assert p.gpu_process_identity(pid) == owner
                signal.pidfd_send_signal(fd,signal.SIGKILL)
            finally:
                os.close(fd)
            subprocess.run(['systemctl','--user','stop',group.name],check=True,timeout=10)
            assert not group.exists()
            pause = dict(owner=owner,unit=unit,closed=True)
    save(out/'pause_closure.json',pause)
save(RAW/'d506_container_cleanup.json',dict(passed=True,captured=captured,removed=removed,
    native_logs_preserved=True,unique_assets_removed=False,pause=pause,scope=scope))
print(json.dumps(dict(passed=True,containers_removed=len(removed),logs_preserved=len(captured))))
