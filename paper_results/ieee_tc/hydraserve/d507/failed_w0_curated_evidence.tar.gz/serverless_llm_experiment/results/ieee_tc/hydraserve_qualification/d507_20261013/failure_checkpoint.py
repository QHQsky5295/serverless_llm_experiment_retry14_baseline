"""Reuse D503 append-only curation, preserving failed full4000 and censoring."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d503_20261013/checkpoint.py').read_text()
anchor="exec(compile(source,str(RAW/'checkpoint_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'checkpoint.py')})"
assert source.count(anchor)==1
scope={'__name__':'__main__','__file__':str(RAW/'failure_checkpoint.py')}
exec(compile(source.replace(anchor,''),str(RAW.parent/'d503_20261013/checkpoint.py'),'exec'),scope)
source=scope['source']
start=source.index("assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']")
end=source.index('protected=p.verify_seal',start)
source=source[:start]+'''audit=json.loads((RAW/'failure_aware_evaluation.json').read_text())
assert audit['audit_pass'] and audit['n_plan']==audit['n_terminal']==4000
assert audit['n_v1_contract_complete']==3876 and audit['n_failed']==124
assert audit['n_joint']==6 and audit['performance_ranking_eligible'] is False
assert audit['physical_gpu_seconds'] is None and not audit['physical_measurement_complete']
assert audit['closure']['actual_recursive_empty'] and audit['closure']['service_gone']
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
assert json.loads((RAW/'terminal_capture_v2_receipt.json').read_text())['passed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
    assert p.digest(Path(record['snapshot']))==record['sha256']
    assert p.digest(Path(path))==record['sha256']
for path,digest in audit['source_sha256'].items():assert p.digest(Path(path))==digest
assert 'Ran 90 tests' in (RAW/'backup_baseline_smoke.log').read_text()
assert '\\nOK\\n' in (RAW/'backup_baseline_smoke.log').read_text()
'''+source[end:]
source=source.replace('D503_HYDRASERVE_COMMON_HTTP.md','D507_HYDRASERVE_FAILED_W0_AUDIT.md')
source=source.replace("hydraserve/d503';dest.mkdir()", "hydraserve/d507';dest.mkdir(exist_ok=True)")
source=source.replace('http_qualification_evidence.tar.gz','failed_w0_evidence.tar.gz')
source=source.replace("x.name not in ('pull-auth.json','curation.log')", "x.name not in ('pull-auth.json','failure_curation.log')")
source=source.replace('paths=sorted(set(paths))', "paths += [x for x in (RAW/'terminal_native_containers_v2').rglob('*') if x.is_file() and not x.is_symlink()]\npaths += [RAW/'terminal_native_containers/pause_closure.json']\npaths=sorted(set(paths))")
start=source.index('summary=dict(')
end=source.index("save(dest/'summary.json'",start)
source=source[:start]+'''summary=dict(checkpoint_verified=True,performance_result=False,cpu_tests_passed=90,
    outcome='full_offered_request_failure_with_cancellation_adaptation_defect_and_censored_release',
    audit=audit,raw_n_correct=None,full_success_audit_executed=False,
    no_precise_resource_ranking=True,actual_release_and_remote_stop=True,
    protected_verification=protected,source_manifest=manifest,archive_sha256=p.digest(archive),
    next='Necessary cancellation ownership review and pre-timeout bottleneck attribution, then faithful HydraServe full result and all baseline comparison before PrimeLoRA optimization')
'''+source[end:]
source=source.replace("save(dest/'summary.json'", "save(dest/'failed_w0_summary.json'")
source=source.replace("p.digest(dest/'summary.json')", "p.digest(dest/'failed_w0_summary.json')")
source=source.replace('cpu_tests=88','cpu_tests=90')
exec(compile(source,str(RAW/'failure_checkpoint_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'failure_checkpoint.py')})
