"""D507 post-terminal audit: failed requests remain in all offered denominators.

Reuses the qualified HTTP validator and replay plan, not the success-only audit.
Missing native release records remain censored. No baseline config is changed.
"""
from collections import Counter
from hashlib import sha256
import importlib.util
import json
import math
from pathlib import Path
import sys
import traceback

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path.append(str(BASE))
from HydraServe_project.runtime.http_contract import validate_observation

def save(name, value):
    with (RAW/name).open('x') as f:
        json.dump(value, f, indent=2)

def read(name):
    return json.loads((RAW/name).read_text())

def journal(name):
    with (RAW/name).open() as f:
        for line in f:
            yield json.loads(line)

def stats(values):
    values = sorted(values)
    if not values:
        return dict(n=0, mean=None, p50=None, p95=None, p99=None, max=None)
    assert all(math.isfinite(x) for x in values)
    return dict(n=len(values), mean=sum(values)/len(values),
                **{k: values[math.ceil(q*len(values))-1] for k, q in
                   [('p50', .5), ('p95', .95), ('p99', .99), ('max', 1.)]})

def event_map(events, name):
    selected = [e for e in events if e['event'] == name]
    mapping = {e['request_id']: e for e in selected}
    assert len(mapping) == len(selected), ('duplicate', name)
    return mapping

def main():
    own = p.scope_identity(p.cg_path().name)
    assert (Path(own['path'])/'memory.max').read_text().strip() == str(4*p.GIB)
    assert (Path(own['path'])/'memory.swap.max').read_text().strip() == '0'
    save('failure_audit_identity_v2.json', own)
    closure, stop, prereg = read('closure.json'), read('remote_stop.json'), read('preregistration.json')
    assert closure['actual_recursive_empty'] and closure['service_gone']
    assert stop['all_owned_units_inactive'] and stop['download_hashes_match_remote']
    assert p.digest(RAW/'preregistration.json') == 'ab9c8692f31d824dd8ee89be6fae0d4e7db6241cea6d15e086653ec7f85f637e'
    for ref in prereg['references'].values():
        assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
    for path, record in read('source_manifest.json').items():
        assert p.digest(Path(path)) == record['sha256'], path
        assert p.digest(Path(record['snapshot'])) == record['sha256']
    assert read('prelaunch_gate.json')['preflight_pass']
    assert set(read('remote_health.json')) == {'3b', '7b'}
    spec = importlib.util.spec_from_file_location('shared_stack_audit', BASE/'scripts/prepare_ieee_tc_serverless_stack.py')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    plan = helper.load_http_replay_plan(read('http_7b_4000.json'))
    assert plan.identity() == prereg['plan_identity']
    events = list(journal('launch_gate.launch/replay.jsonl'))
    ready = events[0]
    assert ready['plan'] == plan.identity()
    expected = {e.request_id for e in plan.entries}
    contracts = event_map(events, 'request_contract')
    created = event_map(events, 'request_created')
    submitted = event_map(events, 'http_headers_sent')
    raws = event_map(events, 'http_raw_response')
    outputs = event_map(events, 'http_response')
    failed = event_map(events, 'http_request_failed')
    assert len(expected) == 4000 and set(contracts) == set(created) == set(submitted) == expected
    assert len(outputs) == len(raws) == 3876 and set(outputs) == set(raws)
    assert len(failed) == 124 and not (set(failed) & set(outputs))
    assert set(failed) | set(outputs) == expected
    assert events[-1] == dict(event='http_replay_complete', N_plan=4000, N_arrived=4000,
                             N_terminal=4000, N_response=3876, N_failed=124)
    assert not any(e['event'] == 'http_request_cancelled' for e in events)
    origin = read('launch_gate.launch/exec_receipt.json')['external_replay']
    registry = {r['adapter_id']: r for r in read('lora_registry.json')}
    transfers = list(journal('remote_transfers.jsonl'))
    by_transfer = {t['transfer_id']: t for t in transfers}
    assert len(by_transfer) == len(transfers)
    for transfer in transfers:
        assert transfer['outcome'] == 'sent'
        assert transfer['pack_performed'] is False and transfer['temporary_created'] is False
    allocations = list(journal('physical/container_allocations.jsonl'))
    maps = {name: {e['lease_id']: e for e in allocations if e['event'] == name}
            for name in ('acquire', 'worker_spawn', 'release', 'native_context')}
    for name, mapping in maps.items():
        assert len(mapping) == sum(e['event'] == name for e in allocations)
    starts, spawns, ends, contexts = (maps[n] for n in ('acquire', 'worker_spawn', 'release', 'native_context'))
    assert len(starts) == 4 and set(starts) == set(spawns) == set(contexts)
    assert len(ends) == 1 and set(ends) < set(starts)
    workers = {e['worker_name']: lid for lid, e in starts.items()}
    assert len(workers) == len(starts) and len({e['gpu_uuid'] for e in starts.values()}) == 4
    last_seen = {}
    for event in journal('launch_gate.launch/watchdog.jsonl'):
        if event['event'] != 'resource_sample':
            continue
        census = event['gpu']
        assert not census['foreign_compute_processes'] and not census['escaped_owned_processes']
        assert not census['unresolved_processes']
        for device in census['devices']:
            for process in device['processes']:
                for lid, spawn in spawns.items():
                    if (process['pid'] == spawn['owner']['pid'] and
                            process['identity'] == spawn['owner']):
                        assert device['gpu_uuid'] == starts[lid]['gpu_uuid']
                        last_seen[lid] = census['query_start_s']
    assert set(last_seen) == set(starts)
    recovery_empty_s = closure['recovery_records'][0]['observed_empty_s']
    intervals = []
    for lid, start in starts.items():
        assert start['clock_id'] == ready['clock_id']
        assert spawns[lid]['at'] >= start['at']
        assert contexts[lid]['at'] >= spawns[lid]['at']
        if lid in ends:
            end = ends[lid]
            assert end['native_context_qualified'] and end['clock_id'] == ready['clock_id']
            lower = upper = end['at']
        else:
            lower, upper = last_seen[lid], recovery_empty_s
        assert start['at'] <= lower <= upper
        intervals.append(dict(lease_id=lid, gpu_uuid=start['gpu_uuid'], worker=start['worker_name'],
                              acquired_s=start['at'], release_lower_s=lower, release_upper_s=upper,
                              release_exact=lid in ends))
    evaluation = json.loads(Path(prereg['references']['slo_eval']['path']).read_text())
    rows, failures, matched_contracts = [], [], []
    seen_transfers = set()
    terminal_times = []
    for entry in plan.entries:
        rid = entry.request_id
        c = contracts[rid]
        assert c['source_item_sha256'] == entry.source_sha256
        observed = outputs.get(rid, failed.get(rid))
        assert abs(observed['planned_arrival_s'] - origin['replay_t0_s'] - entry.offset_s) < 1e-8
        assert observed['source_item_sha256'] == entry.source_sha256
        terminal_times.append(observed['client_completed_s'])
        matched_contracts.append(dict(c, arrival_offset_s=entry.offset_s))
        if rid in failed:
            assert observed['error'] == 'TimeoutError: '
            duration = observed['client_completed_s'] - observed['planned_arrival_s']
            assert duration >= 1800 and duration < 1801
            failures.append(dict(request_id=rid, duration_s=duration,
                                 planned_arrival_s=observed['planned_arrival_s'],
                                 client_completed_s=observed['client_completed_s'],
                                 client_submit_lag_ms=1000*(observed['client_submit_s']-observed['planned_arrival_s']),
                                 error=observed['error'], joint_pass=False))
            continue
        raw, out = raws[rid], outputs[rid]
        n = raw['body']['metrics']['ieee_tc']
        assert raw['status'] == 200
        prepared = dict(c, input_token_ids=n['native_prompt_token_ids'])
        recomputed = validate_observation(prepared, raw['body'], out, raw['client_completed_s'],
                                         ready['clock_id'], ingress_required=True)
        assert recomputed == out['response']
        assert n['native_adapter_index'] == registry[c['adapter_id']]['adapter_index']
        assert n['native_adapter_path'] == registry[c['adapter_id']]['adapter_path']
        proof = n['worker_proof']
        lid = workers[proof['worker_name']]
        assert proof['container_id'] == spawns[lid]['container_id']
        assert proof['host_process'] == spawns[lid]['owner']
        assert starts[lid]['at'] <= n['native_first_token_monotonic_s'] <= n['native_last_token_monotonic_s'] <= proof['verified_at_s']
        assert proof['verified_at_s'] <= (ends[lid]['at'] if lid in ends else last_seen[lid])
        artifact = n['artifact_observation']
        assert p.digest(RAW/'remote_artifacts/receipts'/(c['adapter_id']+'.json')) == artifact['tc_artifact_receipt_sha256']
        if not artifact['tc_artifact_cache_hit']:
            transfer = by_transfer[artifact['tc_artifact_transfer_id']]
            assert transfer['artifact_id'] == c['adapter_id']
            assert transfer['bytes_written'] == artifact['tc_artifact_transferred_bytes']
            assert transfer['transfer_id'] not in seen_transfers
            seen_transfers.add(transfer['transfer_id'])
        length = len(n['native_prompt_token_ids'])
        groups = [g for g in evaluation['groups'] if
                  (g['lower_exclusive'] is None or length > g['lower_exclusive']) and
                  (g['upper_inclusive'] is None or length <= g['upper_inclusive'])]
        assert len(groups) == 1
        ttft_ok = recomputed['ttft_ms'] <= groups[0]['ttft_ms']
        tpot_ok = c['target_tokens'] == 1 or recomputed['tpot_ms'] <= groups[0]['tpot_ms']
        rows.append(dict(request_id=rid, adapter_id=c['adapter_id'], target_tokens=c['target_tokens'],
                         output_tokens=len(n['completion_token_ids']), prompt_tokens=length,
                         ttft_pass=ttft_ok, tpot_pass=tpot_ok, joint_pass=ttft_ok and tpot_ok, **recomputed))
    service_events = list(journal('http_service.jsonl'))
    service_failures = event_map(service_events, 'failed')
    cancelled = event_map(service_events, 'cancelled')
    assert set(service_failures) | set(cancelled) == set(failed)
    assert not set(service_failures) & set(cancelled)
    assert len(service_failures) == 105 and len(cancelled) == 19
    assert all(e['error'] == 'ValueError: generator already executing' for e in service_failures.values())
    # A first-touch fetch can belong to a request which later times out. Bind
    # those bytes to its retained server-side artifact evidence, not a response
    # fabricated for that failed request.
    failure_owned_transfers = []
    for rid, event in service_failures.items():
        a = event['artifact']
        c = contracts[rid]
        assert a['tc_artifact_request_id'] == rid and a['tc_artifact_id'] == c['adapter_id']
        assert a['tc_artifact_content_sha256'] == c['artifact_content_sha256']
        assert p.digest(RAW/'remote_artifacts/receipts'/(c['adapter_id']+'.json')) == a['tc_artifact_receipt_sha256']
        if not a['tc_artifact_cache_hit']:
            transfer = by_transfer[a['tc_artifact_transfer_id']]
            assert transfer['artifact_id'] == c['adapter_id']
            assert transfer['bytes_written'] == a['tc_artifact_transferred_bytes']
            assert transfer['transfer_id'] not in seen_transfers
            seen_transfers.add(transfer['transfer_id'])
            failure_owned_transfers.append(dict(request_id=rid, transfer_id=transfer['transfer_id']))
    assert seen_transfers == set(by_transfer), 'unattributed transfer remains'
    cancellation_offsets = [e['at']-failed[rid]['client_completed_s'] for rid, e in service_failures.items()]
    assert min(cancellation_offsets) >= 0, 'server failure preceded client timeout'
    first_timeout = min(f['client_completed_s'] for f in failures)
    before = [r for r in rows if outputs[r['request_id']]['client_completed_s'] < first_timeout]
    boundaries = (origin['replay_t0_s'], origin['replay_t0_s']+max(e.offset_s for e in plan.entries),
                  max(terminal_times))
    assert boundaries[2] >= boundaries[1]
    def partition(which):
        windows = dict(pre=0., arrival=0., drain=0., cleanup=0.)
        for interval in intervals:
            left, right = interval['acquired_s'], interval[which]
            for name, lo, hi in zip(windows, (-math.inf, *boundaries), (*boundaries, math.inf)):
                windows[name] += max(0., min(right, hi)-max(left, lo))
        return windows
    low_windows, high_windows = partition('release_lower_s'), partition('release_upper_s')
    good = sum(r['joint_pass'] for r in rows)
    multi = [r for r in rows if r['output_tokens'] >= 2]
    observation = boundaries[2]-boundaries[0]
    result = dict(schema='d507_failed_full_w0_observation_v1', audit_pass=True,
                  full_success_audit_run=False, formal_run=False, independent_holdout=False,
                  n_plan=4000, n_arrived=4000, n_submitted=4000, n_terminal=4000,
                  n_response=3876, n_v1_contract_complete=3876, n_failed=124,
                  raw_n_correct_preserved=None, independent_numerical_qualification=False,
                  n_joint=good, joint_slo=good/4000, observed_w0_g1_feasible=False,
                  performance_ranking_eligible=False, physical_measurement_complete=False,
                  ttft_attainment=sum(r['ttft_pass'] for r in rows)/4000,
                  tpot_conditional_attainment=sum(r['tpot_pass'] for r in multi)/len(multi),
                  tpot_conditional_denominator=len(multi),
                  physical_gpu_seconds=None, gpu_seconds_per_v1_contract_request=None,
                  observed_physical_gpu_seconds_lower_bound=sum(low_windows.values()),
                  recovered_physical_gpu_seconds_upper_bound=sum(high_windows.values()),
                  physical_windows_lower_bound=low_windows, physical_windows_upper_bound=high_windows,
                  physical_intervals=intervals, native_output_tokens=sum(r['output_tokens'] for r in rows),
                  observation_s=observation, completed_requests_per_s=3876/observation,
                  good_requests_per_s=good/observation,
                  remote_transfers=len(transfers), remote_wire_bytes=sum(t['bytes_written'] for t in transfers),
                  response_metrics={k:stats([r[k] for r in rows if r[k] is not None]) for k in
                      ('ttft_ms','tpot_ms','e2e_ms','submit_lag_ms','dispatch_wait_after_submit_ms',
                       'service_ttft_ms','decode_ms','completion_notification_ms','artifact_resolve_ms')},
                  failure_duration_s=stats([f['duration_s'] for f in failures]),
                  failure_submit_lag_ms=stats([f['client_submit_lag_ms'] for f in failures]),
                  cancellation_overlap_errors=105, cancellation_events=19,
                  failure_owned_transfers=failure_owned_transfers,
                  server_error_after_client_timeout_s=stats(cancellation_offsets),
                  pre_first_timeout_responses=len(before),
                  pre_first_timeout_metrics={k:stats([r[k] for r in before]) for k in
                                             ('ttft_ms','dispatch_wait_after_submit_ms','service_ttft_ms')},
                  closure=closure, references=prereg['references'],
                  caveats=['Conditional latency only among 3876 contract-complete responses.',
                           'Three native physical releases are missing; intervals are bounds, not exact U.',
                           '105 concurrent generator-close errors followed request timeouts; later service and retirement may be affected.',
                           'Do not attribute the complete failed run solely to native HydraServe policy.',
                           'Qualification/development identity, one physical node, no independent numerical or multirank mechanism proof.'])
    result['source_sha256'] = {str(path): p.digest(path) for path in (
        Path(__file__), RAW/'launch_gate.launch/replay.jsonl', RAW/'http_service.jsonl',
        RAW/'launch_gate.launch/watchdog.jsonl', RAW/'physical/container_allocations.jsonl',
        RAW/'remote_transfers.jsonl', RAW/'closure.json', RAW/'remote_stop.json')}
    save('failure_request_metrics.json', rows)
    save('failure_requests.json', failures)
    save('failure_matched_contracts.json', matched_contracts)
    save('failure_aware_evaluation.json', result)
    print(json.dumps({k:v for k,v in result.items() if k not in
                      ('source_sha256','closure','references','response_metrics','physical_intervals','pre_first_timeout_metrics')}))

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        save('failure_aware_audit_error_v2.json', dict(type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc()))
        raise
