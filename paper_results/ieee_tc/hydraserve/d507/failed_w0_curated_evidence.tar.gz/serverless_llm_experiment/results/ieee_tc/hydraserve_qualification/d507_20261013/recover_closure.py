"""Post-terminal recovery only; never rewrite the failed launch or backdate release."""
import json
from pathlib import Path
import subprocess
import sys
import time

RAW = Path(__file__).resolve().parent
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

own = p.scope_identity(p.cg_path().name)
assert (Path(own['path']) / 'memory.max').read_text().strip() == str(4*p.GIB)
assert (Path(own['path']) / 'memory.swap.max').read_text().strip() == '0'
assert not (RAW/'closure.json').exists()
launch = json.loads((RAW/'launch_gate.json').read_text())
assert launch['external_replay_outcome']['N_terminal'] == 4000
assert launch['external_replay_outcome']['N_failed'] == 124
assert launch['cleanup']['released'] is False
service = launch['service_identity']
aux = p.scope_identity('primelora-tc-aux-d5070000000000000000000000000009.scope')
assert aux['invocation_id'] == '0b984cf4de2844b7b93388ceac2387d4'
assert aux['path'] == launch['auxiliary']['path']
gpu_clear_at = time.monotonic()
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
                                   '--format=csv,noheader'], text=True).strip()
records = []
for identity in (service, aux):
    assert p.scope_still_owned(identity)
    group = Path(identity['path'])
    members = {str(f): f.read_text().split() for f in
               (group/'cgroup.procs', *group.rglob('cgroup.procs'))}
    assert not any(members.values()), members
    records.append(dict(identity=identity, members=members,
                        observed_empty_s=time.monotonic(),
                        stats={k:(group/k).read_text() for k in
                               ('memory.peak', 'memory.events', 'memory.swap.current', 'cgroup.events')}))
with (RAW/'closure_recovery_intent.json').open('x') as f:
    json.dump(dict(own_identity=own, original_launch_sha256=p.digest(RAW/'launch_gate.json'),
                   gpu_clear_observed_s=gpu_clear_at, exact_empty_scopes=records), f, indent=2)
for record in records:
    identity = record['identity']
    group = Path(identity['path'])
    assert p.scope_still_owned(identity)
    assert not any(f.read_text().split() for f in
                   (group/'cgroup.procs', *group.rglob('cgroup.procs')))
    subprocess.run(['systemctl', '--user', 'stop', identity['unit']], check=True, timeout=10)
    assert not group.exists()
    record['stop_confirmed_s'] = time.monotonic()
peak = 0
events = {}
swap = 0
samples = 0
terminal = []
last_sample_s = None
with (RAW/'launch_gate.launch/watchdog.jsonl').open() as f:
    for line in f:
        row = json.loads(line)
        if row['event'] == 'gpu_terminal_census':
            terminal.append(row)
        if row['event'] != 'resource_sample':
            continue
        samples += 1
        last_sample_s = row['monotonic']
        peak = max(peak, row['service']['memory.peak'])
        swap = max(swap, row['service']['memory.swap.current'])
        for k, v in row['service']['memory.events'].items():
            events[k] = max(events.get(k, 0), v)
result = dict(kind='d507_post_terminal_empty_scope_recovery_v1', service=service,
              service_gone=True, auxiliary=aux, actual_recursive_empty=True,
              recovery_records=records, gpu_clear_observed_s=gpu_clear_at,
              peak_bytes=peak, event_max=events, swap_max=swap, sample_count=samples,
              last_original_sample_s=last_sample_s, gpu_terminal_census=terminal,
              original_cleanup_released=False, original_failed_result_preserved=True,
              original_terminal_gpu_census_missing=not bool(terminal),
              caveat='Fresh release proof is not a retroactive exact release timestamp; '
                     'original launch and missing physical closure remain failed/incomplete.')
with (RAW/'closure.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
