"""Reuse D480 explicit protection, smoke, secrets, stage and remote-backup gates."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d507').replace('D480','D507')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['HydraServe_project/runtime/isolated_platform.py',
        'tests/test_ieee_tc_hydraserve_isolated_platform.py',
        'docs/ieee_tc/D507_HYDRASERVE_LIFECYCLE_CORRECTION.md',
        'paper_results/ieee_tc/hydraserve/d507/preregistration.json',
        'paper_results/ieee_tc/hydraserve/d507/summary.json',
        'paper_results/ieee_tc/hydraserve/d507/lifecycle_correction_evidence.tar.gz']
    remote, branch = 'origin', 'main'
    smoke = ['tests.test_ieee_tc_hydraserve_'+name for name in
        ('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
         'tokenizer_compat','request_contract','native_delivery','isolated_platform',
         'platform_port','stage_binding','worker_binding','layer_identity')]
'''+source[end:]
source=source.replace('path.stat().st_size < 2*1024*1024','path.stat().st_size < 16*1024*1024')
source=source.replace('qualify HydraServe native platform injection seam on CPU',
    'correct isolated HydraServe container lifetime without native policy changes')
exec(compile(source,str(template),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'backup.py')})
