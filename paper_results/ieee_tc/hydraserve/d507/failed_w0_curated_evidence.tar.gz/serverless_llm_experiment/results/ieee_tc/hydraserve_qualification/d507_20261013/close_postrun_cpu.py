"""Close a saved exact-owned postrun CPU scope only after recursive emptiness."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
for filename in sys.argv[1:]:
    assert Path(filename).name==filename and filename.endswith('_identity.json') or filename=='failure_audit_identity_v2.json'
    saved=json.loads((RAW/filename).read_text())
    assert saved['unit'].startswith('primelora-tc-aux-d507')
    assert p.scope_still_owned(saved)
    group=Path(saved['path'])
    assert not any(f.read_text().split() for f in (group/'cgroup.procs',*group.rglob('cgroup.procs')))
    stats={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
    subprocess.run(['systemctl','--user','stop',saved['unit']],check=True,timeout=10)
    assert not group.exists()
    result=dict(identity=saved,actual_recursive_empty=True,stats=stats)
    with (RAW/(filename.removesuffix('.json')+'_closure.json')).open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result))
