"""Retain stale Podman State honestly; actual PID/birth/cgroup closure is authoritative.

Read native logs only, no container removal or state normalization. The original
capture failed because conmon was killed before refreshing Podman's State.
"""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'capture_terminal.py').read_text()
source=source[:source.index('exec(compile(source,')]
scope={'__file__':str(RAW/'capture_terminal_v2.py')}
exec(compile(source,str(RAW/'capture_terminal.py'),'exec'),scope)
source=scope['source']
source=source.replace("'capture_terminal_identity.json'", "'capture_terminal_v2_identity.json'")
source=source.replace("RAW/'terminal_native_containers'", "RAW/'terminal_native_containers_v2'")
source=source.replace("    assert not value['State']['Running'] and value['State']['Pid'] == 0\n", '')
source=source.replace("RAW/'terminal_capture_receipt.json'", "RAW/'terminal_capture_v2_receipt.json'")
exec(compile(source,str(RAW/'capture_terminal_v2_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'capture_terminal_v2.py')})
