"""Close only the captured D487 pause after controller interpreter lacks pidfd."""
import json
import os
from pathlib import Path
import signal
import sys
import time
RAW = Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
identity = json.loads((RAW/'probe_identity.json').read_text())
owner = json.loads((RAW/'pause_adoption.json').read_text())['after']
assert p.scope_still_owned(identity)
assert p.gpu_process_identity(owner['pid']) == owner
members = p.owned_pids(Path(identity['path']))
assert [row['pid'] for row in members] == [owner['pid']]
fd = os.pidfd_open(owner['pid'])
try:
    assert p.gpu_process_identity(owner['pid']) == owner
    signal.pidfd_send_signal(fd,signal.SIGKILL)
finally:
    os.close(fd)
for _ in range(50):
    if not p.owned_pids(Path(identity['path'])):
        break
    time.sleep(.1)
assert not p.owned_pids(Path(identity['path']))
with (RAW/'retained_pause_closed.json').open('x') as handle:
    json.dump(dict(passed=True,owner=owner,scope=identity,actual_recursive_empty=True),handle,indent=2)
print('D487 exact retained pause closed; recursive members empty')
