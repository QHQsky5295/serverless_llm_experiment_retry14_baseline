"""Continue D487 LoRA arithmetic with complete-file, not header, identities.

Original CUDA/Punica/SiLU/FlashAttention passed and are not repeated. Preserve
D487 failed source/results. Use explicit system Python for host pidfd cleanup.
"""
import hashlib
import json
import os
from pathlib import Path
import signal

HERE = Path(__file__).resolve().parent
OLD = HERE.parent/'d487_20261013'
assert hasattr(os,'pidfd_open') and hasattr(signal,'pidfd_send_signal')
assert json.loads((OLD/'probe_closure.json').read_text())['actual_recursive_empty']
prior = json.loads((OLD/'output/native_gpu_result.json').read_text())
assert prior['native_reference_test_passed'] and prior['silu_and_flash_attention_passed']
driver = (OLD/'probe.py').read_bytes()
worker = (OLD/'native_gpu_witness.py').read_bytes()
assert hashlib.sha256(driver).hexdigest() == '49139ceb6a6794c102807994ae39e6eb3fb59ffb8b4ed0a54406052a8a4d1c59'
assert hashlib.sha256(worker).hexdigest() == '0e452651d9de0994fea11a6e96a58c7c4e14cbf45f2347dd1b30f3357b58ca17'
text = worker.decode()
begin = text.index('    # Execute original reference/test bodies')
end = text.index("    adapters = ['finance_lora'",begin)
text = text[:begin]+"    result['prior_native_kernel_result'] = 'D487: original Punica/SiLU/FlashAttention passed; not repeated'\n"+text[end:]
text = text.replace("assert sha == 'b2ea218143e5e77daf58417d661880dac772bd6db4376fd23d8538b8cb7ec7e3'", "assert sha == {'finance_lora':'971901c3140f83f57cbb19fcc86d33b4d010f6d8fc15fbec621f0347bc31a258', 'medical_lora':'d2b1dcfe42193917d0b2e0f728e735f24ad119dd2c77cb9b20c983c7f688fa5c'}[adapter]")
compile(text,'corrected_native_gpu_witness','exec')
with (HERE/'native_gpu_witness.py').open('x') as handle:
    handle.write(text)
source = driver.decode().replace('d487','d488').replace('D487','D488')
exec(compile(source,str(OLD/'probe.py'),'exec'),{'__name__':'__main__','__file__':str(HERE/'probe.py')})
