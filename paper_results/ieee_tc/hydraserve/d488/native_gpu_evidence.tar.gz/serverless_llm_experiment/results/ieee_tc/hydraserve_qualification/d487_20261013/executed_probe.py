"""Reuse D477/D478 bounded containers for a no-model IPC/HTTP witness.

Own loopback listener, private shared IPC, no CNI or host network changes. This
does NOT qualify HydraServe, pipeline source-IP identity, CUDA or LoRA arithmetic.
"""
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
OLD = RAW.parent/'d477_20261012'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW/name).open('x') as handle:
        json.dump(value, handle, indent=2)

identity = p.scope_identity(p.cg_path().name)
save('probe_identity.json', identity)
group = Path(identity['path'])
assert os.sched_getaffinity(0) == {2,3,26,27}
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
gate = p.preflight([RAW], predicted_growth=512*p.MIB)
save('preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert json.loads((OLD/'container_affinity_attempt/container_context_closure.json').read_text())['passed']
runtime = Path('/run/user/1001/primelora-hydra-d477-proxy')
store = OLD/'container_proxy_attempt/container_storage'
assert runtime.is_dir() and runtime.stat().st_uid == os.getuid()
assert store.is_dir() and store.stat().st_uid == os.getuid()
(RAW/'empty_hooks').mkdir()
supervisor = group/'supervisor'
supervisor.mkdir()
(supervisor/'cgroup.procs').write_text(str(os.getpid()))
(group/'cgroup.subtree_control').write_text('+memory +pids')
env = {k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','LANG') if k in os.environ}
env.update(CONTAINERS_CONF=str(RAW/'containers.conf'), XDG_RUNTIME_DIR=str(runtime),
           REGISTRY_AUTH_FILE=str(RAW/'pull-auth.json'), CUDA_VISIBLE_DEVICES='')
base = ['podman','--root',str(store),'--runroot',str(runtime/'runroot'),
        '--storage-driver=vfs','--cgroup-manager=cgroupfs','--events-backend=file',
        '--runtime=/usr/bin/nvidia-container-runtime','--hooks-dir',str(RAW/'empty_hooks')]
commands, created, owners = [], [], {}
pause_owner, sentinel = None, None
result = dict(passed=False, kind='isolated_shared_ipc_loopback_http_no_model',
              native_backend_qualified=False, performance_result=False,
              pipeline_peer_identity_qualified=False, gpu_started=False)

def call(tag, args, check=True, timeout=30):
    started = time.monotonic()
    with (RAW/(tag+'.stdout')).open('x') as out, (RAW/(tag+'.stderr')).open('x') as err:
        run = subprocess.run(base+args, env=env, stdout=out, stderr=err, timeout=timeout)
    commands.append(dict(tag=tag, args=args, returncode=run.returncode,
                         elapsed_s=time.monotonic()-started))
    print(json.dumps(dict(tag=tag, returncode=run.returncode)), flush=True)
    if check:
        assert run.returncode == 0, tag
    return (RAW/(tag+'.stdout')).read_text(), run.returncode

def inspect(name, tag):
    raw, _ = call(tag, ['inspect', name])
    state = json.loads(raw)[0]
    assert state['Config']['Labels']['org.primelora.campaign'] == 'd487'
    return state

def qualify_owner(name, tag):
    state = inspect(name, tag)
    assert state['State']['Running']
    pid = state['State']['Pid']
    owner = p.gpu_process_identity(pid)
    assert owner and owner['uid'] == os.getuid()
    child = Path(owner['cgroup'])
    assert group in child.parents
    assert owner['affinity'] == [2,3,26,27]
    limits = {k:(child/k).read_text().strip() for k in ('memory.max','memory.swap.max','pids.max')}
    assert limits == {'memory.max':str(2*p.GIB),'memory.swap.max':'0','pids.max':'512'}
    namespaces = {k:os.readlink(f'/proc/{pid}/ns/{k}') for k in ('ipc','net')}
    owners[name] = owner
    save(tag+'_ownership.json', dict(identity=owner, limits=limits, namespaces=namespaces))
    return state, namespaces

try:
    info = json.loads(call('info', ['info','--format=json'])[0])
    assert info['store']['graphRoot'] == str(store)
    pausefile = runtime/'libpod/tmp/pause.pid'
    assert pausefile.stat().st_uid == os.getuid()
    pid = int(pausefile.read_text())
    before = p.gpu_process_identity(pid)
    assert before and before['uid'] == os.getuid()
    assert Path(f'/proc/{pid}/comm').read_text().strip() == 'podman pause'
    oldgroup = Path(before['cgroup'])
    assert re.fullmatch(r'podman-pause-[0-9]+\.scope', oldgroup.name)
    oldunit = dict(line.split('=',1) for line in subprocess.check_output([
        'systemctl','--user','show',oldgroup.name,'-p','InvocationID','-p','ControlGroup'],text=True).splitlines())
    assert Path('/sys/fs/cgroup'+oldunit['ControlGroup']) == oldgroup
    assert [row['pid'] for row in p.owned_pids(oldgroup)] == [pid]
    boot = next(int(line.split()[1]) for line in Path('/proc/stat').read_text().splitlines() if line.startswith('btime '))
    assert abs(boot+before['start_ticks']/os.sysconf('SC_CLK_TCK')-pausefile.stat().st_mtime) < 5
    assert p.gpu_process_identity(pid) == before
    (supervisor/'cgroup.procs').write_text(str(pid))
    os.sched_setaffinity(pid, {2,3,26,27})
    pause_owner = p.gpu_process_identity(pid)
    assert pause_owner['start_ticks'] == before['start_ticks']
    assert Path(pause_owner['cgroup']) == supervisor
    assert not (oldgroup/'cgroup.procs').read_text().split()
    assert subprocess.check_output(['systemctl','--user','show',oldgroup.name,'-p','InvocationID','--value'],text=True).strip() == oldunit['InvocationID']
    subprocess.run(['systemctl','--user','stop',oldgroup.name],check=True)
    save('pause_adoption.json',dict(before=before, after=pause_owner, original=oldunit,
                                  before_container_start=True))
    assert not call('prior_containers',['ps','-aq'])[0].strip()
    image = json.loads(call('image',['image','inspect','docker.io/library/ubuntu:22.04'])[0])[0]
    assert image['Id'] == json.loads((OLD/'container_proxy_attempt/image_identity.json').read_text())['Id']
    save('image_identity.json',{k:image.get(k) for k in ('Id','Digest','Size','Architecture','Os')})

    ENV = Path('/home/qhq/serverless_llm_baselines/installs/hydraserve_native_d484_20261013')
    PYBASE = Path('/home/qhq/anaconda3/envs/hydraserve_py_20260520')
    CUDA = Path('/home/qhq/anaconda3/envs/slinfer_official_20260612')
    NATIVE = Path('/home/qhq/serverless_llm_baselines/vendor_new_baselines/HydraServe_main_20260520')
    D486 = RAW.parent/'d486_20261013'
    assert json.loads((D486/'native_import_closure.json').read_text())['passed']
    assert json.loads((D486/'native_import_result.json').read_text())['passed']
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    uuid = subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=uuid','--format=csv,noheader'],text=True).strip()
    assert uuid.startswith('GPU-')
    save('selected_gpu.json',dict(uuid=uuid))
    output = RAW/'output'
    output.mkdir()
    nv = CUDA/'lib/python3.11/site-packages/nvidia'
    libraries = [ENV/'lib/python3.10/site-packages/torch/lib', PYBASE/'lib',
                 *[d/'lib' for d in sorted(nv.iterdir()) if (d/'lib').is_dir()],CUDA/'lib']
    worker_env = dict(LD_LIBRARY_PATH=':'.join(map(str,libraries)),
        PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',OMP_NUM_THREADS='2',
        HOME='/tmp',CUDA_CACHE_PATH='/tmp/cuda-cache',VLLM_NO_USAGE_STATS='1',
        VLLM_NCCL_SO_PATH=str(D486/'private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1'))
    common = ['--pull=never','--cgroups=enabled',
        '--cgroup-parent='+str(group).removeprefix('/sys/fs/cgroup'),
        '--memory=2g','--memory-swap=2g','--pids-limit=512','--network=none',
        '--http-proxy=false','--read-only','--cap-drop=ALL',
        '--security-opt=no-new-privileges','--security-opt=label=disable',
        '--label=org.primelora.campaign=d487','--timeout=300',
        '--tmpfs=/tmp:rw,size=128m','--ipc=private','--shm-size=64m',
        '--env=NVIDIA_VISIBLE_DEVICES=nvidia.com/gpu='+uuid,
        '--volume='+str(RAW)+':/probe:ro','--volume='+str(output)+':/out:rw']
    readonly = [ENV,PYBASE,CUDA,NATIVE,D486/'private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1']
    pool = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
    readonly += [pool/'finance_lora',pool/'medical_lora']
    common += ['--volume='+str(path)+':'+str(path)+':ro' for path in readonly]
    common += ['--env='+k+'='+v for k,v in worker_env.items()]
    name = 'primelora-hydra-d487-native-gpu'
    created.append(name)
    cid = call('run_worker',['run','--detach','--name='+name,*common,image['Id'],
        '/usr/bin/taskset','-c','2,3,26,27',str(ENV/'bin/python'),'-B','/probe/native_gpu_witness.py'])[0].strip()
    state, namespaces = qualify_owner(name,'inspect_worker')
    assert namespaces['ipc'] != os.readlink('/proc/self/ns/ipc')
    assert namespaces['net'] != os.readlink('/proc/self/ns/net')
    save('output/permit_cuda.json',dict(passed=True,actual_owner=owners[name],container_id=cid))
    start = time.monotonic()
    with (RAW/'guard.jsonl').open('x') as monitor:
        while True:
            sample = dict(time_monotonic=time.monotonic(),host=p.host_sample(),resources=p.cgroup_snapshot(group),
                disk_free=shutil.disk_usage(RAW).free)
            monitor.write(json.dumps(sample)+'\n');monitor.flush()
            assert sample['host']['available_bytes'] >= 16*p.GIB
            assert sample['disk_free'] >= 100*p.GIB
            assert time.monotonic()-start <= 300, 'finite GPU qualification guard'
            text,_ = call('state_'+str(int(time.monotonic()-start)),['inspect',cid])
            state = json.loads(text)[0]
            if not state['State']['Running']:
                break
            time.sleep(1)
    call('worker_logs',['logs',cid])
    save('worker_final_state.json',dict(container_id=cid,state=state['State']))
    assert state['State']['ExitCode'] == 0, state['State']['ExitCode']
    witness = json.loads((output/'native_gpu_result.json').read_text())
    assert witness['passed'] and witness['modules_compared']==128
    result.update(passed=True,kind='native CUDA and existing nonzero LoRA arithmetic',
        gpu_started=True,gpu_uuid=uuid,container_id=cid,arithmetic=witness,
        native_backend_qualified=False,performance_result=False,actual_worker_contained=True)
except Exception as exc:
    result.update(error_type=type(exc).__name__, error=str(exc))
finally:
    cleanup = []
    for index,name in enumerate(reversed(created)):
        text, code = call('cleanup_inspect_'+str(index),['inspect',name],check=False)
        if code:
            cleanup.append(dict(name=name, exists=False, inspect_returncode=code))
            continue
        state = json.loads(text)[0]
        assert state['Config']['Labels']['org.primelora.campaign'] == 'd487'
        if state['State']['Running']:
            call('stop_'+str(index),['stop','--time=2',name])
        call('remove_'+str(index),['rm',name])
        owner = owners.get(name)
        if owner:
            current = p.gpu_process_identity(owner['pid'])
            assert current is None or current['start_ticks'] != owner['start_ticks']
        cleanup.append(dict(name=name, removed=True))
    if sentinel is not None:
        assert sentinel.stat().st_uid == os.getuid()
        assert sentinel.stat().st_ino == sentinel_inode and sentinel.read_bytes() == payload
        sentinel.unlink()
    if pause_owner is not None:
        current = p.gpu_process_identity(pause_owner['pid'])
        if current is not None:
            assert current == pause_owner
            fd = os.pidfd_open(current['pid'])
            try:
                assert p.gpu_process_identity(current['pid']) == current
                signal.pidfd_send_signal(fd,signal.SIGKILL)
            finally:
                os.close(fd)
    result.update(cleanup=cleanup, disk_free_after=shutil.disk_usage(RAW).free)
    result['gpu_apps_after'] = subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True).strip()
    result['gpu_released'] = not result['gpu_apps_after']
    result['passed'] = result['passed'] and result['gpu_released']
    save('commands.json',commands)
    save('result.json',result)
    print(json.dumps(result),flush=True)
sys.exit(0 if result['passed'] else 1)
