"""Reuse D481 actual lifecycle/cleanup for D487 native GPU arithmetic only.

Reuse existing image, readonly environment and weights. No K8s, network,
installation, model/provider, performance tuning, or new workload generation.
"""
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
template = HERE.parent/'d481_20261013/probe.py'
raw = template.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '96488e0a139e9c39a1b5c14e51a69778b342e5b35a3a725850b625c3e2458f62'
source = raw.decode().replace("'d481'", "'d487'")
source = source.replace("{2,26}","{2,3,26,27}").replace('[2,26]','[2,3,26,27]')
source = source.replace('str(512*p.MIB)','str(4*p.GIB)')
source = source.replace('str(128*p.MIB)','str(2*p.GIB)').replace("'pids.max':'128'","'pids.max':'512'")
source = source.replace('--runtime=/usr/bin/runc','--runtime=/usr/bin/nvidia-container-runtime')
prefix = source[:source.index('try:\n    # Verify address availability')]
adopt = source[source.index("    info = json.loads(call('info'"):source.index("    payload = b'primelora-d481-")]
cleanup = source[source.index('except Exception as exc:\n'):]
body = '''
    ENV = Path('/home/qhq/serverless_llm_baselines/installs/hydraserve_native_d484_20261013')
    PYBASE = Path('/home/qhq/anaconda3/envs/hydraserve_py_20260520')
    CUDA = Path('/home/qhq/anaconda3/envs/slinfer_official_20260612')
    NATIVE = Path('/home/qhq/serverless_llm_baselines/vendor_new_baselines/HydraServe_main_20260520')
    D486 = RAW.parent/'d486_20261013'
    assert json.loads((D486/'native_import_closure.json').read_text())['passed']
    assert json.loads((D486/'native_import_result.json').read_text())['passed']
    assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
    uuid = subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=uuid','--format=csv,noheader'],text=True).strip()
    assert uuid.startswith('GPU-')
    save('selected_gpu.json',dict(uuid=uuid))
    output = RAW/'output'
    output.mkdir()
    nv = CUDA/'lib/python3.11/site-packages/nvidia'
    libraries = [ENV/'lib/python3.10/site-packages/torch/lib', PYBASE/'lib',
                 *[d/'lib' for d in sorted(nv.iterdir()) if (d/'lib').is_dir()],CUDA/'lib']
    worker_env = dict(LD_LIBRARY_PATH=':'.join(map(str,libraries)),
        PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',OMP_NUM_THREADS='2',
        HOME='/tmp',CUDA_CACHE_PATH='/tmp/cuda-cache',VLLM_NO_USAGE_STATS='1',
        VLLM_NCCL_SO_PATH=str(D486/'private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1'))
    common = ['--pull=never','--cgroups=enabled',
        '--cgroup-parent='+str(group).removeprefix('/sys/fs/cgroup'),
        '--memory=2g','--memory-swap=2g','--pids-limit=512','--network=none',
        '--http-proxy=false','--read-only','--cap-drop=ALL',
        '--security-opt=no-new-privileges','--security-opt=label=disable',
        '--label=org.primelora.campaign=d487','--timeout=300',
        '--tmpfs=/tmp:rw,size=128m','--ipc=private','--shm-size=64m',
        '--env=NVIDIA_VISIBLE_DEVICES=nvidia.com/gpu='+uuid,
        '--volume='+str(RAW)+':/probe:ro','--volume='+str(output)+':/out:rw']
    readonly = [ENV,PYBASE,CUDA,NATIVE,D486/'private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1']
    pool = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
    readonly += [pool/'finance_lora',pool/'medical_lora']
    common += ['--volume='+str(path)+':'+str(path)+':ro' for path in readonly]
    common += ['--env='+k+'='+v for k,v in worker_env.items()]
    name = 'primelora-hydra-d487-native-gpu'
    created.append(name)
    cid = call('run_worker',['run','--detach','--name='+name,*common,image['Id'],
        '/usr/bin/taskset','-c','2,3,26,27',str(ENV/'bin/python'),'-B','/probe/native_gpu_witness.py'])[0].strip()
    state, namespaces = qualify_owner(name,'inspect_worker')
    assert namespaces['ipc'] != os.readlink('/proc/self/ns/ipc')
    assert namespaces['net'] != os.readlink('/proc/self/ns/net')
    save('output/permit_cuda.json',dict(passed=True,actual_owner=owners[name],container_id=cid))
    start = time.monotonic()
    with (RAW/'guard.jsonl').open('x') as monitor:
        while True:
            sample = dict(time_monotonic=time.monotonic(),host=p.host_sample(),resources=p.cgroup_snapshot(group),
                disk_free=shutil.disk_usage(RAW).free)
            monitor.write(json.dumps(sample)+'\\n');monitor.flush()
            assert sample['host']['available_bytes'] >= 16*p.GIB
            assert sample['disk_free'] >= 100*p.GIB
            assert time.monotonic()-start <= 300, 'finite GPU qualification guard'
            text,_ = call('state_'+str(int(time.monotonic()-start)),['inspect',cid])
            state = json.loads(text)[0]
            if not state['State']['Running']:
                break
            time.sleep(1)
    call('worker_logs',['logs',cid])
    save('worker_final_state.json',dict(container_id=cid,state=state['State']))
    assert state['State']['ExitCode'] == 0, state['State']['ExitCode']
    witness = json.loads((output/'native_gpu_result.json').read_text())
    assert witness['passed'] and witness['modules_compared']==128
    result.update(passed=True,kind='native CUDA and existing nonzero LoRA arithmetic',
        gpu_started=True,gpu_uuid=uuid,container_id=cid,arithmetic=witness,
        native_backend_qualified=False,performance_result=False,actual_worker_contained=True)
'''
source = prefix+'try:\n'+adopt+body+cleanup
source = source.replace("    save('commands.json',commands)", "    result['gpu_apps_after'] = subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],text=True).strip()\n    result['gpu_released'] = not result['gpu_apps_after']\n    result['passed'] = result['passed'] and result['gpu_released']\n    save('commands.json',commands)")
with (HERE/'executed_probe.py').open('x') as handle:
    handle.write(source)
exec(compile(source,str(HERE/'executed_probe.py'),'exec'),{'__name__':'__main__','__file__':str(HERE/'executed_probe.py')})
