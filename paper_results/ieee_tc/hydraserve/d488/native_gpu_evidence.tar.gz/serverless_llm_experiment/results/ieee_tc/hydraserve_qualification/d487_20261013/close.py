"""Exact recursive-empty closure, reuse qualified D481 procedure."""
from pathlib import Path
HERE = Path(__file__).resolve().parent
source = (HERE.parent/'d481_20261013/close.py').read_text()
exec(compile(source,'d481_close_reused','exec'),{'__name__':'__main__','__file__':str(HERE/'close.py')})
