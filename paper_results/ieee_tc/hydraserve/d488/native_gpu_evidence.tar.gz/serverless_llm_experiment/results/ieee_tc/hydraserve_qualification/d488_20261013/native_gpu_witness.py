"""Actual native CUDA arithmetic using existing nonzero LoRA; NOT a model replay.

Reads immutable weights only. CPU float32 algebra is independent of the GPU
extension. Original FP16 tolerance plus relative update-norm check are fixed
before execution; an all-zero update cannot qualify.
"""
import ast
import hashlib
import json
import os
from pathlib import Path
import time

OUT = Path('/out')
SOURCE = Path('/home/qhq/serverless_llm_baselines/vendor_new_baselines/HydraServe_main_20260520')
POOL = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')

def save(name, data):
    with (OUT/name).open('x') as handle:
        json.dump(data, handle, indent=2)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

save('worker_before_cuda.json', dict(pid=os.getpid(), affinity=sorted(os.sched_getaffinity(0)),
    cgroup=Path('/proc/self/cgroup').read_text(), time_monotonic=time.monotonic()))
deadline = time.monotonic()+60
while not (OUT/'permit_cuda.json').exists():
    if time.monotonic() > deadline:
        raise TimeoutError('actual worker containment not acknowledged')
    time.sleep(.1)
assert json.loads((OUT/'permit_cuda.json').read_text())['passed'] is True
assert os.sched_getaffinity(0) == {2,3,26,27}

result = dict(passed=False, performance_result=False, full_model_qualified=False,
              stage_binding_qualified=False, pipeline_consolidation_qualified=False,
              rows=[], native_reference_test_passed=False)
try:
    import torch
    import vllm
    from safetensors import safe_open
    from vllm.lora import punica
    from vllm import _custom_ops
    from flash_attn import flash_attn_func
    assert torch.__version__ == '2.3.0+cu121' and vllm.__version__ == '0.4.2'
    assert torch.cuda.device_count() == 1 and torch.cuda.get_device_capability(0) == (8,6)
    torch.set_num_threads(2)
    torch.manual_seed(0xabcdabcd987)
    assert digest(Path(punica.__file__)) == '8e86aa8e9cadcc92abf00e5cf6f583fa85affaee516ba11b9496887a6d693263'
    result['prior_native_kernel_result'] = 'D487: original Punica/SiLU/FlashAttention passed; not repeated'
    adapters = ['finance_lora','medical_lora']
    readers, configs, identities = [], [], []
    for adapter in adapters:
        cfg_path = POOL/adapter/'adapter_config.json'
        weights = POOL/adapter/'adapter_model.safetensors'
        cfg = json.loads(cfg_path.read_text())
        assert cfg['r'] == 8 and cfg['lora_alpha'] == 16
        sha = digest(weights)
        assert sha == {'finance_lora':'971901c3140f83f57cbb19fcc86d33b4d010f6d8fc15fbec621f0347bc31a258', 'medical_lora':'d2b1dcfe42193917d0b2e0f728e735f24ad119dd2c77cb9b20c983c7f688fa5c'}[adapter]
        configs.append(cfg)
        readers.append(safe_open(str(weights),framework='pt',device='cpu'))
        identities.append(dict(adapter=adapter,weight_sha256=sha,config_sha256=digest(cfg_path)))
    keys = sorted(k for k in readers[0].keys() if '.lora_A.' in k)
    assert len(keys) == 128 and all(set(r.keys()) == set(readers[0].keys()) for r in readers)
    indices = torch.tensor([-1,0,1,0,1,0,1,0],dtype=torch.long)
    native_indices = indices.cuda()
    for index,key in enumerate(keys):
        a = torch.stack([r.get_tensor(key).half() for r in readers])
        b = torch.stack([r.get_tensor(key.replace('.lora_A.','.lora_B.')).half() for r in readers])
        assert a.shape == (2,8,4096) and b.shape == (2,4096,8)
        inputs = torch.randn(8,4096,dtype=torch.float16)
        reference = torch.zeros(8,4096,dtype=torch.float32)
        for slot in (0,1):
            mask = indices == slot
            reference[mask] = (inputs[mask].float()@a[slot].float().T@b[slot].float().T)*(configs[slot]['lora_alpha']/configs[slot]['r'])
        assert torch.isfinite(reference).all() and float(torch.linalg.vector_norm(reference)) > 0
        output = torch.zeros(8,4096,dtype=torch.float16,device='cuda')
        punica.add_lora(output,inputs.cuda(),a[:,None].cuda(),b[:,None].cuda(),native_indices,0,2.0)
        torch.cuda.synchronize()
        actual_cpu = output.cpu()
        torch.testing.assert_close(actual_cpu,reference.half(),rtol=5e-3,atol=5e-3)
        assert torch.count_nonzero(actual_cpu[0]).item() == 0
        error = actual_cpu.float()-reference
        relative = float(torch.linalg.vector_norm(error)/torch.linalg.vector_norm(reference))
        assert relative <= 5e-3, (key,relative)
        assert torch.count_nonzero(actual_cpu[1:]).item() > 0
        result['rows'].append(dict(module=key.split('.lora_A.')[0],
            max_absolute_error=float(error.abs().max()),relative_l2_error=relative,
            update_l2=float(torch.linalg.vector_norm(reference)),
            native_nonzero=int(torch.count_nonzero(actual_cpu)),no_adapter_row_zero=True))
        if (index+1)%16 == 0:
            print('NONZERO_MODULES_PASSED',index+1,flush=True)
    torch.cuda.synchronize()
    result.update(passed=True,modules_compared=len(result['rows']),logical_adapters=identities,
        unique_weight_sha_count=len({r['weight_sha256'] for r in identities}),
        torch_version=torch.__version__,vllm_version=vllm.__version__,
        gpu_name=torch.cuda.get_device_name(),device_count=torch.cuda.device_count(),
        gpu_peak_allocated_bytes=torch.cuda.max_memory_allocated(),
        gpu_peak_reserved_bytes=torch.cuda.max_memory_reserved(),
        fixed_tolerance=dict(rtol=5e-3,atol=5e-3,relative_update_l2_max=5e-3),
        reference='CPU float32 x @ A.T @ B.T * alpha/r; original FP16 tolerance')
except Exception as exc:
    result.update(error_type=type(exc).__name__,error=str(exc))
    raise
finally:
    save('native_gpu_result.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
