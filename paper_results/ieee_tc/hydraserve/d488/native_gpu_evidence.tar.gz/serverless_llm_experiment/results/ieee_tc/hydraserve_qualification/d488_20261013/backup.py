"""Reuse verified exact-path staging, source/secrets/protected/remote-equality."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
template = RAW.parent/'d480_20261013/backup.py'
source = template.read_text().replace('d480','d488').replace('D480','D488')
start = source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end = source.index('else:\n    paths =',start)
source = source[:start]+'''    paths = ['docs/ieee_tc/D488_HYDRASERVE_NATIVE_GPU_ARITHMETIC.md',
        'paper_results/ieee_tc/hydraserve/d488/summary.json',
        'paper_results/ieee_tc/hydraserve/d488/native_gpu_evidence.tar.gz']
    remote, branch = 'origin','main'
    smoke = []
'''+source[end:]
source = source.replace('qualify HydraServe native platform injection seam on CPU','verify native GPU arithmetic with existing nonzero LoRA')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup_reused.py')})
