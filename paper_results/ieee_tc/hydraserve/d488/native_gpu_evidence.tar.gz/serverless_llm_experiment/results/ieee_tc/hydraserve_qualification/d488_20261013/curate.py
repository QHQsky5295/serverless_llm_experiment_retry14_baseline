"""Reuse explicit evidence tar/roundtrip/protected protocol; no raw binary assets."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile
RAW = Path(__file__).resolve().parent
OLD = RAW.parent/'d487_20261013'
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path,data):
    with path.open('x') as handle:
        json.dump(data,handle,indent=2)

save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
for path in (OLD/'probe_closure.json',RAW/'probe_closure.json'):
    assert json.loads(path.read_text())['actual_recursive_empty']
first = json.loads((OLD/'output/native_gpu_result.json').read_text())
result = json.loads((RAW/'result.json').read_text())
assert first['native_reference_test_passed'] and first['silu_and_flash_attention_passed'] and not first['passed']
assert result['passed'] and result['gpu_released'] and not result['performance_result']
witness = result['arithmetic']
assert witness == json.loads((RAW/'output/native_gpu_result.json').read_text())
expected = {f'base_model.model.model.layers.{i}.self_attn.{m}_proj' for i in range(32) for m in ('q','k','v','o')}
assert len(witness['rows'])==128 and {r['module'] for r in witness['rows']} == expected
assert all(r['relative_l2_error']<=.005 and r['native_nonzero']>0 and r['no_adapter_row_zero'] for r in witness['rows'])
indexpath = MAIN/'paper_results/ieee_tc/inputs/20260927_7b_materialized_content_index.json'
index = {r['id']:r for r in json.loads(indexpath.read_text())['artifacts']}
pool = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
for row in witness['logical_adapters']:
    files = {f['path']:f for f in index[row['adapter']]['files']}
    for name, field in (('adapter_model.safetensors','weight_sha256'),('adapter_config.json','config_sha256')):
        assert files[name]['sha256'] == row[field] == p.digest(pool/row['adapter']/name)
protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
common = ['probe.py','native_gpu_witness.py','executed_probe.py','close.py','launch.sh',
    'containers.conf','launch.log','probe_identity.json','preflight.json','image_identity.json',
    'selected_gpu.json','pause_adoption.json','inspect_worker_ownership.json',
    'worker_final_state.json','worker_logs.stdout','worker_logs.stderr','guard.jsonl',
    'output/native_gpu_result.json','output/worker_before_cuda.json','output/permit_cuda.json',
    'probe_closure.json','remove_0.stdout','remove_0.stderr']
files = [d/n for d in (OLD,RAW) for n in common]
files += [OLD/'close_retained_pause.py', RAW/'result.json', RAW/'commands.json',RAW/'curate.py',RAW/'backup.py',
    BASE/'docs/ieee_tc/D488_HYDRASERVE_NATIVE_GPU_ARITHMETIC.md']
manifest = {}
for path in files:
    assert path.stat().st_size < 1048576, path
    if path.suffix=='.py':
        compile(path.read_text(),str(path),'exec')
    manifest[str(path)] = dict(sha256=p.digest(path),bytes=path.stat().st_size)
dest = BASE/'paper_results/ieee_tc/hydraserve/d488'
dest.mkdir()
archive=dest/'native_gpu_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in files:
        bundle.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle.getmembers():
        assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest()==manifest['/home/qhq/'+member.name]['sha256']
summary=dict(kind='hydraserve_native_gpu_arithmetic',checkpoint_verified=True,performance_result=False,
    gpu_executed=True,native_backend_qualified=False,full_model_qualified=False,
    original_native_kernel_checks=first,nonzero_lora_arithmetic=witness,
    max_relative_l2_error=max(r['relative_l2_error'] for r in witness['rows']),
    max_absolute_error=max(r['max_absolute_error'] for r in witness['rows']),
    prior_input_index_sha256=p.digest(indexpath),source_manifest=manifest,
    archive_sha256=p.digest(archive),protected_verification=protected,tests_count=0,
    component_gpu_checks_passed=True,scope_closures=[json.loads((d/'probe_closure.json').read_text()) for d in (OLD,RAW)],
    note='D487 full-file/header check error retained; actual native test/SiLU/flash pass reused. D488 only existing nonzero LoRA arithmetic. No pipeline/model/performance proof.')
save(dest/'summary.json',summary)
receipt=dict(passed=True,source_count=len(files),archive_sha256=p.digest(archive),summary_sha256=p.digest(dest/'summary.json'))
save(RAW/'curation_result.json',receipt)
print(json.dumps(receipt))
