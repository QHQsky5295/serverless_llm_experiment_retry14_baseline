"""Reuse append-only D503 curation after all 1000-prefix closure/audit gates."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d503_20261013/checkpoint.py').read_text()
source=source.replace("['N_response']==100", "['N_response']==1000")
source=source.replace("['n_native_contract_complete']==100", "['n_native_contract_complete']==1000")
source=source.replace("audit['remote_transfers']==29", "audit['remote_transfers']==audit['actual_unique_adapters']")
source=source.replace("audit['remote_wire_bytes']==50650865", "audit['remote_wire_bytes']>0")
source=source.replace("(RAW/'cpu2.log')", "(RAW.parent/'d504_20261013/backup_baseline_smoke.log')")
source=source.replace('D503_HYDRASERVE_COMMON_HTTP.md','D505_HYDRASERVE_1000_COMPATIBILITY.md')
source=source.replace('hydraserve/d503', 'hydraserve/d505')
source=source.replace('http_qualification_evidence.tar.gz','compatibility_evidence.tar.gz')
source=source.replace('n_native_contract_complete=100,n_correct=None,actual_unique_adapters=29',
    "n_native_contract_complete=1000,n_correct=None,actual_unique_adapters=audit['actual_unique_adapters'],\n    cpu_tests_reused_from_d504=True,prelaunch_health_probe_passed=True")
source=source.replace("next='500-ID functional then1000/4000;", "next='one complete4000 HydraServe then full available baseline comparison and PrimeLoRA optimization;")
anchor="paths += [RAW/'remote_artifacts/run_contract.json']"
assert source.count(anchor)==1
source=source.replace(anchor,anchor+"\npaths += [RAW.parent/'d504_20261013/backup_baseline_smoke.log']")
exec(compile(source,str(RAW/'checkpoint_reused.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'checkpoint.py')})
