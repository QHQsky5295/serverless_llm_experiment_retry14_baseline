# D505 preparation assertion correction

The first CPU preparation stopped before any generated inputs, remote service or
GPU launch. It incorrectly expected the reused D503 config to omit request_view;
the unchanged qualified config actually spells out trace_prefix_v1. prepare2.py
checks that exact existing value. Original prepare.py/prepare.log remain intact.
No workload, adapter mapping, baseline policy or backend setting changed.
