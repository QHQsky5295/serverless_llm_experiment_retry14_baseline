"""Reuse native D503/D504 path for the planned 1000-request compatibility step."""
from hashlib import sha256
import json
from pathlib import Path
import sys

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d504_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one

def put(name,value):
    with (RAW/name).open('x') as f:f.write(value)
def save(name,value):put(name,json.dumps(value,indent=2))

for name in ('http_audit.json','backup_baseline_receipt.json','backup_main_receipt.json'):
    assert json.loads((OLD/name).read_text())['passed']
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
for original,record in json.loads((OLD/'source_manifest.json').read_text()).items():
    assert sha256(Path(record['snapshot']).read_bytes()).hexdigest()==record['sha256']
    assert sha256(Path(original).read_bytes()).hexdigest()==record['sha256']
cfg=json.loads((RAW.parent/'d503_20261013/http_7b_100.json').read_text())
assert 'request_view' not in cfg
cfg.update(request_count=1000,experiment_role='native_hydraserve_1000_compatibility',
    qualification_only=True,formal_run=False)
save('http_7b_1000.json',cfg)
save('remote_input_config.json',{k:cfg[k] for k in
    ('ingress_mode','pool_index','pool_index_sha256','remote_artifacts')})
pool_bytes=Path(cfg['pool_index']).read_bytes()
assert sha256(pool_bytes).hexdigest()==cfg['pool_index_sha256']
pool=json.loads(pool_bytes)['artifacts'];assert len(pool)==500
save('lora_registry.json',[dict(adapter_id=aid,adapter_index=i,adapter_path=str(RAW/'adapter_views'/aid))
    for i,aid in enumerate(sorted(item['id'] for item in pool),1)])
qualification=json.loads((OLD/'input_qualification.json').read_text())
qualification.update(reused_d504_metadata_audit=True,d504_http_audit_sha256=sha256((OLD/'http_audit.json').read_bytes()).hexdigest())
save('input_qualification.json',qualification)
for name in ('model_registration.json','close_pause.py','close_audit.py','close_cpu.py',
             'collect_remote.py','start_remote.sh','online_sources.json','run_and_close.sh'):
    put(name,(OLD/name).read_text().replace('d504','d505'))
for name in ('official_main.py','official_scheduler.py','official_engine.py','official_ModelInfo.py'):
    put(name,(OLD/name).read_text())
launch=(OLD/'launch.sh').read_text().replace('d504','d505').replace('http_7b_500','http_7b_1000')
launch=replace_one(launch,'MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline',
    '''MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline
# Prerequisite success is mandatory, not an asynchronous assumption.
jq -e '.preflight_pass' "$RAW/prelaunch_gate.json" >/dev/null
jq -e 'has("3b") and has("7b")' "$RAW/remote_health.json" >/dev/null''')
put('launch.sh',launch)
body=(OLD/'native_body.py').read_text().replace('d504','d505').replace('http_7b_500','http_7b_1000')
body=replace_one(body,'500 existing requests under explicit adapter_coverage_v1 via common HTTP open-loop',
    '1000 existing prefix requests via common HTTP open-loop')
put('native_body.py',body)
witness=(RAW.parent/'d503_20261013/request_witness.py').read_text().replace('common 100-prefix','common 1000-prefix')
witness=replace_one(witness,"terminal['N_response']==100","terminal['N_response']==1000")
put('request_witness.py',witness)
# Probe only after service start returns and inspect its success before launch.
# The existing publisher additionally authenticates the frozen manifest before notice.
put('prelaunch.py',(OLD/'prelaunch.py').read_text())
template=(OLD/'executed_prepare.py').read_text().replace('d504','d505').replace('http_7b_500','http_7b_1000')
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
