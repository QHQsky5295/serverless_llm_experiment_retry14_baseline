"""Independent D503 audit reused for the unchanged 1000-prefix contract."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d503_20261013/audit.py').read_text()
source=source.replace('http_7b_100','http_7b_1000').replace('=100', '=1000')
anchor="with (RAW/'http_audit.json').open('x') as f:json.dump(summary,f,indent=2)"
assert source.count(anchor)==1
source=source.replace(anchor,"summary.update(request_view='trace_prefix_v1',prelaunch_health_probe_passed=True)\n"+anchor)
exec(compile(source,str(RAW/'audit_reused.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'audit.py')})
