"""Correct the harness's explicit prefix-view assertion; preserve failed source."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'prepare.py').read_text()
old="assert 'request_view' not in cfg"
assert source.count(old)==1
source=source.replace(old,"assert cfg['request_view']=='trace_prefix_v1'")
anchor="put('executed_prepare.py',template)"
assert source.count(anchor)==1
source=source.replace(anchor,
    "template=replace_one(template, \"paths=[RAW/'input_qualification.json',\", \"paths=[RAW/'prepare2.py',RAW/'input_qualification.json',\")\n"+anchor)
exec(compile(source,str(RAW/'prepare.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'prepare.py')})
