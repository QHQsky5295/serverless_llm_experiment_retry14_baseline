"""Reuse D480 exact-identity closure for the corrected fixture attempt."""
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
sys.argv = [str(root/'close.py'), 'test']
exec(compile((root/'close.py').read_text(), str(root/'close.py'), 'exec'),
     {'__name__': '__main__', '__file__': str(root/'fixture_retry/close.py')})
