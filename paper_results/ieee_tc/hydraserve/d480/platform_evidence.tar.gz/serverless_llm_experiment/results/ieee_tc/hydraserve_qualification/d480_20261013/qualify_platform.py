"""Bounded CPU-only qualification of the native platform injection seam."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

RAW = Path(__file__).resolve().parent
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW/name).open('x') as handle:
        json.dump(value, handle, indent=2)

identity = p.scope_identity(p.cg_path().name)
save('test_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.max').read_text().strip() == str(256*p.MIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 26}
native = BASE/'vendor_new_baselines/HydraServe_main_20260520'
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=native) == b''
files = ['HydraServe_project/runtime/platform_port.py',
         'tests/test_ieee_tc_hydraserve_platform_port.py']
sources = {file:p.digest(BASE/file) for file in files}
started = time.monotonic()
with (RAW/'test.log').open('x') as log:
    run = subprocess.run([sys.executable, '-B', '-m', 'unittest',
        'tests.test_ieee_tc_hydraserve_platform_port',
        'tests.test_ieee_tc_hydraserve_stage_binding', '-v'], cwd=BASE,
        stdout=log, stderr=subprocess.STDOUT, timeout=30,
        env=dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONNOUSERSITE='1'))
result = dict(passed=run.returncode == 0, returncode=run.returncode,
              source_sha256=sources, elapsed_s=time.monotonic()-started,
              platform_installed=False, native_gpu_qualified=False,
              kubernetes_contacted=False, performance_result=False)
save('test_result.json', result)
print(json.dumps(result), flush=True)
sys.exit(run.returncode)
