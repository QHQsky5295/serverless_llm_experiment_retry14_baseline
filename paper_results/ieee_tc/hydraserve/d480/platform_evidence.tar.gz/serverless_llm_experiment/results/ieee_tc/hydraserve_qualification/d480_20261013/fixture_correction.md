# D480 first CPU-test failure preserved

First run: 21 passed, one error. The synthetic ModelStats test double lacked
`prefill_time`; native ModelStats defines this field with default 0. This was a
test fixture omission, NOT a native scheduling failure or performance result.

Only correction to the test is this one-line substitution:

```diff
-        stats = NS(model_size=14, num_profile_points=0, tpot=0, tpot_slo=100,
+        stats = NS(model_size=14, num_profile_points=0, tpot=0, tpot_slo=100, prefill_time=0,
```

Initial test source SHA is recorded in test_result.json. Reversing the exact
substitution above reconstructs it. Production overlay source is unchanged.
Initial result/log/identity/closure remain at D480 root. Rerun evidence goes to
fixture_retry/, never overwrites the first attempt. No GPU or cluster operation.
