"""Reuse the unchanged qualification helper, writing only a fresh attempt."""
from pathlib import Path

root = Path(__file__).resolve().parent
attempt = root/'fixture_retry'
attempt.mkdir(exist_ok=False)
source = (root/'qualify_platform.py').read_text()
exec(compile(source, str(root/'qualify_platform.py'), 'exec'),
     {'__name__': '__main__', '__file__': str(attempt/'qualify_platform.py')})
