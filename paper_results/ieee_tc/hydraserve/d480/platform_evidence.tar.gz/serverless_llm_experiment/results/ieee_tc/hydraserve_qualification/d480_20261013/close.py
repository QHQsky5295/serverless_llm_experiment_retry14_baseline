"""Close only a saved, still-identical, recursively empty D480 scope."""
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
name = sys.argv[1]
assert name in ('test', 'curation', 'backup_baseline', 'backup_main')
identity = json.loads((RAW/(name+'_identity.json')).read_text())
assert p.scope_still_owned(identity)
group = Path(identity['path'])
entries = {str(x):x.read_text().split() for x in group.rglob('cgroup.procs')}
assert entries and not any(entries.values())
resources = {k:(group/k).read_text().strip()
             for k in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']], check=True)
assert not group.exists()
result = dict(passed=True, identity=identity, resources=resources,
              actual_recursive_procs_empty=True)
with (RAW/(name+'_closure.json')).open('x') as handle:
    json.dump(result,handle,indent=2)
print(json.dumps(result))
