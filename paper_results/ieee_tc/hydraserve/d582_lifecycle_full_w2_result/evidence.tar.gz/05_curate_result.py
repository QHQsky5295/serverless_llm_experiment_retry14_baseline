"""Reuse D539 bounded archive/secret/protected checks for complete D582."""
import hashlib
from pathlib import Path
RAW = Path(__file__).resolve().parent
original = RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source = original.read_text()
def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)
replace("save(RAW/'curation_identity.json',identity)", "save(RAW/'result_identity.json',identity)")
replace("save(RAW/'curation_receipt.json'", "save(RAW/'result_receipt.json'")
replace("((RAW,'review'),(CLEAN,'cleanup'))",
        "tuple((RAW,n) for n in ('prepare','remote_prelaunch','audit','output_comparison','output_comparison2'))")
old = source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old, """review=read(RAW/'full_w2_evaluation.json')
assert review['full_audit_pass'] and review['n_v1_contract_complete']==4000 and review['n_failed']==0
assert review['native_output_tokens']==458224 and review['raw_n_correct_preserved'] is None
assert review['n_joint']==2640 and not review['observed_w2_g1_feasible']
join=read(RAW/'cross_contract.json')
assert join['passed'] and join['request_count']==4000 and join['all_workers_pp1_batch8']
assert join['native_worker_count']==32 and join['final_scheduler_instance_count']==3
assert read(RAW/'closure.json')['actual_recursive_empty']
assert not Path(read(RAW/'closure.json')['service']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
for path,record in read(RAW/'source_manifest.json').items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
for path,sha in review['source_sha256'].items():assert p.digest(Path(path))==sha,path
for ref in join['refs']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
assert read(RAW/'cross_contract_attempt1_failure.json')['inference_repeated'] is False
""")
old = source[source.index('specs=['):source.index('reports=[]')]
replace(old, """names=('audit.py','run_audit.py','cross_contract.py','cross_contract_v2.py',
 'cross_contract_attempt1_failure.json','curate_result.py','close_result.py',
 'preregistration.json','source_manifest.json','reuse_inspection.json','prepare_result.json',
 'w2_input_qualification.json','prelaunch_gate.json','remote_health.json','result.json',
 'closure.json','remote_stop.json','remote_stop.log','external_terminal_summary.json',
 'http_audit.json','full_w2_evaluation.json','full_w2_slo_rows.json','request_metrics.json',
 'cross_contract.json','native_scheduler_after_requests.json','native_admission_capacity.json',
 'generation_result.json','audit_identity.json','audit_closure.json',
 'output_comparison_identity.json','output_comparison_closure.json',
 'output_comparison2_identity.json','output_comparison2_closure.json','remote_transfers.jsonl')
files=[RAW/n for n in names]
files += [RAW/'physical/container_allocations.jsonl',RAW/'physical/summary.json',
 RAW/'launch_gate.launch/exec_receipt.json',original,RAW.parent/'d503_20261013/audit.py',
 RAW.parent/'d570_20261016/close.py',
 RAW.parent.parent/'vllm_qualification/d557_20261016/cross_contract.py',
 ROOT/'docs/ieee_tc/D582_HYDRASERVE_LIFECYCLE_FULL_W2_RESULT.md']
files += sorted((RAW/'platform').glob('d582-w*.native-request.json'))
files += sorted((RAW/'remote_artifacts/receipts').glob('*.json'))
copies={n:RAW/n for n in ('full_w2_evaluation.json','cross_contract.json',
 'full_w2_slo_rows.json','request_metrics.json','closure.json','remote_stop.json')}
specs=[('hydraserve/d582_lifecycle_full_w2_result',files,copies)]
""")
replace('new_gpu_run=False', 'new_gpu_run=True')
replace('Executed assertions plus source AST and archive round-trip; no new serving change or repeated GPU tests',
        'One complete known-trace W2 replay; strict4000 native/remote/clock/physical audit; exact input join to D557 common W2 witness; all32 workers pp1/batch8; failed offline affinity attempt preserved; independent numerical qualification unknown; AST and archive SHA roundtrip')
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'curate_result.py'), 'original': original})
