"""Extend the existing D557 exact W2 input witness; no inference or tuning."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
PREVIOUS = RAW.parent.parent/'vllm_qualification/d557_20261016'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(name, value):
    with (RAW/name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save('output_comparison_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid',
                                   '--format=csv,noheader'], text=True).strip()
closed = read(RAW/'audit_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
current = read(RAW/'full_w2_evaluation.json')
assert current['full_audit_pass'] and current['n_v1_contract_complete'] == 4000
assert current['native_output_tokens'] == 458224 and current['n_failed'] == 0
previous_path = PREVIOUS/'cross_contract.json'
previous = read(previous_path)
assert previous['passed'] and previous['request_count'] == 4000
for ref in previous['refs']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
source = PREVIOUS/'cross_contract.py'
assert p.digest(source) == 'c9439b3bb0b46782b76bc9bd8e583f2f9bc0016c85970b5d7f5b5249131a373a'
# Reuse its exact streaming JSONL contract reader, without executing another
# system's audit or requiring a duplicate copy of its result/trace.
nodes = [node for node in ast.parse(source.read_text()).body
         if isinstance(node, ast.FunctionDef) and node.name == 'contracts']
assert len(nodes) == 1
namespace = {'json': json}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'), namespace)
contracts = namespace['contracts']
replay = RAW/'launch_gate.launch/replay.jsonl'
previous_replay = PREVIOUS/'launch7b.launch/replay.jsonl'
current_rows, previous_rows = contracts(replay), contracts(previous_replay)
assert len(current_rows) == 4000 and current_rows.keys() == previous_rows.keys()
fields = ('request_id', 'adapter_id', 'target_tokens', 'canonical_prompt_sha256',
          'canonical_prompt_tokens', 'native_prompt_token_ids_sha256',
          'source_item_sha256', 'artifact_content_sha256', 'artifact_manifest_sha256')
for rid, row in current_rows.items():
    assert all(row[field] == previous_rows[rid][field] for field in fields), rid
plan = read(RAW/'preregistration.json')['plan_identity']
assert plan == previous['source_plan'] and plan['profile'] == 'W2'
qualification = read(RAW/'w2_input_qualification.json')
assert qualification['exact_4000_entries_equal'] and qualification['actual_unique_adapters'] == 497
comparison = dict(previous['comparison'])
comparison['HydraServe'] = dict(joint=current['joint_slo'],
    gpu_seconds=current['physical_gpu_seconds'], p95_ttft_ms=current['metrics']['ttft_ms']['p95'])
prime = comparison['PrimeLoRA']
changes = {name: dict(lower_better_change_percent={key: 100*(row[key]-prime[key])/row[key]
    for key in ('gpu_seconds', 'p95_ttft_ms')}, joint_difference_pp=100*(prime['joint']-row['joint']))
    for name, row in comparison.items() if name != 'PrimeLoRA'}
workers = [read(path) for path in sorted((RAW/'platform').glob('d582-w*.native-request.json'))]
allocations = [json.loads(line) for line in (RAW/'physical/container_allocations.jsonl').open()]
spawns = {row['worker_name']: row for row in allocations if row['event'] == 'worker_spawn'}
assert len(workers) == len(spawns) == 32
assert set(spawns) == {worker['name'] for worker in workers}
assert all(worker['env']['PP_SIZE'] == '1' and worker['env']['BATCH_SIZE'] == '8' for worker in workers)
save('cross_contract.json', dict(passed=True, schema='d582_w2_four_system_input_witness_v1',
    scope=identity, request_count=4000, compared_fields=list(fields), source_plan=plan,
    comparison=comparison, changes=changes, native_worker_count=32,
    final_scheduler_instance_count=len(read(RAW/'native_scheduler_after_requests.json')['instances']),
    all_workers_pp1_batch8=True, reference_frozen=False, input_join_only=True,
    independent_numerical_correctness='unknown', initial_state_contract_identical=False,
    limitations=previous['limitations']+[
        'HydraServe joint SLO is below 95%; retain the complete nonfeasible observation.',
        'All actual HydraServe workers are pp1; pipeline/consolidation benefit not established.',
        'No previous same-backend W2 output reference; W0 output is not a W2 numerical oracle.'],
    refs=[dict(path=str(path), sha256=p.digest(path)) for path in
          (replay, previous_replay, previous_path, source, Path(__file__),
           RAW/'full_w2_evaluation.json', RAW/'w2_input_qualification.json',
           RAW/'physical/container_allocations.jsonl')]))
print(json.dumps(dict(passed=True, request_count=4000, comparison=comparison,
                      changes=changes, native_workers=32)))
