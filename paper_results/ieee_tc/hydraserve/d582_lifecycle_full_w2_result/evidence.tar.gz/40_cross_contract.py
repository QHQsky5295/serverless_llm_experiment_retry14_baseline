"""Reuse D555's streaming W2 input join for the closed D557 observation."""
import ijson
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
PRIME = RAW.parent.parent/'p2_backend_qualification/d554_20261015'
SERVERLESS = RAW.parent.parent/'serverless_qualification/d555_20261015'
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan

def read(path): return json.loads(path.read_text())
def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def requests(path):
    with path.open('rb') as stream:
        names = []
        for prefix, event, value in ijson.parse(stream, use_float=True):
            if prefix == 'detailed_results' and event == 'map_key':
                names.append(value)
                break
    assert len(names) == 1
    with path.open('rb') as stream:
        yield from ijson.items(stream, 'detailed_results.'+names[0]+'.requests.item', use_float=True)

def contracts(path):
    result = {}
    for line in path.open():
        row = json.loads(line)
        if row['event'] == 'request_contract':
            assert row['request_id'] not in result
            result[row['request_id']] = row
    return result

scope = p.scope_identity(p.cg_path().name)
save(RAW/'contract_identity.json', scope)
group = Path(scope['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
closed = read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
assert not Path(closed['identity']['path']).exists()
current = read(RAW/'audit_full4000_w2.json')
prime_path = PRIME/'cross_contract.json'
prime = read(prime_path)
serverless_path = SERVERLESS/'cross_contract.json'
serverless = read(serverless_path)
assert prime['passed'] and serverless['passed']
assert prime['request_count'] == serverless['request_count'] == 4000
assert current['source_plan'] == prime['source_plan'] == serverless['source_plan']
assert current['source_plan']['profile'] == 'W2'
assert current['measurement_complete'] and current['workload_passed']
assert current['native_revalidated_requests'] == 4000
assert current['actual_native_output_tokens'] == 458224
for witness in (prime, serverless):
    for ref in witness['refs']:
        assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
context = read(RAW/'launch7b.launch/exec_receipt.json')['external_replay']
plan = FrozenReplayPlan.from_launch_context(context)
assert plan.identity() == current['source_plan']
entries = {entry.request_id:entry for entry in plan.entries}
replay = RAW/'launch7b.launch/replay.jsonl'
serverless_replay = SERVERLESS/'launch7b_repaired.launch/replay.jsonl'
current_rows, serverless_rows = contracts(replay), contracts(serverless_replay)
assert current_rows.keys() == serverless_rows.keys() == entries.keys()
assert len(current_rows) == 4000
fields = ('request_id','adapter_id','target_tokens','canonical_prompt_sha256',
          'canonical_prompt_tokens','native_prompt_token_ids_sha256')
for rid, row in current_rows.items():
    assert all(row[field] == serverless_rows[rid][field] for field in fields)
sources = list((PRIME/'7b_initial_control_full_w2').glob('experiment_results*.json'))
assert len(sources) == 1
seen = set()
for row in requests(sources[0]):
    rid = row['request_id']
    assert rid not in seen
    seen.add(rid)
    ref, entry = current_rows[rid], entries[rid]
    assert row['adapter_id'] == ref['adapter_id'] == json.loads(entry.source_json)['adapter_id']
    assert row['requested_completion_tokens'] == row['completion_tokens'] == ref['target_tokens']
    assert row['canonical_prompt_sha256'] == ref['canonical_prompt_sha256']
    assert row['canonical_prompt_tokens'] == ref['canonical_prompt_tokens']
    assert row['native_token_timing']['native_prompt_token_ids_sha256'] == ref['native_prompt_token_ids_sha256']
    assert abs(row['scheduled_arrival_offset_s'] - entry.offset_s) <= 1e-9
    assert row['generation_contract'] == 'fixed_length_greedy_v1' and row['output_contract_match'] is True
assert seen == current_rows.keys()
comparison = dict(serverless['comparison'])
assert comparison['PrimeLoRA'] == dict(joint=prime['observation']['joint_rate'],
    gpu_seconds=prime['observation']['gpu_seconds'], p95_ttft_ms=prime['observation']['p95_ttft_ms'])
comparison['vLLM'] = dict(joint=current['common_slo']['joint_attainment'],
    gpu_seconds=current['physical_gpu_seconds'],
    p95_ttft_ms=current['conditional_metrics']['ttft_ms']['p95_type1'])
x = comparison['PrimeLoRA']
changes = {name:dict(lower_better_change_percent={key:100*(y[key]-x[key])/y[key]
    for key in ('gpu_seconds','p95_ttft_ms')},joint_difference_pp=100*(x['joint']-y['joint']))
    for name,y in comparison.items() if name != 'PrimeLoRA'}
save(RAW/'cross_contract.json',dict(passed=True,schema='d557_w2_three_system_input_witness_v1',
    scope=scope,request_count=4000,compared_fields=[*fields,'scheduled_arrival_offset_s'],
    source_plan=current['source_plan'],comparison=comparison,changes=changes,
    reference_frozen=False,independent_numerical_correctness='unknown',input_join_only=True,
    initial_state_contract_identical=False,
    limitations=['Single known-workload observations; no repeated-run inference.',
        'Native versions, configuration and compilation histories differ; input identity is not output/numerical proof.',
        'PrimeLoRA W2 is below 95%; no G1/G2 closure or global optimum claim.'],
    refs=[dict(path=str(path),sha256=p.digest(path)) for path in
        (replay,serverless_replay,sources[0],prime_path,serverless_path,RAW/'audit_full4000_w2.json',Path(__file__),SERVERLESS/'cross_contract.py')]))

markers = ('Using cache directory:', 'torch.compile takes', 'torch.compile took',
    'init engine (', 'Model loading took', 'Directly load AOT compilation',
    'Loading compiled graph', 'Dynamo bytecode transform time:')
logs = sorted((RAW/'model7b').glob('worker_*.log'))
receipts = sorted((RAW/'model7b/worker_receipts').glob('*.json'))
assert len(logs) == len(receipts) == current['backend_ready_receipts'] == 4
ready = sorted((read(path) for path in receipts),key=lambda row:row['index'])
assert [row['index'] for row in ready] == list(range(4))
save(RAW/'startup_diagnostic.json',dict(scope=scope,
    ready_offsets_from_business_s=[row['at']-context['replay_t0_s'] for row in ready],
    log_evidence=[dict(path=str(path),line=i,text=re.sub(r'\x1b\[[0-9;]*m','',line.rstrip()))
        for path in logs for i,line in enumerate(path.open(errors='replace'),1)
        if any(marker in line for marker in markers)],
    source_order_joint=[row['common_slo']['joint_good'] for row in current['source_order_diagnostics']],
    queue_mean_fraction_of_ttft=current['conditional_metrics']['router_queue_ms']['mean']/current['conditional_metrics']['ttft_ms']['mean'],
    causal_attribution_complete=False,
    refs=[dict(path=str(path),sha256=p.digest(path)) for path in [*logs,*receipts]]))
print(json.dumps(dict(passed=True,comparison=comparison,changes=changes,scope=scope)))
