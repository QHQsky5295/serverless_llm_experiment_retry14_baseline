"""Distinct identity for the explicit-affinity offline invocation; same checks."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
original = RAW/'cross_contract.py'
source = original.read_text()
old = "save('output_comparison_identity.json', identity)"
assert source.count(old) == 1
source = source.replace(old, "save('output_comparison2_identity.json', identity)")
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'cross_contract_v2.py')})
