"""Reuse D539 exact-path publication and safeguards for the D582 result."""
import hashlib
from pathlib import Path
RAW = Path(__file__).resolve().parent
original = RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source = original.read_text()
def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)
replace("save(RAW/'publication_identity.json',identity)",
        "save(RAW/'result_publication_identity.json',identity)")
replace("save(RAW/'publication_receipt.json'", "save(RAW/'result_publication_receipt.json'")
replace('3e759d75b6e69e182d646d87aca5090f5935024f',
        '0fcea6f7a84e8e213e285e032e21d7e7e2ab7e8d')
replace("for name in ('review','curation'):",
        "for name in ('audit','output_comparison2','result'):")
replace("names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md']",
        "names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D582_HYDRASERVE_LIFECYCLE_FULL_W2_RESULT.md']")
replace("reports=read(RAW/'curation_receipt.json')['reports']",
        "reports=read(RAW/'result_receipt.json')['reports']")
replace("assert record['passed'] and not record['new_gpu_run'] and not record['production_changed']",
        "assert record['passed'] and record['new_gpu_run'] and not record['production_changed']")
replace("members=[RAW/n for n in ('publish.py','curation_identity.json','curation_closure.json','curation_receipt.json','close.py')]",
        "members=[RAW/n for n in ('publish_result.py','result_identity.json','result_closure.json','result_receipt.json','close_result.py')]+[original]")
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: preserve complete HydraServe W2 observation and common-input witness (D582)')
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'publish_result.py'), 'original': original})
