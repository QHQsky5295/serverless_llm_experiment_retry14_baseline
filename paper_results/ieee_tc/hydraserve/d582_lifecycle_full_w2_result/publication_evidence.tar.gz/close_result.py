"""Reuse exact-owned empty-scope closure, including retained analysis attempt."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
original = RAW.parent/'d570_20261016/close.py'
source = original.read_text()
old = "('review', 'review2', 'curation', 'curation2', 'publication', 'publication2')"
assert source.count(old) == 1
source = source.replace(old, "('output_comparison2', 'result', 'result_publication')")
exec(compile(source, str(original), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'close_result.py')})
