"""Reuse checked D509/D499 small prelaunch archive, without copying old logs."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d509_20261013/checkpoint.py').read_text()
source=source.replace('d509','d510').replace('D509_HYDRASERVE_AFFECTED_GPU_QUALIFICATION','D510_HYDRASERVE_FULL_W0')
old="""for filename in ('capture_identity','cleanup_remaining_identity','cleanup_reaped_identity',
                 'cleanup_final_identity','prepare_identity'):"""
assert source.count(old)==1
source=source.replace(old,"for filename in ('prepare_identity',):")
source=source.replace('n_plan=100,full_performance_result=False','n_plan=4000,full_performance_result=False')
exec(compile(source,str(RAW/'checkpoint_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'checkpoint.py')})
