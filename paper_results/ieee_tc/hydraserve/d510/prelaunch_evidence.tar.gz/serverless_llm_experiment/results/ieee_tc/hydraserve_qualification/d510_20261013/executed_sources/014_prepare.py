"""Expand the qualified D509 recipe to the original full W0, exactly once.

No new inputs, scheduling change, timeout change or performance search.
Generated launch files are mechanical reuse of the already qualified recipe.
"""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d509_20261013'
FULL=RAW.parent/'d507_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
from faaslora.datasets.workload_generator import FrozenReplayPlan
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one

def digest(path): return sha256(Path(path).read_bytes()).hexdigest()
def put(name,value):
    with (RAW/name).open('x') as f:f.write(value)
def save(name,value):put(name,json.dumps(value,indent=2))

save('prepare_identity.json',p.scope_identity(p.cg_path().name))
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((OLD/'remote_stop.json').read_text())['all_owned_units_inactive']
for mode in ('baseline','main'):
    assert json.loads((OLD/f'result_backup_{mode}_receipt.json').read_text())['passed']
    assert json.loads((OLD/f'result_backup_{mode}_identity_closure.json').read_text())['actual_recursive_empty']
for path,record in json.loads((OLD/'source_manifest.json').read_text()).items():
    assert digest(path)==digest(record['snapshot'])==record['sha256'],path
cfg=json.loads((FULL/'http_7b_4000.json').read_text())
assert cfg['request_count']==4000 and cfg['request_view']=='trace_prefix_v1'
assert digest(cfg['trace'])==cfg['trace_sha256']
assert digest(cfg['pool_index'])==cfg['pool_index_sha256']
save('http_7b_4000.json',cfg)
for name in ('remote_input_config.json','model_registration.json','input_qualification.json',
             'online_sources.json','official_main.py','official_scheduler.py',
             'official_engine.py','official_ModelInfo.py'):
    put(name,(OLD/name).read_text())
for name in ('close_pause.py','close_audit.py','collect_remote.py','start_remote.sh',
             'run_and_close.sh','prelaunch.py','launch.sh','remote_prelaunch.py','close_cpu.py'):
    source=(OLD/name).read_text().replace('d509','d510').replace('http_7b_100.json','http_7b_4000.json')
    put(name,source)
body=(OLD/'native_body.py').read_text().replace('d509','d510').replace('http_7b_100.json','http_7b_4000.json')
body=replace_one(body,'100 existing W0-prefix requests; affected mixed-LoRA/memory qualification','4000 existing W0 requests')
put('native_body.py',body)
witness=(OLD/'request_witness.py').read_text().replace('first100 W0-prefix','full4000 W0')
witness=replace_one(witness,"terminal['N_response']==100","terminal['N_response']==4000")
put('request_witness.py',witness)
pool=json.loads(Path(cfg['pool_index']).read_text())['artifacts']
assert len(pool)==500
save('lora_registry.json',[dict(adapter_id=aid,adapter_index=i,
    adapter_path=str(RAW/'adapter_views'/aid)) for i,aid in
    enumerate(sorted(item['id'] for item in pool),1)])
plan=FrozenReplayPlan.load(cfg['trace'],count=4000).identity()
assert plan['view_sha256']=='a5331be2e2204483f18206825d9aaa18cbaa259fe0babfc303f989055819430d'
prereg=json.loads((OLD/'preregistration.json').read_text())
for ref in prereg['references'].values():assert digest(ref['path'])==ref['sha256']
prereg.update(campaign='d510_20261013',workload='W0',n_plan=4000,plan_identity=plan,
    interpretation='one full W0 development binding/accounting observation; independent numerical qualification remains open',
    reuse_from=str(OLD),reuse_audit_sha256=digest(OLD/'affected_qualification.json'),
    full_config_source=str(FULL/'http_7b_4000.json'),full_config_sha256=digest(FULL/'http_7b_4000.json'),
    no_runtime_policy_change=True,adaptation_change='no new adaptation; retain qualified D508 opt-ins exercised by D509',
    same_backend_output_audit=dict(path=str(OLD/'same_backend_output_comparison.json'),
        sha256=digest(OLD/'same_backend_output_comparison.json'),equal_sequences=96,changed_sequences=4,
        cause_independently_proved=False),
    acceptance=['4000 native contract responses; no failures; exactly 458224 output tokens and 132 observed adapter IDs',
        'source, canonical prompt, native token/adapter, real remote content and clock binding',
        'actual source-derived batch and unchanged D509 overlays',
        'actual physical lifecycle closure and explicit resource events',
        'evaluate frozen common SLO only after full audit; nonfeasibility is retained, not rejected'],
    source_heads={label:subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
                  for label,root in [('baseline',BASE),('main',MAIN)]})
save('preregistration.json',prereg)
template=(OLD/'executed_prepare.py').read_text().replace('d509','d510').replace('http_7b_100.json','http_7b_4000.json')
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
assert json.loads((RAW/'overlays/manifest.json').read_text())==json.loads((OLD/'overlays/manifest.json').read_text())
audit=(FULL/'audit.py').read_text()
audit=replace_one(audit,digest(FULL/'preregistration.json'),digest(RAW/'preregistration.json'))
put('audit.py',audit)
for name in ('prepare.py','request_witness.py','probe.py','prelaunch.py','close_audit.py','collect_remote.py','remote_prelaunch.py','audit.py'):
    compile((RAW/name).read_text(),str(RAW/name),'exec')
for name in ('launch.sh','run_and_close.sh','start_remote.sh'):
    subprocess.run(['bash','-n',str(RAW/name)],check=True)
save('prepare_result.json',dict(passed=True,preregistration_sha256=digest(RAW/'preregistration.json'),
    d509_overlays_equal=True,n_plan=4000,prepared_not_launched=True,performance_result=False,
    full_config_equal=(RAW/'http_7b_4000.json').read_bytes()==(FULL/'http_7b_4000.json').read_bytes()))
print(json.dumps(json.loads((RAW/'prepare_result.json').read_text())))
