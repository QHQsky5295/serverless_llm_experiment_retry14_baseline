"""D480 explicit-file checksum/test/secrets backup, only new D510 evidence."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d510').replace('D480','D510')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['docs/ieee_tc/D510_HYDRASERVE_FULL_W0.md',
        'paper_results/ieee_tc/hydraserve/d510/summary.json',
        'paper_results/ieee_tc/hydraserve/d510/prelaunch_evidence.tar.gz']
    remote,branch='origin','main'
    smoke=['tests.test_ieee_tc_hydraserve_'+name for name in
        ('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
         'tokenizer_compat','request_contract','native_delivery','isolated_platform',
         'platform_port','stage_binding','worker_binding','layer_identity')]
'''+source[end:]
source=source.replace('qualify HydraServe native platform injection seam on CPU',
    'preregister full W0 with qualified HydraServe recipe')
exec(compile(source,str(template),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'backup.py')})
