"""Resume two verified-identity partial blobs; no Podman import or model start.

Download-only wall guard is 3h, derived from remaining bytes and observed slow
registry transfer. This does not change an inference timeout or configuration.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

RAW = Path(__file__).resolve().parent
OUT = RAW / 'resume_attempt'
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)

OUT.mkdir(mode=0o700)
save(RAW / 'resume_identity.json', p.scope_identity(p.cg_path().name))
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
gate = p.preflight([RAW], predicted_growth=4*p.GIB)
save(OUT / 'preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert json.loads((RAW / 'pull_attempt/pull_closure.json').read_text())['passed']
assert json.loads((RAW / 'storage_result.json').read_text())['passed']
audit = json.loads((RAW / 'retained_cache_audit.json').read_text())
assert audit['post_terminal_range_probe']['passed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
manifest_digest = 'sha256:7a5c182f2296dcafacf9576cf09c3d4d188eda4738d51c081a7ca009f0c4a32f'
repo = 'kubernetes-fc/modelscope-vllm'
base = 'https://registry.us-east-1.aliyuncs.com/v2/' + repo + '/'

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        out = super().redirect_request(req, fp, code, msg, headers, newurl)
        if out and urllib.parse.urlsplit(newurl).netloc != urllib.parse.urlsplit(req.full_url).netloc:
            out.remove_header('Authorization')
        return out

opener = urllib.request.build_opener(SafeRedirect)
result = dict(passed=False, kind='resumable_official_image_bytes', performance_result=False,
              model_started=False, image_imported=False, wall_limit_s=10800, completed=[])
started = time.monotonic()

def safety():
    if time.monotonic()-started > 10800:
        raise TimeoutError('download_wall_limit')
    if shutil.disk_usage(RAW).free < 100*p.GIB:
        raise RuntimeError('disk_runtime_floor')
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024
    if available < 16*p.GIB:
        raise RuntimeError('host_memory_floor')

try:
    auth = 'https://dockerauth-us-east-1.aliyuncs.com/auth?' + urllib.parse.urlencode({
        'service':'registry.aliyuncs.com:us-east-1:26842', 'scope':'repository:'+repo+':pull'})
    with opener.open(auth, timeout=25) as response:
        token = json.loads(response.read(65536))['token']
    def get(suffix, headers=None):
        return opener.open(urllib.request.Request(base+suffix, headers={
            'Authorization':'Bearer '+token,
            'Accept':'application/vnd.docker.distribution.manifest.v2+json', **(headers or {})}), timeout=30)
    with get('manifests/'+manifest_digest) as response:
        raw_manifest = response.read(1048577)
    assert len(raw_manifest) <= 1048576
    assert 'sha256:'+hashlib.sha256(raw_manifest).hexdigest() == manifest_digest
    manifest = json.loads(raw_manifest)
    with (OUT/'manifest.raw.json').open('xb') as stream:stream.write(raw_manifest)
    with get('blobs/'+manifest['config']['digest']) as response:
        config = response.read(1048577)
    assert len(config) <= 1048576
    assert 'sha256:'+hashlib.sha256(config).hexdigest() == manifest['config']['digest']
    with (OUT/'config.raw.json').open('xb') as stream:stream.write(config)
    layers = {item['digest']:item for item in manifest['layers']}
    partials = [row for row in audit['files'] if not row['verified']]
    # Every mapping is established by remote prefix AND interior bytes before append.
    for digest in sorted(audit['missing_digests'], key=lambda d:layers[d]['size']):
        size = layers[digest]['size']
        matched = list(partials)
        probes = []
        for offset in (0,1048576):
            with get('blobs/'+digest, {'Range':f'bytes={offset}-{offset+4095}'}) as response:
                assert response.status == 206
                assert response.headers.get('Content-Range') == f'bytes {offset}-{offset+4095}/{size}'
                data = response.read(4097)
            assert len(data) == 4096
            matches=[]
            for row in matched:
                with Path(row['path']).open('rb') as stream:
                    stream.seek(offset)
                    if stream.read(4096) == data:matches.append(row)
            matched=matches
            probes.append(dict(offset=offset,sha256=hashlib.sha256(data).hexdigest()))
        assert len(matched)==1
        row=matched[0]
        path=Path(row['path'])
        stamp=path.stat()
        assert stamp.st_ino==row['inode'] and stamp.st_size==row['bytes'] and stamp.st_uid==os.getuid()
        offset=stamp.st_size
        assert 0<offset<size
        save(OUT/(digest.split(':')[1]+'.resume.json'), dict(digest=digest,source=str(path),
            original_inode=stamp.st_ino,initial_bytes=offset,expected_bytes=size,probes=probes))
        safety()
        with get('blobs/'+digest,{'Range':f'bytes={offset}-{size-1}'}) as response:
            assert response.status==206
            assert response.headers.get('Content-Range')==f'bytes {offset}-{size-1}/{size}'
            assert int(response.headers['Content-Length'])==size-offset
            with path.open('ab',buffering=0) as stream:
                assert os.fstat(stream.fileno()).st_ino==stamp.st_ino
                last_report=time.monotonic()
                while offset<size:
                    safety()
                    data=response.read(min(1024*1024,size-offset))
                    if not data:raise EOFError('incomplete_blob')
                    written=stream.write(data)
                    assert written==len(data)
                    offset+=len(data)
                    if time.monotonic()-last_report>=30:
                        print(json.dumps(dict(digest=digest,bytes=offset,total=size,free=shutil.disk_usage(RAW).free)),flush=True)
                        last_report=time.monotonic()
                os.fsync(stream.fileno())
        assert path.stat().st_size==size
        assert 'sha256:'+p.digest(path)==digest
        entry=dict(digest=digest,path=str(path),bytes=size,initial_bytes=stamp.st_size,verified=True)
        save(OUT/(digest.split(':')[1]+'.verified.json'),entry)
        result['completed'].append(entry)
        print(json.dumps(entry),flush=True)
    result['passed']=True
except Exception as exc:
    reason=getattr(exc,'reason',None)
    result.update(error_type=type(exc).__name__,reason_type=type(reason).__name__,
                  reason_errno=getattr(reason,'errno',None),http_status=getattr(exc,'code',None))
finally:
    result.update(elapsed_s=time.monotonic()-started,disk_free=shutil.disk_usage(RAW).free)
    save(OUT/'result.json',result)
    print(json.dumps(result),flush=True)
sys.exit(0 if result['passed'] else 1)
