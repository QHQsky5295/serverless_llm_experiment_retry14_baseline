"""D477 launcher continuation: immutable official image, bounded private overlay.

No model, GPU container, Kubernetes request or benchmark is launched here.
Credentials/proxy values are never serialized. Existing host services are untouched.
"""
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

REPO = 'kubernetes-fc/modelscope-vllm'
REGISTRY = 'registry.us-east-1.aliyuncs.com'
DIGEST = 'sha256:7a5c182f2296dcafacf9576cf09c3d4d188eda4738d51c081a7ca009f0c4a32f'
RUNTIME = Path('/run/user/1001/pl-hydra-d478')


def save(name, value):
    with (RAW / name).open('x') as stream:
        json.dump(value, stream, indent=2)


identity = p.scope_identity(p.cg_path().name)
save('image_identity_scope.json', identity)
group = Path(identity['path'])
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
assert (group / 'memory.swap.max').read_text().strip() == '0'
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
gate = p.preflight([RAW], predicted_growth=30 * p.GIB)
save('image_preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert not RUNTIME.exists()
RUNTIME.mkdir(mode=0o700)
for name in ('empty_hooks', 'download_tmp'):
    (RAW / name).mkdir()
supervisor = group / 'supervisor'
supervisor.mkdir()
(supervisor / 'cgroup.procs').write_text(str(os.getpid()))
(group / 'cgroup.subtree_control').write_text('+memory +pids')

env = {key: os.environ[key] for key in ('PATH', 'HOME', 'USER', 'LOGNAME', 'LANG',
    'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY',
    'http_proxy', 'https_proxy', 'all_proxy', 'no_proxy') if key in os.environ}
env.update(CONTAINERS_CONF=str(RAW / 'containers.conf'), XDG_RUNTIME_DIR=str(RUNTIME),
    CUDA_VISIBLE_DEVICES='', REGISTRY_AUTH_FILE=str(RAW / 'pull-auth.json'),
    TMPDIR=str(RAW / 'download_tmp'))
base = ['podman', '--root', str(RAW / 'container_storage'),
    '--runroot', str(RUNTIME / 'runroot'), '--storage-driver=overlay',
    '--storage-opt=overlay.mount_program=/usr/bin/fuse-overlayfs',
    '--cgroup-manager=cgroupfs', '--events-backend=file',
    '--runtime=/usr/bin/nvidia-container-runtime', '--hooks-dir', str(RAW / 'empty_hooks')]
commands = []
pause_owner = None
result = dict(passed=False, kind='official_image_acquisition',
    native_backend_qualified=False, performance_result=False, runtime_directory=str(RUNTIME))


def call(tag, args, timeout=120):
    start = time.monotonic()
    with (RAW / (tag + '.stdout')).open('x') as out, (RAW / (tag + '.stderr')).open('x') as err:
        child = subprocess.Popen(base + args, env=env, stdout=out, stderr=err)
        try:
            while child.poll() is None:
                if time.monotonic() - start > timeout:
                    raise TimeoutError(tag)
                if shutil.disk_usage(RAW).free < 100 * p.GIB:
                    raise RuntimeError('runtime disk floor')
                available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))) * 1024
                if available < 16 * p.GIB:
                    raise RuntimeError('host memory floor')
                time.sleep(.5)
        except BaseException:
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=10)
            raise
    commands.append(dict(tag=tag, command=base + args, returncode=child.returncode,
        duration_s=time.monotonic()-start))
    print(json.dumps(commands[-1]), flush=True)
    assert child.returncode == 0, tag
    return (RAW / (tag + '.stdout')).read_text()


try:
    auth = 'https://dockerauth-us-east-1.aliyuncs.com/auth?' + urllib.parse.urlencode({
        'service':'registry.aliyuncs.com:us-east-1:26842','scope':'repository:'+REPO+':pull'})
    with urllib.request.urlopen(auth, timeout=20) as response:
        token = json.load(response)['token']
    def registry_get(suffix):
        request = urllib.request.Request('https://'+REGISTRY+'/v2/'+REPO+'/'+suffix,
            headers={'Authorization':'Bearer '+token,
                'Accept':'application/vnd.docker.distribution.manifest.v2+json'})
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read(1048577)
        assert len(data) <= 1048576
        return data
    raw_manifest = registry_get('manifests/'+DIGEST)
    assert 'sha256:'+hashlib.sha256(raw_manifest).hexdigest() == DIGEST
    manifest = json.loads(raw_manifest)
    save('registry_manifest.json', manifest)
    config_raw = registry_get('blobs/'+manifest['config']['digest'])
    assert 'sha256:'+hashlib.sha256(config_raw).hexdigest() == manifest['config']['digest']
    config = json.loads(config_raw)
    # Keep only non-secret identity fields, not arbitrary image environment/history.
    save('registry_identity.json', dict(registry=REGISTRY, repository=REPO,
        manifest_digest=DIGEST, config_digest=manifest['config']['digest'],
        architecture=config['architecture'], os=config['os'], created=config.get('created'),
        diff_ids=config['rootfs']['diff_ids'],
        compressed_layer_bytes=sum(x['size'] for x in manifest['layers']),
        layer_count=len(manifest['layers'])))
    assert config['architecture'] == 'amd64' and config['os'] == 'linux'
    assert sum(x['size'] for x in manifest['layers']) < 5 * p.GIB
    info = json.loads(call('info', ['info', '--format=json']))
    assert info['store']['graphRoot'] == str(RAW / 'container_storage')
    assert info['store']['graphDriverName'] == 'overlay'
    # Adopt this exclusive namespace's tiny pause process BEFORE download or workers.
    # This does not claim it was born inside our parent or qualify model containment.
    pausefile = RUNTIME / 'libpod/tmp/pause.pid'
    assert pausefile.stat().st_uid == os.getuid()
    pid = int(pausefile.read_text().strip())
    before = p.gpu_process_identity(pid)
    assert before and before['uid'] == os.getuid()
    assert Path(f'/proc/{pid}/comm').read_text().strip() == 'podman pause'
    oldgroup = Path(before['cgroup'])
    assert re.fullmatch(r'podman-pause-[0-9]+\.scope', oldgroup.name)
    own = dict(line.split('=',1) for line in subprocess.check_output([
        'systemctl','--user','show',oldgroup.name,'-p','InvocationID','-p','ControlGroup'],text=True).splitlines())
    assert Path('/sys/fs/cgroup'+own['ControlGroup']) == oldgroup
    assert len(p.owned_pids(oldgroup)) == 1
    assert p.owned_pids(oldgroup)[0]['pid'] == pid
    boot = next(int(x.split()[1]) for x in Path('/proc/stat').read_text().splitlines() if x.startswith('btime '))
    assert abs(boot+before['start_ticks']/os.sysconf('SC_CLK_TCK')-pausefile.stat().st_mtime) < 5
    assert p.gpu_process_identity(pid) == before
    (supervisor / 'cgroup.procs').write_text(str(pid))
    os.sched_setaffinity(pid, {2,3,26,27})
    pause_owner = p.gpu_process_identity(pid)
    assert pause_owner['start_ticks'] == before['start_ticks']
    assert Path(pause_owner['cgroup']) == supervisor
    assert pause_owner['affinity'] == [2,3,26,27]
    assert not (oldgroup / 'cgroup.procs').read_text().split()
    assert subprocess.check_output(['systemctl','--user','show',oldgroup.name,'-p','InvocationID','--value'],text=True).strip() == own['InvocationID']
    subprocess.run(['systemctl','--user','stop',oldgroup.name],check=True)
    save('pause_adoption.json', dict(before=before, after=pause_owner, old_unit=own,
        old_group_removed=not oldgroup.exists(), before_model_and_image_pull=True))
    call('pull', ['pull', REGISTRY+'/'+REPO+'@'+DIGEST], timeout=1800)
    image = json.loads(call('image_inspect', ['image','inspect',REGISTRY+'/'+REPO+'@'+DIGEST]))[0]
    assert image['Digest'] == DIGEST
    assert image['Id'] == manifest['config']['digest'].removeprefix('sha256:')
    assert image['RootFS']['Layers'] == config['rootfs']['diff_ids']
    save('official_image_identity.json', {k:image.get(k) for k in
        ('Id','Digest','RepoDigests','Size','Architecture','Os','RootFS')})
    result.update(passed=True, official_image_digest=image['Digest'], image_size_bytes=image['Size'],
        storage_driver='overlay', model_launched=False, gpu_container_launched=False)
except Exception as exc:
    result['failure'] = type(exc).__name__ + ': ' + str(exc)
finally:
    # Only this newly created namespace's exact captured pause PID is terminated.
    if pause_owner is not None:
        current = p.gpu_process_identity(pause_owner['pid'])
        if current is not None:
            assert current == pause_owner
            fd = os.pidfd_open(current['pid'])
            try:
                assert p.gpu_process_identity(current['pid']) == current
                signal.pidfd_send_signal(fd, signal.SIGKILL)
            finally:
                os.close(fd)
    result['disk_free_after'] = shutil.disk_usage(RAW).free
    result['remaining_scope_members'] = p.owned_pids(group)
    save('image_commands.json', commands)
    save('image_result.json', result)
    print(json.dumps(result), flush=True)
sys.exit(0 if result['passed'] else 1)
