"""Exact identity/recursive-empty closure, continued from D477."""
import json
import subprocess
import sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
name=sys.argv[1]
assert name in ('image','pull','cache','range','inspect','inspect2','storage','resume','curation','backup_baseline','backup_main')
directory=RAW/'pull_attempt' if name=='pull' else RAW
filename='image_identity_scope.json' if name in ('image','pull') else name+'_identity.json'
identity=json.loads((directory/filename).read_text())
group=Path(identity['path'])
assert p.scope_still_owned(identity)
entries={str(x):x.read_text().split() for x in group.rglob('cgroup.procs')}
assert entries and not any(entries.values())
resources={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert not group.exists()
receipt=dict(passed=True,identity=identity,resources=resources,actual_recursive_procs_empty=True)
with (directory/(name+'_closure.json')).open('x') as stream:json.dump(receipt,stream,indent=2)
print(json.dumps(receipt))
