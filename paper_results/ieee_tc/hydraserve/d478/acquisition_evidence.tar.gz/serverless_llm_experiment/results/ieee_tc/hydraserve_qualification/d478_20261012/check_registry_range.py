"""Tiny read-only Range qualification, not an image or performance retry."""
import hashlib
import json
import os
import sys
import urllib.parse
import urllib.request
from pathlib import Path

RAW = Path(__file__).resolve().parent
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW / name).open('x') as stream:
        json.dump(value, stream, indent=2)

save('range_identity.json', p.scope_identity(p.cg_path().name))
owner = json.loads((RAW / 'pull_attempt/image_identity_scope.json').read_text())
assert p.scope_still_owned(owner)
assert not (RAW / 'pull_attempt/image_result.json').exists()
group = Path(owner['path'])
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
(group / 'supervisor/cgroup.procs').write_text(str(os.getpid()))
assert os.sched_getaffinity(0) == {2, 3, 26, 27}

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        result = super().redirect_request(req, fp, code, msg, headers, newurl)
        if result and urllib.parse.urlsplit(newurl).netloc != urllib.parse.urlsplit(req.full_url).netloc:
            result.remove_header('Authorization')
        return result

opener = urllib.request.build_opener(SafeRedirect)
registry = 'registry.us-east-1.aliyuncs.com'
repo = 'kubernetes-fc/modelscope-vllm'
result = dict(passed=False, kind='read_only_range_qualification', full_blob_verified=False)
try:
    auth = 'https://dockerauth-us-east-1.aliyuncs.com/auth?' + urllib.parse.urlencode({
        'service': 'registry.aliyuncs.com:us-east-1:26842', 'scope': 'repository:' + repo + ':pull'})
    with opener.open(auth, timeout=20) as response:
        token = json.loads(response.read(65536))['token']
    manifest = json.loads((RAW / 'pull_attempt/registry_manifest.json').read_text())
    layer = max(manifest['layers'], key=lambda item: item['size'])
    result.update(digest=layer['digest'], expected_bytes=layer['size'])
    def fetch(start):
        end = start + 4095
        req = urllib.request.Request('https://' + registry + '/v2/' + repo + '/blobs/' + layer['digest'],
            headers={'Authorization': 'Bearer ' + token, 'Range': f'bytes={start}-{end}'})
        with opener.open(req, timeout=25) as response:
            record = dict(start=start, status=response.status, content_range=response.headers.get('Content-Range'),
                          content_length=response.headers.get('Content-Length'))
            # Strict bounded read even if server ignores Range.
            data = response.read(4097)
        record.update(received_bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        record['range_valid'] = record['status'] == 206 and record['content_range'] == f'bytes {start}-{end}/{layer["size"]}' and len(data) == 4096
        return record, data
    prefix, data = fetch(0)
    result['prefix'] = prefix
    if prefix['range_valid']:
        matches = []
        for path in sorted((RAW / 'retained_compressed_cache').iterdir()):
            st = path.stat()
            if st.st_size >= 4096:
                with path.open('rb') as stream:
                    if stream.read(4096) == data:
                        matches.append(dict(path=str(path), inode=st.st_ino, bytes_at_check=st.st_size))
        result['prefix_matching_cache_files'] = matches
        assert len(matches) == 1
        # Check an interior offset that already exists; neither truncate nor append.
        offset = min(1024 * 1024, matches[0]['bytes_at_check'] - 4096)
        interior, data = fetch(offset)
        result['interior'] = interior
        with Path(matches[0]['path']).open('rb') as stream:
            stream.seek(offset)
            interior['cache_matches'] = stream.read(4096) == data
        result['passed'] = interior['range_valid'] and interior['cache_matches']
except Exception as exc:
    result['error_type'] = type(exc).__name__
    result['http_status'] = getattr(exc, 'code', None)
save('range_result.json', result)
print(json.dumps(result), flush=True)
