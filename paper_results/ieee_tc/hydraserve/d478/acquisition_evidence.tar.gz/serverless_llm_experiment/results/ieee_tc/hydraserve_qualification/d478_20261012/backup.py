"""Reuse the explicit-file Git milestone checks; do not stage user work."""
import hashlib
import json
import re
import subprocess
import sys
import tarfile
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
mode=sys.argv[1]
assert mode in ('baseline','main')
root=BASE if mode=='baseline' else MAIN
def save(name,data):
    with (RAW/name).open('x') as stream:json.dump(data,stream,indent=2)
scope=p.scope_identity(p.cg_path().name)
save('backup_'+mode+'_identity.json',scope)
summary=json.loads((BASE/'paper_results/ieee_tc/hydraserve/d478/summary.json').read_text())
assert summary['checkpoint_verified'] and not summary['performance_result']
for path, expected in summary['source_manifest'].items():assert p.digest(Path(path))==expected['sha256'],path
assert p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))['pass']
if mode=='baseline':
    paths=['docs/ieee_tc/D478_HYDRASERVE_IMAGE_PREPARATION.md','paper_results/ieee_tc/hydraserve/d478/summary.json',
           'paper_results/ieee_tc/hydraserve/d478/acquisition_evidence.tar.gz']
    remote,branch='origin','main'
    smoke=['tests.test_ieee_tc_hydraserve_layer_identity']
else:
    paths=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D477.md',
           'scripts/ieee_tc/compress_closed_main_outcomes.py','tests/test_ieee_tc_closed_outcome_archive.py',
           'paper_results/ieee_tc/storage/20261012_d478_closed_remote_monitors.json']
    remote,branch='faaslora_origin','retry14_continuous_queue_v2'
    smoke=['tests.test_ieee_tc_closed_outcome_archive','tests.test_ieee_tc_external_replay']
with (RAW/('backup_'+mode+'_smoke.log')).open('x') as stream:
    subprocess.run([sys.executable,'-B','-m','unittest',*smoke,'-v'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,check=True)
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).strip()
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()==branch
subprocess.run(['git','diff','--check'],cwd=root,check=True)
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
    assert not token or token not in data
for name in paths:
    path=root/name
    assert path.stat().st_size<2*1024*1024
    check(path.read_bytes())
    if name.endswith('.tar.gz'):
        assert p.digest(path)==summary['archive_sha256']
        with tarfile.open(path,'r:gz') as bundle:
            for member in bundle.getmembers():
                data=bundle.extractfile(member).read();check(data)
                assert hashlib.sha256(data).hexdigest()==summary['source_manifest']['/home/qhq/'+member.name]['sha256']
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines()
assert set(staged)==set(paths) and all('lora_manifest_1000' not in path for path in staged)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','tc: preserve HydraServe acquisition and lossless storage checkpoint (D478)'],cwd=root,check=True)
subprocess.run(['git','push',remote,branch],cwd=root,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
remote_head=subprocess.check_output(['git','ls-remote',remote,'refs/heads/'+branch],cwd=root,text=True).split()[0]
assert head==remote_head
receipt=dict(passed=True,head=head,remote_head=remote_head,files=paths,scope=scope,
             smoke_sha256=p.digest(RAW/('backup_'+mode+'_smoke.log')))
save('backup_'+mode+'_receipt.json',receipt)
print(json.dumps(receipt))
