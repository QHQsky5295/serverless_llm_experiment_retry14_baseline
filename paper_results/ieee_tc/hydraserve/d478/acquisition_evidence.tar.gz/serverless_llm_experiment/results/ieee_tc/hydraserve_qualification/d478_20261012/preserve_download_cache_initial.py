"""Retain in-progress download inodes without copying bytes or changing the pull.

These links are mutable download cache, NOT sealed source/result evidence.
They allow later verified resume if the bounded registry transfer times out.
"""
import json
import os
import stat
import sys
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
attempt=RAW/'pull_attempt'
identity=json.loads((attempt/'image_identity_scope.json').read_text())
assert p.scope_still_owned(identity)
group=Path(identity['path'])
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert not (attempt/'image_result.json').exists()
# This helper does only metadata work, under the already-owned download parent.
os.sched_setaffinity(0,{2,3,26,27})
(group/'supervisor/cgroup.procs').write_text(str(os.getpid()))
assert p.cg_path()==group/'supervisor'
dest=RAW/'retained_compressed_cache'
dest.mkdir()
items=[]
source_root=attempt/'download_tmp'
for source in sorted(source_root.glob('*/*')):
    before=source.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid()
    assert source.resolve().is_relative_to(source_root)
    name=source.parent.name+'_'+source.name
    target=dest/name
    os.link(source,target,follow_symlinks=False)
    after=target.stat()
    assert (before.st_dev,before.st_ino)==(after.st_dev,after.st_ino)
    items.append(dict(source=str(source),retained=str(target),device=after.st_dev,
        inode=after.st_ino,observed_bytes=after.st_size))
assert items
receipt=dict(passed=True,scope_identity=identity,kind='mutable_download_cache_links',
    duplicated_data_bytes=0,content_verified=False,files=items)
with (RAW/'cache_retention.json').open('x') as stream:json.dump(receipt,stream,indent=2)
print(json.dumps(dict(passed=True,retained_file_count=len(items),duplicated_data_bytes=0,
    content_verified=False)))
