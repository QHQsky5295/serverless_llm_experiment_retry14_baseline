"""Qualify retained compressed bytes after the actual pull has ended.

Does not restart Podman, alter a blob, import an image or load a model.
Never turn a missing original completion record into a claimed success/failure code.
"""
import hashlib
import json
import os
import shutil
import sys
import urllib.parse
import urllib.request
from pathlib import Path

RAW = Path(__file__).resolve().parent
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW / name).open('x') as stream:
        json.dump(value, stream, indent=2)

save('inspect2_identity.json', p.scope_identity(p.cg_path().name))
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
closure = json.loads((RAW / 'pull_attempt/pull_closure.json').read_text())
assert closure['passed'] and not Path(closure['identity']['path']).exists()
assert not (RAW / 'pull_attempt/image_result.json').exists()
manifest = json.loads((RAW / 'pull_attempt/registry_manifest.json').read_text())
layers = {item['digest']: item for item in manifest['layers']}
size_set = {item['size'] for item in layers.values()}
rows = []
for path in sorted((RAW / 'retained_compressed_cache').iterdir()):
    st = path.stat()
    row = dict(path=str(path), inode=st.st_ino, bytes=st.st_size)
    if st.st_size in size_set:
        sha = 'sha256:' + p.digest(path)
        row.update(digest=sha, verified=sha in layers and layers[sha]['size'] == st.st_size)
    else:
        row.update(verified=False, reason='length_not_equal_to_any_manifest_blob')
    # Reading may update atime; check only content/identity mutation fields.
    after = path.stat()
    assert (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns) == (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
    rows.append(row)
verified = {row['digest'] for row in rows if row['verified']}
result = dict(kind='post_terminal_retained_blob_audit', acquisition_complete=False,
    original_result_missing=True, original_pull_returncode=None,
    finalization_error='owned_pids census changed during child exit; preserved original traceback',
    timeout_inference_only='exit timing agrees with the fixed 1800-second pull deadline; original caught exception was not serialized',
    fully_verified_blob_count=len(verified), unique_manifest_blob_count=len(layers),
    verified_bytes=sum(layers[d]['size'] for d in verified),
    retained_bytes=sum(row['bytes'] for row in rows),
    missing_digests=sorted(set(layers)-verified), files=rows,
    disk_free=shutil.disk_usage(RAW).free, model_started=False, performance_result=False)

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        if redirected and urllib.parse.urlsplit(newurl).netloc != urllib.parse.urlsplit(req.full_url).netloc:
            redirected.remove_header('Authorization')
        return redirected

# New metadata observation AFTER all pull connections have closed. No content
# append/retry, disabled TLS verification or global proxy alteration.
probe = dict(passed=False, bytes_transferred_limit=8194, tls_verification=True)
try:
    opener = urllib.request.build_opener(SafeRedirect)
    repo = 'kubernetes-fc/modelscope-vllm'
    auth = 'https://dockerauth-us-east-1.aliyuncs.com/auth?' + urllib.parse.urlencode({
        'service': 'registry.aliyuncs.com:us-east-1:26842', 'scope': 'repository:' + repo + ':pull'})
    with opener.open(auth, timeout=20) as response:
        token = json.loads(response.read(65536))['token']
    layer = max(layers.values(), key=lambda item: item['size'])
    partials = [row for row in rows if not row['verified'] and row['bytes'] >= 1048576 + 4096]
    samples = []
    for start in (0, 1048576):
        req = urllib.request.Request('https://registry.us-east-1.aliyuncs.com/v2/' + repo + '/blobs/' + layer['digest'],
            headers={'Authorization': 'Bearer ' + token, 'Range': f'bytes={start}-{start+4095}'})
        with opener.open(req, timeout=25) as response:
            sample = dict(start=start, status=response.status, content_range=response.headers.get('Content-Range'))
            data = response.read(4097)
        sample.update(received_bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        sample['valid'] = sample['status'] == 206 and sample['content_range'] == f'bytes {start}-{start+4095}/{layer["size"]}' and len(data) == 4096
        sample['cache_matches'] = []
        if sample['valid']:
            for row in partials:
                with Path(row['path']).open('rb') as stream:
                    stream.seek(start)
                    if stream.read(4096) == data:
                        sample['cache_matches'].append(row['path'])
        samples.append(sample)
    probe.update(samples=samples, digest=layer['digest'])
    probe['passed'] = all(s['valid'] for s in samples) and len(samples[0]['cache_matches']) == 1 and samples[0]['cache_matches'] == samples[1]['cache_matches']
except Exception as exc:
    reason = getattr(exc, 'reason', None)
    probe.update(error_type=type(exc).__name__, reason_type=type(reason).__name__,
                 reason_errno=getattr(reason, 'errno', None), http_status=getattr(exc, 'code', None))
result['post_terminal_range_probe'] = probe
save('retained_cache_audit.json', result)
print(json.dumps({key: value for key, value in result.items() if key != 'files'}), flush=True)
