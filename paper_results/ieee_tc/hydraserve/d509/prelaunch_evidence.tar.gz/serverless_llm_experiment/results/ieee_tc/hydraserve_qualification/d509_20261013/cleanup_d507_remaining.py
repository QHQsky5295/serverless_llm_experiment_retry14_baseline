"""Finish exact-owned stale record cleanup: provider before IPC storage owner.

The preceding attempt removed three workers and stopped on storage's remaining
provider dependency. Keep that attempt; verify absent IDs, never recreate them.
"""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'cleanup_d507.py').read_text()
source=source[:source.index('exec(compile(source,')]+'''
source=source.replace("save(RAW / 'capture_identity.json', scope)",
    "save(RAW / 'cleanup_remaining_identity.json', scope)")
source=source.replace("out = RAW/'d507_stopped_containers'",
    "out = RAW/'d507_remaining_containers'")
source=source.replace("failure = {'container_states': receipt['captured']}",
    "failure = {'container_states': [next(r for r in receipt['captured'] if r['name']==name) for name in ('d507-storage','d507-provider')]}")
source=source.replace('assert len(captured) == 5','assert len(captured) == 2')
source=source.replace('pause = None\\ntry:', """pause = None
already_absent=[]
try:
    for row in receipt['captured']:
        if row['name'].startswith('d507-w'):
            code=subprocess.run(base+['container','exists',row['container_id']],env=env,
                                capture_output=True,timeout=30).returncode
            assert code==1
            already_absent.append(dict(name=row['name'],id=row['container_id']))
    save(out/'preceding_attempt_absent.json',already_absent)
""")
try:
    exec(compile(source,str(RAW/'cleanup_remaining_reused.py'),'exec'),
         {'__name__':'__main__','__file__':str(RAW/'cleanup_d507_remaining.py')})
except Exception as exc:
    import json
    with (RAW/'cleanup_remaining_error.json').open('x') as f:
        json.dump(dict(type=type(exc).__name__,message=str(exc),
            stdout=getattr(exc,'stdout',None),stderr=getattr(exc,'stderr',None)),f,indent=2)
    raise
'''
exec(compile(source,str(RAW/'cleanup_remaining_adapter.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'cleanup_d507_remaining.py')})
