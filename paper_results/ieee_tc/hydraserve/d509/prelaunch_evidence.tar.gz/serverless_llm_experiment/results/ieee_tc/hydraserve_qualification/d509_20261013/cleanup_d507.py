"""Reuse the existing owned-container cleanup, retaining D507's sealed logs."""
from pathlib import Path

RAW = Path(__file__).resolve().parent
source = (RAW.parent/'d507_20261013/capture_d506.py').read_text()
source = source.replace('d506', 'd507')
source = source.replace("failure = json.loads((OLD/'container_lifetime_failure.json').read_text())\nassert not Path(failure['service_identity']['path']).exists()", """receipt = json.loads((OLD/'terminal_capture_v2_receipt.json').read_text())
assert receipt['passed'] and not receipt['removed']
failure = {'container_states': receipt['captured']}
for row in failure['container_states']:
    for item in row['logs']:
        assert sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
""")
source = source.replace("    assert not value['State']['Running'] and value['State']['Pid'] == 0", """    # Podman State is stale after the already-recorded hard kill. Never
    # reinterpret it as an original release; require actual absence now.
    for key in ('Pid', 'ConmonPid'):
        pid = value['State'][key]
        assert pid > 0 and not Path(f'/proc/{pid}').exists(), (key, pid)
""")
source = source.replace('assert len(captured) == 6', 'assert len(captured) == 5')
source = source.replace("base+['rm',row['container_id']]", "base+['rm','--force',row['container_id']]")
exec(compile(source,str(RAW/'cleanup_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'cleanup_d507.py')})
