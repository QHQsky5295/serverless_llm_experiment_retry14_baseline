"""Accept observed reaped State after rm, still require actual process absence."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'cleanup_d507_remaining.py').read_text()
source=source.replace('cleanup_remaining_identity.json','cleanup_reaped_identity.json')
source=source.replace('d507_remaining_containers','d507_reaped_containers')
source=source.replace('cleanup_remaining_error.json','cleanup_reaped_error.json')
anchor="try:\n    exec(compile(source,str(RAW/'cleanup_remaining_reused.py'),'exec'),"
replacement='''source=source.replace("    assert value['State'] == row['state']", """    assert value['State']['StartedAt'] == row['state']['StartedAt']
    # Prior exact-ID rm may have updated State before its dependency refusal.
    # Keep both records; absence/owner identity, not State labels, authorizes rm.
""")
source=source.replace("assert pid > 0 and not Path(f'/proc/{pid}').exists(), (key, pid)",
    "assert pid == 0 or not Path(f'/proc/{pid}').exists(), (key, pid)")
try:
    exec(compile(source,str(RAW/'cleanup_remaining_reused.py'),'exec'),'''
assert source.count(anchor)==1
source=source.replace(anchor,replacement)
exec(compile(source,str(RAW/'cleanup_reaped_adapter.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'cleanup_d507_reaped.py')})
