"""Existing explicit-file backup, scoped to the D509 preregistration."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d509').replace('D480','D509')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['docs/ieee_tc/D509_HYDRASERVE_AFFECTED_GPU_QUALIFICATION.md',
        'paper_results/ieee_tc/hydraserve/d509/summary.json',
        'paper_results/ieee_tc/hydraserve/d509/prelaunch_evidence.tar.gz']
    remote,branch='origin','main'
    smoke=['tests.test_ieee_tc_hydraserve_'+name for name in
        ('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
         'tokenizer_compat','request_contract','native_delivery','isolated_platform',
         'platform_port','stage_binding','worker_binding','layer_identity')]
'''+source[end:]
source=source.replace("paths = ['docs/ieee_tc/EXECUTION_STATUS.md']",
    "paths = ['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D508.md']")
source=source.replace('qualify HydraServe native platform injection seam on CPU',
    'preregister affected HydraServe mixed-LoRA GPU qualification')
exec(compile(source,str(template),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'backup.py')})
