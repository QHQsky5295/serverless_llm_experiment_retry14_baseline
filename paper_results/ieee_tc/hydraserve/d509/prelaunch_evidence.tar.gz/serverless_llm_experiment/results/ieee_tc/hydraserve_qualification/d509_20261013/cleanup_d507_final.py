"""Known original PIDs remain the identity authority after Podman reaps State."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'cleanup_d507_reaped.py').read_text()
source=source.replace("source=source.replace('cleanup_remaining_identity.json','cleanup_reaped_identity.json')",
    "source=source.replace('cleanup_remaining_identity.json','cleanup_final_identity.json')")
source=source.replace("source=source.replace('d507_remaining_containers','d507_reaped_containers')",
    "source=source.replace('d507_remaining_containers','d507_final_containers')")
source=source.replace("source=source.replace('cleanup_remaining_error.json','cleanup_reaped_error.json')",
    "source=source.replace('cleanup_remaining_error.json','cleanup_final_error.json')")
anchor='source=source.replace("assert pid > 0'
insertion='''source=source.replace("pid = value['State'][key]", """pid = row['state'][key]
        assert not Path(f'/proc/{pid}').exists()
        pid = value['State'].get(key, 0)""")
'''
assert source.count(anchor)==1
source=source.replace(anchor,insertion+anchor)
exec(compile(source,str(RAW/'cleanup_final_adapter.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'cleanup_d507_final.py')})
