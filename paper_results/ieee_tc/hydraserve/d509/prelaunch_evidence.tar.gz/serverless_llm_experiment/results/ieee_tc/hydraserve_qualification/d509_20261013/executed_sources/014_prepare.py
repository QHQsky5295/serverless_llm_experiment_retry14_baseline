"""D509: affected mixed-LoRA/memory qualification, reusing the D507 recipe.

This is the existing first-100 trace view, not a performance sweep or a new
workload. Only D508's necessary opt-ins change the native execution contract.
"""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d507_20261013'
CPU=RAW.parent/'d508_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one, native_admission_batch
from faaslora.datasets.workload_generator import FrozenReplayPlan

def digest(path): return sha256(Path(path).read_bytes()).hexdigest()
def put(name,value):
    with (RAW/name).open('x') as f: f.write(value)
def save(name,value): put(name,json.dumps(value,indent=2))

save('prepare_identity.json',p.scope_identity(p.cg_path().name))
assert json.loads((RAW/'d507_container_cleanup.json').read_text())['passed']
for mode in ('baseline','main'):
    assert json.loads((CPU/f'backup_{mode}_receipt.json').read_text())['passed']
    assert json.loads((CPU/f'backup_{mode}_identity_closure.json').read_text())['actual_recursive_empty']
for path,record in json.loads((OLD/'source_manifest.json').read_text()).items():
    assert digest(record['snapshot'])==record['sha256'],path
cfg=json.loads((OLD/'http_7b_4000.json').read_text())
assert cfg['request_count']==4000 and cfg['request_view']=='trace_prefix_v1'
cfg.update(request_count=100,experiment_role='d508_affected_mixed_lora_memory_qualification')
save('http_7b_100.json',cfg)
for name in ('remote_input_config.json','model_registration.json','input_qualification.json',
             'online_sources.json','official_main.py','official_scheduler.py',
             'official_engine.py','official_ModelInfo.py'):
    put(name,(OLD/name).read_text())
for name in ('close_pause.py','close_audit.py','collect_remote.py','start_remote.sh',
             'run_and_close.sh','prelaunch.py','launch.sh'):
    source=(OLD/name).read_text().replace('d507','d509').replace('http_7b_4000.json','http_7b_100.json')
    put(name,source)
body=(OLD/'native_body.py').read_text().replace('d507','d509').replace('http_7b_4000.json','http_7b_100.json')
body=body.replace('4000 existing W0 requests','100 existing W0-prefix requests; affected mixed-LoRA/memory qualification')
put('native_body.py',body)
witness=(OLD/'request_witness.py').read_text().replace('full4000 W0','first100 W0-prefix')
witness=replace_one(witness,"terminal['N_response']==4000","terminal['N_response']==100")
witness=replace_one(witness,'        http.set_scheduler(scheduler)', '''        from HydraServe_project.runtime.native_delivery import native_admission_batch
        batch=native_admission_batch(Path('/home/qhq/serverless_llm_baselines/vendor_new_baselines/HydraServe_main_20260520'))
        assert all(model.batch_size==batch for model in scheduler.models)
        save('native_admission_capacity.json',dict(native_batch=batch,
            actual_batches=[model.batch_size for model in scheduler.models],
            max_loras_rule='native_batch * current PP_SIZE',
            cancellation_ownership=True,lora_admission_capacity=True))
        http.set_scheduler(scheduler)''')
put('request_witness.py',witness)
pool=json.loads(Path(cfg['pool_index']).read_text())['artifacts']
assert len(pool)==500 and digest(cfg['pool_index'])==cfg['pool_index_sha256']
save('lora_registry.json',[dict(adapter_id=aid,adapter_index=i,
    adapter_path=str(RAW/'adapter_views'/aid)) for i,aid in
    enumerate(sorted(item['id'] for item in pool),1)])
prereg=json.loads((OLD/'preregistration.json').read_text())
for value in prereg['references'].values(): assert digest(value['path'])==value['sha256']
prereg.update(campaign='d509_20261013',workload='W0_prefix_100_qualification',n_plan=100,
    plan_identity=FrozenReplayPlan.load(cfg['trace'],count=100).identity(),
    interpretation='affected concurrency/memory/contract qualification only; not a full workload performance point',
    adaptation_change='D508 single-owner cancellation and max_loras derived from native batch * PP_SIZE',
    adaptation_checkpoint=str(CPU),
    adaptation_summary_sha256=digest(BASE/'paper_results/ieee_tc/hydraserve/d508/summary.json'),
    reuse_from=str(OLD),reuse_audit_sha256=digest(OLD/'failure_audit_v2.json') if (OLD/'failure_audit_v2.json').exists() else None,
    no_runtime_policy_change=False,no_native_scheduling_policy_change=True,
    cancellation_ownership=True,lora_admission_capacity=True,
    native_batch=native_admission_batch(BASE/'vendor_new_baselines/HydraServe_main_20260520'),
    acceptance=['100 native contract responses; no failures',
        'actual distinct-adapter decode overlap >= 2 on at least one native worker',
        'actual batch equals source-derived admission; native slots and KV stay within GPU capacity',
        'source, canonical prompt, native token/adapter, remote content and clock binding',
        'actual lifecycle closure; no OOM or unresolved native GPU lease'],
    cancellation_gpu_coverage='only if naturally triggered; prior CPU ownership tests separately retained',
    source_heads={label:subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
                  for label,root in [('baseline',BASE),('main',MAIN)]})
prereg.pop('invalid_predecessor',None)
save('preregistration.json',prereg)
template=(OLD/'executed_prepare.py').read_text().replace('d507','d509').replace('http_7b_4000.json','http_7b_100.json')
template=replace_one(template,'request_contract=True,shm_control=True)',
    'request_contract=True,shm_control=True,lora_admission_capacity=True)')
template=replace_one(template,'control_observations=True)',
    'control_observations=True,cancellation_ownership=True)')
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
# The D508 CPU-qualified overlay must be exactly the one exercised here.
assert json.loads((RAW/'overlays/manifest.json').read_text())==json.loads((CPU/'qualified_overlay_manifest.json').read_text())
for name in ('prepare.py','request_witness.py','probe.py','prelaunch.py','close_audit.py','collect_remote.py'):
    compile((RAW/name).read_text(),str(RAW/name),'exec')
for name in ('launch.sh','run_and_close.sh','start_remote.sh'):
    subprocess.run(['bash','-n',str(RAW/name)],check=True)
save('prepare_result.json',dict(passed=True,preregistration_sha256=digest(RAW/'preregistration.json'),
    d508_overlays_equal=True,n_plan=100,full_performance_result=False))
print(json.dumps(json.loads((RAW/'prepare_result.json').read_text())))
