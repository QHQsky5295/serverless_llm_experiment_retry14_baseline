"""Small prelaunch checkpoint; reuse D499 archive and SHA roundtrip code."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tarfile
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
assert json.loads((RAW/'prepare_result.json').read_text())['passed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for filename in ('capture_identity','cleanup_remaining_identity','cleanup_reaped_identity',
                 'cleanup_final_identity','prepare_identity'):
    assert json.loads((RAW/(filename+'_closure.json')).read_text())['actual_recursive_empty']
for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'];save(RAW/'protected_verification.json',protected)
paths=[BASE/'docs/ieee_tc/D509_HYDRASERVE_AFFECTED_GPU_QUALIFICATION.md']
paths += [x for x in RAW.iterdir() if x.is_file() and not x.is_symlink()
          and x.name not in ('pull-auth.json','curation.log')]
for child in ('executed_sources','overlays'):
    paths += [x for x in (RAW/child).rglob('*') if x.is_file() and not x.is_symlink()]
# Original large logs are already sealed in D507. Preserve only hashes/State
# and cleanup receipts here, not another compressed copy of their contents.
for child in RAW.glob('d507_*_containers'):
    paths += [x for x in child.iterdir() if x.suffix=='.json']
template=(RAW.parent/'d499_20261013/checkpoint.py').read_text()
body=template[template.index('paths=sorted(set(paths))'):template.index('summary=dict(')]
body=body.replace("hydraserve/d499'","hydraserve/d509'").replace('generation_release_evidence.tar.gz','prelaunch_evidence.tar.gz')
exec(compile(body,'reused_d499_archive_roundtrip','exec'))
summary=dict(checkpoint_verified=True,performance_result=False,prepared_not_launched=True,
    n_plan=100,full_performance_result=False,source_manifest=manifest,
    archive_sha256=p.digest(archive),archive_bytes=archive.stat().st_size,
    preregistration=json.loads((RAW/'preregistration.json').read_text()),
    protected_verification=protected,old_failures_retained=True)
save(dest/'summary.json',summary)
save(RAW/'curation_result.json',dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size,
    archive_sha256=p.digest(archive),summary_sha256=p.digest(dest/'summary.json')))
print(json.dumps(dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size)))
