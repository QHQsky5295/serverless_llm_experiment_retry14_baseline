"""Post-release only: reuse strict request/remote/physical audits, add overlap.

No full-workload feasibility classification is derived from this short prefix.
"""
from pathlib import Path
import json
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
with (RAW/'audit_identity.json').open('x') as f:
    json.dump(p.scope_identity(p.cg_path().name),f,indent=2)
original=(RAW.parent/'d507_20261013/audit.py').read_text()
source=original[:original.index('    evaluation =')]
source=source.replace('4000','100').replace('458224',"sum(r['target_tokens'] for r in rows)")
source=source.replace("== 132", "== len({r['adapter_id'] for r in contracts.values()})")
source=source.replace('ab9c8692f31d824dd8ee89be6fae0d4e7db6241cea6d15e086653ec7f85f637e',
                      'a3f929110c4586c967565a6fe599791aea95614f4925af1c157db9b91b819fe1')
source+='''    capacity=json.loads((RAW/'native_admission_capacity.json').read_text())
    assert capacity['native_batch']==8 and capacity['actual_batches']==[8]
    intervals={}
    for rid, raw in raws.items():
        n=raw['body']['metrics']['ieee_tc'];proof=n['worker_proof']
        start,spawn,end=by_worker[proof['worker_name']]
        assert proof['container_id']==spawn['container_id']
        assert proof['host_process']==spawn['owner']
        assert start['at']<=n['native_first_token_monotonic_s']<=n['native_last_token_monotonic_s']<=proof['verified_at_s']<=end['at']
        intervals.setdefault(proof['worker_name'],[]).append((n['native_first_token_monotonic_s'],
            n['native_last_token_monotonic_s'],n['native_adapter_id'],rid))
    observed={}
    for worker,values in intervals.items():
        events=[]
        for start,end,adapter,rid in values:
            assert end>start
            events.extend([(start,1,adapter,rid),(end,0,adapter,rid)])
        active={};peak_distinct=peak_requests=0;cross=set()
        for at,kind,adapter,rid in sorted(events):
            if kind==0:assert active.pop(rid)==adapter
            else:
                for prior,other in active.items():
                    if other!=adapter:cross.add(tuple(sorted((prior,rid))))
                active[rid]=adapter
                peak_requests=max(peak_requests,len(active))
                peak_distinct=max(peak_distinct,len(set(active.values())))
        assert not active
        observed[worker]=dict(n=len(values),peak_request_decode_overlap=peak_requests,
            peak_distinct_adapter_decode_overlap=peak_distinct,cross_adapter_overlap_pairs=len(cross))
    mixed=any(v['peak_distinct_adapter_decode_overlap']>=2 for v in observed.values())
    closure=json.loads((RAW/'closure.json').read_text())
    assert closure['event_max']['oom']==closure['event_max']['oom_kill']==0
    gpu_peaks={};samples=0
    with (RAW/'launch_gate.launch/watchdog.jsonl').open() as handle:
        for line in handle:
            event=json.loads(line)
            if event['event']!='resource_sample':continue
            samples+=1
            for device in event['gpu']['devices']:
                used=device['memory_used_bytes'];total=device['memory_total_bytes']
                assert 0<=used<=total
                gpu_peaks[device['gpu_uuid']]=max(gpu_peaks.get(device['gpu_uuid'],0),used)
    memory_lines=[]
    for path in sorted((RAW/'platform').glob('*.stdout')):
        with path.open(errors='replace') as handle:
            for line in handle:
                if any(key in line for key in ('# GPU blocks:','max_loras=','LoRAConfig','GPU memory','KV cache')):
                    memory_lines.append(dict(path=str(path),line=line.rstrip()))
    result=dict(passed=mixed,qualification_only=True,performance_result=False,
        n_native_contract_complete=100,n_failed=0,n_correct=None,
        independent_numerical_qualification=False,actual_batch=capacity,
        per_worker_decode_overlap=observed,mixed_adapter_overlap_observed=mixed,
        physical_gpu_seconds=independent_gpu_s,complete_actual_release=True,
        closure=closure,watchdog_samples=samples,gpu_peak_used_bytes=gpu_peaks,
        native_memory_log_lines=memory_lines,metrics=scope['summary']['metrics'],
        prior_output_comparison=scope['summary']['prior_output_comparison'],
        remote_transfers=scope['summary']['remote_transfers'],
        remote_wire_bytes=scope['summary']['remote_wire_bytes'],
        cancellation_gpu_qualification='not inferred; CPU ownership tests separately retained',
        next='one new full4000 HydraServe then all-baseline comparison' if mixed else 'inspect affected concurrency evidence; no full claim',
        source_sha256={str(path):digest(path) for path in (RAW/'audit.py',RAW/'preregistration.json',
            RAW/'http_audit.json',RAW/'physical/container_allocations.jsonl',RAW/'native_admission_capacity.json')})
    save('affected_qualification.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('metrics','closure','native_memory_log_lines','source_sha256')}))
    assert mixed,'distinct adapter concurrency was not exercised'
'''
source+=original[original.index('except Exception as exc:'):]
exec(compile(source,str(RAW/'audit_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'audit.py')})
