"""Explicitly await remote start and readiness before the existing launch gate."""
import json
from pathlib import Path
import subprocess
import sys
import time
import urllib.error
import urllib.request
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
with (RAW/'remote_prelaunch_identity.json').open('x') as f:
    json.dump(p.scope_identity(p.cg_path().name),f,indent=2)
for mode in ('baseline','main'):
    assert json.loads((RAW/f'backup_{mode}_receipt.json').read_text())['passed']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
subprocess.run(['bash',str(RAW/'start_remote.sh')],check=True,timeout=60)
# Bounded pre-deployment readiness only; no replay or performance clock running.
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_text().strip()
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
started=time.monotonic()
for port in (18080,18081):
    while True:
        request=urllib.request.Request(f'http://192.168.4.174:{port}/health',headers={'Authorization':'Bearer '+token})
        try:
            with opener.open(request,timeout=5) as response:
                assert response.status==200
                json.loads(response.read())
            break
        except urllib.error.HTTPError:
            raise
        except urllib.error.URLError as exc:
            if time.monotonic()-started>=30:raise
            if not isinstance(exc.reason,ConnectionRefusedError):raise
            time.sleep(.25)
subprocess.run([sys.executable,'-B',str(RAW/'prelaunch.py')],check=True,timeout=60)
print(json.dumps(dict(passed=True,remote_start_awaited=True,prelaunch_completed=True)))
