"""Reuse checked explicit backup for new result only; prepared checkpoint stays."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'backup.py').read_text()
source=source.replace("source=source[:start]+", "source=source.replace('backup_'+mode if False else 'backup_', 'result_backup_')\nsource=source[:start]+")
source=source.replace('D509_HYDRASERVE_AFFECTED_GPU_QUALIFICATION.md','D509_HYDRASERVE_GPU_RESULT.md')
source=source.replace('hydraserve/d509/', 'hydraserve/d509_result/')
source=source.replace('prelaunch_evidence.tar.gz','affected_gpu_evidence.tar.gz')
source=source.replace("source=source.replace(\"paths = ['docs/ieee_tc/EXECUTION_STATUS.md']\",\n    \"paths = ['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/EXECUTION_HISTORY_THROUGH_D508.md']\")",'')
source=source.replace('preregister affected HydraServe mixed-LoRA GPU qualification',
    'qualify HydraServe mixed-LoRA concurrency and actual release')
# Summary location originates in the common template, not the explicit list.
source=source.replace("start=source.index(","source=source.replace('hydraserve/d509/','hydraserve/d509_result/')\nstart=source.index(",1)
exec(compile(source,str(RAW/'backup_result_reused.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'backup_result.py')})
