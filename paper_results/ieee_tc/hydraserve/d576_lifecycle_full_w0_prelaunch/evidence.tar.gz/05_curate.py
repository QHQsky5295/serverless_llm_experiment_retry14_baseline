"""Reuse D539 append-only curation for D575 maintenance/D576 preregistration."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert sha256(original.read_bytes()).hexdigest()=='5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("storage_maintenance/d538_20261015", "storage_maintenance/d575_20261016")
replace("((RAW,'review'),(CLEAN,'cleanup'))", "((RAW,'prepare'),(CLEAN,'cleanup'))")
old=source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old,"""prepared=read(RAW/'prepare_result.json')
assert prepared['passed'] and prepared['prepared_not_launched'] and not prepared['performance_result']
assert prepared['n_plan']==4000 and prepared['full_config_equal'] and prepared['native_overlays_unchanged']
clean=read(CLEAN/'cleanup_receipt.json');assert clean['passed'] and clean['returncode']==0
OLD=RAW.parent/'d574_20261016'
before=read(OLD/'cache_cleanup_before.json');after=read(OLD/'cache_cleanup_after.json')
assert before['current_cache_bytes_rehashed'] and before['current_original_bytes_rehashed']
assert after['removed'] and after['observed_reclaimed_bytes']==725774336
assert not after['raw_results_removed'] and not after['unique_artifacts_removed']
assert not Path(after['target']).exists()
for path,record in read(RAW/'source_manifest.json').items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
""")
old=source[source.index('specs=['):source.index('reports=[]')]
replace(old,"""files=sorted(x for x in RAW.iterdir() if x.is_file() and not x.is_symlink()
    and x.suffix in ('.py','.json','.sh') and x.name not in ('pull-auth.json','curation_identity.json'))
for child in ('executed_sources','overlays','metadata'):
    files+=sorted(x for x in (RAW/child).rglob('*') if x.is_file() and not x.is_symlink())
files+=sorted(x for x in CLEAN.iterdir() if x.is_file() and not x.is_symlink())
files+=[OLD/'cache_cleanup_before.json',OLD/'cache_cleanup_after.json',original,
    CLEAN.parent/'d538_20261015/run_cleanup.py',D532/'reclaim_objects.py']
copies={'prepare_result.json':RAW/'prepare_result.json','preregistration.json':RAW/'preregistration.json',
    'prepare_resource_gate.json':RAW/'prepare_resource_gate.json','cleanup_receipt.json':CLEAN/'cleanup_receipt.json',
    'cleanup_closure.json':CLEAN/'cleanup_closure.json','cache_cleanup_after.json':OLD/'cache_cleanup_after.json'}
specs=[('hydraserve/d576_lifecycle_full_w0_prelaunch',files,copies)]
""")
replace("if path.suffix=='.py':ast.parse(data)", """if path.suffix=='.py':
                if path==RAW/'native_body.py' or (path.parent==RAW/'executed_sources' and path.name.endswith('_native_body.py')):
                    import textwrap
                    ast.parse(textwrap.dedent(data.decode('utf-8')))
                else:ast.parse(data)""")
replace('Executed assertions plus source AST and archive round-trip; no new serving change or repeated GPU tests',
        'D574 successful qualification reused; D575 fresh cache/source audit; D576 source/input/overlay checks, AST and shell syntax, archive SHA roundtrip; no new GPU run yet')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py')})
