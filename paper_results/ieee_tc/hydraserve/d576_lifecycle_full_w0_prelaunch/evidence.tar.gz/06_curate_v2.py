"""Preserve curation namespace failure; supply recipe path to reused recipe."""
import json
from pathlib import Path
RAW=Path(__file__).resolve().parent
closed=json.loads((RAW/'curation_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
with (RAW/'curation_attempt1_failure.json').open('x') as f:
    json.dump(dict(error='NameError: original not provided in expanded recipe namespace',
        before_output_creation=True,no_experiment_or_cleanup_repeated=True,closure=closed),f,indent=2)
recipe=RAW/'curate.py'
ns={'__file__':str(recipe),'__name__':'curation_recipe'}
exec(compile(recipe.read_text().split('exec(compile(source,',1)[0],str(recipe),'exec'),ns)
ns['replace']("save(RAW/'curation_identity.json',identity)","save(RAW/'curation2_identity.json',identity)")
ns['replace']("save(RAW/'curation_receipt.json'","save(RAW/'curation2_receipt.json'")
exec(compile(ns['source'],str(ns['original']),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'curate_v2.py'),'original':ns['original']})
