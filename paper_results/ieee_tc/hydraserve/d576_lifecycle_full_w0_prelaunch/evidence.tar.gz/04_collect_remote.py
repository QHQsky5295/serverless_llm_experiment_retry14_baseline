"""Reuse prior exact-invocation remote stop/collection AFTER local GPU release."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']
old=RAW.parent.parent/'p2_backend_qualification/d476_20261012'
source=(old/'stop_remote.sh').read_text()
source=source.replace('p2_backend_qualification/d476_20261012','hydraserve_qualification/d576_20261016')
source=source.replace('d476_20261012_hostexecw0','d576_20261016_hydraremote').replace('d476-hostexecw0','d576-hydraremote')
source=source.replace("jq -e '.native_gpu_context_release_confirmed and .service_path_removed' \"$raw/7b_full_w0/launch.json\" >/dev/null",
    "jq -e '.service_gone and .actual_recursive_empty' \"$raw/closure.json\" >/dev/null")
with (RAW/'stop_remote.sh').open('x') as f:f.write(source)
subprocess.run(['bash',str(RAW/'stop_remote.sh')],check=True,timeout=60)
source=(old/'collect_closure.py').read_text()
start=source.index("stop = (raw/'remote_stop.log').read_text()")
end=source.index("\nsource = next(run.glob",start)
source=source[start:end].replace('d476_20261012_hostexecw0','d576_20261016_hydraremote')
exec(compile(source,str(RAW/'collect_remote_reused.py'),'exec'),dict(raw=RAW,p=p,json=json,subprocess=subprocess))
