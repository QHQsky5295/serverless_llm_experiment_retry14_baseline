"""Reuse exact-path D539 checkpoint before D576 inference; include D575."""
from hashlib import sha256
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert sha256(original.read_bytes()).hexdigest()=='34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('3e759d75b6e69e182d646d87aca5090f5935024f','5084aff91c06b4397697f5a08edee0b31acc46a3')
replace("('review','curation')", "('prepare','curation','curation2')")
replace("reports=read(RAW/'curation_receipt.json')['reports']", "reports=read(RAW/'curation2_receipt.json')['reports']")
replace("'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'",
        "'docs/ieee_tc/D575_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D576_HYDRASERVE_LIFECYCLE_FULL_W0.md'")
replace("('publish.py','curation_identity.json','curation_closure.json','curation_receipt.json','close.py')]",
        "('publish.py','curate_v2.py','curation2_identity.json','curation2_closure.json','curation2_receipt.json','close_cpu.py')]+[original]")
replace('arcname=path.name','arcname=("base_recipe_"+path.name if path==original else path.name)')
replace('bundle.extractfile(path.name)','bundle.extractfile("base_recipe_"+path.name if path==original else path.name)')
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: preserve safe cache reclaim and HydraServe full W0 preregistration (D575-D576)')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py'),'original':original})
