"""Reuse D539 explicit-path publication for the complete D576 W0 evidence."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("save(RAW/'publication_identity.json',identity)","save(RAW/'result_publication_identity.json',identity)")
replace("save(RAW/'publication_receipt.json'","save(RAW/'result_publication_receipt.json'")
replace('3e759d75b6e69e182d646d87aca5090f5935024f','fb03630b9ffa8e3f38a5056e964db585cc8c41a7')
replace("('review','curation')", "('prepare','remote_prelaunch','audit','output_comparison','result')")
replace("not record['new_gpu_run']", "record['new_gpu_run']")
replace("'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'",
        "'docs/ieee_tc/D576_HYDRASERVE_LIFECYCLE_FULL_W0_RESULT.md'")
replace("reports=read(RAW/'curation_receipt.json')['reports']", "reports=read(RAW/'result_receipt.json')['reports']")
replace("('publish.py','curation_identity.json','curation_closure.json','curation_receipt.json','close.py')]",
        "('publish_result.py','result_identity.json','result_closure.json','result_receipt.json','close_result.py')]+[original]")
replace('arcname=path.name','arcname=("base_recipe_"+path.name if path==original else path.name)')
replace('bundle.extractfile(path.name)','bundle.extractfile("base_recipe_"+path.name if path==original else path.name)')
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: seal complete HydraServe W0 lifecycle-adaptation result (D576)')
replace("out=Path(reports[-1]['path']);archive=out/'publication_evidence.tar.gz'", """out=Path(reports[-1]['path']);archive=out/'publication_evidence.tar.gz'
base=Path('/home/qhq/serverless_llm_baselines')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()=='80e08b4c6e7c2874b1b237500a00811ec06cd8c5'
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=base,text=True).split()[0]=='80e08b4c6e7c2874b1b237500a00811ec06cd8c5'
audit=read(out/'full_w0_evaluation.json')
assert audit['full_audit_pass'] and audit['n_v1_contract_complete']==4000 and audit['n_joint']==2729
assert read(out/'old_new_w0_comparison_v2.json')['native_worker_count']==35
for path,record in read(RAW/'source_manifest.json').items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
save(out/'checkpoint.json',dict(baseline_commit='80e08b4c6e7c2874b1b237500a00811ec06cd8c5',
    baseline_remote_equal=True,reused_cpu_tests=71,reused_native_prefix=100,
    qualification='full W0 native contract observation; not G1 feasible, not independent numerical qualification'))
names.append(str((out/'checkpoint.json').relative_to(ROOT)))
""")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish_result.py'),'original':original})
