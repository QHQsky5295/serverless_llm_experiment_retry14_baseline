"""Reuse bounded D539 curation; preserve complete D576 audit and old/new evidence."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("save(RAW/'curation_identity.json',identity)","save(RAW/'result_identity.json',identity)")
replace("save(RAW/'curation_receipt.json'","save(RAW/'result_receipt.json'")
replace("((RAW,'review'),(CLEAN,'cleanup'))", "tuple((RAW,n) for n in ('prepare','remote_prelaunch','audit','output_comparison'))")
old=source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old,"""review=read(RAW/'full_w0_evaluation.json')
assert review['full_audit_pass'] and review['n_v1_contract_complete']==4000 and review['n_failed']==0
assert review['native_output_tokens']==458224 and review['raw_n_correct_preserved'] is None
assert review['n_joint']==2729 and not review['observed_w0_g1_feasible']
join=read(RAW/'same_backend_output_comparison.json')
assert join['passed_contract_match'] and join['n']==4000
assert join['equal_output_sequences']==3942 and join['changed_sequences']==58
assert read(RAW/'closure.json')['actual_recursive_empty']
assert not Path(read(RAW/'closure.json')['service']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
for path,record in read(RAW/'source_manifest.json').items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
for path,sha in review['source_sha256'].items():assert p.digest(Path(path))==sha,path
# R1 analysis correction only: scheduler.instances is the final live set, not
# the number of all workers over the replay. Preserve first analysis unchanged.
comparison=read(RAW/'old_new_w0_comparison.json')
assert comparison['native_worker_count']==3
workers=[read(path) for path in sorted((RAW/'platform').glob('d576-w*.native-request.json'))]
allocations=[json.loads(line) for line in (RAW/'physical/container_allocations.jsonl').read_text().splitlines()]
spawn={e['worker_name']:e for e in allocations if e['event']=='worker_spawn'}
assert len(workers)==len(spawn)==35 and set(spawn)=={w['name'] for w in workers}
assert all(w['env']['PP_SIZE']=='1' and w['env']['BATCH_SIZE']=='8' for w in workers)
comparison['final_scheduler_instance_count']=comparison.pop('native_worker_count')
comparison['native_worker_count']=len(workers)
comparison['all_pp1']=all(w['env']['PP_SIZE']=='1' for w in workers)
comparison['analysis_correction']='R1: original count3 described only final scheduler instances; actual lifecycle/native request records establish35 workers, all pp1/batch8. Original file unchanged; no performance metric changed.'
comparison['sources'][str(RAW/'old_new_w0_comparison.json')]=p.digest(RAW/'old_new_w0_comparison.json')
comparison['sources'][str(RAW/'physical/container_allocations.jsonl')]=p.digest(RAW/'physical/container_allocations.jsonl')
for path in sorted((RAW/'platform').glob('d576-w*.native-request.json')):
    comparison['sources'][str(path)]=p.digest(path)
save(RAW/'old_new_w0_comparison_v2.json',comparison)
""")
old=source[source.index('specs=['):source.index('reports=[]')]
replace(old,"""names=('audit.py','run_audit.py','compare_outputs.py','curate_result.py','close_result.py',
 'preregistration.json','source_manifest.json','reuse_inspection.json','prepare_result.json',
 'prelaunch_gate.json','remote_health.json','result.json','closure.json','remote_stop.json',
 'remote_stop.log','external_terminal_summary.json','http_audit.json','full_w0_evaluation.json',
 'full_w0_slo_rows.json','request_metrics.json','same_backend_output_comparison.json',
 'old_new_w0_comparison.json','old_new_w0_comparison_v2.json','native_scheduler_after_requests.json',
 'native_admission_capacity.json','generation_result.json','audit_identity.json','audit_closure.json',
 'output_comparison_identity.json','output_comparison_closure.json','remote_transfers.jsonl')
files=[RAW/n for n in names]
files += [RAW/'physical/container_allocations.jsonl',RAW/'physical/summary.json',
 RAW/'launch_gate.launch/exec_receipt.json',original,RAW.parent/'d503_20261013/audit.py',
 RAW.parent/'d509_20261013/compare_outputs.py',RAW.parent/'d570_20261016/close.py',
 ROOT/'docs/ieee_tc/D576_HYDRASERVE_LIFECYCLE_FULL_W0_RESULT.md']
files += sorted((RAW/'platform').glob('d576-w*.native-request.json'))
files += sorted((RAW/'remote_artifacts/receipts').glob('*.json'))
copies={n:RAW/n for n in ('full_w0_evaluation.json','old_new_w0_comparison_v2.json',
 'same_backend_output_comparison.json','full_w0_slo_rows.json','request_metrics.json',
 'closure.json','remote_stop.json')}
specs=[('hydraserve/d576_lifecycle_full_w0_result',files,copies)]
""")
replace('new_gpu_run=False','new_gpu_run=True')
replace('Executed assertions plus source AST and archive round-trip; no new serving change or repeated GPU tests',
 'One full known-trace W0 replay; full native input/output/remote/clock/physical audit, all4000 old/new contract joins; independent numerical qualification unknown; reused D573 71 CPU tests and D574 native100 qualification, no repeated GPU run; source AST and archive round-trip')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate_result.py'),'original':original})
