"""Reuse exact-path D539 publication with distinct archive source names."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('3e759d75b6e69e182d646d87aca5090f5935024f','86139f8a501bf06ac3e502ee5586b9ba96faa0b6')
replace("('review','curation')", "('review','review2','review3','curation')")
replace("'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'",
        "'docs/ieee_tc/D572_HYDRASERVE_STARTUP_PATH_REVIEW.md'")
replace("'close.py')]", "'close.py')]+[original]")
replace('arcname=path.name','arcname=("base_recipe_"+path.name if path==original else path.name)')
replace('bundle.extractfile(path.name)','bundle.extractfile("base_recipe_"+path.name if path==original else path.name)')
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: preserve HydraServe startup path and adaptation hypotheses (D572)')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py'),'original':original})
