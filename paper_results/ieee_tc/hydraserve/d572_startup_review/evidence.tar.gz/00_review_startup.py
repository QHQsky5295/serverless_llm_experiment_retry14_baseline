"""Extend D570 bounded offline review with original startup/delivery logs.

No GPU run, controller import, source modification or counterfactual latency.
"""
from pathlib import Path
import hashlib
BASE_RECIPE=Path(__file__).resolve().parent.parent/'d570_20261016/review_native.py'
assert hashlib.sha256(BASE_RECIPE.read_bytes()).hexdigest()=='3b94f7e9cd7fc34a479f54e5d43d63bb213ab2eb8ed5772b12f378d5b6addbb3'
# Reuse precisely the prior imports/helpers and bounded actual-scope gate.
source=BASE_RECIPE.read_text()
prefix=source[:source.index('refs = [Path(__file__)]')]
assert prefix.count('review2_identity.json')==1
exec(compile(prefix.replace('review2_identity.json','review3_identity.json'),str(BASE_RECIPE),'exec'))
refs={BASE_RECIPE,Path(__file__)}
review570=read(RAW.parent/'d570_20261016/review.json')
refs.add(RAW.parent/'d570_20261016/review.json')
results={}
for label,directory,count in [('D510_W0','d510_20261013',34),('D546_W1','d546_20261015',21)]:
    root=RAW.parent/directory
    closure=read(root/'closure.json')
    assert closure['service_gone'] and closure['actual_recursive_empty']
    assert not Path(closure['service']['path']).exists()
    refs.add(root/'closure.json')
    commands={}
    for path in (root/'platform').glob('*.command.json'):
        item=read(path)
        if item['args'][0]=='logs':
            assert item['args'][1] not in commands
            commands[item['args'][1]]=path
    role_logs={}
    for role in ('provider','storage'):
        own=root/'platform'/(directory.split('_')[0]+'-'+role+'.ownership.json')
        command=commands[read(own)['container_id']]
        assert read(command)['returncode']==0
        log=command.with_name(command.name.removesuffix('.command.json')+'.stdout')
        role_logs[role]=log.read_text()
        refs.update((own,command,log))
    storage=role_logs['storage']
    starts=[float(x) for x in re.findall(r'Received pre-load request for llama2_7b/0 at ([0-9.eE+-]+) s',storage)]
    spans=[float(x) for x in re.findall(r'Process pre-load request for llama2_7b/0 time cost = ([0-9.eE+-]+) seconds',storage)]
    buffers=[(int(a),int(b)) for a,b in re.findall(r'allocate_buffer \[\d+\]: \((\d+), (\d+)\)',storage)]
    freed=[(int(a),int(b)) for a,b in re.findall(r'free_buffer: \((\d+), (\d+)\)',storage)]
    assert len(starts)==len(spans)==len(buffers)==len(freed)==count
    assert buffers==freed and all(b-a==13476855675 for a,b in buffers)
    # Native SharedMemory reserves 8 progress bytes in addition to wire content.
    data_bytes=buffers[0][1]-buffers[0][0]-8
    provider=[]
    for thread,threads,span,speed in re.findall(r'send_state_dict \[(\d+)-(\d+)\] time cost = ([0-9.eE+-]+) seconds, speed = ([0-9.eE+-]+) GB/s',role_logs['provider']):
        # The source's GB/s string actually divides by 1024**3.
        elapsed=float(span);rate=float(speed)
        provider.append(dict(thread=int(thread),threads=int(threads),elapsed_s=elapsed,
            reported_rate_gib_s=rate,derived_bytes=elapsed*rate*(1024**3)))
    assert len(provider)==2*count and all(x['threads']==2 and x['thread'] in (0,1) for x in provider)
    assert abs(sum(x['derived_bytes'] for x in provider)-count*data_bytes)<32
    assert all(starts[i]+spans[i]<=starts[i+1] for i in range(count-1))
    service=root/'launch_gate.launch/service.log'
    lines=service.read_text().splitlines()
    refs.add(service)
    cold=[];rnets=[];current=None;init=[]
    assignments=0
    assigned_ids=set()
    for number,line in enumerate(lines,1):
        if line.startswith('Rnets = '):
            rnets.append(ast.literal_eval(line.split('=',1)[1].strip()))
        if line=='Model llama2_7b/0 allocated to [0]':
            assert current is None
            current=dict(start_line=number,assignments_while_initializing=0,
                         prior_generations_finished_while_initializing=0)
        matched=re.fullmatch(r'initialize pods for (\[.*\]) time cost = ([0-9.eE+-]+) seconds',line)
        if matched:
            ips=ast.literal_eval(matched[1]);assert len(ips)==1
            init.append(dict(address=ips[0],elapsed_s=float(matched[2])))
        matched=re.fullmatch(r'scheduler: create instance \[(\d+)\] for llama2_7b/0, allocate_time = ([0-9.]+) s, create_pod_time = ([0-9.]+) s, init_pod_time = ([0-9.]+) s',line)
        if matched:
            assert current is not None and 'instance_id' not in current
            current.update(instance_id=int(matched[1]),allocation_s_rounded=float(matched[2]),
                create_s_rounded=float(matched[3]),init_s_rounded=float(matched[4]))
        matched=re.fullmatch(r'scheduler: model llama2_7b/0 coldstart time = ([0-9.]+) s, slo = (-?[0-9.]+)',line)
        if matched:
            assert current is not None and 'instance_id' in current
            current.update(coldstart_s_rounded=float(matched[1]),native_startup_slo_s_rounded=float(matched[2]),end_line=number)
            cold.append(current);current=None
        # Two processes can concatenate complete print records on one line.
        # Preserve each complete typed event, not only whole-line matches.
        for assignment in re.finditer(r'request \[(req_\d+)\] allocated to instance \[\d+\], waiting time = [0-9.]+ seconds',line):
            assert assignment[1] not in assigned_ids
            assigned_ids.add(assignment[1])
            assignments+=1
            if current is not None:current['assignments_while_initializing']+=1
        if current is not None:
            current['prior_generations_finished_while_initializing']+=len(re.findall(r'Request \[req_\d+\] generation finished, #Tokens = \d+, elapsed [0-9.]+ s',line))
    assert current is None and len(cold)==len(rnets)==len(init)==count and assignments==4000
    assert assigned_ids=={row['request_id'] for row in read(root/'request_metrics.json')}
    assert {x['instance_id'] for x in cold}==set(range(count))
    prior=review570['observations'][label]
    workers={int(w['worker'].split('-w')[-1]):w for w in prior['workers']}
    for row in cold:
        row['native_request_count']=workers[row['instance_id']]['native_request_count']
    # Full worker-load spans already belong to known container logs; read only
    # those source-SHA-bound logs, not arbitrary current files.
    load=[]
    for ref in review570['refs']:
        path=Path(ref['path'])
        if path.parent!=root/'platform' or path.suffix!='.stdout':continue
        assert p.digest(path)==ref['sha256']
        refs.add(path)
        for line in path.open():
            matched=re.fullmatch(r"GPU executor: init worker time cost: create worker=([0-9.eE+-]+) s, init device=([0-9.eE+-]+) s, load model=([0-9.eE+-]+) s\s*",line)
            if matched:load.append(float(matched[3]))
    assert len(load)==count
    results[label]=dict(workers=count,backbone_bytes_per_delivery=data_bytes,
        local_preload_elapsed_s=stats(spans),local_preload_effective_gbit_s=stats([data_bytes*8/1e9/x for x in spans]),
        local_preload_intervals=[dict(start_s=a,elapsed_s=b) for a,b in zip(starts,spans)],
        overlapping_preload_intervals=0,provider_threads=provider,
        provider_sum_derived_bytes=sum(x['derived_bytes'] for x in provider),
        native_executor_load_model_elapsed_s=stats(load),native_initialize_pods_s=stats([x['elapsed_s'] for x in init]),
        native_create_pod_s_rounded=stats([x['create_s_rounded'] for x in cold]),
        native_coldstart_s_rounded=stats([x['coldstart_s_rounded'] for x in cold]),
        successful_allocation_rnets=rnets,startups=cold,request_assignments=assignments,
        startup_intervals_with_existing_completions=sum(x['prior_generations_finished_while_initializing']>0 for x in cold),
        existing_completions_in_startup_intervals=sum(x['prior_generations_finished_while_initializing'] for x in cold),
        assignment_count_in_startup_intervals=sum(x['assignments_while_initializing'] for x in cold))
    refs.update((root/'source_manifest.json',root/'overlays/manifest.json',root/'native_body.py'))
for relative in ('scripts/kubernetes/vllm/src/scheduler.py','scripts/kubernetes/vllm/src/resource_manager.py',
                 'scripts/kubernetes/vllm/src/algs.py','scripts/kubernetes/vllm/storage_server/local_server.py',
                 'scripts/kubernetes/vllm/storage_server/remote_server.py'):
    refs.add(NATIVE/relative)
save(RAW/'review.json',dict(passed=True,schema='d572_hydraserve_startup_log_review_v1',identity=identity,
    source_plan_sha256=p.check_plan(),new_performance_run=False,changed_serving_code=False,
    observations=results,refs=[dict(path=str(x),sha256=p.digest(x)) for x in sorted(refs)],
    limitations=['Local preload interval includes query, process startup, transport and completion polling; not isolated NIC bandwidth.',
                 'Provider elapsed*rate recovers bytes from rounded log fields; allocation supplies exact payload bound.',
                 'Native create/coldstart prints rounded tenths of seconds; do not use for submillisecond timing.',
                 'Sequential startup-line intervals describe actual event ordering; not a counterfactual latency result.',
                 'Successful Rnets records do not expose every failed or skipped scheduling attempt.',
                 'Two logical-node pipeline/consolidation and independent numerical correctness remain unqualified.']))
print(json.dumps(dict(passed=True,summary={k:{n:v[n] for n in ('workers','local_preload_elapsed_s',
    'local_preload_effective_gbit_s','native_coldstart_s_rounded','startup_intervals_with_existing_completions',
    'existing_completions_in_startup_intervals','assignment_count_in_startup_intervals')} for k,v in results.items()})))
