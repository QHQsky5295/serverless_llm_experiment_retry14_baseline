"""Reuse D539 offline-review curation for D572; retain parser failures."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("((RAW,'review'),(CLEAN,'cleanup'))", "((RAW,'review'),(RAW,'review2'),(RAW,'review3'))")
old=source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old,"""review=read(RAW/'review.json')
assert review['passed'] and not review['changed_serving_code'] and not review['new_performance_run']
for key,count in (('D510_W0',34),('D546_W1',21)):
    row=review['observations'][key]
    assert row['workers']==len(row['startups'])==count and row['request_assignments']==4000
    assert row['assignment_count_in_startup_intervals']==0
    assert row['local_preload_elapsed_s']['n']==count and row['backbone_bytes_per_delivery']==13476855667
assert p.check_plan()==review['source_plan_sha256']
""")
old=source[source.index('specs=['):source.index('reports=[]')]
replace(old,"""specs=[('hydraserve/d572_startup_review',
 [RAW/n for n in ('review_startup.py','close.py','curate.py','review_identity.json',
 'review_closure.json','review2_identity.json','review2_closure.json','review3_identity.json',
 'review3_closure.json','review_attempt1_source.tar.gz','review_attempt1_failure.json',
 'review_attempt2_source.tar.gz','review_attempt2_failure.json')]+
 [original,RAW.parent/'d570_20261016/review_native.py'],
 {'review.json':RAW/'review.json','review_closure.json':RAW/'review3_closure.json'})]
""")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py'),'original':original})
