"""Reuse D570 actual-identity recursive-empty closure."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d570_20261016/close.py'
source=original.read_text()
assert source.count("'review2',")==1
source=source.replace("'review2',", "'review2', 'review3',")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'close.py')})
