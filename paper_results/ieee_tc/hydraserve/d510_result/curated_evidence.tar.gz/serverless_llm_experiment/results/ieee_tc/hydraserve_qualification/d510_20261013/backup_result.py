"""D480 exact-file tests/secrets/checksum backup for the complete D510 result."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d510_result').replace('D480','D510')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['docs/ieee_tc/D510_HYDRASERVE_FULL_W0_RESULT.md',
        'paper_results/ieee_tc/hydraserve/d510_result/summary.json',
        'paper_results/ieee_tc/hydraserve/d510_result/curated_evidence.tar.gz']
    remote,branch='origin','main'
    smoke=['tests.test_ieee_tc_hydraserve_'+name for name in
        ('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
         'tokenizer_compat','request_contract','native_delivery','isolated_platform',
         'platform_port','stage_binding','worker_binding','layer_identity')]
'''+source[end:]
source=source.replace("paths = ['docs/ieee_tc/EXECUTION_STATUS.md']",
    "paths = ['docs/ieee_tc/EXECUTION_STATUS.md','paper_results/ieee_tc/main_comparison/d510_7b_w0/comparison.json','paper_results/ieee_tc/main_comparison/d510_7b_w0/delivery.json']")
source=source.replace('qualify HydraServe native platform injection seam on CPU',
    'seal full HydraServe W0 and matched seven-system evidence')
source=source.replace('backup_', 'result_backup_')
exec(compile(source,str(template),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'backup_result.py')})
