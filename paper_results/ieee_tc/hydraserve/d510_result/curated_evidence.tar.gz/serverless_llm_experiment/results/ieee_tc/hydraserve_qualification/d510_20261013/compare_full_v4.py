"""Source-pinned join with the FOUR exhaustively audited representation changes.

No chained fallback or relaxed hashes: current runtime stays pinned, historical
code uses its exact committed bytes, and gzip must decode to the original SHA.
All other references retain the original strict comparison check.
"""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'compare_full.py').read_text()
source=source.replace("RAW/'comparison_identity.json'","RAW/'comparison_v4_identity.json'")
start=source.index('refs={}\n')
end=source.index('\ndef read(',start)
source=source[:start]+'''refs={}
import gzip
representation_receipts=[]
inventory=json.loads((RAW/'reference_inventory.json').read_text())
assert inventory['reference_count']==217 and len(inventory['differences'])==4
differences={(r['path'],r['expected_sha256']):r for r in inventory['differences']}
historical={
    str(MAIN/'docs/ieee_tc/BASELINE_EXECUTION_RULES_20261011.md'):
        (MAIN,'29e98482d0375181fb020f53747d29ecdb136336','historical_baseline_execution_rules.md'),
    str(BASE/'scripts/prepare_ieee_tc_serverless_stack.py'):
        (BASE,'b28c993f02ccdfb0726f3c2edf9201e05872add7','historical_prepare_ieee_tc_serverless_stack.py')}
def checked(path,expected=None):
    path=Path(path)
    record=differences.get((str(path),expected))
    if record is not None and str(path) in historical:
        assert p.digest(path)==record['current_sha256']
        root,commit,name=historical[str(path)]
        payload=subprocess.check_output(['git','show',commit+':'+path.relative_to(root).as_posix()],cwd=root)
        assert sha256(payload).hexdigest()==expected
        target=RAW/name
        if target.exists():assert target.read_bytes()==payload
        else:
            with target.open('xb') as f:f.write(payload)
        representation_receipts.append(dict(original_path=str(path),original_sha256=expected,
            historical_commit=commit,retained_path=str(target),current_sha256=record['current_sha256']))
        path=target
    elif record is not None and record['gzip_present']:
        assert not path.exists()
        target=Path(str(path)+'.gz');digest=sha256();size=0
        with gzip.open(target,'rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):
                digest.update(block);size+=len(block)
        assert digest.hexdigest()==expected
        representation_receipts.append(dict(original_path=str(path),original_sha256=expected,
            retained_path=str(target),retained_sha256=p.digest(target),decompressed_bytes=size))
        path=target;expected=representation_receipts[-1]['retained_sha256']
    actual=p.digest(path)
    assert expected is None or actual==expected,path
    assert str(path) not in refs or refs[str(path)]==actual,path
    refs[str(path)]=actual
    return path
'''+source[end:]
source=source.replace("checked(RAW/'compare_full.py')", "checked(RAW/'compare_full.py');checked(RAW/'compare_full_v4.py');checked(RAW/'reference_inventory.json')")
source=source.replace("summary=dict(kind='d510_full_seven_system_known_w0_observation',",
    "summary=dict(kind='d510_full_seven_system_known_w0_observation',representation_receipts=representation_receipts,")
exec(compile(source,str(RAW/'compare_full_v4_executed'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'compare_full.py')})
