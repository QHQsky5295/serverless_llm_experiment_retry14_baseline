"""Same measurement join, existing PrimeLoRA streaming-analysis environment."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=(RAW/'compare_full_v5.py').read_text()
scope={'__name__':'__main__','__file__':str(RAW/'compare_full_v5.py')}
exec(compile(template[:template.index('exec(compile(source,')],str(RAW/'compare_v5_preparation'),'exec'),scope)
source=scope['source'].replace("RAW/'comparison_v5_identity.json'","RAW/'comparison_v6_identity.json'")
source=source.replace("checked(RAW/'compare_full_v5.py')", "checked(RAW/'compare_full_v5.py');checked(RAW/'compare_full_v6.py');checked(RAW/'comparison_executed_v6.py')")
compile(source,str(RAW/'comparison_executed_v6.py'),'exec')
with (RAW/'comparison_executed_v6.py').open('x') as f:f.write(source)
exec(compile(source,str(RAW/'comparison_executed_v6.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'compare_full.py')})
