"""Reuse D507 compact evidence backup; full closed archive remains local."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d507_20261013/compact_checkpoint.py').read_text()
source=source.replace("hydraserve/d507'","hydraserve/d510_result'")
source=source.replace('failed_w0_summary.json','full_summary.json')
source=source.replace('failed_w0_evidence.tar.gz','full_w0_evidence.tar.gz')
source=source.replace('failed_w0_curated_evidence.tar.gz','curated_evidence.tar.gz')
source=source.replace('failed_w0_checkpoint_summary.json','summary.json')
source=source.replace("required={'failure_request_metrics.json','failure_matched_contracts.json'}",
    "required={'request_metrics.json','full_w0_slo_rows.json','full_seven_system_comparison.json'}")
source=source.replace("assert all(p.digest(path)==full['source_manifest'][str(path)]['sha256'] for path in paths)","""
for path in (RAW/'compact_checkpoint.py',RAW/'backup_result.py'):
    assert str(path) not in full['source_manifest']
    full['source_manifest'][str(path)]=dict(sha256=p.digest(path),bytes=path.stat().st_size,
        role='postrelease compact/publication script; additional to immutable full archive')
    paths.append(path)
assert all(p.digest(path)==full['source_manifest'][str(path)]['sha256'] for path in paths)
""")
source += '''
dest_main=MAIN/'paper_results/ieee_tc/main_comparison/d510_7b_w0'
dest_main.mkdir()
original=RAW/'full_seven_system_comparison.json'
with (dest_main/'comparison.json').open('xb') as f:f.write(original.read_bytes())
assert p.digest(dest_main/'comparison.json')==p.digest(original)
save(dest_main/'delivery.json',dict(passed=True,comparison_sha256=p.digest(original),
    source_path=str(original),baseline_summary_path=str(dest/'summary.json'),
    baseline_summary_sha256=p.digest(dest/'summary.json'),
    full_archive=summary['local_full_archive'],qualified_full_request_join=4000,
    no_new_gpu_replay=True,no_figures=True,formal_m1_m2_complete=False))
'''
exec(compile(source,str(RAW/'compact_checkpoint_executed'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'compact_checkpoint.py')})
