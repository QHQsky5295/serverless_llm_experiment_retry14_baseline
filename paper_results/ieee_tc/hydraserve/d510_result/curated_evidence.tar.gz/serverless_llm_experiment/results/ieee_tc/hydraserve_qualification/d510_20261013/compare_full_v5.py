"""Use the actual complete launch receipt; retain every old source check."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=(RAW/'compare_full_v4.py').read_text()
boundary=template.index('exec(compile(source,')
scope={'__name__':'__main__','__file__':str(RAW/'compare_full_v4.py')}
exec(compile(template[:boundary],str(RAW/'compare_v4_preparation'),'exec'),scope)
source=scope['source'].replace("RAW/'comparison_v4_identity.json'","RAW/'comparison_v5_identity.json'")
anchor="context=launch['external_replay']"
assert source.count(anchor)==1
source=source.replace(anchor,"""context=read(RAW/'launch_gate.launch/exec_receipt.json')['external_replay']
assert {key:context[key] for key in launch['external_replay']}==launch['external_replay']""")
source=source.replace("checked(RAW/'compare_full_v4.py')", "checked(RAW/'compare_full_v4.py');checked(RAW/'compare_full_v5.py')")
exec(compile(source,str(RAW/'compare_full_v5_executed'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'compare_full.py')})
