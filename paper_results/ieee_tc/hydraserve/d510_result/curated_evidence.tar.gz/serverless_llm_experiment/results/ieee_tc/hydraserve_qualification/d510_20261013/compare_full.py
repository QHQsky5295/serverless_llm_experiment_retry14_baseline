"""Post-release seven-system W0 join using existing D454/D476 primitives.

Prepared while inference runs, NEVER executed before complete release/audit.
No replay, input regeneration, reference refreeze or baseline optimization.
"""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
PRIME=RAW.parent.parent/'p2_backend_qualification/d476_20261012'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.check_d299_full_context import (
    matched_controller_rows,matched_request_contract,matched_relative_observation)
from faaslora.datasets.workload_generator import FrozenReplayPlan

def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)

# A live GPU is a hard refusal, not permission to scan active measurements.
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
save(RAW/'comparison_identity.json',p.scope_identity(p.cg_path().name))
refs={}
def checked(path,expected=None):
    path=Path(path);actual=p.digest(path)
    assert expected is None or actual==expected,path
    assert str(path) not in refs or refs[str(path)]==actual,path
    refs[str(path)]=actual
    return path
def read(path,expected=None):return json.loads(checked(path,expected).read_text())

closure=read(RAW/'closure.json')
assert closure['actual_recursive_empty'] and closure['service_gone']
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
evaluation=read(RAW/'full_w0_evaluation.json')
assert evaluation['full_audit_pass'] and evaluation['n_plan']==evaluation['n_v1_contract_complete']==4000
assert evaluation['n_failed']==0 and evaluation['native_output_tokens']==458224
for path,digest in evaluation['source_sha256'].items():checked(path,digest)
audit=read(RAW/'http_audit.json')
assert audit['passed'] and audit['n_native_contract_complete']==4000
for path,digest in audit['source_sha256'].items():checked(path,digest)
for path,record in read(RAW/'source_manifest.json').items():
    checked(path,record['sha256']);checked(record['snapshot'],record['sha256'])
prereg=read(RAW/'preregistration.json')
for record in prereg['references'].values():checked(record['path'],record['sha256'])

previous=read(MAIN/'paper_results/ieee_tc/main_comparison/d454_7b_w0/comparison.json',
    'e8246c0203202f8d1e50adeac85a6569d134ea95729627da7a6a1df12b6c38ce')
latest=read(MAIN/'paper_results/ieee_tc/p2_backend/d476_full_w0/matched_comparison.json')
for record in previous['source_refs']+latest['refs']:
    checked(record['path'],record['sha256'])
assert latest['matched_contract_sha256']==previous['matched_contract_sha256']
assert latest['reference']==previous['reference']
assert latest['previous_six_system_results']==previous['results']
assert prereg['references']['metric_protocol']['sha256']==previous['metric_protocol_sha256']
assert prereg['references']['single_run_amendment']['sha256']==previous['single_run_amendment_sha256']
assert prereg['references']['slo_eval']['sha256']==previous['common_slo_sha256']
launch=read(RAW/'launch_gate.json')
assert launch['pass'] and launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert launch['preflight']['policy']==previous['common_resource_policy']
context=launch['external_replay']
assert context['replay_t0_s']-context['deployment_notice_s']==previous['preparation_lead_s']==60
cfg=read(RAW/'http_7b_4000.json',context['config_sha256'])
assert cfg['generation_contract']=='fixed_length_greedy_v1'
plan=FrozenReplayPlan.load(cfg['trace'])
assert plan.identity()==context['plan']==prereg['plan_identity']
assert {k:v for k,v in plan.identity().items() if k!='source_path'}==previous['common_input']
index=read(cfg['pool_index'],previous['pool_index_sha256'])
content={a['id']:sha256(json.dumps(sorted(a['files'],key=lambda f:f['path']),
    sort_keys=True,separators=(',',':')).encode()).hexdigest() for a in index['artifacts']}
review=read(PRIME/'single_run_review.json')
prime_source=checked(review['source'],review['source_sha256'])
prime_launch=read(prime_source.parent/'launch.json')
prime=matched_controller_rows(prime_source,'tc_ieee_full',content)
for row in prime.values():
    row['arrival_offset_s']=row['arrival']-prime_launch['external_replay']['replay_t0_s']

contracts={};outputs={};native={}
with checked(RAW/'launch_gate.launch/replay.jsonl').open() as stream:
    for line in stream:
        row=json.loads(line)
        target={'request_contract':contracts,'http_response':outputs,'http_raw_response':native}.get(row['event'])
        if target is not None:
            assert row['request_id'] not in target
            target[row['request_id']]=row
order=[entry.request_id for entry in plan.entries]
assert len(order)==4000 and set(contracts)==set(outputs)==set(native)==set(prime)==set(order)
keys=('request_id','source_item_sha256','adapter_id','target_tokens',
    'canonical_prompt_sha256','native_prompt_token_ids_sha256','native_prompt_tokens',
    'artifact_content_sha256','generation_contract')
joined=[]
for entry in plan.entries:
    rid=entry.request_id;c=contracts[rid];out=outputs[rid]
    n=native[rid]['body']['metrics']['ieee_tc']
    assert c['native_backend']=='hydraserve' and out['response']['protocol_valid']
    assert c['source_item_sha256']==entry.source_sha256
    assert c['artifact_content_sha256']==content[c['adapter_id']]
    assert n['native_output_tokens']==c['target_tokens']
    row={k:c[k] for k in keys if k in c}
    row.update(native_prompt_tokens=len(n['native_prompt_token_ids']),
        generation_contract=cfg['generation_contract'],
        arrival_offset_s=out['planned_arrival_s']-context['replay_t0_s'])
    assert abs(row['arrival_offset_s']-entry.offset_s)<=1e-6
    matched_request_contract(row,prime[rid])
    joined.append({k:row[k] for k in keys})
contract_sha=sha256(json.dumps(joined,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert contract_sha==previous['matched_contract_sha256']

# Translate exact Type-1 field names only; no numerical change or recomputation
# from rounded display values. Full numerical audit has already been performed.
metrics={name:{('p95_type1' if k=='p95' else 'p99_type1' if k=='p99' else
    'p50_type1' if k=='p50' else k):v for k,v in value.items()}
    for name,value in evaluation['metrics'].items()}
hydra=dict(counts=dict(N=4000,native_contract=4000,joint_pass=evaluation['n_joint']),
    observed_protocol_feasible=evaluation['observed_w0_g1_feasible'],
    joint_slo=evaluation['joint_slo'],physical_gpu_seconds=evaluation['physical_gpu_seconds'],
    gpu_seconds_per_protocol_valid_request=evaluation['gpu_seconds_per_v1_contract_request'],
    window_gpu_seconds=audit['physical']['window_gpu_seconds'],metrics=metrics,
    raw_n_correct=None,independent_numerical_proof=False,
    resource_configuration_optimum=False)
results=dict(previous['results'])
assert 'HydraServe' not in results and 'PrimeLoRA' in results
results['PrimeLoRA']=latest['candidate'];results['HydraServe']=hydra
assert set(results)=={'PrimeLoRA','ServerlessLLM','vLLM','S-LoRA','Loquetier','ElasticLocality','HydraServe'}
differences={name:matched_relative_observation(results['PrimeLoRA'],value)
    for name,value in results.items() if name!='PrimeLoRA'}
feasible=sorted((name for name,row in results.items() if row['observed_protocol_feasible']),
    key=lambda name:results[name]['physical_gpu_seconds'])
checked(RAW/'compare_full.py')
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
summary=dict(kind='d510_full_seven_system_known_w0_observation',
    results=results,PrimeLoRA_relative_observations=differences,
    observed_feasible_resource_order=feasible,matched_request_count=4000,
    matched_contract_sha256=contract_sha,native_tokens=458224,actual_unique_adapters=132,
    common_input=previous['common_input'],common_resource_policy=previous['common_resource_policy'],
    common_slo_sha256=previous['common_slo_sha256'],reference=previous['reference'],
    metric_protocol_sha256=previous['metric_protocol_sha256'],
    single_run_amendment_sha256=previous['single_run_amendment_sha256'],
    formal_m1_m2_complete=False,confidence_interval=None,
    independent_numerical_qualification=False,
    caveats=['Known-workload single-run observations; no significance or independent holdout claim.',
        'All failures and previous candidates retained; no baseline performance search.',
        'HydraServe native binding/accounting qualification is not independent numerical proof.',
        'D509 same-backend four changed sequences remain disclosed with unproved numerical cause.',
        'One physical host/four GPUs and limited weight diversity; no modern-cluster generalization.',
        'W0 is not W1/W2 or G2 closure; pipeline/consolidation coverage follows actual event audit.',
        'Different backends retain their actual entry stages; only user TTFT/TPOT and physical resource definitions are common.'],
    protected_verification=protected,source_refs=[dict(path=path,sha256=value) for path,value in refs.items()])
save(RAW/'full_seven_system_comparison.json',summary)
print(json.dumps(dict(passed=True,matched=4000,resource_order=feasible,
    differences=differences,source_count=len(refs)),indent=2))
