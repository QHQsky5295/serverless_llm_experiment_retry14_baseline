"""Flat post-release comparison source, reusing the audited D454/D476 join."""
import ijson
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=(RAW/'compare_full_v4.py').read_text()
prefix,separator,_=template.rpartition('\nexec(compile(source,')
assert separator
scope={'__name__':'__main__','__file__':str(RAW/'compare_full_v4.py')}
exec(compile(prefix,str(RAW/'comparison_source_preparation'),'exec'),scope)
source=scope['source'].replace("RAW/'comparison_v4_identity.json'","RAW/'comparison_final_identity.json'")
anchor="context=launch['external_replay']"
assert source.count(anchor)==1
source=source.replace(anchor,"""context=read(RAW/'launch_gate.launch/exec_receipt.json')['external_replay']
assert {key:context[key] for key in launch['external_replay']}==launch['external_replay']""")
source=source.replace("checked(RAW/'compare_full_v4.py')", "checked(RAW/'compare_full_v4.py');checked(RAW/'compare_final.py');checked(RAW/'comparison_executed_final.py')")
compile(source,str(RAW/'comparison_executed_final.py'),'exec')
with (RAW/'comparison_executed_final.py').open('x') as f:f.write(source)
exec(compile(source,str(RAW/'comparison_executed_final.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'compare_full.py')})
