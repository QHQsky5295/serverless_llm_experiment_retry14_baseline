"""Resolve one verified historical policy reference, not a hash-check bypass.

The old D454 record predates the user's D507 clarification. All measurement
and source-code references retain the original strict checks. No retry of GPU
work; preserve the first failed analysis and its exact-empty closure.
"""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW/'compare_full.py').read_text()
source=source.replace("RAW/'comparison_identity.json'","RAW/'comparison_v2_identity.json'")
anchor='def read(path,expected=None):return json.loads(checked(path,expected).read_text())'
assert source.count(anchor)==1
source=source.replace(anchor,anchor+'''

current_checked=checked
historical_references=[]
def checked(path,expected=None):
    path=Path(path)
    policy=MAIN/'docs/ieee_tc/BASELINE_EXECUTION_RULES_20261011.md'
    old_sha='1102651164744701a6c7f54783bdff96fef9f9b1c85fb063485f3a698b369571'
    if path==policy and expected==old_sha:
        current_checked(path,'82e853b845c3bd3fe5db5890589151a491ee15ccb6fdac57859c2ca170eb2812')
        commit='29e98482d0375181fb020f53747d29ecdb136336'
        relative=path.relative_to(MAIN).as_posix()
        payload=subprocess.check_output(['git','show',commit+':'+relative],cwd=MAIN)
        assert sha256(payload).hexdigest()==old_sha
        destination=RAW/'historical_baseline_execution_rules.md'
        if destination.exists():assert destination.read_bytes()==payload
        else:
            with destination.open('xb') as f:f.write(payload)
        historical_references.append(dict(original_path=str(path),historical_commit=commit,
            historical_sha256=old_sha,materialized_path=str(destination),
            current_sha256=refs[str(path)],reason='post-D454 user clarification; no measurement change'))
        return current_checked(destination,old_sha)
    return current_checked(path,expected)
''')
source=source.replace("checked(RAW/'compare_full.py')", "checked(RAW/'compare_full.py');checked(RAW/'compare_full_v2.py')")
source=source.replace("summary=dict(kind='d510_full_seven_system_known_w0_observation',",
    "summary=dict(kind='d510_full_seven_system_known_w0_observation',historical_references=historical_references,")
exec(compile(source,str(RAW/'compare_full_v2_executed'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'compare_full.py')})
