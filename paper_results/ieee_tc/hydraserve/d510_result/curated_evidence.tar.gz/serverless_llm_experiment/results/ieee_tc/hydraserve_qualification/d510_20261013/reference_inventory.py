"""Audit ALL old reference representations before changing the comparator."""
import json
from pathlib import Path
import sys
RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
with (RAW/'reference_inventory_identity.json').open('x') as f:
    json.dump(p.scope_identity(p.cg_path().name),f,indent=2)
sources=[(MAIN/'paper_results/ieee_tc/main_comparison/d454_7b_w0/comparison.json','source_refs'),
         (MAIN/'paper_results/ieee_tc/p2_backend/d476_full_w0/matched_comparison.json','refs')]
current={};differences=[];seen=set()
for source,key in sources:
    for record in json.loads(source.read_text())[key]:
        path=Path(record['path']);identity=(str(path),record['sha256'])
        if identity in seen:continue
        seen.add(identity)
        if str(path) not in current:current[str(path)]=p.digest(path) if path.is_file() else None
        if current[str(path)]!=record['sha256']:
            differences.append(dict(path=str(path),expected_sha256=record['sha256'],
                current_sha256=current[str(path)],gzip_present=Path(str(path)+'.gz').is_file(),
                referring_comparison=str(source)))
result=dict(reference_count=len(seen),differences=differences)
with (RAW/'reference_inventory.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result,indent=2))
