"""Seal full closed result locally, reusing D499 archive/roundtrip mechanics."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tarfile
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2)
save(RAW/'result_curation_identity.json',p.scope_identity(p.cg_path().name))
audit=json.loads((RAW/'full_w0_evaluation.json').read_text())
comparison=json.loads((RAW/'full_seven_system_comparison.json').read_text())
assert audit['full_audit_pass'] and audit['n_v1_contract_complete']==4000 and audit['n_failed']==0
assert comparison['matched_request_count']==4000 and len(comparison['results'])==7
assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for name in ('audit_identity','comparison_identity','comparison_v2_identity',
    'comparison_v3_identity','reference_inventory_identity','comparison_v4_identity',
    'comparison_v5_identity','comparison_prepare_failure_identity','comparison_final_identity'):
    assert json.loads((RAW/(name+'_closure.json')).read_text())['actual_recursive_empty']
for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'];save(RAW/'result_protected_verification.json',protected)
native=[json.loads(x.read_text()) for x in (RAW/'platform').glob('d510-w*.native-request.json')]
assert len(native)==34 and all(x['env']['PP_SIZE']==x['env']['DEST_PP_SIZE']=='1'
    and x['env']['BATCH_SIZE']=='8' for x in native)
paths=[BASE/'docs/ieee_tc/D510_HYDRASERVE_FULL_W0_RESULT.md']
paths += [x for x in RAW.iterdir() if x.is_file() and not x.is_symlink()
    and x.name not in ('pull-auth.json','curation.log','result_curation.log')]
for child in ('overlays','executed_sources','platform','physical','remote_artifacts/receipts',
              'remote_artifacts/journals','adapter_views/.receipts'):
    paths += [x for x in (RAW/child).rglob('*') if x.is_file() and not x.is_symlink()]
paths += [RAW/'remote_artifacts/run_contract.json']
paths += [x for x in (RAW/'launch_gate.launch').iterdir() if x.is_file() and not x.is_symlink()]
template=(RAW.parent/'d499_20261013/checkpoint.py').read_text()
body=template[template.index('paths=sorted(set(paths))'):template.index('summary=dict(')]
body=body.replace("hydraserve/d499'","hydraserve/d510_result'").replace('generation_release_evidence.tar.gz','full_w0_evidence.tar.gz')
exec(compile(body,'reused_d499_archive_roundtrip','exec'))
summary=dict(checkpoint_verified=True,performance_result=False,full_w0_observation=True,
    audit=audit,comparison=comparison,source_manifest=manifest,
    archive_sha256=p.digest(archive),archive_bytes=archive.stat().st_size,
    protected_verification=protected,native_workers=34,all_native_pp1=True,
    next='PrimeLoRA optimization after completed full available baseline comparison')
save(dest/'full_summary.json',summary)
save(RAW/'result_curation_result.json',dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size,
    archive_sha256=p.digest(archive),summary_sha256=p.digest(dest/'full_summary.json')))
print(json.dumps(dict(passed=True,files=len(paths),archive_bytes=archive.stat().st_size,archive_sha256=p.digest(archive))))
