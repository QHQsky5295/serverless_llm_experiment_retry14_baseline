"""Record and close the exact empty scope of the pre-import analysis failure."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
unit='primelora-tc-aux-d5100000000000000000000000000017.scope'
identity=p.scope_identity(unit)
assert identity['invocation_id']=='50e7f5c9f8c8457c8c79a3058b41e04d'
group=Path(identity['path'])
assert not any(f.read_text().split() for f in (group/'cgroup.procs',*group.rglob('cgroup.procs')))
with (RAW/'comparison_prepare_failure_identity.json').open('x') as f:json.dump(identity,f,indent=2)
subprocess.run(['/usr/bin/python3','-B',str(RAW/'close_cpu.py'),
    'comparison_prepare_failure_identity.json'],check=True,timeout=15)
