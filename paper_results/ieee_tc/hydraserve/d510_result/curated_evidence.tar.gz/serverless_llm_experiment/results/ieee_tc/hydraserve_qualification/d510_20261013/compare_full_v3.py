"""Use retained lossless representation while enforcing original source SHA."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=(RAW/'compare_full_v2.py').read_text()
boundary=template.index('exec(compile(source,')
scope={'__name__':'__main__','__file__':str(RAW/'compare_full_v2.py')}
exec(compile(template[:boundary],str(RAW/'compare_v2_preparation'),'exec'),scope)
source=scope['source'].replace("RAW/'comparison_v2_identity.json'","RAW/'comparison_v3_identity.json'")
anchor='current_checked=checked'
assert source.count(anchor)==1
source=source.replace(anchor,'''import gzip
plain_checked=checked
compressed_references=[]
def representation_checked(path,expected=None):
    path=Path(path)
    if path.exists():return plain_checked(path,expected)
    # Missing evidence is not replaced by an arbitrary path or default value.
    # Only the existing gzip representation, with exact ORIGINAL decoded SHA,
    # is acceptable. Stream it; do not duplicate a multi-GiB outcome on disk.
    compressed=Path(str(path)+'.gz')
    assert expected is not None and compressed.is_file(),path
    digest=sha256();size=0
    with gzip.open(compressed,'rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block);size+=len(block)
    assert digest.hexdigest()==expected,path
    result=plain_checked(compressed)
    compressed_references.append(dict(original_path=str(path),original_sha256=expected,
        decompressed_bytes=size,retained_path=str(compressed),
        retained_sha256=refs[str(compressed)],method='gzip stream, exact original SHA'))
    return result
current_checked=representation_checked''')
source=source.replace("checked(RAW/'compare_full_v2.py')", "checked(RAW/'compare_full_v2.py');checked(RAW/'compare_full_v3.py')")
source=source.replace('historical_references=historical_references,',
    'historical_references=historical_references,compressed_references=compressed_references,')
exec(compile(source,str(RAW/'compare_full_v3_executed'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'compare_full.py')})
