"""Reuse existing explicit source/secrets/protected/smoke/remote-equality gate."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d495').replace('D480','D495')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index('else:\n    paths =',start)
source=source[:start]+'''    paths = ['HydraServe_project/runtime/isolated_platform.py',
        'HydraServe_project/runtime/native_delivery.py',
        'HydraServe_project/runtime/native_overlay_entry.py',
        'tests/test_ieee_tc_hydraserve_native_delivery.py',
        'tests/test_ieee_tc_hydraserve_isolated_platform.py',
        'docs/ieee_tc/D495_HYDRASERVE_NATIVE_DELIVERY.md',
        'paper_results/ieee_tc/hydraserve/d495/summary.json',
        'paper_results/ieee_tc/hydraserve/d495/native_delivery_evidence.tar.gz']
    remote, branch = 'origin','main'
    smoke = ['tests.test_ieee_tc_hydraserve_native_delivery',
             'tests.test_ieee_tc_hydraserve_isolated_platform',
             'tests.test_ieee_tc_hydraserve_platform_port',
             'tests.test_ieee_tc_hydraserve_stage_binding',
             'tests.test_ieee_tc_hydraserve_worker_binding',
             'tests.test_ieee_tc_hydraserve_layer_identity']
'''+source[end:]
source=source.replace('qualify HydraServe native platform injection seam on CPU',
                      'qualify native HydraServe backbone delivery and real LoRA-enabled app init')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup_reused.py')})
