"""D494 retained; requalify only with source-derived native LoRA token ceiling."""
from pathlib import Path
import json
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d494_20261013'
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
for name in ('native_body.py','launch.sh','close_audit.py'):
    with (RAW/name).open('x') as f:f.write((OLD/name).read_text().replace('d494','d495'))
source=(OLD/'prepare.py').read_text().replace('d494','d495')
with (RAW/'executed_prepare.py').open('x') as f:f.write(source)
exec(compile(source,str(RAW/'executed_prepare.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
