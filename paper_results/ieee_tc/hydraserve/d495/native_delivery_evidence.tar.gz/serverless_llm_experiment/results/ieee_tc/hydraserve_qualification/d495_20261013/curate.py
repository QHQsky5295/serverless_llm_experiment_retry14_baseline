"""D493 curation method: explicit evidence, round-trip SHA, protected seal."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d494_20261013'
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
assert json.loads((RAW/'result.json').read_text())['passed']
assert not json.loads((OLD/'result.json').read_text())['passed']
assert all(json.loads((x/'closure.json').read_text())['actual_recursive_empty'] for x in (OLD,RAW))
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
files=[]
names=('prepare.py','probe.py','native_body.py','launch.sh','launch.log','source_manifest.json',
    'probe_identity.json','preflight.json','image_identity.json','pause_adoption.json',
    'shm_capacity.json','provider_ready.json','result.json','commands.json',
    'launch_gate.json','close_audit.py','closure.json')
for root in (OLD,RAW):
    files += [root/name for name in names]
    files += sorted((root/'executed_sources').glob('*'))
    files += sorted(x for x in (root/'overlays').rglob('*') if x.is_file())
    files += [root/'metadata/partition.json',root/'launch_gate.launch/service.log',
              root/'launch_gate.launch/watchdog.stderr',root/'launch_gate.launch/exec_receipt.json']
    files += sorted((root/'platform').glob('*.command.json'))
    files += sorted((root/'platform').glob('*.ownership.json'))
    files += sorted((root/'platform').glob('*.native-request.json'))
    for command in (root/'platform').glob('*.command.json'):
        if json.loads(command.read_text())['args'][0]=='logs':
            stem=command.name.removesuffix('.command.json')
            files += [root/'platform'/(stem+s) for s in ('.stdout','.stderr')]
    for directory in (root/'platform').iterdir():
        if directory.is_dir():files += sorted(directory.glob('*.json'))
files += [RAW/'native_init_response.json',RAW/'native_model_registry.json',RAW/'curate.py',RAW/'backup.py']
files += [OLD/'upstream_config.py']
files += [BASE/name for name in ('HydraServe_project/runtime/isolated_platform.py',
    'HydraServe_project/runtime/native_delivery.py','HydraServe_project/runtime/native_overlay_entry.py',
    'tests/test_ieee_tc_hydraserve_native_delivery.py','tests/test_ieee_tc_hydraserve_isolated_platform.py',
    'docs/ieee_tc/D495_HYDRASERVE_NATIVE_DELIVERY.md')]
manifest={str(path):dict(sha256=p.digest(path),bytes=path.stat().st_size) for path in files}
assert len(files)==len(manifest)
assert all(v['bytes']<1024**2 for v in manifest.values())
dest=BASE/'paper_results/ieee_tc/hydraserve/d495';dest.mkdir()
archive=dest/'native_delivery_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as out:
    for path in files:out.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle.getmembers():
        assert sha256(bundle.extractfile(member).read()).hexdigest()==manifest['/home/qhq/'+member.name]['sha256']
summary=dict(checkpoint_verified=True,performance_result=False,native_app_init=True,
    request_lora_qualified=False,native_generation_qualified=False,
    previous_failure=json.loads((OLD/'result.json').read_text()),
    successful_init=json.loads((RAW/'result.json').read_text()),
    closures=[json.loads((r/'closure.json').read_text()) for r in (OLD,RAW)],
    protected_verification=protected,source_manifest=manifest,archive_sha256=p.digest(archive),
    next='Native Request/ChatEngine LoRA+fixed-output+native timing; startup control-socket lifetime; no performance claim')
save(dest/'summary.json',summary)
receipt=dict(passed=True,files=len(files),archive_sha256=p.digest(archive),summary_sha256=p.digest(dest/'summary.json'))
save(RAW/'curation_result.json',receipt)
print(json.dumps(receipt))
