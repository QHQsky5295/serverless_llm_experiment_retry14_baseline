# Initial CPU-only publication test failure (not a GPU experiment)

Before the successful 80-test suite, the first targeted 24-test invocation had
three errors in BoundRequest preparation/concurrent publication/view reuse.
All were PermissionError at staged.rename(destination), after the reused
materialize_metadata_view sealed the staging directory mode to 0555.
Moving across parents needs write permission for the directory's '..' update.
The fix unseals only the owned staging directory, renames it, then seals the
final view before publishing its receipt. No source artifact/weight changes.
Cancellation test additionally checks that the drained writer published a receipt.
The failed suite was streamed to the tool output, not a retained local log;
this note does not claim a captured full traceback or an executed GPU failure.
Failed scope d502...0001 was actually empty and closed; receipt cpu_closure_123.json.
