"""Two existing nonzero LoRAs through full original Scheduler cold start.

Not full workload, real-remote delivery, numerical equivalence or performance.
Actual controller, HTTP/TCP, resource manager, algorithm and model lifecycle.
"""
import asyncio
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import time
from HydraServe_project.runtime.controller_runtime import native_controller
from HydraServe_project.runtime.request_contract import BoundRequest,FrozenRequest,matches_worker_process

async def qualify(platform,raw,views):
    raw=Path(raw)
    def save(name,value):
        with (raw/name).open('x') as f:json.dump(value,f,indent=2)
    # Reuse the already-canonical original trace rows, not regenerated inputs.
    origin=raw.parent/'d498_20261013/existing_input_binding.json'
    inputs=json.loads(origin.read_text());rows=inputs['rows']
    save('existing_input_binding.json',dict(inputs,canonical_source=str(origin),canonical_source_sha=sha256(origin.read_bytes()).hexdigest()))
    registry=json.loads((raw/'lora_registry.json').read_text());bindings={r['adapter_id']:r for r in registry}
    result=dict(passed=False,actual_gpu_generation=True,performance_result=False,
                full_scheduler_path_exercised=True,remote_delivery_qualified=False,requests=[])
    manifest_sha=sha256((raw/'overlays/manifest.json').read_bytes()).hexdigest()
    for name in ('USE_CACHE','SLOW_EXPR'):assert os.getenv(name,'0')=='0'
    assert 'MAX_PP_SIZE' not in os.environ
    with native_controller(raw/'overlays',manifest_sha) as native:
        # Original ModelSet[0] Llama-2-7B test registration, renamed for the
        # existing local checkpoint; no new SLO/performance parameter search.
        info=tuple(json.loads((raw/'model_registration.json').read_text())['model_info'])
        scheduler=native.Scheduler(None,None,{'test':{'llama2_7b':info}},platform=platform)
        assert scheduler.alg is sys.modules['algs'].ours
        assert scheduler.resource_manager.rgpus==[[24]*4]
        assert not scheduler.models[0].instances and not platform.workers
        idle=None
        try:
            for row in rows:
                aid=row['adapter_id'];binding=bindings[aid]
                contract=FrozenRequest(row['request_id'],aid,binding['adapter_index'],binding['adapter_path'],
                    row['prompt'],tuple(row['input_token_ids']),row['target_tokens'])
                bound=BoundRequest(contract,artifact_preparer=views);submitted=time.perf_counter()
                try:
                    stream=await scheduler.process_request(contract.request_id,'llama2_7b/0',bound,stream=True)
                    # Native FastAPI StreamingResponse consumes its synchronous
                    # generator off the loop. Match that calling convention.
                    if idle is None:idle=asyncio.create_task(scheduler.check_instance_loop(30))
                    chunks=await asyncio.to_thread(list,stream)
                    completed=time.perf_counter()
                finally:
                    save(contract.request_id+'_native_events.json',dict(events=bound.events,terminal=bound.terminal,
                        native_process=bound.native_process,native_request_id=bound.native_request_id))
                assert bound.terminal and bound.events
                evidence=bound.artifact_evidence
                assert evidence and evidence['tc_artifact_cache_hit'] is False
                assert evidence['native_weight_bytes_copied']==0
                assert evidence['tc_artifact_transferred_bytes']>0
                assert submitted<=evidence['tc_artifact_resolve_started_s']<=evidence['native_view_completed_s']<=bound.events[0]['output_monotonic_s']
                save(contract.request_id+'_artifact_evidence.json',evidence)
                ids=[token for event in bound.events for token in event['delta_token_ids']]
                assert len(ids)==contract.target_tokens
                owners=[worker for worker in platform.workers.values() if matches_worker_process(
                    bound.native_process,worker.owner,json.loads((worker.output/'entry.json').read_text()),
                    Path('/proc/sys/kernel/random/boot_id').read_text().strip())]
                assert len(owners)==1
                owner=owners[0]
                assert owner.owner['start_ticks']==bound.native_process['start_ticks']
                assert os.readlink('/proc/self/ns/time')==os.readlink(f"/proc/{owner.owner['pid']}/ns/time")
                assert submitted<=bound.events[0]['output_monotonic_s']<=bound.events[-1]['output_monotonic_s']<=completed
                assert all(i.num_reqs==0 and i.num_coldstart_reqs==0 for i in scheduler.models[0].instances)
                result['requests'].append(dict(request_id=contract.request_id,adapter_id=aid,
                    prompt_sha256=contract.prompt_sha256,target_tokens=contract.target_tokens,actual_tokens=len(ids),
                    output_token_ids=ids,submitted_s=submitted,completed_s=completed,
                    first_native_output_s=bound.events[0]['output_monotonic_s'],
                    last_native_output_s=bound.events[-1]['output_monotonic_s'],
                    native_process=bound.native_process,worker_name=owner.name,
                    output_text_sha256=sha256(''.join(chunks[:-1]).encode()).hexdigest()))
                print(json.dumps(dict(request_id=contract.request_id,actual_tokens=len(ids),full_scheduler=True)),flush=True)
            instances=list(scheduler.models[0].instances)
            save('native_scheduler_after_requests.json',dict(algorithm=scheduler.alg.__name__,
                original_idle_grace_s=30,physical_inventory=platform.inventory(),
                resource_gpus=scheduler.resource_manager.rgpus,
                instances=[dict(id=i.id,pp_size=i.pp_size,inited=i.inited,num_reqs=i.num_reqs,
                    will_scale_down=i.will_scale_down,resource_usages=[vars(u) for u in i.resource_usages]) for i in instances],
                native_stats=vars(scheduler.models[0].model_stats)))
            # Observe original idle-deletion loop; do not manually release early.
            while any(not worker.removed for worker in platform.workers.values()):
                if idle.done():await idle
                await asyncio.sleep(.1)
            while scheduler.resource_manager.rgpus != [[24]*4]:await asyncio.sleep(.1)
            save('native_scheduler_idle_release.json',dict(passed=True,resource_gpus=scheduler.resource_manager.rgpus,
                worker_names=list(platform.workers),all_deleted=True,original_idle_grace_s=30))
            result['passed']=True
            result['remote_delivery_qualified']=True
            result['actual_native_idle_release']=True
        finally:
            tasks=list(scheduler.tasks)+([idle] if idle else [])
            for task in tasks:task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)
            for instance in scheduler.models[0].instances:
                if instance.inited:
                    instance.chat_engine.client.close()
                    await instance.chat_engine.client_async.close()
            conn=sys.modules['utils'].conn
            if conn is not None:await conn.close()
            save('generation_result.json',result)
    return result
