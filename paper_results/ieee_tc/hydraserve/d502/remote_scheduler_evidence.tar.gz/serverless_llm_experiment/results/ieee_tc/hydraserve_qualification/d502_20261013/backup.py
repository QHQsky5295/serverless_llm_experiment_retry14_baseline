"""Reuse explicit stage/checksum/protection/secrets/test/push gates."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d499_20261013/backup.py').read_text().replace('d499','d502').replace('D499','D502')
source=source.replace('HydraServe_project/runtime/shm_control.py','HydraServe_project/runtime/remote_artifacts.py')
source=source.replace('HydraServe_project/runtime/native_delivery.py','HydraServe_project/runtime/request_contract.py')
source=source.replace('tests/test_ieee_tc_hydraserve_shm_control.py','tests/test_ieee_tc_hydraserve_remote_artifacts.py')
source=source.replace('D502_HYDRASERVE_GENERATION_AND_RELEASE.md','D502_HYDRASERVE_REAL_REMOTE.md')
source=source.replace('generation_release_evidence.tar.gz','remote_scheduler_evidence.tar.gz')
source=source.replace("('shm_control','tokenizer_compat'", "('remote_artifacts','controller_runtime','shm_control','tokenizer_compat'")
source=source.replace('qualify native HydraServe generation and SHM release before worker deletion',
    'qualify request-driven real-remote LoRA through native HydraServe scheduler')
exec(compile(source,str(RAW/'backup_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup.py')})
