"""Reuse D501 actual native scheduler with common request-driven remote delivery."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import urllib.request
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d501_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
assert json.loads((OLD/'generation_result.json').read_text())['passed']
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
def put(name,data):
    with (RAW/name).open('x') as f:f.write(data)
sources={}
for name in ('scheduler','engine'):
    url='https://raw.githubusercontent.com/LLMServe/HydraServe/8ae605de354ccfa2e9095514cdb4a9e9c56aa56b/scripts/kubernetes/vllm/src/'+name+'.py'
    with urllib.request.urlopen(url,timeout=20) as r:data=r.read(200000)
    assert data==(BASE/'vendor_new_baselines/HydraServe_main_20260520/scripts/kubernetes/vllm/src'/f'{name}.py').read_bytes()
    put('official_'+name+'.py',data.decode())
    sources[name]=dict(url=url,sha256=sha256(data).hexdigest())
put('online_sources.json',json.dumps(sources,indent=2))
for name in ('model_registration.json','close_pause.py','close_audit.py'):
    put(name,(OLD/name).read_text().replace('d501','d502'))
registry=json.loads((OLD/'lora_registry.json').read_text())
for row in registry:row['adapter_path']=str(RAW/'adapter_views'/row['adapter_id'])
put('lora_registry.json',json.dumps(registry,indent=2))
cfg=json.loads((RAW.parent.parent/'serverless_qualification/d409_20261011/http_7b_100.json').read_text())
put('remote_input_config.json',json.dumps({k:cfg[k] for k in
    ('ingress_mode','pool_index','pool_index_sha256','remote_artifacts')},indent=2))
launch=(OLD/'launch.sh').read_text().replace('d501','d502')
launch=replace_one(launch,'exec systemd-run',
    'export PRIME_REMOTE_TOKEN="$(< /home/qhq/.config/primelora-tc-d75/artifact.token)"\nexec systemd-run')
put('launch.sh',launch)
remote=(RAW.parent.parent/'p2_backend_qualification/d476_20261012/start_remote.sh').read_text()
remote=remote.replace('p2_backend_qualification/d476_20261012','hydraserve_qualification/d502_20261013')
remote=remote.replace('d476_20261012_hostexecw0','d502_20261013_hydraremote').replace('d476-hostexecw0','d502-hydraremote')
put('start_remote.sh',remote)
body=(OLD/'native_body.py').read_text().replace('d501','d502')
start=body.index('    readonly += [Path(row["adapter_path"])')
end=body.index('    mounts=[',start)
body=body[:start]+'''    # Common remote downloader runs in the service, never the replay client.
    support_spec=importlib.util.spec_from_file_location('tc_prepare_shared',BASE/'scripts/prepare_ieee_tc_serverless_stack.py')
    support=importlib.util.module_from_spec(support_spec);support_spec.loader.exec_module(support)
    cfg=json.loads((RAW/'remote_input_config.json').read_text())
    remote_config,remote_paths=support.prepare_remote_artifacts(cfg,RAW,str(group).removeprefix('/sys/fs/cgroup'))
    measure_spec=importlib.util.spec_from_file_location('tc_remote_shared',BASE/'scripts/ieee_tc_serverless_measurement.py')
    measure=importlib.util.module_from_spec(measure_spec);measure_spec.loader.exec_module(measure)
    from HydraServe_project.runtime.remote_artifacts import NativeArtifactViews
    views=NativeArtifactViews(measure.PublishedArtifactResolver(remote_config),RAW/'adapter_views')
    assert len(remote_paths)==500 and not list((Path(remote_config['cache_dir'])/'objects').iterdir())
    readonly += [views.root,Path(remote_config['cache_dir'])/'objects']
'''+body[end:]
body=replace_one(body,'generation=await module.qualify(platform,RAW)','generation=await module.qualify(platform,RAW,views)')
body=body.replace("qualification_scope='full original Scheduler cold start, two existing LoRA bindings, idle release; not numerical/remote/performance'",
    "remote_delivery_qualified=True,qualification_scope='two request-driven real-remote existing LoRAs through native Scheduler; not numerical/full workload/performance'")
put('native_body.py',body)
witness=(OLD/'request_witness.py').read_text().replace('d501','d502')
witness=replace_one(witness,'async def qualify(platform,raw):','async def qualify(platform,raw,views):')
witness=replace_one(witness,'bound=BoundRequest(contract);submitted=time.perf_counter()',
    'bound=BoundRequest(contract,artifact_preparer=views);submitted=time.perf_counter()')
witness=replace_one(witness,"assert bound.terminal and bound.events",'''assert bound.terminal and bound.events
                evidence=bound.artifact_evidence
                assert evidence and evidence['tc_artifact_cache_hit'] is False
                assert evidence['native_weight_bytes_copied']==0
                assert evidence['tc_artifact_transferred_bytes']>0
                assert submitted<=evidence['tc_artifact_resolve_started_s']<=evidence['native_view_completed_s']<=bound.events[0]['output_monotonic_s']
                save(contract.request_id+'_artifact_evidence.json',evidence)''')
witness=replace_one(witness,"result['passed']=True", "result['passed']=True\n            result['remote_delivery_qualified']=True")
put('request_witness.py',witness)
template=(OLD/'executed_prepare.py').read_text().replace('d501','d502')
template=replace_one(template,"paths=[RAW/'close_pause.py',", "paths=[BASE/'scripts/prepare_ieee_tc_serverless_stack.py',BASE/'scripts/ieee_tc_serverless_measurement.py',RAW/'remote_input_config.json',RAW/'close_pause.py',")
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
