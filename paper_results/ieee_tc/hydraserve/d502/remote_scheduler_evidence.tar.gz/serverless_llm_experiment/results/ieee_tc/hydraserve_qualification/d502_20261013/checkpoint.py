"""Reuse D499 append-only tar/protected-asset curation for the D502 remote witness."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d499_20261013/checkpoint.py').read_text()
start=source.index('generations=[]')
end=source.index('protected=p.verify_seal',start)
source=source[:start]+'''assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((RAW/'result.json').read_text())['passed']
generation=json.loads((RAW/'generation_result.json').read_text())
assert generation['passed'] and generation['remote_delivery_qualified'] and len(generation['requests'])==2
assert not generation['performance_result']
assert 'Ran 80 tests' in (RAW/'cpu_tests.log').read_text() and '\\nOK\\n' in (RAW/'cpu_tests.log').read_text()
for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
    assert p.digest(Path(record['snapshot']))==record['sha256']
    assert p.digest(Path(path))==record['sha256']
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
transfers=[json.loads(line) for line in (RAW/'remote_transfers.jsonl').read_text().splitlines()]
assert len(transfers)==2
prior=json.loads((RAW.parent/'d501_20261013/generation_result.json').read_text())
audit=[]
for row,old in zip(generation['requests'],prior['requests']):
    assert row['actual_tokens']==row['target_tokens']
    evidence=json.loads((RAW/(row['request_id']+'_artifact_evidence.json')).read_text())
    receipt=RAW/'remote_artifacts/receipts'/(row['adapter_id']+'.json')
    assert p.digest(receipt)==evidence['tc_artifact_receipt_sha256']
    matched=[t for t in transfers if t['transfer_id']==evidence['tc_artifact_transfer_id']]
    assert len(matched)==1
    transfer=matched[0]
    assert transfer['artifact_id']==row['adapter_id'] and transfer['outcome']=='sent'
    assert transfer['pack_performed'] is False and transfer['temporary_created'] is False
    assert transfer['bytes_written']==evidence['tc_artifact_transferred_bytes']
    assert evidence['tc_artifact_cache_hit'] is False and evidence['native_weight_bytes_copied']==0
    metadata=json.loads((RAW/'adapter_views/.receipts'/(row['adapter_id']+'.json')).read_text())
    previous=json.loads((RAW.parent/'d501_20261013/tokenizer_views.json').read_text())
    # Immutable tokenizer hashes were already qualified across the complete trace.
    prior_views=previous if isinstance(previous,list) else previous['views']
    expected=next(v for v in prior_views if Path(v['source']).name==row['adapter_id'])
    assert metadata['source_tokenizer_sha256']==expected['source_tokenizer_sha256']
    assert metadata['delivered_tokenizer_sha256']==expected['delivered_tokenizer_sha256']
    audit.append(dict(request_id=row['request_id'],adapter_id=row['adapter_id'],
        actual_tokens=row['actual_tokens'],wire_bytes=transfer['bytes_written'],
        remote_pack_performed=False,content_verified=json.loads(receipt.read_text())['evidence']['content_verified'],
        output_ids_equal_d501=row['output_token_ids']==old['output_token_ids']))
save(RAW/'remote_binding_audit.json',audit)
'''+source[end:]
start=source.index('paths=[BASE/name')
end=source.index('paths=sorted(set(paths))',start)
source=source[:start]+'''paths=[BASE/name for name in ('HydraServe_project/runtime/remote_artifacts.py',
    'HydraServe_project/runtime/request_contract.py',
    'tests/test_ieee_tc_hydraserve_remote_artifacts.py',
    'docs/ieee_tc/D502_HYDRASERVE_REAL_REMOTE.md')]
paths += [x for x in RAW.iterdir() if x.is_file() and not x.is_symlink()
          and x.name not in ('pull-auth.json','curation.log')]
for child in ('overlays','executed_sources','platform','remote_artifacts/receipts',
              'remote_artifacts/journals','adapter_views/.receipts'):
    paths += [x for x in (RAW/child).rglob('*') if x.is_file() and not x.is_symlink()]
paths += [RAW/'remote_artifacts/run_contract.json']
paths += [RAW/'launch_gate.launch'/x for x in ('watchdog.jsonl','watchdog.stderr','exec_receipt.json','service.log')]
'''+source[end:]
source=source.replace("hydraserve/d499'", "hydraserve/d502'").replace('generation_release_evidence.tar.gz','remote_scheduler_evidence.tar.gz')
start=source.index('summary=dict(')
end=source.index("save(dest/'summary.json'",start)
source=source[:start]+'''summary=dict(checkpoint_verified=True,performance_result=False,cpu_tests_passed=80,
    full_native_scheduler_exercised=True,remote_delivery_qualified_on_existing_adapters=2,
    actual_native_idle_release=True,request_evidence=audit,
    numerical_lora_equivalence_qualified=False,pipeline_and_consolidation_qualified=False,
    copied_view_weight_bytes=0,protected_verification=protected,source_manifest=manifest,
    archive_sha256=p.digest(archive),next='Common HTTP/open-loop/native numerical qualification then100/500-ID/1000/4000; no new model/trace/pool')
'''+source[end:]
source=source.replace('cpu_tests=70','cpu_tests=80')
exec(compile(source,str(RAW/'checkpoint_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'checkpoint.py')})
