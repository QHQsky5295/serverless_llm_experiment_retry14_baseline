"""Reuse exact-identity recursive-empty auxiliary closure."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d496_20261013/close_scope.py').read_text().replace('d496','d502')
exec(compile(source,str(RAW/'close_scope.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'close_scope.py')})
