"""Bounded CPU-only regression for the software-acquisition revision."""
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
def save(name, value):
    with (ROOT/name).open('x') as out:
        json.dump(value, out, indent=2)
save('test_identity.json', p.scope_identity(p.cg_path().name))
start = time.monotonic()
with (ROOT/'test.log').open('x') as log:
    rc = subprocess.run([sys.executable, '-B', str(ROOT/'test_retry_budget.py')],
                        stdout=log, stderr=subprocess.STDOUT, timeout=15).returncode
save('test_result.json', dict(passed=rc == 0, returncode=rc, elapsed_s=time.monotonic()-start,
     source_sha256={name:p.digest(ROOT/name) for name in
                    ('retry_budget.py','resume_image_blobs_v3.py','test_retry_budget.py')},
     network_used=False, model_started=False, performance_result=False))
print((ROOT/'test.log').read_text())
sys.exit(rc)
