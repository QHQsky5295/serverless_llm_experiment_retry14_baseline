"""Reuse exact-identity/actual-recursive-empty closure with a new run directory."""
from pathlib import Path
root = Path(__file__).resolve().parent
template = root.parent/'d481_20261013/close.py'
source = template.read_text().replace("'probe','probe_retry','test','curation','backup_baseline','backup_main'",
                                    "'test','resume','build_audit','packages','curation','backup_baseline','backup_main'")
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(root/'close_reused.py')})
