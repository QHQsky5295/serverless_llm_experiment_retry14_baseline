"""No network or model; exercise every failure boundary in the finite retry."""
import ssl
import unittest
import urllib.error
from retry_budget import RetryBudget
from resume_image_blobs_v3 import render


class RetryTests(unittest.TestCase):
    def make(self, limit=8, safety=lambda: None):
        self.records, self.sleeps = [], []
        return RetryBudget(safety=safety, sleep=self.sleeps.append,
                           report=self.records.append, limit=limit)

    def test_auth_tls_retried_without_body_needed(self):
        budget = self.make()
        errors = [urllib.error.URLError(ssl.SSLEOFError(8, 'test')), 'ok']
        def operation():
            value = errors.pop(0)
            if isinstance(value, Exception):
                raise value
            return value
        self.assertEqual(budget.call(operation, phase='auth_or_prefix_probe'), 'ok')
        self.assertEqual(budget.failures, 1)
        self.assertEqual(self.sleeps, [2])

    def test_one_shared_budget_across_phases(self):
        budget = self.make(limit=2)
        budget.failure(TimeoutError(), phase='auth_or_prefix_probe')
        with self.assertRaises(EOFError):
            budget.failure(EOFError(), phase='auth_or_range_body')
        self.assertEqual(budget.failures, 2)
        self.assertEqual(len(self.sleeps), 1)

    def test_success_does_not_reset_failure_count(self):
        budget = self.make()
        budget.failure(TimeoutError(), phase='probe')
        self.assertEqual(budget.call(lambda: 42, phase='body'), 42)
        self.assertEqual(budget.failures, 1)

    def test_http_rejection_not_retried(self):
        budget = self.make()
        with self.assertRaises(urllib.error.HTTPError):
            budget.failure(urllib.error.HTTPError('private', 403, 'no', {}, None), phase='auth')
        self.assertFalse(self.sleeps)
        self.assertNotIn('private', str(self.records))

    def test_certificate_failure_not_retried(self):
        budget = self.make()
        with self.assertRaises(urllib.error.URLError):
            budget.failure(urllib.error.URLError(ssl.SSLCertVerificationError()), phase='auth')
        self.assertFalse(self.sleeps)

    def test_safety_and_invariant_errors_escape(self):
        def abort():
            raise TimeoutError('wall_guard')
        budget = self.make(safety=abort)
        with self.assertRaises(TimeoutError):
            budget.call(lambda: 42, phase='body')
        self.assertFalse(self.records)
        budget = self.make()
        with self.assertRaises(AssertionError):
            budget.call(lambda: self.fail('bad range'), phase='probe')
        self.assertFalse(self.records)

    def test_source_revision_preserves_integrity_and_safety(self):
        source = render()
        self.assertIn("assert 'sha256:'+p.digest(path) == blob", source)
        self.assertIn("assert path.stat().st_size == size", source)
        self.assertIn("path.open('ab', buffering=0)", source)
        self.assertIn("wall_limit_s=10800", source)
        self.assertIn("max_failures_per_blob=8", source)
        self.assertIn("budget.call(read_probe", source)
        self.assertIn("budget.failure(exc, phase='auth_or_range_body')", source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
