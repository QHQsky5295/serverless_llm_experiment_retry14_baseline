"""Fetch only two exact official build dependencies; no install/build/model.

Uses the existing Python3.10 interpreter and pip, exact PyPI metadata already
saved by source_build_audit. GPU, package versions and baseline policy unchanged.
"""
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

def save(name,value):
    with (ROOT/name).open('x') as out:
        json.dump(value,out,indent=2)

identity=p.scope_identity(p.cg_path().name)
save('packages_identity.json',identity)
assert os.sched_getaffinity(0)=={2,3,26,27}
assert json.loads((ROOT/'resume_closure.json').read_text())['passed']
gate=p.preflight([ROOT],predicted_growth=4*p.GIB)
save('packages_preflight.json',gate)
assert gate['preflight_pass'],gate['issues']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
audit=json.loads((ROOT/'source_build_audit.json').read_text())
destination=ROOT/'build_wheels'
destination.mkdir(mode=0o700)
env=dict(os.environ,PIP_CONFIG_FILE=os.devnull,PIP_DISABLE_PIP_VERSION_CHECK='1',
         CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1')
command=['/home/qhq/anaconda3/envs/hydraserve_py_20260520/bin/python','-B','-m','pip',
         'download','--no-deps','--no-cache-dir','--only-binary=:all:',
         '--index-url=https://pypi.org/simple','--dest='+str(destination),
         'torch==2.3.0','xformers==0.0.26.post1']
result=dict(passed=False,kind='official_source_build_dependency_acquisition',
            environment_modified=False,model_started=False,performance_result=False)
started=time.monotonic()
proc=None
try:
    with (ROOT/'packages_pip.log').open('x') as log:
        proc=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        owner=p.gpu_process_identity(proc.pid)
        assert owner and Path(identity['path']) in (Path(owner['cgroup']),*Path(owner['cgroup']).parents)
        save('packages_worker.json',owner)
        while proc.poll() is None:
            available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                               if x.startswith('MemAvailable:')))*1024
            assert available>=16*p.GIB and shutil.disk_usage(ROOT).free>=100*p.GIB
            if time.monotonic()-started>1800:
                raise TimeoutError('package_download_wall_guard')
            time.sleep(1)
        assert proc.returncode==0,proc.returncode
    verified=[]
    for package in ('torch','xformers'):
        wheel=audit['public_metadata'][package]['wheels']
        assert len(wheel)==1
        expected=wheel[0]
        path=destination/expected['filename']
        assert path.stat().st_size==expected['bytes']
        assert p.digest(path)==expected['sha256']
        verified.append(dict(path=str(path),bytes=path.stat().st_size,sha256=expected['sha256']))
    result.update(passed=True,verified=verified)
except Exception as exc:
    result.update(error_type=type(exc).__name__)
finally:
    if proc is not None and proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            proc.wait(timeout=5)
    result.update(returncode=None if proc is None else proc.returncode,
                  elapsed_s=time.monotonic()-started,disk_free=shutil.disk_usage(ROOT).free)
    save('packages_result.json',result)
    print(json.dumps(result),flush=True)
sys.exit(0 if result['passed'] else 1)
