"""Narrow revision of D479 acquisition; original evidence stays immutable.

D479's body timeout led to authorize() inside an except block, outside its
retry boundary. The auth TLS error aborted after only one recorded body failure.
All network phases now consume one finite budget per blob. Existing range,
inode, content length, full SHA, safe redirect, and host protection checks remain.
"""
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent
TEMPLATE = ROOT.parent / "d479_20261012/resume_image_blobs_v2.py"


def render():
    source = TEMPLATE.read_text()
    edits = [
        ("import urllib.request\n", "import urllib.request\nfrom retry_budget import RetryBudget, NETWORK_ERRORS\n"),
        ("assert json.loads((PREVIOUS/'resume_closure.json').read_text())['passed']\n"
         "prior = json.loads((PREVIOUS/'resume_attempt/result.json').read_text())\n"
         "assert not prior['passed'] and prior['error_type'] == 'TimeoutError'\n",
         "assert json.loads((RAW.parent/'d479_20261012/resume_closure.json').read_text())['passed']\n"
         "prior = json.loads((RAW.parent/'d479_20261012/resume_attempt/result.json').read_text())\n"
         "assert not prior['passed'] and prior['error_type'] == 'URLError' and prior['reason_type'] == 'SSLEOFError'\n"),
        ("def get(blob, start, stop):\n    return opener.open(urllib.request.Request(base+'blobs/'+blob, headers={\n"
         "        'Authorization':'Bearer '+token, 'Range':f'bytes={start}-{stop}'}), timeout=30)\n",
         "def get(blob, start, stop):\n"
         "    global token\n"
         "    if token is None:\n"
         "        authorize()\n"
         "    try:\n"
         "        return opener.open(urllib.request.Request(base+'blobs/'+blob, headers={\n"
         "            'Authorization':'Bearer '+token, 'Range':f'bytes={start}-{stop}'}), timeout=30)\n"
         "    except urllib.error.HTTPError as exc:\n"
         "        if exc.code == 401:\n"
         "            token = None\n"
         "        raise\n"),
        ("try:\n    authorize()\n    layers =", "try:\n    layers ="),
        ("        probes = []\n", "        probes = []\n"
         "        def report_failure(failure):\n"
         "            failure = dict(digest=blob, **failure)\n"
         "            result['attempt_failures'].append(failure)\n"
         "            print(json.dumps(failure), flush=True)\n"
         "        budget = RetryBudget(safety=safety, sleep=time.sleep, report=report_failure,\n"
         "                             limit=result['max_failures_per_blob'])\n"),
        ("            with get(blob, offset, offset+4095) as response:\n"
         "                assert response.status == 206\n"
         "                assert response.headers.get('Content-Range') == f'bytes {offset}-{offset+4095}/{size}'\n"
         "                data = response.read(4097)\n",
         "            def read_probe():\n"
         "                with get(blob, offset, offset+4095) as response:\n"
         "                    assert response.status == 206\n"
         "                    assert response.headers.get('Content-Range') == f'bytes {offset}-{offset+4095}/{size}'\n"
         "                    return response.read(4097)\n"
         "            data = budget.call(read_probe, phase='auth_or_prefix_probe')\n"),
        ("        failures = 0\n", ""),
        ("            except (TimeoutError, ConnectionError, EOFError, urllib.error.URLError) as exc:\n"
         "                safety()\n"
         "                failures += 1\n"
         "                failure = dict(digest=blob, bytes=offset, failure_index=failures, **error_summary(exc))\n"
         "                result['attempt_failures'].append(failure)\n"
         "                print(json.dumps(failure), flush=True)\n"
         "                # Byte/inode mismatch is never repaired by truncate/re-download.\n"
         "                assert path.stat().st_ino == stamp.st_ino and path.stat().st_size == offset\n"
         "                if failures >= result['max_failures_per_blob']:\n"
         "                    raise\n"
         "                time.sleep(min(2**failures, 30))\n"
         "                authorize()\n",
         "            except NETWORK_ERRORS as exc:\n"
         "                # Persisted bytes are authoritative. Never rewind/truncate.\n"
         "                assert path.stat().st_ino == stamp.st_ino and path.stat().st_size == offset\n"
         "                budget.failure(exc, phase='auth_or_range_body')\n"),
    ]
    for old, new in edits:
        if source.count(old) != 1:
            raise ValueError("unexpected D479 source drift")
        source = source.replace(old, new, 1)
    compile(source, str(ROOT / "resume_reused.py"), "exec")
    return source


if __name__ == "__main__":
    import json
    source = render()
    identities = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                  for path in (TEMPLATE, Path(__file__), ROOT / "retry_budget.py")}
    with (ROOT / "resume_source_identity.json").open("x") as out:
        json.dump(dict(sources=identities,
                       executed_sha256=hashlib.sha256(source.encode()).hexdigest()), out, indent=2)
    exec(compile(source, str(ROOT / "resume_reused.py"), "exec"),
         {"__name__": "__main__", "__file__": str(ROOT / "resume_reused.py")})
