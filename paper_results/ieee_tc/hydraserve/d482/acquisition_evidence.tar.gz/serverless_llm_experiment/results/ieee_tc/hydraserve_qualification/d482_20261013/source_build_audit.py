"""Read-only source-build prerequisite audit; no installs, models or compilation.

Official Dockerfile requires CUDA12.4 and torch2.3.0; inventory candidate cached
toolchain and exact public package metadata, never substitute another backend.
"""
import email
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
BASE = Path('/home/qhq/serverless_llm_baselines')
NATIVE = BASE/'vendor_new_baselines/HydraServe_main_20260520'
ENV = Path('/home/qhq/anaconda3/envs/slinfer_official_20260612')
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (ROOT/name).open('x') as out:
        json.dump(value,out,indent=2)

save('build_audit_identity.json',p.scope_identity(p.cg_path().name))
start=time.monotonic()
assert json.loads((ROOT/'resume_closure.json').read_text())['passed']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=NATIVE)
source_names=['scripts/image/Dockerfile','requirements-cuda.txt','requirements-build.txt',
              'requirements-common.txt','scripts/image/fastload/CMakeLists.txt','setup.py']
sources={name:dict(sha256=p.digest(NATIVE/name),bytes=(NATIVE/name).stat().st_size)
         for name in source_names}
names=['bin/nvcc','bin/ptxas','include/cuda.h','include/cuda_runtime.h',
       'nvvm/libdevice/libdevice.10.bc','lib/libcudart.so.12.4.127']
toolchain={name:dict(exists=(ENV/name).is_file(),resolved=str((ENV/name).resolve()),
                    bytes=(ENV/name).stat().st_size if (ENV/name).is_file() else None)
           for name in names}
version=subprocess.check_output([str(ENV/'bin/nvcc'),'--version'],text=True,timeout=5)
installed={}
for path in sorted((ENV/'lib/python3.11/site-packages').glob('*.dist-info/METADATA')):
    if not (path.parent.name.startswith(('torch-','nvidia_','xformers-','triton-'))):
        continue
    meta=email.message_from_bytes(path.read_bytes())
    installed[meta['Name']]=dict(version=meta['Version'],metadata_sha256=p.digest(path),
                               path=str(path),requires_dist=meta.get_all('Requires-Dist',[]))
public={}
for package, release in [('torch','2.3.0'),('xformers','0.0.26.post1')]:
    try:
        with urllib.request.urlopen(f'https://pypi.org/pypi/{package}/{release}/json',timeout=15) as r:
            raw=r.read(2*1024*1024)
            metadata=json.loads(raw)
        selected=[dict(filename=x['filename'],bytes=x['size'],sha256=x['digests']['sha256'],url=x['url'])
                  for x in metadata['urls'] if 'cp310-cp310' in x['filename']
                  and 'manylinux' in x['filename'] and 'x86_64' in x['filename']]
        public[package]=dict(version=release,metadata_sha256=hashlib.sha256(raw).hexdigest(),
                             wheels=selected,requires_dist=metadata['info']['requires_dist'])
    except Exception as exc:
        public[package]=dict(error_type=type(exc).__name__,
                             reason_type=type(getattr(exc,'reason',None)).__name__)
result=dict(kind='official_source_build_prerequisite_inventory',
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=NATIVE,text=True).strip(),
    source_manifest=sources,toolchain_root=str(ENV),toolchain_files=toolchain,nvcc_version=version,
    installed_packages=installed,public_metadata=public,source_build_qualified=False,
    environment_modified=False,package_installed=False,kernel_compiled=False,
    model_started=False,performance_result=False,elapsed_s=time.monotonic()-start)
save('source_build_audit.json',result)
print(json.dumps(dict(nvcc_version=version,toolchain_files_present=all(x['exists'] for x in toolchain.values()),
    installed_torch=installed.get('torch',{}).get('version'),
    public={k:dict(version=v.get('version'),wheel_count=len(v.get('wheels',[])),
                   bytes=sum(x['bytes'] for x in v.get('wheels',[])),error=v.get('error_type'))
            for k,v in public.items()},source_build_qualified=False)),flush=True)
