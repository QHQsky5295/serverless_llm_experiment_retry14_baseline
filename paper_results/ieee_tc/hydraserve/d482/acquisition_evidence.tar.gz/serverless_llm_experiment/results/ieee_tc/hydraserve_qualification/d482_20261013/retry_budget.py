"""One finite failure budget across registry auth, probe and body operations.

This affects software acquisition only, never an inference request or its timeout.
No exception text, URLs, auth response, token or environment is serialized.
"""
import http.client
import ssl
import urllib.error


NETWORK_ERRORS = (TimeoutError, ConnectionError, EOFError, urllib.error.URLError,
                  http.client.IncompleteRead, ssl.SSLError)


class RetryBudget:
    def __init__(self, *, safety, sleep, report, limit=8):
        if limit < 1:
            raise ValueError("positive finite retry limit required")
        self.safety, self.sleep, self.report = safety, sleep, report
        self.limit, self.failures = limit, 0

    def failure(self, exc, *, phase):
        self.safety()
        reason = getattr(exc, "reason", None)
        status = getattr(exc, "code", None)
        # Never turn a bad path, denied access, TLS identity failure, or corrupt
        # byte/header invariant into a retry. A 401 may renew the public token.
        retryable = isinstance(exc, NETWORK_ERRORS)
        if isinstance(exc, urllib.error.HTTPError):
            retryable = status in (401, 408, 429, 500, 502, 503, 504)
        if isinstance(exc, ssl.SSLCertVerificationError) or isinstance(
                reason, ssl.SSLCertVerificationError):
            retryable = False
        self.failures += 1
        self.report(dict(phase=phase, failure_index=self.failures,
                         retryable=retryable, error_type=type(exc).__name__,
                         reason_type=type(reason).__name__,
                         reason_errno=getattr(reason, "errno", None),
                         http_status=status))
        if not retryable or self.failures >= self.limit:
            raise exc
        delay = min(2 ** self.failures, 30)
        self.sleep(delay)
        self.safety()

    def call(self, operation, *, phase):
        while True:
            self.safety()
            try:
                return operation()
            except NETWORK_ERRORS as exc:
                self.failure(exc, phase=phase)
