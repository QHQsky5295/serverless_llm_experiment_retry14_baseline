"""Close only this qualification's private Podman namespace and captured scope."""
import json
import os
import re
import signal
import subprocess
import sys
import time
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
mode=sys.argv[1]
assert mode in ('direct','proxy','delegated','parent','affinity')
raw=BASE if mode=='direct' else BASE/('container_'+mode+'_attempt')
runtime=Path(json.loads((raw/'container_result.json').read_text())['runtime_directory'])
assert (raw/'container_result.json').is_file()
identity=json.loads((raw/'container_identity.json').read_text())
members=Path(identity['path'])/'cgroup.procs'
if members.exists():
    assert not members.read_text().split(), 'qualification still executing'
pausefile=runtime/'libpod/tmp/pause.pid'
receipt=dict(passed=False,mode=mode)
if pausefile.exists():
    assert pausefile.stat().st_uid==os.getuid()
    pid=int(pausefile.read_text().strip())
    proc=p.gpu_process_identity(pid)
    assert proc and proc['uid']==os.getuid()
    assert Path(f'/proc/{pid}/comm').read_text().strip()=='podman pause'
    group=Path(proc['cgroup'])
    assert re.fullmatch(r'podman-pause-[0-9]+\.scope',group.name)
    assert group.is_relative_to(Path('/sys/fs/cgroup/user.slice/user-1001.slice/user@1001.service'))
    # This private runtime was created exclusively by this recorded attempt.
    boot=next(int(line.split()[1]) for line in Path('/proc/stat').read_text().splitlines() if line.startswith('btime '))
    born=boot+proc['start_ticks']/os.sysconf('SC_CLK_TCK')
    assert abs(born-pausefile.stat().st_mtime)<5
    props=subprocess.check_output(['systemctl','--user','show',group.name,'-p','InvocationID','-p','ControlGroup'],text=True)
    own=dict(line.split('=',1) for line in props.splitlines())
    assert (Path('/sys/fs/cgroup')/own['ControlGroup'].lstrip('/'))==group
    assert p.owned_pids(group)==[{k:proc[k] for k in ('pid','start_ticks','cgroup','affinity')}]
    fd=os.pidfd_open(pid)
    try:
        assert p.gpu_process_identity(pid)==proc
        signal.pidfd_send_signal(fd,signal.SIGKILL)
    finally:
        os.close(fd)
    for _ in range(100):
        if not group.exists() or not (group/'cgroup.procs').read_text().split():
            break
        time.sleep(.02)
    if group.exists():
        assert not (group/'cgroup.procs').read_text().split()
        current=subprocess.check_output(['systemctl','--user','show',group.name,'-p','InvocationID','--value'],text=True).strip()
        assert current==own['InvocationID']
        subprocess.run(['systemctl','--user','stop',group.name],check=True)
    assert not group.exists()
    receipt['pause']=dict(identity=proc,unit=own,private_pidfile=str(pausefile),actual_released=True,
        caveat='Podman creates a separate pause scope; not proof of whole-service containment')
group=Path(identity['path'])
if group.exists():
    assert p.scope_still_owned(identity)
    entries={str(x):x.read_text().split() for x in group.rglob('cgroup.procs')}
    assert entries and not any(entries.values())
    receipt['resources']={k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
    subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
    assert not group.exists()
receipt.update(passed=True,identity=identity)
with (raw/'container_context_closure.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))


