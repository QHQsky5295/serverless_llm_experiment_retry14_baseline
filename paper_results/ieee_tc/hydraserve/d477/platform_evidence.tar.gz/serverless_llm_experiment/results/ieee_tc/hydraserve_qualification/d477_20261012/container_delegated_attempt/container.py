"""One isolated NVML container qualification; not HydraServe or model performance."""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW / name).open('x') as stream:
        json.dump(value, stream, indent=2)

identity = p.scope_identity(p.cg_path().name)
save('container_identity.json', identity)
group = Path(identity['path'])
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
assert (group / 'memory.swap.max').read_text().strip() == '0'
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
gate = p.preflight([RAW], predicted_growth=p.GIB)
save('container_preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
runtime = Path('/run/user/1001/primelora-hydra-d477-delegated')
runtime.mkdir(mode=0o700)
(RAW / 'empty_hooks').mkdir()
store = RAW.parent / 'container_proxy_attempt/container_storage'
supervisor = group / 'supervisor'
supervisor.mkdir()
(supervisor / 'cgroup.procs').write_text(str(os.getpid()))
(group / 'cgroup.subtree_control').write_text('+memory +pids')
assert {'memory', 'pids'} <= set((group / 'cgroup.subtree_control').read_text().split())
env = {key: os.environ[key] for key in ('PATH', 'HOME', 'USER', 'LOGNAME', 'LANG', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY',
        'http_proxy', 'https_proxy', 'all_proxy', 'no_proxy') if key in os.environ}
env.update(CONTAINERS_CONF=str(RAW / 'containers.conf'), XDG_RUNTIME_DIR=str(runtime), CUDA_VISIBLE_DEVICES='', REGISTRY_AUTH_FILE=str(RAW / 'pull-auth.json'))
base = ['podman', '--root', str(store), '--runroot', str(runtime / 'runroot'),
        '--storage-driver=vfs', '--cgroup-manager=cgroupfs', '--events-backend=file',
        '--runtime=/usr/bin/nvidia-container-runtime', '--hooks-dir', str(RAW / 'empty_hooks')]
commands = []
def call(tag, args, check=True, timeout=120):
    command = base + args
    start = time.monotonic()
    with (RAW / (tag + '.stdout')).open('x') as out, (RAW / (tag + '.stderr')).open('x') as err:
        result = subprocess.run(command, env=env, stdout=out, stderr=err, timeout=timeout)
    commands.append(dict(tag=tag, command=command, returncode=result.returncode, duration_s=time.monotonic()-start))
    print(json.dumps(commands[-1]), flush=True)
    if check:
        assert result.returncode == 0, tag
    return (RAW / (tag + '.stdout')).read_text()

container_id = None
result = dict(passed=False, evidence='NVML only; no CUDA tensor/model/Kubernetes qualification')
try:
    info = json.loads(call('info', ['info', '--format=json']))
    assert info['store']['graphRoot'] == str(store)
    save('contained_after_info.json', p.owned_pids(group))
    assert (RAW.parent / 'container_proxy_attempt/image_identity.json').is_file()
    image = json.loads(call('image', ['image', 'inspect', 'docker.io/library/ubuntu:22.04']))[0]
    assert image['Digest'] and image['Id']
    assert image['Id'] == json.loads((RAW.parent / 'container_proxy_attempt/image_identity.json').read_text())['Id']
    save('image_identity.json', {k: image.get(k) for k in ('Id','Digest','RepoDigests','Size','Architecture','Os')})
    uuid = subprocess.check_output(['nvidia-smi', '--id=0', '--query-gpu=uuid', '--format=csv,noheader'], text=True).strip()
    assert uuid.startswith('GPU-')
    save('selected_gpu.json', dict(uuid=uuid, index_at_launch=0))
    output = call('run', ['run', '--detach', '--name=primelora-hydra-d477-delegated-nvml',
        '--label=org.primelora.campaign=d477', '--pull=never', '--cgroups=enabled', '--cgroup-parent='+str(group).removeprefix('/sys/fs/cgroup'),
        '--memory=128m', '--memory-swap=128m', '--pids-limit=128',
        '--network=none', '--http-proxy=false', '--read-only', '--cap-drop=ALL',
        '--security-opt=no-new-privileges', '--security-opt=label=disable',
        '--env=NVIDIA_VISIBLE_DEVICES=nvidia.com/gpu='+uuid, '--timeout=30',
        image['Id'], '/bin/sh', '-c',
        'nvidia-smi -L && cat /proc/self/cgroup && sleep 15'])
    container_id = output.strip()
    assert len(container_id) == 64 and all(c in '0123456789abcdef' for c in container_id)
    state = json.loads(call('inspect_live', ['inspect', container_id]))[0]
    assert state['Config']['Labels']['org.primelora.campaign'] == 'd477'
    pid = state['State']['Pid']
    owner = p.gpu_process_identity(pid)
    save('container_process_identity.json', owner)
    assert owner and owner['uid'] == os.getuid()
    assert p.cg_path(str(pid)) == group or group in p.cg_path(str(pid)).parents
    assert set(os.sched_getaffinity(pid)) == {2, 3, 26, 27}
    wait = call('wait', ['wait', container_id], timeout=40)
    logs = call('logs', ['logs', container_id])
    assert wait.strip() == '0' and logs.count('UUID:') == 1 and uuid in logs
    result.update(passed=True, gpu_uuid=uuid, container_id=container_id, actual_worker_contained=True)
except Exception as exc:
    result['failure'] = type(exc).__name__ + ': ' + str(exc)
finally:
    # No project-wide or global prune: exact label-bound created container only.
    if container_id:
        state = json.loads(call('inspect_final', ['inspect', container_id]))[0]
        assert state['Config']['Labels']['org.primelora.campaign'] == 'd477'
        if state['State']['Running']:
            call('stop_owned', ['stop', '--time=5', container_id])
        call('remove_owned', ['rm', container_id])
    save('container_commands.json', commands)
    result['remaining_scope_members'] = p.owned_pids(group)
    result['disk_free_after'] = shutil.disk_usage(RAW).free
    result['runtime_directory'] = str(runtime)
    save('container_result.json', result)
    print(json.dumps(result), flush=True)
sys.exit(0 if result['passed'] else 1)


