"""Reuse the existing closed-evidence archiver before HydraServe platform qualification."""
import json
import subprocess
import sys
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name)
with (RAW/'storage_identity.json').open('x') as f:json.dump(identity,f,indent=2)
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
seal=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json')
assert p.verify_seal(seal)['pass']
subprocess.run([sys.executable,str(ROOT/'scripts/ieee_tc/compress_closed_main_outcomes.py'),
 '--closed-run','d140_20261001/7b_full_w0_prefix1',
 '--closed-run','d100_20260928/3b_full_w0_attempt7',
 '--closed-run','d97_20260928/3b_full_w0_attempt4',
 '--allow-closed-failure','--receipt',
 str(ROOT/'paper_results/ieee_tc/storage/20261012_d477_closed_outcomes_lossless.json')],check=True)
assert p.verify_seal(seal)['pass']
