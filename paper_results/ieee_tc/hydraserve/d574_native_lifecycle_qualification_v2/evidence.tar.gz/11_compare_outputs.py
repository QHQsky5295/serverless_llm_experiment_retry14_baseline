"""Reuse D509 exact-input/native-output join against the previous D509 prefix."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d509_20261013/compare_outputs.py'
source=original.read_text()
assert source.count("OLD=RAW.parent/'d503_20261013'")==1
source=source.replace("OLD=RAW.parent/'d503_20261013'", "OLD=RAW.parent/'d509_20261013'")
source=source.replace('native LoRA capacity and lifecycle adaptation changed; no independent reference, no 4000-request performance extrapolation',
    'D573 per-worker lifecycle lock changed; native policy and LoRA capacity unchanged; exact input join, no independent numerical reference or full-workload extrapolation')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'compare_outputs.py')})
