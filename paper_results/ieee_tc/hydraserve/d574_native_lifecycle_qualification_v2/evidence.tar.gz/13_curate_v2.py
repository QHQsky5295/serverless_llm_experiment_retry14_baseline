"""Preserve the first curation failure; validate known indented body fragments."""
import hashlib
import json
from pathlib import Path

RAW = Path(__file__).resolve().parent
ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
partial = ROOT/'paper_results/ieee_tc/hydraserve/d574_native_lifecycle_qualification/evidence.tar.gz'
closed = json.loads((RAW/'curation_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
assert not Path(closed['identity']['path']).exists()
with (RAW/'curation_attempt1_failure.json').open('x') as stream:
    json.dump(dict(
        passed=False, failure='IndentationError: unexpected indent in intentionally indented native_body.py fragment',
        affects='archive AST validation only; executed sources and measurements unchanged',
        partial_archive=str(partial), partial_sha256=hashlib.sha256(partial.read_bytes()).hexdigest(),
        closure=closed, partial_preserved=True), stream, indent=2)

recipe = RAW/'curate.py'
prefix = recipe.read_text().split('exec(compile(source,', 1)[0]
namespace = {'__file__': str(recipe), '__name__': 'curation_recipe'}
exec(compile(prefix, str(recipe), 'exec'), namespace)
replace = namespace['replace']
replace("('prepare','remote_prelaunch','audit','output_comparison')",
        "('prepare','remote_prelaunch','audit','output_comparison','curation')")
replace("save(RAW/'curation_identity.json',identity)", "save(RAW/'curation2_identity.json',identity)")
replace("save(RAW/'curation_receipt.json'", "save(RAW/'curation2_receipt.json'")
replace("hydraserve/d574_native_lifecycle_qualification'", "hydraserve/d574_native_lifecycle_qualification_v2'")
replace("if path.suffix=='.py':ast.parse(data)", """if path.suffix=='.py':
                if path == RAW/'native_body.py' or (
                    path.parent == RAW/'executed_sources' and path.name.endswith('_native_body.py')
                ):
                    import textwrap
                    ast.parse(textwrap.dedent(data.decode('utf-8')))
                else:
                    ast.parse(data)""")
exec(compile(namespace['source'], str(namespace['original']), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'curate_v2.py'), 'original': namespace['original']})
