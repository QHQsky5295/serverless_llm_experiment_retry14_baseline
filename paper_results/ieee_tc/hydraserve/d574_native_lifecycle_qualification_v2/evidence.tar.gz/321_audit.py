"""Post-release D503 audit reuse plus frozen full-W0 evaluation.

Never execute during inference. Strict qualification failure produces a retained
audit_failure.json, not a partial performance row or a changed denominator.
Raw numerical-correctness fields are never rewritten.
"""
from hashlib import sha256
import json
import math
from pathlib import Path
import traceback

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')

def save(name, data):
    with (RAW / name).open('x') as handle:
        json.dump(data, handle, indent=2)

def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()

def replace_one(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)

try:
    assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']
    assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
    prereg = json.loads((RAW/'preregistration.json').read_text())
    assert digest(RAW/'preregistration.json') == 'ab9c8692f31d824dd8ee89be6fae0d4e7db6241cea6d15e086653ec7f85f637e'
    for ref in prereg['references'].values():
        assert digest(ref['path']) == ref['sha256'], ref['path']
    for path, record in json.loads((RAW/'source_manifest.json').read_text()).items():
        assert digest(path) == record['sha256'], path
        assert digest(record['snapshot']) == record['sha256']
    assert json.loads((RAW/'prelaunch_gate.json').read_text())['preflight_pass']
    assert set(json.loads((RAW/'remote_health.json').read_text())) == {'3b', '7b'}

    original = RAW.parent/'d503_20261013/audit.py'
    source = original.read_text().replace('http_7b_100.json', 'http_7b_4000.json').replace('=100', '=4000')
    source = replace_one(source,
        "outputs={r['request_id']:r for r in events if r['event']=='http_response'}",
        """outputs={r['request_id']:r for r in events if r['event']=='http_response'}
for event, mapping in [('request_contract',contracts),('http_raw_response',raws),('http_response',outputs)]:
    assert sum(r['event']==event for r in events)==len(mapping)==4000, event
registry={r['adapter_id']:r for r in json.loads((RAW/'lora_registry.json').read_text())}
assert plan.identity()==json.loads((RAW/'preregistration.json').read_text())['plan_identity']""")
    source = replace_one(source,
        "    validate_observation(prepared,raw['body'],out,raw['client_completed_s'],ready['clock_id'],ingress_required=True)",
        """    recomputed=validate_observation(prepared,raw['body'],out,raw['client_completed_s'],ready['clock_id'],ingress_required=True)
    assert recomputed==out['response'],rid
    assert n['native_adapter_index']==registry[c['adapter_id']]['adapter_index'],rid
    assert n['native_adapter_path']==registry[c['adapter_id']]['adapter_path'],rid""")
    scope = {'__name__': '__main__', '__file__': str(RAW/'audit.py')}
    exec(compile(source, str(original), 'exec'), scope)
    rows, contracts, raws = scope['rows'], scope['contracts'], scope['raws']
    physical, ready, plan = scope['physical'], scope['ready'], scope['plan']
    assert len(rows) == 4000 and physical['n_plan'] == physical['n_terminal'] == 4000
    assert all(row['protocol_valid'] is True for row in rows)
    assert sum(row['output_tokens'] for row in rows) == 458224
    assert len({row['adapter_id'] for row in rows}) == 132

    # Independently integrate physical reservations and bind every native
    # response to its actual worker's recorded lifetime. Do not extrapolate
    # native bookkeeping before our qualified pp1 allocation boundary.
    scheduler = json.loads((RAW/'native_scheduler_after_requests.json').read_text())
    assert scheduler['instances'] and all(i['pp_size'] == 1 for i in scheduler['instances']), 'multirank boundary audit required'
    assert scheduler['resource_gpus'] == [[24]*4]
    allocations = [json.loads(line) for line in (RAW/'physical/container_allocations.jsonl').read_text().splitlines()]
    acquires, releases, spawns = {}, {}, {}
    for event in allocations:
        if event['event'] in ('acquire', 'release', 'worker_spawn'):
            target = {'acquire': acquires, 'release': releases, 'worker_spawn': spawns}[event['event']]
            assert event['lease_id'] not in target
            target[event['lease_id']] = event
    assert set(acquires) == set(releases) == set(spawns) and acquires
    by_worker = {}
    devices = {}
    for lease, start in acquires.items():
        end, spawn = releases[lease], spawns[lease]
        assert start['clock_id'] == end['clock_id'] == ready['clock_id']
        assert start['worker_name'] == end['worker_name'] == spawn['worker_name']
        assert start['gpu_uuid'] == end['gpu_uuid'] == spawn['gpu_uuid']
        assert start['at'] <= spawn['at'] < end['at']
        assert end['native_context_qualified'] is True
        assert start['worker_name'] not in by_worker
        by_worker[start['worker_name']] = (start, spawn, end)
        devices.setdefault(start['gpu_uuid'], []).append((start['at'], end['at']))
    independent_gpu_s = 0.
    for intervals in devices.values():
        intervals.sort()
        start, end = intervals[0]
        for left, right in intervals[1:]:
            if left <= end:
                end = max(end, right)
            else:
                independent_gpu_s += end-start
                start, end = left, right
        independent_gpu_s += end-start
    assert abs(independent_gpu_s-physical['gpu_seconds']) <= 1e-6

    evaluation = json.loads(Path(prereg['references']['slo_eval']['path']).read_text())
    evaluated = []
    last_completed = None
    for row in rows:
        native = raws[row['request_id']]['body']['metrics']['ieee_tc']
        proof = native['worker_proof']
        start, spawn, end = by_worker[proof['worker_name']]
        assert proof['container_id'] == spawn['container_id']
        assert proof['host_process'] == spawn['owner']
        assert start['at'] <= native['native_first_token_monotonic_s'] <= native['native_last_token_monotonic_s'] <= proof['verified_at_s'] <= end['at']
        length = len(native['native_prompt_token_ids'])
        groups = [g for g in evaluation['groups']
                  if (g['lower_exclusive'] is None or length > g['lower_exclusive'])
                  and (g['upper_inclusive'] is None or length <= g['upper_inclusive'])]
        assert len(groups) == 1
        group = groups[0]
        ttft_ok = row['ttft_ms'] <= group['ttft_ms']
        tpot_ok = row['output_tokens'] == 1 or row['tpot_ms'] <= group['tpot_ms']
        evaluated.append(dict(request_id=row['request_id'], adapter_id=row['adapter_id'],
            prompt_tokens=length, output_tokens=row['output_tokens'],
            ttft_ms=row['ttft_ms'], tpot_ms=row['tpot_ms'],
            ttft_limit_ms=group['ttft_ms'], tpot_limit_ms=group['tpot_ms'],
            ttft_pass=ttft_ok, tpot_pass=tpot_ok, joint_pass=ttft_ok and tpot_ok))
        completed = raws[row['request_id']]['client_completed_s']
        last_completed = completed if last_completed is None else max(last_completed, completed)
    origin = json.loads((RAW/'launch_gate.launch/exec_receipt.json').read_text())['external_replay']
    observation_s = max(last_completed, origin['replay_t0_s']+max(e.offset_s for e in plan.entries))-origin['replay_t0_s']
    good = sum(r['joint_pass'] for r in evaluated)
    multi = [r for r in evaluated if r['output_tokens'] >= 2]
    def stats(field):
        values = sorted(r[field] for r in rows if r[field] is not None)
        assert values and all(math.isfinite(x) for x in values)
        return dict(n=len(values), mean=sum(values)/len(values),
                    **{name: values[math.ceil(q*len(values))-1] for name, q in
                       [('p50',.5),('p95',.95),('p99',.99),('max',1.)]})
    result = dict(schema='hydraserve_full_w0_v1_binding_accounting_observation',
        full_audit_pass=True, formal_run=False, independent_holdout=False,
        n_plan=4000, n_arrived=4000, n_terminal=4000, n_v1_contract_complete=4000,
        raw_n_correct_preserved=None, independent_numerical_qualification=False,
        count_basis='frozen V1 native source/adapter binding, normal terminal, fixed work and clock; D393 interpretation',
        n_failed=0, n_joint=good, joint_slo=good/4000,
        ttft_attainment=sum(r['ttft_pass'] for r in evaluated)/4000,
        tpot_conditional_attainment=sum(r['tpot_pass'] for r in multi)/len(multi),
        tpot_conditional_denominator=len(multi), observed_w0_g1_feasible=good>=3800,
        physical_gpu_seconds=independent_gpu_s, gpu_seconds_per_v1_contract_request=independent_gpu_s/4000,
        physical_boundary='actual pp1 container reservation union, before create through actual release',
        resource_configuration_optimum=False, g2_or_cross_workload_goal_complete=False,
        observation_s=observation_s, completed_requests_per_s=4000/observation_s,
        good_requests_per_s=good/observation_s, good_requests_per_gpu_second=good/independent_gpu_s,
        native_output_tokens=458224, output_tokens_per_s=458224/observation_s,
        remote_transfers=scope['summary']['remote_transfers'], remote_wire_bytes=scope['summary']['remote_wire_bytes'],
        metrics={field:stats(field) for field in ('ttft_ms','tpot_ms','e2e_ms','submit_lag_ms',
            'dispatch_wait_after_submit_ms','service_ttft_ms','decode_ms','completion_notification_ms','artifact_resolve_ms')},
        stage_note='dispatch_wait ends at actual instance assignment; service_ttft is assignment-to-first and includes any init/adapter wait; artifact span nested, not additive',
        references=prereg['references'],
        source_sha256={str(path):digest(path) for path in (RAW/'audit.py', original,
            RAW/'preregistration.json', RAW/'http_audit.json', RAW/'request_metrics.json',
            RAW/'physical/container_allocations.jsonl', RAW/'native_scheduler_after_requests.json')})
    save('full_w0_slo_rows.json', evaluated)
    save('full_w0_evaluation.json', result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('metrics','references','source_sha256')}))
except Exception as exc:
    save('audit_failure.json', dict(passed=False, error_type=type(exc).__name__,
         error=str(exc), traceback=traceback.format_exc(), performance_row_qualified=False))
    raise
