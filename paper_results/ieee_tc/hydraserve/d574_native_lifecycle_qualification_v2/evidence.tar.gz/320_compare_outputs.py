"""Same-native-backend audit against the existing matched D503 100-prefix."""
from hashlib import sha256
import json
from pathlib import Path
import sys
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d503_20261013'
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
def save(name,value):
    with (RAW/name).open('x') as f:json.dump(value,f,indent=2)
save('output_comparison_identity.json',p.scope_identity(p.cg_path().name))
assert json.loads((RAW/'affected_qualification.json').read_text())['passed']
assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']
def load(root):
    contracts={};outputs={};plan=None
    with (root/'launch_gate.launch/replay.jsonl').open() as handle:
        for line in handle:
            row=json.loads(line)
            if 'plan' in row:plan=row['plan']
            if row['event']=='request_contract':contracts[row['request_id']]=row
            if row['event']=='http_raw_response':outputs[row['request_id']]=row['body']['metrics']['ieee_tc']
    assert len(contracts)==len(outputs)==100
    return plan,contracts,outputs
a,ac,ao=load(OLD);b,bc,bo=load(RAW)
assert a==b and set(ac)==set(bc)
changes=[]
for rid in sorted(ac):
    for key in ('adapter_id','canonical_prompt_sha256','target_tokens','source_item_sha256'):
        assert ac[rid][key]==bc[rid][key],(rid,key)
    left=ao[rid]['completion_token_ids'];right=bo[rid]['completion_token_ids']
    assert len(left)==len(right)==bc[rid]['target_tokens']
    assert ao[rid]['native_prompt_token_ids']==bo[rid]['native_prompt_token_ids']
    if left!=right:
        first=next(i for i,(x,y) in enumerate(zip(left,right)) if x!=y)
        changes.append(dict(request_id=rid,adapter_id=bc[rid]['adapter_id'],
            first_differing_token=first,differing_positions=sum(x!=y for x,y in zip(left,right)),
            old_ids=left,new_ids=right))
result=dict(passed_contract_match=True,old_run=str(OLD),new_run=str(RAW),n=100,
    equal_output_sequences=100-len(changes),changed_sequences=len(changes),changes=changes,
    numerical_equivalence_claim=False,
    limitations='native LoRA capacity and lifecycle adaptation changed; no independent reference, no 4000-request performance extrapolation',
    sources={str(root/'launch_gate.launch/replay.jsonl'):p.digest(root/'launch_gate.launch/replay.jsonl') for root in (OLD,RAW)})
save('same_backend_output_comparison.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ('changes','sources')}))
