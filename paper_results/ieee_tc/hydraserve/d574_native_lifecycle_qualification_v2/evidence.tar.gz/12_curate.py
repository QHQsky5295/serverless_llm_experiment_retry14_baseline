"""Reuse D539 append-only curation for the completed D574 native qualification."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("((RAW,'review'),(CLEAN,'cleanup'))", "tuple((RAW,n) for n in ('prepare','remote_prelaunch','audit','output_comparison'))")
old=source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old,"""review=read(RAW/'affected_qualification.json')
assert review['passed'] and review['qualification_only'] and not review['performance_result']
assert review['n_native_contract_complete']==100 and review['n_failed']==0
assert read(RAW/'same_backend_output_comparison.json')['equal_output_sequences']==100
assert read(RAW/'closure.json')['actual_recursive_empty']
assert not Path(read(RAW/'closure.json')['service']['path']).exists()
assert read(RAW/'remote_stop.json')['all_owned_units_inactive']
for path,record in read(RAW/'source_manifest.json').items():
    assert p.digest(Path(path))==p.digest(Path(record['snapshot']))==record['sha256']
""")
old=source[source.index('specs=['):source.index('reports=[]')]
replace(old,"""files=sorted(x for x in RAW.iterdir() if x.is_file() and not x.is_symlink()
    and x.suffix in ('.py','.json','.jsonl','.log','.sh')
    and x.name not in ('pull-auth.json','curation_identity.json','curation.log'))
for child in ('executed_sources','overlays','platform','physical','remote_artifacts/receipts'):
    files += sorted(x for x in (RAW/child).rglob('*') if x.is_file() and not x.is_symlink())
files += [RAW/'launch_gate.launch'/n for n in ('replay.jsonl','service.log','watchdog.jsonl','exec_receipt.json')]
files += [original,RAW.parent/'d570_20261016/close.py',RAW.parent/'d509_20261013/compare_outputs.py',
          RAW.parent/'d507_20261013/audit.py',RAW.parent/'d503_20261013/audit.py']
copies={n:RAW/n for n in ('affected_qualification.json','same_backend_output_comparison.json',
    'preregistration.json','reuse_inspection.json','request_metrics.json','closure.json','remote_stop.json')}
specs=[('hydraserve/d574_native_lifecycle_qualification',files,copies)]
""")
replace('new_gpu_run=False','new_gpu_run=True')
replace('Executed assertions plus source AST and archive round-trip; no new serving change or repeated GPU tests',
        'One native 100-request affected-path qualification; strict input/token/remote/physical audit and output join; archive SHA round-trip; not a full performance result')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py'),'original':original})
