"""Reuse D509's exact 100-request native qualification with D573 platform locks.

No new weights, trace, backend, scheduling policy or resource envelope.
"""
import ast
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d509_20261013'
RECENT=RAW.parent/'d546_20261015'
CPU=RAW.parent/'d573_20261016'
BASE=Path('/home/qhq/serverless_llm_baselines')
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path[:0]=[str(BASE),str(BASE/'scripts')]
from HydraServe_project.runtime.native_delivery import replace_one
from prepare_ieee_tc_serverless_stack import load_http_replay_plan,validate_http_lifecycle_contract

def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def put(name,text):
    with (RAW/name).open('x') as f:f.write(text)
def save(name,value):put(name,json.dumps(value,indent=2))
def retag(source):return source.replace('d509_20261013','d574_20261016').replace('d509','d574')

identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save('prepare_identity.json',identity)
assert os.sched_getaffinity(0)=={2,3,26,27}
for key,value in [('memory.high',3*p.GIB),('memory.max',4*p.GIB),('memory.swap.max',0)]:
    assert (group/key).read_text().strip()==str(value)
assert os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
# The first preparation attempt exited before importing any service or saving a
# scope receipt (BASE's `scripts` package shadowed MAIN's namespace). Preserve
# that launcher failure and close only its now-empty, freshly verified scope.
failed=p.scope_identity('primelora-tc-aux-d5740000000000000000000000000001.scope')
failed_group=Path(failed['path'])
members={str(x):x.read_text().split() for x in failed_group.rglob('cgroup.procs')}
assert members and not any(members.values()) and p.scope_still_owned(failed)
failed_resources={k:(failed_group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
subprocess.run(['systemctl','--user','stop',failed['unit']],check=True)
assert not failed_group.exists()
save('prepare_import_failure.json',dict(error='ImportError: cannot import ieee_tc_preflight from baseline scripts package',
    before_any_service_or_inference=True,identity_observed_after_exit=failed,
    actual_recursive_empty=True,path_gone=True,resources=failed_resources,
    remedy='Import existing MAIN preflight before adding BASE to sys.path; no serving change'))
gate=p.preflight([RAW],predicted_growth=20*p.GIB)
save('prepare_resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
for mode in ('baseline','main'):
    receipt=json.loads((CPU/f'publication_{mode}_receipt.json').read_text())
    closed=json.loads((CPU/f'publication_{mode}_closure.json').read_text())
    assert receipt['passed'] and receipt['head']==receipt['remote']
    assert closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
assert json.loads((CPU/'after2_result.json').read_text())['successful']
for directory in (OLD,RECENT):
    assert json.loads((directory/'closure.json').read_text())['actual_recursive_empty']
    assert json.loads((directory/'remote_stop.json').read_text())['all_owned_units_inactive']

# Audit all shared source changes against the last native full run. The two
# shared input changes add opt-in W2 only; the W0 prefix identity stays exact.
comparisons=[]
for path,record in json.loads((RECENT/'source_manifest.json').read_text()).items():
    assert digest(record['snapshot'])==record['sha256']
    if str(RECENT) in path:continue
    comparisons.append(dict(path=path,old_sha256=record['sha256'],current_sha256=digest(path)))
changed={r['path']:r['current_sha256'] for r in comparisons if r['old_sha256']!=r['current_sha256']}
assert changed=={
    str(MAIN/'faaslora/datasets/workload_generator.py'):'02930d843fd017eb9ed775184c1745b3db9420895a41aaf33b33f9f85b3064d6',
    str(BASE/'scripts/prepare_ieee_tc_serverless_stack.py'):'d9277550f57098fccc36b6ca9c5d488518598aee740ddfbe6f2a95b88479ff48',
    str(BASE/'HydraServe_project/runtime/isolated_platform.py'):'2c02b76f9d4902f8ae73386e8cc5efcf9db1029e0f51c8aa42dfaae679dc5b7f'}
save('reuse_inspection.json',dict(passed=True,comparisons=comparisons,changed=changed,
    input_changes='D553 opt-in W2 adapter-only view; W0 prefix identity checked unchanged',
    runtime_change='D573 per-worker lifecycle locks; original controller policy unchanged'))
cfg=json.loads((OLD/'http_7b_100.json').read_text())
assert cfg['request_count']==100 and cfg['request_view']=='trace_prefix_v1'
cfg['experiment_role']='d573_affected_native_lifecycle_qualification'
plan=load_http_replay_plan(cfg);validate_http_lifecycle_contract(cfg)
old_prereg=json.loads((OLD/'preregistration.json').read_text())
assert plan.identity()==old_prereg['plan_identity']
assert digest(cfg['pool_index'])==cfg['pool_index_sha256']
save('http_7b_100.json',cfg)
for name in ('remote_input_config.json','model_registration.json','input_qualification.json',
             'online_sources.json','official_main.py','official_scheduler.py','official_engine.py','official_ModelInfo.py'):
    put(name,(OLD/name).read_text())
for name in ('close_pause.py','close_audit.py','collect_remote.py','start_remote.sh',
             'run_and_close.sh','prelaunch.py','launch.sh','native_body.py','request_witness.py'):
    source=retag((OLD/name).read_text())
    if name=='launch.sh':
        source=replace_one(source,'-p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0',
            '-p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 -p AllowedCPUs=2,3,26,27')
    put(name,source)
source=retag((OLD/'remote_prelaunch.py').read_text())
source=replace_one(source,"for mode in ('baseline','main'):\n    assert json.loads((RAW/f'backup_{mode}_receipt.json').read_text())['passed']",
    "for mode in ('baseline','main'):\n    assert json.loads((RAW.parent/'d573_20261016'/f'publication_{mode}_receipt.json').read_text())['passed']\nassert json.loads((RAW/'prepare_result.json').read_text())['passed']")
put('remote_prelaunch.py',source)
pool=json.loads(Path(cfg['pool_index']).read_text())['artifacts'];assert len(pool)==500
save('lora_registry.json',[dict(adapter_id=aid,adapter_index=i,adapter_path=str(RAW/'adapter_views'/aid))
    for i,aid in enumerate(sorted(x['id'] for x in pool),1)])
prereg=old_prereg
for key,ref in prereg['references'].items():
    if key=='plan':ref['sha256']=p.check_plan()
    else:assert digest(ref['path'])==ref['sha256']
prereg.update(campaign='d574_20261016',reuse_from=str(OLD),reuse_audit_sha256=digest(RAW/'reuse_inspection.json'),
    adaptation_change='D573 per-worker platform lifecycle locks only; no native scheduling/configuration changes',
    adaptation_checkpoint=str(CPU),adaptation_summary_sha256=digest(CPU/'after2_result.json'),
    no_runtime_policy_change=False,no_native_policy_change=True,
    interpretation='affected lifecycle/concurrency qualification, not full workload performance or numerical equivalence',
    source_heads={label:subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
                  for label,root in [('baseline',BASE),('main',MAIN)]})
save('preregistration.json',prereg)
template=retag((OLD/'executed_prepare.py').read_text())
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
assert json.loads((RAW/'overlays/manifest.json').read_text())==json.loads((RECENT/'overlays/manifest.json').read_text())
audit=(OLD/'audit.py').read_text()
audit=replace_one(audit,digest(OLD/'preregistration.json'),digest(RAW/'preregistration.json'))
put('audit.py',audit)
for path in RAW.glob('*.py'):
    if path.name!='native_body.py':ast.parse(path.read_text(),filename=str(path))
for path in RAW.glob('*.sh'):subprocess.run(['bash','-n',str(path)],check=True)
save('prepare_result.json',dict(passed=True,prepared_not_launched=True,performance_result=False,
    n_plan=100,source_trace_seed=42,plan_identity=plan.identity(),native_overlays_unchanged=True,
    preregistration_sha256=digest(RAW/'preregistration.json'),reuse_inspection_sha256=digest(RAW/'reuse_inspection.json'),
    qualified_platform_sha256=digest(BASE/'HydraServe_project/runtime/isolated_platform.py'),
    source_manifest_sha256=digest(RAW/'source_manifest.json')))
print(json.dumps(dict(passed=True,n_plan=100,prepared_not_launched=True)))
