"""Reuse D539 exact-path tested publication for D574 native qualification."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('3e759d75b6e69e182d646d87aca5090f5935024f','716b74a0d547bc69daa0f02c7790b8aeb00a74b2')
replace("('review','curation')", "('prepare','remote_prelaunch','audit','output_comparison','curation','curation2')")
replace("not record['new_gpu_run']", "record['new_gpu_run']")
replace("'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'",
        "'docs/ieee_tc/D574_HYDRASERVE_LIFECYCLE_NATIVE_QUALIFICATION.md'")
replace("reports=read(RAW/'curation_receipt.json')['reports']", "reports=read(RAW/'curation2_receipt.json')['reports']")
replace("('publish.py','curation_identity.json','curation_closure.json','curation_receipt.json','close.py')]",
        "('publish.py','curate_v2.py','curation2_identity.json','curation2_closure.json','curation2_receipt.json','close_cpu.py')]+[original]")
replace('arcname=path.name','arcname=("base_recipe_"+path.name if path==original else path.name)')
replace('bundle.extractfile(path.name)','bundle.extractfile("base_recipe_"+path.name if path==original else path.name)')
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: preserve HydraServe lifecycle native qualification (D574)')
replace("out=Path(reports[-1]['path']);archive=out/'publication_evidence.tar.gz'", """out=Path(reports[-1]['path']);archive=out/'publication_evidence.tar.gz'
base=Path('/home/qhq/serverless_llm_baselines')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()=='80e08b4c6e7c2874b1b237500a00811ec06cd8c5'
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=base,text=True).split()[0]=='80e08b4c6e7c2874b1b237500a00811ec06cd8c5'
save(out/'checkpoint.json',dict(baseline_commit='80e08b4c6e7c2874b1b237500a00811ec06cd8c5',
    baseline_remote_equal=True,qualification='100-request native qualification, not full G1/G2'))
names.append(str((out/'checkpoint.json').relative_to(ROOT)))
""")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py'),'original':original})
