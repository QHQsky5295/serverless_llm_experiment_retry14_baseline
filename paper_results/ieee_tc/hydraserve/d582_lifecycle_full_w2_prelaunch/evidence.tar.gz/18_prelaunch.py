"""Fresh protected-assets, resource and authenticated published-service gates."""
import json
from pathlib import Path
import sys
import urllib.request
RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(name,data):
    with (RAW/name).open('x') as f:json.dump(data,f,indent=2)
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass'];save('protected_before.json',protected)
for path,expected in (
    (MAIN/'configs/generated/lora_manifest_1000.json','3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df'),
    (BASE/'scripts/replay_openai_trace.py','04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22'),
    (BASE/'scripts/run_serverlessllm_relayserve_continuation.sh','337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499')):
    assert p.digest(path)==expected
for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
    assert p.digest(Path(path))==record['sha256']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_text().strip()
health={}
for model,port in [('3b',18080),('7b',18081)]:
    request=urllib.request.Request(f'http://192.168.4.174:{port}/health',headers={'Authorization':'Bearer '+token})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=15) as response:
        health[model]=json.loads(response.read())
save('remote_health.json',health)
gate=p.preflight([RAW],predicted_growth=20*p.GIB)
save('prelaunch_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
print(json.dumps(dict(passed=True,protected=protected['pass'],remote_health=health)))
