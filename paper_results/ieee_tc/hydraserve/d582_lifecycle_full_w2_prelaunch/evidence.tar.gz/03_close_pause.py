"""Host Python provides pidfd APIs; act only on this run's exact adopted pause."""
import json
import os
from pathlib import Path
import signal
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
owner=json.loads((RAW/'pause_adoption.json').read_text())['after']
service=json.loads((RAW/'probe_identity.json').read_text())
assert p.scope_still_owned(service)
assert Path(owner['cgroup'])==Path(service['path'])/'supervisor'
assert p.gpu_process_identity(owner['pid'])==owner
assert Path(f"/proc/{owner['pid']}/comm").read_text().strip()=='podman pause'
fd=os.pidfd_open(owner['pid'])
try:
    assert p.gpu_process_identity(owner['pid'])==owner
    signal.pidfd_send_signal(fd,signal.SIGKILL)
finally:os.close(fd)
