"""Reuse D574 qualified native recipe on the existing complete W0, once."""
import ast
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

RAW=Path(__file__).resolve().parent
QUAL=RAW.parent/'d574_20261016'
FULL=RAW.parent/'d510_20261013'
RECENT=RAW.parent/'d546_20261015'
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path[:0]=[str(BASE),str(BASE/'scripts')]
from HydraServe_project.runtime.native_delivery import replace_one
from prepare_ieee_tc_serverless_stack import load_http_replay_plan,validate_http_lifecycle_contract

def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def put(name,value):
    with (RAW/name).open('x') as f:f.write(value)
def save(name,value):put(name,json.dumps(value,indent=2))
def retag(text):return text.replace('d574_20261016','d576_20261016').replace('d574','d576').replace('http_7b_100.json','http_7b_4000.json')

identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save('prepare_identity.json',identity)
assert os.sched_getaffinity(0)=={2,3,26,27}
for key,value in [('memory.high',3*p.GIB),('memory.max',4*p.GIB),('memory.swap.max',0)]:
    assert (group/key).read_text().strip()==str(value)
assert os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
gate=p.preflight([RAW],predicted_growth=20*p.GIB)
save('prepare_resource_gate.json',gate)
assert gate['preflight_pass'],gate['issues']
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
for name in ('prepare','remote_prelaunch','audit','output_comparison','curation','curation2','publication'):
    closed=json.loads((QUAL/(name+'_closure.json')).read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
publication=json.loads((QUAL/'publication_receipt.json').read_text())
assert publication['passed'] and publication['head']==publication['remote']=='5084aff91c06b4397697f5a08edee0b31acc46a3'
assert json.loads((QUAL/'affected_qualification.json').read_text())['passed']
assert json.loads((QUAL/'same_backend_output_comparison.json').read_text())['equal_output_sequences']==100
assert json.loads((QUAL/'remote_stop.json').read_text())['all_owned_units_inactive']
clean=RAW.parent.parent/'storage_maintenance/d575_20261016'
assert json.loads((clean/'cleanup_receipt.json').read_text())['passed']
assert json.loads((clean/'cleanup_closure.json').read_text())['path_gone']
assert json.loads((QUAL/'cache_cleanup_after.json').read_text())['removed']

comparisons=[]
for path,record in json.loads((QUAL/'source_manifest.json').read_text()).items():
    assert digest(path)==digest(record['snapshot'])==record['sha256'],path
    if str(QUAL) not in path:
        comparisons.append(dict(path=path,sha256=record['sha256']))
save('reuse_inspection.json',dict(passed=True,shared_sources_equal=True,comparisons=comparisons,
    qualification=str(QUAL),native_policy_changed=False,
    adaptation='D573 per-worker lifecycle locks, already CPU/native-qualified',
    current_runtime_count=sum('/HydraServe_project/runtime/' in r['path'] for r in comparisons)))

cfg=json.loads((FULL/'http_7b_4000.json').read_text())
assert cfg['request_count']==4000 and cfg['request_view']=='trace_prefix_v1'
plan=load_http_replay_plan(cfg);validate_http_lifecycle_contract(cfg)
old_prereg=json.loads((FULL/'preregistration.json').read_text())
assert plan.identity()==old_prereg['plan_identity']
assert digest(cfg['trace'])==cfg['trace_sha256'] and digest(cfg['pool_index'])==cfg['pool_index_sha256']
save('http_7b_4000.json',cfg)
for name in ('remote_input_config.json','model_registration.json','input_qualification.json',
             'online_sources.json','official_main.py','official_scheduler.py','official_engine.py','official_ModelInfo.py'):
    put(name,(QUAL/name).read_text())
for name in ('close_pause.py','close_audit.py','collect_remote.py','start_remote.sh',
             'run_and_close.sh','prelaunch.py','launch.sh','remote_prelaunch.py','close_cpu.py'):
    put(name,retag((QUAL/name).read_text()))
body=retag((QUAL/'native_body.py').read_text())
body=replace_one(body,'100 existing W0-prefix requests; affected mixed-LoRA/memory qualification','4000 existing W0 requests')
put('native_body.py',body)
witness=(QUAL/'request_witness.py').read_text().replace('first100 W0-prefix','full4000 W0')
witness=replace_one(witness,"terminal['N_response']==100","terminal['N_response']==4000")
put('request_witness.py',witness)
pool=json.loads(Path(cfg['pool_index']).read_text())['artifacts'];assert len(pool)==500
save('lora_registry.json',[dict(adapter_id=aid,adapter_index=i,adapter_path=str(RAW/'adapter_views'/aid))
    for i,aid in enumerate(sorted(x['id'] for x in pool),1)])
prereg=old_prereg
for key,ref in prereg['references'].items():
    if key=='plan':ref['sha256']=p.check_plan()
    else:assert digest(ref['path'])==ref['sha256']
prereg.update(campaign='d576_20261016',workload='W0',n_plan=4000,plan_identity=plan.identity(),
    reuse_from=str(QUAL),full_config_source=str(FULL/'http_7b_4000.json'),
    full_config_sha256=digest(FULL/'http_7b_4000.json'),reuse_audit_sha256=digest(RAW/'reuse_inspection.json'),
    adaptation_change='D573 per-worker platform lifecycle locks; official scheduling/configuration unchanged',
    no_runtime_policy_change=False,no_native_policy_change=True,
    interpretation='one complete known-trace W0 development observation after necessary platform adaptation; not independent holdout or numerical qualification',
    same_backend_output_audit=dict(path=str(QUAL/'same_backend_output_comparison.json'),
        sha256=digest(QUAL/'same_backend_output_comparison.json'),equal_sequences=100,changed_sequences=0,
        cause_independently_proved=False),
    source_heads={label:subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
        for label,root in [('baseline',BASE),('main',MAIN)]})
save('preregistration.json',prereg)
template=retag((QUAL/'executed_prepare.py').read_text())
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
assert json.loads((RAW/'overlays/manifest.json').read_text())==json.loads((QUAL/'overlays/manifest.json').read_text())
audit=(RECENT/'audit.py').read_text()
audit=replace_one(audit,digest(RECENT/'preregistration.json'),digest(RAW/'preregistration.json'))
audit=audit.replace('full-W1','full-W0').replace('full_w1','full_w0').replace('observed_w1_g1_feasible','observed_w0_g1_feasible')
put('audit.py',audit)
put('run_audit.py',(RECENT/'run_audit.py').read_text())
for path in RAW.glob('*.py'):
    if path.name!='native_body.py':ast.parse(path.read_text(),filename=str(path))
for path in RAW.glob('*.sh'):subprocess.run(['bash','-n',str(path)],check=True)
save('prepare_result.json',dict(passed=True,n_plan=4000,source_trace_seed=42,
    prepared_not_launched=True,performance_result=False,full_config_equal=(RAW/'http_7b_4000.json').read_bytes()==(FULL/'http_7b_4000.json').read_bytes(),
    plan_identity=plan.identity(),native_overlays_unchanged=True,
    reuse_inspection_sha256=digest(RAW/'reuse_inspection.json'),
    preregistration_sha256=digest(RAW/'preregistration.json'),source_manifest_sha256=digest(RAW/'source_manifest.json')))
print(json.dumps(dict(passed=True,n_plan=4000,prepared_not_launched=True)))
