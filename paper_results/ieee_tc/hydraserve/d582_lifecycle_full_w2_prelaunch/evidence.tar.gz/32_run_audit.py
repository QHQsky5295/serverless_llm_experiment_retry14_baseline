"""Identity-bound post-release invocation of the preregistered full audit."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'],text=True).strip()
with (RAW/'audit_identity.json').open('x') as f:
    json.dump(p.scope_identity(p.cg_path().name),f,indent=2)
source=(RAW/'audit.py').read_text()
exec(compile(source,str(RAW/'audit.py'),'exec'),
     {'__name__':'__main__','__file__':str(RAW/'audit.py')})
