"""Independent post-release input/token/timing/remote/resource audit."""
from hashlib import sha256
import importlib.util
import json
import math
from pathlib import Path
import sys
RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path.append(str(BASE))
from HydraServe_project.runtime.http_contract import validate_observation
assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
cfg=json.loads((RAW/'http_7b_100.json').read_text())
spec=importlib.util.spec_from_file_location('shared_stack_audit',BASE/'scripts/prepare_ieee_tc_serverless_stack.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
plan=helper.load_http_replay_plan(cfg)
events=[json.loads(line) for line in (RAW/'launch_gate.launch/replay.jsonl').read_text().splitlines()]
ready=events[0];assert ready['plan']==plan.identity()
contracts={r['request_id']:r for r in events if r['event']=='request_contract'}
raws={r['request_id']:r for r in events if r['event']=='http_raw_response'}
outputs={r['request_id']:r for r in events if r['event']=='http_response'}
transfers=[json.loads(line) for line in (RAW/'remote_transfers.jsonl').read_text().splitlines()]
by_transfer={r['transfer_id']:r for r in transfers}
assert len(by_transfer)==len(transfers)
assert set(contracts)==set(raws)==set(outputs)=={e.request_id for e in plan.entries}
assert events[-1]==dict(event='http_replay_complete',N_plan=100,N_arrived=100,N_terminal=100,N_response=100,N_failed=0)
rows=[];seen_transfer=set();prior={r['request_id']:r for r in json.loads((RAW.parent/'d502_20261013/generation_result.json').read_text())['requests']}
comparison=[]
for entry in plan.entries:
    rid=entry.request_id;c=contracts[rid];raw=raws[rid];n=raw['body']['metrics']['ieee_tc'];out=outputs[rid]
    assert c['source_item_sha256']==entry.source_sha256 and raw['status']==200
    # Client request contract excludes input text/IDs; raw native IDs remain
    # independently hash-bound to that earlier contract, not to target counts.
    prepared=dict(c,input_token_ids=n['native_prompt_token_ids'])
    validate_observation(prepared,raw['body'],out,raw['client_completed_s'],ready['clock_id'],ingress_required=True)
    a=n['artifact_observation'];receipt=RAW/'remote_artifacts/receipts'/(c['adapter_id']+'.json')
    assert p.digest(receipt)==a['tc_artifact_receipt_sha256']
    if not a['tc_artifact_cache_hit']:
        transfer=by_transfer[a['tc_artifact_transfer_id']]
        assert transfer['artifact_id']==c['adapter_id'] and transfer['outcome']=='sent'
        assert transfer['pack_performed'] is False and transfer['temporary_created'] is False
        assert transfer['bytes_written']==a['tc_artifact_transferred_bytes']
        assert transfer['transfer_id'] not in seen_transfer
        seen_transfer.add(transfer['transfer_id'])
    row=dict(request_id=rid,adapter_id=c['adapter_id'],target_tokens=c['target_tokens'],
        output_tokens=len(n['completion_token_ids']),**out['response'])
    rows.append(row)
    if rid in prior:
        previous=prior[rid]
        assert previous['prompt_sha256']==c['canonical_prompt_sha256']
        comparison.append(dict(request_id=rid,same_canonical_prompt=True,
            output_ids_equal_d502=previous['output_token_ids']==n['completion_token_ids']))
assert seen_transfer==set(by_transfer)
physical=json.loads((RAW/'physical/summary.json').read_text())
assert physical['measurement_complete'] and physical['native_contexts_qualified'] and not physical['open_lease_ids']
assert physical['n_correct'] is None and physical['n_terminal']==100
assert abs(sum(physical['window_gpu_seconds'].values())-physical['gpu_seconds'])<1e-8
def stats(key):
    values=sorted(r[key] for r in rows if r[key] is not None)
    return dict(n=len(values),mean=sum(values)/len(values),p50=values[math.ceil(.5*len(values))-1],
        p95=values[math.ceil(.95*len(values))-1],max=values[-1])
summary=dict(passed=True,qualification_only=True,performance_result=False,n_native_contract_complete=100,
    n_correct=None,numerical_lora_qualified=False,actual_unique_adapters=len({r['adapter_id'] for r in rows}),
    remote_transfers=len(transfers),remote_wire_bytes=sum(r['bytes_written'] for r in transfers),
    pack_performed=False,physical=physical,
    metrics={k:stats(k) for k in ('ttft_ms','tpot_ms','e2e_ms','submit_lag_ms','dispatch_wait_after_submit_ms',
        'service_ttft_ms','decode_ms','artifact_resolve_ms')},prior_output_comparison=comparison,
    source_sha256={str(path):p.digest(path) for path in (RAW/'launch_gate.launch/replay.jsonl',
        RAW/'remote_transfers.jsonl',RAW/'physical/summary.json',RAW/'http_7b_100.json')})
with (RAW/'http_audit.json').open('x') as f:json.dump(summary,f,indent=2)
with (RAW/'request_metrics.json').open('x') as f:json.dump(rows,f,indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ('physical','metrics','source_sha256')}))
