"""Reuse prior bounded preregistration curation for the common W2 input view."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d579_20261016/curate.py'
source=original.read_text().replace('d579','d582').replace('D579','D582').replace('full-W1','full-W2').replace('full_w1','full_w2')
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("prepared['full_config_equal']", "prepared['native_config_preserved'] and prepared['common_w2_plan_equal']")
replace("prepared['plan_identity']['profile']=='W1'", "prepared['plan_identity']['profile']=='W2'")
replace("assert p.digest(RAW/'http_7b_4000.json')==p.digest(RAW.parent/'d546_20261015/http_7b_4000.json')",
        "assert read(RAW/'w2_input_qualification.json')['exact_4000_entries_equal']\nassert read(RAW/'w2_input_qualification.json')['actual_unique_adapters']==497")
replace('D582 exact D546 W1 inputs', 'D582 exact D553/D557 common W2 input view')
replace("files.append(original)", "files.append(original)\nfiles.extend([RAW.parent/'d576_20261016/prepare.py', RAW.parent/'d579_20261016/audit.py', RAW.parent/'d503_20261013/audit.py'])")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py')})
