"""Audit qualified launch release, close only exact-owned empty auxiliary scope."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
launch=json.loads((RAW/'launch_gate.json').read_text())
identity=launch['service_identity']
assert not Path(identity['path']).exists()
assert launch['cleanup']['released']
events=[json.loads(x) for x in (RAW/'launch_gate.launch/watchdog.jsonl').read_text().splitlines()]
samples=[x for x in events if x['event']=='resource_sample']
terminal=[x for x in events if x['event']=='gpu_terminal_census']
assert terminal and not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
aux=p.scope_identity('primelora-tc-aux-d5820000000000000000000000000009.scope')
group=Path(aux['path'])
members={str(x):x.read_text().split() for x in (group/'cgroup.procs',*group.rglob('cgroup.procs'))}
assert not any(members.values()) and p.scope_still_owned(aux)
subprocess.run(['systemctl','--user','stop',aux['unit']],check=True)
assert not group.exists()
result=dict(service=identity,service_gone=True,auxiliary=aux,actual_recursive_empty=True,
    peak_bytes=max(x['service']['memory.peak'] for x in samples),
    event_max={k:max(x['service']['memory.events'][k] for x in samples) for k in samples[0]['service']['memory.events']},
    swap_max=max(x['service']['memory.swap.current'] for x in samples),
    gpu_terminal_census=terminal,original_failed_result_preserved=True)
with (RAW/'closure.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='gpu_terminal_census'}))
