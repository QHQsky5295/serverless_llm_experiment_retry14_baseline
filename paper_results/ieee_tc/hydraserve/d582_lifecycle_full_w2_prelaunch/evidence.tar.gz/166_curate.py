"""Adapt D537 curation for bounded D538 maintenance and D539 offline review."""
import ast, hashlib, io, json, os, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
CLEAN=RAW.parent.parent/'storage_maintenance/d538_20261015'
D532=RAW.parent.parent/'vllm_qualification/d532_20261015'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(x):return json.loads(x.read_text())
def save(x,v):
    with x.open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'curation_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
for directory,name in ((RAW,'review'),(CLEAN,'cleanup')):
    c=read(directory/(name+'_closure.json'))
    assert c['passed'] and c['path_gone'] and c['actual_recursive_procs_empty']
    assert not Path(c['identity']['path']).exists()
review=read(RAW/'review.json');clean=read(CLEAN/'cleanup_receipt.json')
assert review['passed'] and not review['changed_serving_code'] and not review['new_performance_run']
assert all(review['upstream_core_ast_equal'].values())
epochs=review['observations']['D537_W1']['epochs']
assert len(epochs)==16 and sum(e['served'] for e in epochs)==4000
assert all(e['compiled_graph_cache_hit'] for e in epochs)
assert clean['passed'] and clean['returncode']==0
before=read(D532/'cache_cleanup_before.json');after=read(D532/'cache_cleanup_after.json')
assert before['current_cache_bytes_rehashed'] and before['current_original_bytes_rehashed']
assert after['observed_reclaimed_bytes']==3305652224 and after['removed']
assert not after['raw_results_removed'] and not after['unique_artifacts_removed']
preserved={str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
 str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
 str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}',data)
specs=[('storage/d538_targeted_cache_reclaim',
 [CLEAN/n for n in ('run_cleanup.py','close.py','cleanup_identity.json','cleanup_receipt.json','cleanup_closure.json')]+
 [D532/n for n in ('reclaim_objects.py','cache_cleanup_before.json','cache_cleanup_after.json')],
 {'cleanup_receipt.json':CLEAN/'cleanup_receipt.json','cleanup_closure.json':CLEAN/'cleanup_closure.json',
 'cache_cleanup_after.json':D532/'cache_cleanup_after.json'}),
 ('main_comparison/d539_serverlessllm_queue_review',
 [RAW/n for n in ('review_queue.py','close.py','review_identity.json','review_closure.json','sources_before.json','curate.py')]+
 sorted((RAW/'worker_evidence').iterdir()),{'review.json':RAW/'review.json','review_closure.json':RAW/'review_closure.json'})]
reports=[]
for relative,files,copies in specs:
    out=ROOT/'paper_results/ieee_tc'/relative;out.mkdir(parents=True,exist_ok=False)
    members={}
    with tarfile.open(out/'evidence.tar.gz','x:gz') as bundle:
        for i,path in enumerate(files):
            data=path.read_bytes();check(data);assert len(data)<8*1024*1024
            if path.suffix=='.py':ast.parse(data)
            name=f'{i:02d}_{path.name}';member=tarfile.TarInfo(name)
            member.size=len(data);member.mode=0o600;member.mtime=0
            bundle.addfile(member,io.BytesIO(data))
            members[name]=dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
    with tarfile.open(out/'evidence.tar.gz') as bundle:
        assert set(bundle.getnames())==set(members)
        for name,ref in members.items():assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==ref['sha256']
    for name,path in copies.items():
        data=path.read_bytes();check(data)
        with (out/name).open('xb') as f:f.write(data)
    outputs={name:p.digest(out/name) for name in (*copies,'evidence.tar.gz')}
    save(out/'manifest.json',dict(passed=True,new_gpu_run=False,production_changed=False,identity=identity,
        source_plan_sha256=p.check_plan(),preserved=preserved,protected=protected,
        archive_members=members,outputs=outputs,validation='Executed assertions plus source AST and archive round-trip; no new serving change or repeated GPU tests'))
    with (out/'result.sha256').open('x') as f:
        for name in (*outputs,'manifest.json'):f.write(p.digest(out/name)+'  '+name+'\n')
    reports.append(dict(path=str(out),archive_bytes=(out/'evidence.tar.gz').stat().st_size))
save(RAW/'curation_receipt.json',dict(passed=True,identity=identity,reports=reports))
print(json.dumps(dict(passed=True,reports=reports)))
