"""Reuse exact-path SHA/secret/protected publication for D582 preregistration."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent/'d579_20261016/publish.py'
source=original.read_text().replace('d579','d582').replace('D579','D582').replace('full-W1','full-W2').replace('FULL_W1','FULL_W2').replace('full W1','full W2')
assert source.count('c1cd00e3d2c2d30fc515a1734c288a40410907b4')==1
source=source.replace('c1cd00e3d2c2d30fc515a1734c288a40410907b4','cef1218e4d8b4e3dfae5c59d82af85b0310d0a48')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py')})
