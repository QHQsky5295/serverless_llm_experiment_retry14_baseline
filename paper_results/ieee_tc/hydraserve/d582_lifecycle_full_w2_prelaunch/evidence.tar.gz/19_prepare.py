"""Reuse D576 native execution recipe with the already qualified common W2 view."""
from pathlib import Path

RAW = Path(__file__).resolve().parent
original = RAW.parent / 'd576_20261016/prepare.py'
source = original.read_text().replace('d576_20261016', 'd582_20261016').replace('d576', 'd582')

def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace("FULL=RAW.parent/'d510_20261013'", "FULL=RAW.parent/'d576_20261016'")
replace("RECENT=RAW.parent/'d546_20261015'", "RECENT=RAW.parent/'d579_20261016'")
replace('comparisons=[]', """# Prior execution and maintenance must be actually closed, not merely labelled.
for campaign in ('d576_20261016','d579_20261016'):
    previous=RAW.parent/campaign
    for name in ('prepare','remote_prelaunch','audit','output_comparison','result','result_publication'):
        closed=json.loads((previous/(name+'_closure.json')).read_text())
        assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
        assert not Path(closed['identity']['path']).exists()
    assert json.loads((previous/'remote_stop.json').read_text())['all_owned_units_inactive']
    for path,record in json.loads((previous/'source_manifest.json').read_text()).items():
        if str(previous) not in path:assert digest(path)==record['sha256'],path
for campaign,names in (('d580_20261016',('cleanup',)),
                       ('d581_20261016',('storage','curation','publication'))):
    directory=RAW.parent.parent/'storage_maintenance'/campaign
    for name in names:
        closed=json.loads((directory/(name+'_closure.json')).read_text())
        assert closed['passed'] and closed['path_gone'] and closed['actual_recursive_procs_empty']
        assert not Path(closed['identity']['path']).exists()
comparisons=[]""")
replace("assert cfg['request_count']==4000 and cfg['request_view']=='trace_prefix_v1'", """assert cfg['request_count']==4000 and cfg['request_view']=='trace_prefix_v1'
old_cfg=dict(cfg)
shared=RAW.parent.parent/'vllm_qualification/d557_20261016'
common=json.loads((shared/'http_7b_4000.json').read_text())
for key in ('trace','trace_sha256','request_view','replay_profile','adapter_map','adapter_map_sha256'):
    cfg[key]=common[key]
cfg['experiment_role']='native_hydraserve_full_w2_single_observation'
assert cfg['request_view']=='trace_w2_v1' and cfg['replay_profile']=='W2'
changed={k for k in set(cfg)|set(old_cfg) if cfg.get(k)!=old_cfg.get(k)}
assert changed=={'trace','request_view','replay_profile','adapter_map','adapter_map_sha256','experiment_role'}
assert digest(cfg['adapter_map'])=='48c72e39bfff13874de70a73a8a7ca26ff7be5246d5ee5a3a59dfb06bd502300'
qualified=RAW.parent.parent/'main_comparison/d553_20261015/qualification_final.json'
assert digest(qualified)=='1e5f62dac7b1cb9e94f9b37a8b56e232a58069ac47513e36441751921a5fdeb1'
q=json.loads(qualified.read_text());assert q['passed'] and q['tests']==386
for path in (BASE/'scripts/prepare_ieee_tc_serverless_stack.py',MAIN/'faaslora/datasets/workload_generator.py'):
    assert digest(path)==q['refs'][str(path)]
""")
replace("assert plan.identity()==old_prereg['plan_identity']", """assert plan.identity()==load_http_replay_plan(common).identity()==q['http_plan']
assert plan.identity()['view_sha256']=='5734bd88587c75dacc0d5c7534ad5b4d5d2a67aa0980f9b203dd87135d3adce7'
entries=[json.loads(e.source_json) for e in plan.entries]
assert len(entries)==4000 and len({r['adapter_id'] for r in entries})==497
assert sum(min(r['expected_output_tokens'],256) for r in entries)==458224
common_entries=load_http_replay_plan(common).entries
assert all((a.request_id,a.offset_s,a.source_sha256,a.source_json)==
           (b.request_id,b.offset_s,b.source_sha256,b.source_json)
           for a,b in zip(plan.entries,common_entries))
save('w2_input_qualification.json',dict(passed=True,common_plan=plan.identity(),
    exact_4000_entries_equal=True,actual_unique_adapters=497,target_tokens=458224,
    common_config=str(shared/'http_7b_4000.json'),common_config_sha256=digest(shared/'http_7b_4000.json'),
    map_sha256=digest(cfg['adapter_map']),reused_w2_tests=386,
    qualified_by=str(qualified),qualification_sha256=digest(qualified),
    changed_input_fields=sorted(changed),native_policy_unchanged=True,new_trace_or_weights=False))""")
replace("'4000 existing W0 requests'", "'4000 existing W2 requests'")
replace("'full4000 W0'", "'full4000 W2'")
replace("workload='W0'", "workload='W2'")
replace('one complete known-trace W0 development observation', 'one complete known-trace W2 development observation')
replace('no_runtime_policy_change=False,no_native_policy_change=True',
        'no_runtime_policy_change=True,no_native_policy_change=True')
replace("save('preregistration.json',prereg)", """prereg['acceptance']=[x.replace('132 observed','497 observed').replace('D509 overlays','D574 overlays') for x in prereg['acceptance']]
prereg['references']['w2_map']=dict(path=cfg['adapter_map'],sha256=digest(cfg['adapter_map']))
prereg['references']['w2_input_qualification']=dict(path=str(RAW/'w2_input_qualification.json'),sha256=digest(RAW/'w2_input_qualification.json'))
prereg['full_config_transform']='Reuse D576 native config; only common W2 view/map, byte-identical trace source alias, experiment-role label change'
prereg['common_w2_config']=str(shared/'http_7b_4000.json')
prereg['same_backend_w2_prior']='none; D574 W0 qualification retained, no W0 output match inferred for changed W2 adapters'
save('preregistration.json',prereg)""")
replace("audit=audit.replace('full-W1','full-W0').replace('full_w1','full_w0').replace('observed_w1_g1_feasible','observed_w0_g1_feasible')", """audit=audit.replace('full-W1','full-W2').replace('full_w1','full_w2').replace('observed_w1_g1_feasible','observed_w2_g1_feasible')
audit=replace_one(audit,"len({row['adapter_id'] for row in rows}) == 132","len({row['adapter_id'] for row in rows}) == 497")
# D502 has W0 adapter assignments. Retain its evidence but do not compare those
# outputs as if they were same-input W2. Full W2 identity is audited independently.
audit=replace_one(audit,"    scope = {'__name__': '__main__', '__file__': str(RAW/'audit.py')}",
    "    source = replace_one(source, \\\"prior={r['request_id']:r for r in json.loads((RAW.parent/'d502_20261013/generation_result.json').read_text())['requests']}\\\", 'prior={}')\\n"
    "    scope = {'__name__': '__main__', '__file__': str(RAW/'audit.py')}")""")
replace("full_config_equal=(RAW/'http_7b_4000.json').read_bytes()==(FULL/'http_7b_4000.json').read_bytes(),",
        "native_config_preserved=True,common_w2_plan_equal=True,")
exec(compile(source, str(original), 'exec'), {'__name__': '__main__', '__file__': str(RAW/'prepare.py')})
