#!/bin/sh
set -eu
test ! -e "/dev/shm/$HOST_SENTINEL"
test ! -e /dev/nvidiactl
cmp /probe/payload /dev/shm/psm_primelora_d481
/usr/local/bin/primelora-probe-busybox wget -q -Y off -O /tmp/payload http://127.77.48.10:8080/payload
cmp /probe/payload /tmp/payload
rm -- /dev/shm/psm_primelora_d481
printf 'SHARED_IPC_HTTP_PASS\n'
exec sleep 45
