"""Reuse D477/D478 bounded containers for a no-model IPC/HTTP witness.

Own loopback listener, private shared IPC, no CNI or host network changes. This
does NOT qualify HydraServe, pipeline source-IP identity, CUDA or LoRA arithmetic.
"""
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
OLD = RAW.parent/'d477_20261012'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW/name).open('x') as handle:
        json.dump(value, handle, indent=2)

identity = p.scope_identity(p.cg_path().name)
save('probe_identity.json', identity)
group = Path(identity['path'])
assert os.sched_getaffinity(0) == {2,26}
assert (group/'memory.max').read_text().strip() == str(512*p.MIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
gate = p.preflight([RAW], predicted_growth=512*p.MIB)
save('preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert json.loads((OLD/'container_affinity_attempt/container_context_closure.json').read_text())['passed']
runtime = Path('/run/user/1001/primelora-hydra-d477-proxy')
store = OLD/'container_proxy_attempt/container_storage'
assert runtime.is_dir() and runtime.stat().st_uid == os.getuid()
assert store.is_dir() and store.stat().st_uid == os.getuid()
(RAW/'empty_hooks').mkdir()
supervisor = group/'supervisor'
supervisor.mkdir()
(supervisor/'cgroup.procs').write_text(str(os.getpid()))
(group/'cgroup.subtree_control').write_text('+memory +pids')
env = {k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','LANG') if k in os.environ}
env.update(CONTAINERS_CONF=str(RAW/'containers.conf'), XDG_RUNTIME_DIR=str(runtime),
           REGISTRY_AUTH_FILE=str(RAW/'pull-auth.json'), CUDA_VISIBLE_DEVICES='')
base = ['podman','--root',str(store),'--runroot',str(runtime/'runroot'),
        '--storage-driver=vfs','--cgroup-manager=cgroupfs','--events-backend=file',
        '--runtime=/usr/bin/runc','--hooks-dir',str(RAW/'empty_hooks')]
commands, created, owners = [], [], {}
pause_owner, sentinel = None, None
result = dict(passed=False, kind='isolated_shared_ipc_loopback_http_no_model',
              native_backend_qualified=False, performance_result=False,
              pipeline_peer_identity_qualified=False, gpu_started=False)

def call(tag, args, check=True, timeout=30):
    started = time.monotonic()
    with (RAW/(tag+'.stdout')).open('x') as out, (RAW/(tag+'.stderr')).open('x') as err:
        run = subprocess.run(base+args, env=env, stdout=out, stderr=err, timeout=timeout)
    commands.append(dict(tag=tag, args=args, returncode=run.returncode,
                         elapsed_s=time.monotonic()-started))
    print(json.dumps(dict(tag=tag, returncode=run.returncode)), flush=True)
    if check:
        assert run.returncode == 0, tag
    return (RAW/(tag+'.stdout')).read_text(), run.returncode

def inspect(name, tag):
    raw, _ = call(tag, ['inspect', name])
    state = json.loads(raw)[0]
    assert state['Config']['Labels']['org.primelora.campaign'] == 'd481'
    return state

def qualify_owner(name, tag):
    state = inspect(name, tag)
    assert state['State']['Running']
    pid = state['State']['Pid']
    owner = p.gpu_process_identity(pid)
    assert owner and owner['uid'] == os.getuid()
    child = Path(owner['cgroup'])
    assert group in child.parents
    assert owner['affinity'] == [2,26]
    limits = {k:(child/k).read_text().strip() for k in ('memory.max','memory.swap.max','pids.max')}
    assert limits == {'memory.max':str(128*p.MIB),'memory.swap.max':'0','pids.max':'128'}
    namespaces = {k:os.readlink(f'/proc/{pid}/ns/{k}') for k in ('ipc','net')}
    owners[name] = owner
    save(tag+'_ownership.json', dict(identity=owner, limits=limits, namespaces=namespaces))
    return state, namespaces

try:
    # Verify address availability, no interface/route/firewall modifications.
    with socket.socket() as probe:
        probe.bind(('127.77.48.10', 8080))
    info = json.loads(call('info', ['info','--format=json'])[0])
    assert info['store']['graphRoot'] == str(store)
    pausefile = runtime/'libpod/tmp/pause.pid'
    assert pausefile.stat().st_uid == os.getuid()
    pid = int(pausefile.read_text())
    before = p.gpu_process_identity(pid)
    assert before and before['uid'] == os.getuid()
    assert Path(f'/proc/{pid}/comm').read_text().strip() == 'podman pause'
    oldgroup = Path(before['cgroup'])
    assert re.fullmatch(r'podman-pause-[0-9]+\.scope', oldgroup.name)
    oldunit = dict(line.split('=',1) for line in subprocess.check_output([
        'systemctl','--user','show',oldgroup.name,'-p','InvocationID','-p','ControlGroup'],text=True).splitlines())
    assert Path('/sys/fs/cgroup'+oldunit['ControlGroup']) == oldgroup
    assert [row['pid'] for row in p.owned_pids(oldgroup)] == [pid]
    boot = next(int(line.split()[1]) for line in Path('/proc/stat').read_text().splitlines() if line.startswith('btime '))
    assert abs(boot+before['start_ticks']/os.sysconf('SC_CLK_TCK')-pausefile.stat().st_mtime) < 5
    assert p.gpu_process_identity(pid) == before
    (supervisor/'cgroup.procs').write_text(str(pid))
    os.sched_setaffinity(pid, {2,26})
    pause_owner = p.gpu_process_identity(pid)
    assert pause_owner['start_ticks'] == before['start_ticks']
    assert Path(pause_owner['cgroup']) == supervisor
    assert not (oldgroup/'cgroup.procs').read_text().split()
    assert subprocess.check_output(['systemctl','--user','show',oldgroup.name,'-p','InvocationID','--value'],text=True).strip() == oldunit['InvocationID']
    subprocess.run(['systemctl','--user','stop',oldgroup.name],check=True)
    save('pause_adoption.json',dict(before=before, after=pause_owner, original=oldunit,
                                  before_container_start=True))
    assert not call('prior_containers',['ps','-aq'])[0].strip()
    image = json.loads(call('image',['image','inspect','docker.io/library/ubuntu:22.04'])[0])[0]
    assert image['Id'] == json.loads((OLD/'container_proxy_attempt/image_identity.json').read_text())['Id']
    save('image_identity.json',{k:image.get(k) for k in ('Id','Digest','Size','Architecture','Os')})
    payload = b'primelora-d481-private-shared-memory-and-http\n'
    with (RAW/'payload').open('xb') as handle:
        handle.write(payload)
    sentinel_fd, sentinel_name = tempfile.mkstemp(prefix='primelora-d481-',dir='/dev/shm')
    os.close(sentinel_fd)
    sentinel = Path(sentinel_name)
    # The sentinel is this test's own tiny data, not an unrelated shm object.
    sentinel.write_bytes(payload)
    sentinel_inode = sentinel.stat().st_ino
    common = ['--pull=never','--cgroups=enabled',
        '--cgroup-parent='+str(group).removeprefix('/sys/fs/cgroup'),
        '--memory=128m','--memory-swap=128m','--pids-limit=128','--network=host',
        '--http-proxy=false','--read-only','--cap-drop=ALL',
        '--security-opt=no-new-privileges','--security-opt=label=disable',
        '--label=org.primelora.campaign=d481','--timeout=90',
        '--tmpfs=/tmp:rw,size=16m','--env=HOST_SENTINEL='+sentinel.name,
        '--volume='+str(RAW)+':/probe:ro',
        '--volume=/usr/bin/busybox:/usr/local/bin/primelora-probe-busybox:ro']
    storage_name = 'primelora-hydra-d481-storage'
    created.append(storage_name)
    storage_id = call('run_storage',['run','--detach','--name='+storage_name,
        *common,'--ipc=private','--shm-size=64m',image['Id'],
        '/usr/bin/taskset','-c','2,26','/bin/sh','/probe/storage_probe.sh'])[0].strip()
    storage_state, storage_ns = qualify_owner(storage_name,'inspect_storage')
    assert storage_ns['ipc'] != os.readlink('/proc/self/ns/ipc')
    assert storage_ns['net'] == os.readlink('/proc/self/ns/net')
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open('http://127.77.48.10:8080/payload',timeout=5) as response:
        assert response.read(4096) == payload
    worker_name = 'primelora-hydra-d481-worker'
    created.append(worker_name)
    call('run_worker',['run','--detach','--name='+worker_name,*common,
        '--ipc=container:'+storage_id,image['Id'],
        '/usr/bin/taskset','-c','2,26','/bin/sh','/probe/worker_probe.sh'])
    worker_state, worker_ns = qualify_owner(worker_name,'inspect_worker')
    assert storage_ns['ipc'] == worker_ns['ipc']
    assert storage_ns['net'] == worker_ns['net']
    for index in range(20):
        logs = call('worker_log_'+str(index),['logs',worker_name])[0]
        if 'SHARED_IPC_HTTP_PASS' in logs:
            break
        time.sleep(.1)
    assert 'SHARED_IPC_HTTP_PASS' in logs
    call('storage_shared_unlink',['exec',storage_name,'/usr/bin/taskset','-c','2,26',
        '/usr/bin/test','!','-e','/dev/shm/psm_primelora_d481'])
    assert sentinel.stat().st_ino == sentinel_inode and sentinel.read_bytes() == payload
    result.update(passed=True, actual_host_http=True, actual_container_http=True,
                  shared_ipc_between_containers=True, host_shm_isolated=True,
                  private_shm_bytes=64*p.MIB, cpu_affinity=[2,26], host_network=True,
                  kernel_network_isolation=False, network_configuration_changed=False)
except Exception as exc:
    result.update(error_type=type(exc).__name__, error=str(exc))
finally:
    cleanup = []
    for index,name in enumerate(reversed(created)):
        text, code = call('cleanup_inspect_'+str(index),['inspect',name],check=False)
        if code:
            cleanup.append(dict(name=name, exists=False, inspect_returncode=code))
            continue
        state = json.loads(text)[0]
        assert state['Config']['Labels']['org.primelora.campaign'] == 'd481'
        if state['State']['Running']:
            call('stop_'+str(index),['stop','--time=2',name])
        call('remove_'+str(index),['rm',name])
        owner = owners.get(name)
        if owner:
            current = p.gpu_process_identity(owner['pid'])
            assert current is None or current['start_ticks'] != owner['start_ticks']
        cleanup.append(dict(name=name, removed=True))
    if sentinel is not None:
        assert sentinel.stat().st_uid == os.getuid()
        assert sentinel.stat().st_ino == sentinel_inode and sentinel.read_bytes() == payload
        sentinel.unlink()
    if pause_owner is not None:
        current = p.gpu_process_identity(pause_owner['pid'])
        if current is not None:
            assert current == pause_owner
            fd = os.pidfd_open(current['pid'])
            try:
                assert p.gpu_process_identity(current['pid']) == current
                signal.pidfd_send_signal(fd,signal.SIGKILL)
            finally:
                os.close(fd)
    result.update(cleanup=cleanup, disk_free_after=shutil.disk_usage(RAW).free)
    save('commands.json',commands)
    save('result.json',result)
    print(json.dumps(result),flush=True)
sys.exit(0 if result['passed'] else 1)
