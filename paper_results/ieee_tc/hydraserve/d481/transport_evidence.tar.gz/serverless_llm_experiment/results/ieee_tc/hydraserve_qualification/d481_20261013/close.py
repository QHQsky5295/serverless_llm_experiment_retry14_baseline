"""Reuse exact scope identity and recursive-empty closure for D481 only."""
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
mode = sys.argv[1]
assert mode in ('probe','probe_retry','test','curation','backup_baseline','backup_main')
root = RAW/'fixture_retry' if mode == 'probe_retry' else RAW
name = 'probe' if mode == 'probe_retry' else mode
identity = json.loads((root/(name+'_identity.json')).read_text())
assert p.scope_still_owned(identity)
group = Path(identity['path'])
entries = {str(path):path.read_text().split() for path in group.rglob('cgroup.procs')}
assert entries and not any(entries.values())
resources = {k:(group/k).read_text().strip() for k in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert not group.exists()
result = dict(passed=True,identity=identity,resources=resources,actual_recursive_empty=True)
with (root/(name+'_closure.json')).open('x') as stream:
    json.dump(result,stream,indent=2)
print(json.dumps(result))
