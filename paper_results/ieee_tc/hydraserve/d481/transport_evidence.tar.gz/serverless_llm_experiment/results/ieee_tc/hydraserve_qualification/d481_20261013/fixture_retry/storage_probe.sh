#!/bin/sh
set -eu
test ! -e "/dev/shm/$HOST_SENTINEL"
test ! -e /dev/nvidiactl
cp /probe/payload /dev/shm/psm_primelora_d481
exec /usr/local/bin/busybox httpd -f -p 127.77.48.10:8080 -h /probe
