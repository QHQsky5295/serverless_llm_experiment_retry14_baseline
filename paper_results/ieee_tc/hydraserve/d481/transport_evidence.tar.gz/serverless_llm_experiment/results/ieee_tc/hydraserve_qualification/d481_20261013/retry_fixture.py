"""Reuse D481 probe with corrected multicall basename and preserved failure."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
assert json.loads((root/'probe_closure.json').read_text())['passed']
cid = (root/'run_storage.stdout').read_text().strip()
run = subprocess.run(['journalctl','--user','CONTAINER_ID_FULL='+cid,
                      '--no-pager','-o','json'],capture_output=True,text=True,check=True,timeout=10)
messages = [{k:row.get(k) for k in ('MESSAGE','__REALTIME_TIMESTAMP','CONTAINER_ID_FULL')}
            for row in map(json.loads,run.stdout.splitlines())]
assert any('primelora-probe-busybox: applet not found' in row['MESSAGE'] for row in messages)
with (root/'original_failure_journal.json').open('x') as handle:
    json.dump(messages,handle,indent=2)
source = (root/'probe.py').read_text()
source = source.replace("OLD = RAW.parent/'d477_20261012'",
                       "OLD = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d477_20261012')")
source = source.replace('primelora-probe-busybox','busybox')
source = source.replace("        if state['State']['Running']:\n",
    "        call('cleanup_logs_'+str(index),['logs',name],check=False)\n"
    "        if state['State']['Running']:\n")
source = source.replace("result.update(error_type=type(exc).__name__, error=str(exc))",
    "result.update(error_type=type(exc).__name__, error=str(exc))\n"
    "    import traceback\n"
    "    result['traceback'] = traceback.format_exc()")
with (root/'fixture_retry/source_identity.json').open('x') as handle:
    json.dump(dict(original_sha256=hashlib.sha256((root/'probe.py').read_bytes()).hexdigest(),
                   executed_sha256=hashlib.sha256(source.encode()).hexdigest(),
                   wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),handle,indent=2)
exec(compile(source, str(root/'probe.py'), 'exec'),
     {'__name__':'__main__','__file__':str(root/'fixture_retry/probe.py')})
