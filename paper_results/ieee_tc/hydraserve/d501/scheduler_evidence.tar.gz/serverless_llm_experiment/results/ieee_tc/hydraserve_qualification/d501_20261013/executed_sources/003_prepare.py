"""D500 measurement-only repair: PID namespaces and host pidfd cleanup."""
from pathlib import Path
import json
import sys
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d500_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
assert not json.loads((OLD/'generation_result.json').read_text())['passed']
failure=json.loads((OLD/'req_00000_native_events.json').read_text())
assert failure['terminal'] and sum(len(e['delta_token_ids']) for e in failure['events'])==152
for name in ('lora_registry.json','tokenizer_views.json','model_registration.json','online_sources.json','official_utils.py','official_scheduler.py'):
    with (RAW/name).open('xb') as f:f.write((OLD/name).read_bytes())
for name in ('launch.sh','close_audit.py','native_body.py'):
    with (RAW/name).open('x') as f:f.write((OLD/name).read_text().replace('d500','d501'))
source=(OLD/'request_witness.py').read_text().replace('d500','d501')
source=replace_one(source,'from HydraServe_project.runtime.request_contract import BoundRequest,FrozenRequest',
    'from HydraServe_project.runtime.request_contract import BoundRequest,FrozenRequest,matches_worker_process')
source=replace_one(source,"owners=[worker for worker in platform.workers.values() if worker.owner['pid']==bound.native_process['pid']]",
    "owners=[worker for worker in platform.workers.values() if matches_worker_process(\n"
    "                    bound.native_process,worker.owner,json.loads((worker.output/'entry.json').read_text()),\n"
    "                    Path('/proc/sys/kernel/random/boot_id').read_text().strip())]")
with (RAW/'request_witness.py').open('x') as f:f.write(source)
template=(OLD/'executed_prepare.py').read_text().replace('d500','d501')
template=replace_one(template,"body=(RAW/'native_body.py').read_text()",
'''# Native dependency Python lacks pidfd APIs; original host Python does cleanup.
old="""            fd = os.pidfd_open(current['pid'])
            try:
                assert p.gpu_process_identity(current['pid']) == current
                signal.pidfd_send_signal(fd,signal.SIGKILL)
            finally:
                os.close(fd)
"""
assert suffix.count(old)==1
suffix=suffix.replace(old,"            subprocess.run(['/usr/bin/python3','-B',str(RAW/'close_pause.py')],check=True,timeout=10)\\n")
body=(RAW/'native_body.py').read_text()''')
template=replace_one(template,"paths=[RAW/'probe.py',", "paths=[RAW/'close_pause.py',RAW/'probe.py',")
with (RAW/'executed_prepare.py').open('x') as f:f.write(template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
