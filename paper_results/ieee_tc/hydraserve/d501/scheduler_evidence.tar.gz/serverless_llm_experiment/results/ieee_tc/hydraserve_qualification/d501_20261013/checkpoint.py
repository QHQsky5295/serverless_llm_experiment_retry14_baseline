"""Reuse D499 bounded append-only curation for full-scheduler qualification."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d499_20261013/checkpoint.py').read_text()
source=source.replace("OLD=RAW.parent/'d498_20261013'", "OLD=RAW.parent/'d500_20261013'")
start=source.index('generations=[]')
end=source.index("tests=['tests.test",start)
source=source[:start]+'''for root in (OLD,RAW):
    assert json.loads((root/'closure.json').read_text())['actual_recursive_empty']
    for path,record in json.loads((root/'source_manifest.json').read_text()).items():
        assert p.digest(Path(record['snapshot']))==record['sha256'],path
failed=json.loads((OLD/'generation_result.json').read_text())
events=json.loads((OLD/'req_00000_native_events.json').read_text())
assert not failed['passed'] and failed['requests']==[] and not (OLD/'result.json').exists()
assert events['terminal'] and sum(len(e['delta_token_ids']) for e in events['events'])==152
assert json.loads((OLD/'launch_gate.json').read_text())['cleanup']['released']
generation=json.loads((RAW/'generation_result.json').read_text())
assert generation['passed'] and generation['full_scheduler_path_exercised']
assert generation['actual_native_idle_release'] and not generation['performance_result']
assert len(generation['requests'])==2
assert [r['actual_tokens'] for r in generation['requests']]==[152,89]
assert all(r['actual_tokens']==r['target_tokens'] for r in generation['requests'])
assert json.loads((RAW/'result.json').read_text())['passed']
assert json.loads((RAW/'native_scheduler_idle_release.json').read_text())['resource_gpus']==[[24]*4]
'''+source[end:]
source=source.replace("('shm_control','tokenizer_compat',", "('controller_runtime','shm_control','tokenizer_compat',")
source=source.replace('Ran 70 tests','Ran 75 tests').replace('cpu_tests_passed=70','cpu_tests_passed=75').replace('cpu_tests=70','cpu_tests=75')
start=source.index("url='https://")
end=source.index('protected=p.verify_seal',start)
source=source[:start]+source[end:]
start=source.index('paths=[BASE/name')
end=source.index('for root in (OLD,RAW):',start)
source=source[:start]+'''paths=[BASE/name for name in ('HydraServe_project/runtime/controller_runtime.py',
    'HydraServe_project/runtime/native_overlay_entry.py','HydraServe_project/runtime/request_contract.py',
    'tests/test_ieee_tc_hydraserve_controller_runtime.py',
    'docs/ieee_tc/D501_HYDRASERVE_NATIVE_SCHEDULER.md')]
'''+source[end:]
source=source.replace("hydraserve/d499'", "hydraserve/d501'").replace('generation_release_evidence.tar.gz','scheduler_evidence.tar.gz')
start=source.index('    d498_actual_gpu_generation_passed=')
end=source.index('    weight_bytes_copied=',start)
source=source[:start]+'''    d500_measurement_failure_preserved=True,d500_first_request_native_tokens=152,
    d501_actual_native_scheduler_generation_passed=True,completed_requests=2,
    actual_native_idle_release=True,remote_delivery_qualified=False,
    numerical_lora_equivalence_qualified=False,pipeline_and_consolidation_qualified=False,
'''+source[end:]
source=source.replace('Full native Scheduler and request-driven real-remote LoRA integration; no new model/trace/pool',
    'Request-driven real-remote LoRA integration then common full replay; no new model/trace/pool')
exec(compile(source,str(RAW/'checkpoint_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'checkpoint.py')})
