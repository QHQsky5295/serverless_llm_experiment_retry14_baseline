#!/bin/bash
set -euo pipefail
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d500_20261013
MAIN=/home/qhq/serverless_llm_experiment_retry14_baseline
export FAASLORA_TC_NVML_BINDING=/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py
export FAASLORA_TC_NVML_SHA256=4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea
export NO_PROXY="*" no_proxy="*" USE_TORCH=0 USE_TF=0
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1
exec systemd-run --user --scope --unit=primelora-tc-aux-d5000000000000000000000000000009 \
 -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 \
 taskset -c 2,3,26,27 /usr/bin/python3 -B "$MAIN/scripts/ieee_tc_preflight.py" \
 gated-launch --output "$RAW/launch_gate.json" --predicted-growth-gib 1 \
 --exec /home/qhq/serverless_llm_baselines/installs/hydraserve_native_d484_20261013/bin/python -B "$RAW/probe.py" >"$RAW/launch.log" 2>&1
