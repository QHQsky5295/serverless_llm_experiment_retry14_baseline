"""Reuse previous exact-owned preparation scope closure for D500 CPU1/2."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d499_20261013/close_prepare.py').read_text().replace('d499','d500').replace('(1,2,6)','(1,2)')
exec(compile(source,str(RAW/'close_prepare.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'close_prepare.py')})
