"""Reuse exact-file checks and push gate for the D501 qualification checkpoint."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d499_20261013/backup.py').read_text().replace('d499','d501').replace('D499','D501')
source=source.replace("'HydraServe_project/runtime/shm_control.py',", "'HydraServe_project/runtime/controller_runtime.py',\n        'HydraServe_project/runtime/native_overlay_entry.py',")
source=source.replace('HydraServe_project/runtime/native_delivery.py','HydraServe_project/runtime/request_contract.py')
source=source.replace('tests/test_ieee_tc_hydraserve_shm_control.py','tests/test_ieee_tc_hydraserve_controller_runtime.py')
source=source.replace('D501_HYDRASERVE_GENERATION_AND_RELEASE.md','D501_HYDRASERVE_NATIVE_SCHEDULER.md')
source=source.replace('generation_release_evidence.tar.gz','scheduler_evidence.tar.gz')
source=source.replace("('shm_control','tokenizer_compat'", "('controller_runtime','shm_control','tokenizer_compat'")
source=source.replace('qualify native HydraServe generation and SHM release before worker deletion',
    'qualify full native HydraServe scheduler generation and idle release')
exec(compile(source,str(RAW/'backup_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup.py')})
