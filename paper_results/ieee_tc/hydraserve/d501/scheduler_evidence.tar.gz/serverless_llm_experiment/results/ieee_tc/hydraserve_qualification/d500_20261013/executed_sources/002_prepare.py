"""Reuse D499 qualified native stack; replace manual Instance with Scheduler."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import urllib.request
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d499_20261013'
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
from HydraServe_project.runtime.controller_runtime import render_controller_sources,ALIASES
from HydraServe_project.scripts.probe_layer_identity import NATIVE
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((OLD/'generation_result.json').read_text())['passed']
for name in ('lora_registry.json','tokenizer_views.json'):
    with (RAW/name).open('xb') as f:f.write((OLD/name).read_bytes())
for name in ('launch.sh','close_audit.py'):
    source=(OLD/name).read_text().replace('d499','d500')
    if name=='launch.sh':
        source=source.replace('--exec /usr/bin/python3 -B', '--exec '+str(BASE/'installs/hydraserve_native_d484_20261013/bin/python')+' -B')
        source=source.replace('export PYTHONDONTWRITEBYTECODE=', 'export NO_PROXY="*" no_proxy="*" USE_TORCH=0 USE_TF=0\nexport PYTHONDONTWRITEBYTECODE=')
    with (RAW/name).open('x') as f:f.write(source)
sources=render_controller_sources(NATIVE)
online=[]
for name in ('utils','scheduler'):
    relative=ALIASES[name]
    url='https://raw.githubusercontent.com/LLMServe/HydraServe/8ae605de354ccfa2e9095514cdb4a9e9c56aa56b/'+relative
    with urllib.request.urlopen(url,timeout=20) as response:data=response.read(100000)
    assert data==(NATIVE/relative).read_bytes()
    with (RAW/('official_'+name+'.py')).open('xb') as f:f.write(data)
    online.append(dict(url=url,sha256=sha256(data).hexdigest()))
with (RAW/'online_sources.json').open('x') as f:json.dump(online,f,indent=2)
registration_path=NATIVE/'scripts/kubernetes/vllm/src/ModelInfo.py'
registration_source=registration_path.read_bytes();ns={}
exec(compile(registration_source,str(registration_path),'exec'),ns)
info=ns['ModelSet'][0]['test']['modelscope/Llama-2-7b-chat-ms']
with (RAW/'model_registration.json').open('x') as f:json.dump(dict(source=str(registration_path),
    source_sha256=sha256(registration_source).hexdigest(),source_key='ModelSet[0]/test/modelscope/Llama-2-7b-chat-ms',
    mapped_model='llama2_7b',model_info=info,scope='qualification_not_frozen_performance'),f,indent=2)
body=(OLD/'native_body.py').read_text().replace('d499','d500')
body=replace_one(body,"native_images=('native-image',)",
    "native_images=('registry.us-east-1.aliyuncs.com/kubernetes-fc/modelscope-vllm:v1',)")
start=body.index("            ns=helper.load_resource(")
end=body.index('        finally:\n            await platform.close()',start)
body=body[:start]+'''            witness=importlib.util.spec_from_file_location('d500_scheduler_witness',RAW/'request_witness.py')
            module=importlib.util.module_from_spec(witness);witness.loader.exec_module(module)
            generation=await module.qualify(platform,RAW)
            assert generation['passed']
            result.update(passed=True,actual_cpu_provider=True,actual_private_storage=True,
                native_app_init=True,shared_memory_fastload=True,physical_nodes=1,gpu_started=True,
                native_generation_qualified=True,full_scheduler_path_exercised=True,
                actual_native_idle_release=True,request_lora_qualified=False,performance_result=False,
                qualification_scope='full original Scheduler cold start, two existing LoRA bindings, idle release; not numerical/remote/performance')
'''+body[end:]
with (RAW/'native_body.py').open('x') as f:f.write(body)
template=(OLD/'executed_prepare.py').read_text().replace('d499','d500')
template=replace_one(template,'overlays=render_overlays(NATIVE,request_contract=True,shm_control=True)',
    'overlays=render_overlays(NATIVE,request_contract=True,shm_control=True)\n'
    'from HydraServe_project.runtime.controller_runtime import render_controller_sources\n'
    'overlays.update(render_controller_sources(NATIVE))')
with (RAW/'executed_prepare.py').open('x') as f:f.write(template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
