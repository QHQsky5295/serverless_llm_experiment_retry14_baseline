"""Actual native Llama layers/manager at ModelRunner load boundaries.

Controlled pp4 rank3 -> pp2 rank1 native partition views on ONE GPU. No claim
of running a four/two-worker pipeline, fastload, KV migration or performance.
Backbone and two nonzero adapters are read-only existing assets, never generated.
"""
import ast
import copy
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace as NS

OUT = Path('/out')
BASE = Path('/home/qhq/serverless_llm_baselines')
NATIVE = BASE/'vendor_new_baselines/HydraServe_main_20260520'
MODEL = Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf')
POOL = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
sys.path.insert(0, str(BASE))

def save(name, obj):
    with (OUT/name).open('x') as f:
        json.dump(obj, f, indent=2)

save('worker_before_cuda.json', dict(pid=os.getpid(), affinity=sorted(os.sched_getaffinity(0)),
    cgroup=Path('/proc/self/cgroup').read_text(), time_monotonic=time.monotonic()))
deadline = time.monotonic()+60
while not (OUT/'permit_cuda.json').exists():
    if time.monotonic() > deadline:
        raise TimeoutError('worker containment not acknowledged')
    time.sleep(.1)
assert json.loads((OUT/'permit_cuda.json').read_text())['passed']
assert os.sched_getaffinity(0) == {2,3,26,27}
result = dict(passed=False, performance_result=False, full_model_qualified=False,
    pipeline_consolidation_qualified=False, stage_binding_qualified=False, rows=[])
try:
    import torch
    from safetensors import safe_open
    from transformers import LlamaConfig
    from vllm.config import LoRAConfig
    from vllm.distributed import init_distributed_environment, ensure_model_parallel_initialized
    from vllm.lora.request import LoRARequest
    from vllm.lora.layers import LoRAMapping
    from vllm.lora import layers as native_layers
    import vllm.model_executor.model_loader  # native public import order
    from vllm.model_executor.models.llama import LlamaForCausalLM
    from HydraServe_project.runtime import lora_worker_binding as binding
    from HydraServe_project.scripts.probe_layer_identity import collect_witness, native_functions
    torch.set_num_threads(2)
    torch.set_default_dtype(torch.float16)
    assert torch.cuda.device_count() == 1
    init_distributed_environment(world_size=1, rank=0, local_rank=0,
        distributed_init_method='file:///tmp/native-distributed', backend='nccl')
    ensure_model_parallel_initialized(1,1)
    witness = collect_witness()
    doc = dict(schema='hydraserve_native_partition_v1', total_layers=32,
        partitions=witness['partitions'], source='unchanged native get_layer_distribution',
        model_config_sha256=witness['model_config_sha256'], header_sha256=witness['header_sha256'])
    save('partition.json',doc)
    os.environ.update(HYDRASERVE_PARTITION_MANIFEST=str(OUT/'partition.json'),
        HYDRASERVE_PARTITION_SHA256=sha256((OUT/'partition.json').read_bytes()).hexdigest(),
        PP_RANK='3',PP_SIZE='4',DEST_PP_RANK='1',DEST_PP_SIZE='2')
    config = LlamaConfig.from_pretrained(MODEL, local_files_only=True)
    config.torch_dtype = torch.float16
    lo = LoRAConfig(max_lora_rank=8,max_loras=2,max_cpu_loras=2,
        lora_dtype=torch.float16,lora_extra_vocab_size=0)
    index = json.loads((MODEL/'model.safetensors.index.json').read_text())['weight_map']
    readers = {name:safe_open(str(MODEL/name),framework='pt',device='cpu') for name in set(index.values())}
    transforms = native_functions('scripts/kubernetes/vllm/download/download.py',
        {'getType','get_layer_distribution','transform'})
    transform = transforms['transform']
    old_ends, dest_ends = doc['partitions'][4], doc['partitions'][2]
    duplicate, original_weights, new_weights = {}, [], []
    for key, shard in index.items():
        if 'rotary' in key:
            continue
        old_rank, old_name = transform(key,old_ends,None)
        new_rank, new_name = transform(key,dest_ends,None)
        if old_rank == 3:
            original_weights.append((old_name,key,shard))
        if new_rank == 1:
            if old_rank == 3:
                duplicate[old_name] = new_name
            else:
                new_weights.append((new_name,key,shard))
    save('duplicate_state_dict-1-2.json',duplicate)
    os.environ['DEST_MODEL_PATH'] = str(OUT/'dest_model-1-2.safetensors')
    loads = []
    def existing_model_factory(**kwargs):
        destination = bool(loads)
        conf = copy.deepcopy(config)
        ends, rank = (dest_ends,1) if destination else (old_ends,3)
        conf.num_hidden_layers = ends[rank] - (ends[rank-1] if rank else 0)
        with torch.device('cuda:0'):
            model = LlamaForCausalLM(conf,lora_config=lo)
        entries = new_weights if destination else original_weights
        model.load_weights((local,readers[shard].get_tensor(global_name)) for local,global_name,shard in entries)
        torch.cuda.synchronize()
        loads.append(dict(destination=destination,loaded_tensors=len(entries),layer_count=conf.num_hidden_layers))
        return model.eval()
    # Execute the integrated real ModelRunner load functions, not inert manager
    # substitutes. Only its storage get_model factory is controlled here so we
    # can read existing shards without rewriting a partitioned checkpoint.
    overlay, removed = binding.render_overlay(NATIVE)
    binding.verify_inverse(overlay, removed, NATIVE)
    import vllm.worker.model_runner as native_runner
    namespace = dict(vars(native_runner))
    namespace.update(_hydra_bind_initial=binding.bind_initial,
                     _hydra_bind_destination=binding.bind_destination,
                     get_model=existing_model_factory)
    runner_node = next(n for n in ast.parse(overlay).body if isinstance(n,ast.ClassDef) and n.name=='ModelRunner')
    methods = [n for n in runner_node.body if getattr(n,'name',None) in ('load_model','load_dest_model')]
    exec(compile(ast.fix_missing_locations(ast.Module(body=methods,type_ignores=[])),str(NATIVE/binding.RUNNER),'exec'),namespace)
    runner = NS(model_config=None,device_config=None,load_config=None,lora_config=lo,
        vision_language_config=None,parallel_config=None, scheduler_config=NS(max_num_seqs=8,max_num_batched_tokens=8),
        vocab_size=config.vocab_size,device=torch.device('cuda:0'),kv_cache_dtype='auto')
    runner.model_config = NS(quantization_param_path=None)
    with torch.inference_mode():
        namespace['load_model'](runner)
    old = runner.model
    worker = runner.lora_manager
    manager = worker._lora_manager
    adapters = ['finance_lora','medical_lora']
    expected_sha = ['971901c3140f83f57cbb19fcc86d33b4d010f6d8fc15fbec621f0347bc31a258',
                    'd2b1dcfe42193917d0b2e0f728e735f24ad119dd2c77cb9b20c983c7f688fa5c']
    ar = []
    for name, expected in zip(adapters,expected_sha):
        path = POOL/name/'adapter_model.safetensors'
        assert sha256(path.read_bytes()).hexdigest() == expected
        ar.append(safe_open(str(path),framework='pt',device='cpu'))
    requests = {LoRARequest(name,i+1,str(POOL/name)) for i,name in enumerate(adapters)}
    mapping = LoRAMapping([0,1,2,1,2,1,2,1],[0,1,2,1,2,1,2,1])
    with torch.inference_mode():
        worker.set_active_loras(requests,mapping)
    slots_before = list(manager.lora_index_to_id)
    shared = {name:module for name,module in manager.modules.items()}
    ptr_before = {name:module.indices.data_ptr() for name,module in shared.items() if hasattr(module,'indices')}
    os.environ.update(PP_RANK='1',PP_SIZE='2')
    with torch.inference_mode():
        namespace['load_dest_model'](runner)
    assert runner.dest_model.lora_manager is old.lora_manager is manager
    assert manager.lora_index_to_id == slots_before
    assert all(manager.modules[name] is module for name,module in shared.items())
    assert all(manager.modules[name].indices.data_ptr() == ptr for name,ptr in ptr_before.items())
    assert runner.dest_model.lm_head is old.lm_head
    assert runner.dest_model.logits_processor is old.logits_processor
    assert all(runner.dest_model.model.layers[global_i-dest_ends[0]] is old.model.layers[i]
               for i,global_i in enumerate(range(old_ends[2],old_ends[3])))
    # Exercise the inherited batch mapping again AFTER destination attachment.
    # Already-active adapters early-return natively: new layers must be filled.
    with torch.inference_mode():
        worker.set_active_loras(requests,mapping)
    torch.manual_seed(719)
    inputs = torch.randn(8,4096,dtype=torch.float16)
    x = inputs.cuda()
    for global_i in range(dest_ends[0],dest_ends[1]):
        for packed in ('qkv_proj','o_proj'):
            name = f'model.layers.{global_i}.self_attn.{packed}'
            module = manager.modules[name]
            projs = ('q_proj','k_proj','v_proj') if packed=='qkv_proj' else ('o_proj',)
            reference_parts = []
            for proj in projs:
                ref = torch.zeros(8,4096,dtype=torch.float32)
                key = f'base_model.model.model.layers.{global_i}.self_attn.{proj}'
                for identifier,reader in enumerate(ar,1):
                    mask = torch.tensor(mapping.index_mapping)==identifier
                    a = reader.get_tensor(key+'.lora_A.weight').float()
                    b = reader.get_tensor(key+'.lora_B.weight').float()
                    ref[mask] = inputs[mask].float()@a.T@b.T*2.0
                reference_parts.append(ref)
            reference = torch.cat(reference_parts,dim=1)
            out = torch.zeros_like(reference,dtype=torch.float16,device='cuda')
            with torch.inference_mode():
                if packed=='qkv_proj':
                    native_layers._apply_lora_packed_nslice(x,module.lora_a_stacked,module.lora_b_stacked,
                        module.indices[:module.indices_len[0]],out,module.output_slices)
                else:
                    native_layers._apply_lora(x,module.lora_a_stacked,module.lora_b_stacked,
                        module.indices[:module.indices_len[0]],out)
                full = module(x)[0]
                base = module.base_layer(x)[0]
            torch.cuda.synchronize()
            actual = out.cpu().float()
            rel = float(torch.linalg.vector_norm(actual-reference)/torch.linalg.vector_norm(reference))
            assert rel <= .005 and torch.count_nonzero(actual[1:])>0
            assert torch.count_nonzero(actual[0]) == 0
            torch.testing.assert_close(actual.half(),reference.half(),rtol=.005,atol=.005)
            torch.testing.assert_close(full,(base.float()+reference.cuda()).half(),rtol=.005,atol=.005)
            result['rows'].append(dict(module=name,relative_l2_error=rel,
                max_absolute_error=float((actual-reference).abs().max()),full_linear_forward_passed=True,
                nonzero_update=True,no_adapter_row_zero=True))
        print('NATIVE_BOUND_GLOBAL_LAYER_PASSED',global_i,flush=True)
    result.update(passed=True,stage_binding_qualified=True,loads=loads,
        partitions=doc['partitions'],global_layers_checked=list(range(dest_ends[0],dest_ends[1])),
        native_load_boundaries_executed=True,source_overlay_sha256=sha256(overlay).hexdigest(),
        native_worker_manager=True,one_mapping_owner=True,active_slots_preserved=True,
        shared_head_processor=True,shared_decoder_count=len(old.model.layers),
        inherited_lru_and_activation=True,native_model_loader_fastload_qualified=False,
        modules_compared=len(result['rows']),gpu_peak_allocated_bytes=torch.cuda.max_memory_allocated(),
        gpu_peak_reserved_bytes=torch.cuda.max_memory_reserved(),model_memory_usage=runner.model_memory_usage,
        limitations=['Controlled get_model factory only; not complete service or fastload.',
                    'No attention/KV/pipeline transport or end-to-end token result.'])
except Exception as exc:
    result.update(error_type=type(exc).__name__,error=str(exc))
    raise
finally:
    save('native_gpu_result.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
