"""Reuse D488 qualified actual-container guard/ownership/cleanup.

Only functional qualification capacity changes: parent10/12GiB and child10GiB,
swap0, same four auxiliary CPUs. No performance run; actual model views up to
half of 7B are loaded, not four fictitious physical nodes. No cluster access.
"""
from hashlib import sha256
import os
from pathlib import Path
import signal
HERE = Path(__file__).resolve().parent
assert hasattr(os,'pidfd_open') and hasattr(signal,'pidfd_send_signal')
path = HERE.parent/'d488_20261013/executed_probe.py'
raw = path.read_bytes()
assert sha256(raw).hexdigest() == 'f3ef809927d8ff8fcd4ad6fdb2fcf15c7c5ebcea2fede574f53e8b624646a71e'
source = raw.decode().replace('d488','d489').replace('D488','D489')
source = source.replace('str(4*p.GIB)', 'str(12*p.GIB)')
source = source.replace('str(2*p.GIB)', 'str(10*p.GIB)')
source = source.replace("'--memory=2g','--memory-swap=2g'", "'--memory=10g','--memory-swap=10g'")
source = source.replace("'--timeout=300'", "'--timeout=900'").replace('<= 300,', '<= 900,')
source = source.replace("'--tmpfs=/tmp:rw,size=128m'", "'--tmpfs=/tmp:rw,size=256m'")
source = source.replace("    readonly += [pool/'finance_lora',pool/'medical_lora']", "    readonly += [pool/'finance_lora',pool/'medical_lora', Path('/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf'), Path('/home/qhq/serverless_llm_baselines/HydraServe_project'), Path('/home/qhq/serverless_llm_baselines/Loquetier_project')]")
source = source.replace("witness['modules_compared']==128", "witness['stage_binding_qualified'] and witness['native_load_boundaries_executed']")
source = source.replace("kind='native CUDA and existing nonzero LoRA arithmetic'", "kind='native model load-boundary shared LoRA binding'")
compile(source,'d489_container_driver','exec')
with (HERE/'executed_probe.py').open('x') as f:
    f.write(source)
exec(compile(source,str(HERE/'executed_probe.py'),'exec'),{'__name__':'__main__','__file__':str(HERE/'executed_probe.py')})
