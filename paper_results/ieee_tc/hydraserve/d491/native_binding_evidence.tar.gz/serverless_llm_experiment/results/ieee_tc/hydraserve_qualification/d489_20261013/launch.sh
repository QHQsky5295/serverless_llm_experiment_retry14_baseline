#!/bin/bash
set -euo pipefail
exec systemd-run --user --scope --unit=primelora-tc-aux-d4890000000000000000000000000002 \
  -p MemoryHigh=10G -p MemoryMax=12G -p MemorySwapMax=0 \
  taskset -c 2,3,26,27 /usr/bin/python3 -B \
  /home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d489_20261013/probe.py \
  > /home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d489_20261013/launch.log 2>&1
