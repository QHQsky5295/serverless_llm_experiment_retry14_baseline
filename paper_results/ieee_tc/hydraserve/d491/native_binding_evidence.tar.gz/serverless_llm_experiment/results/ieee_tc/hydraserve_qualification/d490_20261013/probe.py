"""Continue D489 with the native public-loader import order.

Initial direct Llama import caused an upstream circular import before CUDA.
No native source, tensor, tolerance, resource limit or baseline policy changed.
"""
from hashlib import sha256
import json
from pathlib import Path
HERE = Path(__file__).resolve().parent
OLD = HERE.parent/'d489_20261013'
assert json.loads((OLD/'probe_closure.json').read_text())['actual_recursive_empty']
assert not json.loads((OLD/'result.json').read_text())['passed']
worker = (OLD/'native_gpu_witness.py').read_text()
needle = '    from vllm.model_executor.models.llama import LlamaForCausalLM\n'
assert worker.count(needle)==1
worker = worker.replace(needle, '    import vllm.model_executor.model_loader  # native public import order\n'+needle)
with (HERE/'native_gpu_witness.py').open('x') as f:
    f.write(worker)
driver = (OLD/'probe.py').read_text().replace('d489','d490').replace('D489','D490')
exec(compile(driver,str(OLD/'probe.py'),'exec'),{'__name__':'__main__','__file__':str(HERE/'probe.py')})
