"""D490 continuation using the complete ORIGINAL DefaultModelLoader boundary.

The prior controlled factory omitted native model.to(device), leaving native
RowParallel weights on CPU (its loader assigns param.data). Retain that failure.
Now substitute only the read-only shard iterator, not the loader's semantics.
"""
from hashlib import sha256
import json
from pathlib import Path
HERE = Path(__file__).resolve().parent
OLD = HERE.parent/'d490_20261013'
assert json.loads((OLD/'probe_closure.json').read_text())['actual_recursive_empty']
raw = (OLD/'native_gpu_witness.py').read_bytes()
assert sha256(raw).hexdigest() == '49252522d2cdc48e5cd052766a3cf16d9dcf3b8e46e67c58278705d1193eda97'
source = raw.decode()
start = source.index("        with torch.device('cuda:0'):\n")
end = source.index('        loads.append(',start)
source = source[:start]+'''        from vllm.config import LoadConfig, DeviceConfig
        from vllm.model_executor.model_loader.loader import DefaultModelLoader
        entries = new_weights if destination else original_weights
        loader = DefaultModelLoader(LoadConfig(load_format='safetensors'))
        loader._get_weights_iterator = lambda *args, **kwargs: (
            (local,readers[shard].get_tensor(global_name)) for local,global_name,shard in entries)
        native_config = NS(hf_config=conf,quantization=None,dtype=torch.float16,
            model=str(MODEL),revision=None)
        model = loader.load_model(model_config=native_config,
            device_config=DeviceConfig('cuda'), lora_config=lo,
            vision_language_config=None,parallel_config=None,scheduler_config=None)
        torch.cuda.synchronize()
'''+source[end:]
source = source.replace('native_model_loader_fastload_qualified=False,',
    'native_default_model_loader_executed=True,native_model_loader_fastload_qualified=False,')
compile(source,'d491_native_loader_witness','exec')
with (HERE/'native_gpu_witness.py').open('x') as f:
    f.write(source)
driver = (HERE.parent/'d489_20261013/probe.py').read_text().replace('d489','d491').replace('D489','D491')
exec(compile(driver,'d489_driver_reused','exec'),{'__name__':'__main__','__file__':str(HERE/'probe.py')})
