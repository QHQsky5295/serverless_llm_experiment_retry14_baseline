import json
from pathlib import Path
import subprocess
import sys
RAW = Path(__file__).resolve().parent
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
with (RAW/'test_identity.json').open('x') as f:
    json.dump(p.scope_identity(p.cg_path().name), f, indent=2)
with (RAW/'tests.log').open('x') as f:
    result = subprocess.run(['/usr/bin/python3','-B','-m','unittest',
        'tests.test_ieee_tc_hydraserve_worker_binding',
        'tests.test_ieee_tc_hydraserve_stage_binding','-v'], cwd=BASE,
        stdout=f, stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
