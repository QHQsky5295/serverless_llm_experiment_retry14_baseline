"""Reuse explicit staging, secrets/source/roundtrip/protected/remote-equality."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
template = RAW.parent/'d480_20261013/backup.py'
source = template.read_text().replace('d480','d491').replace('D480','D491')
start = source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end = source.index('else:\n    paths =',start)
source = source[:start]+'''    paths = ['HydraServe_project/runtime/lora_worker_binding.py',
        'tests/test_ieee_tc_hydraserve_worker_binding.py',
        'docs/ieee_tc/D491_HYDRASERVE_NATIVE_SHARED_LORA_BINDING.md',
        'paper_results/ieee_tc/hydraserve/d491/summary.json',
        'paper_results/ieee_tc/hydraserve/d491/native_binding_evidence.tar.gz']
    remote, branch = 'origin','main'
    smoke = ['tests.test_ieee_tc_hydraserve_worker_binding',
             'tests.test_ieee_tc_hydraserve_stage_binding',
             'tests.test_ieee_tc_hydraserve_layer_identity']
'''+source[end:]
source = source.replace('qualify HydraServe native platform injection seam on CPU',
    'qualify native model load-boundary shared LoRA binding on GPU')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup_reused.py')})
