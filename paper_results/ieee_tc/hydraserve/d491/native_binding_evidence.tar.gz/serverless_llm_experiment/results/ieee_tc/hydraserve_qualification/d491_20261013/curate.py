"""Explicit small evidence archive; successes/failures retained and SHA checked."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile
RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path,obj):
    with path.open('x') as f:
        json.dump(obj,f,indent=2)

save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
dirs = [RAW.parent/f'd{i}_20261013' for i in (489,490,491)]
closures = [json.loads((d/'probe_closure.json').read_text()) for d in dirs]
assert all(c['actual_recursive_empty'] for c in closures)
results = [json.loads((d/'result.json').read_text()) for d in dirs]
assert [r['passed'] for r in results] == [False,False,True]
assert all(r['gpu_released'] and not r['performance_result'] for r in results)
witness = results[-1]['arithmetic']
assert witness == json.loads((RAW/'output/native_gpu_result.json').read_text())
assert witness['native_default_model_loader_executed'] and witness['stage_binding_qualified']
assert witness['modules_compared']==32 and witness['shared_decoder_count']==8
expected = {f'model.layers.{i}.self_attn.{name}' for i in range(16,32) for name in ('qkv_proj','o_proj')}
assert {r['module'] for r in witness['rows']} == expected
assert all(r['relative_l2_error'] <= .005 and r['full_linear_forward_passed'] and
           r['nonzero_update'] and r['no_adapter_row_zero'] for r in witness['rows'])
protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
names = ['probe.py','executed_probe.py','native_gpu_witness.py','close.py','launch.sh',
    'containers.conf','launch.log','probe_identity.json','preflight.json','image_identity.json',
    'selected_gpu.json','pause_adoption.json','inspect_worker_ownership.json','worker_final_state.json',
    'worker_logs.stdout','worker_logs.stderr','guard.jsonl','result.json','commands.json',
    'output/native_gpu_result.json','output/worker_before_cuda.json','output/permit_cuda.json',
    'probe_closure.json','remove_0.stdout','remove_0.stderr']
files = [d/name for d in dirs for name in names]
files += [dirs[0]/name for name in ('test.py','tests.log','test_identity.json','test_closure.json')]
files += [d/'output'/name for d in dirs[1:] for name in ('partition.json','duplicate_state_dict-1-2.json')]
files += [BASE/name for name in ('HydraServe_project/runtime/lora_worker_binding.py',
    'HydraServe_project/runtime/lora_stage_binding.py','tests/test_ieee_tc_hydraserve_worker_binding.py',
    'docs/ieee_tc/D491_HYDRASERVE_NATIVE_SHARED_LORA_BINDING.md')]
files += [RAW/'curate.py',RAW/'backup.py']
manifest = {}
for path in files:
    assert path.stat().st_size < 1048576, path
    if path.suffix=='.py':
        compile(path.read_text(),str(path),'exec')
    manifest[str(path)] = dict(sha256=p.digest(path),bytes=path.stat().st_size)
dest = BASE/'paper_results/ieee_tc/hydraserve/d491'
dest.mkdir()
archive = dest/'native_binding_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in files:
        bundle.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle.getmembers():
        assert sha256(bundle.extractfile(member).read()).hexdigest() == manifest['/home/qhq/'+member.name]['sha256']
summary = dict(kind='native_load_boundary_shared_lora_binding',checkpoint_verified=True,
    performance_result=False,native_backend_qualified=False,full_model_qualified=False,
    fastload_qualified=False,pipeline_kv_migration_qualified=False,stage_binding_qualified=True,
    native_model_witness=witness,failed_attempts=[json.loads((d/'output/native_gpu_result.json').read_text()) for d in dirs[:2]],
    max_relative_l2_error=max(r['relative_l2_error'] for r in witness['rows']),
    max_absolute_error=max(r['max_absolute_error'] for r in witness['rows']),
    source_manifest=manifest,archive_sha256=p.digest(archive),tests_count=13,
    scope_closures=closures,protected_verification=protected,
    next='Actual isolated native platform/fastload/request identity and generation; no elementary CUDA/binding repeat.')
save(dest/'summary.json',summary)
receipt = dict(passed=True,source_count=len(files),archive_sha256=p.digest(archive),summary_sha256=p.digest(dest/'summary.json'))
save(RAW/'curation_result.json',receipt)
print(json.dumps(receipt))
