"""Reuse D495 explicit-file curation/protection and bounded CPU test procedure."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import urllib.request

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path, data):
    with path.open('x') as f:
        json.dump(data, f, indent=2)

save(RAW/'curation_identity.json', p.scope_identity(p.cg_path().name))
closed = []
for number, invocation in ((1, '0b174bbf77dd43ad85571910eb9b9069'),
                            (2, '77d858ba78e14d2d96929f3a135dec46')):
    ident = p.scope_identity('primelora-tc-aux-d496'+f'{number:028d}'+'.scope')
    assert ident['invocation_id'] == invocation
    group = Path(ident['path'])
    members = {str(x): x.read_text().split() for x in
               (group/'cgroup.procs', *group.rglob('cgroup.procs'))}
    assert not any(members.values()) and p.scope_still_owned(ident)
    stats = {k: (group/k).read_text().strip() for k in
             ('memory.peak', 'memory.events', 'memory.swap.current')}
    subprocess.run(['systemctl', '--user', 'stop', ident['unit']], check=True)
    assert not group.exists()
    closed.append(dict(identity=ident, actual_recursive_empty=True, stats=stats))
save(RAW/'cpu_scope_closures.json', closed)
tests = ['tests.test_ieee_tc_hydraserve_request_contract',
         'tests.test_ieee_tc_hydraserve_native_delivery',
         'tests.test_ieee_tc_hydraserve_isolated_platform',
         'tests.test_ieee_tc_hydraserve_platform_port',
         'tests.test_ieee_tc_hydraserve_stage_binding',
         'tests.test_ieee_tc_hydraserve_worker_binding',
         'tests.test_ieee_tc_hydraserve_layer_identity']
with (RAW/'cpu_tests.log').open('x') as f:
    subprocess.run([sys.executable, '-B', '-m', 'unittest', *tests, '-v'], cwd=BASE,
                   stdout=f, stderr=subprocess.STDOUT, check=True, timeout=30)
assert 'Ran 59 tests' in (RAW/'cpu_tests.log').read_text()
url = ('https://raw.githubusercontent.com/LLMServe/HydraServe/'
       '8ae605de354ccfa2e9095514cdb4a9e9c56aa56b/scripts/kubernetes/vllm/src/engine.py')
with urllib.request.urlopen(url, timeout=20) as r:
    raw = r.read(100000)
assert sha256(raw).hexdigest() == 'c0722e5512fd7ef88a19146f85850d9715fe8002baf49de4fe33aed377174337'
with (RAW/'upstream_engine.py').open('xb') as f:
    f.write(raw)
save(RAW/'online_source.json', dict(url=url, sha256=sha256(raw).hexdigest()))
protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
save(RAW/'protected_verification.json', protected)
paths = [RAW/n for n in ('checkpoint.py', 'backup.py', 'cpu_scope_closures.json',
    'cpu_tests.log', 'upstream_engine.py', 'online_source.json', 'protected_verification.json',
    'curation_identity.json')]
paths += [BASE/n for n in ('HydraServe_project/runtime/request_contract.py',
    'HydraServe_project/runtime/native_delivery.py',
    'tests/test_ieee_tc_hydraserve_request_contract.py',
    'docs/ieee_tc/D496_HYDRASERVE_REQUEST_CONTRACT.md')]
manifest = {str(x): dict(sha256=p.digest(x), bytes=x.stat().st_size) for x in paths}
dest = BASE/'paper_results/ieee_tc/hydraserve/d496'
dest.mkdir()
archive = dest/'request_contract_evidence.tar.gz'
with tarfile.open(archive, 'x:gz') as out:
    for path in paths:
        out.add(path, arcname=str(path).removeprefix('/home/qhq/'), recursive=False)
with tarfile.open(archive, 'r:gz') as bundle:
    for member in bundle.getmembers():
        assert sha256(bundle.extractfile(member).read()).hexdigest() == manifest['/home/qhq/'+member.name]['sha256']
summary = dict(checkpoint_verified=True, performance_result=False, cpu_tests_passed=59,
    actual_gpu_generation_qualified=False, remote_request_materialization_qualified=False,
    original_scheduler_policy_ast_unchanged=True, protected_verification=protected,
    source_manifest=manifest, archive_sha256=p.digest(archive),
    next='Actual native generation/binding; remote resolver; SHM control ownership; full original scheduler replay')
save(dest/'summary.json', summary)
save(RAW/'curation_result.json', dict(passed=True, summary_sha256=p.digest(dest/'summary.json'),
    archive_sha256=p.digest(archive), files=len(paths)))
print(json.dumps(dict(passed=True, cpu_tests=59, performance_result=False)))
