"""Reuse explicit D480 tested backup gate; do not stage user dirt or secrets."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
template = RAW.parent/'d480_20261013/backup.py'
source = template.read_text().replace('d480', 'd496').replace('D480', 'D496')
start = source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end = source.index('else:\n    paths =', start)
source = source[:start]+'''    paths = ['HydraServe_project/runtime/request_contract.py',
        'HydraServe_project/runtime/native_delivery.py',
        'tests/test_ieee_tc_hydraserve_request_contract.py',
        'docs/ieee_tc/D496_HYDRASERVE_REQUEST_CONTRACT.md',
        'paper_results/ieee_tc/hydraserve/d496/summary.json',
        'paper_results/ieee_tc/hydraserve/d496/request_contract_evidence.tar.gz']
    remote, branch = 'origin', 'main'
    smoke = ['tests.test_ieee_tc_hydraserve_request_contract',
             'tests.test_ieee_tc_hydraserve_native_delivery',
             'tests.test_ieee_tc_hydraserve_isolated_platform',
             'tests.test_ieee_tc_hydraserve_platform_port',
             'tests.test_ieee_tc_hydraserve_stage_binding',
             'tests.test_ieee_tc_hydraserve_worker_binding',
             'tests.test_ieee_tc_hydraserve_layer_identity']
'''+source[end:]
source = source.replace('qualify HydraServe native platform injection seam on CPU',
    'wire common request and native token contract through original HydraServe controller')
exec(compile(source, str(template), 'exec'), {'__name__': '__main__',
     '__file__': str(RAW/'backup_reused.py')})
