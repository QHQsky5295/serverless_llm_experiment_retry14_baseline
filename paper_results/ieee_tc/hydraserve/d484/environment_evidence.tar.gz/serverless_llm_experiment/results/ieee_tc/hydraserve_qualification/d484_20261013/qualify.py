"""Small CPU regression, using the established resource identity protocol."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
identity=p.scope_identity(p.cg_path().name)
with (RAW/'test_identity.json').open('x') as out:
    json.dump(identity,out,indent=2)
sources=[BASE/'scripts/ieee_tc_prepare_hydraserve_source_environment.py',
         BASE/'tests/test_ieee_tc_hydraserve_environment_reuse.py']
with (RAW/'test.log').open('x') as log:
    proc=subprocess.run([sys.executable,'-B','-m','unittest',
        'tests.test_ieee_tc_hydraserve_environment_reuse','-v'],cwd=BASE,
        stdout=log,stderr=subprocess.STDOUT,timeout=30)
result=dict(passed=proc.returncode==0,returncode=proc.returncode,
            sources={str(x):p.digest(x) for x in sources},log_sha256=p.digest(RAW/'test.log'))
with (RAW/'test_result.json').open('x') as out:
    json.dump(result,out,indent=2)
print(json.dumps(result))
sys.exit(proc.returncode)
