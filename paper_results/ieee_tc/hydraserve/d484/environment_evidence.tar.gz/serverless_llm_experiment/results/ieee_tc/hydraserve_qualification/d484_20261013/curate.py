"""D480 curation procedure with explicit D484 source and completed receipts."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile
RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as out:
        json.dump(value,out,indent=2)
save(RAW/'curation_identity.json',p.scope_identity(p.cg_path().name))
tests=json.loads((RAW/'test_result.json').read_text())
environment=json.loads((RAW/'environment_result.json').read_text())
closure=json.loads((RAW/'environment_closure.json').read_text())
assert tests['passed'] and environment['passed'] and closure['passed']
for name,expected in tests['sources'].items():
    assert p.digest(Path(name))==expected
protected=p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
names=['qualify.py','close.py','curate.py','backup.py','initial_test_note.md',
       'initial_test_identity.json','initial_test_closure.json',
       'test.log','test_result.json','test_identity.json','test_closure.json',
       'environment_identity.json','environment_preflight.json',
       'environment_result.json','environment_closure.json','cuda_reuse_manifest.json',
       'exact_wheels_report.json','dependencies_report.json']
for label in ('venv','exact_wheels','dependencies','pip_check','import_check','freeze'):
    names.extend([label+'.log',label+'_worker.json'])
files=[RAW/name for name in names]+[Path(name) for name in tests['sources']]
files += [BASE/'docs/ieee_tc/D484_HYDRASERVE_SOURCE_ENVIRONMENT.md']
manifest={str(path):dict(sha256=p.digest(path),bytes=path.stat().st_size) for path in files}
dest=BASE/'paper_results/ieee_tc/hydraserve/d484'
dest.mkdir()
archive=dest/'environment_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as bundle:
    for path in files:
        assert path.stat().st_size<2*1024*1024
        bundle.add(path,arcname=str(path).removeprefix('/home/qhq/'),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle.getmembers():
        assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest()==manifest['/home/qhq/'+member.name]['sha256']
summary=dict(kind='hydraserve_native_source_dependencies_checkpoint',checkpoint_verified=True,
    tests=tests,tests_count=4,environment=environment,closure=closure,
    source_manifest=manifest,archive_sha256=p.digest(archive),protected_verification=protected,
    native_backend_qualified=False,numerical_qualified=False,performance_result=False,
    upstream_commit='8ae605de354ccfa2e9095514cdb4a9e9c56aa56b',live_work=None)
save(dest/'summary.json',summary)
receipt=dict(passed=True,source_count=len(files),archive_sha256=p.digest(archive),
             summary_sha256=p.digest(dest/'summary.json'))
save(RAW/'curation_result.json',receipt)
print(json.dumps(receipt))
