# Initial CPU test launcher failure

2026-10-13, scope primelora-tc-aux-d4840000000000000000000000000001.scope.
Actual command exited1 before tests/environment creation. The tool returned:
ImportError: cannot import name 'ieee_tc_preflight' from 'scripts'
(/home/qhq/serverless_llm_baselines/scripts/__init__.py).
Both repositories have a scripts package; sys.path insertion does not replace
the already imported baseline scripts namespace. The only correction loads the
existing common preflight by explicit file/module identity using importlib.
This note is a transcription of the observed failure, not an original log SHA.
No CUDA, model, new environment, download, cluster or remote service was started.
