"""Reuse D480 tested/source/secrets/explicit-stage/remote verification."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
template=RAW.parent/'d480_20261013/backup.py'
source=template.read_text().replace('d480','d484').replace('D480','D484')
start=source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end=source.index("else:\n    paths =",start)
source=source[:start]+"""    paths = [
        'scripts/ieee_tc_prepare_hydraserve_source_environment.py',
        'tests/test_ieee_tc_hydraserve_environment_reuse.py',
        'docs/ieee_tc/D484_HYDRASERVE_SOURCE_ENVIRONMENT.md',
        'paper_results/ieee_tc/hydraserve/d484/summary.json',
        'paper_results/ieee_tc/hydraserve/d484/environment_evidence.tar.gz']
    remote, branch = 'origin','main'
    smoke = ['tests.test_ieee_tc_hydraserve_environment_reuse']
"""+source[end:]
source=source.replace('qualify HydraServe native platform injection seam on CPU',
                      'verify isolated HydraServe official source dependency environment')
exec(compile(source,str(template),'exec'),{'__name__':'__main__','__file__':str(RAW/'backup_reused.py')})
