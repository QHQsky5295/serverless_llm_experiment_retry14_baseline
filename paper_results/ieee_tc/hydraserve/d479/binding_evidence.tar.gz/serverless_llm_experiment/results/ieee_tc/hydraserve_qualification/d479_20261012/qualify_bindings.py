"""Small CPU-only native-coordinate adaptation tests while software bytes resume."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

RAW = Path(__file__).resolve().parent
BASE = Path('/home/qhq/serverless_llm_baselines')
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW / name).open('x') as handle:
        json.dump(value, handle, indent=2)

identity = p.scope_identity(p.cg_path().name)
save('test_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.max').read_text().strip() == str(256 * p.MIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 26}
native = BASE/'vendor_new_baselines/HydraServe_main_20260520'
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=native) == b''
files = ['HydraServe_project/runtime/lora_stage_binding.py',
         'tests/test_ieee_tc_hydraserve_stage_binding.py']
sources = {file: p.digest(BASE/file) for file in files}
started = time.monotonic()
with (RAW/'test.log').open('x') as log:
    run = subprocess.run([sys.executable, '-B', '-m', 'unittest',
        'tests.test_ieee_tc_hydraserve_stage_binding', '-v'], cwd=BASE,
        stdout=log, stderr=subprocess.STDOUT, timeout=30,
        env=dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONNOUSERSITE='1'))
result = dict(passed=run.returncode == 0, returncode=run.returncode,
              source_sha256=sources, elapsed_s=time.monotonic()-started,
              backend_installed=False, gpu_model_started=False,
              numerical_qualified=False, performance_result=False)
save('test_result.json', result)
print(json.dumps(result), flush=True)
sys.exit(run.returncode)
