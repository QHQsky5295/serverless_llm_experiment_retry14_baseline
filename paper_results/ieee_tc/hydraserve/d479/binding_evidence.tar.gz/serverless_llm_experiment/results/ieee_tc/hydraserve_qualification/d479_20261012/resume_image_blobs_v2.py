"""Continue D478's exact verified cache with bounded HTTP Range segments.

Revision of D478/resume_image_blobs.py, not a new image/mirror/backend. The first
resume ended in TimeoutError at 1233s, well below its 10800s wall guard. Keep its
evidence and bytes. Stream read1 records delivered partial data; bounded retry
reopens at the actual written offset. No GPU/import/model action.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request

RAW = Path(__file__).resolve().parent
PREVIOUS = RAW.parent/'d478_20261012'
OUT = RAW/'resume_attempt'
sys.path.insert(0, '/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)

OUT.mkdir(mode=0o700)
save(RAW/'resume_identity.json', p.scope_identity(p.cg_path().name))
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
gate = p.preflight([RAW], predicted_growth=4*p.GIB)
save(OUT/'preflight.json', gate)
assert gate['preflight_pass'], gate['issues']
assert json.loads((PREVIOUS/'resume_closure.json').read_text())['passed']
prior = json.loads((PREVIOUS/'resume_attempt/result.json').read_text())
assert not prior['passed'] and prior['error_type'] == 'TimeoutError'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid',
    '--format=csv,noheader'], text=True).strip()
audit = json.loads((PREVIOUS/'retained_cache_audit.json').read_text())
digest = 'sha256:7a5c182f2296dcafacf9576cf09c3d4d188eda4738d51c081a7ca009f0c4a32f'
raw_manifest = (PREVIOUS/'resume_attempt/manifest.raw.json').read_bytes()
assert 'sha256:'+hashlib.sha256(raw_manifest).hexdigest() == digest
manifest = json.loads(raw_manifest)
repo = 'kubernetes-fc/modelscope-vllm'
base = 'https://registry.us-east-1.aliyuncs.com/v2/'+repo+'/'

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        out = super().redirect_request(req, fp, code, msg, headers, newurl)
        if out and urllib.parse.urlsplit(newurl).netloc != urllib.parse.urlsplit(req.full_url).netloc:
            out.remove_header('Authorization')
        return out

opener = urllib.request.build_opener(SafeRedirect)
started = time.monotonic()
result = dict(passed=False, kind='segmented_resume_official_image_bytes',
    performance_result=False, model_started=False, image_imported=False,
    wall_limit_s=10800, segment_bytes=64*1024*1024, max_failures_per_blob=8,
    completed=[], attempt_failures=[])
token = None

def safety():
    if time.monotonic()-started > 10800:
        raise TimeoutError('download_wall_limit')
    if shutil.disk_usage(RAW).free < 100*p.GIB:
        raise RuntimeError('disk_runtime_floor')
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:')))*1024
    if available < 16*p.GIB:
        raise RuntimeError('host_memory_floor')

def authorize():
    global token
    auth = 'https://dockerauth-us-east-1.aliyuncs.com/auth?'+urllib.parse.urlencode({
        'service':'registry.aliyuncs.com:us-east-1:26842', 'scope':'repository:'+repo+':pull'})
    with opener.open(auth, timeout=30) as response:
        token = json.loads(response.read(65536))['token']

def get(blob, start, stop):
    return opener.open(urllib.request.Request(base+'blobs/'+blob, headers={
        'Authorization':'Bearer '+token, 'Range':f'bytes={start}-{stop}'}), timeout=30)

def error_summary(exc):
    reason = getattr(exc, 'reason', None)
    return dict(error_type=type(exc).__name__, reason_type=type(reason).__name__,
                reason_errno=getattr(reason, 'errno', None), http_status=getattr(exc, 'code', None))

try:
    authorize()
    layers = {item['digest']:item for item in manifest['layers']}
    partials = [row for row in audit['files'] if not row['verified']]
    for blob in sorted(audit['missing_digests'], key=lambda d:layers[d]['size']):
        size = layers[blob]['size']
        matched = list(partials)
        probes = []
        for offset in (0, 1048576):
            safety()
            with get(blob, offset, offset+4095) as response:
                assert response.status == 206
                assert response.headers.get('Content-Range') == f'bytes {offset}-{offset+4095}/{size}'
                data = response.read(4097)
            assert len(data) == 4096
            candidates = []
            for row in matched:
                with Path(row['path']).open('rb') as stream:
                    stream.seek(offset)
                    if stream.read(4096) == data:
                        candidates.append(row)
            matched = candidates
            probes.append(dict(offset=offset, sha256=hashlib.sha256(data).hexdigest()))
        assert len(matched) == 1
        row = matched[0]
        path = Path(row['path'])
        stamp = path.stat()
        assert stamp.st_ino == row['inode'] and stamp.st_uid == os.getuid()
        assert row['bytes'] <= stamp.st_size < size
        offset = stamp.st_size
        save(OUT/(blob.split(':')[1]+'.resume.json'), dict(digest=blob, path=str(path),
             inode=stamp.st_ino, initial_bytes=offset, total_bytes=size, probes=probes))
        failures = 0
        last_report = time.monotonic()
        while offset < size:
            safety()
            stop = min(size-1, offset+result['segment_bytes']-1)
            try:
                with get(blob, offset, stop) as response:
                    assert response.status == 206
                    assert response.headers.get('Content-Range') == f'bytes {offset}-{stop}/{size}'
                    assert int(response.headers['Content-Length']) == stop-offset+1
                    with path.open('ab', buffering=0) as stream:
                        current = os.fstat(stream.fileno())
                        assert current.st_ino == stamp.st_ino and current.st_size == offset
                        while offset <= stop:
                            safety()
                            data = response.read1(min(1024*1024, stop-offset+1))
                            if not data:
                                raise EOFError('incomplete_segment')
                            assert stream.write(data) == len(data)
                            offset += len(data)
                            if time.monotonic()-last_report >= 30:
                                print(json.dumps(dict(digest=blob, bytes=offset, total=size,
                                    free=shutil.disk_usage(RAW).free)), flush=True)
                                last_report = time.monotonic()
                        os.fsync(stream.fileno())
            except (TimeoutError, ConnectionError, EOFError, urllib.error.URLError) as exc:
                safety()
                failures += 1
                failure = dict(digest=blob, bytes=offset, failure_index=failures, **error_summary(exc))
                result['attempt_failures'].append(failure)
                print(json.dumps(failure), flush=True)
                # Byte/inode mismatch is never repaired by truncate/re-download.
                assert path.stat().st_ino == stamp.st_ino and path.stat().st_size == offset
                if failures >= result['max_failures_per_blob']:
                    raise
                time.sleep(min(2**failures, 30))
                authorize()
        assert path.stat().st_size == size
        assert 'sha256:'+p.digest(path) == blob
        entry = dict(digest=blob, path=str(path), bytes=size,
                     initial_bytes=stamp.st_size, verified=True)
        save(OUT/(blob.split(':')[1]+'.verified.json'), entry)
        result['completed'].append(entry)
        print(json.dumps(entry), flush=True)
    result['passed'] = True
except Exception as exc:
    result.update(error_summary(exc))
finally:
    result.update(elapsed_s=time.monotonic()-started, disk_free=shutil.disk_usage(RAW).free)
    save(OUT/'result.json', result)
    print(json.dumps(result), flush=True)
sys.exit(0 if result['passed'] else 1)
