"""Read-only D414 timing recheck; not a new performance or numerical experiment."""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(name, value):
    with (RAW/name).open('x') as f:
        json.dump(value, f, indent=2)

identity = p.scope_identity(p.cg_path().name)
save('recheck_identity.json', identity)
limits = p.cgroup_snapshot(Path(identity['path']))
assert limits['memory.max'] == 256*1024**2 and limits['memory.swap.max'] == 0
assert os.sched_getaffinity(0) == {2, 26}
audit_path = MAIN/'paper_results/ieee_tc/baseline_audit/d414_7b_full_w0/audit.json'
audit = json.loads(audit_path.read_text())
assert p.digest(audit_path) == '714a2fdb01b2d5a0e2e6f3a9b0faf7cb23b29632efbf5b343822b7dfe4b7dd74'
freeze_path = Path(audit['common_slo']['freeze_path'])
assert p.digest(freeze_path) == audit['common_slo']['freeze_sha256']
freeze = json.loads(freeze_path.read_text())
assert p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md') == freeze['metric_protocol_sha256']
assert p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md') == freeze['single_run_amendment_sha256']
analyzer_path = MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py'
spec = importlib.util.spec_from_file_location('existing_slo_auditor', analyzer_path)
analyzer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analyzer)
contracts, arrivals, native, submitted, terminal = {}, {}, {}, set(), None
sha = hashlib.sha256()
with Path(audit['replay_path']).open('rb') as f:
    for line in f:
        sha.update(line)
        r = json.loads(line)
        event, rid = r['event'], r.get('request_id')
        if event == 'replay_ready':
            clock = r['clock_id']
            assert r['plan'] == audit['source_plan'] or all(
                r['plan'][k] == v for k, v in audit['source_plan'].items())
        elif event == 'request_contract':
            assert rid not in contracts
            contracts[rid] = r
        elif event == 'request_created':
            assert rid not in arrivals
            arrivals[rid] = r['planned_arrival_s']
        elif event == 'http_headers_sent':
            assert rid not in submitted
            submitted.add(rid)
        elif event == 'http_raw_response':
            assert rid not in native and r['status'] == 200
            n = r['body']['metrics']['ieee_tc']
            c = contracts[rid]
            assert n['native_clock_id'] == clock and n['native_terminal_observed']
            assert n['native_lora_name'] == c['adapter_id']
            assert n['native_prompt_token_ids_sha256'] == c['native_prompt_token_ids_sha256']
            assert n['native_output_tokens'] == len(n['completion_token_ids']) == c['target_tokens']
            for key in ('native_prompt_token_ids', 'completion_token_ids'):
                assert hashlib.sha256(json.dumps(n[key], separators=(',', ':')).encode()).hexdigest() == n[key+'_sha256']
            native[rid] = n
        elif event == 'http_replay_complete':
            assert terminal is None
            terminal = r
assert sha.hexdigest() == audit['replay_sha256']
assert len(contracts) == 4000 and set(contracts) == set(arrivals) == set(native) == submitted
assert terminal['N_plan'] == terminal['N_arrived'] == terminal['N_terminal'] == terminal['N_response'] == 4000
assert terminal['N_failed'] == 0
rows = []
for rid, n in native.items():
    first, last = n['native_first_token_monotonic_s'], n['native_last_token_monotonic_s']
    count = n['native_output_tokens']
    assert arrivals[rid] <= first <= last and count >= 2
    ttft, tpot = 1000*(first-arrivals[rid]), 1000*(last-first)/(count-1)
    assert math.isfinite(ttft) and math.isfinite(tpot)
    assert abs(tpot-n['native_tpot_ms']) <= .001
    rows.append(dict(request_id=rid, status='http_response', actual_tokens=count,
                     target_tokens=contracts[rid]['target_tokens'], ttft_ms=ttft, tpot_ms=tpot))
rows.sort(key=lambda r: r['request_id'])
slo = analyzer.frozen_slo_summary(rows, native, freeze['groups'])
for k, v in slo.items():
    assert audit['common_slo'][k] == v, (k, v)
stats = {k: analyzer.timing_stats([r[k] for r in rows]) for k in ('ttft_ms', 'tpot_ms')}
for k in stats:
    for key, value in stats[k].items():
        assert abs(value-audit['conditional_metrics'][k][key]) < 1e-8
phases = []
for start in range(0, 4000, 500):
    subset = rows[start:start+500]
    phase = dict(first_index=start, last_index=start+499,
                 common_slo=analyzer.frozen_slo_summary(subset, native, freeze['groups']),
                 ttft=analyzer.timing_stats([r['ttft_ms'] for r in subset]))
    assert phase['common_slo'] == audit['source_order_diagnostics'][start//500]['common_slo']
    phases.append(phase)
ordered = sorted(r['ttft_ms'] for r in rows)
result = dict(passed=True, new_performance_run=False, independent_numerical_proof=False,
    source_replay_sha256=sha.hexdigest(), audit_sha256=p.digest(audit_path),
    analyzer_sha256=p.digest(analyzer_path), freeze_sha256=p.digest(freeze_path),
    protocol_v1_sha256=freeze['metric_protocol_sha256'],
    amendment_v2_sha256=freeze['single_run_amendment_sha256'],
    counts=terminal, common_slo=slo, metrics=stats, source_order_phases=phases,
    extra_tail_diagnostics_ms=dict(p99_type1=ordered[math.ceil(.99*len(ordered))-1], maximum=ordered[-1]),
    physical_gpu_seconds=audit['physical_gpu_seconds'],
    physical_gpu_seconds_per_binding_valid_request=audit['physical_gpu_seconds']/len(rows),
    resource_provenance='Reuses sealed D414 allocation/release audit; not independently re-integrated here.',
    scope='Exact replay SHA + native clocks, IDs/counts and timing arithmetic; not a rerun of all content/worker/lifecycle validators.',
    limitations=['One reused development observation, not holdout or confidence interval.',
                 'Whole-run >=95% does not ensure startup phase >=95%; no phase or request removed.',
                 'Raw n_correct remains unknown; native contract is not independent numerical proof.'])
save('recheck_result.json', result)
print(json.dumps(dict(passed=True, common_slo=slo, metrics=stats,
                     extra_tail_diagnostics_ms=result['extra_tail_diagnostics_ms'])))
