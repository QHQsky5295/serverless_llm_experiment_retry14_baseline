"""Reuse exact-file backup, bundle/source/secrets/protected and remote-equality gates."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
template = RAW.parent/'d480_20261013/backup.py'
source = template.read_text().replace('d480', 'd486').replace('D480', 'D486')
start = source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end = source.index("else:\n    paths =", start)
source = source[:start]+"""    paths = ['docs/ieee_tc/D486_HYDRASERVE_NATIVE_INSTALL.md',
        'paper_results/ieee_tc/hydraserve/d486/summary.json',
        'paper_results/ieee_tc/hydraserve/d486/native_install_and_metric_recheck.tar.gz']
    remote, branch = 'origin','main'
    smoke = []
"""+source[end:]
source = source.replace("paths = ['docs/ieee_tc/EXECUTION_STATUS.md']", "paths = ['docs/ieee_tc/EXECUTION_STATUS.md', 'docs/ieee_tc/D486_METRIC_FAIRNESS_RECHECK.md', 'paper_results/ieee_tc/metric_audit/20261013_d486_serverlessllm_recheck.json']")
source = source.replace('qualify HydraServe native platform injection seam on CPU',
                        'verify original HydraServe library imports and recheck frozen SLO arithmetic')
exec(compile(source, str(template), 'exec'), {'__name__':'__main__', '__file__':str(RAW/'backup_reused.py')})
