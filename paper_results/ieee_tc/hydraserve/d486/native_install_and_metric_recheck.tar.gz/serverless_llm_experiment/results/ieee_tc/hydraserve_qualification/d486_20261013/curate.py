"""Reuse explicit small-evidence tar/roundtrip/protected-seal checkpoint procedure."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile
RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2)

save(RAW/'curation_identity.json', p.scope_identity(p.cg_path().name))
build = RAW.parent/'d485_20261013/header_retry'
for directory, name in ((build,'build'),(RAW,'recheck'),(RAW,'dependencies'),(RAW,'native_import')):
    assert json.loads((directory/(name+'_closure.json')).read_text())['passed']
for path in (build/'build_result.json', RAW/'native_import_result.json', RAW/'native_import_supervisor_result.json', RAW/'recheck_result.json'):
    assert json.loads(path.read_text())['passed']
assert not json.loads((RAW/'dependencies_result.json').read_text())['passed']  # Preserve README check failure.
protected = p.verify_seal(Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/slora_qualification/d435_20261011/protected_before.json'))
assert protected['pass']
names = ['recheck_slo.py','close.py','native_package_tasks.py','finish_dependencies.py',
         'verify_import.py','import_retry.py','curate.py','backup.py',
         'recheck_identity.json','recheck_result.json','recheck_closure.json',
         'dependencies_identity.json','dependencies_preflight.json','dependencies_sources.json',
         'dependencies_commands.json','dependencies_result.json','dependencies_closure.json',
         'native_import_identity.json','native_import_preflight.json','native_import_sources.json',
         'native_import_commands.json','native_import_supervisor_result.json','native_import_result.json',
         'native_import_closure.json','native_package_manifest.json','nccl_artifact.json',
         'flash_attn_report.json','nccl_report.json','native_package_report.json']
for label in ('prepare_source','flash_attn','nccl_library','nccl_package','native_package','pip_check','native_import','native_import_retry'):
    names += [label+'.log', label+'_worker.json']
files = [RAW/n for n in names]
files += [build/n for n in ('build_result.json','build_closure.json','build_vllm.log')]
files += [BASE/'docs/ieee_tc/D486_HYDRASERVE_NATIVE_INSTALL.md',
          MAIN/'docs/ieee_tc/D486_METRIC_FAIRNESS_RECHECK.md']
manifest = {}
for path in files:
    assert path.stat().st_size < 1048576, path
    if path.suffix == '.py':
        compile(path.read_text(), str(path), 'exec')
    manifest[str(path)] = dict(sha256=p.digest(path), bytes=path.stat().st_size)
dest = BASE/'paper_results/ieee_tc/hydraserve/d486'
dest.mkdir()
archive = dest/'native_install_and_metric_recheck.tar.gz'
with tarfile.open(archive, 'x:gz') as bundle:
    for path in files:
        bundle.add(path, arcname=str(path).removeprefix('/home/qhq/'), recursive=False)
with tarfile.open(archive, 'r:gz') as bundle:
    for member in bundle.getmembers():
        assert hashlib.sha256(bundle.extractfile(member).read()).hexdigest() == manifest['/home/qhq/'+member.name]['sha256']
summary = dict(kind='hydraserve_native_libraries_built_installed_imported',
    checkpoint_verified=True, performance_result=False, gpu_executed=False,
    native_backend_qualified=False, numerical_qualified=False,
    import_result=json.loads((RAW/'native_import_result.json').read_text()),
    build_result=json.loads((build/'build_result.json').read_text()),
    metric_recheck=json.loads((RAW/'recheck_result.json').read_text()),
    source_manifest=manifest, archive_sha256=p.digest(archive),
    protected_verification=protected, tests_count=0, syntax_checks=True,
    note='Actual native compile/link, package/import and replay arithmetic checks; no new GPU/model or unit-test claim. All failures retained.')
save(dest/'summary.json', summary)
metric_dest = MAIN/'paper_results/ieee_tc/metric_audit'
metric_dest.mkdir(exist_ok=True)
save(metric_dest/'20261013_d486_serverlessllm_recheck.json',
     dict(summary['metric_recheck'], source_recipe_sha256=p.digest(RAW/'recheck_slo.py'),
          raw_scope_closure=json.loads((RAW/'recheck_closure.json').read_text()),
          baseline_evidence_archive_sha256=summary['archive_sha256']))
receipt = dict(passed=True, source_count=len(files), archive_sha256=p.digest(archive),
               summary_sha256=p.digest(dest/'summary.json'))
save(RAW/'curation_result.json', receipt)
print(json.dumps(receipt))
