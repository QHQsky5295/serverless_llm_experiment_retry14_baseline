"""Native package operations under the reused bounded command supervisor.

No native source edits: uses upstream VLLM_USE_PRECOMPILED with D485 outputs.
No old environment installs; NVIDIA shared runtime namespace remains read-only.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import urllib.request

RAW = Path(__file__).resolve().parent
BASE = Path('/home/qhq/serverless_llm_baselines')
NATIVE = BASE/'vendor_new_baselines/HydraServe_main_20260520'
ENV = BASE/'installs/hydraserve_native_d484_20261013'
BUILD = RAW.parent/'d485_20261013/header_retry'

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def save(name, value):
    with (RAW/name).open('x') as f:
        json.dump(value, f, indent=2)

mode = sys.argv[1]
if mode == 'prepare':
    assert json.loads((BUILD/'build_closure.json').read_text())['passed']
    result = json.loads((BUILD/'build_result.json').read_text())
    assert result['passed']
    for path, rec in result['outputs'].items():
        assert digest(path) == rec['sha256'] and Path(path).stat().st_size == rec['bytes']
    view = RAW/'native_package_source'
    view.mkdir()
    files = [NATIVE/'setup.py', NATIVE/'README.md', NATIVE/'LICENSE']
    files += sorted(NATIVE.glob('requirements*.txt'))
    files += [p for p in (NATIVE/'vllm').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    manifest = {}
    for path in files:
        rel = path.relative_to(NATIVE)
        out = view/rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, out)
        assert digest(path) == digest(out)
        manifest[str(rel)] = digest(out)
    for path in sorted((BUILD/'native_extensions').glob('*.so')):
        out = view/'vllm'/path.name
        assert not out.exists()
        # Separate packaged bytes, not modification of compiled artifacts.
        shutil.copyfile(path, out)
        assert digest(path) == digest(out)
        manifest['vllm/'+path.name] = digest(out)
    save('native_package_manifest.json', dict(source_commit='8ae605de354ccfa2e9095514cdb4a9e9c56aa56b',
        files=manifest, mode='official VLLM_USE_PRECOMPILED; original Python + own verified native extensions'))
elif mode == 'nccl':
    url = 'https://github.com/vllm-project/vllm-nccl/releases/download/v0.1.0/cu12-libnccl.so.2.18.1'
    target = RAW/'private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1'
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    # Finite parent deadline + socket timeout, no original setup.py infinite retry.
    sha, md5, total = hashlib.sha256(), hashlib.md5(), 0
    with urllib.request.urlopen(url, timeout=30) as r, target.open('xb') as f:
        expected = int(r.headers['Content-Length']) if r.headers.get('Content-Length') else None
        while True:
            b = r.read(1024*1024)
            if not b:
                break
            total += len(b)
            assert total <= 512*1024**2
            f.write(b); sha.update(b); md5.update(b)
    assert expected is None or total == expected
    assert md5.hexdigest() == '296c4de7fbdb0f7fd8501fb63bd0cb40'
    target.chmod(0o644)
    save('nccl_artifact.json', dict(path=str(target), source_url=url, bytes=total,
         sha256=sha.hexdigest(), official_package_md5=md5.hexdigest(), content_length=expected))
elif mode == 'verify':
    import importlib.metadata as metadata
    import torch
    assert not torch.cuda.is_initialized()
    assert torch.__version__ == '2.3.0+cu121' and torch._C._GLIBCXX_USE_CXX11_ABI is False
    import vllm
    import vllm._C, vllm._moe_C, vllm._punica_C
    import flash_attn, flash_attn_2_cuda
    assert vllm.__version__ == '0.4.2' and flash_attn.__version__ == '2.5.8'
    manifest = json.loads((RAW/'native_package_manifest.json').read_text())
    installed = ENV/'lib/python3.10/site-packages'
    for relative, sha in manifest['files'].items():
        if relative.startswith('vllm/'):
            assert digest(installed/relative) == sha, relative
    assert os.environ['ENABLE_PARA'] == '0'  # Import-only; never bypasses real loader qualification.
    fast = RAW.parent/'d485_20261013/build_fastload/lib/libst_pybinding.so'
    torch.ops.load_library(str(fast))
    from vllm.distributed.device_communicators.pynccl import ncclGetVersion
    nccl_version = ncclGetVersion()
    assert str(nccl_version) in ('2.18.1', '21801'), nccl_version
    assert not torch.cuda.is_initialized()
    Path(os.environ['VLLM_NCCL_SO_PATH']).chmod(0o644)
    save('native_import_result.json', dict(passed=True, cuda_initialized=False, numerical_qualified=False,
         performance_result=False, native_python_files_verified=True,
         torch=torch.__version__, vllm=vllm.__version__, distribution=metadata.version('vllm'),
         flash_attn=flash_attn.__version__, nccl_version=nccl_version,
         fastload_sha256=digest(fast), fastload_import_only_enable_para=0,
         import_paths={m.__name__:m.__file__ for m in (vllm, vllm._C, vllm._moe_C, vllm._punica_C, flash_attn, flash_attn_2_cuda)}))
else:
    raise ValueError(mode)
