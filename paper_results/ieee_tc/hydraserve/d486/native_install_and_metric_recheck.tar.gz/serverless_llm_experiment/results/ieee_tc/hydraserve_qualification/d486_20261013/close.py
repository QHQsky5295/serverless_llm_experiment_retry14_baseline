"""Reuse actual recursive-empty closure, only this checkpoint's owned scopes."""
from pathlib import Path
HERE = Path(__file__).resolve().parent
template = HERE.parent/'d481_20261013/close.py'
source = template.read_text().replace("'backup_main')", "'backup_main','recheck','dependencies','native_import')")
exec(compile(source, str(template), 'exec'), {'__name__':'__main__', '__file__':str(HERE/'close_reused.py')})
