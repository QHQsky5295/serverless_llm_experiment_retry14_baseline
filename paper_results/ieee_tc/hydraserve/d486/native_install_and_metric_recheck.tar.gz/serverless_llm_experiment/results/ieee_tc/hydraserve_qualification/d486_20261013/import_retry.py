"""Reuse finite supervisor; no repeated install, download, build or model load."""
from pathlib import Path
HERE = Path(__file__).resolve().parent
template = HERE/'finish_dependencies.py'
wrapper = template.read_text()
marker = "exec(compile(source, str(template), 'exec'), {'__name__':'__main__', '__file__':str(HERE/'dependencies_reused.py')})"
assert wrapper.count(marker) == 1
wrapper = wrapper.replace(marker, '''
source = source.replace("save('dependencies_", "save('native_import_")
start = source.index('commands=[\\n')
end = source.index("save('native_import_commands.json'", start)
source = source[:start]+"commands=[('native_import_retry',[python,'-B',str(RAW/'verify_import.py')])]\\n"+source[end:]
source = source.replace("started=time.monotonic()", "assert json.loads((RAW/'dependencies_closure.json').read_text())['passed']\\nstarted=time.monotonic()")
source = source.replace("save('native_import_result.json',result)", "save('native_import_supervisor_result.json',result)")
exec(compile(source, str(template), 'exec'), {'__name__':'__main__', '__file__':str(HERE/'import_reused.py')})
''')
exec(compile(wrapper, str(template), 'exec'), {'__name__':'__main__', '__file__':str(HERE/'dependencies_reused.py')})
