"""Reuse D485 finite supervisor for exact native packaging/dependencies/imports."""
from pathlib import Path
HERE = Path(__file__).resolve().parent
template = HERE.parent/'d485_20261013/build_native.py'
source = template.read_text()
source = source.replace("save('build_", "save('dependencies_")
source = source.replace("predicted_growth=8*p.GIB", "predicted_growth=4*p.GIB")
source = source.replace('>3600', '>1800')
start = source.index("commands=[\n")
end = source.index("started=time.monotonic()", start)
source = source[:start] + '''
python = str(ENV/'bin/python')
task = str(RAW/'native_package_tasks.py')
env.update(HOME=str(RAW/'private_home'), VLLM_USE_PRECOMPILED='1',
           VLLM_TARGET_DEVICE='cuda', ENABLE_PARA='0',
           VLLM_NCCL_SO_PATH=str(RAW/'private_home/.config/vllm/nccl/cu12/libnccl.so.2.18.1'),
           PIP_CONFIG_FILE=os.devnull, PIP_DISABLE_PIP_VERSION_CHECK='1')
pip = [python,'-B','-m','pip','--isolated','install','--no-cache-dir','--no-deps',
       '--index-url=https://pypi.org/simple','--timeout=30','--retries=2']
flash = 'https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.8/flash_attn-2.5.8+cu122torch2.3cxx11abiFALSE-cp310-cp310-linux_x86_64.whl'
commands=[
    ('prepare_source',[python,'-B',task,'prepare']),
    ('flash_attn', [*pip,'--report',str(RAW/'flash_attn_report.json'),flash]),
    ('nccl_library',[python,'-B',task,'nccl']),
    ('nccl_package',[*pip,'--no-build-isolation','--report',str(RAW/'nccl_report.json'),
        'https://files.pythonhosted.org/packages/41/07/c1be8f4ffdc257646dda26470b803487150c732aa5c9f532dd789f186a54/vllm_nccl_cu12-2.18.1.0.4.0.tar.gz#sha256=d56535da1b893ac49c1f40be9245f999e543c3fc95b4839642b70dd1d72760c0']),
    ('native_package',[*pip,'--no-build-isolation','--report',str(RAW/'native_package_report.json'),str(RAW/'native_package_source')]),
    ('pip_check',[python,'-B','-m','pip','--isolated','check']),
    ('native_import',[python,'-B',task,'verify'])]
save('dependencies_commands.json',dict(commands=commands,library_bindings={k:str(v) for k,v in libs.items()},
    environment={k:env[k] for k in ('CUDA_HOME','CUDACXX','LD_LIBRARY_PATH','VLLM_USE_PRECOMPILED','ENABLE_PARA','VLLM_NCCL_SO_PATH')}))
''' + source[end:]
start = source.index("    outputs=list(")
end = source.index("    assert all(p.digest(NATIVE/", start)
source = source[:start] + "    assert json.loads((RAW/'native_import_result.json').read_text())['passed']\n" + source[end:]
source = source.replace('native_compile_wall_guard', 'native_dependencies_wall_guard')
exec(compile(source, str(template), 'exec'), {'__name__':'__main__', '__file__':str(HERE/'dependencies_reused.py')})
