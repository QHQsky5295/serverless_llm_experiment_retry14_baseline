"""Correct only source-vs-wheel documentation scope; retain first check failure."""
import json
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
template = HERE/'native_package_tasks.py'
source = template.read_text()
old = "        if relative.startswith('vllm/'):\n"
new = "        if relative.startswith('vllm/') and relative != 'vllm/model_executor/layers/fused_moe/configs/README':\n"
assert source.count(old) == 1
# Official setup packages *.py, the three binaries and listed data, not this README.
missing_readme = 'vllm/model_executor/layers/fused_moe/configs/README'
manifest = json.loads((HERE/'native_package_manifest.json').read_text())
site = Path('/home/qhq/serverless_llm_baselines/installs/hydraserve_native_d484_20261013/lib/python3.10/site-packages')
assert [p for p in manifest['files'] if p.startswith('vllm/') and not (site/p).exists()] == [missing_readme]
source = source.replace(old, new)
sys.argv = [str(template), 'verify']
exec(compile(source, str(template), 'exec'), {'__name__':'__main__', '__file__':str(template)})
