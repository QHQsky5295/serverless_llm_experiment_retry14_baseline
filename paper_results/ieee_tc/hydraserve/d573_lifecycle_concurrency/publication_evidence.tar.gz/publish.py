"""Reuse D539 exact-path publication; baseline first, main records its hash."""
import hashlib
from pathlib import Path
import sys
RAW=Path(__file__).resolve().parent
mode=sys.argv[1]
assert mode in ('baseline','main')
original=RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("('review','curation')", "('before','before2','after','after2','curation')")
replace('publication_identity.json','publication_'+mode+'_identity.json')
replace('publication_receipt.json','publication_'+mode+'_receipt.json')
replace("not record['production_changed']", "record['production_changed']")
replace("reports=read(RAW/'curation_receipt.json')['reports']",
        "reports=[r for r in read(RAW/'curation_receipt.json')['reports'] if ROOT in Path(r['path']).parents]; assert len(reports)==1")
replace("'close.py')]", "'close.py')]+[original]")
replace('arcname=path.name','arcname=("base_recipe_"+path.name if path==original else path.name)')
replace('bundle.extractfile(path.name)','bundle.extractfile("base_recipe_"+path.name if path==original else path.name)')
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: qualify per-worker HydraServe lifecycle concurrency (D573)')
if mode=='baseline':
    replace("ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')",
            "ROOT=Path('/home/qhq/serverless_llm_baselines')")
    replace('sys.path.insert(0,str(ROOT))',
            "sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')")
    replace('3e759d75b6e69e182d646d87aca5090f5935024f','5486c4d6a8417ef67484d2b1dbb65d0cd938ff27')
    replace("names=['docs/ieee_tc/EXECUTION_STATUS.md','docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md']",
            "names=['HydraServe_project/runtime/isolated_platform.py','tests/test_ieee_tc_hydraserve_isolated_platform.py','docs/ieee_tc/D573_HYDRASERVE_LIFECYCLE_CONCURRENCY.md']")
    source=source.replace("'faaslora_origin'","'origin'").replace("'retry14_continuous_queue_v2'","'main'").replace("'refs/heads/retry14_continuous_queue_v2'","'refs/heads/main'")
else:
    replace('3e759d75b6e69e182d646d87aca5090f5935024f','f1e0b6f507fff9bf48a7557a7aba74de546ebb58')
    replace("'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'",
            "'docs/ieee_tc/D573_HYDRASERVE_LIFECYCLE_CONCURRENCY.md'")
    replace("out=Path(reports[-1]['path']);archive=out/'publication_evidence.tar.gz'", """out=Path(reports[-1]['path']);archive=out/'publication_evidence.tar.gz'
base=read(RAW/'publication_baseline_receipt.json')
closed=read(RAW/'publication_baseline_closure.json')
assert base['passed'] and base['head']==base['remote'] and closed['path_gone']
save(out/'checkpoint.json',dict(baseline_commit=base['head'],baseline_remote_equal=True,
    baseline_publication_actual_closed=closed,qualification='CPU only; actual affected-path qualification pending'))
names.append(str((out/'checkpoint.json').relative_to(ROOT)))
""")
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py'),'original':original})
