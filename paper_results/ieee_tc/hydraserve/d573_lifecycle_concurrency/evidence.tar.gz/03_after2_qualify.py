"""Bounded CPU-only existing lifecycle tests; no Podman or native inference."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import types
import unittest

MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
sys.path.insert(0,str(BASE))
sys.path.insert(0,str(BASE/'tests'))
# These are the baseline repository's real test files. MAIN has a separate
# regular `tests` package; do not let that package shadow this namespace.
test_package=types.ModuleType('tests')
test_package.__path__=[str(BASE/'tests')]
sys.modules['tests']=test_package
phase=sys.argv[1]
assert phase in ('before2','after2')
def save(name, value):
    with (RAW/name).open('x') as f:
        json.dump(value,f,indent=2)
identity=p.scope_identity(p.cg_path().name)
save(phase+'_identity.json',identity)
group=Path(identity['path'])
for key,value in [('memory.high',3*p.GIB),('memory.max',4*p.GIB),('memory.swap.max',0)]:
    assert (group/key).read_text().strip()==str(value)
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
plan=p.check_plan()
files=[BASE/'HydraServe_project/runtime/isolated_platform.py',
       BASE/'tests/test_ieee_tc_hydraserve_isolated_platform.py',Path(__file__)]
sources={}
for path in files:
    data=path.read_bytes()
    with (RAW/(phase+'_'+path.name)).open('xb') as f: f.write(data)
    sources[str(path)]=hashlib.sha256(data).hexdigest()
modules=['test_ieee_tc_hydraserve_isolated_platform']
if phase=='after2':
    modules += ['test_ieee_tc_hydraserve_'+suffix for suffix in
                ('controller_runtime','physical_lifecycle','platform_port',
                 'worker_binding','stage_binding','request_contract')]
suite=unittest.defaultTestLoader.loadTestsFromNames(modules)
with (RAW/(phase+'_tests.log')).open('x') as out:
    result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
failures=[(case.id(),detail) for case,detail in result.failures]
errors=[(case.id(),detail) for case,detail in result.errors]
save(phase+'_result.json',dict(phase=phase,tests=result.testsRun,
    failures=failures,errors=errors,skipped=result.skipped,
    successful=result.wasSuccessful(),sources=sources,plan_sha256=plan,
    cpu_only=True,gpu_performance_claim=False))
print(json.dumps(dict(phase=phase,tests=result.testsRun,failures=len(failures),errors=len(errors))))
if phase=='before2':
    expected={'test_unrelated_lookup_does_not_wait_for_worker_deletion',
              'test_unrelated_create_does_not_wait_for_worker_deletion'}
    assert {name.rsplit('.',1)[-1] for name,_ in failures}==expected and not errors
else:
    assert result.wasSuccessful() and not result.skipped
