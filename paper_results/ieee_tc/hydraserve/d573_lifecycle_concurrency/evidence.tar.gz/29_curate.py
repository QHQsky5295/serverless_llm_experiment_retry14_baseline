"""Reuse D539 bounded curation for the D573 before/after lifecycle evidence."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace("((RAW,'review'),(CLEAN,'cleanup'))", "tuple((RAW,n) for n in ('before','before2','after','after2'))")
old=source[source.index("review=read(RAW/'review.json')"):source.index('preserved={')]
replace(old,"""before=read(RAW/'before2_result.json');after=read(RAW/'after2_result.json')
assert before['tests']==13 and len(before['failures'])==2 and not before['errors']
assert after['tests']==71 and after['successful'] and not after['skipped']
for path,sha in after['sources'].items():assert p.digest(Path(path))==sha
""")
old=source[source.index('specs=['):source.index('reports=[]')]
replace(old,"""files=sorted(x for x in RAW.iterdir() if x.is_file() and x.suffix in ('.py','.json','.log')
    and x.name not in ('curation_identity.json','curation.log'))
files += [original,RAW.parent/'d570_20261016/close.py',
    BASE/'HydraServe_project/runtime/isolated_platform.py',
    BASE/'tests/test_ieee_tc_hydraserve_isolated_platform.py']
copies={n:RAW/n for n in ('before2_result.json','after2_result.json','before2_closure.json','after2_closure.json')}
specs=[(root/'paper_results/ieee_tc/hydraserve/d573_lifecycle_concurrency',files,copies)
       for root in (BASE,ROOT)]
""")
replace("out=ROOT/'paper_results/ieee_tc'/relative;out.mkdir(parents=True,exist_ok=False)",
        "out=relative;out.mkdir(parents=True,exist_ok=False)")
replace('production_changed=False','production_changed=True')
replace('Executed assertions plus source AST and archive round-trip; no new serving change or repeated GPU tests',
        '13 pre-change checks with exactly two expected concurrency failures; 71 post-change CPU checks passed; source AST and archive round-trip; GPU qualification pending')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'curate.py'),'original':original})
