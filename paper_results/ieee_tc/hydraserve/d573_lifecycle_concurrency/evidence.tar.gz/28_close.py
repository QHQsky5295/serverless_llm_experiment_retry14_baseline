"""Reuse actual identity and recursive-empty closure, with this test's names."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source_path=RAW.parent/'d570_20261016/close.py'
source=source_path.read_text()
old="('review', 'review2', 'curation', 'curation2', 'publication', 'publication2')"
assert source.count(old)==1
source=source.replace(old,"('before', 'before2', 'after', 'after2', 'curation', 'publication')")
exec(compile(source,str(source_path),'exec'),{'__name__':'__main__','__file__':str(RAW/'close.py')})
