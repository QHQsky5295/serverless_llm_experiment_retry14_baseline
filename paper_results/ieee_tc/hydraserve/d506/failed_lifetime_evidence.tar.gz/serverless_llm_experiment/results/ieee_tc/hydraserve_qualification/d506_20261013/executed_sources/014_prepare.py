"""D506: mechanically reuse qualified D505, changing only population/identity.

No runtime policy, native controller, backend, weight or source-trace change.
This file is one-shot; every output must be absent before preparation.
"""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

RAW = Path(__file__).resolve().parent
OLD = RAW.parent / 'd505_20261013'
BASE = Path('/home/qhq/serverless_llm_baselines')
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0, str(MAIN))
sys.path.insert(0, str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one
from faaslora.datasets.workload_generator import FrozenReplayPlan

def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()

def put(name, value):
    with (RAW / name).open('x') as handle:
        handle.write(value)

def save(name, value):
    put(name, json.dumps(value, indent=2))

for name in ('http_audit.json', 'backup_baseline_receipt.json', 'backup_main_receipt.json'):
    assert json.loads((OLD / name).read_text())['passed'], name
assert json.loads((OLD / 'closure.json').read_text())['actual_recursive_empty']
for path, record in json.loads((OLD / 'source_manifest.json').read_text()).items():
    assert digest(record['snapshot']) == record['sha256']
    assert digest(path) == record['sha256'], path

cfg = json.loads((OLD / 'http_7b_1000.json').read_text())
assert cfg['request_count'] == 1000 and cfg['request_view'] == 'trace_prefix_v1'
cfg.update(request_count=4000, experiment_role='native_hydraserve_full_w0_single_observation',
           qualification_only=True, formal_run=False)
save('http_7b_4000.json', cfg)
save('remote_input_config.json', {k: cfg[k] for k in
     ('ingress_mode', 'pool_index', 'pool_index_sha256', 'remote_artifacts')})
assert digest(cfg['pool_index']) == cfg['pool_index_sha256']
pool = json.loads(Path(cfg['pool_index']).read_text())['artifacts']
assert len(pool) == 500
save('lora_registry.json', [dict(adapter_id=aid, adapter_index=i,
     adapter_path=str(RAW / 'adapter_views' / aid))
     for i, aid in enumerate(sorted(item['id'] for item in pool), 1)])
qualification = json.loads((OLD / 'input_qualification.json').read_text())
qualification.update(reused_d505_compatibility_audit=True,
                     d505_http_audit_sha256=digest(OLD / 'http_audit.json'))
save('input_qualification.json', qualification)
for name in ('model_registration.json', 'close_pause.py', 'close_audit.py', 'close_cpu.py',
             'collect_remote.py', 'start_remote.sh', 'online_sources.json',
             'run_and_close.sh', 'prelaunch.py'):
    put(name, (OLD / name).read_text().replace('d505', 'd506'))
for name in ('official_main.py', 'official_scheduler.py', 'official_engine.py', 'official_ModelInfo.py'):
    put(name, (OLD / name).read_text())
put('launch.sh', (OLD / 'launch.sh').read_text().replace('d505', 'd506')
    .replace('http_7b_1000', 'http_7b_4000'))
body = (OLD / 'native_body.py').read_text().replace('d505', 'd506').replace('http_7b_1000', 'http_7b_4000')
body = replace_one(body,
    '1000 existing prefix requests via common HTTP open-loop, native Scheduler and real-remote; not numerical/full4000/performance',
    '4000 existing W0 requests via common HTTP open-loop, native Scheduler and real-remote; development observation, not independent numerical qualification')
put('native_body.py', body)
witness = (OLD / 'request_witness.py').read_text().replace('common 1000-prefix', 'common full4000 W0')
witness = replace_one(witness, "terminal['N_response']==1000", "terminal['N_response']==4000")
put('request_witness.py', witness)

plan = FrozenReplayPlan.load(cfg['trace'], count=4000)
identity = plan.identity()
assert identity['source_sha256'] == cfg['trace_sha256']
assert identity['view_sha256'] == 'a5331be2e2204483f18206825d9aaa18cbaa259fe0babfc303f989055819430d'
assert identity['count'] == identity['source_count'] == 4000
metric_paths = {
    'plan': Path('/home/qhq/storage_audit_20260915/PrimeLoRA-PLAN.md'),
    'metric_protocol': MAIN / 'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md',
    'single_run_amendment': MAIN / 'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md',
    'slo_eval': MAIN / 'paper_results/ieee_tc/protocols/20261010_7b_slo_d394_frozen.json',
}
expected = dict(plan='f851e6da5237cb706f5a167dd1180984d5d02694fa6568f1720e0e5aada0b1f5',
    metric_protocol='5f0732ef54d629b40cece42bdbf536e8e74c6505e3ec5d4c7e8742408ad80f22',
    single_run_amendment='193bf1535af1aa50f83d98dc2e944ecbdc7bd27aa96baeca82f0654e02f9357d',
    slo_eval='2d906f8aaf3fa1bf8cf30d116990db9970fb7be7bf1374fdbd1d8995090104f3')
for key, path in metric_paths.items():
    assert digest(path) == expected[key], key
save('preregistration.json', dict(
    campaign='d506_20261013', status='prepared_not_launched', system='HydraServe',
    model='Llama-2-7B', workload='W0', n_plan=4000, plan_identity=identity,
    formal_run=False, qualification_only=True, performance_result=False,
    interpretation='preregistered single development observation; derive V1 binding/accounting metrics after full audit; no independent holdout or optimal configuration claim',
    reuse_from=str(OLD), reuse_audit_sha256=digest(OLD / 'http_audit.json'),
    references={k: dict(path=str(v), sha256=expected[k]) for k, v in metric_paths.items()},
    runtime_registration_sha256=digest(RAW / 'model_registration.json'),
    runtime_model_info=[13, 9000, 200, 1000000, 1],
    runtime_thresholds_are_not_evaluation_thresholds=True,
    generation_contract=cfg['generation_contract'], native_batch=8,
    native_use_cache=0, native_slow_expr=0, native_idle_retirement_s=30,
    deployment_notice_s=60, request_guard_s=1800, predicted_growth_gib=20,
    physical_nodes=1, physical_gpus=4, physical_ledger='hydraserve_container_union_v1',
    pp1_claim_to_create_boundary_qualified=True, multirank_boundary_audit_if_exercised=True,
    no_runtime_policy_change=True, no_config_search=True, repeat_count=1,
    numerical_lora_qualified=False, n_correct=None,
    pipeline_migration_consolidation_qualification='not established; record actual triggers, no forced events',
    source_heads={label: subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
                  for label, root in [('baseline', BASE), ('main', MAIN)]}))
template = (OLD / 'executed_prepare.py').read_text().replace('d505', 'd506').replace('http_7b_1000', 'http_7b_4000')
template = replace_one(template, "RAW/'prepare2.py'", "RAW/'preregistration.json'")
put('executed_prepare.py', template)
exec(compile(template, str(RAW / 'executed_prepare.py'), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW / 'executed_prepare.py')})
print(json.dumps(dict(prepared=True, request_count=4000, view_sha256=identity['view_sha256'],
                     preregistration_sha256=digest(RAW / 'preregistration.json'))))
