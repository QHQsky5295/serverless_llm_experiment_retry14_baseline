"""Reuse D503/D499 evidence curation for a failed, incomplete D506 attempt."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d503_20261013/checkpoint.py').read_text()
# Expand the existing wrapper in isolation, intercepting its final exec so
# the same explicit file list, protected seal and roundtrip archive are reused.
anchor="exec(compile(source,str(RAW/'checkpoint_reused.py'),'exec'),{'__name__':'__main__','__file__':str(RAW/'checkpoint.py')})"
assert source.count(anchor)==1
scope={'__name__':'__main__','__file__':str(RAW/'failure_checkpoint.py')}
exec(compile(source.replace(anchor,''),str(RAW.parent/'d503_20261013/checkpoint.py'),'exec'),scope)
source=scope['source']
start=source.index("assert json.loads((RAW/'closure.json').read_text())['actual_recursive_empty']")
end=source.index('protected=p.verify_seal',start)
source=source[:start]+'''failure=json.loads((RAW/'container_lifetime_failure.json').read_text())
closure=json.loads((RAW/'closure.json').read_text())
assert failure['classification']=='protocol_or_launcher_error' and not failure['performance_comparison_eligible']
assert closure['actual_recursive_empty'] and closure['service_gone']
launch=json.loads((RAW/'launch_gate.json').read_text())
assert not launch['pass'] and launch['classification']=='protocol_or_launcher_error'
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert json.loads((RAW/'remote_stop.json').read_text())['all_owned_units_inactive']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
for path,record in json.loads((RAW/'source_manifest.json').read_text()).items():
    assert p.digest(Path(record['snapshot']))==record['sha256']
    assert p.digest(Path(path))==record['sha256']
from collections import Counter
events=Counter();terminal=None
with (RAW/'launch_gate.launch/replay.jsonl').open() as stream:
    for line in stream:
        row=json.loads(line);events[row['event']]+=1
        if row['event']=='http_replay_incomplete':terminal=row
assert terminal==dict(event='http_replay_incomplete',N_plan=4000,N_arrived=2229,N_terminal=2229,N_response=1202,N_failed=1027,error='CancelledError: ')
assert events['request_created']==2229 and events['http_response']==1202
assert events['http_request_failed']+events['http_request_cancelled']==1027
assert 'Ran 88 tests' in (RAW/'backup2_baseline_smoke.log').read_text()
assert '\\nOK\\n' in (RAW/'backup2_baseline_smoke.log').read_text()
save(RAW/'failure_population_audit.json',dict(passed=True,terminal=terminal,event_counts=dict(events),
    not_arrived=1771,not_arrived_are_not_failed=True,full_result_qualified=False))
'''+source[end:]
source=source.replace('D503_HYDRASERVE_COMMON_HTTP.md','D506_HYDRASERVE_FULL_W0.md')
source=source.replace("hydraserve/d503';dest.mkdir()", "hydraserve/d506';dest.mkdir(exist_ok=True)")
source=source.replace('http_qualification_evidence.tar.gz','failed_lifetime_evidence.tar.gz')
source=source.replace("x.name not in ('pull-auth.json','curation.log')", "x.name not in ('pull-auth.json','failure_curation.log')")
start=source.index('summary=dict(')
end=source.index("save(dest/'summary.json'",start)
source=source[:start]+'''summary=dict(checkpoint_verified=True,performance_result=False,cpu_tests_passed=88,
    outcome='incomplete_protocol_or_launcher_error',container_lifetime_failure=failure,
    publisher_terminal=terminal,not_arrived=1771,n_correct=None,full_audit_executed=False,
    no_slo_or_resource_ranking=True,actual_release_and_remote_stop=True,closure=closure,
    protected_verification=protected,source_manifest=manifest,archive_sha256=p.digest(archive),
    next='Remove incorrect container TTL only; validate lifetime boundary then new full4000 attempt; full comparison then PrimeLoRA optimization')
'''+source[end:]
exec(compile(source,str(RAW/'failure_checkpoint_reused.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'failure_checkpoint.py')})
