"""Reuse explicit D480 protection/test/secrets/stage/push gates before launch."""
from pathlib import Path

RAW = Path(__file__).resolve().parent
BASE = Path('/home/qhq/serverless_llm_baselines')
template = RAW.parent / 'd480_20261013/backup.py'
source = template.read_text().replace('d480', 'd506').replace('D480', 'D506')
start = source.index("summary = json.loads(")
end = source.index("assert p.verify_seal", start)
source = source[:start] + '''prereg = RAW/'preregistration.json'
assert p.digest(prereg) == '033911e0ae567ae8c3dd02dc0bf0be65739465ae0acd10113fa3899c06654b24'
for path, record in json.loads((RAW/'source_manifest.json').read_text()).items():
    assert p.digest(Path(path)) == record['sha256'], path
    assert p.digest(Path(record['snapshot'])) == record['sha256']
curated = BASE/'paper_results/ieee_tc/hydraserve/d506/preregistration.json'
if mode == 'baseline':
    curated.parent.mkdir(parents=True, exist_ok=True)
    with curated.open('xb') as handle: handle.write(prereg.read_bytes())
assert p.digest(curated) == p.digest(prereg)
''' + source[end:]
start = source.index("    paths = ['HydraServe_project/runtime/platform_port.py',")
end = source.index('else:\n    paths =', start)
source = source[:start] + '''    paths = ['docs/ieee_tc/D506_HYDRASERVE_FULL_W0.md',
             'paper_results/ieee_tc/hydraserve/d506/preregistration.json']
    remote, branch = 'origin', 'main'
    smoke = ['tests.test_ieee_tc_hydraserve_'+name for name in
        ('http_contract','physical_lifecycle','remote_artifacts','controller_runtime','shm_control',
         'tokenizer_compat','request_contract','native_delivery','isolated_platform',
         'platform_port','stage_binding','worker_binding','layer_identity')]
''' + source[end:]
source = source.replace('qualify HydraServe native platform injection seam on CPU',
                        'preregister unchanged HydraServe full W0 single observation')
exec(compile(source, str(template), 'exec'),
     {'__name__': '__main__', '__file__': str(RAW/'preregister_backup.py')})
