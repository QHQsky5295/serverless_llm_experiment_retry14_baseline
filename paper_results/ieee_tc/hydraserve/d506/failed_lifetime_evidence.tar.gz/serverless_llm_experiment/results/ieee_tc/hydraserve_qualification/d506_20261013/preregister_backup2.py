"""Resume backup in the qualified CPU-test environment; keep first failure."""
from pathlib import Path
RAW = Path(__file__).resolve().parent
source = (RAW/'preregister_backup.py').read_text()
old = "    with curated.open('xb') as handle: handle.write(prereg.read_bytes())"
assert source.count(old) == 1
source = source.replace(old, "    assert curated.read_bytes() == prereg.read_bytes()")
anchor = "exec(compile(source, str(template), 'exec'),"
assert source.count(anchor) == 1
source = source.replace(anchor,
    "source = source.replace(\"'backup_'\", \"'backup2_'\")\n" + anchor)
exec(compile(source, str(RAW/'preregister_backup.py'), 'exec'),
     {'__name__':'__main__', '__file__':str(RAW/'preregister_backup2.py')})
