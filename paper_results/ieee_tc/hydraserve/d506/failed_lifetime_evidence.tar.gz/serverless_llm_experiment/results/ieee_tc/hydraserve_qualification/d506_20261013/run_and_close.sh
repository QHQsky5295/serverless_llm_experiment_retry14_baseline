#!/bin/bash
# One actual run, then exact-owned closure; never retry or overwrite results.
set -u
set -o noclobber
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/hydraserve_qualification/d506_20261013
bash "$RAW/launch.sh"
launch_status=$?
/usr/bin/python3 -B "$RAW/close_audit.py" > "$RAW/close.log" 2>&1 || exit 91
/usr/bin/python3 -B "$RAW/collect_remote.py" > "$RAW/remote_collection.log" 2>&1 || exit 92
exit "$launch_status"
