"""Host pidfd signal using the already captured, exact-owned failure receipt."""
import json
import os
from pathlib import Path
import signal
import sys
import time
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
evidence=json.loads((RAW/'container_lifetime_failure.json').read_text())
owner=evidence['launcher_identity']
assert evidence['classification']=='protocol_or_launcher_error'
assert p.scope_still_owned(evidence['service_identity'])
assert p.scope_still_owned(evidence['auxiliary_identity'])
assert p.gpu_process_identity(owner['pid'])==owner
fd=os.pidfd_open(owner['pid'])
try:
    assert p.gpu_process_identity(owner['pid'])==owner
    signal.pidfd_send_signal(fd,signal.SIGINT)
finally:
    os.close(fd)
with (RAW/'launcher_interrupt.json').open('x') as handle:
    json.dump(dict(sent=True,signal='SIGINT',owner=owner,at_monotonic_s=time.perf_counter(),
        cause_receipt_sha256=p.digest(RAW/'container_lifetime_failure.json')),handle,indent=2)
print('Exact-owned launcher interrupted; wait for its existing cleanup path.')
