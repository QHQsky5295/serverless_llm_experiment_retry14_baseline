"""Record actual D506 container-lifetime failure, interrupt exact launcher only."""
from datetime import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
receipt=json.loads((RAW/'launch_gate.launch/exec_receipt.json').read_text())
service=receipt['service_identity']
assert service['invocation_id']=='f0b714394f5c4c2ab4e975f96174040c'
assert p.scope_still_owned(service)
aux=p.scope_identity('primelora-tc-aux-d5060000000000000000000000000009.scope')
pid=2871677
owner=p.gpu_process_identity(pid)
assert owner and owner['uid']==os.getuid() and owner['cgroup']==aux['path']
command=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
assert b'gated-launch' in command and str(RAW/'launch_gate.json').encode() in command
base=['podman','--root',str(RAW.parent/'d477_20261012/container_proxy_attempt/container_storage'),
      '--runroot','/run/user/1001/primelora-hydra-d477-proxy/runroot',
      '--storage-driver=vfs','--cgroup-manager=cgroupfs','--events-backend=file',
      '--runtime=/usr/bin/nvidia-container-runtime','--hooks-dir',str(RAW/'empty_hooks')]
env={**os.environ,'CONTAINERS_CONF':str(RAW/'containers.conf'),
     'XDG_RUNTIME_DIR':'/run/user/1001/primelora-hydra-d477-proxy',
     'REGISTRY_AUTH_FILE':str(RAW/'pull-auth.json')}
names=['d506-storage','d506-provider',*[f'd506-w{i}' for i in range(4)]]
states=[]
for name in names:
    data=json.loads(subprocess.check_output(base+['inspect',name],env=env,text=True,timeout=10))[0]
    assert data['Config']['Labels']['org.primelora.campaign']=='d506'
    assert data['Id']==json.loads((RAW/'platform'/(name+'.ownership.json')).read_text())['container_id']
    state=data['State']
    assert not state['Running'] and not state['OOMKilled']
    duration=(datetime.fromisoformat(state['FinishedAt'])-datetime.fromisoformat(state['StartedAt'])).total_seconds()
    assert abs(duration-1800)<2, (name,duration)
    states.append(dict(name=name,container_id=data['Id'],state=state,actual_duration_s=duration))
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
evidence=dict(classification='protocol_or_launcher_error',
    cause='isolated adaptation Podman --timeout=1800 killed all native containers; not native scheduler failure or request timeout',
    performance_comparison_eligible=False, n_plan=4000, measured_full_result=False,
    at_monotonic_s=time.perf_counter(), container_states=states,
    service_identity=service, auxiliary_identity=aux, launcher_identity=owner,
    source_path='/home/qhq/serverless_llm_baselines/HydraServe_project/runtime/isolated_platform.py',
    source_sha256=p.digest(Path('/home/qhq/serverless_llm_baselines/HydraServe_project/runtime/isolated_platform.py')),
    action='SIGINT exact launcher via pidfd; existing guarded-launch finally owns service/publisher/watchdog cleanup',
    retain_all_failed_and_unarrived_requests=True, no_result_or_timeout_adjustment=True)
with (RAW/'container_lifetime_failure.json').open('x') as handle:json.dump(evidence,handle,indent=2)
fd=os.pidfd_open(pid)
try:
    assert p.gpu_process_identity(pid)==owner and p.scope_still_owned(service)
    signal.pidfd_send_signal(fd,signal.SIGINT)
finally:
    os.close(fd)
print(json.dumps(dict(interrupt_sent=True,launcher_pid=pid,classification=evidence['classification'],
                     durations={r['name']:r['actual_duration_s'] for r in states})))
