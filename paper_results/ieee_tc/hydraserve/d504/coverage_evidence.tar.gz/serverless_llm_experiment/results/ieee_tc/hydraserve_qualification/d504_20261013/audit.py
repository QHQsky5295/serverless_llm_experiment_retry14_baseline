"""Reuse independent D503 audit for explicit coverage, never W0 performance."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d503_20261013/audit.py').read_text()
source=source.replace('http_7b_100','http_7b_500').replace('=100', '=500')
old="prior={r['request_id']:r for r in json.loads((RAW.parent/'d502_20261013/generation_result.json').read_text())['requests']}"
assert source.count(old)==1
source=source.replace(old,"prior={}  # Coverage changes adapter mapping; no false paired-output comparison.")
anchor='assert seen_transfer==set(by_transfer)'
assert source.count(anchor)==1
source=source.replace(anchor,anchor+'''
assert plan.profile=='ADAPTER_COVERAGE_V1' and len(plan.entries)==500
expected_ids={r['id'] for r in json.loads(Path(cfg['pool_index']).read_text())['artifacts']}
assert {r['adapter_id'] for r in rows}==expected_ids and len(expected_ids)==500
for ordinal,entry in enumerate(plan.entries):
    contract=contracts[entry.request_id]
    view=contract['tc_adapter_coverage']
    assert view==json.loads(entry.source_json)['tc_adapter_coverage']
    assert view['ordinal']==ordinal and view['pool_index_sha256']==cfg['pool_index_sha256']
''')
anchor="with (RAW/'http_audit.json').open('x') as f:json.dump(summary,f,indent=2)"
assert source.count(anchor)==1
source=source.replace(anchor,"summary.update(request_view='adapter_coverage_v1',prelaunch_health_probe_passed=False,\n    orchestration_deviation='see prelaunch_failure_notes.md; independent resource and manifest gates passed before deployment notice')\n"+anchor)
exec(compile(source,str(RAW/'audit_reused.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'audit.py')})
