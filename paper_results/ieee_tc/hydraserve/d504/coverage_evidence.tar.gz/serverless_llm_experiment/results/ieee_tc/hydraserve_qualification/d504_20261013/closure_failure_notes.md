# D504 post-run collection prerequisite failure

All500 native-contract responses and actual local GPU/service release completed.
run_and_close.sh then exited92 because stop_remote.sh requires remote_health.json,
which the earlier failed prelaunch probe had never written. jq exited2 BEFORE
the SSH command: no remote service was stopped by that failed call. The original
remote_collection.log, stop_remote.sh and local closure remain immutable.

The agent then launched audit.py before checking remote_collection.log; it exited
on missing remote_stop.json before creating any audit outputs. CPU scope3 was
actually empty and closed. This was another prerequisite sequencing error, not
a model, LoRA, HTTP-response or native-resource-release failure.

collect_remote_after_run.py explicitly obtains health only AFTER local release,
stores remote_health_after_run.json (not a forged prelaunch receipt), and reuses
the same start-Invocation comparison, stop, port check and SHA download procedure.
The post-run clock chooses the transfer journal; every transferred request ID
must independently match the request-time local receipt in the final audit.
No inference rerun, request modification, timeout or baseline-policy change.
