"""Reuse D503 append-only evidence curation for full static-ID coverage."""
from pathlib import Path
RAW=Path(__file__).resolve().parent
source=(RAW.parent/'d503_20261013/checkpoint.py').read_text()
source=source.replace("['N_response']==100", "['N_response']==500")
source=source.replace("['n_native_contract_complete']==100", "['n_native_contract_complete']==500")
source=source.replace("['remote_transfers']==29", "['remote_transfers']==500")
source=source.replace("audit['remote_wire_bytes']==50650865 and ", "audit['actual_unique_adapters']==500 and ")
source=source.replace("(RAW/'cpu2.log')", "(RAW.parent/'d503_20261013/cpu2.log')")
source=source.replace('D503_HYDRASERVE_COMMON_HTTP.md','D504_HYDRASERVE_500_ID_COVERAGE.md')
source=source.replace('hydraserve/d503', 'hydraserve/d504')
source=source.replace('http_qualification_evidence.tar.gz','coverage_evidence.tar.gz')
source=source.replace('n_native_contract_complete=100,n_correct=None,actual_unique_adapters=29',
    'n_native_contract_complete=500,n_correct=None,actual_unique_adapters=500,\n    cpu_tests_reused_from_d503=True,prelaunch_health_probe_passed=False')
source=source.replace("next='500-ID functional then1000/4000;", "next='1000 compatibility then4000;")
exec(compile(source,str(RAW/'checkpoint_reused.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'checkpoint.py')})
