"""Post-release health identity, then the same exact-Invocation stop/collection.

Does not reconstruct a missing prelaunch check or modify measured requests.
Preserves original failed stop_remote.sh and remote_collection.log.
"""
import json
from pathlib import Path
import subprocess
import sys
import urllib.request

RAW=Path(__file__).resolve().parent
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
closure=json.loads((RAW/'closure.json').read_text())
assert closure['actual_recursive_empty'] and closure['service_gone']
assert not Path(closure['service']['path']).exists()
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_text().strip()
health={}
for model,port in [('3b',18080),('7b',18081)]:
    request=urllib.request.Request(f'http://192.168.4.174:{port}/health',headers={'Authorization':'Bearer '+token})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=15) as response:
        health[model]=json.loads(response.read())
with (RAW/'remote_health_after_run.json').open('x') as f:json.dump(health,f,indent=2)
source=(RAW/'stop_remote.sh').read_text().replace('remote_health.json','remote_health_after_run.json')
with (RAW/'stop_remote_after_run.sh').open('x') as f:f.write(source)
subprocess.run(['bash',str(RAW/'stop_remote_after_run.sh')],check=True,timeout=60)
old=RAW.parent.parent/'p2_backend_qualification/d476_20261012'
source=(old/'collect_closure.py').read_text()
start=source.index("stop = (raw/'remote_stop.log').read_text()")
end=source.index("\nsource = next(run.glob",start)
source=source[start:end].replace('d476_20261012_hostexecw0','d504_20261013_hydraremote')
exec(compile(source,str(RAW/'postrun_collection_reused.py'),'exec'),
    dict(raw=RAW,p=p,json=json,subprocess=subprocess))
