"""Close only this campaign's exact-owned, recursively empty CPU scopes."""
import json
from pathlib import Path
import subprocess
import sys
RAW=Path(__file__).resolve().parent
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
out=[]
for digit in sys.argv[1:]:
    assert digit in ('1','2','3','4','5','6','7','8')
    identity=p.scope_identity('primelora-tc-aux-d504'+'0'*27+digit+'.scope')
    group=Path(identity['path'])
    assert not any(x.read_text().split() for x in (group/'cgroup.procs',*group.rglob('cgroup.procs')))
    assert p.scope_still_owned(identity)
    stats={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
    subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
    assert not group.exists()
    out.append(dict(identity=identity,actual_recursive_empty=True,stats=stats))
with (RAW/('cpu_closure_'+''.join(sys.argv[1:])+'.json')).open('x') as f:json.dump(out,f,indent=2)
print(json.dumps(out))
