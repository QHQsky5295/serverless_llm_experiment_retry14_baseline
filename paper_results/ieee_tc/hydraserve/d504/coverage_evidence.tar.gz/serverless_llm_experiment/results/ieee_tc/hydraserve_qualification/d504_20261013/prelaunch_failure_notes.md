# D504 prerequisite probe / orchestration deviation

The standalone prelaunch.py CPU scope2 completed the protected/user-dirty/source
checks, then failed on its first authenticated remote /health connection with
ConnectionRefusedError [Errno 111], wrapped as urllib.error.URLError. It did not
write remote_health.json or prelaunch_gate.json. Remote systemd start had returned
active; an active label alone did not establish a listening HTTP service.

The agent launched D504 before incorporating this asynchronous tool failure.
The earlier status sentence claiming scope2 had passed was wrong and is corrected
in current EXECUTION_STATUS. This ordering deviation is retained, not overwritten
by a later success or called an inference failure.

The independently mandatory guarded-launch gates did pass: preflight.json records
actual memory/disk/ownership checks, and the common publisher fetched the remote
authenticated frozen manifest before emitting replay_ready/deployment notice.
The actual service also accepted the same metadata before CPU provider startup.
No remote restart/change, artificial delay removal or health retry was performed
during the running qualification. Thus the already running experiment can supply
functional evidence, but is not a formal performance point; all outcomes remain.

Next launch must await and inspect the standalone prerequisite result explicitly.
Do not rerun this prelaunch.py in place: its protected_before.json already exists.
