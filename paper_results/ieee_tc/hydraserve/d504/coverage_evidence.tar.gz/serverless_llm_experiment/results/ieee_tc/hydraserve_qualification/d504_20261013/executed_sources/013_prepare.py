"""Reuse D503's qualified native path for the existing 500-ID functional view."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d503_20261013'
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(BASE))
from HydraServe_project.runtime.native_delivery import replace_one

def put(name,value):
    with (RAW/name).open('x') as f:f.write(value)
def save(name,value):put(name,json.dumps(value,indent=2))
assert json.loads((OLD/'http_audit.json').read_text())['passed']
assert json.loads((OLD/'closure.json').read_text())['actual_recursive_empty']
assert json.loads((OLD/'backup_baseline_receipt.json').read_text())['passed']
assert json.loads((OLD/'backup_main_receipt.json').read_text())['passed']
for original,record in json.loads((OLD/'source_manifest.json').read_text()).items():
    assert sha256(Path(record['snapshot']).read_bytes()).hexdigest()==record['sha256']
    assert sha256(Path(original).read_bytes()).hexdigest()==record['sha256']
cfg=json.loads((OLD/'http_7b_100.json').read_text())
cfg.update(request_count=500,request_view='adapter_coverage_v1',
    experiment_role='adapter_pool_functional_coverage',qualification_only=True,formal_run=False)
save('http_7b_500.json',cfg)
save('remote_input_config.json',{k:cfg[k] for k in
    ('ingress_mode','pool_index','pool_index_sha256','remote_artifacts')})
pool_bytes=Path(cfg['pool_index']).read_bytes()
assert sha256(pool_bytes).hexdigest()==cfg['pool_index_sha256']
pool=json.loads(pool_bytes)['artifacts'];assert len(pool)==500
# No copying/preloading: read existing small configs solely for compatibility.
frozen=Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix')
ranks=Counter();targets=Counter();total=0;tokenizers=set()
for item in pool:
    files={f['path']:f for f in item['files']}
    data=(frozen/item['id']/'adapter_config.json').read_bytes()
    assert sha256(data).hexdigest()==files['adapter_config.json']['sha256']
    config=json.loads(data)
    assert config['r']<=16 and not config.get('use_dora')
    ranks[config['r']]+=1;targets[','.join(sorted(config['target_modules']))]+=1
    total+=sum(f['size_bytes'] for f in item['files'])
    tokenizers.add(files['tokenizer.json']['sha256'])
observed_tokenizers={json.loads(f.read_text())['source_tokenizer_sha256']
    for f in (OLD/'adapter_views/.receipts').glob('*.json')}
assert tokenizers<=observed_tokenizers
assert total+500*4*1024**2+1024**3 < 20*1024**3
save('input_qualification.json',dict(passed=True,logical_ids=500,ranks=dict(ranks),
    targets=dict(targets),source_materialized_bytes=total,predicted_growth_gib=20,
    tokenizer_source_shas=sorted(tokenizers),all_tokenizer_classes_exercised_d503=True,
    no_weight_copy_or_prefetch=True,scope='existing metadata compatibility only, not GPU/numerical coverage'))
registry=[dict(adapter_id=aid,adapter_index=index,adapter_path=str(RAW/'adapter_views'/aid))
    for index,aid in enumerate(sorted(item['id'] for item in pool),1)]
save('lora_registry.json',registry)
for name in ('model_registration.json','close_pause.py','close_audit.py','close_cpu.py',
             'collect_remote.py','start_remote.sh','online_sources.json'):
    put(name,(OLD/name).read_text().replace('d503','d504'))
for name in ('official_main.py','official_scheduler.py','official_engine.py','official_ModelInfo.py'):
    put(name,(OLD/name).read_text())
launch=(OLD/'launch.sh').read_text().replace('d503','d504').replace('http_7b_100','http_7b_500')
launch=replace_one(launch,'--predicted-growth-gib 4','--predicted-growth-gib 20')
put('launch.sh',launch)
body=(OLD/'native_body.py').read_text().replace('d503','d504').replace('http_7b_100','http_7b_500')
body=replace_one(body,'100 existing requests via common HTTP open-loop',
    '500 existing requests under explicit adapter_coverage_v1 via common HTTP open-loop')
put('native_body.py',body)
witness=(OLD/'request_witness.py').read_text().replace('common 100-prefix','common 500-ID functional view')
witness=replace_one(witness,"terminal['N_response']==100","terminal['N_response']==500")
put('request_witness.py',witness)
prelaunch=(RAW.parent/'d502_20261013/prelaunch.py').read_text()
prelaunch=replace_one(prelaunch,'predicted_growth=p.GIB','predicted_growth=20*p.GIB')
put('prelaunch.py',prelaunch)
template=(OLD/'executed_prepare.py').read_text().replace('d503','d504').replace('http_7b_100','http_7b_500')
template=replace_one(template,"paths=[RAW/'http_7b_500.json',",
    "paths=[RAW/'input_qualification.json',RAW/'model_registration.json',RAW/'http_7b_500.json',")
put('executed_prepare.py',template)
exec(compile(template,str(RAW/'executed_prepare.py'),'exec'),
    {'__name__':'__main__','__file__':str(RAW/'executed_prepare.py')})
