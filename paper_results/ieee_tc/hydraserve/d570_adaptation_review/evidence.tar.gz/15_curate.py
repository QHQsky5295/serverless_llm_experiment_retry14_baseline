"""Reuse D539 combined offline-review/maintenance curation; no new framework."""
import hashlib
from pathlib import Path
RAW = Path(__file__).resolve().parent
original = RAW.parent.parent/'serverless_qualification/d539_20261015/curate.py'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '5e02854d6a5abb875a4eaaf22aa517a71e0f47bd1aa1879ce41b29372153d59e'
source = original.read_text()
def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)
replace("storage_maintenance/d538_20261015", "storage_maintenance/d571_20261016")
replace("vllm_qualification/d532_20261015", "loquetier_qualification/d569_20261016")
replace("curation_identity.json", "curation2_identity.json")
replace("curation_receipt.json", "curation2_receipt.json")
replace("((RAW,'review'),(CLEAN,'cleanup'))", "((RAW,'review'),(RAW,'review2'),(CLEAN,'cleanup'),(CLEAN,'cleanup2'))")
replace("clean=read(CLEAN/'cleanup_receipt.json')", "clean=read(CLEAN/'cleanup2_receipt.json')")
old = source[source.index("assert all(review['upstream_core_ast_equal']"):source.index("assert clean['passed']")]
replace(old, """assert len(review['decision_only_cases']) == 12
assert all(c['allocation']['num_nodes'] == 1 for c in review['decision_only_cases'])
for key, count in (('D510_W0', 34), ('D546_W1', 21)):
    observation = review['observations'][key]
    assert observation['worker_count'] == count and len(observation['workers']) == count
    assert sum(w['native_request_count'] for w in observation['workers']) == 4000
    assert all(w['pp_size'] == 1 and w['batch_size'] == 8 for w in observation['workers'])
    assert all(w['counters'].get('schedule', 0) == w['counters'].get('execute', 0) for w in observation['workers'])
    assert len(observation['runtime_source_shas']) == 15
    for name, sha in observation['runtime_source_shas'].items():
        assert p.digest(BASE/'HydraServe_project/runtime'/name) == sha
""")
replace("3305652224", "13004431360")
old = source[source.index("specs=["):source.index("reports=[]")]
replace(old, """specs=[('storage/d571_targeted_cache_reclaim',
 [CLEAN/n for n in ('run_cleanup.py','run_cleanup2.py','reclaim_d569.py','close.py',
 'cleanup_identity.json','cleanup_closure.json','cleanup_attempt1_failure.json',
 'cleanup2_identity.json','cleanup2_receipt.json','cleanup2_closure.json')]+
 [D532/n for n in ('cache_cleanup_before.json','cache_cleanup_after.json')],
 {'cleanup_receipt.json':CLEAN/'cleanup2_receipt.json',
 'cleanup_closure.json':CLEAN/'cleanup2_closure.json',
 'cache_cleanup_after.json':D532/'cache_cleanup_after.json'}),
 ('hydraserve/d570_adaptation_review',
 [RAW/n for n in ('review_native.py','close.py','review_identity.json','review_closure.json',
 'review2_identity.json','review2_closure.json','review_attempt1_failure.json',
 'review_attempt1_source.tar.gz','curation_setup_failure_source.tar.gz',
 'curation_setup_failure.json','curation_attempt1_source.tar.gz',
 'curation_attempt1_failure.json','curation_identity.json','curation_closure.json',
 'close_curation_setup_failure.py','curate.py')]+[original],
 {'review.json':RAW/'review.json','review_closure.json':RAW/'review2_closure.json'})]
""")
exec(compile(source, str(original), 'exec'), {'__name__':'__main__', '__file__':str(RAW/'curate.py'), 'original':original})
