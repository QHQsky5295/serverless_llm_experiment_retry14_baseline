"""Record/close empty pre-identity recipe-expansion failure; no results existed."""
import json
import sys
from pathlib import Path
import subprocess
sys.path.insert(0,'/home/qhq/serverless_llm_experiment_retry14_baseline')
from scripts import ieee_tc_preflight as p
raw=Path(__file__).resolve().parent
identity=p.scope_identity('primelora-tc-aux-d5700000000000000000000000000003.scope')
group=Path(identity['path'])
assert p.scope_still_owned(identity)
members={str(x):x.read_text().split() for x in group.rglob('cgroup.procs')}
assert members and not any(members.values())
resources={k:(group/k).read_text() for k in ('memory.peak','memory.events','memory.swap.current')}
assert p.scope_still_owned(identity)
subprocess.run(['systemctl','--user','stop',identity['unit']],check=True)
assert not group.exists()
with (raw/'curation_setup_failure.json').open('x') as f:
    json.dump(dict(passed_closure=True,identity=identity,resources=resources,path_gone=True,
        actual_recursive_procs_empty=True,failure='unique replacement assertion: cleanup_receipt occurs twice; failed before curation execution',
        source_archive_sha256=p.digest(raw/'curation_setup_failure_source.tar.gz'),
        output_directories_created=False,new_performance_run=False),f,indent=2)
print(json.dumps(dict(closed=True,resources=resources)))
