"""D539 bounded offline-review recipe, applied to all D510/D546 workers.

No serving changes, native imports, container operations or performance replay.
Native execute-model host spans are not CUDA-kernel timings or removable costs.
"""
import ast
import collections
import dataclasses
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import typing

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
NATIVE = BASE/'vendor_new_baselines/HydraServe_main_20260520'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p
import re

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def stats(values):
    xs = sorted(values)
    return dict(n=len(xs), min=xs[0], median=xs[math.ceil(.5*len(xs))-1],
                p95=xs[math.ceil(.95*len(xs))-1], max=xs[-1], mean=sum(xs)/len(xs)) if xs else dict(n=0)

def native_definitions(path, names, namespace):
    tree = ast.parse(path.read_text())
    selected = [node for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in names]
    assert {node.name for node in selected} == set(names)
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'review2_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'], text=True).strip()
refs = [Path(__file__)]
results = {}
schedule_re = re.compile(r'^schedule \[whole=(True|False)\]: len = (\d+); (\[.*\])$')
execute_re = re.compile(r'^GPUexecutor: execute_model time cost = ([0-9.eE+-]+) ms$')
for label, directory, expected_workers in [('D510_W0','d510_20261013',34),('D546_W1','d546_20261015',21)]:
    root = RAW.parent/directory
    platform = root/'platform'
    closure = read(root/'closure.json')
    assert closure['service_gone'] and closure['actual_recursive_empty']
    assert not Path(closure['service']['path']).exists()
    metrics = read(root/'request_metrics.json')
    assert len(metrics) == 4000 and all(row['protocol_valid'] for row in metrics)
    snapshots = read(root/'source_manifest.json')
    source_valid = {}
    for original, item in snapshots.items():
        if '/HydraServe_project/runtime/' in original:
            snapshot = Path(item['snapshot'])
            assert p.digest(snapshot) == item['sha256']
            source_valid[Path(original).name] = item['sha256']
            refs.append(snapshot)
    overlays = read(root/'overlays/manifest.json')
    for path, digest in overlays.items():
        assert p.digest(root/'overlays'/path) == digest
    log_index = collections.defaultdict(list)
    for command in sorted(platform.glob('*.command.json')):
        value = read(command)
        if value['args'][0] == 'logs':
            log_index[value['args'][1]].append(command)
    workers = []
    aggregate = collections.defaultdict(list)
    for request_path in sorted(platform.glob('*-w*.native-request.json')):
        stem = request_path.name.removesuffix('.native-request.json')
        request = read(request_path)
        ownership_path = platform/(stem+'.ownership.json')
        ownership = read(ownership_path)
        assert len(log_index[ownership['container_id']]) == 1
        command = log_index[ownership['container_id']][0]
        assert read(command)['returncode'] == 0
        stdout = command.with_name(command.name.removesuffix('.command.json')+'.stdout')
        stderr = stdout.with_suffix('.stderr')
        pending = None
        seen = set()
        groups = collections.defaultdict(list)
        markers = []
        counts = collections.Counter()
        for line in stdout.open(errors='strict'):
            line = line.strip()
            match = schedule_re.fullmatch(line)
            if match:
                assert pending is None, (stem, 'unmatched schedule')
                ids = ast.literal_eval(match[3])
                assert len(ids) == int(match[2]) and len(ids) == len(set(ids))
                assert all(isinstance(x,str) for x in ids)
                kind = 'contains_first_seen_request' if set(ids)-seen else 'repeat_requests_only'
                pending = (kind, len(ids), match[1])
                seen.update(ids)
                counts['schedule'] += 1
            match = execute_re.fullmatch(line)
            if match:
                assert pending is not None, (stem, 'unmatched execute')
                elapsed = float(match[1]); assert math.isfinite(elapsed) and elapsed >= 0
                key = f'{pending[0]}/batch{pending[1]}/whole{pending[2]}'
                groups[key].append(elapsed); aggregate[key].append(elapsed)
                counts['execute'] += 1
                pending = None
            if any(word in line for word in ('Initializing an LLM engine','Using FlashAttention','KV cache profiling',
                '# GPU blocks:', 'TOTAL_GPU', 'engine init time', 'app init time','model init time',
                'num_gpu_blocks', 'preempted','Preemption','migrate kv cache: completed',
                'Error', 'Traceback', 'WARNING')):
                # Exclude native prompt/response text from compact evidence.
                if len(line) <= 1800 and 'Received request' not in line:
                    markers.append(line)
        assert pending is None and counts['schedule'] == counts['execute'], (stem, dict(counts), pending)
        assert request['env']['PP_SIZE'] == '1' and request['env']['BATCH_SIZE'] == '8'
        workers.append(dict(worker=stem, physical_gpu_index=request['gpu_id'],
            pp_size=1, batch_size=8, native_request_count=len(seen), counters=dict(counts),
            no_scheduled_request_observed=(counts['schedule'] == 0),
            execute_host_span_ms={key:stats(xs) for key,xs in groups.items()}, markers=markers,
            stdout_bytes=stdout.stat().st_size, stderr_bytes=stderr.stat().st_size))
        refs += [request_path, ownership_path, command, stdout, stderr]
    assert len(workers) == expected_workers
    assert sum(row['native_request_count'] for row in workers) == 4000
    results[label] = dict(workers=workers, worker_count=len(workers), runtime_source_shas=source_valid,
        execute_host_span_ms={key:stats(xs) for key,xs in aggregate.items()},
        request_metrics={key:stats([row[key] for row in metrics]) for key in
                         ('ttft_ms','tpot_ms','service_ttft_ms','decode_ms','completion_notification_ms')})
    refs += [root/'source_manifest.json',root/'overlays/manifest.json',root/'request_metrics.json',root/'closure.json']

# Execute the exact upstream definitions without importing Kubernetes/torch.
# This is a decision-only scenario calculation, not a new topology measurement.
source_dir = NATIVE/'scripts/kubernetes/vllm/src'
ns = dict(dataclass=dataclasses.dataclass, List=typing.List, Dict=typing.Dict, Tuple=typing.Tuple,
          time=time, math=math, max_pp_size=4, KVCacheRequiredSize=5)
native_definitions(source_dir/'resource_manager.py', ('ResourceUsage','AllocatedResource'), ns)
native_definitions(source_dir/'scheduler.py', ('ModelStats',), ns)
native_definitions(source_dir/'algs.py', ('pipeline_parallel_static','ours'), ns)
assert p.digest(source_dir/'algs.py') == '12dd34c2cea578b64dcf7ed6f35efdff4b6a6fcd2a87c4d33191300ccae3ece1'
cases = []
for label,profile in [('initial',dict(model_size=13,ttft_slo=9000,tpot_slo=200,cost_slo=1000000)),
                      ('D546_final_profile',read(RAW.parent/'d546_20261015/native_scheduler_after_requests.json')['native_stats'])]:
    for nodes, bandwidth in [(1,[1.0]),(2,[.5,.5]),(2,[1.0,1.0])]:
        for required in (1,2):
            allocation = ns['ours']([24]*nodes, bandwidth, ns['ModelStats'](**profile), required, 0)
            cases.append(dict(profile=label,nodes=nodes,bandwidth_gbps=bandwidth,
                duplicate_link_capacity=(nodes==2 and bandwidth==[1.,1.]),required_pp=required,
                max_wait_ms=0,allocation=dataclasses.asdict(allocation)))
assert all(row['allocation']['num_nodes'] == 1 for row in cases)
refs += [source_dir/name for name in ('resource_manager.py','scheduler.py','algs.py')]
refs += [RAW.parent/'d546_20261015/native_scheduler_after_requests.json']
for name in ('async_llm_engine.py',):
    refs.append(NATIVE/'vllm/engine'/name)
refs += [NATIVE/'vllm/executor/gpu_executor.py',NATIVE/'scripts/image/app.py']
save(RAW/'review.json',dict(passed=True,schema='d570_hydraserve_native_review_v1',identity=identity,
    plan_sha=p.check_plan(),metric_v1_sha=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    metric_v2_sha=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    observations=results,decision_only_cases=cases,changed_serving_code=False,new_performance_run=False,
    refs=[dict(path=str(path),sha256=p.digest(path)) for path in sorted(set(refs))],
    limitations=['Native host execute spans include dispatch/waits/sampling and are not pure CUDA timings.',
                 'Repeat-request-only steps may include recomputation; no kernel-only decode claim.',
                 'Scheduling calculation uses stated hypothetical inventory; it does not create two physical nodes.',
                 'Per-token annotation overhead is not isolated by these logs; do not subtract it.',
                 'Independent numerical correctness and full pipeline-consolidation qualification remain open.']))
print(json.dumps(dict(passed=True,workers={key:value['worker_count'] for key,value in results.items()},
                     decision_cases=len(cases),all_decision_cases_pp1=True)))
