"""Reuse D539 explicit publication for D570 review/D571 maintenance only."""
import hashlib
from pathlib import Path
RAW=Path(__file__).resolve().parent
original=RAW.parent.parent/'serverless_qualification/d539_20261015/publish.py'
assert hashlib.sha256(original.read_bytes()).hexdigest()=='34d69627d4dd365f513d0a54e601962579df69a57c17131e103e1ccc8b2a0faa'
source=original.read_text()
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('3e759d75b6e69e182d646d87aca5090f5935024f','cc5ad04d887a4ebf99c55bb4417b80760b9f1bc0')
replace('publication_identity.json','publication2_identity.json')
replace('publication_evidence.tar.gz','publication2_evidence.tar.gz')
assert source.count('publication.sha256')==3
source=source.replace('publication.sha256','publication2.sha256')
replace("('review','curation')", "('review','review2','curation','curation2')")
replace("'docs/ieee_tc/D538_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D539_SERVERLESSLLM_QUEUE_REVIEW.md'",
        "'docs/ieee_tc/D571_TARGETED_CACHE_RECLAIM.md','docs/ieee_tc/D570_HYDRASERVE_ADAPTATION_REVIEW.md','docs/ieee_tc/LOQUETIER_OPTIMIZATION_AND_STORAGE_20261016.md'")
assert source.count('curation_receipt.json')==2
source=source.replace('curation_receipt.json','curation2_receipt.json')
replace("'curation_identity.json','curation_closure.json'", "'curation2_identity.json','curation2_closure.json'")
replace("'close.py')]", "'close.py','publication_attempt1_source.tar.gz','publication_attempt1_failure.json','publication_identity.json','publication_closure.json')]+[original]")
replace('arcname=path.name','arcname=("base_recipe_"+path.name if path==original else path.name)')
replace('bundle.extractfile(path.name)','bundle.extractfile("base_recipe_"+path.name if path==original else path.name)')
replace('tc: preserve startup queue review and safe cache reclaim (D538-D539)',
        'tc: preserve HydraServe adaptation review and safe cache reclaim (D570-D571)')
exec(compile(source,str(original),'exec'),{'__name__':'__main__','__file__':str(RAW/'publish.py'),'original':original})
