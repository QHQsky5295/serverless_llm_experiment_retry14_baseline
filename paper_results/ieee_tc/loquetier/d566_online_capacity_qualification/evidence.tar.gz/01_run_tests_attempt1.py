"""D565 bounded receipt pattern, reused for online Loquetier ownership/capacity qualification."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

phase = sys.argv[1]
assert phase in ('before', 'qualification', 'regression')
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
with (RAW / (phase + '_identity.json')).open('x') as f:
    json.dump(identity, f, indent=2)
assert (group / 'memory.high').read_text().strip() == str(3 * p.GIB)
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
assert (group / 'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
BASE = Path('/home/qhq/serverless_llm_baselines')
sources = [BASE / name for name in ('tests/test_ieee_tc_loquetier_service.py',
    'tests/test_ieee_tc_loquetier_worker.py', 'tests/test_ieee_tc_loquetier_http.py',
    'configs/ieee_tc/loquetier_7b_prepared_capacity_v1.json',
    'tests/test_loquetier_native_generation.py', 'tests/test_loquetier_static_capacity.py',
    'tests/test_ieee_tc_loquetier_measurement.py', 'scripts/ieee_tc_serverless_measurement.py',
    'scripts/replay_vllm_engine_trace.py', 'Loquetier_project/scripts/run_loquetier_trace_gate.py',
    'vendor_new_baselines/Loquetier_main_20260520/src/loquetier_src/virtual_model.py',
    'vendor_new_baselines/Loquetier_main_20260520/src/loquetier_src/models/mixed_lora.py',
    'vendor_new_baselines/Loquetier_main_20260520/src/loquetier_src/model_generation.py')]
with tarfile.open(RAW / (phase + '_source.tar.gz'), 'x:gz') as archive:
    for path in sources:
        archive.add(path, arcname=str(path.relative_to(BASE)), recursive=False)
commands = [
    ['/home/qhq/anaconda3/envs/sllm_vllm0102_newserverless_20260518/bin/python', '-B', '-m', 'unittest',
     'tests.test_ieee_tc_loquetier_service', 'tests.test_ieee_tc_loquetier_worker',
     'tests.test_ieee_tc_loquetier_http', '-v'],
    [sys.executable, '-B', '-m', 'unittest', 'tests.test_loquetier_native_generation',
     'tests.test_loquetier_static_capacity', '-v'],
    [sys.executable, '-B', '-m', 'unittest', 'tests.test_ieee_tc_loquetier_measurement', '-v']]
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
returncodes = []
with (RAW / (phase + '.log')).open('x') as log:
    for command in commands:
        result = subprocess.run(command, cwd=BASE, stdout=log, stderr=subprocess.STDOUT, timeout=240)
        returncodes.append(result.returncode)
record = dict(passed=all(code == 0 for code in returncodes), phase=phase, commands=commands,
    returncodes=returncodes, identity=identity,
    sources={str(path): p.digest(path) for path in sources + [Path(__file__),
        RAW / (phase + '.log'), RAW / (phase + '_source.tar.gz')]},
    resources={k: (group / k).read_text() for k in ('memory.peak', 'memory.events', 'memory.swap.current')})
with (RAW / (phase + '_receipt.json')).open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record), flush=True)
assert record['passed']
