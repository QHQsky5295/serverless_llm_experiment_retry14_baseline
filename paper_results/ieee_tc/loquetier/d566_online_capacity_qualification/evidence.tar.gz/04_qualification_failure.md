# First CPU launcher attempt

2026-10-16: the new D566 scope started but its driver stopped at the explicit
`os.sched_getaffinity(0) == {2, 3, 26, 27}` assertion before source archiving or
any test command. The command specified systemd AllowedCPUs but omitted taskset;
that does not satisfy the independently checked process affinity on this host.
No GPU or performance experiment occurred. Original driver and actual scope
identity/recursive-empty closure are retained. Next launcher adds the same
explicit process affinity; no production change or relaxation of the assertion.
