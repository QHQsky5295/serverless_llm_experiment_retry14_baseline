"""Reuse explicit checkpoint checks for D562; preserve both repos' user dirt."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/loquetier/d562_derived_batch_prelaunch'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
identity=p.scope_identity(p.cg_path().name)
save(RAW/'publication_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
receipt=read(RAW/'qualification_receipt.json')
assert receipt['passed'] and receipt['returncode']==0
assert re.search(r'Ran 17 tests in [0-9.]+s\s+OK\n', (RAW/'qualification.log').read_text())
assert git(BASE,'diff','--name-only','--','scripts','Loquetier_project').splitlines()==[
    'Loquetier_project/scripts/run_loquetier_trace_gate.py',
    'scripts/replay_openai_trace.py','scripts/run_serverlessllm_relayserve_continuation.sh']
with tarfile.open(RAW/'qualification_source.tar.gz') as nested:
    for member in nested.getmembers():
        assert member.isfile() and member.size<2*1024*1024
        assert hashlib.sha256(nested.extractfile(member).read()).hexdigest()==receipt['sources'][str(BASE/member.name)]
qualification=dict(passed=True,tests=17,refs=receipt['sources'],cpu_only=True,
    native_gpu_forward_qualified=False,production_changed=False,receipt=receipt,
    preserved={
        str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
        str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
        str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'})
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'qualification.json',qualification)
assert qualification['passed'] and qualification['tests']==17
for path,sha in {**qualification['refs'],**qualification['preserved']}.items():
    assert p.digest(Path(path))==sha,path
assert p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')['pass']
closed=read(RAW/'qualification_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and not Path(closed['identity']['path']).exists()
assert git(ROOT,'rev-parse','HEAD')=='c30a288890abf530498fb1dfd51b1eb045172a56'
assert git(BASE,'rev-parse','HEAD')=='a3d4fbdd6c9bf00cbf3536ab72ce29a322668c15'
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    if data.startswith(b'\x1f\x8b'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as nested:
            for member in nested.getmembers():
                assert member.isfile() and member.size<2*1024*1024
                clean(nested.extractfile(member).read())
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
def publish(repo,paths,branch,remote,message):
    assert git(repo,'branch','--show-current')==branch
    assert not git(repo,'diff','--cached','--name-only')
    for name in paths:
        data=(repo/name).read_bytes();assert len(data)<2*1024*1024
        if not name.endswith('.tar.gz'):clean(data)
    subprocess.run(['git','diff','--check'],cwd=repo,check=True)
    subprocess.run(['git','add','--',*paths],cwd=repo,check=True)
    assert set(git(repo,'diff','--cached','--name-only').splitlines())==set(paths)
    assert not any(name in paths for name in ('configs/generated/lora_manifest_1000.json',
        'scripts/replay_openai_trace.py','scripts/run_serverlessllm_relayserve_continuation.sh'))
    for name in paths:
        assert hashlib.sha256(subprocess.check_output(['git','show',':'+name],cwd=repo)).hexdigest()==p.digest(repo/name)
    subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
    subprocess.run(['git','commit','-m',message],cwd=repo,check=True)
    subprocess.run(['git','push',remote,branch],cwd=repo,check=True)
    head=git(repo,'rev-parse','HEAD')
    assert git(repo,'ls-remote',remote,'refs/heads/'+branch).split()[0]==head
    return dict(head=head,remote_equal=True,files=paths)

# Archive only small source/receipts; no duplicate source trace or model assets.
files=[RAW/name for name in ('run_tests.py','close.py','publish.py',
    'qualification.log','qualification_identity.json','qualification_closure.json',
    'qualification_receipt.json','qualification_source.tar.gz','prepare.py',
    'prepare_receipt.json','prepare_identity.json','prepare_closure.json','launch.py','run_capacity.sh')]
files += [BASE/'tests/test_loquetier_native_generation.py',
    BASE/'tests/test_loquetier_static_capacity.py',BASE/'Loquetier_project/scripts/run_loquetier_trace_gate.py',
    BASE/'docs/ieee_tc/D562_LOQUETIER_DERIVED_BATCH_CAPACITY.md',
    ROOT/'docs/ieee_tc/D562_LOQUETIER_DERIVED_BATCH_CAPACITY.md',
    Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d531_20261015/backup.py')]
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<2*1024*1024;clean(data)
        name=f'{i:02d}_{path.name}'
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
baseline=publish(BASE,['tests/test_loquetier_static_capacity.py','Loquetier_project/scripts/run_loquetier_trace_gate.py',
    'docs/ieee_tc/D562_LOQUETIER_DERIVED_BATCH_CAPACITY.md'],
    'main','origin','tc: qualify opt-in native Loquetier derived-concurrency native capacity probe (D562)')
save(RAW/'baseline_backup_receipt.json',baseline)
save(OUT/'manifest.json',dict(passed=True,tests=17,baseline_checkpoint=baseline,
    source_plan_sha256=p.check_plan(),
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_revision_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    qualification_sha256=p.digest(OUT/'qualification.json'),archive_sha256=p.digest(OUT/'evidence.tar.gz'),
    archive_members=members,preparation_only=True,no_inference_started=True))
outputs=('qualification.json','manifest.json','evidence.tar.gz')
with (OUT/'result.sha256').open('x') as f:
    for name in outputs:f.write(p.digest(OUT/name)+'  '+name+'\n')
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
paths=['docs/ieee_tc/D562_LOQUETIER_DERIVED_BATCH_CAPACITY.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(ROOT)) for name in (*outputs,'result.sha256')]
main=publish(ROOT,paths,'retry14_continuous_queue_v2','faaslora_origin',
             'tc: preserve qualified Loquetier derived-concurrency native capacity probe preparation (D562)')
save(RAW/'publication_receipt.json',dict(passed=True,scope=identity,main=main,baseline=baseline,tests=17))
print(json.dumps(dict(passed=True,main=main,baseline=baseline)))
