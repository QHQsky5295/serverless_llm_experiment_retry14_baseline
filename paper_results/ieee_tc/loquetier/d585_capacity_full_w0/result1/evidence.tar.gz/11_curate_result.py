"""Reuse D544 bounded curation for D585 full W0 capacity observation."""
import hashlib, io, json, os, re, subprocess, sys, tarfile
from pathlib import Path
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=MAIN/'paper_results/ieee_tc/loquetier/d585_capacity_full_w0/result1'
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,row):
    with path.open('x') as f:json.dump(row,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);save(RAW/'result_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
audit=read(RAW/'audit_full4000.json')
assert audit['measurement_complete'] and audit['workload_passed']
assert audit['counts']==dict(N_plan=4000,N_arrived=4000,N_submitted=4000,N_terminal=4000,N_response=4000,N_failed=0)
assert audit['actual_native_output_tokens']==458224 and audit['native_revalidated_requests']==4000
assert audit['source_plan']['profile']=='W0' and audit['n_correct'] is None
assert audit['common_slo']['joint_good']==2474
assert all(audit[k]==0 for k in ('max_e2e_recomputation_error_ms','max_tpot_recomputation_error_ms','max_native_recompute_error_ms'))
for ref in audit['raw_sources']:assert p.digest(Path(ref['path']))==ref['sha256'],ref['path']
for name in ('analysis','analysis2','cross'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and not Path(closed['identity']['path']).exists()
qualification=read(RAW/'qualification_final.json');tests=read(RAW/'analysis2_receipt.json')
assert qualification['passed'] and qualification['contract_checks_passed'] and not qualification['tests_rerun']
assert tests['passed'] and all(r['returncode']==0 for r in tests['commands'])
for path,sha in qualification['refs'].items():assert p.digest(Path(path))==sha
for path,sha in tests['source_sha256'].items():assert p.digest(Path(path))==sha
assert qualification['reused_analysis_tests']==69 and qualification['reused_online_tests']==86
cross=read(RAW/'cross_contract.json');diagnosis=read(RAW/'startup_capacity_diagnostic.json')
assert cross['passed'] and cross['request_count']==4000 and cross['changed_output_requests']==373
assert diagnosis['error_counts']=={}
assert diagnosis['native_enqueued_count']==diagnosis['native_completed_count']==4000
assert diagnosis['cancellation_count']==0
assert diagnosis['failed_without_native_terminal']==0 and not diagnosis['native_problem_records']
preserved={str(MAIN/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'}
for path,sha in preserved.items():assert p.digest(Path(path))==sha,path
protected=p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count']==147
subprocess.run(['git','diff','--exit-code','2765f7bbe2af8b0de44ec2e09fc447a769bb6365','--',
    'faaslora','scripts/ieee_tc_preflight.py','scripts/run_all_experiments.py'],cwd=MAIN,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()=='80e08b4c6e7c2874b1b237500a00811ec06cd8c5'
OUT.mkdir(parents=True,exist_ok=False)
files=[RAW/name for name in ('close_launch.py','stop_remote.sh','preserve_evidence.py','run_analysis.py',
    'run_analysis2.py','analysis2_receipt.json','analysis2_closure.json','analysis2.log',
    'cross_contract.py','close.py','close_postprocess.py','curate_result.py',
    'launch7b.json','local_cleanup.json','analysis_receipt.json','analysis_closure.json','analysis1.log',
    'cross_closure.json','remote_stop.log',
    'evidence_copy_receipt.json','http_7b_4000.json','native_7b.json','input_identity.json',
    'qualification_final.json','qualification_closure.json','qualification_source.tar.gz')]
files += [MAIN/'paper_results/ieee_tc/baseline_audit/d445_7b_loquetier_full_w0/audit.json']
files+=sorted((RAW/'model7b/worker_receipts').glob('*.json'))
files += [MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',MAIN/'tests/test_tc_serverless_qualification_population.py',
    MAIN/'docs/ieee_tc/D585_LOQUETIER_CAPACITY_FULL_W0_RESULT.md']
token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
members={};archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<32*1024*1024
        assert token and token not in data
        assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}',data)
        name=f'{i:02d}_{path.name}'
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o600;member.mtime=0
        tar.addfile(member,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(archive) as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
assert archive.stat().st_size<2*1024*1024
for dest,source in (('audit.json','audit_full4000.json'),('cross_contract.json','cross_contract.json'),
                    ('startup_capacity_diagnostic.json','startup_capacity_diagnostic.json')):
    with (OUT/dest).open('xb') as f:f.write((RAW/source).read_bytes())
save(OUT/'manifest.json',dict(passed=True,scope=identity,new_gpu_run=False,serving_changed=False,analysis_launcher_environment_repaired=True,
    analysis_changed=False,reference_frozen=False,performance_ranking_eligible=False,
    reason='D585 full W0 single development observation; not independently numerically proven or cross-scenario G1/G2 feasible',
    reused_native_tests=86,reused_offline_analysis_tests=69,
    execution_main_commit='2765f7bbe2af8b0de44ec2e09fc447a769bb6365',
    execution_baseline_commit='80e08b4c6e7c2874b1b237500a00811ec06cd8c5',
    metric_protocol_sha256=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_protocol_sha256=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    protected=protected,preserved=preserved,source_refs=audit['raw_sources'],archive_members=members,
    analysis_receipt_path=str(RAW/'analysis2_receipt.json'),analysis_receipt_sha256=p.digest(RAW/'analysis2_receipt.json'),
    outputs={n:p.digest(OUT/n) for n in ('audit.json','cross_contract.json','startup_capacity_diagnostic.json','evidence.tar.gz')}))
print(json.dumps(dict(passed=True,archive_bytes=archive.stat().st_size,scope=identity)))

