"""Reuse explicit checkpoint checks for D561; preserve both repos' user dirt."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
ROOT=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OUT=ROOT/'paper_results/ieee_tc/loquetier/d561_forward_capacity_result'
sys.path.insert(0,str(ROOT))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
identity=p.scope_identity(p.cg_path().name)
save(RAW/'result_publication_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
receipt=read(RAW/'qualification2_receipt.json')
assert receipt['passed'] and receipt['returncode']==0
assert re.search(r'Ran 14 tests in [0-9.]+s\s+OK\n', (RAW/'qualification2.log').read_text())
assert git(BASE,'diff','--name-only','--','scripts','Loquetier_project').splitlines()==[
    'scripts/replay_openai_trace.py','scripts/run_serverlessllm_relayserve_continuation.sh']
with tarfile.open(RAW/'qualification2_source.tar.gz') as nested:
    for member in nested.getmembers():
        assert member.isfile() and member.size<2*1024*1024
        assert hashlib.sha256(nested.extractfile(member).read()).hexdigest()==receipt['sources'][str(BASE/member.name)]
qualification=dict(passed=True,tests=14,refs=receipt['sources'],cpu_only=True,
    native_gpu_forward_qualified=True,production_changed=False,receipt=receipt,
    preserved={
        str(ROOT/'configs/generated/lora_manifest_1000.json'):'3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
        str(BASE/'scripts/replay_openai_trace.py'):'04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
        str(BASE/'scripts/run_serverlessllm_relayserve_continuation.sh'):'337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499'})
OUT.mkdir(parents=True,exist_ok=False)
save(OUT/'qualification.json',qualification)
assert qualification['passed'] and qualification['tests']==14
for path,sha in {**qualification['refs'],**qualification['preserved']}.items():
    assert p.digest(Path(path))==sha,path
assert p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')['pass']
closed=read(RAW/'qualification2_closure.json')
assert closed['passed'] and closed['actual_recursive_procs_empty'] and not Path(closed['identity']['path']).exists()
assert git(ROOT,'rev-parse','HEAD')=='82a8d125c47d381896935dda211a603feb8b2416'
assert git(BASE,'rev-parse','HEAD')=='9cce860b07dec32ac1ab5ab6f3adbbcd54ac87be'
native=read(RAW/'native_capacity.json');launch=read(RAW/'capacity_launch.json')
forward=native['forward_capacity'];cases=forward['cases']
assert native['passed'] and forward['passed'] and not native['runtime_qualified']
assert launch['pass'] and launch['service_returncode']==launch['watchdog_returncode']==0
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed']
assert not Path(launch['service_identity']['path']).exists()
cl=read(RAW/'launcher_closure.json')
assert cl['passed'] and cl['actual_recursive_procs_empty'] and not Path(cl['identity']['path']).exists()
assert len(cases)==1 and cases[0]['selection']=='max_prefill+max_context'
case=cases[0]
assert (case['prompt_tokens'],case['target_tokens'],case['batch_size'])==(760,256,2)
assert len(case['outputs'])==2 and len(case['samples'])==257
assert all(o['native_output_tokens']==o['native_forward_count']==len(o['completion_token_ids'])==256
    and o['matches_retained_output'] for o in case['outputs'])
assert case['samples'][-1]['live_kv_pages']==case['samples'][-1]['live_kv_bytes']==0
assert forward['release']['remaining_owners']==forward['release']['remaining_parameters']==0
assert forward['release']['allocated_reduction_bytes']==forward['release']['raw_storage_bytes']==5469372416
assert native['script_sha256']==p.digest(BASE/'Loquetier_project/scripts/run_loquetier_trace_gate.py')
peak=swap=samples=0;events={};available=[]
with (RAW/'capacity_launch.launch/watchdog.jsonl').open() as f:
    for line in f:
        row=json.loads(line)
        if row.get('event')!='resource_sample':continue
        samples+=1;svc=row['service'];peak=max(peak,svc['memory.peak']);swap=max(swap,svc['memory.swap.current'])
        available.append(row['host']['available_bytes'])
        assert not row['decision']['abort_reasons']
        for k,v in svc['memory.events'].items():events[k]=max(events.get(k,0),v)
assert all(v==0 for v in events.values()) and swap==0
summary=dict(passed=True,performance_run=False,independent_numerical_correctness=False,
    all_four_workers_qualified=False,higher_batch_qualified=False,mixed_prefill_decode_qualified=False,
    adapter_count=125,case_count=1,request_copies=2,
    input={k:v for k,v in forward['input'].items() if k!='cases'},
    source_request_id=case['source_request_id'],adapter_id=case['adapter_id'],
    prompt_tokens=760,target_tokens=256,outputs_match_retained=True,
    release=forward['release'],kv_page_bytes=forward['kv_page_bytes'],
    idle_allocated_bytes=case['idle_allocated_bytes'],
    peak_allocated_bytes=max(r['peak_allocated_bytes'] for r in case['samples']),
    peak_reserved_bytes=max(r['peak_reserved_bytes'] for r in case['samples']),
    maximum_live_kv_bytes=max(r['live_kv_bytes'] for r in case['samples']),
    prefill_peak_minus_end_allocated_bytes=case['samples'][1]['peak_allocated_bytes']-case['samples'][1]['allocated_bytes'],
    persistent_warm_allocated_delta=case['samples'][-1]['allocated_bytes']-case['idle_allocated_bytes'],
    minimum_sample_device_free_bytes=min(r['device_free_bytes'] for r in case['samples']),
    maximum_sample_inactive_split_bytes=max(r['inactive_split_bytes'] for r in case['samples']),
    stages=native['stages'],limitations=native['limitations'],watchdog_samples=samples,
    service_peak_bytes=peak,service_events=events,service_swap_bytes=swap,minimum_host_available_bytes=min(available),
    source_sha256={str(path):p.digest(path) for path in
        (RAW/'native_capacity.json',RAW/'capacity_launch.json',RAW/'capacity_launch.launch/watchdog.jsonl',
         RAW/'capacity_launch.launch/service.log',RAW/'launcher_closure.json',Path(__file__))})
save(OUT/'result.json',summary)

token=Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def clean(data):
    assert token and token not in data
    if data.startswith(b'\x1f\x8b'):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as nested:
            for member in nested.getmembers():
                assert member.isfile() and member.size<2*1024*1024
                clean(nested.extractfile(member).read())
    assert not re.search(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----|ghp_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{20,}|hf_[A-Za-z0-9]{25,}',data)
def publish(repo,paths,branch,remote,message):
    assert git(repo,'branch','--show-current')==branch
    assert not git(repo,'diff','--cached','--name-only')
    for name in paths:
        data=(repo/name).read_bytes();assert len(data)<2*1024*1024
        if not name.endswith('.tar.gz'):clean(data)
    subprocess.run(['git','diff','--check'],cwd=repo,check=True)
    subprocess.run(['git','add','--',*paths],cwd=repo,check=True)
    assert set(git(repo,'diff','--cached','--name-only').splitlines())==set(paths)
    assert not any(name in paths for name in ('configs/generated/lora_manifest_1000.json',
        'scripts/replay_openai_trace.py','scripts/run_serverlessllm_relayserve_continuation.sh'))
    for name in paths:
        assert hashlib.sha256(subprocess.check_output(['git','show',':'+name],cwd=repo)).hexdigest()==p.digest(repo/name)
    subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True)
    subprocess.run(['git','commit','-m',message],cwd=repo,check=True)
    subprocess.run(['git','push',remote,branch],cwd=repo,check=True)
    head=git(repo,'rev-parse','HEAD')
    assert git(repo,'ls-remote',remote,'refs/heads/'+branch).split()[0]==head
    return dict(head=head,remote_equal=True,files=paths)

# Archive only small source/receipts; no duplicate source trace or model assets.
files=[RAW/name for name in ('run_tests.py','close.py','publish.py','publish_result.py','native_capacity.json',
    'capacity_launch.json','capacity_launch.launch/exec_receipt.json','capacity_launch.launch/service.log',
    'launcher_identity.json','launcher_closure.json','publication_receipt.json','publication_closure.json',
    'qualification.log','qualification2.log','qualification_identity.json','qualification2_identity.json',
    'qualification_closure.json','qualification2_closure.json','qualification_receipt.json','qualification2_receipt.json',
    'qualification_source.tar.gz','qualification2_source.tar.gz','prepare.py','prepare2.py',
    'prepare_receipt.json','prepare2_receipt.json','prepare_identity.json','prepare2_identity.json',
    'prepare_closure.json','prepare2_closure.json','launch.py','run_capacity.sh')]
files += [BASE/'tests/test_loquetier_native_generation.py',
    BASE/'tests/test_loquetier_static_capacity.py',BASE/'Loquetier_project/scripts/run_loquetier_trace_gate.py',
    BASE/'docs/ieee_tc/D561_LOQUETIER_FORWARD_CAPACITY.md',
    ROOT/'docs/ieee_tc/D561_LOQUETIER_FORWARD_CAPACITY.md',
    Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/main_comparison/d531_20261015/backup.py')]
members={}
with tarfile.open(OUT/'evidence.tar.gz','x:gz') as tar:
    for i,path in enumerate(files):
        data=path.read_bytes();assert len(data)<2*1024*1024;clean(data)
        name=f'{i:02d}_{path.name}'
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
        members[name]=dict(path=str(path),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
with tarfile.open(OUT/'evidence.tar.gz','r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,ref in members.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==ref['sha256']
baseline=publish(BASE,['docs/ieee_tc/D561_LOQUETIER_FORWARD_CAPACITY.md'],
    'main','origin','tc: record native long-input Loquetier workspace evidence (D561)')
save(RAW/'baseline_result_backup_receipt.json',baseline)
save(OUT/'manifest.json',dict(passed=True,tests=14,baseline_checkpoint=baseline,
    source_plan_sha256=p.check_plan(),
    metric_protocol_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_revision_sha256=p.digest(ROOT/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    qualification_sha256=p.digest(OUT/'qualification.json'),archive_sha256=p.digest(OUT/'evidence.tar.gz'),
    archive_members=members,preparation_only=False,performance_run=False))
outputs=('qualification.json','result.json','manifest.json','evidence.tar.gz')
with (OUT/'result.sha256').open('x') as f:
    for name in outputs:f.write(p.digest(OUT/name)+'  '+name+'\n')
subprocess.run(['sha256sum','-c','result.sha256'],cwd=OUT,check=True)
paths=['docs/ieee_tc/D561_LOQUETIER_FORWARD_CAPACITY.md','docs/ieee_tc/EXECUTION_STATUS.md']
paths += [str((OUT/name).relative_to(ROOT)) for name in (*outputs,'result.sha256')]
main=publish(ROOT,paths,'retry14_continuous_queue_v2','faaslora_origin',
             'tc: preserve native Loquetier long-input capacity and closure (D561)')
save(RAW/'result_publication_receipt.json',dict(passed=True,scope=identity,main=main,baseline=baseline,tests=14))
print(json.dumps(dict(passed=True,main=main,baseline=baseline)))
