"""Reuse the already verified D560 native observation view, new full-input probe."""
import json
import os
from pathlib import Path
import subprocess
import sys
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
OLD=RAW.parent/'d560_20261016'
sys.path[:0]=[str(MAIN),str(BASE/'scripts'),str(BASE/'Loquetier_project/scripts')]
from scripts import ieee_tc_preflight as p
from replay_vllm_engine_trace import verify_loquetier_source_view
from run_loquetier_trace_gate import _capacity_inputs
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'prepare_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
qualification=read(RAW/'qualification_receipt.json');assert qualification['passed']
assert read(RAW/'qualification_closure.json')['path_gone']
for name,expected in qualification['sources'].items():assert p.digest(Path(name))==expected,name
cfg=read(BASE/'configs/ieee_tc/loquetier_7b_static_native_v1.json')
prep=read(OLD/'prepare_receipt.json');view=Path(prep['source_view'])
assert p.digest(view/'measurement_manifest.json')==prep['source_view_sha256']
verify_loquetier_source_view(dict(cfg,main_repo=str(MAIN),source_view=str(view),
    source_view_manifest_sha256=p.digest(view/'measurement_manifest.json')))
journal=Path(prep['input']['journal'])
inputs=_capacity_inputs(journal,prep['input']['journal_sha256'])
plan=read(BASE/'paper_results/ieee_tc/loquetier/d437_7b_static_capacity.json')
shard=max(plan['shards'],key=lambda s:(s['weights_and_kv_accounted_bytes'],-s['index']))
assert all(c['adapter_id'] in shard['adapter_ids'] for c in inputs['cases'])
save(RAW/'prepare_receipt.json',dict(passed=True,identity=identity,
    plan_sha256=p.check_plan(),source_view=str(view),source_view_sha256=prep['source_view_sha256'],
    input=inputs,prior_ownership_evidence_sha256=p.digest(OLD/'native_capacity.json'),
    source_sha256={str(x):p.digest(x) for x in (Path(__file__),BASE/'Loquetier_project/scripts/run_loquetier_trace_gate.py',
        BASE/'scripts/replay_vllm_engine_trace.py',BASE/'configs/ieee_tc/loquetier_7b_static_native_v1.json')},
    no_serving_policy_change=True,no_gpu_run=True))
print(json.dumps(dict(passed=True,inputs=[{k:v for k,v in c.items() if k not in ('prompt_ids','retained_output_ids')} for c in inputs['cases']])))
