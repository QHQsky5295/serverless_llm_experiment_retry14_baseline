"""Reuse D544 source-view refresh; no new native source/config or data pool."""
import json
import os
from pathlib import Path
import subprocess
import sys
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path[:0]=[str(MAIN),str(BASE),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from prepare_ieee_tc_serverless_stack import prepare_loquetier_measurement_view
from replay_vllm_engine_trace import verify_loquetier_source_view
from Loquetier_project.scripts.run_loquetier_trace_gate import _ownership_prompt
def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name);group=Path(identity['path'])
save(RAW/'prepare2_identity.json',identity)
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27}
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
qualification=read(RAW/'qualification_receipt.json');assert qualification['passed']
assert read(RAW/'qualification_closure.json')['path_gone']
for name,expected in qualification['sources'].items():assert p.digest(Path(name))==expected,name
cfg=read(BASE/'configs/ieee_tc/loquetier_7b_static_native_v1.json')
old=read(Path(cfg['source_view'])/'measurement_manifest.json')
view=RAW/'source_view'
manifest=prepare_loquetier_measurement_view(BASE/'vendor_new_baselines/Loquetier_main_20260520',view,MAIN)
assert manifest['original_sha256']==old['original_sha256']
assert manifest['measured_sha256']==old['measured_sha256']
verify_loquetier_source_view(dict(cfg,main_repo=str(MAIN),source_view=str(view),
    source_view_manifest_sha256=p.digest(view/'measurement_manifest.json')))
journal=Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/loquetier_qualification/d445_20261012/model7b/worker_0.native_events.jsonl')
prompt=_ownership_prompt(journal,p.digest(journal))
save(RAW/'prepare_receipt.json',dict(passed=True,identity=identity,
    plan_sha256=p.check_plan(),source_view=str(view),source_view_sha256=p.digest(view/'measurement_manifest.json'),
    source_native_unchanged=True,source_measurement_unchanged=True,input=prompt,
    source_sha256={str(x):p.digest(x) for x in (Path(__file__),BASE/'Loquetier_project/scripts/run_loquetier_trace_gate.py',
        BASE/'scripts/replay_vllm_engine_trace.py',BASE/'configs/ieee_tc/loquetier_7b_static_native_v1.json')},
    no_serving_policy_change=True,no_gpu_run=True))
print(json.dumps(dict(passed=True,source_view_sha256=p.digest(view/'measurement_manifest.json'),
    input_journal_sha256=prompt['journal_sha256'],source_request_id=prompt['source_request_id'])))
