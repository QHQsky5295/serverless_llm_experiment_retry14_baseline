"""Reuse D553 environment-split analysis tests; no production/dependency changes."""
import ast
import json
import os
from pathlib import Path
import re
import subprocess
import sys
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
identity=p.scope_identity(p.cg_path().name)
save(RAW/'contract_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
prior=json.loads((RAW/'qualification.json').read_text())
assert not prior['passed'] and prior['tests_returncode']==1
closed=json.loads((RAW/'qualification_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
changed_helpers={str(RAW/name) for name in ('backup.py','start.py','close.py')}
changes={}
for name,sha in prior['refs'].items():
    current=p.digest(Path(name))
    if name in changed_helpers:
        changes[name]=dict(qualified_snapshot_sha256=sha,current_sha256=current,
            reason='Prelaunch recipe fields corrected to actual prior nested commit identity, coverage profile and analysis test count; no serving change.')
    else:assert current==sha,name
log=(RAW/'cpu_contract_tests.log').read_text()
tests=['tests.test_tc_serverless_qualification_population.ElasticLocalityMatchedTests.'+name
       for name in ('test_extension_cannot_drop_prior_rows','test_streamed_controller_loader_requires_explicit_complete_scenario')]
failed={match[1] for match in re.findall(r'^(ERROR|FAIL): \S+ \(([^)]+)\)',log,re.M)}
assert failed==set(tests) and 'Ran 69 tests' in log
assert "ModuleNotFoundError: No module named 'ijson'" in log
command=['/home/qhq/.venvs/primelora_vllm0300_tc_20260925/bin/python','-B','-m','unittest',*tests,'-v']
with (RAW/'analysis_tests.log').open('x') as stream:
    result=subprocess.run(command,cwd=MAIN,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
assert result.returncode==0 and re.search(r'Ran 2 tests in [0-9.]+s\s+OK\n',(RAW/'analysis_tests.log').read_text())
for path in sorted(RAW.glob('*.py')):ast.parse(path.read_text(),filename=str(path))
for path in sorted(RAW.glob('*.sh')):subprocess.run(['bash','-n',str(path)],check=True)
record=dict(prior,passed=True,tests_returncode=0,tests=69,primary_passed_methods=67,
    environment_only_rechecks=2,initial_failures_retained=True,dependency_or_production_changes=False,
    corrected_prelaunch_helpers=changes,identity=identity,
    environment_rechecks=dict(command=command,returncode=0,log_sha256=p.digest(RAW/'analysis_tests.log')))
record['refs']={name:p.digest(Path(name)) for name in prior['refs']}
record['refs'].update({str(path):p.digest(path) for path in (Path(__file__),RAW/'qualification.json',RAW/'analysis_tests.log')})
save(RAW/'qualification_final.json',record)
print(json.dumps(dict(passed=True,tests=69,primary_passed=67,rechecked=2)))
