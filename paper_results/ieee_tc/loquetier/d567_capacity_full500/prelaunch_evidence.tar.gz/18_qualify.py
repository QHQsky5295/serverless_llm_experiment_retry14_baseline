"""Reuse D566 bounded qualification and D443 frozen full-pool input checks."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
PREVIOUS = RAW.parent/'d566_20261016'
sys.path[:0] = [str(MAIN), str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from prepare_ieee_tc_serverless_stack import load_http_replay_plan
from replay_vllm_engine_trace import validate_native_service_config, verify_loquetier_source_view

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
prior = json.loads((PREVIOUS/'qualification3_receipt.json').read_text())
assert prior['passed'] and prior['returncodes'] == [0,0,0]
for path, sha in prior['sources'].items():
    assert p.digest(Path(path)) == sha, path
for name in ('qualification3', 'publication'):
    closed = json.loads((PREVIOUS/(name+'_closure.json')).read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
http = json.loads((RAW/'http_7b_500.json').read_text())
cfg = json.loads((RAW/'native_7b.json').read_text())
assert (RAW/'http_7b_500.json').read_bytes() == (RAW.parent/'d443_20261012/http_7b_500.json').read_bytes()
assert (RAW/'native_7b.json').read_bytes() == (BASE/'configs/ieee_tc/loquetier_7b_prepared_capacity_v1.json').read_bytes()
validate_native_service_config(cfg, http)
verify_loquetier_source_view(dict(cfg, main_repo=str(MAIN)))
plan = load_http_replay_plan(http)
assert plan.identity()['view_sha256'] == '286f7547a8129fd6e75885379428b84c9a5c23a7eb02bf1d7546f49bcf2cee5d'
rows = [json.loads(e.source_json) for e in plan.entries]
assert len(rows) == len({r['adapter_id'] for r in rows}) == 500
assert sum(min(r['expected_output_tokens'],256) for r in rows) == 68925
sources = [MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',
    MAIN/'tests/test_tc_loquetier_evidence.py', MAIN/'tests/test_tc_serverless_qualification_population.py',
    BASE/'scripts/replay_vllm_engine_trace.py', BASE/'scripts/prepare_ieee_tc_serverless_stack.py',
    PREVIOUS/'qualification3_receipt.json', PREVIOUS/'qualification3_closure.json',
    PREVIOUS/'publication_closure.json', *sorted(RAW.glob('*.py')), *sorted(RAW.glob('*.sh')),
    RAW/'native_7b.json', RAW/'http_7b_500.json']
for path in sources:
    if path.suffix == '.py':
        ast.parse(path.read_text(), filename=str(path))
    elif path.suffix == '.sh':
        subprocess.run(['bash','-n',str(path)],check=True)
with tarfile.open(RAW/'qualification_source.tar.gz','x:gz') as archive:
    for i,path in enumerate(sources):
        archive.add(path, arcname=f'{i:02d}_{path.name}', recursive=False)
command = [sys.executable,'-B','-m','unittest','tests.test_tc_loquetier_evidence',
           'tests.test_tc_serverless_qualification_population','-v']
with (RAW/'cpu_contract_tests.log').open('x') as log:
    result = subprocess.run(command,cwd=MAIN,stdout=log,stderr=subprocess.STDOUT,timeout=180)
record = dict(passed=result.returncode==0,tests_returncode=result.returncode,command=command,
    input_identity=plan.identity(),actual_unique_adapters=500,target_tokens=68925,
    reused_online_tests=86,native_service_source_unchanged_since_D566=True,
    inference_capacity=cfg['inference_capacity'],identity=identity,
    refs={str(path):p.digest(path) for path in sources+[RAW/'cpu_contract_tests.log',RAW/'qualification_source.tar.gz']},
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')})
save(RAW/'qualification.json',record)
print(json.dumps(dict(passed=record['passed'],tests_returncode=result.returncode,input_identity=plan.identity())),flush=True)
assert record['passed']
