"""D567: reuse D423 input/cache sealing with explicit Loquetier native identity."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path[:0] = [str(MAIN), str(BASE/'scripts')]
from prepare_ieee_tc_serverless_stack import load_http_replay_plan
from replay_vllm_engine_trace import _exclusive_json, _sha, validate_native_service_config, verify_loquetier_source_view
http_path = ROOT/'http_7b_500.json'
cfg_path = ROOT/'native_7b.json'
http = json.loads(http_path.read_text())
cfg = json.loads(cfg_path.read_text())
validate_native_service_config(cfg, http)
verify_loquetier_source_view(dict(cfg, main_repo=str(MAIN)))
plan = load_http_replay_plan(http)
assert plan.identity()['view_sha256'] == '286f7547a8129fd6e75885379428b84c9a5c23a7eb02bf1d7546f49bcf2cee5d'
assert _sha(http['pool_index']) == http['pool_index_sha256']
rows = [json.loads(e.source_json) for e in plan.entries]
assert len(rows) == 500 and len({r['adapter_id'] for r in rows}) == 500
assert sum(min(r['expected_output_tokens'], 256) for r in rows) == 68925
pool = json.loads(Path(http['pool_index']).read_text())['artifacts']
assert len(pool) == 500
assert {r['adapter_id'] for r in rows} == {r['id'] for r in pool}
_exclusive_json(ROOT/'input_identity.json', dict(plan=plan.identity(),
    actual_unique_adapters=500, target_tokens=68925, native_pool_adapters=500,
    performance_ranking_eligible=False, qualification_only=True,
    source_trace_and_pool_unmodified=True,
    http_sha256=_sha(http_path), config_sha256=_sha(cfg_path),
    source_view_manifest_sha256=cfg['source_view_manifest_sha256'],
    main_execution_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip(),
    baseline_execution_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip()))
print(json.dumps(dict(input=plan.identity(), native_kernel_sha256=cfg['native_kernel_sha256'], static_plan_sha256=cfg['static_plan_sha256'])))
