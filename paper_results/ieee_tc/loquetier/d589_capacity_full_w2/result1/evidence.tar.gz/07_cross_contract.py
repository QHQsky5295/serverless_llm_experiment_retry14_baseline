"""Reuse D587 native stage witness; join D589 W2 inputs to retained D557 vLLM."""
from collections import Counter
import json
import os
from pathlib import Path
import sys

MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW=Path(__file__).resolve().parent
BASE=Path('/home/qhq/serverless_llm_baselines')
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.audit_d402_serverlessllm_path import timing_stats
def read(path):return json.loads(path.read_text())
def save(path,row):
    with path.open('x') as f:json.dump(row,f,indent=2,allow_nan=False)
def events(path):return [json.loads(line) for line in path.open()]
scope=p.scope_identity(p.cg_path().name);save(RAW/'cross_identity.json',scope)
group=Path(scope['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
closed=read(RAW/'analysis_closure.json')
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
audit=read(RAW/'audit_full4000.json')
assert audit['measurement_complete'] and audit['workload_passed']
prior=RAW.parent.parent/'vllm_qualification/d557_20261016'
prior_audit=read(prior/'audit_full4000_w2.json')
assert prior_audit['measurement_complete'] and prior_audit['workload_passed']
assert audit['source_plan']==prior_audit['source_plan']
paths=[RAW/'launch7b.launch/replay.jsonl',prior/'launch7b.launch/replay.jsonl']
rows,prior_rows=map(events,paths)
def index(data,event):
    selected=[r for r in data if r['event']==event]
    keyed={r['request_id']:r for r in selected}
    assert len(keyed)==len(selected)
    return keyed
contracts,reference=index(rows,'request_contract'),index(prior_rows,'request_contract')
assert len(contracts)==4000 and contracts.keys()==reference.keys()
fields=('adapter_id','artifact_content_sha256','artifact_manifest_sha256','canonical_prompt_sha256',
    'canonical_prompt_tokens','native_prompt_token_ids_sha256','source_item_sha256','target_tokens','tc_adapter_rotation')
for rid in contracts:
    for key in fields:assert contracts[rid][key]==reference[rid][key],(rid,key)
created=index(rows,'request_created');ref_created=index(prior_rows,'request_created')
business=read(RAW/'launch7b.launch/exec_receipt.json')['external_replay']['replay_t0_s']
ref_business=read(prior/'launch7b.launch/exec_receipt.json')['external_replay']['replay_t0_s']
arrival_error=max(abs((created[r]['planned_arrival_s']-business)-(ref_created[r]['planned_arrival_s']-ref_business)) for r in contracts)
assert arrival_error<=1e-8
raw_now=index(rows,'http_raw_response');raw_ref=index(prior_rows,'http_raw_response')
assert raw_now.keys()==raw_ref.keys()==contracts.keys()
assert len(index(prior_rows,'http_response'))==4000
assert not index(prior_rows,'http_request_failed')
for rid in contracts:
    now=raw_now[rid]['body']['metrics']['ieee_tc']
    ref=raw_ref[rid]['body']['metrics']['ieee_tc']
    assert now['native_prompt_token_ids']==ref['native_prompt_token_ids'],rid
    assert now['native_adapter_id']==ref['native_lora_name']==contracts[rid]['adapter_id'],rid
    assert len(now['completion_token_ids'])==len(ref['completion_token_ids'])==contracts[rid]['target_tokens']
save(RAW/'cross_contract.json',dict(passed=True,schema='d589_full4000_w2_cross_system_input_witness_v1',
    scope=scope,request_count=4000,source_plan=audit['source_plan'],
    compared_fields=['request_id',*fields,'relative_planned_arrival_s','native_prompt_token_ids','native_adapter_binding','native_output_count'],
    arrival_max_error_s=arrival_error,reference_system='vLLM',reference_run='D557',
    output_token_equality_required=False,independent_numerical_correctness=False,
    initial_state_contract_identical=False,reference_frozen=False,performance_ranking_eligible=False,
    limitations=['Same complete W2 offered input, canonical/native prompt, adapter and target work.',
        'Cross-backend output-token equality is not a numerical oracle and is not required by V1.',
        'Distinct native preparation/cache policies remain; no equality of realized cache/page-cache state is asserted.',
        'One known-source development observation; not an independent holdout or cross-scenario optimum.'],
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in (*paths,RAW/'audit_full4000.json',prior/'audit_full4000_w2.json',Path(__file__))]))
cfg=read(RAW/'model7b/worker_config.json');qual=read(RAW/'model7b/model_qualification.json')
ready_paths=sorted((RAW/'model7b/worker_receipts').glob('*.json'))
ready=sorted(map(read,ready_paths),key=lambda r:r['index'])
assert len(ready)==4 and all(len(r['adapter_ids'])==125 for r in ready)
shards={aid:r['index'] for r in ready for aid in r['adapter_ids']};assert len(shards)==500
fail=index(rows,'http_request_failed');success=index(rows,'http_response');raw=index(rows,'http_raw_response')
assert len(fail)==0 and len(success)==4000 and not fail.keys()&success.keys()
assert fail.keys()|success.keys()==contracts.keys()
errors=Counter(r['error'] for r in fail.values())
timeouts=[r['client_completed_s']-r['planned_arrival_s'] for r in fail.values()]
enqueue={};completed={};cancelled={};native_events={};native_problems=[];worker_records=[]
native_paths=sorted((RAW/'model7b').glob('worker_*.native_events.jsonl'))
for i,path in enumerate(native_paths):
    data=events(path);native_events[str(i)]=dict(Counter(r['event'] for r in data))
    for row in data:
        rid=row.get('request_id')
        if rid is not None:assert shards[contracts[rid]['adapter_id']]==i
        if row['event']=='loquetier_online_enqueued':
            assert rid not in enqueue;enqueue[rid]=row
        elif row['event']=='loquetier_native_completed':
            assert rid not in completed;completed[rid]=row
        elif row['event']=='loquetier_request_cancelled':
            assert rid not in cancelled;cancelled[rid]=row
        if row.get('error') or row['event'] in ('loquetier_native_failure','loquetier_cleanup_failure','loquetier_registration_failed'):
            native_problems.append(dict(worker=i,record=row))
    row=ready[i];acquire=[e['at'] for e in qual['physical_allocations'][i]['events'] if e['event']=='acquire']
    assert len(acquire)==1
    worker_records.append(dict(index=i,adapter_count=len(row['adapter_ids']),ready_s=row['at'],
        business_to_ready_s=row['at']-business,acquire_to_ready_s=row['at']-acquire[0],
        offered=sum(shards[r['adapter_id']]==i for r in contracts.values()),
        successful=sum(shards[contracts[r]['adapter_id']]==i for r in success),
        failed=sum(shards[contracts[r]['adapter_id']]==i for r in fail),
        inference_capacity=row['inference_capacity'],native_args=row['native_args']))
stages={k:[] for k in ('native_queue_before_register_ms','register_to_first_ms','native_decode_ms')}
for rid in success:
    obs=raw[rid]['body']['metrics']['ieee_tc'];end=completed[rid]['observation']
    assert end['native_output_tokens']==contracts[rid]['target_tokens']
    assert obs['native_first_token_monotonic_s']==end['native_first_token_monotonic_s']
    stages['native_queue_before_register_ms'].append(1000*(end['native_registered_monotonic_s']-enqueue[rid]['at']))
    stages['register_to_first_ms'].append(1000*(end['native_first_token_monotonic_s']-end['native_registered_monotonic_s']))
    stages['native_decode_ms'].append(1000*(end['native_last_token_monotonic_s']-end['native_first_token_monotonic_s']))
preparation_path=RAW/'model7b/loquetier_full_pool_preparation.json';prep=read(preparation_path)
failure_rows=[dict(request_id=rid,index=fail[rid]['index'],worker=shards[contracts[rid]['adapter_id']],
    elapsed_s=fail[rid]['client_completed_s']-fail[rid]['planned_arrival_s'],
    enqueued=rid in enqueue,native_completed=rid in completed,cancellation_record=cancelled.get(rid),
    native_completion_after_client_failure_s=(completed[rid]['observation']['worker_completed_monotonic_s']-fail[rid]['client_completed_s'] if rid in completed else None)) for rid in fail]
record=dict(scope=scope,error_counts=dict(errors),timeout_elapsed_s=timing_stats(timeouts),
    event_counts=dict(Counter(r['event'] for r in rows)),native_event_counts=native_events,
    native_problem_records=native_problems,worker_ready=worker_records,
    native_enqueued_count=len(enqueue),native_completed_count=len(completed),cancellation_count=len(cancelled),
    failed_native_completed=sum(r in completed for r in fail),failed_cancellation_recorded=sum(r in cancelled for r in fail),
    failed_without_native_terminal=sum(r not in completed and r not in cancelled for r in fail),
    failure_rows=failure_rows,successful_latency_stages_ms={k:timing_stats(v) for k,v in stages.items()},
    deployment_notice_s=cfg['deployment_notice_s'],business_start_s=business,
    full_pool_prepare_start_s=min(r['tc_artifact_resolve_started_s'] for r in prep.values()),
    full_pool_prepare_end_s=max(r['tc_artifact_resolve_completed_s'] for r in prep.values()),
    full_pool_count=len(prep),worker_startup=cfg['worker_startup'],
    phase_counts=[dict(source_indices_inclusive=r['source_indices_inclusive'],**r['common_slo']) for r in audit['source_order_diagnostics']],
    causal_attribution_complete=False,
    official_workflow_url='https://raw.githubusercontent.com/NJUDeepEngine/Loquetier/aae33baeeb19777129c1ccbff99a898d4a0e2c63/src/loquetier_src/model_workflow.py',
    limitations=['Official workflow batch-bound admission/generate loop is retained in an online FIFO adapter; static125-ID shards and evidence-derived batch8 define this deployment.',
        'No request-time packing/fetch, no OOM/high/swap event; absence does not establish a unique cause.',
        'No independent numerical oracle; cross-backend input equality does not establish numerical equivalence.'],
    refs=[dict(path=str(x),sha256=p.digest(x)) for x in (*native_paths,*ready_paths,preparation_path,RAW/'model7b/model_qualification.json',BASE/'scripts/replay_vllm_engine_trace.py',Path(__file__))])
save(RAW/'startup_capacity_diagnostic.json',record)
print(json.dumps({k:record[k] for k in ('error_counts','timeout_elapsed_s','native_event_counts','worker_ready','native_problem_records','failed_native_completed','failed_cancellation_recorded','failed_without_native_terminal','successful_latency_stages_ms')}))
