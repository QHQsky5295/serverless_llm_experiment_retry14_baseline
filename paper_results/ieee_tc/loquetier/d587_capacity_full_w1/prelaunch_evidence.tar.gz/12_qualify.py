"""Reuse D567 source-qualified checks; bind D544's full W1 after D569 compatibility."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
from types import SimpleNamespace

MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
PRIOR=RAW.parent/'d567_20261016'
sys.path[:0]=[str(MAIN),str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.audit_d402_serverlessllm_path import validate_population
from prepare_ieee_tc_serverless_stack import load_http_replay_plan
from replay_vllm_engine_trace import validate_native_service_config, verify_loquetier_source_view

def read(path):return json.loads(path.read_text())
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)

identity=p.scope_identity(p.cg_path().name)
save(RAW/'qualification_identity.json',identity)
group=Path(identity['path'])
assert (group/'memory.high').read_text().strip()==str(3*p.GIB)
assert (group/'memory.max').read_text().strip()==str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip()=='0'
assert os.sched_getaffinity(0)=={2,3,26,27} and os.environ['CUDA_VISIBLE_DEVICES']==''
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
assert p.check_plan()=='d7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
prior=read(PRIOR/'qualification_final.json')
assert prior['passed'] and prior['tests']==69 and prior['reused_online_tests']==86
for path,sha in prior['refs'].items():assert p.digest(Path(path))==sha,path
for name in ('qualification','contract','analysis','cross','result','result_publication'):
    closed=read(PRIOR/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
coverage=PRIOR/'audit_adapter_coverage_v1.json'
assert p.digest(coverage)=='4a131744ab34af981ccbb636e77427bb47c2523c1eeb1e9f8e2e946142913544'
audit=read(coverage)
assert audit['workload_passed'] and audit['measurement_complete']
assert audit['native_revalidated_requests']==500 and audit['actual_native_output_tokens']==68925
assert audit['offered_unique_adapters']==500 and audit['counts']['N_failed']==0
for ref in audit['scheduler_qualification']['native_worker_receipts']:
    assert p.digest(Path(ref['path']))==ref['sha256']
compat=RAW.parent/'d569_20261016'
compat_audit=compat/'audit_prefix1000.json'
assert p.digest(compat_audit)=='31737ac6b8e4721aa52885d6beca45a1f7c27f9fdf58435df83beacab9b88cfe'
compatibility=read(compat_audit)
assert compatibility['workload_passed'] and compatibility['measurement_complete']
assert compatibility['native_revalidated_requests']==1000 and compatibility['counts']['N_failed']==0
assert compatibility['actual_native_output_tokens']==122510
for role in ('qualification','backup','start','analysis','cross','result','result_publication'):
    closed=read(compat/(role+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
http_path=RAW/'http_7b_4000.json';cfg_path=RAW/'native_7b.json'
old_http=RAW.parent/'d544_20261015/http_7b_4000.json'
assert p.digest(old_http)=='ad2868ca14b33af9620807e3ec073ece1a83fb0302abe5cbecba6a53d1747440'
# The new text file adds only the terminal LF; every configuration value is reused.
assert http_path.read_bytes()==old_http.read_bytes()+b'\n'
assert read(http_path)==read(old_http)
assert cfg_path.read_bytes()==(PRIOR/'native_7b.json').read_bytes()
assert cfg_path.read_bytes()==(BASE/'configs/ieee_tc/loquetier_7b_prepared_capacity_v1.json').read_bytes()
http=read(http_path);cfg=read(cfg_path)
validate_native_service_config(cfg,http)
verify_loquetier_source_view(dict(cfg,main_repo=str(MAIN)))
plan=load_http_replay_plan(http)
assert plan.identity()==read(RAW.parent/'d544_20261015/input_identity.json')['plan']
assert plan.identity()['view_sha256']=='103ac4add35a43c4c2859cb1d9118ea18971186e7332ba8f025eb2754e98d9a3'
rows=[json.loads(e.source_json) for e in plan.entries]
assert len(rows)==4000 and len({r['adapter_id'] for r in rows})==132
assert sum(min(r['expected_output_tokens'],256) for r in rows)==458224
contracts={e.request_id:dict(source_item_sha256=e.source_sha256,
    adapter_id=json.loads(e.source_json)['adapter_id'],
    target_tokens=min(json.loads(e.source_json)['expected_output_tokens'],256)) for e in plan.entries}
assert validate_population(http,dict(plan=plan.identity()),contracts,
    SimpleNamespace(load_http_replay_plan=load_http_replay_plan),'full4000_w1')==4000
sources=[MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',
    MAIN/'tests/test_tc_loquetier_evidence.py',MAIN/'tests/test_tc_serverless_qualification_population.py',
    BASE/'scripts/replay_vllm_engine_trace.py',BASE/'scripts/prepare_ieee_tc_serverless_stack.py',
    PRIOR/'qualification_final.json',coverage,PRIOR/'result_publication_closure.json',compat_audit,compat/'result_publication_closure.json',
    RAW.parent/'d544_20261015/input_identity.json',old_http,*sorted(RAW.glob('*.py')),
    *sorted(RAW.glob('*.sh')),cfg_path,http_path]
for path in sources:
    if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
    elif path.suffix=='.sh':subprocess.run(['bash','-n',str(path)],check=True)
with tarfile.open(RAW/'qualification_source.tar.gz','x:gz') as archive:
    for i,path in enumerate(sources):archive.add(path,arcname=f'{i:02d}_{path.name}',recursive=False)
record=dict(passed=True,contract_checks_passed=True,tests_rerun=False,
    input_identity=plan.identity(),actual_unique_adapters=132,target_tokens=458224,
    reused_online_tests=86,reused_analysis_tests=69,
    native_service_source_unchanged_since_D566=True,
    previous_full500_coverage_reused=True,previous_prefix1000_compatibility_reused=True,independent_numerical_correctness='unknown',
    inference_capacity=cfg['inference_capacity'],identity=identity,
    refs={str(path):p.digest(path) for path in sources+[RAW/'qualification_source.tar.gz']},
    resources={key:(group/key).read_text() for key in ('memory.peak','memory.events','memory.swap.current')})
save(RAW/'qualification_final.json',record)
print(json.dumps(dict(passed=True,input_identity=plan.identity(),reused_online_tests=86,reused_analysis_tests=69,tests_rerun=False)),flush=True)
