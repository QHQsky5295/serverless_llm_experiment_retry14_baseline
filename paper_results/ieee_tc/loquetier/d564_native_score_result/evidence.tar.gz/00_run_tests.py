"""D541 bounded regression receipt pattern, reused for Loquetier native representation ownership."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
RAW = Path(__file__).resolve().parent
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

phase = sys.argv[1]
assert phase in ('before', 'qualification', 'regression')
identity = p.scope_identity(p.cg_path().name)
group = Path(identity['path'])
with (RAW / (phase + '_identity.json')).open('x') as f:
    json.dump(identity, f, indent=2)
assert (group / 'memory.high').read_text().strip() == str(3 * p.GIB)
assert (group / 'memory.max').read_text().strip() == str(4 * p.GIB)
assert (group / 'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
BASE = Path('/home/qhq/serverless_llm_baselines')
sources = [BASE / name for name in ('tests/test_loquetier_native_generation.py', 'tests/test_loquetier_static_capacity.py',
    'tests/test_ieee_tc_loquetier_measurement.py', 'scripts/ieee_tc_serverless_measurement.py',
    'scripts/replay_vllm_engine_trace.py', 'Loquetier_project/scripts/run_loquetier_trace_gate.py',
    'vendor_new_baselines/Loquetier_main_20260520/src/loquetier_src/virtual_model.py',
    'vendor_new_baselines/Loquetier_main_20260520/src/loquetier_src/models/mixed_lora.py',
    'vendor_new_baselines/Loquetier_main_20260520/src/loquetier_src/model_generation.py')]
with tarfile.open(RAW / (phase + '_source.tar.gz'), 'x:gz') as archive:
    for path in sources:
        archive.add(path, arcname=str(path.relative_to(BASE)), recursive=False)
tests = ['tests.test_loquetier_static_capacity',
    'tests.test_loquetier_native_generation.NativeGenerationRules.test_prepared_fp16_copy_survives_fp32_peft_owner_collection',
    'tests.test_loquetier_native_generation.NativeGenerationRules.test_prepared_alias_retains_storage_after_fp16_parameter_collection',
    'tests.test_loquetier_native_generation.NativeGenerationRules.test_owner_inventory_tracks_content_storage_and_releases_input']
if phase == 'before':
    tests = ['tests.test_ieee_tc_loquetier_measurement.NativeLoquetierObservationTests.test_capacity_schedules_share_native_registry_without_reusing_request_ids']
commands = [[sys.executable, '-B', '-m', 'unittest', *tests, '-v']]
if phase != 'before':
    # Fresh interpreter prevents native source-view imports leaking across suites.
    commands.append([sys.executable, '-B', '-m', 'unittest', 'tests.test_ieee_tc_loquetier_measurement', '-v'])
returncodes = []
with (RAW / (phase + '.log')).open('x') as log:
    for command in commands:
        result = subprocess.run(command, cwd=BASE, stdout=log, stderr=subprocess.STDOUT, timeout=240)
        returncodes.append(result.returncode)
record = dict(passed=all(code == 0 for code in returncodes), phase=phase, commands=commands,
    returncodes=returncodes, identity=identity,
    sources={str(path): p.digest(path) for path in sources + [Path(__file__),
        RAW / (phase + '.log'), RAW / (phase + '_source.tar.gz')]},
    resources={k: (group / k).read_text() for k in ('memory.peak', 'memory.events', 'memory.swap.current')})
with (RAW / (phase + '_receipt.json')).open('x') as f:
    json.dump(record, f, indent=2)
print(json.dumps(record), flush=True)
assert record['passed']
