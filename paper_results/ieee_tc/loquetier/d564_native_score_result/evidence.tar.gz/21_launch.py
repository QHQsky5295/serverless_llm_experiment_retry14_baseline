"""Reuse guarded D560/D438 launch, only the full-input diagnostic changes."""
import json
import os
from pathlib import Path
import sys
MAIN=Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE=Path('/home/qhq/serverless_llm_baselines')
RAW=Path(__file__).resolve().parent
sys.path.insert(0,str(MAIN))
from scripts import ieee_tc_preflight as p
def read(path):return json.loads(path.read_text())
identity=p.scope_identity(p.cg_path().name)
with (RAW/'launcher_identity.json').open('x') as f:json.dump(identity,f,indent=2)
prep=read(RAW/'prepare_receipt.json');assert prep['passed']
for name in ('qualification','prepare','publication'):
    closed=read(RAW/(name+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty']
    assert not Path(closed['identity']['path']).exists()
for path,sha in prep['source_sha256'].items():assert p.digest(Path(path))==sha,path
assert read(RAW/'publication_receipt.json')['passed']
command=[sys.executable,str(MAIN/'scripts/ieee_tc_preflight.py'),'gated-launch',
    '--output',str(RAW/'capacity_launch.json'),'--predicted-growth-gib','2','--exec',
    '/home/qhq/anaconda3/envs/loquetier_20260520/bin/python','-B',
    str(BASE/'Loquetier_project/scripts/run_loquetier_trace_gate.py'),
    '--native-capacity-probe','--forward-capacity-probe',
    '--capacity-evidence',prep['capacity_evidence'],'--capacity-evidence-sha256',prep['capacity_evidence_sha256'],
    '--capacity-score-evidence',prep['capacity_score_evidence'],
    '--capacity-score-evidence-sha256',prep['capacity_score_evidence_sha256'],
    '--base-model','/home/qhq/serverless_llm_experiment/models/meta-llama--Llama-2-7b-hf',
    '--adapter-root','/home/qhq/serverless_llm_experiment/artifacts/frozen/llama2_7b_a500_v2_publicmix',
    '--static-capacity-plan',str(BASE/'paper_results/ieee_tc/loquetier/d437_7b_static_capacity.json'),
    '--measurement-view',prep['source_view'],'--measurement-view-sha256',prep['source_view_sha256'],
    '--ownership-input-journal',prep['input']['journal'],
    '--ownership-input-sha256',prep['input']['journal_sha256'],
    '--physical-gpu-id','0','--main-repo',str(MAIN),'--output',str(RAW/'native_capacity.json')]
os.execv(sys.executable,command)
