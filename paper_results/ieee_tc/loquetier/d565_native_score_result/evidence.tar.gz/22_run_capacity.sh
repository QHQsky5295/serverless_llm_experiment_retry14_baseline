#!/usr/bin/env bash
set -euo pipefail
RAW=/home/qhq/serverless_llm_experiment/results/ieee_tc/loquetier_qualification/d565_20261016
cd /home/qhq/serverless_llm_baselines
exec systemd-run --user --scope --unit=primelora-tc-aux-d5650000000000000000000000000006.scope \
  -p MemoryHigh=3G -p MemoryMax=4G -p MemorySwapMax=0 \
  taskset -c 2,3,26,27 env -u PYTHONPATH -u PYTHONHOME \
  FAASLORA_TC_NVML_BINDING=/home/qhq/anaconda3/envs/LLM_vllm0102/lib/python3.12/site-packages/pynvml.py \
  FAASLORA_TC_NVML_SHA256=4251429c25f1615a4166f395d3c09fe0732bfb023864c4b7f12813373e5696ea \
  CUDA_VISIBLE_DEVICES=0 PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 \
  HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
  /usr/bin/python3 -B "$RAW/launch.py"
