"""D651 bounded curation/checkpoint; reuse D649/D557 provenance and Git checks."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OUT = MAIN/'paper_results/ieee_tc/vllm/d651_3b_native_coverage'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'publication_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
audit = read(RAW/'audit_coverage500.json')
assert audit['measurement_complete'] and audit['workload_passed']
assert audit['native_revalidated_requests'] == 500 and audit['actual_native_output_tokens'] == 68925
assert audit['counts']['N_failed'] == 0 and audit['model_key'] == '3b'
assert audit['common_slo']['joint_good'] == 499 and audit['n_correct'] is None
assert not audit['formal_performance_qualified'] and not audit['complete_system_qualified']
assert all(audit[k] == 0 for k in ('max_e2e_recomputation_error_ms', 'max_tpot_recomputation_error_ms', 'max_native_recompute_error_ms'))
for ref in audit['raw_sources']:
    assert p.digest(Path(ref['path'])) == ref['sha256'], ref['path']
qualpath = RAW.parent/'d649_20261018/qualification.json'
qual = read(qualpath)
assert qual['passed'] and qual['tests'] == 89
for path, sha in {**qual['refs'], **qual['preserved']}.items():
    assert p.digest(Path(path)) == sha, path
for phase in ('start', 'analysis'):
    closed = read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
launch = read(RAW/'launch3b.json')
assert launch['pass'] and launch['service_returncode'] == 0 and launch['watchdog_returncode'] == 0
assert launch['service_path_removed'] and launch['native_gpu_context_release_confirmed']
cleanup = read(RAW/'local_cleanup.json')
assert cleanup['passed']
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
parents = {MAIN: '87be826ecc75461b52cad43285722b46beca18fe', BASE: 'e16af33aaf41f02a62ecdce59f6f3227813244c3'}
for repo, head in parents.items():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == head
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()
def check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}', data)
files = [RAW/name for name in (
    'publish.py', 'start.py', 'start_remote.sh', 'stop_remote.sh', 'check_remote_health_stdlib.py',
    'run3b.sh', 'close.py', 'close_launch.py', 'preserve_evidence.py', 'run_analysis.py',
    'http_3b_500.json', 'input_identity.json', 'launch_gate.json', 'launch3b.json',
    'start_identity.json', 'start_receipt.json', 'start_closure.json', 'service_aux_identity.json',
    'local_cleanup.json', 'analysis_identity.json', 'analysis_receipt.json', 'analysis_closure.json',
    'evidence_copy_receipt.json', 'remote_health.json', 'remote_start.log', 'remote_stop.log',
    'remote_transfers.jsonl', 'model3b/physical/physical_resource_summary.json',
    'model3b/physical/summary.json', 'model3b/model_qualification.json', 'model3b/worker_config.json',
    'model3b/native_toolchain.json')]
files += sorted((RAW/'model3b/worker_receipts').glob('*.json'))
files += sorted((RAW/'model3b').glob('worker_*.log'))
files += [RAW.parent/'d650_20261018'/name for name in (
    'reclaim_objects.py', 'cache_cleanup_before.json', 'cache_cleanup_after.json', 'qualification_closure.json')]
OUT.mkdir(parents=True, exist_ok=False)
members = {}
with tarfile.open(OUT/'execution_evidence.tar.gz', 'x:gz') as bundle:
    for path in files:
        data = path.read_bytes()
        check(data)
        assert len(data) < 32*1024*1024
        if path.suffix == '.py':
            ast.parse(data)
        name = str(path.relative_to(RAW.parent))
        info = tarfile.TarInfo(name)
        info.size = len(data); info.mode = 0o600; info.mtime = 0
        bundle.addfile(info, io.BytesIO(data))
        members[name] = dict(path=str(path), sha256=p.digest(path), bytes=len(data))
with tarfile.open(OUT/'execution_evidence.tar.gz') as bundle:
    assert set(bundle.getnames()) == set(members)
    for name, ref in members.items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == ref['sha256']
assert (OUT/'execution_evidence.tar.gz').stat().st_size < 2*1024*1024
with (OUT/'audit.json').open('xb') as f:
    f.write((RAW/'audit_coverage500.json').read_bytes())
save(OUT/'manifest.json', dict(passed=True, identity=identity,
    execution_main_commit=parents[MAIN], execution_baseline_commit=parents[BASE],
    role='3b_native_resident_coverage500_qualification', resource_reference_frozen=False,
    full_performance_qualified=False, service_source_changed=False,
    reused_tests=dict(count=89, path=str(qualpath), sha256=p.digest(qualpath)),
    metric_protocol_sha256=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md'),
    single_run_protocol_sha256=p.digest(MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md'),
    plan_sha256=p.check_plan(), preserved=qual['preserved'], protected=protected,
    source_refs=audit['raw_sources'], archive_members=members,
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    caveat='Native binding/length/timing qualification only; numerical proof unknown, no full W0/G1/G2 conclusion.'))
outputs = ['audit.json', 'manifest.json', 'execution_evidence.tar.gz']
with (OUT/'result.sha256').open('x') as f:
    for name in outputs:
        f.write(p.digest(OUT/name)+'  '+name+'\n')
names = ['docs/ieee_tc/D651_3B_NATIVE_500_ADAPTER_COVERAGE.md', 'docs/ieee_tc/EXECUTION_STATUS.md']
names += [str((OUT/name).relative_to(MAIN)) for name in outputs+['result.sha256']]
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=MAIN, text=True).strip()
subprocess.run(['sha256sum', '-c', 'result.sha256'], cwd=OUT, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=MAIN, check=True)
for name in names:
    check((MAIN/name).read_bytes())
subprocess.run(['git', 'add', '--', *names], cwd=MAIN, check=True)
assert set(subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=MAIN, text=True).splitlines()) == set(names)
assert 'configs/generated/lora_manifest_1000.json' not in names
for name in names:
    assert subprocess.check_output(['git', 'show', ':'+name], cwd=MAIN) == (MAIN/name).read_bytes()
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=MAIN, check=True)
subprocess.run(['git', 'commit', '-m', 'tc: seal 3B native Resident 500-ID remote coverage without full-performance claims (D651)'], cwd=MAIN, check=True)
subprocess.run(['git', 'push', 'faaslora_origin', 'retry14_continuous_queue_v2'], cwd=MAIN, check=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=MAIN, text=True).strip()
remote = subprocess.check_output(['git', 'ls-remote', 'faaslora_origin', 'refs/heads/retry14_continuous_queue_v2'], cwd=MAIN, text=True).split()[0]
assert head == remote
save(RAW/'publication_receipt.json', dict(passed=True, head=head, remote=remote, files=names,
    identity=identity, protected=protected, baseline_commit=parents[BASE]))
print(json.dumps(dict(passed=True, head=head, files=len(names), remote_equal=True)))
