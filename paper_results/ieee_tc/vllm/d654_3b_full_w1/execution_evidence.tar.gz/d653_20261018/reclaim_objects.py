"""Reclaim only closed D653 downloads, reusing the existing cleanup primitives."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
TARGET = Path('/tmp/tc-d653-3bv/remote_artifacts/objects')
ORIGINAL = Path('/home/qhq/serverless_llm_experiment/artifacts/frozen/llama32_3b_a500_v1_modelscope')
sys.path.insert(0, str(MAIN/'scripts/ieee_tc'))
from cleanup_d370_aborted_cache import digest, active_reference, write_json

sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as preflight
identity = preflight.scope_identity(preflight.cg_path().name)
write_json(ROOT/'qualification_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*preflight.GIB)
assert (group/'memory.max').read_text().strip() == str(4*preflight.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2,3,26,27}
assert ROOT.name == 'd653_20261018'
for phase in ('start', 'analysis', 'analysis2', 'publication', 'publication2'):
    closed = json.loads((ROOT/(phase+'_closure.json')).read_text())
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
backup = json.loads((ROOT/'publication_receipt.json').read_text())
assert backup['passed'] and backup['head'] == backup['remote']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=MAIN, text=True).strip() == backup['head']
assert not (ROOT/'cache_cleanup_before.json').exists()
assert TARGET.is_dir() and not TARGET.is_symlink() and TARGET.resolve() == TARGET
launch = json.loads((ROOT/'launch3b.json').read_text())
assert launch['native_gpu_context_release_confirmed'] and launch['service_path_removed'] and launch['service_returncode'] == 0
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
audit_path = MAIN/'paper_results/ieee_tc/vllm/d653_3b_full_w0/audit.json'
assert digest(audit_path) == 'fa94e223f86cb108d0e808eea6b9e345463d9601e528c330545290af07132eb2'
audit = json.loads(audit_path.read_text())
assert audit['workload_passed'] and audit['offered_unique_adapters'] == 132 and audit['verified_materialized_bytes'] == 5139892912
index_path = MAIN/'paper_results/ieee_tc/inputs/20260927_3b_remote_content_index.json'
assert digest(index_path) == 'bd1826c58f00ea30dee1d3829dc11727a975127db701a1eee6c6c86b4a38f275'
index = json.loads(index_path.read_text())
expected, total = set(), 0
selected = {p.stem for p in (ROOT/'remote_resolver_evidence/receipts').glob('*.json')}
assert len(selected) == audit['offered_unique_adapters']
assert selected <= {r['id'] for r in index['artifacts']}
assert selected == {p.name for p in TARGET.iterdir() if p.is_dir()}
for row in index['artifacts']:
    if row['id'] not in selected:
        continue
    for item in row['files']:
        p, source = TARGET/row['id']/item['path'], ORIGINAL/row['id']/item['path']
        assert p.is_file() and not p.is_symlink() and source.is_file()
        assert p.stat().st_size == source.stat().st_size == item['size_bytes']
        assert (p.stat().st_dev,p.stat().st_ino) != (source.stat().st_dev,source.stat().st_ino)
        # Rehash both current cache and retained original; no stale hash assumption.
        assert digest(p) == digest(source) == item['sha256']
        expected.add(p)
        total += item['size_bytes']
assert total == audit['verified_materialized_bytes']
assert not any(p.is_symlink() for p in TARGET.rglob('*'))
assert {p for p in TARGET.rglob('*') if p.is_file()} == expected
for line in Path('/proc/self/mountinfo').read_text().splitlines():
    mount = line.split()[4]
    assert mount != str(TARGET) and not mount.startswith(str(TARGET)+'/')
assert not active_reference(TARGET)
private = str(TARGET.parent.parent)
assert not active_reference(TARGET.parent.parent)
unreadable, hits = [], []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    try:
        if proc.stat().st_uid != os.getuid():
            continue
        links = [proc/'cwd',proc/'root',*list((proc/'fd').iterdir())]
        for link in links:
            try:
                value = os.readlink(link)
                if value == private or value.startswith(private+'/'):
                    hits.append(dict(pid=proc.name,link=link.name))
            except (FileNotFoundError,ProcessLookupError):
                pass
    except (FileNotFoundError,ProcessLookupError):
        pass
    except PermissionError:
        unreadable.append(proc.name)
assert not hits, hits
future = []
for repo in (MAIN,BASE):
    result = subprocess.run(['git','grep','-l','-F',private,'--','configs','scripts'],cwd=repo,capture_output=True,text=True)
    assert result.returncode in (0,1), result.stderr
    future.extend(result.stdout.splitlines())
assert not future, future
metadata = TARGET.parent
saved = ROOT/'remote_resolver_evidence'
for name in ('receipts','journals'):
    originals = {p.relative_to(metadata) for p in (metadata/name).rglob('*') if p.is_file()}
    copies = {p.relative_to(saved) for p in (saved/name).rglob('*') if p.is_file()}
    assert originals == copies
    assert all(digest(metadata/p) == digest(saved/p) for p in originals)
assert digest(metadata/'run_contract.json') == digest(saved/'run_contract.json')
before = shutil.disk_usage('/home/qhq').free
record = dict(schema='ieee_tc_closed_download_cache_reclamation_v1',campaign=ROOT.name,
    target=str(TARGET),status='verified_before_removal',files=len(expected),payload_bytes=total,
    published_checkpoint_sha=backup['head'],
    disk_before_bytes=before,audit=dict(path=str(audit_path),sha256=digest(audit_path)),
    source_index=dict(path=str(index_path),sha256=digest(index_path)),retained_original_pool=str(ORIGINAL),
    retained_evidence=str(ROOT),all_cache_bytes_previously_hashed_by_audit=True,
    current_original_bytes_rehashed=True,current_cache_bytes_rehashed=True,current_file_sizes_and_original_inodes_verified=True,
    owned_runtime_references=hits,future_config_script_references=future,cache_symlinks_or_nested_mounts=False,
    metadata_copies_hash_match=True,unreadable_same_uid_proc_entries=sorted(set(unreadable)),
    open_fd_check_scope='readable same-UID FD/cwd/root plus fuser, not claimed complete system-wide',
    raw_results_removed=False,unique_artifacts_removed=False,recipe_sha256=digest(Path(__file__)),
    recorded_unix=time.time())
write_json(ROOT/'cache_cleanup_before.json',record)
shutil.rmtree(TARGET)
assert not TARGET.exists()
after = shutil.disk_usage('/home/qhq').free
write_json(ROOT/'cache_cleanup_after.json',dict(schema=record['schema'],campaign=ROOT.name,
    target=str(TARGET),removed=True,disk_before_bytes=before,disk_after_bytes=after,
    observed_reclaimed_bytes=after-before,before_receipt_sha256=digest(ROOT/'cache_cleanup_before.json'),
    raw_results_removed=False,unique_artifacts_removed=False,recorded_unix=time.time()))
print(json.dumps(dict(removed=str(TARGET),files=len(expected),payload_bytes=total,
    observed_reclaimed_bytes=after-before,disk_after_bytes=after,unreadable_same_uid_proc_entries=sorted(set(unreadable)))))
