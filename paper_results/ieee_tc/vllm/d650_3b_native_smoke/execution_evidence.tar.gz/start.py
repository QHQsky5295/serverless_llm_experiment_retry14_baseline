"""D650: existing native Resident launcher, frozen 3B 100-request inputs."""
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
PRIOR = RAW.parent/'d649_20261018'
sys.path[:0] = [str(ROOT), str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from prepare_ieee_tc_serverless_stack import load_http_replay_plan, validate_http_lifecycle_contract
from replay_vllm_engine_trace import validate_native_service_config

def read(path):
    return json.loads(path.read_text())

def save(name, value):
    with (RAW/name).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()

assert RAW.name == 'd650_20261018'
assert not any((RAW/name).exists() for name in ('launch3b.json', 'launch3b.launch', 'model3b', 'input_identity.json'))
assert not Path('/tmp/tc-d650-3bv').exists()
identity = p.scope_identity(p.cg_path().name)
save('start_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
backup = read(PRIOR/'backup_receipt.json')
assert backup['passed']
head, basehead = git(ROOT, 'rev-parse', 'HEAD'), git(BASE, 'rev-parse', 'HEAD')
assert head == backup['main']['head'] == '0b0b044951e8f6246fdf45e058b9a0656a089791'
assert basehead == backup['baseline']['head'] == 'e16af33aaf41f02a62ecdce59f6f3227813244c3'
assert git(ROOT, 'ls-remote', 'faaslora_origin', 'refs/heads/retry14_continuous_queue_v2').split()[0] == head
assert git(BASE, 'ls-remote', 'origin', 'refs/heads/main').split()[0] == basehead
for phase in ('qualification', 'qualification2', 'analysis', 'backup'):
    closed = read(PRIOR/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
for repo, paths in ((ROOT, ['faaslora', 'scripts', 'configs/ieee_tc', 'tests']),
                    (BASE, ['scripts/prepare_ieee_tc_serverless_stack.py', 'scripts/replay_vllm_engine_trace.py',
                            'scripts/ieee_tc_serverless_measurement.py', 'configs/ieee_tc', 'tests/test_ieee_tc_vllm_service.py'])):
    assert not git(repo, 'diff', '--name-only', 'HEAD', '--', *paths)
binding = read(PRIOR/'qualification.json')
assert binding['passed'] and binding['tests'] == 89 and binding['no_gpu_run']
for path, sha in {**binding['refs'], **binding['preserved']}.items():
    assert p.digest(Path(path)) == sha, path
assert (RAW/'http_3b_100.json').read_bytes() == (PRIOR/'http_3b_100.json').read_bytes()
http = read(RAW/'http_3b_100.json')
config = BASE/'configs/ieee_tc/vllm_3b_resident_native_compiler_v1.json'
validate_http_lifecycle_contract(http)
validate_native_service_config(read(config), http)
plan = load_http_replay_plan(http)
assert plan.identity() == binding['views']['100']['plan']
assert p.digest(Path(http['pool_index'])) == http['pool_index_sha256']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([ROOT], 32*p.GIB)
assert gate['preflight_pass'], gate['issues']
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
session = 'tc-d650-vllm-3b100'
assert subprocess.run(['tmux', 'has-session', '-t', session], stderr=subprocess.DEVNULL).returncode != 0
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
helpers = sorted([*RAW.glob('*.py'), *RAW.glob('*.sh')])
for path in helpers:
    if path.suffix == '.py':
        ast.parse(path.read_text())
    else:
        subprocess.run(['bash', '-n', str(path)], check=True)
save('input_identity.json', dict(**binding['views']['100'], http_sha256=p.digest(RAW/'http_3b_100.json'),
    config_path=str(config), config_sha256=p.digest(config), main_execution_commit=head,
    baseline_execution_commit=basehead, qualification_only=True, resident_reference_candidate=False,
    no_new_trace_or_weights=True, complete_3b_reference_pending=True))
save('launch_gate.json', dict(passed=True, head=head, baseline_head=basehead,
    qualification_path=str(PRIOR/'qualification.json'), qualification_sha256=p.digest(PRIOR/'qualification.json'),
    gate=gate, protected=protected, scope=identity,
    helpers=[dict(path=str(path), sha256=p.digest(path), content=path.read_text()) for path in helpers]))
subprocess.run(['bash', str(RAW/'start_remote.sh')], check=True)
subprocess.run([sys.executable, str(RAW/'check_remote_health_stdlib.py')], cwd=ROOT, check=True)
subprocess.run(['tmux', 'new-session', '-d', '-s', session, '-c', str(BASE),
                f'bash {RAW}/run3b.sh > {RAW}/runner.log 2>&1'], check=True)
receipt = RAW/'launch3b.launch/exec_receipt.json'
deadline = time.monotonic()+210
while not receipt.exists():
    if time.monotonic() > deadline:
        raise TimeoutError('observation timeout only; inspect the same tmux, never restart')
    time.sleep(.1)
launched = read(receipt)
captured = p.scope_identity(Path(launched['auxiliary_path']).name)
save('service_aux_identity.json', captured)
save('start_receipt.json', dict(launched=True, head=head, baseline_head=basehead, tmux=session,
    starter_identity=identity, launcher_identity=captured))
print(json.dumps(dict(launched=True, tmux=session, head=head, baseline_head=basehead)))
