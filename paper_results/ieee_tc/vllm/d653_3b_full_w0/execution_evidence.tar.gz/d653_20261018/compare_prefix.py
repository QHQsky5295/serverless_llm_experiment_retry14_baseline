"""Reuse D652/D422 retained native sequence comparison, without an HF oracle.

Offline audit only. Exact equality is an observation, never an admission gate.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OLD = RAW.parent/'d652_20261018'
sys.path[:0] = [str(MAIN), str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from prepare_ieee_tc_serverless_stack import load_http_replay_plan

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'analysis2_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27}
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
closed = json.loads((RAW/'analysis_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()

sources, runs = [], []
for root, count, audit_name in ((OLD, 1000, 'audit_prefix1000.json'), (RAW, 4000, 'audit_full4000.json')):
    audit_path = root/audit_name
    audit = json.loads(audit_path.read_text())
    assert audit['measurement_complete'] and audit['workload_passed']
    assert audit['native_revalidated_requests'] == count and audit['model_key'] == '3b'
    replay = root/'launch3b.launch/replay.jsonl'
    assert p.digest(replay) == audit['replay_sha256']
    events = [json.loads(line) for line in replay.read_text().splitlines()]
    contracts = {e['request_id']: e for e in events if e['event'] == 'request_contract'}
    observed = {e['request_id']: e['body']['metrics']['ieee_tc'] for e in events if e['event'] == 'http_raw_response'}
    assert len(contracts) == len(observed) == count and set(contracts) == set(observed)
    cfgpath = root/f'http_3b_{count}.json'
    plan = load_http_replay_plan(json.loads(cfgpath.read_text()))
    assert plan.identity() == audit['source_plan']
    runs.append((plan, contracts, observed))
    sources.extend([audit_path, replay, cfgpath, root/'model3b/worker_config.json'])
assert runs[0][0].identity()['source_sha256'] == runs[1][0].identity()['source_sha256']
ids = [entry.request_id for entry in runs[0][0].entries]
assert ids == [entry.request_id for entry in runs[1][0].entries[:1000]]
rows = []
for rid in ids:
    before, after = runs[0][1][rid], runs[1][1][rid]
    assert before == after, rid
    outputs = [run[2][rid] for run in runs]
    for output in outputs:
        tokens = output['completion_token_ids']
        assert len(tokens) == before['target_tokens'] and all(type(t) is int and t >= 0 for t in tokens)
        assert hashlib.sha256(json.dumps(tokens, separators=(',', ':')).encode()).hexdigest() == output['completion_token_ids_sha256']
        assert output['native_lora_name'] == before['adapter_id']
        assert output['native_prompt_token_ids_sha256'] == before['native_prompt_token_ids_sha256']
    assert outputs[0]['native_prompt_token_ids'] == outputs[1]['native_prompt_token_ids']
    divergence = next((i for i, (a, b) in enumerate(zip(outputs[0]['completion_token_ids'], outputs[1]['completion_token_ids'])) if a != b), None)
    rows.append(dict(request_id=rid, adapter_id=before['adapter_id'], target_tokens=before['target_tokens'],
        exact_sequence_match=divergence is None, first_divergent_position=divergence,
        d652_ids_sha256=outputs[0]['completion_token_ids_sha256'], d653_ids_sha256=outputs[1]['completion_token_ids_sha256']))
sources.extend([Path(__file__), OLD/'compare_prefix.py', RAW.parent/'d422_20261011/audit_reference_prefix.py'])
result = dict(schema='ieee_tc_retained_native_prefix_comparison_v1', passed=True,
    count=1000, total_run_requests=4000, source_indices_inclusive=[0, 999],
    exact_sequences=sum(r['exact_sequence_match'] for r in rows),
    changed_sequences=sum(not r['exact_sequence_match'] for r in rows), requests=rows,
    independent_numerical_proof=None, new_gpu_experiment=False, exact_match_admission_gate=False,
    limitation='Same-request native output consistency only. No independent HF/PEFT witness; no numerical correctness claim or attribution of differences to rounding; no claim about the other 3000 requests.',
    sources=[dict(path=str(path), sha256=p.digest(path)) for path in sources])
save(RAW/'native_prefix_comparison.json', result)
print(json.dumps({k: v for k, v in result.items() if k not in ('requests', 'sources')}))
