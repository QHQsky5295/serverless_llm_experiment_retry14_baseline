"""D649 explicit two-repository checkpoint, using the established bounded backup checks."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
OUT = MAIN/'paper_results/ieee_tc/vllm/d649_3b_resident_inputs'
sys.path.insert(0, str(MAIN))
from scripts import ieee_tc_preflight as p

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save(RAW/'backup_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
gate = p.preflight([MAIN, BASE, RAW], 32*1024*1024)
save(RAW/'backup_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
qualification = read(RAW/'qualification.json')
assert qualification['passed'] and qualification['tests'] == 89 and qualification['no_gpu_run']
for path, sha in {**qualification['refs'], **qualification['preserved']}.items():
    assert p.digest(Path(path)) == sha, path
closures = {}
for phase in ('qualification', 'qualification2', 'analysis'):
    closed = read(RAW/(phase+'_closure.json'))
    assert closed['passed'] and closed['actual_recursive_procs_empty'] and closed['path_gone']
    assert not Path(closed['identity']['path']).exists()
    closures[phase] = closed
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
token = Path('/home/qhq/.config/primelora-tc-d75/artifact.token').read_bytes().strip()

def secret_check(data):
    assert token and token not in data
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}', data)

def checkpoint(repo, names, parent, remote, branch, message):
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
    assert git('rev-parse', 'HEAD') == parent
    assert git('branch', '--show-current') == branch
    assert not git('diff', '--cached', '--name-only')
    subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
    for name in names:
        secret_check((repo/name).read_bytes())
    assert 'configs/generated/lora_manifest_1000.json' not in names
    subprocess.run(['git', 'add', '--', *names], cwd=repo, check=True)
    assert set(git('diff', '--cached', '--name-only').splitlines()) == set(names)
    for name in names:
        assert subprocess.check_output(['git', 'show', ':'+name], cwd=repo) == (repo/name).read_bytes()
    subprocess.run(['git', 'diff', '--cached', '--check'], cwd=repo, check=True)
    subprocess.run(['git', 'commit', '-m', message], cwd=repo, check=True)
    subprocess.run(['git', 'push', remote, branch], cwd=repo, check=True)
    head = git('rev-parse', 'HEAD')
    remote_head = git('ls-remote', remote, 'refs/heads/'+branch).split()[0]
    assert head == remote_head
    record = dict(repo=str(repo), head=head, remote=remote_head, files=names, passed=True)
    save(RAW/(repo.name+'_checkpoint.json'), record)
    return record

# Cross-repo source/config identity is recorded before the main publication commit.
base_checkpoint = checkpoint(BASE,
    ['configs/ieee_tc/vllm_3b_resident_native_compiler_v1.json', 'tests/test_ieee_tc_vllm_service.py'],
    '80e08b4c6e7c2874b1b237500a00811ec06cd8c5', 'origin', 'main',
    'tc: reuse qualified 3B model parameters for native Resident reference (D649)')
members = [RAW/name for name in ('qualify.py', 'qualify2.py', 'qualify3.py', 'close.py', 'backup.py',
    'http_3b_100.json', 'qualification_identity.json', 'qualification_gate.json', 'qualification_closure.json',
    'qualification2_identity.json', 'qualification2_gate.json', 'qualification2_closure.json',
    'analysis_identity.json', 'analysis_gate.json', 'analysis_closure.json', 'qualification.json',
    'tests_0.log', 'tests_1.log', 'tests_0.json', 'tests_1.json',
    'tests2_0.log', 'tests2_1.log', 'tests2_0.json', 'tests2_1.json',
    'tests3_0.log', 'tests3_1.log', 'tests3_0.json', 'tests3_1.json',
    'backup_gate.json', 'serverless_llm_baselines_checkpoint.json')]
for path in members:
    secret_check(path.read_bytes())
    if path.suffix == '.py':
        ast.parse(path.read_text())
OUT.mkdir(parents=True, exist_ok=False)
with tarfile.open(OUT/'execution_evidence.tar.gz', 'x:gz') as bundle:
    for path in members:
        bundle.add(path, arcname=path.name, recursive=False)
with tarfile.open(OUT/'execution_evidence.tar.gz') as bundle:
    for path in members:
        assert hashlib.sha256(bundle.extractfile(path.name).read()).hexdigest() == p.digest(path)
save(OUT/'http_3b_100.json', read(RAW/'http_3b_100.json'))
save(OUT/'qualification.json', dict(passed=True, tests=89, no_gpu_run=True,
    qualification=qualification, closures=closures, protected=protected,
    baseline_checkpoint=base_checkpoint, main_parent='06f5f1574352f176b896a2d3c7f4e6f1b26d9a08',
    failed_test_drivers_retained=2, service_algorithm_unchanged=True,
    archive_sha256=p.digest(OUT/'execution_evidence.tar.gz'),
    archive_members={path.name: dict(path=str(path), sha256=p.digest(path)) for path in members},
    caveat='3B input/configuration and CPU regression only; no Resident resource or main performance result.'))
outputs = ['qualification.json', 'execution_evidence.tar.gz', 'http_3b_100.json']
with (OUT/'result.sha256').open('x') as handle:
    for name in outputs:
        handle.write(p.digest(OUT/name)+'  '+name+'\n')
subprocess.run(['sha256sum', '-c', 'result.sha256'], cwd=OUT, check=True, stdout=subprocess.DEVNULL)
names = ['scripts/ieee_tc/audit_d402_serverlessllm_path.py', 'tests/test_tc_serverless_qualification_population.py',
         'docs/ieee_tc/D649_3B_RESIDENT_INPUT_QUALIFICATION.md', 'docs/ieee_tc/EXECUTION_STATUS.md']
names += [str((OUT/name).relative_to(MAIN)) for name in outputs+['result.sha256']]
main_checkpoint = checkpoint(MAIN, names, '06f5f1574352f176b896a2d3c7f4e6f1b26d9a08',
    'faaslora_origin', 'retry14_continuous_queue_v2',
    'tc: bind explicit 3B Resident inputs and SLO identity without changing metrics (D649)')
for path, sha in qualification['preserved'].items():
    assert p.digest(Path(path)) == sha
save(RAW/'backup_receipt.json', dict(passed=True, identity=identity,
    main=main_checkpoint, baseline=base_checkpoint, protected=protected))
print(json.dumps(dict(passed=True, main=main_checkpoint['head'], baseline=base_checkpoint['head'], tests=89)))
