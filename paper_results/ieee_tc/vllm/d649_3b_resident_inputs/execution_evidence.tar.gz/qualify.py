"""D649 CPU-only 3B input/model binding; reuse the native service and existing tests."""
import ast
import json
import os
from pathlib import Path
import re
import subprocess
import sys

MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
RAW = Path(__file__).resolve().parent
sys.path[:0] = [str(MAIN), str(BASE/'scripts')]
from scripts import ieee_tc_preflight as p
from scripts.ieee_tc.audit_d402_serverlessllm_path import validate_metric_model
from prepare_ieee_tc_serverless_stack import load_http_replay_plan, validate_http_lifecycle_contract
from replay_vllm_engine_trace import validate_native_service_config

def read(path):
    return json.loads(path.read_text())

def save(name, value):
    with (RAW/name).open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)

identity = p.scope_identity(p.cg_path().name)
save('qualification_identity.json', identity)
group = Path(identity['path'])
assert (group/'memory.high').read_text().strip() == str(3*p.GIB)
assert (group/'memory.max').read_text().strip() == str(4*p.GIB)
assert (group/'memory.swap.max').read_text().strip() == '0'
assert os.sched_getaffinity(0) == {2, 3, 26, 27} and os.environ['CUDA_VISIBLE_DEVICES'] == ''
assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
assert p.check_plan() == 'd7acd08127d4f4513b23af6dd57a9647cf047570f2b563e361e716ccb0b32b83'
gate = p.preflight([MAIN, RAW], 64*1024*1024)
save('qualification_gate.json', gate)
assert gate['preflight_pass'], gate['issues']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=MAIN, text=True).strip() == '06f5f1574352f176b896a2d3c7f4e6f1b26d9a08'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=BASE, text=True).strip() == '80e08b4c6e7c2874b1b237500a00811ec06cd8c5'
preserved = {
    MAIN/'configs/generated/lora_manifest_1000.json': '3b69bd0a6888aa56e98c3b9efb61234860d4b80f25729cfea6b79126d19127df',
    BASE/'scripts/replay_openai_trace.py': '04f3eb52c64c6d684dec3ecef1e6a450d687e0922430c2d77932917e4a38fc22',
    BASE/'scripts/run_serverlessllm_relayserve_continuation.sh': '337dceec7a528b7816e5a55e81d3c26f3feb1499976a4d049faa69809acec499',
}
for path, sha in preserved.items():
    assert p.digest(path) == sha, str(path)
prior = RAW.parent.parent/'p2_backend_qualification/d648_20261017'
for phase in ('start', 'analysis', 'publication', 'backup'):
    closed = read(prior/(phase+'_closure.json'))
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()

config = BASE/'configs/ieee_tc/vllm_3b_resident_native_compiler_v1.json'
http = read(RAW/'http_3b_100.json')
cfg = read(config)
validate_http_lifecycle_contract(http)
validate_native_service_config(cfg, http)
slo = MAIN/'paper_results/ieee_tc/protocols/20261017_3b_slo_d648_frozen.json'
assert p.digest(slo) == 'd15123570c4a8d830515ca942d1db553c6717ffc1a40ade5c1546d35e2bed9d8'
frozen = read(slo)
assert validate_metric_model(http, '3b', MAIN, frozen) == 'llama32_3b_main_modelscope'
for key in ('path', 'audit_path'):
    sha_key = 'sha256' if key == 'path' else 'audit_sha256'
    assert p.digest(MAIN/frozen['calibration'][key]) == frozen['calibration'][sha_key]
assert p.digest(Path(http['pool_index'])) == http['pool_index_sha256']
pool = read(Path(http['pool_index']))['artifacts']
ids = {row['id'] for row in pool}
assert len(ids) == len(pool) == 500
views = {}
for count in (100, 1000, 4000):
    plan = load_http_replay_plan(dict(http, request_count=count))
    rows = [json.loads(entry.source_json) for entry in plan.entries]
    assert len(rows) == count and {row['adapter_id'] for row in rows} <= ids
    views[str(count)] = dict(plan=plan.identity(), actual_unique_adapters=len({r['adapter_id'] for r in rows}),
                            target_tokens=sum(min(r['expected_output_tokens'], 256) for r in rows))
assert views['4000']['plan']['view_sha256'] == '0d998f48a006d638dda9b8d714f667fe3a87f4d2c88044ce19a816b308494a37'
coverage = load_http_replay_plan(dict(http, request_count=500, request_view='adapter_coverage_v1',
                                    experiment_role='adapter_pool_functional_coverage'))
assert {json.loads(row.source_json)['adapter_id'] for row in coverage.entries} == ids
views['coverage'] = dict(plan=coverage.identity(), actual_unique_adapters=500,
                         purpose='functional mapping, not a W0 performance run')

test_groups = [(MAIN, ['tests.test_tc_serverless_qualification_population', 'tests.test_tc_loquetier_evidence']),
               (BASE, ['tests.test_ieee_tc_vllm_service'])]
tests = []
for number, (repo, modules) in enumerate(test_groups):
    log = RAW/f'tests_{number}.log'
    with log.open('x') as handle:
        proc = subprocess.run([sys.executable, '-B', '-m', 'unittest', *modules, '-v'], cwd=repo,
                              stdout=handle, stderr=subprocess.STDOUT, timeout=180)
    match = re.search(r'Ran (\d+) tests? in ', log.read_text())
    tests.append(dict(repo=str(repo), modules=modules, returncode=proc.returncode,
                      tests=int(match.group(1)) if match else None, log_sha256=p.digest(log)))
    save(f'tests_{number}.json', tests[-1])
    assert proc.returncode == 0 and match, str(log)
native_sources = [BASE/'scripts'/name for name in ('replay_vllm_engine_trace.py',
                  'prepare_ieee_tc_serverless_stack.py', 'ieee_tc_serverless_measurement.py')]
for path in native_sources:
    original = subprocess.check_output(['git', 'show', 'HEAD:'+str(path.relative_to(BASE))], cwd=BASE)
    assert path.read_bytes() == original, str(path)
refs = native_sources + [config, RAW/'http_3b_100.json', RAW/'qualify.py', RAW/'close.py', slo,
    MAIN/'scripts/ieee_tc/audit_d402_serverlessllm_path.py',
    MAIN/'tests/test_tc_serverless_qualification_population.py', MAIN/'tests/test_tc_loquetier_evidence.py',
    BASE/'tests/test_ieee_tc_vllm_service.py', MAIN/'configs/ieee_tc/20261017_d641_3b_native_source.yaml',
    MAIN/'docs/ieee_tc/METRIC_PROTOCOL_FROZEN_V1.md', MAIN/'docs/ieee_tc/METRIC_PROTOCOL_SINGLE_RUN_V2.md']
for path in refs:
    if path.suffix == '.py':
        ast.parse(path.read_text())
protected = p.verify_seal(RAW.parent.parent/'slora_qualification/d435_20261011/protected_before.json')
assert protected['pass'] and protected['entry_count'] == 147
for path, sha in preserved.items():
    assert p.digest(path) == sha
save('qualification.json', dict(passed=True, tests=sum(row['tests'] for row in tests), test_groups=tests,
    views=views, scope=identity, protected=protected, no_policy_change=True, no_gpu_run=True,
    native_service_sources_unchanged=True, slo_reference_frozen=True, resident_reference_frozen=False,
    refs={str(path): p.digest(path) for path in refs}, preserved={str(k): v for k, v in preserved.items()},
    limitations=['CPU preparation only; 3B HTTP smoke, coverage, 1000 compatibility and full 4000 not executed.',
                 'Known source seed42/development identity retained; not unseen evaluation or performance evidence.']))
print(json.dumps(dict(passed=True, tests=sum(row['tests'] for row in tests), views=views)))
