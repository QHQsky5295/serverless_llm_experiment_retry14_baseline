"""Retain D649's failed test driver; fix only the colliding test package context."""
import ast
import hashlib
import json
from pathlib import Path

RAW = Path(__file__).resolve().parent
source = RAW/'qualify.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '6b7c1dff5a24cbd00a28c0476e6ebbfa5f8f29c8c56080c358d907e7e9662e3e'
closed = json.loads((RAW/'qualification_closure.json').read_text())
assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
code = source.read_text()
for old, new in [('qualification_identity.json', 'qualification2_identity.json'),
                 ('qualification_gate.json', 'qualification2_gate.json'),
                 ("f'tests_{number}.log'", "f'tests2_{number}.log'"),
                 ("f'tests_{number}.json'", "f'tests2_{number}.json'"),
                 ("RAW/'qualify.py'", "RAW/'qualify.py', RAW/'qualify2.py'")]:
    assert code.count(old) == 1, old
    code = code.replace(old, new)
old = """proc = subprocess.run([sys.executable, '-B', '-m', 'unittest', *modules, '-v'], cwd=repo,
                              stdout=handle, stderr=subprocess.STDOUT, timeout=180)"""
new = """command = [sys.executable, '-B', '-m', 'unittest', *modules, '-v']
        cwd = repo
        if repo == BASE:
            # Production starts a script under BASE/scripts, not the BASE package.
            # Load MAIN's namespace before adding the BASE test package; no mocked module.
            bootstrap = ('import sys; sys.path.insert(0, '+repr(str(MAIN))+'); '
                         'import scripts.ieee_tc_native_toolchain; '
                         'sys.path.insert(0, '+repr(str(BASE))+'); '
                         'import unittest; unittest.main(module=None, argv=["unittest", *sys.argv[1:]])')
            command = [sys.executable, '-I', '-B', '-c', bootstrap, *modules, '-v']
            cwd = MAIN
        proc = subprocess.run(command, cwd=cwd,
                              stdout=handle, stderr=subprocess.STDOUT, timeout=180)"""
assert code.count(old) == 1
code = code.replace(old, new)
ast.parse(code)
exec(compile(code, str(source), 'exec'))
