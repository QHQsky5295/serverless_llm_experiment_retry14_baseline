"""Use D534's existing file-qualified baseline-test loader; retain both failures."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest

RAW = Path(__file__).resolve().parent
MAIN = Path('/home/qhq/serverless_llm_experiment_retry14_baseline')
BASE = Path('/home/qhq/serverless_llm_baselines')
sys.path[:0] = [str(MAIN), str(BASE/'scripts')]
if sys.argv[1:] == ['--baseline-tests']:
    # Same explicit file loader as D534 qualify2.py, now run all service tests.
    modules = {}
    for name in ('test_ieee_tc_vllm_measurement', 'test_ieee_tc_vllm_service'):
        spec = importlib.util.spec_from_file_location('tests.'+name, BASE/'tests'/(name+'.py'))
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        modules[name] = module
    suite = unittest.defaultTestLoader.loadTestsFromModule(modules['test_ieee_tc_vllm_service'])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() and not result.skipped else 1)

source = RAW/'qualify.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '6b7c1dff5a24cbd00a28c0476e6ebbfa5f8f29c8c56080c358d907e7e9662e3e'
for phase in ('qualification', 'qualification2'):
    closed = json.loads((RAW/(phase+'_closure.json')).read_text())
    assert closed['passed'] and closed['path_gone'] and not Path(closed['identity']['path']).exists()
code = source.read_text()
for old, new in [('qualification_identity.json', 'analysis_identity.json'),
                 ('qualification_gate.json', 'analysis_gate.json'),
                 ("f'tests_{number}.log'", "f'tests3_{number}.log'"),
                 ("f'tests_{number}.json'", "f'tests3_{number}.json'"),
                 ("RAW/'qualify.py'", "RAW/'qualify.py', RAW/'qualify2.py', RAW/'qualify3.py'")]:
    assert code.count(old) == 1, old
    code = code.replace(old, new)
old = """proc = subprocess.run([sys.executable, '-B', '-m', 'unittest', *modules, '-v'], cwd=repo,
                              stdout=handle, stderr=subprocess.STDOUT, timeout=180)"""
new = """command = ([sys.executable, '-B', str(RAW/'qualify3.py'), '--baseline-tests'] if repo == BASE
                   else [sys.executable, '-B', '-m', 'unittest', *modules, '-v'])
        proc = subprocess.run(command, cwd=MAIN,
                              stdout=handle, stderr=subprocess.STDOUT, timeout=180)"""
assert code.count(old) == 1
code = code.replace(old, new)
ast.parse(code)
exec(compile(code, str(source), 'exec'))
