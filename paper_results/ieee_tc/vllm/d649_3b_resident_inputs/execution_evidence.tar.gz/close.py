"""Reuse exact-owned recursive-empty closure; no broad process cleanup."""
from pathlib import Path
source = Path('/home/qhq/serverless_llm_experiment/results/ieee_tc/p2_backend_qualification/d550_20261015/close.py')
exec(compile(source.read_text(), str(source), 'exec'))
